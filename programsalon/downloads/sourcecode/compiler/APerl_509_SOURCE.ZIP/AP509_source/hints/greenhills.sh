ccflags="$ccflags -X18"
