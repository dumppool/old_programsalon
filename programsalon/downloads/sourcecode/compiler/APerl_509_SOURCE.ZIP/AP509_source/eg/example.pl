print "Hello from ActivePerl!";
