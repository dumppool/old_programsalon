print "LIBRARY $ARGV[0]\n";
print "CODE LOADONCALL\n";
print "DATA LOADONCALL NONSHARED MULTIPLE\n";
print "EXPORTS\n";
print "\tboot_$ARGV[0]\n"
