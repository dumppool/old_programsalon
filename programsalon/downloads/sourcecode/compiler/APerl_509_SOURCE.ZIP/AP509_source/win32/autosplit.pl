use AutoSplit;

autosplit($ARGV[0], $ARGV[1], 0, 1, 1);
