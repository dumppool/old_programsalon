int array[10];
main()
{
	char i;
	i=4;
	i=4;
	i=4;
	i=4;
	array[i++] = 4;

}