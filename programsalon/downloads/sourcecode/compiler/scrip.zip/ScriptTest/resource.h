//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ScriptTest.rc
//
#define IDR_SRVR_INPLACE                4
#define IDR_SRVR_EMBEDDED               5
#define IDR_CNTR_INPLACE                6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_FAILED_TO_CREATE            102
#define IDR_MAINFRAME                   128
#define IDR_SCRTSTTYPE                  129
#define IDD_SCRIPT_DIALOG               131
#define IDC_SCRIPT_TEXT                 1000
#define IDC_SCRIPT_TYPE                 1004
#define ID_CANCEL_EDIT_CNTR             32768
#define ID_CANCEL_EDIT_SRVR             32769
#define ID_SCRIPT_RUN                   32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
