// ScriptTestDoc.cpp : implementation of the CScriptTestDoc class
//

#include "stdafx.h"
#include "ScriptTest.h"

#include "ScriptTestDoc.h"
#include "CntrItem.h"
#include "SrvrItem.h"

#include "ScriptDialog.h"

#include "Utils.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#if 0
// SGW: I added this.

const GUID CDECL BASED_CODE _tlid =
//		{ 0xc099ea71, 0x4220, 0x11d0, { 0x8a, 0x1e, 0, 0xa0, 0x24, 0xa, 0x3f, 0xa0 } };
const WORD _wVerMajor = 1;
const WORD _wVerMinor = 0;

IMPLEMENT_OLETYPELIB(CScriptTestDoc, _tlid, _wVerMajor, _wVerMinor)
#endif
/////////////////////////////////////////////////////////////////////////////
// CScriptTestDoc

IMPLEMENT_DYNCREATE(CScriptTestDoc, COleServerDoc)

BEGIN_MESSAGE_MAP(CScriptTestDoc, COleServerDoc)
	//{{AFX_MSG_MAP(CScriptTestDoc)
	ON_COMMAND(ID_SCRIPT_RUN, OnScriptRun)
	//}}AFX_MSG_MAP
	// Enable default OLE container implementation
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, COleServerDoc::OnUpdatePasteMenu)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE_LINK, COleServerDoc::OnUpdatePasteLinkMenu)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_CONVERT, COleServerDoc::OnUpdateObjectVerbMenu)
	ON_COMMAND(ID_OLE_EDIT_CONVERT, COleServerDoc::OnEditConvert)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, COleServerDoc::OnUpdateEditLinksMenu)
	ON_COMMAND(ID_OLE_EDIT_LINKS, COleServerDoc::OnEditLinks)
	ON_UPDATE_COMMAND_UI(ID_OLE_VERB_FIRST, COleServerDoc::OnUpdateObjectVerbMenu)
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CScriptTestDoc, COleServerDoc)
	//{{AFX_DISPATCH_MAP(CScriptTestDoc)
	DISP_PROPERTY_EX(CScriptTestDoc, "Text", GetText, SetText, VT_BSTR)
	DISP_FUNCTION(CScriptTestDoc, "MsgBox", MsgBox, VT_EMPTY, VTS_BSTR)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IScrTst to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {9A9CBD93-6595-11D0-8A26-00A0240A3FA0}
static const IID IID_IScrTst =
{ 0x9a9cbd93, 0x6595, 0x11d0, { 0x8a, 0x26, 0x0, 0xa0, 0x24, 0xa, 0x3f, 0xa0 } };

BEGIN_INTERFACE_MAP(CScriptTestDoc, COleServerDoc)
	INTERFACE_PART(CScriptTestDoc, IID_IScrTst, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScriptTestDoc construction/destruction

CScriptTestDoc::CScriptTestDoc() :
  m_strText("Hello, World!"),
  m_pScriptDialog(NULL)
{
	// Use OLE compound files
	EnableCompoundFile();

	// TODO: add one-time construction code here

	EnableAutomation();

	AfxOleLockApp();
}

CScriptTestDoc::~CScriptTestDoc()
{
	AfxOleUnlockApp();

	// delete the script dialog
	delete m_pScriptDialog;
}

BOOL CScriptTestDoc::OnNewDocument()
{
	if (!COleServerDoc::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CScriptTestDoc server implementation

COleServerItem* CScriptTestDoc::OnGetEmbeddedItem()
{
	// OnGetEmbeddedItem is called by the framework to get the COleServerItem
	//  that is associated with the document.  It is only called when necessary.

	CScriptTestSrvrItem* pItem = new CScriptTestSrvrItem(this);
	ASSERT_VALID(pItem);
	return pItem;
}

/////////////////////////////////////////////////////////////////////////////
// CScriptTestDoc serialization

void CScriptTestDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_strText;
	}
	else
	{
		ar >> m_strText;
	}

	// Calling the base class COleServerDoc enables serialization
	//  of the container document's COleClientItem objects.
	COleServerDoc::Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CScriptTestDoc diagnostics

#ifdef _DEBUG
void CScriptTestDoc::AssertValid() const
{
	COleServerDoc::AssertValid();
}

void CScriptTestDoc::Dump(CDumpContext& dc) const
{
	COleServerDoc::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CScriptTestDoc commands

void CScriptTestDoc::OnScriptRun() 
{
	TRACE_IN("CScriptTestDoc::OnScriptRun");
	
	// if the script dialog hasn't been created yet ...
	if (m_pScriptDialog == NULL) {
		// create it now
		m_pScriptDialog = new CScriptDialog(this);
	}

	// invoke the script dialog
	ASSERT_POINTER(m_pScriptDialog, CScriptDialog);
	m_pScriptDialog->DoModal();
}

BSTR CScriptTestDoc::GetText() 
{
	TRACE_IN("CScriptTestDoc::GetText");

	return m_strText.AllocSysString();
}

void CScriptTestDoc::SetText(LPCTSTR lpszNewValue) 
{
	TRACE_IN("CScriptTestDoc::SetText");

	// if new value is different from the old one ...
	if (m_strText != lpszNewValue) {
		// save the new text value
		m_strText = lpszNewValue;

		// mark us modified
		SetModifiedFlag();

		// update all views
		UpdateAllViews(NULL);
	}
}

CString CScriptTestDoc::GetTextAsCString() const
{
	TRACE_IN("CScriptTestDoc::GetTextAsCString");

	return m_strText;
}

void CScriptTestDoc::MsgBox(LPCTSTR strMsg) 
{
	TRACE_IN("CScriptTestDoc::MsgBox");

	AfxMessageBox(strMsg);
}
