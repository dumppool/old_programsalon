// ScriptDialog.cpp : implementation file
//

#include "stdafx.h"
#include "ScriptTest.h"
#include "ScriptDialog.h"
#include "ScriptTestScriptEngine.h"
#include "ScriptTestDoc.h"
#include "Utils.h"

#include <AFXPRIV.H> // for OLE string to MBCS conversion macros

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// The GUID used to identify the coclass of the VB Script engine
// 	{B54F3741-5B07-11cf-A4B0-00AA004A55E8}
const CLSID CLSID_VBScript =
	{ 0xb54f3741, 0x5b07, 0x11cf, { 0xa4, 0xb0, 0x00, 0xaa, 0x00, 0x4a, 0x55, 0xe8 } };

// The GUID used to identify the coclass of the JavaScript engine
// 	{f414c260-6ac0-11cf-b6d1-00aa00bbbb58}
const CLSID CLSID_JScript =
	{ 0xf414c260, 0x6ac0, 0x11cf, { 0xb6, 0xd1, 0x00, 0xaa, 0x00, 0xbb, 0xbb, 0x58 } };

/////////////////////////////////////////////////////////////////////////////
// CScriptDialog dialog

CScriptDialog::CScriptDialog(CScriptTestDoc* pDoc, CWnd* pParent /*=NULL*/) :
	CDialog(CScriptDialog::IDD, pParent),
  m_pDoc(pDoc)
{
	ASSERT(m_pDoc != NULL);
	//{{AFX_DATA_INIT(CScriptDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

BEGIN_MESSAGE_MAP(CScriptDialog, CDialog)
	//{{AFX_MSG_MAP(CScriptDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

const CLSID* CScriptDialog::GetScriptEngineCLSID() const
{
	TRACE_IN("CScriptDialog::GetScriptEngineCLSID");

	// get the script type combo box
	CComboBox* pComboBox = (CComboBox*)GetDlgItem(IDC_SCRIPT_TYPE);
	ASSERT(pComboBox != NULL);

	// get the index of the currently selected item
	int nIndex = pComboBox->GetCurSel();
	ASSERT(nIndex != CB_ERR);

	// get the current item's CLSID
	CLSID* pCLSID = (CLSID*)pComboBox->GetItemDataPtr(nIndex);
	ASSERT(pCLSID != NULL);

	return pCLSID;
}

CString CScriptDialog::GetScript() const
{
	CString strScript;

	// get the script edit control
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_SCRIPT_TEXT);
	ASSERT(pEdit != NULL);

	// get the edit control's text
	pEdit->GetWindowText(strScript);

	return strScript;
}

/////////////////////////////////////////////////////////////////////////////
// CScriptDialog message handlers

BOOL CScriptDialog::OnInitDialog() 
{
	TRACE_IN("CScriptDialog::OnInitDialog");

	CDialog::OnInitDialog();
	
	// get the script type combo box
	CComboBox* pComboBox = (CComboBox*)GetDlgItem(IDC_SCRIPT_TYPE);

	int nIndex = CB_ERR;
  int nRC = CB_ERR;

	// NOTE: What should be done here is a search of the registry
	//       for all script engines.

	// add item to list of script types
	nIndex = pComboBox->AddString(_T("JScript"));
	ASSERT(nIndex != CB_ERR && nIndex != CB_ERRSPACE);
	nRC = pComboBox->SetItemDataPtr(nIndex, (void*)&CLSID_JScript);
	ASSERT(nRC != CB_ERR);

	// add item to list of script types
	nIndex = pComboBox->AddString(_T("VBScript"));
	ASSERT(nIndex != CB_ERR && nIndex != CB_ERRSPACE);
	nRC = pComboBox->SetItemDataPtr(nIndex, (void*)&CLSID_VBScript);
	ASSERT(nRC != CB_ERR);

	// make the last item added the current item
	nRC = pComboBox->SetCurSel(nIndex);
	ASSERT(nRC != CB_ERR);

	// get the script edit control
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_SCRIPT_TEXT);
	ASSERT(pEdit != NULL);

	// set the edit control's text
	pEdit->SetWindowText(m_strScript);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CScriptDialog::OnOK() 
{
	TRACE_IN("CScriptDialog::OnOK");

	// get the script text
	m_strScript = GetScript();

	HRESULT hr = S_OK;

	// if the user entered a script ...
	if (!m_strScript.IsEmpty()) {
		// get the script engine's CLSID
		const CLSID* pCLSID = GetScriptEngineCLSID();
		ASSERT(pCLSID != NULL);

		// create the script engine proxy on heap (already AddRef'd upon return)
		CScriptEngine* pScriptEngine = new CScriptTestScriptEngine(m_pDoc);
		ASSERT(pScriptEngine != NULL);

		// create the actual scripting engine
		hr = pScriptEngine->Create(*pCLSID);

		// if success ...
		if (SUCCEEDED(hr)) {
			// give the engine the script
			USES_CONVERSION; // needed by the T2COLE macro
			hr = pScriptEngine->ParseScriptText(T2COLE(m_strScript));

			// if success ...
			if (SUCCEEDED(hr)) {
				// add the document as a named item
				hr = pScriptEngine->AddNamedItem(L"Document");

				// if success ...
				if (SUCCEEDED(hr)) {
					// run the script
					hr = pScriptEngine->Run();

					// if failure ...
					if (FAILED(hr)) {
						MESSAGE_BOX(("Script failed to run.\nReturn code = %x", hr));
					}
				} else {
					MESSAGE_BOX(("Failed to add document to script's name space.\nReturn code = %x", hr));
				}
			} else {
				MESSAGE_BOX(("Failed to parse script.\nReturn code = %x", hr));
			}
		} else {
			MESSAGE_BOX(("Failed to create script engine.\nReturn code = %x", hr));
		}

		// close the script engine
		pScriptEngine->Close();

		// release the script engine
		pScriptEngine->ExternalRelease();
	}

	// if success ...
	if (SUCCEEDED(hr)) {
		CDialog::OnOK();
	}
}
