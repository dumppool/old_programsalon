#include "stdafx.h"
#include "ScriptTestScriptEngine.h"
#include "ScriptTestDoc.h"
#include "Utils.h"

IMPLEMENT_SERIAL(CScriptTestScriptEngine, CScriptEngine, 1)

CScriptTestScriptEngine::CScriptTestScriptEngine() : m_pDoc(NULL)
{
	TRACE_IN("CScriptTestScriptEngine::CScriptTestScriptEngine");
}

CScriptTestScriptEngine::CScriptTestScriptEngine(CScriptTestDoc* pDoc) : m_pDoc(pDoc)
{
	TRACE_IN("CScriptTestScriptEngine::CScriptTestScriptEngine");

	ASSERT_VALID(m_pDoc);
}

CScriptTestScriptEngine::CScriptTestScriptEngine(CScriptTestDoc* pDoc,
																								 REFCLSID clsidScriptEngine) :
  CScriptEngine(clsidScriptEngine),
  m_pDoc(pDoc)
{
	TRACE_IN("CScriptTestScriptEngine::CScriptTestScriptEngine");

	ASSERT_VALID(m_pDoc);
}

CScriptTestScriptEngine::~CScriptTestScriptEngine()
{
	TRACE_IN("CScriptTestScriptEngine::~CScriptTestScriptEngine");
}

void CScriptTestScriptEngine::Serialize(CArchive& ar)
{
	CScriptEngine::Serialize(ar);

  if (ar.IsStoring()) {
    ar << m_pDoc;
  } else {
		CObject* pObj;
		ar >> pObj;
		m_pDoc = (CScriptTestDoc*)pObj;
  }
}

HRESULT CScriptTestScriptEngine::OnGetItemInfo(
		/* [in] */ LPCOLESTR   pstrName,
		/* [in] */ DWORD       dwReturnMask,
		/* [out]*/ IUnknown**  ppUnknownItem,
		/* [out]*/ ITypeInfo** ppTypeInfo)
{
	TRACE_IN("CScriptTestScriptEngine::OnGetItemInfo");

	HRESULT hr = S_OK;

	// get the name as a CString
	CString strName(pstrName);

	// if the ppUnknownItem pointer is valid ...
	if (ppUnknownItem != NULL) {
		// initialize the return value
		*ppUnknownItem = NULL;
	}

	// if the ppTypeInfo pointer is valid ...
	if (ppTypeInfo != NULL) {
		// initialize the return value
		*ppTypeInfo = NULL;
	}

	// if the script engine wants the document object ...
	if (wcsicmp(pstrName, L"Document") == 0) {
		// get the document's dispatch interface
		IDispatch* pDispatch = m_pDoc->GetIDispatch(FALSE); // FALSE -> don't AddRef()
		ASSERT(pDispatch != NULL);

		// if the script engine wants the object's IUnknown pointer ...
		if (dwReturnMask & SCRIPTINFO_IUNKNOWN) {
			ASSERT(ppUnknownItem != NULL);
			ASSERT_VALID(m_pDoc);

			// return the document's IDispatch interface as its IUnknown
			*ppUnknownItem = (IUnknown*)m_pDoc->GetIDispatch(TRUE); // TRUE => does AddRef()
			ASSERT(*ppUnknownItem != NULL);
		}

		// if the script engine wants the object's ITypeInfo pointer ...
		if (dwReturnMask & SCRIPTINFO_ITYPEINFO) {
			ASSERT(ppTypeInfo != NULL);

			// just return a NULL pointer
			*ppTypeInfo = NULL;
		}
	} else {
		MESSAGE_BOX(("The script engine asked for information\nfor an unknown object named \"%s\".", (LPCSTR)strName));
		ASSERT(FALSE);
		hr = E_UNEXPECTED;
	}

	return hr;
}

/////////////////////////////////////////////////////////////////////////////
// CScriptTestScriptEngine diagnostics

#ifdef _DEBUG
void CScriptTestScriptEngine::AssertValid() const
{
	CScriptEngine::AssertValid();

	ASSERT_VALID(m_pDoc);
}

void CScriptTestScriptEngine::Dump(CDumpContext& dc) const
{
	CScriptEngine::Dump(dc);

	dc << "m_pDoc = " << m_pDoc;

	m_pDoc->Dump(dc);
}
#endif //_DEBUG
