// ScriptTestDoc.h : interface of the CScriptTestDoc class
//
/////////////////////////////////////////////////////////////////////////////

class CScriptTestSrvrItem;
class CScriptDialog;

class CScriptTestDoc : public COleServerDoc
{
protected: // create from serialization only
	CScriptTestDoc();
	DECLARE_DYNCREATE(CScriptTestDoc)

// Attributes
public:
	CString GetTextAsCString() const;

	CScriptTestSrvrItem* GetEmbeddedItem()
		{ return (CScriptTestSrvrItem*)COleServerDoc::GetEmbeddedItem(); }

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScriptTestDoc)
	protected:
	virtual COleServerItem* OnGetEmbeddedItem();
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CScriptTestDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CScriptTestDoc)
	afx_msg void OnScriptRun();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CScriptTestDoc)
	afx_msg BSTR GetText();
	afx_msg void SetText(LPCTSTR lpszNewValue);
	afx_msg void MsgBox(LPCTSTR strMsg);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()

private:
	// this document's text
	CString m_strText;

	// pointer to document's script dialog
	CScriptDialog* m_pScriptDialog;
};

/////////////////////////////////////////////////////////////////////////////
