// SrvrItem.h : interface of the CScriptTestSrvrItem class
//

class CScriptTestSrvrItem : public COleServerItem
{
	DECLARE_DYNAMIC(CScriptTestSrvrItem)

// Constructors
public:
	CScriptTestSrvrItem(CScriptTestDoc* pContainerDoc);

// Attributes
	CScriptTestDoc* GetDocument() const
		{ return (CScriptTestDoc*)COleServerItem::GetDocument(); }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScriptTestSrvrItem)
	public:
	virtual BOOL OnDraw(CDC* pDC, CSize& rSize);
	virtual BOOL OnGetExtent(DVASPECT dwDrawAspect, CSize& rSize);
	//}}AFX_VIRTUAL

// Implementation
public:
	~CScriptTestSrvrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
};

/////////////////////////////////////////////////////////////////////////////
