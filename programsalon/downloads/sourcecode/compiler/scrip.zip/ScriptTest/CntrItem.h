// CntrItem.h : interface of the CScriptTestCntrItem class
//

class CScriptTestDoc;
class CScriptTestView;

class CScriptTestCntrItem : public COleClientItem
{
	DECLARE_SERIAL(CScriptTestCntrItem)

// Constructors
public:
	CScriptTestCntrItem(CScriptTestDoc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.

// Attributes
public:
	CScriptTestDoc* GetDocument()
		{ return (CScriptTestDoc*)COleClientItem::GetDocument(); }
	CScriptTestView* GetActiveView()
		{ return (CScriptTestView*)COleClientItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScriptTestCntrItem)
	public:
	virtual void OnChange(OLE_NOTIFICATION wNotification, DWORD dwParam);
	virtual void OnActivate();
	protected:
	virtual void OnGetItemPosition(CRect& rPosition);
	virtual void OnDeactivateUI(BOOL bUndoable);
	virtual BOOL OnChangeItemPosition(const CRect& rectPos);
	virtual BOOL CanActivate();
	//}}AFX_VIRTUAL

// Implementation
public:
	~CScriptTestCntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	virtual void Serialize(CArchive& ar);
};

/////////////////////////////////////////////////////////////////////////////
