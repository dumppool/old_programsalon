// ScriptTestScriptEngine.h : interface of the CScriptTestScriptEngine class
//

#include "ScriptEngine.h"

class CScriptTestDoc;

class CScriptTestScriptEngine : public CScriptEngine
{
	DECLARE_SERIAL(CScriptTestScriptEngine)

public:
	// constructors
	CScriptTestScriptEngine(CScriptTestDoc* pDoc);
	CScriptTestScriptEngine(CScriptTestDoc* pDoc, REFCLSID clsidScriptEngine);

	// IActiveScriptSite overridables
	virtual HRESULT OnGetItemInfo(
		/* [in] */ LPCOLESTR pstrName,
		/* [in] */ DWORD dwReturnMask,
		/* [out]*/ IUnknown** ppUnknownItem,
		/* [out]*/ ITypeInfo** ppTypeInfo);
	
// Implementation
public:
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	// serialization
	void Serialize(CArchive& ar);

	// destructor (protected to prevent creation of objects the stack)
	virtual ~CScriptTestScriptEngine();

private:
	// default constructor used by serialization only
	CScriptTestScriptEngine();

	// don't allow copy construction or assignment
	CScriptTestScriptEngine(const CScriptTestScriptEngine& scriptEngine);
	CScriptTestScriptEngine& operator=(const CScriptTestScriptEngine& scriptEngine);

	// this script engine's document
	CScriptTestDoc* m_pDoc;
};