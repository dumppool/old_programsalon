// ScriptDialog.h : header file
//

class CScriptTestDoc;

extern const CLSID CLSID_VBScript;
extern const CLSID CLSID_JScript;

/////////////////////////////////////////////////////////////////////////////
// CScriptDialog dialog

class CScriptDialog : public CDialog
{
// Construction
public:
	CScriptDialog(CScriptTestDoc* pDoc, CWnd* pParent=NULL);

// Dialog Data
	//{{AFX_DATA(CScriptDialog)
	enum { IDD = IDD_SCRIPT_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScriptDialog)
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CScriptDialog)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	// helpers
	const CLSID* GetScriptEngineCLSID() const;
	CString GetScript() const;

	// pointer to the document
	CScriptTestDoc* m_pDoc;

	// the script's text
	CString m_strScript;
};
