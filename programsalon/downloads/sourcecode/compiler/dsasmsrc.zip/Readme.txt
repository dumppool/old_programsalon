dsasmsrc.zip source program for disassem.exe (disassem.zip in this directory)

This is a fully functional win32program dissassembler source.

This program was developed with DJGPP c language.
There is no special requirement to run this program.

dsasmsrc.zip    source program for disassem.exe
readme.txt      you are reading it now

You can contact me if you have any questions or problems.
e-mail: sangcho@alpha94.chongju.ac.kr
phone:  +82-431-229-8491 (South Korea)

p.s. I like to receive nice postcards from you.
if there is anyone who wants to express his/her gratitute
he/she can send me a nice postcard.

        Sang Cho
        Computer and Information Engineering
        ChongJu University
        NaeDok-Dong 36 
        ChongJu 360-764
        South Korea