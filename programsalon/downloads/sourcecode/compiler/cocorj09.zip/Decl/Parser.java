package Decl;
import java.util.*;

class Parser {
	private static final int maxT = 9;
	private static final int maxP = 9;

	private static final boolean T = true;
	private static final boolean x = false;
	private static final int minErrDist = 2;
	private static int errDist = minErrDist;

	static Token token;   // last recognized token
	static Token t;       // lookahead token

	

	static void Error(int n) {
		if (errDist >= minErrDist) Scanner.err.ParsErr(n, t.line, t.col);
		errDist = 0;
	}

	static void SemError(int n) {
		if (errDist >= minErrDist) Scanner.err.SemErr(n, token.line, token.col);
		errDist = 0;
	}

	static boolean Successful() {
		return Scanner.err.count == 0;
	}

	static String LexString() {
		return token.str;
	}

	static String LexName() {
		return token.val;
	}

	static String LookAheadString() {
		return t.str;
	}

	static String LookAheadName() {
		return t.val;
	}

	private static void Get() {
		for (;;) {
			token = t;
			t = Scanner.Scan();
			if (t.kind <= maxT) {errDist++; return;}

			t = token;
		}
	}

	private static void Expect(int n) {
		if (t.kind == n) Get(); else Error(n);
	}

	private static boolean StartOf(int s) {
		return set[s][t.kind];
	}

	private static void ExpectWeak(int n, int follow) {
		if (t.kind == n) Get();
		else {
			Error(n);
			while (!StartOf(follow)) Get();
		}
	}

	private static boolean WeakSeparator(int n, int syFol, int repFol) {
		boolean[] s = new boolean[maxT+1];
		if (t.kind == n) {Get(); return true;}
		else if (StartOf(repFol)) return false;
		else {
			for (int i = 0; i <= maxT; i++) {
				s[i] = set[syFol][i] || set[repFol][i] || set[0][i];
			}
			Error(n);
			while (!s[t.kind]) Get();
			return StartOf(syFol);
		}
	}

	private static void Descriptor() {
		if (t.kind == 5 || t.kind == 7) {
			if (t.kind == 7) {
				Get();
				System.out.print(" array ");
				if (t.kind == 1) {
					Get();
					System.out.print("[" + LexString() + "] ");
				} else if (t.kind == 8) {
				} else Error(10);
				Expect(8);
				System.out.print("of");
				Descriptor();
			} else {
				Get();
				Expect(6);
				System.out.print(" function returning");
			}
		}
	}

	private static void DirectDcl() {
		if (t.kind == 2) {
			Get();
			System.out.print(LexString() + " is");
			Descriptor();
		} else if (t.kind == 5) {
			Get();
			Dcl();
			Expect(6);
			Descriptor();
		} else Error(11);
	}

	private static void Dcl() {
		if (t.kind == 4) {
			Get();
			Dcl();
			System.out.print(" pointer to");
		} else if (t.kind == 2 || t.kind == 5) {
			DirectDcl();
		} else Error(12);
	}

	private static void Decl() {
		while (t.kind == 2) {
			Get();
			String s = LexString();
			Dcl();
			System.out.println(" " + s);
			Expect(3);
		}
	}



	static void Parse() {
		t = new Token();
		Get();
		Decl();

	}

	private static boolean[][] set = {
	{T,x,x,x, x,x,x,x, x,x,x}

	};
}
