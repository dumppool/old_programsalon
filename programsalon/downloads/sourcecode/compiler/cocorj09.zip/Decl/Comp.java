package Decl;

import java.awt.*;

public class Comp {

	static ErrorStream ErrorHandler;

	public static void main (String[] args) {
		String file, dir;
		if (args.length == 0) {
			FileDialog d = new FileDialog(new Frame("C Declarations"), "open declaration file");
			d.show();
			file = d.getFile();
			dir = d.getDirectory();
		} else {
			file = args[0];
			dir = "";
		}
		if (file != null) {
			System.out.println("C Declarations");
			file = dir + file;
			ErrorHandler = new ErrorStream();
			Scanner.Init(file, ErrorHandler);
			Parser.Parse();
			ErrorHandler.Summarize(dir);
		}
		System.exit(0);
	}

}
