package Decl;

class ErrorStream {

	int count;  // number of errors detected

	ErrorStream() {
		count = 0;
	}

	void StoreError(int n, int line, int col, String s) {
		System.out.println("-- line " + line + " col " + col + ": " + s);
	}

	void ParsErr(int n, int line, int col) {
		String s;
		count++;
		switch (n) {
			case 0: {s = "EOF expected"; break;}
			case 1: {s = "number expected"; break;}
			case 2: {s = "name expected"; break;}
			case 3: {s = "';' expected"; break;}
			case 4: {s = "'*' expected"; break;}
			case 5: {s = "'(' expected"; break;}
			case 6: {s = "')' expected"; break;}
			case 7: {s = "'[' expected"; break;}
			case 8: {s = "']' expected"; break;}
			case 9: {s = "not expected"; break;}
			case 10: {s = "invalid Descriptor"; break;}
			case 11: {s = "invalid DirectDcl"; break;}
			case 12: {s = "invalid Dcl"; break;}

			default: s = "Syntax error " + n;
		}
		StoreError(n, line, col, s);
	}

	void SemErr(int n, int line, int col) {
		String s;
		count++;
		switch (n) {
			case -1: {s = "invalid character"; break;}
			// perhaps insert application specific error messages here
			default: {s = "Semantic error " + n; break;}
		}
		StoreError(n, line, col, s);
	}

	void Exception (String s) {
		System.out.println(s); System.exit(0);
	}

	void Summarize (String s) {
		switch (count) {
			case 0 : System.out.println("No errors detected"); break;
			case 1 : System.out.println("1 error detected"); break;
			default: System.out.println(count + " errors detected"); break;
		}
	}

}
