/*--------------------------------------------
Trace output
  0: prints the states of the scanner automaton
  1: prints the First and Follow sets of all nonterminals
  2: prints the syntax graph of the productions
  3: traces the computation of the First sets
  4: assigns symbolic names to terminals
  6: prints the symbol table (terminals, nonterminals, pragmas)
  7: prints a cross reference list of all syntax symbols
  8: prints statistics about the Coco run
  
Trace output can be switched on by the pragma
     $ {digit}
in the attributed grammar.
--------------------------------------------*/

package Coco;

import java.awt.*;

class CocoErrors extends ErrorStream {

	void SemErr(int n, int line, int col) {
		String s;
		count++;
		switch (n) {
			case -1: {s = "invalid character"; break;}
			case  2: {s = "string literal may not extend over line end"; break;}
			case  3: {s = "a literal must not have attributes"; break;}
			case  4: {s = "this symbol kind is not allowed in a production"; break;}
			case  5: {s = "attribute mismatch between declaration and use"; break;}
			case  6: {s = "undefined string in production"; break;}
			case  7: {s = "name declared twice"; break;}
			case  8: {s = "this symbol kind not allowed on left side of production"; break;}
			case  9: {s = "earlier semantic action was not terminated"; break;}
			case 11: {s = "no production found for grammar name"; break;}
			case 12: {s = "grammar symbol must not have attributes"; break;}
			case 13: {s = "a literal must not be declared with a structure"; break;}
			case 14: {s = "semantic action not allowed here"; break;}
			case 15: {s = "undefined name"; break;}
			case 17: {s = "name does not match grammar name"; break;}
			case 18: {s = "unacceptable constant value"; break;}
			case 19: {s = "may not ignore CHR(0)"; break;}
			case 20: {s = "token may not be empty"; break;}
			case 21: {s = "token must not start with an iteration"; break;}
			case 22: {s = "only characters allowed in comment declaration"; break;}
			case 23: {s = "only terminals may be weak"; break;}
			case 24: {s = "literal tokens may not contain white space"; break;}
			case 25: {s = "comment delimiters must be 1 or 2 characters long"; break;}
			case 26: {s = "character set contains more than 1 character"; break;}
			case 27: {s = "could not make deterministic automaton"; break;}
			case 29: {s = "literal tokens may not be empty"; break;}
			default: {s = "Semantic error " + n; break;}
		}
		StoreError(n, line, col, s);
	}

}

public class Comp {

	static ErrorStream ErrorHandler;

	public static void main (String[] args) {
		String file, dir;
		if (args.length == 0) {
			FileDialog d = new FileDialog(new Frame("Coco"), "open attribute grammar");
			d.show();
			file = d.getFile();
			dir = d.getDirectory();
		} else {
			file = args[0];
			dir = "";
		}
		if (file != null) {
                        System.out.println("Coco/R V1.09 (9 July 1999)");
			System.out.println("Original by Hanspeter Moessenboeck (moessenboeck@ssw.uni-linz.ac.at)");
			System.out.println("Some modifications Pat Terry (cspt@cs.ru.ac.za)");
			file = dir + file;
			// ErrorHandler = new MergeErrors(); // Merge error messages in listing
			// ErrorHandler = new ErrorStream(); // Very rudimentary
			ErrorHandler = new CocoErrors(); // Error messages reported to StdOut
			Scanner.Init(file, ErrorHandler);
			Tab.Init(); DFA.Init(dir); ParserGen.Init(dir); Trace.Init(dir);
			Parser.Parse();
			ErrorHandler.Summarize(dir);
			Trace.out.flush();
		}
		System.exit(0);
	}

}
