package Coco;

import java.io.*;

class Trace {
// Portability - Use the following for Java 1.0
//	static PrintStream out;
// Portability - Use the following for Java 1.1
//	static PrintWriter out;

	static PrintWriter out;

	static void Init(String dir) {
		try {

// Portability - Use the following for Java 1.0
//			out = new PrintStream(new BufferedOutputStream(new FileOutputStream(dir + "listing")));
// Portability - Use the following for Java 1.1
//			out = new PrintWriter(new BufferedWriter(new FileWriter(dir + "listing")));

			out = new PrintWriter(new BufferedWriter(new FileWriter(dir + "listing")));

		}
		catch (IOException e) {
			Scanner.err.Exception("-- could not open trace file");
		}
	}

	static void print(String s) {
		out.print(s);
	}

	static void println(String s) {
		out.println(s);
	}

	static void println() {
		out.println();
	}
}
