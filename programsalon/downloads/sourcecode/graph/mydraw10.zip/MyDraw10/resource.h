//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyDraw.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MYDRAWTYPE                  129
#define IDR_DRAWING                     130
#define IDD_DRAWING_TITLE               132
#define IDD_PS_LINE                     133
#define IDD_PS_SHAPE                    134
#define IDC_DRAWING_TITLE               1001
#define IDC_EDIT1                       1002
#define IDC_SPIN1                       1003
#define IDC_COMBO                       1005
#define IDC_RADIO1                      1006
#define IDC_RADIO2                      1007
#define IDC_CHECK1                      1008
#define ID_MENUITEM32773                32773
#define ID_MENUITEM32774                32774
#define ID_TOOL_RECTANGLE               32775
#define ID_TOOL_ELLIPSE                 32776
#define ID_TOOL_TRANSPARENT             32779
#define ID_COLOR_BLACK                  32780
#define ID_COLOR_BLUE                   32781
#define ID_COLOR_GREEN                  32782
#define ID_COLOR_CYAN                   32783
#define ID_COLOR_RED                    32784
#define ID_COLOR_MAGENTA                32785
#define ID_COLOR_YELLOW                 32786
#define ID_COLOR_WHITE                  32787
#define ID_COLOR_DKGRAY                 32788
#define ID_COLOR_LTGRAY                 32789
#define ID_TOOL_SELECTION               32790
#define ID_EDIT_DRAWING_TITLE           32794
#define ID_TOOL_CUSTOM_COLOR            32795
#define ID_TOOL_SETTINGS                32796

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32797
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
