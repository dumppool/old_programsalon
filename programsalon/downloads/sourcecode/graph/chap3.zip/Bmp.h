#include "windows.h"
#define IDM_LOADBMP   1
#define IDM_EXIT      2 

#define IDM_SMOOTHING_BOX               40007
#define IDM_SMOOTHING_GAUSS             40008
#define IDM_SHARPENING_LAPLACIAN        40009
#define IDM_HMEDIAN                     40046
#define IDM_VMEDIAN                     40047

#define TEMPLATE_SMOOTH_BOX    1
#define TEMPLATE_SMOOTH_GAUSS  2
#define TEMPLATE_SHARPEN_LAPLACIAN 3
