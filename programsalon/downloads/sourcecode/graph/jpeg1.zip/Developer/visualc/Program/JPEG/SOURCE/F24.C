#include <stdio.h>
#include <graphics.h>
#include <conio.h>
main()
{
FILE	*fp,*ofp,*ifp;
int i,i1,i2,i3,row=0,col=0,trow=0;
int gd=DETECT,gm;
int c,c1,f=0,rr;
char by[72];
long length;

initgraph(&gd,&gm,"c:\\tc");
if ((fp=fopen("st24","rb"))==NULL)
	{
	closegraph();
	  puts("\7 can't open file1");
	exit(0);
	}
if ((ifp=fopen("hz24.dat","rb"))==NULL)
	{
	closegraph();
	  puts("\7 can't open file2");
	exit(0);
	}
if ((ofp=fopen("hz24.ovl","wb"))==NULL)
	{
	closegraph();
          puts("\7 can't open file");
	exit(0);
	}
fseek(ofp,0,SEEK_SET);
while((c=getc(ifp))!=EOF)
	{
	if(c>0xa0)
		 if(f==0){
		 f=1;
		 c1=(c-0xa1)&0x07f;
		 }
		 else{
		 f=0;
		 length=c1*94*72l+(((c-0xa1)&0x07f))*72l;
		 c1=24;
		 rr=8;
		 }
	if(f==0){
        col=trow;
	fseek(fp,length,SEEK_SET);
	fread(by,72,1,fp);
	fwrite(by,72,1,ofp);
	for(i1=0;i1<24;i1++)
		{for(i2=0;i2<3;i2++)
		for(i3=0;i3<rr;i3++)
		if(getbit(by[i1*3+i2],7-i3))
		putpixel(row,col+i2*8+i3,GREEN);
		row++;}
	row+=4;
	if(row>640)
		   {row=0;trow+=28;
		if(trow>450){getch();cleardevice();trow=0;}
		}
	} }
	fclose(ofp);
	getch();
	closegraph();
}

int getbit(unsigned char c,int n)
{return((c>>n)&1);
}
