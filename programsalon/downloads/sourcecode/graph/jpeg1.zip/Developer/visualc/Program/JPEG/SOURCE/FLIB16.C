#include <stdio.h>
#include <graphics.h>
#include <conio.h>

main()
{
FILE	*fp;
int i,i1,i2,i3,row=0,col=0,trow=0;
int gd=DETECT,gm;
char by[32];
long length;

/*registerbgidriver(EGAVGA_driver);*/
detectgraph(&gd,&gm);
if(gm==CGAHI) gm=CGAC0;
initgraph(&gd,&gm,"c:\\tc");
if ((fp=fopen("jpeg.ovl","rb"))==NULL)
	{
	closegraph();
          puts("\7 can't open file");
	exit(0);
	}
fseek(fp,0,2);
length=ftell(fp)/32l;
fseek(fp,0,0);
for(i=0;i<length;i++)
	{
	fread(by,32,1,fp);
	row=trow;
	for(i1=0;i1<16;i1++)
		{for(i2=0;i2<2;i2++)
		for(i3=0;i3<8;i3++)
		if(getbit(by[i1*2+i2],7-i3))
		putpixel(col+i2*8+i3,row,GREEN+128);
		row++;
		}
	col=col+16;
	if(col>639)
		   {col=0;trow+=20;
		if(trow>479){getch();cleardevice();trow=0;}
		}
	}
getch();
closegraph();
}

int getbit(unsigned char c,int n)
{return((c>>n)&1);
}
