/* ͼ�β����ӳ� */
int  set_mode(int mode)
  {  in.h.ah=0;
     in.h.al=mode;
     int86(0x10,&in,&out);
    }

void Close_display()
   { while((inportb(0x3da)&8)==0);
     while((inportb(0x3da)&8)==8);
     outportb(0x3c4,1);
     outportb(0x3c5,inportb(0x3c5)|0x20);
    }

void Open_display()
   { while((inportb(0x3da)&8)==0);
     while((inportb(0x3da)&8)==8);
     outportb(0x3c4,1);
     outportb(0x3c5,inportb(0x3c5)&0xdf);
    }

int  mputs(int x,int y,char *s,unsigned int bkcolor,unsigned int forecolor)
  {  Hide();
     in.x.ax=0x1124;
     in.h.bl=25;
     int86(0x10,&in,&out);
     do {
       in.h.ah=2;          in.h.bh=0;
       in.h.dh=y;          in.h.dl=x++;
       int86(0x10,&in,&out);
       in.h.ah=9;          in.h.al=*s++;
       in.h.bl=forecolor;  in.x.cx=1;
       in.h.bh=bkcolor;    int86(0x10,&in,&out);
      } while(*s!='\x0');
     Show();
   }

int  getbit(unsigned char c,int n)
  {  return((c>>n)&1);  }

int  color()
  {  int i;
     char buf[30]={ 50,50,00,
		    20,60,36,
		    10,60,61,
		    10,54,62,
		    60,00,20,
		    60,00,10,
		    00,00,40,
		    30,31,32,
		    22,22,22,
		    50,50,50 };

     outportb(0x3c8,246);
     for(i=0;i<30;i++) outportb(0x3c9,buf[i]);
     outportb(0x3c8,0);
     for(i=0;i<64*3;i++) outportb(0x3c9,i/3);
    }

int  mputpixel(int x,int y,int color)
   { int offset;
     unsigned long ea;

     ea=(unsigned long)y*DIMX+x;
     offset=ea&0xffff;
     outportb(0x3c4,0x0e);
     outportb(0x3c5,((ea>>16)&0x0f)^2);
     pokeb(0xa000,offset,color);
    }

char mgetpixel(int x,int y)
   { int offset;
     unsigned long ea;

     ea=(unsigned long)y*DIMX+x;
     offset=ea&0xffff;
     outportb(0x3c4,0x0e);
     outportb(0x3c5,((ea>>16)&0x0f)^2);
     return(peekb(0xa000,offset));
    }

int  mline(int x1,int y1,int x2,int y2,int color)
   { int i=1,x,y,n;
     int dx,dy,dxs,dys;

     dx=x2-x1;  dy=y2-y1;
     n=abs(dx);
     if(n<abs(dy)) n=abs(dy);
     if(n==0) { mputpixel(x1,y1,color); return 0; }
     dxs=dx/n; dys=dy/n;
     x=x1;  y=y1;  dx=0; dy=0;
     do {
       mputpixel(x,y,color);
       dx+=dxs;  dy+=dys;
       x=x1+dx;  y=y1+dy;
      } while((++i)<=n);
   }

int  mxline(int x1,int y1,int x2,int y2,int color)
   { int i=1,x,y,n;
     float dx,dy,step,dxs,dys;

     dx=x2-x1;  dy=y2-y1;
     step=abs(dx);
     if(step<abs(dy)) step=abs(dy);
     if(step==0) { mputpixel(x1,y1,color); return; }
     else {
       dxs=dx/step; dys=dy/step;
       n=step; x=x1;  y=y1;  dx=0; dy=0;
       for(i=1;i<=n;i++) {
	 mputpixel(x,y,color);
	 dx+=dxs;  dy+=dys;
	 x=x1+dx;  y=y1+dy;
	}
      }
    }

int  mrectangle(int x1,int y1,int x2,int y2,int color)
  {  mline(x1,y1,x2,y1,color);
     mline(x1,y1,x1,y2,color);
     mline(x2,y1,x2,y2+1,color);
     mline(x1,y2,x2+1,y2,color);
    }

int  mcrectangle(int x1,int y1,int x2,int y2,int c1,int c2)
  {  mline(x1,y1,x2,y1,c1);
     mline(x1,y1,x1,y2,c1);
     mline(x2,y1,x2,y2+1,c2);
     mline(x1,y2,x2+1,y2,c2);
    }

int  mbar(int x1,int y1,int x2,int y2,int color)
   { char far *p;
     int i,dx,cy=1;
     unsigned long ea;
     unsigned char seg;
     unsigned int m,offset;

     dx=x2-x1+1;
     ea=(long)y1*DIMX+x1;  offset=ea&0xffff;
     seg=(ea>>16)&0x0f;   outportb(0x3c4,0x0e);
     outportb(0x3c5,(seg++)^2);
     p=MK_FP(0xa000,offset);
     for(i=0;i<=abs(y2-y1);i++) {
       if((offset+dx>=offset)&&(offset+dx<=0xffff)) {
	 memset(p,color,dx); p+=dx; }
	else {
	  cy=0;
	  m=(unsigned int)0xffff-offset+1;
	  memset(p,color,m); p+=m;
	  outportb(0x3c4,0x0e);
	  outportb(0x3c5,((seg++)&0x0f)^2);
	  m=dx-m;
	  memset(p,color,m); p+=m;
	 }
       p+=(DIMX-dx); offset+=DIMX;
       if((FP_OFF(p)<DIMX)&&cy) {
	 outportb(0x3c4,0x0e);
	 outportb(0x3c5,((seg++)&0x0f)^2);
	}
       cy=1;
       }
   }

int  mgetimage(int x1,int y1,int x2,int y2,char far *buf)
   { char far *p;
     int i,m,dx,cy=1;
     unsigned long ea;
     unsigned char seg;
     unsigned int offset;

     dx=x2-x1+1;
     ea=(long)y1*DIMX+x1; offset=ea&0xffff;
     seg=(ea>>16)&0x0f;  outportb(0x3c4,0x0e);
     outportb(0x3c5,(seg++)^2);
     p=MK_FP(0xa000,offset);
     for(i=0;i<=abs(y2-y1);i++) {
      if(offset+dx>=offset&&offset+dx<=0xffff) {
	memcpy(buf,p,dx); buf+=dx; p+=dx; }
       else {
	 cy=0;
	 m=0xffff-offset+1;
	 memcpy(buf,p,m);
	 buf+=m; p+=m;
	 outportb(0x3c4,0x0e);
	 outportb(0x3c5,((seg++)&0x0f)^2);
	 m=dx-m; memcpy(buf,p,m);
	 buf+=m; p+=m;
	}
      p+=(DIMX-dx);offset+=DIMX;
      if((FP_OFF(p)<DIMX)&&cy) {
	outportb(0x3c4,0x0e);
	outportb(0x3c5,((seg++)&0x0f)^2);
       }
       cy=1;
      }
    }

int  mputimage(int x1,int y1,int x2,int y2,char far *buf)
   { char far *p;
     int i,m,dx,cy=1;
     unsigned long ea;
     unsigned char seg;
     unsigned int offset;

     dx=x2-x1+1;
     ea=(long)y1*DIMX+x1; offset=ea&0xffff;
     seg=(ea>>16)&0x0f;  outportb(0x3c4,0x0e);
     outportb(0x3c5,(seg++)^2);
     p=MK_FP(0xa000,offset);
     for(i=0;i<=abs(y2-y1);i++) {
       if((offset+dx>=offset)&&(offset+dx<=0xffff)) {
	 memcpy(p,buf,dx); p+=dx; buf+=dx; }
	else {
	 cy=0;
	 m=0xffff-offset+1;
	 memcpy(p,buf,m);
	 p+=m; buf+=m;
	 outportb(0x3c4,0x0e);
	 outportb(0x3c5,((seg++)&0x0f)^2);
	 m=dx-m; memcpy(p,buf,m);
	 p+=m; buf+=m;
	}
       p+=(DIMX-dx);  offset+=DIMX;
       if((FP_OFF(p)<DIMX)&&cy) {
	 outportb(0x3c4,0x0e);
	 outportb(0x3c5,((seg++)&0x0f)^2);
	}
       cy=1;
      }
    }

int  putchn(int *col,int *row,char *by,int color)
  {  int i1,i2,i3;

     for(i1=0;i1<24;i1++) {
       for(i2=0;i2<3;i2++)
	 for(i3=0;i3<8;i3++)
	   if(getbit(by[i1*3+i2],7-i3)) {
	     mputpixel(*col+2,*row+i2*8+i3+2,254);
	     mputpixel(*col,*row+i2*8+i3,color);
	    }
       *col+=1;
      }
    }

int  putchn16(int *col,int *row,char *by,int color)
  {  int i1,i2,i3;

     for(i1=0;i1<16;i1++) {
       for(i2=0;i2<2;i2++)
	 for(i3=0;i3<8;i3++)
	   if(getbit(by[i1*2+i2],7-i3))
	     mputpixel(*col+i2*8+i3,*row,color);
       *row+=1;
      }
     *col+=16;
    }

int  title(int col,int rrow,int num,int room,int color)
  {  int j,row;
     char by[72];

     for(j=0;j<num;j++)	{
       fread(by,72,1,ovlp); row=rrow;
       putchn(&col,&row,by,color);
       col+=room;
      }
    }

int  title16(int col,int rrow,int num,int room,int color)
  {  int j,row;
     char by[32];

     for(j=0;j<num;j++)	{
       fread(by,32,1,ovlp); row=rrow;
       putchn16(&col,&row,by,color); col+=room;
      }
    }

void YES(int x,int y,int flag)
   { int color;

     if(flag) color=251;
      else color=253;
     mxline(x,y,x+4,y+5,color);
     mxline(x+4,y+5,x+11,y-6,color);
    }

int  show(char *filename,int mode,int flag)
  {  char msg[9];
     unsigned long ea;
     int pcx_src,y=512,cy=1;
     unsigned int i,m,seg,offset,num=600;
     unsigned char buffs[DIMX],far *pvideo;

     if(!mode) {
       if((pcx_src=open(filename,O_RDWR|O_BINARY,S_IREAD))==-1) {
	 fseek(ovlp,-5*32,2);
	 bell(800); title16(400,575,5,2,255);
	 return -1; }
       fseek(ovlp,-33*32,SEEK_END);
       mbar(0,DIMY-29,640,DIMY,252);
       title16(400,575,3,2,255);
       read(pcx_src,msg,8);
       if(strcmp(msg,"JPEG R")!=NULL) {
	 close(pcx_src); return -1; }
       read(pcx_src,&num,2);
       read(pcx_src,&y,2);
       y-=1;
      }
     ea=(unsigned long)(610-y)/2*DIMX+(1000-num)/2;
     offset=ea&0xffff; seg=ea>>16;
     pvideo=MK_FP(0xa000,offset);
     outportb(0x3c4,0x0e);
     outportb(0x3c5,((seg++)&0x0f)^2);
     for(i=0;i<=y;i++) {
       if(mode) memset(buffs,255,num);
	else {
	 read(pcx_src,buffs,num);
	 for(m=0;m<num;m++) buffs[m]>>=flag;}
       if((offset+num>=offset)&&(offset+num<=0xffff)) {
	 memcpy(pvideo,buffs,num); pvideo+=num; }
	else {
	 cy=0; m=0xffff-offset+1;
	 memcpy(pvideo,buffs,m);
	 pvideo+=m;
	 outportb(0x3c4,0x0e);
	 outportb(0x3c5,((seg++)&0x0f)^2);
	 memcpy(pvideo,&buffs[m],num-m);
	 pvideo+=num-m;
	}
       pvideo+=(DIMX-num); offset+=DIMX;
       if((FP_OFF(pvideo)<DIMX)&&cy) {
	 outportb(0x3c4,0x0e);
	 outportb(0x3c5,((seg++)&0x0f)^2);
	}
       cy=1;
       }
      close(pcx_src);
      return 1;
    }

int  dshow(char *filename,int flag)
  {  unsigned long ea;
     int pcx_src,y=512,cy=1;
     unsigned char buffs[DIMX];
     char far *pvideo,msg[9];
     unsigned int i,j,k,m,seg,offset,num;

     if((pcx_src=open(filename,O_RDWR|O_BINARY,S_IREAD))==-1) {
       fseek(ovlp,-5*32,2); title16(400,575,5,2,255);
       bell(800); return -1; }
     fseek(ovlp,-33*32,SEEK_END);
     mbar(0,DIMY-29,640,DIMY,252);
     title16(400,575,3,2,255);
     read(pcx_src,msg,8);
     if(strcmp(msg,"JPEG R")!=NULL) {
       close(pcx_src); return -1; }
     read(pcx_src,&num,2);
     read(pcx_src,&y,2);
     num*=2; y=y*2-1;
     lseek(pcx_src,0,SEEK_SET);
     ea=(unsigned long)(610-y)/2*DIMX+(1000-num)/2;
     seg=ea>>16; offset=ea&0xffff;
     pvideo=MK_FP(0xA000,offset);
     outportb(0x3c4,0x0e);
     outportb(0x3c5,((seg++)&0x0f)^2);
     for(j=0;j<=(y/2)+1;j++) {
       read(pcx_src,buffs,num/2);
       for(m=0;m<num/2;m++) buffs[m]>>=flag;
       for(k=0;k<=1;k++) {
	 if(offset+num>=offset&&offset+num<=0xffff)
	   for(m=0;m<num;m++) *pvideo++=buffs[m/2];
	  else {
            cy=0;
	    for(m=0;m<=0xffff-offset;m++) *pvideo++=buffs[m/2];
	    outportb(0x3c4,0x0e);
	    outportb(0x3c5,((seg++)&0x0f)^2);
	    for(i=m;i<num;i++) *pvideo++=buffs[i/2];
	   }
	  pvideo+=(DIMX-num); offset+=DIMX;
	  if((FP_OFF(pvideo)<DIMX)&&cy) {
	    outportb(0x3c4,0x0e);
	    outportb(0x3c5,((seg++)&0x0f)^2);
	   }
	  cy=1;
	 }
       }
      close(pcx_src);
      return 1;
    }

int  mshow(unsigned int segment,int width,int height,int C)
  {  unsigned long ea;
     char huge *buffs,far *p;
     unsigned int i,m,seg,offset,cy=1;

     if(C!=1&&C!=2) return -1;
     width*=C; height*=C;
     ea=(unsigned long)(610-width)/2*DIMX+(1000-height)/2;
     seg=ea>>16; offset=ea&0xffff;
     p=MK_FP(0xA000,offset);
     outportb(0x3c4,0x0e);
     outportb(0x3c5,((seg++)&0x0f)^2);
     buffs=(char far *)MK_FP(segment,0);
     for(i=0;i<height;i++) {
       if((offset+width>=offset)&&(offset+width<=0xffff))
	 for(m=0;m<width;m++) *p++=(unsigned char)*(buffs+m/C)>>2;
	else {
	 cy=0;
	 for(m=0;m<0xffff-offset+1;m++)
	   *p++=(unsigned char)*(buffs+m/C)>>2;
	 outportb(0x3c4,0x0e);
	 outportb(0x3c5,((seg++)&0x0f)^0x02);
	 for(m=m;m<width;m++)
	   *p++=(unsigned char)*(buffs+m/C)>>2;
	}
       p+=(DIMX-width); offset+=DIMX;
       if(FP_OFF(p)<DIMX&&cy) {
	 outportb(0x3c4,0x0e);
	 outportb(0x3c5,((seg++)&0x0f)^2);
	}
       cy=1;
       if(C==1) buffs+=width;
	else buffs+=(i%2)?width/C:0;
      }
    }

void ScrBar()
   { Hide();
     draw_bmp256(1,Bar[0][0],Bar[0][1]);
     draw_bmp256(2,Bar[1][0],Bar[1][1]);
     draw_bmp256(3,Bar[2][0],Bar[2][1]);
     draw_bmp256(4,Bar[3][0],Bar[3][1]);
     mcrectangle(Bar[0][0],Bar[2][1],Bar[2][0]+18,Bar[0][1]+18,253,254);
     mbar(Bar[0][0]+17,Bar[0][1],Bar[1][0],Bar[1][1]+17,253);
     mbar(Bar[2][0],Bar[2][1]+17,Bar[3][0]+17,Bar[3][1],253);
     mrectangle(Bar[0][0],Bar[2][1],Bar[2][0]-1,Bar[0][1]-1,254);
     mbar(Bar[2][0],Bar[1][1]+1,Bar[2][0]+17,Bar[1][1]+17,253);
     Show();
    }
