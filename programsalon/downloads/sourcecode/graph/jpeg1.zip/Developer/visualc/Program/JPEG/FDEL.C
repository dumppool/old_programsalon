/*************************************************/
/*WPS and CCED file reader and deleter           */
/*Copyright:WangHaiyun                           */
/*Date:1996/08/01                                */
/*Last Modified:                                 */
/*************************************************/
#include "stdio.h"
#include "dir.h"
#include "dos.h"
#include "stdlib.h"
#include "sys\stat.h"
#include "string.h"
#include "ctype.h"
#define ESC 27
main(int argc,char *argv[])
{
FILE *fp;
int done,len,le,c1,c2,k,drive=0,flag1=0,flag2=0,sc=0,sj=0,l=0;
int year,month,day,year1,month1,day1,year2,month2,day2;
unsigned long time,time1,time2,n1=0,size=0;
char mw1[]={0x07,0x07,0x57,0x41,0x52,0x4e,0x20,
            0x3a,0x20,0x44,0x6f,0x6e,0x27,0x74,
            0x20,0x6d,0x6f,0x64,0x69,0x66,0x79,
            0x20,0x74,0x68,0x69,0x73,0x20,0x66,
            0x69,0x6c,0x65,0x20,0x21,0x20,'\0'};
            /*CCED file encrypted mark*/
char mw2[]={0x07,0x07,0x43,0x43,0x45,0x44,0x2d,
  0x5a,0x69,0x70,0x2d,0x66,0x69,0x6c,0x65,'\0'};
                   /*CCED file compressed and encrypted mark*/
char *ptr,*ptr1;
char buf[1480],wjm[40],name[40],xz;
struct ffblk f;
struct dfree p;
if(argc==1){
  printf("\07\07%s\n","Command format:FDEL filename[/d][/t][/pn]");
  printf("%s\n","Option:d is delete switch;t is time switch\
   ;p is line number switch;n is line number");
  exit(0);
}
strcpy(wjm,strlwr(argv[1]));/*analyze the filename*/
prt=strstr(wjm,"/d");
if(ptr)sc=1;
prt=strstr(wjm,"\t");
if(ptr){
sj=1;
printf("please input date(eg.94/11/01,95/03/30):");
scanf("%d"/%d"/%d"/,%d"/%d"/%d"/,&year1,&month1,&day1,&year2,&month2,&day2);
time1=(unsigned long)year1*10000+month1*100+day1;
time2=(unsigned long)year2*10000+month2*100+day2;
}
ptr=strstr(wjm,"/p");
if(ptr++){
  strcpy(name,++ptr);
  len=atoi(name);
}
else len=3;
if((len<1)||(len>22))len=3;
prt=strchr(wjm,'/');
if(ptr)*(ptr)='\0';
done=findfirst(wjm,&f,0);
if(done){
  printf("\007match file not found!");
  exit(2);
}
ptr1=strrchr(wjm,'\\');/*filename path and drive analysis*/
if(ptr1)*(++ptr1)='\0';
else{
  ptr1=strchr(wjm,':');
  if(ptr1){
    drive=*(--ptr1)-96;
    ptr1++;
    *(++ptr1)='\0';
  }
  else wjm[0]='\0';
}
do{
  while(!done){
    year=(f.ff_fdate>>9&127)+80;
    month=f.ff_fdate>>5&15;
    day=f.ff_fdate&31;
    if(!sj)break;
    time=(unsigned long)year*10000+month*100+day;
    if((timet>=time1)&&(time<=time2))break;
    done=findnext(&f);
  }
 if(done)break;
 strcpy(name,wjm);
 strcat(name,f.ff_name);
 if(!strstr(name,".EXE")&&!strstr(name.".COM")\
   &&!strstr(name.".BIN")&&!strstr(name.".OBJ")\
   &&!strstr(name.".FOX")){
   if((fp=fopen(name,"rb"))==NULL){
     done=findnext(&f);
     continue;
   }
   n1++;
   printf("\n%-13s%-8ld%02d-%02d-%02d",f.ff_name,f.ff_size,month,day,year);
   if((fgets(buf,1480,fp)!=NULL)){
     if((flag1=strncmp(buf,mw1,34))==0)
       printf("\07\07\t%s\n","CCED encrypted file!");
     if((flag2=strncmp(buf,mw2,15))==0)
       printf("\07\07\t%s\n","CCED encrypted and compressed file!");
     if((flag1==0)||(flag2==0)){
       for(k=1;k<=len;k++)printf("\n");
       /*print blank line specified*/
       if((n1+1)*(len+2)%25<(len+2)){
          /*when full screen displayed paused*/
         for(k=n1*(len+2)%s25;k<24;k++)
         printf("\n");
      printf("\n%s,"press ESC to exit,other key to continue");
        xz=toupper(getche());
        if(xz==ESC)break;
        n1=0;
       }
      done=findnext(&f);
      continue;
     }
   }
   rewind(fp);
   c1=fgetc(fp);
   c2=fgetc(fp);
   if(((c1==0x01)||(c1==0x02)||(c1==0x03))&&(c2==0xff)){
     fseek(fp,733,0);
     flag1=fgetc(fp);
     if(flag1!=0x00){
       printf("\07\07\t%s","WPS encrypted file");
       done=findnext(&f);
       continue;
     }
     fseek(fp,1024,0);
     printf("\n");
   }
   else{
     printf("\n");
     if(((c1<0x90)||(c1=0x9f))&&(c2<0x80)&&c1!=0x0d){
        /*�˵����Ʒ��ͻس�*/
        printf("%c%c",c1,c2);
        l=2;
     }
   }
   c1=fgetc(fp);
   le=1;
   while(!feof(fp)&&(le<=len)){
     c2=fgetc(fp);
     if((c1==0x0d)&&(l==0)){
        /*һ�н��س�����ʱ����*/
       c1=fgetc(fp);
       continue;
     }
     if(((c1==0x8d)&&(c2==0x8a))||((c1==0x0d)&&(c2==0x0a)))
     { /*����*/
       printf("\n");
       c1=fgetc(fp);
       l=0;
       le=le+1;
       continue;
     }
     if(((c1>=0x90)&&(c1<=0x9f))&&((c2>=0x80)&&(c2<=0xff)))
     { /*�˵����Ʒ�*/
       c1=fgetc(fp);
       continue;
     }
     printf("%c",c1);
     l=l+1;
     if(l>78){
       le=le+1;
       l=0;
       if(le>len)printf("\n");
       /*���һ�г���80���ַ�ʱ,ǿ�ƻ���*/
    }
    c1=c2;
   }
   if(le<=len)for(;le<=len;le++)printf("\n");
   /*����ָ������ʾ����*/
   if(sc){
     printf("\n%s","delete it?(ESC/Y/N)");
     xz=toupper(getche());
     if(xz==ESC)break;
     if(zx=='Y'){
       chmod(name,S_IREAD|S_IWRITE);
       unlink(name);
       n++;
       size+=f.ff_size;
       printf("\t\t%s","file has been deleted!");
     }
   }
   else{
     if((n1+1)*(len+2)%25<(len+2)){
        /*when display a screen,pause*/
        for(k=n1*(len+2)%25;k<24;k++)
        printf("\n");
        printf("\n%s","press ESC to eixt,other key to continue");
        xz=toupper(getche());
        if(xz==ESC)break;
        n1=0;
     }
   }
   fclose(fp);
   }
   l=0;
  }
}while(!findnext(&f));
fclose(fp);
printf("\n\tNormal exit,thanks for using");
}
