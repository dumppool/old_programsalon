#include <ctype.h>
#include <dos.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include "c_base.h"
/*open graph_text field file */
DBT *_Cdecl open_DBT(char *dbf_name)
{
    DBT *dbt;
    dbt=(DBT *)malloc(sizeof(DBT));
    if((dbt->handle=open(dbt_name,O_RDWR|O_DENYNOEN|O_BINARY))==-1)
    {
        free(dbt);
        return NULL;
    }
    read(dbt->handle,&(dbt->filename),4);
    return dbt;
}

/*create new DBT file*/
DBT *_Cdecl create_DBT(char *dbf_name)
{
    DBT *dbt;
    dbt=(DBT *)malloc(sizeof(DBT));
    _creat(dbt_name,0x20);
    if((dbt->handle=open(dbt_name,O_RDWR|O_DENYNOEN|O_BINARY))==-1)
    {
        free(dbt);
        return NULL;
    }
    dbt->filesize=4L;
    write(dbt->handle,&(dbt->filesize),4);
    return dbt;
}

/*close DBT file*/
int _Cdecl close_DBT(DBT *dbt)
{
    if(dbt==NULL)
    return 0;
    lseek(dbt->handle,0L,SEEK_SET);
    write(dbt->handle,&(dbt->filesize),4);
    close(dbt->handle);
    free(dbt);
    return 1;
}

int _Cdecl put_gt(DBF *dbt,int field_no,DBT *dbt,long info_len,\
   void *buff,int type)
{
    GRAPH_TEXT gt;
    char format[6];
    if(dbt==NULL||dbf==NULL||field_no>dbt->fld_count||\
      dbf->dbf_stru[field_no-1].field_type!='M')
      return 0;
    gt.modify_tag='#';
    gt.field_type=type;
    gt.addr=dbt->filesize;
    gt.len=info_len;
    itoa(field_no,format,10);
    strcat(format,"g");
    put_record(dbf,format,gt);
    lseek(dbt->handle,0L,SEEK_END);
    if(write(dbt->handle,buff,info_len)==0)
    return 0;
    dbt->filesize+=info_len;
    return 1;
}

/*get a graph_text item to buffer*/
int _Cdecl get_gt(DBF *dbf,int field_no,DBT *dbt,void *buff)
{
    GRAPH_TEXT gt;
    char format[6];
    if(dbt==NULL||dbf==NULL||field_no>dbt->fld_count||\
      dbf->dbf_stru[field_no-1].field_type!='M')
      return 0;
    itoa(field_no,format,10);
    strcat(format,"g");
    get_record(dbf,format,&gt);
    lseek(dbt->handle,gt.addr,SEEK_SET);
    if(read(dbt->handle,buff,gt.len)==0)
       return 0;
    return 1;
}

/*---write file content to database Memo field-------- */
int _Cdecl file_to_gt(DBF *dbf,int field_no,DBT *dbt,char *filename,int type)
{
    GRAPH_TEXT gt;
    char format[6];
    int file_handle;
    char buff;
    if(dbt==NULL||dbf==NULL||field_no>dbt->fld_count||\
      dbf->dbf_stru[field_no-1].field_type!='M'\
      ||(file_handle=open(filename,O_RDONLY|BINARY))==0)
      return 0;
    itoa(field_no,format,10);
    strcat(format,"g");
    gt.modify_tag='#';
    gt.field_type=type;
    gt.addr=dbt->filesize;
    gt.len=filelength(file_handle);
    lseek(dbt->handle,0L,SEEK_END);
    while(eof(file_handle)==0)
    {
        read(file_handle,&buff,1);
        write(dbt->handle,&buff,1);
    }
    dbt->filesize+=gt.len;
    put_record(dbf,format,gt);
    return 1;
}

/*put Memo field into a file*/
int _Cdecl gt_to_file(DBF *dbf,int field_no,DBT *dbt,char *filename)
{
    GRAPH_TEXT gt;
    char format[6];
    int file_handle;
    int i;
    char buff;
    if(dbt==NULL||dbf==NULL||field_no>dbt->fld_count||\
      dbf->dbf_stru[field_no-1].field_type!='M')
      return 0;
    if((file_handle=_creat(filename,0x20))==-1)
    return 0;
    itoa(field_no,format,10);
    strcat(format,"g");
    get_record(dbf,format,&gt);
    lseek(dbt->handle,gt.addr,SEEK_SET);
    for(i=0;i<gt.len;i++)
    {
        read(dbt->handle,&buff,1);
        write(file_handle,&buff,1);
    }
    return 1;
}

/*delete Memo field content*/
int _Cdecl delete_gt(DBF *dbf,int field_no)
{
    GRAPH_TEXT gt;
    char format[6];
    if(dbt==NULL||dbf==NULL||field_no>dbt->fld_count||\
      dbf->dbf_stru[field_no-1].field_type!='M')
      return 0;
    itoa(field_no,format,10);
    strcat(format,"g");
    get_record(dbf,format,&gt);
    if(gt.modify_tag!='#')
        return 0;
    gt.modify_tag='#';
    put_record(dbf,format,gt);
    return 1;
}

/*pack Memo file*/
int _Cdecl pack_gt(DBF *dbf,int field_no,char *old_dbt_name,\
    char *new_dbt_name)
{
    DBT *old_dbt=open_DBT(old_dbt_name);
    DBT *new_dbt=create_DBT(new_dbt_name);
    GRAPH_TEXT gt;
    char format[6];
    char buff;
    long i;
    if(old_dbt==NULL||new_dbt==NULL||dbf==NULL||field_no>dbt->fld_count||\
      dbf->dbf_stru[field_no-1].field_type!='M')
      return 0;
    itoa(field_no,format,10);
    strcat(format,"g");
    go_record(dbf,1);
    while(!eof_DBF(dbf))
    {
        get_record(dbf,format,&gt);
        if(gt.modify_tag=='#')
        {
            lseek(old_dbt->handle,gt.addr,SEEK_SET);
            gt.addr=filelength(new_dbt->handle);
            for(i=0L;i<gt.len;i++)
            {
                read(old_dbt->handle,&buff,1);
                write(new_dbt->handle,&buff,1);
            }
            put_record(dbf,format,gt);
       }
       skip(dbf,1);
    }
    new_dbt->filesize=filelength(new_dbt->handle);
    close_DBT(odl_dbt);
    close_DBT(new_dbt);
    return 1;
}

