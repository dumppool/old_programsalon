#include <stdio.h>
#include <io.h>
#include <alloc.h>
#include <stdlib.h>
#include <dos.h>
#include <mem.h>
#include <string.h>
#include <dir.h>
#include <math.h>
#define	FALSE 	  0
#define TRUE	  1
#define	EMM	  0x67
#define COLOR_NUM 240
#define DAC_BEGIN 1
#define LM 	  64

char far *EMMbase;
union REGS regs;
struct SREGS sregs;
struct ffblk ffblk;
unsigned char far *buf[LM][LM];
unsigned char coll[3][15000];
char fr[13],fg[13],fb[13],fout[13],fpal[13];
int WIDTH=256,HEIGHT=256,PAGE_NUM=4,COLOR_CUT=8,PAGE_LINE=0x40;

main(int argc,char *argv[])
{unsigned int EMMhandle,offset,sgm,ex1,ex2,ex3,p,num;
register int k,j,i;
unsigned char far *p1,far *p2,far *p3,far *p4;
struct time time1,time2;
char path[80],driver[4],dir[80],name[9],ext[4];
FILE *f1,*f2,*f3,*f4,*f5;

if(argc<2) {printf("Input filename[eg. AMBER.R ...]:");
	scanf("%s",path);
	}
	else strcpy(path,argv[1]);
if(strchr(path,'.')==NULL) strcat(path,".*");
if(!findfirst(path,&ffblk,0x20)) {
	fnsplit(ffblk.ff_name,driver,dir,name,ext);
	strcpy(fr,name);strcat(fr,".r1");
	strcpy(fg,name);strcat(fg,".g1");
	strcpy(fb,name);strcat(fb,".b1");
	}
	else {printf("\nFile cna't Open!\n");
	return -1;
	}
f1=fopen(fr,"rb"); f2=fopen(fg,"rb"); f3=fopen(fb,"rb");
if((f1==NULL)|(f2==NULL)|(f3==NULL)) {
	printf("File Open ERROR!");EMMclose();return -1;}
fseek(f1,0,2);WIDTH=(int)sqrt(ftell(f1));rewind(f1);
switch(WIDTH){
case 512:WIDTH=HEIGHT=512;PAGE_NUM=16;
	 COLOR_CUT=15;PAGE_LINE=0x20;break;
case 128:WIDTH=HEIGHT=128;PAGE_NUM=1;
	 COLOR_CUT=5;PAGE_LINE=0x80;
}
gettime(&time1);
if(!EMMtest()){
	printf("Expanded Memory is NOT present\n");
	return -1;
	}
if(!EMMok()){
	printf("Expanded Memory is NOT available\n");
	return -1;
	}
EMMnum();
if((EMMhandle=EMMalloc(PAGE_NUM*3))==0xffff)
	{printf("EMM alloc error");
	 return -1;
	}

for(k=0;k<PAGE_NUM;k++){
	EMMmap(0,k,EMMhandle);	          EMMmove(0,f1);
	EMMmap(0,k+PAGE_NUM,EMMhandle);	  EMMmove(0,f2);
	EMMmap(0,k+PAGE_NUM*2,EMMhandle); EMMmove(0,f3);
	}
for(j=0;j<LM;j++)
	for(k=0;k<LM;k++)
	{buf[j][k]=(unsigned char far *)malloc(LM);
	if(buf[j][k]==NULL)
		{printf("\nMemory application failed!");return -1;}
	}
p1=(unsigned char far *)malloc(WIDTH);
p2=(unsigned char far *)malloc(WIDTH);
p3=(unsigned char far *)malloc(WIDTH);
p4=(unsigned char far *)malloc(WIDTH);
for(i=0;i<LM;i++)
    for(j=0;j<LM;j++)
	for(k=0;k<LM;k++)
	buf[i][j][k]=0;
printf("\nCreating Palettes   ");
for(j=0;j<HEIGHT;j++)
	{p=j%PAGE_LINE;
	if(!p){printf("�");i=j/PAGE_LINE;
		EMMmap(0,i,EMMhandle);
		EMMmap(1,i+PAGE_NUM,EMMhandle);
		EMMmap(2,i+PAGE_NUM*2,EMMhandle);
		}
	offset=(unsigned int)p*WIDTH;
	EMMget(0,p1,offset);
	EMMget(1,p2,offset);
	EMMget(2,p3,offset);
	for(k=0;k<WIDTH;k++)
		{p1[k]>>=2;p2[k]>>=2;p3[k]>>=2;}
	for(k=0;k<WIDTH;k++)
	if(buf[p1[k]][p2[k]][p3[k]]<=COLOR_CUT) buf[p1[k]][p2[k]][p3[k]]++;
	}
if(fclose(f2)|fclose(f3)|fclose(f1))
	{printf("File close ERROR!");EMMclose();return -1;}
num=DAC_BEGIN;
for(i=0;i<LM;i++)
  for(j=0;j<LM;j++)
     for(k=0;k<LM;k++)
     if(buf[i][j][k]>COLOR_CUT)
     {coll[0][num]=i;coll[1][num]=j;coll[2][num]=k;
     num++;
     }
sgm=0;
while(num>COLOR_NUM){
sgm++;
for(i=DAC_BEGIN;i<num-1;i++){
   ex2=256;if(num<COLOR_NUM) break;
   for(k=i+1;k<i+15;k++){
	if(k>num-1) break;
	ex1=abs(coll[0][i]-coll[0][k])+abs(coll[1][i]-coll[1][k])+abs(coll[2][i]-coll[2][k]);
	if(ex1<ex2){ex2=ex1;ex3=k;}
	}
   if(ex2<=sgm){
	for(j=ex3;j<num-1;j++)
	  for(k=0;k<3;k++) coll[k][j]=coll[k][j+1];
	for(k=0;k<3;k++) coll[k][num-1]=0;
	num--;
	}
   }
}

ex1=ex2=ex3=0;
strcpy(fout,name);strcat(fout,".img");
strcpy(fpal,name);strcat(fpal,".pal");
f4=fopen(fout,"wb");
f5=fopen(fpal,"wb");
for(k=0;k<256;k++){
	fputc(coll[0][k],f5);
	fputc(coll[1][k],f5);
	fputc(coll[2][k],f5);
	}
gettime(&time2);
printf("\nUsing %d Seconds",
    (time2.ti_min-time1.ti_min)*60+time2.ti_sec-time1.ti_sec);
gettime(&time1);
printf("\nSelecting  Colors   ");
for(i=0;i<HEIGHT;i++)
    {p=i%PAGE_LINE;
	if(!p){printf("�");j=i/PAGE_LINE;
	      EMMmap(0,j,EMMhandle);
	      EMMmap(1,j+PAGE_NUM,EMMhandle);
	      EMMmap(2,j+PAGE_NUM*2,EMMhandle);
	      }
    offset=(unsigned int)p*WIDTH;
    EMMget(0,p1,offset);
    EMMget(1,p2,offset);
    EMMget(2,p3,offset);
    for(k=0;k<WIDTH;k++) {p1[k]>>=2;p2[k]>>=2;p3[k]>>=2;}
    for(j=0;j<WIDTH;j++)
	{ex1=256;ex3=128;
	for(k=DAC_BEGIN;k<COLOR_NUM;k++)
	    {ex2=abs(p1[j]-coll[0][k])+
		abs(p2[j]-coll[1][k])+abs(p3[j]-coll[2][k]);
	    if(ex2<ex1) {ex3=k;ex1=ex2;if(ex1<7) break;}
	    }
	p4[j]=ex3;
	}
    fwrite(p4,1,WIDTH,f4);
    }
fclose(f4);fclose(f5);
mark2: for(j=0;j<LM;j++)
	 for(k=0;k<LM;k++) free(buf[j][k]);
free(p1);free(p2);free(p3);free(p4);EMMclose(EMMhandle);
gettime(&time2);
printf("\nUsing %d Seconds\n",
	(time2.ti_min-time1.ti_min)*60+time2.ti_sec-time1.ti_sec);
}

int EMMtest()
{int result;
unsigned int handle;
regs.x.ax=0x3d00;
regs.x.dx=(int)"EMMXXXX0";
sregs.ds=_DS;
intdosx(&regs,&regs,&sregs);
handle=regs.x.ax;
if(result=(regs.x.cflag==0)){
	regs.h.ah=0x3e;
	regs.x.bx=handle;
	intdos(&regs,&regs);
	}
return(result);
}

int EMMok()
{regs.h.ah=0x40;
int86(EMM,&regs,&regs);
if(regs.h.ah!=0)
	return(FALSE);
regs.h.ah=0x41;
int86(EMM,&regs,&regs);
if(regs.h.ah!=0)
	return(FALSE);
EMMbase=MK_FP(regs.x.bx,0);
return(TRUE);
}

int EMMalloc(int n)
{regs.h.ah=0x43;
regs.x.bx=n;
int86(EMM,&regs,&regs);
if(regs.h.ah!=0)
	return(0xffff);
 else return(regs.x.dx);
}

int EMMmap(int page,int phys,unsigned int handle)
{regs.h.ah=0x44;
regs.h.al=page;
regs.x.bx=phys;
regs.x.dx=handle;
int86(EMM,&regs,&regs);
return(regs.h.ah==0);
}

int EMMmove(int page,FILE *ff)
{char far *ptr;
ptr=EMMbase+page*0x4000;
fread(ptr,1,0x4000,ff);
}

int EMMget(int page,char *str,int offset)
{char far *ptr;
ptr=EMMbase+page*0x4000+offset;
memcpy(str,ptr,WIDTH);
}

int EMMnum()
{int total,notuse;
EMMver();
regs.h.ah=0x42;
int86(EMM,&regs,&regs);
if(regs.h.ah==0)
	{total=regs.x.dx;notuse=regs.x.bx;
	printf("�� Total  Expanded Memory=%3d Pages\n\n",total);
	printf("�� Enable Expanded Memory=%3d Pages\n\n",notuse);
	printf("�� Using  Expanded Memory=%3d Pages\n\n",PAGE_NUM*3);
	}
}

int EMMver()
{int t;
regs.h.ah=0x46;
int86(EMM,&regs,&regs);
t=regs.h.al;
printf("�� EMS Ver %x.%x\n\n",t>>4,t&0x0f);
}

int EMMclose(unsigned int handle)
{regs.h.ah=0x45;
regs.x.dx=handle;
int86(EMM,&regs,&regs);
return(regs.h.ah==0);
}
