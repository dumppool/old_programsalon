#include <stdio.h>
#include <graphics.h>
#include <conio.h>

main()
{
FILE	*fp;
int i,i1,i2,i3,row=0,col=0,trow=0;
int gd=DETECT,gm;
char by[72];
long length=10;

initgraph(&gd,&gm,"c:\\tc");
if ((fp=fopen("jpeg.ov1","rb"))==NULL)
	{
	closegraph();
          puts("\7 can't open file");
	exit(0);
	}
fseek(fp,0,2);
length=ftell(fp)/72l;
fseek(fp,0,0);
for(i=0;i<length;i++)
	{if(kbhit()){getch();break;}
	fread(by,72,1,fp);
	col=trow;
	for(i1=0;i1<24;i1++)
		{for(i2=0;i2<3;i2++)
		for(i3=0;i3<8;i3++)
		if(getbit(by[i1*3+i2],7-i3))
		putpixel(row,col+i2*8+i3,GREEN);
		row++;
		}
	row+=4;
	if(row>610)
		   {row=0;trow+=28;
		if(trow>450){getch();cleardevice();trow=0;}
		}
	}
getch();
closegraph();
}

int getbit(unsigned char c,int n)
{return((c>>n)&1);
}
