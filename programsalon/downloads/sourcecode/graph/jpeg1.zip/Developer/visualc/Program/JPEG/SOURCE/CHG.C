#include <io.h>
#include <dos.h>
#include <math.h>
#include <stdio.h>
#include <alloc.h>
#include <fcntl.h>
#include <sys/stat.h>

main ()
   { float temp;
     unsigned long len;
     char fr[80],fg[80],fb[80],fy[80],fcr[80],fcb[80];
     int hR,hG,hB,hY,hCr,hCb,i,j,width,height,ww,hh,step;
     unsigned int segment,Seg_R,Seg_G,Seg_B,Seg_Y,Seg_Cr,Seg_Cb;
     unsigned char huge *pR,huge *pG,huge *pB,huge *pY,huge *pCr,huge *pCb;

     printf("File Name:"); gets(fr);
     strcpy(fy,fr);
     strcat(fr,".bmp");
     strcat(fy,".ov2");
     len=(unsigned long)64*64;
     if((i=allocmem(len,&segment))!=-1) {
       printf("Not Enough Memory!"); exit(-1); }
     if((hR=open(fr,O_RDONLY|O_BINARY,S_IREAD))==-1) {
       printf("Open File Error!");
       freemem(segment); exit(-1); }
     if((hY=open(fy,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE))==-1) {
       printf("Open File Error!"); close(hR);
       freemem(segment); exit(-1); }
     lseek(hR,0,SEEK_END);
     len=tell(hR);
     lseek(hR,0,SEEK_SET);
     Seg_R=segment;
     pR=MK_FP(Seg_R,0);
     read(hR,(void *)pR,len);
     pY=MK_FP(Seg_R,1078);
     for(i=0;i<len-1078;i++) {
      if(*pY==248) *pY=254;
       else if(*pY==0x7) *pY=253;
       else if((*pY!=0x7)&&(*pY!=248)&&(*pY!=255)) *pY=255;
      pY++;
      }
     write(hY,(void *)pR,len);
     close(hY); close(hR);
     freemem(segment);
    }
