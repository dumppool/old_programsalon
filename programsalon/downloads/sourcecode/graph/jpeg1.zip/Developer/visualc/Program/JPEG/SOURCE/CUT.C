#include <stdio.h>
#include <sys/stat.h>
#include <dos.h>
#include <fcntl.h>
#include <io.h>
#define SIZE (unsigned int )(32*1024)

 int main()
 {
   char filenamein[30],filenameout[30];
   register int i,j;
   unsigned int segp1;
   int handle,SX,SY,stat,dim_X,dim_Y,X,Y,s1;
   char huge *p;
/*-------------------------------------------------------------------------*/
   printf("Enter the source file's name:");
   scanf("%s",filenamein);
   printf("Enter the object file's name:");
   scanf("%s",filenameout);
   printf("Enter the dimension of the image:");
   scanf("%d,%d",&dim_X,&dim_Y);
   printf("Enter the object start point:");
   scanf("%d,%d",&SX,&SY);
   printf("Enter the object size of the image:");
   scanf("%d,%d",&X,&Y);
   stat=allocmem(64*256,&segp1);
   if(stat!=-1){
      printf("Failed:Max Memory available is %uk\n",stat/64);
      exit(0);
     }
   p=(char huge *)MK_FP(segp1,0);
   handle=open(filenamein,O_RDWR|O_BINARY,S_IREAD);
   if(handle==-1){
      printf("Failed to open this file!\n");
      freemem(segp1);  abort(1);
     }
   s1=dim_X/32*dim_Y/1024;
   if (s1>=1)
     for(i=0;i<=s1;i++){
	read(handle,(void *)p,SIZE);  p=p+SIZE;
       }
    else read(handle,(void *)p,dim_X*dim_Y);
   close(handle);
   handle=open(filenameout,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE);
   if(handle==-1){
      printf("Failed to open this object file!\n");
      freemem(segp1);   abort(1);
     }
   segp1+=(dim_X/16)*SY;  p=(char huge *)MK_FP(segp1,0);
   p+=SX;
   for (i=0;i<Y;i++) {
     write(handle,(void *)p,X);  p=p+dim_X;
    }
   close(handle);
   freemem(segp1);
 }
