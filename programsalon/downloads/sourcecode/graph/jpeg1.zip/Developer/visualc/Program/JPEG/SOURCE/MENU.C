/* JPEG System MENU & Main Functions */
/* Written in TURBO C V2.0 6-13-1995 */
/* �Ҷ�ͼ��ѹ�� */
int  Image_Stacker()
  {  unsigned long imagesize;
     unsigned int segp1,segp2,code_size;
     register int i,stat,handle1,handle2;
     char huge *p,message[40]="Failed:Max Memory available is ",size[9];

     if((stat=allocmem(64*64,&segp2))!=-1) {
       ultoa((long)stat/64,size,10);
       strcat(message,size);
       strcat(message,"K");
       ErrorProc(message);
       return -1; }
     while(1) {
       fseek(ovlp,-12*32,SEEK_END);
       Hide(); mbar(0,DIMY-29,640,DIMY,252);
       title16(2,575,7,2,255); Show();
       if(mscanf(filenamein)==-1)  {
	 Hide(); mbar(0,DIMY-29,640,DIMY,252);  Show();
	 mputs(25,36,"Return to MainMenu...",252,255); break; }
       if(findfirst(filenamein,&f_blk,FA_ARCH)!=-1) {
	 fnsplit(filenamein,drive,dir,name,ext);
	 do {
	   Set_Mouse(IDC_WAIT);
	   strcpy(name,f_blk.ff_name);
	   fnmerge(filenamein,drive,dir,name,"");
	   get_base_name(name,filenameout,".JPG");
	   if((handle1=open(filenamein,O_RDWR|O_BINARY,S_IREAD))!=-1) {
	     if((handle2=open(filenameout,
	      O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE))!=-1) {
	       read(handle1,size,8);
	       if(strcmp(size,"JPEG R")==NULL) {
		 read(handle1,&Width,2);
		 read(handle1,&Height,2);
		 imagesize=(unsigned long)Width*Height;
		 if((stat=allocmem((long)imagesize/16+1,&segp1))==-1) {
		   p=(char huge *)MK_FP(segp1,0);
		   stat=imagesize/SIZE;
		   imagesize%=SIZE;
		   for(i=0;i<stat;i++) {
		     read(handle1,(void *)p,SIZE); p+=SIZE; }
		   if(imagesize!=0)
		     read(handle1,(void *)p,(unsigned int)imagesize);
		   close(handle1);
		   Hide(); show("cls",1,0);
		   mshow(segp1,Width,Height,1);
		   mbar(0,DIMY-29,640,DIMY,252); Show();
		   fseek(ovlp,-41*32,2);
		   mputs(25,36,f_blk.ff_name,252,255);
		   Hide(); title16(400,575,11,2,255); Show();
		   code_size=Compress(segp1,segp2,Width,Height);
		   freemem(segp1); bell(800);
		   p=(char huge *)MK_FP(segp2,0);
		   write(handle2,"JPEG Y\x0\x0",8);
		   write(handle2,(void *)p,(unsigned int)code_size*4);
		   close(handle2);
		   Hide(); mbar(400,DIMY-29,640,DIMY,252);
		   title16(400,575,4,2,255); Show();
		   Hide(); mbar(400,DIMY-29,640,DIMY,252); Show();
		   strcpy(message,"Code_size is ");
		   ultoa((long)code_size*4,size,10);
		   strcat(message,size); strcat(message," Bytes");
		   mputs(50,36,message,252,255);
		   Set_Mouse(IDC_CURSOR);
		  }
		 else {
		   Set_Mouse(IDC_CURSOR);
		   ultoa((long)stat/64,size,10);
		   strcat(message,size); strcat(message,"K");
		   ErrorProc(message);
		   close(handle1); close(handle2);
		   remove(filenameout);
		   message[31]='\x0'; }
		}
               else {
		  Set_Mouse(IDC_CURSOR);
		  strcpy(message,filenamein);
		  strcat(message,"  UnKnown Image Format!");
		  ErrorProc(message);
		  close(handle1); close(handle2);
		  remove(filenameout); }
	      }
	     else {
	       Set_Mouse(IDC_CURSOR);
	       bell(800); mputs(25,36,filenameout,252,255);
	       mputs(50,36,"Failed to open object file!",252,251);
	       close(handle1); mdelay(20); }
	    }
	   else {
	     Set_Mouse(IDC_CURSOR);
	     fseek(ovlp,-5*32,SEEK_END); bell(800);
	     mputs(25,36,filenamein,252,255);
	     Hide(); title16(300,575,5,2,251); Show();
	     mdelay(20); }
	  } while(findnext(&f_blk)!=-1);
	}
       else {
	 Set_Mouse(IDC_CURSOR);
	 mputs(25,36,filenamein,252,255);
	 mputs(50,36,"File Not Found!",252,251);
	 bell(800); mdelay(20); }
      }
     freemem(segp2); return 0;
    }

/* �Ҷ�ͼ����� */
int  Image_UnStacker()
  {  unsigned long imagesize;
     int i,stat,handle1,handle2;
     unsigned int code_size,s,segp1,segp2;
     char huge *p,message[40]="Failed:Max Memory available is ",size[9];

     while(1) {
       fseek(ovlp,-12*32,2);
       Hide(); title16(2,575,7,2,255); Show();
       if(mscanf(filenamein)==-1) {
	 Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
	 mputs(25,36,"Return to MainMenu...",252,255); return 0; }
       if(strstr(filenamein,".")==NULL) strcat(filenamein,".JPG");
       if(findfirst(filenamein,&f_blk,FA_ARCH)!=-1) {
	 fnsplit(filenamein,drive,dir,name,ext);
	 do {
	   Set_Mouse(IDC_WAIT);
	   strcpy(name,f_blk.ff_name);
	   fnmerge(filenamein,drive,dir,name,"");
	   get_base_name(name,filenameout,".IMG");
	   if((handle1=open(filenamein,O_RDWR|O_BINARY,S_IREAD))!=-1) {
             if((handle2=open(filenameout,
	      O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE))!=-1) {
	       lseek(handle1,0,SEEK_END); imagesize=tell(handle1);
	       if((stat=allocmem((unsigned long)imagesize/16+1,&segp1))==-1) {
		 lseek(handle1,0,SEEK_SET);
		 read(handle1,&size[0],8);
		 if(strcmp(size,"JPEG Y")==NULL) {
		   read(handle1,&code_size,2);
		   read(handle1,&s,2);
		   imagesize=(unsigned long)code_size*s/16+1;
		   if((stat=allocmem((unsigned long)imagesize,&segp2))==-1) {
		     p=(char huge *)MK_FP(segp1,0);
		     stat=imagesize/SIZE+1;
		     lseek(handle1,8,SEEK_SET);
		     for(i=0;i<stat;i++) {
		       read(handle1,(void *)p,SIZE); p+=SIZE; }
		     close(handle1);
		     Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
		     mputs(25,36,filenamein,252,255);
		     fseek(ovlp,-26*32,SEEK_END);
		     Hide(); title16(400,575,10,2,255); Show();
		     imagesize=Decompress(segp2,segp1);
		     bell(800);
		     Hide(); mbar(400,DIMY-29,640,DIMY,252);
		     title16(400,575,4,2,255); Show();
		     p=(char huge *)MK_FP(segp2,0);
		     code_size=imagesize&0x0000ffff; /* width */
		     stat=imagesize/0x10000;         /* heigth */
		     write(handle2,"JPEG R\x0\x0",8);
		     write(handle2,&code_size,2);
		     write(handle2,&stat,2);
		     for(i=0;i<stat;i++){
		       write(handle2,(void *)p,code_size);
		       p+=code_size; }
		     close(handle2);
		     Hide(); mbar(400,DIMY-29,640,DIMY,252);
		     show("cls",1,0);
		     mshow(segp2,code_size,stat,1); Show();
		     Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
		     freemem(segp1); freemem(segp2);
		     Set_Mouse(IDC_CURSOR);
		    }
		   else {
		     Set_Mouse(IDC_CURSOR);
		     ultoa((long)stat/64,size,10);
		     strcat(message,size); strcat(message,"K");
		     ErrorProc(message);
		     message[31]='\x0';
		     freemem(segp1); close(handle1);
		     close(handle2); mdelay(20); }
		  }
		else {
		  Set_Mouse(IDC_CURSOR);
		  ErrorProc("Not A Luminance Image Code!");
		  freemem(segp1); close(handle1);
		  close(handle2); }
		}
	       else {
		 Set_Mouse(IDC_CURSOR);
		 ultoa((long)stat/64,size,10);
		 strcat(message,size); strcat(message,"K");
		 ErrorProc(message);
		 message[31]='\x0';
		 close(handle1);
		 close(handle2); mdelay(20); }
	      }
	     else {
	       Set_Mouse(IDC_CURSOR);
	       mputs(25,36,filenameout,252,255);
	       bell(800); close(handle1);
	       mputs(50,36,"Failed to Open object file!",252,251);
	       mdelay(20); }
	     }
	    else {
	      Set_Mouse(IDC_CURSOR);
	      mputs(25,36,filenamein,252,255);
	      bell(800); fseek(ovlp,-5*32,2); Hide();
	      title16(400,575,5,2,251); Show();
	      mdelay(20); }
	  } while(findnext(&f_blk)!=-1);
	 }
	else {
	  Set_Mouse(IDC_CURSOR);
	  mputs(25,36,filenamein,252,255);
	  mputs(50,36,"File Not Found!",252,251);
	  bell (800); delay(4000); }
      }
    }

/* ��ʽת���Ӳ˵����� */
int  Image_Manger()
  {  unsigned int seg;
     int cn,key=0,level=0,prev=0,use;

     Hide(); show("cls",1,0); Show();
     format();
     Hide(); select(SUB_box[0]); Show();
     while(1) {
       while(key!=CRKEY) {
	 if(bioskey(1)!=0) {
	 key=bioskey(0);
	 if((key==LEFT)||(key==RIGHT)||(key==TAB)) {
	   if(key==LEFT) level=level<=0?3:level-1;
	   if((key==RIGHT)||(key==TAB)) level=level>=3?0:level+1;
	   Hide(); bclose(SUB_box[prev]);
	   select(SUB_box[level]);
	   Show();
	  }
	 }
       prev=level;
       use=0;
       for(cn=0;cn<4;cn++)
	 if(Mouse_in_Box(&SUB_B_box[cn][0])) use++;
       if(use==0) Set_Mouse(IDC_CURSOR);
	else Set_Mouse(IDC_HAND);
       if(Left_Pressed()) {
	 do {
	   for(cn=0;cn<4;cn++) {
	     switch(SUB_BOX[cn]) {
	       case OFF: if(Mouse_in_Box(&SUB_B_box[cn][0])) {
			   Set_Mouse(IDC_HAND);
			   Hide(); box_down(SUB_box[cn]);
			   bclose(SUB_box[prev]);
			   select(SUB_box[cn]); Show();
			   SUB_BOX[cn]=ON; level=cn; prev=cn; key=CRKEY; }
			   break;
	       case  ON:   if(!Mouse_in_Box(&SUB_B_box[cn][0])) {
                           Set_Mouse(IDC_CURSOR);
			   Hide(); box_up(SUB_box[cn]); Show();
			   SUB_BOX[cn]=OFF;
			   key=level==cn?0:key; }
	      }
	     }
	   } while(Left_Pressed());
	  Hide();
	  box_up(SUB_box[level]);
	  Show();  SUB_BOX[level]=OFF;
	 }
	}
       key=0;
       Set_Mouse(IDC_CURSOR);
       switch(level) {
	 case 0: FormatChange(OFF); break;
	 case 1: FormatChange(ON);  break;
	 case 2: FormatHelp();      break;
	 case 3: Hide(); show("cls",1,0); Show(); return 1;
	}
      }
   }

/* ͼ��ۿ� */
int  Image_Viewer(char *fname)
  {  char pal[768],flags=OFF;
     int i,j,handle,flag=2,result;

     if(strcmp(fname,"")==NULL) {
       fseek(ovlp,-12*32,2);
       Hide(); mbar(0,DIMY-29,640,DIMY,252);
       title16(2,575,7,2,255); Show();
       if(mscanf(filenamein)==-1) {
	 Hide(); mbar(0,DIMY-29,640,DIMY,252);
	 Show(); return -1; }
      }
      else {
       strcpy(filenamein,fname);
       flags=ON; }
     if(strrchr(filenamein,'.')==NULL) strcat(filenamein,".IMG");
     if(findfirst(filenamein,&f_blk,FA_ARCH)!=-1) {
       Hide(); show("",1,0); Show();
       fnsplit(filenamein,drive,dir,name,ext);
       do {
	 Set_Mouse(IDC_WAIT);
	 strcpy(name,f_blk.ff_name);
	 fnmerge(filenamein,drive,dir,name,"");
	 Hide(); mbar(0,DIMY-29,640,DIMY,252);
	 get_base_name(filenamein,filenameout,".PAL");
	 if((handle=open(filenameout,O_RDWR|O_BINARY,S_IREAD))!=-1) {
	   read(handle,pal,768);
	   flag=0;
	   outportb(0x3c8,0);
	   for(i=0;i<240;i++)
	     for(j=0;j<3;j++)
	       outportb(0x3c9,pal[i*3+j]);
	  }
	 if((strstr(filenamein,".128")==NULL)&&
	  (strstr(filenamein,".256")==NULL)) result=show(filenamein,0,flag);
	  else result=dshow(filenamein,flag);
         mbar(0,DIMY-29,640,DIMY,252); Show();
	 if(flags==ON) return 2;
	 if(result==-1) strcat(filenamein," UnKnown Format");
	 mputs(25,36,filenamein,252,255);
	 mputs(55,36,"Press Any Key to View next...",252,255);
	 Set_Mouse(IDC_CURSOR);
	 bioskey(0);
	 flag=2;
	 Hide(); show("",1,0); Show();
	 if(handle!=-1) {
	   close(handle);
	   outportb(0x3c8,0);
	   for(i=0;i<64;i++)
	     for(j=0;j<3;j++) outportb(0x3c9,i);
	  }
	} while(findnext(&f_blk)!=-1);
       Hide(); mbar(0,DIMY-29,700,DIMY,252); Show();
       mputs(25,36,"All the Image are done,Return to MainMenu...",252,255);
      }
     else {
      bell(800);
      Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
      mputs(25,36,filenamein,252,255);
      mputs(50,36,"File Not Found",252,251); }
    }

/* R G B ==> ����+ɫ�� ɫ�ռ�ת�� */
int  ColorChange(char *name)
  {  float temp;
     unsigned long len;
     int hR,hG,hB,hY,i,j,ww,hh,step;
     unsigned int segment,Seg_R,Seg_G,Seg_B,Seg_Y,Seg_Cr,Seg_Cb;

     strcpy(fr,name); strcpy(fg,name);
     strcpy(fb,name); strcpy(fy,name);
     strcat(fr,".R"); strcat(fg,".G");
     strcat(fb,".B"); strcat(fy,".SWP");
     len=(unsigned long)(64*4+32)*64;
     if((i=allocmem(len,&segment))!=-1) {
       ErrorProc("Not Enough Memory!");
       return(-2); }
     Seg_R=segment;      Seg_G=segment+4096;
     Seg_B=Seg_G+4096;   Seg_Y=Seg_B+4096;
     Seg_Cr=Seg_Y+4096;  Seg_Cb=Seg_Cr+1024;
     if((hR=open(fr,O_RDONLY|O_BINARY,S_IREAD))==-1) {
       ErrorProc("Open File Error!");
       freemem(segment); return(-1); }
     read(hR,fr,8);
     if(strcmp(fr,"JPEG R")!=NULL) {
       close(hR); return -3; }
     read(hR,&Width,2);
     read(hR,&Height,2);
     if((hG=open(fg,O_RDONLY|O_BINARY,S_IREAD))==-1) {
       ErrorProc("Open File Error!");
       close(hR); freemem(segment);
       return(-1); }
     if((hB=open(fb,O_RDONLY|O_BINARY,S_IREAD))==-1) {
       ErrorProc("Open File Error!");
       close(hG); close(hR);
       freemem(segment); return(-1); }
     if((hY=open(fy,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE))==-1) {
       ErrorProc("Open File Error!");
       close(hR); close(hB); close(hG);
       freemem(segment); return(-1); }
     lseek(hG,12,SEEK_SET);
     lseek(hB,12,SEEK_SET);
     ww=Width&0xfff0; hh=Height&0xfff0;
     write(hY,&ww,2); write(hY,&hh,2);
     step=65536L/Width; step&=0xfff0;
     while(hh>0) {
       pR=MK_FP(Seg_R,0); pG=MK_FP(Seg_G,0);
       pB=MK_FP(Seg_B,0); pY=MK_FP(Seg_Y,0);
       step=(step>hh)?hh:step;
       hh-=step;
       for(i=0;i<step;i++) {
	 read(hR,(void *)pR,Width); pR+=ww;
	 read(hG,(void *)pG,Width); pG+=ww;
	 read(hB,(void *)pB,Width); pB+=ww; }
       pR=MK_FP(Seg_R,0); pG=MK_FP(Seg_G,0);
       pB=MK_FP(Seg_B,0);
       len=(unsigned long)step*ww;
       do {
	 temp=(unsigned char)*pR*0.3+(unsigned char)*pG*0.6+(unsigned char)*pB*0.1;
	 *pY=(unsigned char)temp;
	 pR++; pG++; pB++; pY++; len--;
	} while(len>0);
       len=(unsigned long)step*ww;
       pCr=MK_FP(Seg_Cr,0); pCb=MK_FP(Seg_Cb,0);
       pY=MK_FP(Seg_Y,0); pR=MK_FP(Seg_R,0);
       pB=MK_FP(Seg_B,0);
       len/=4; i=0;
       do {
	 temp=(*pR-*pY)/1.6+128;
	 *pCr++=(char)temp;
	 temp=(*pB-*pY)/2+128;
	 *pCb++=(char)temp;
	 pR+=2; pB+=2; pY+=2;
	 len--; i++;
	 if((i%(ww/2))==0) {
	   pR+=ww; pB+=ww; pY+=ww; }
	} while(len>0);
       pY=MK_FP(Seg_Y,0); pCr=MK_FP(Seg_Cr,0);
       pCb=MK_FP(Seg_Cb,0);
       for(i=0;i<step;i++) {
	 write(hY,(void *)pY,ww);    pY+=ww;
	 write(hY,(void *)pCr,ww/4); pCr+=(ww/4);
	 write(hY,(void *)pCb,ww/4); pCb+=(ww/4);
	}
      }
     freemem(segment);
     close(hR); close(hG);
     close(hB); close(hY);
     return 1;
   }

/* ��ɫͼ����� */
int  ColorDct(char *name)
  {  unsigned long len,count;
     int hY,hc,i,j,hcount,step;
     unsigned int segment,Code,size,times;
     unsigned char far *ps,far *ps1,far *ps2,far *pd;

     strcpy(fy,name); strcpy(fcr,name);
     strcpy(fc,name); strcpy(fcb,name);
     strcat(fy,".SWP"); strcat(fc,".JPG");
     len=(unsigned long)(64+32)*2*64;
     if((i=allocmem(len,&segment))!=-1) {
       ErrorProc("Not Enough Memory!");
       return(-1); }
     Code=segment+4096+1024*2+2;
     if((hY=open(fy,O_RDONLY|O_BINARY,S_IREAD))==-1) {
       ErrorProc("Open File Error!");
       freemem(segment);
       return(-1); }
     if((hc=open(fc,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE))==-1) {
       ErrorProc("Creat File Error!");
       close(hY); freemem(segment);
       return(-1); }
     read(hY,&Width,2);
     read(hY,&Height,2);
     step=65536L/Width; step&=0xfff0;
     times=Height/step;
     if(Height%step) times++;
     write(hc,"JPEG C\x0\x0",8);
     write(hc,&Width,sizeof(Width));
     write(hc,&Height,sizeof(Height));
     hcount=0;
     for(i=0;i<times;i++) write(hc,&hcount,2);
     hcount=Height;
     count=0; times=0;
     mputs(25,36,"Compressing Image ",252,255);
     mputs(50,36,name,252,255);
     while(hcount>0) {
       step=(hcount<step)?hcount:step;
       hcount-=step;
       ps=MK_FP(segment,0);
       ps1=MK_FP(segment+4096,0);
       ps2=MK_FP(segment+4096+1024,0);
       for(i=0;i<step;i++) {
	 read(hY,(void *)ps,Width);    ps+=Width;
	 read(hY,(void *)ps1,Width/4); ps1+=(Width/4);
	 read(hY,(void *)ps2,Width/4); ps2+=(Width/4); }
       size=CCompress(segment,Code,Width,step);
       pd=(unsigned char far *)MK_FP(Code,0);
       for(i=0;i<4;i++)  {
	 write(hc,(void *)pd,size); pd+=size; }
       lseek(hc,12+times,SEEK_SET);
       size*=4; count+=size;
       write(hc,&size,2);
       lseek(hc,0,SEEK_END);
       times+=2;
      }
     close(hY);  close(hc);
     remove(fy); freemem(segment);
     Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
    }

/* ��ɫͼ��ѹ���ӳ� */
int  ColorStacker()
  {  int i;
     static char Old[8]="";

     while(1) {
       fseek(ovlp,-12*32,SEEK_END);
       Hide(); mbar(0,DIMY-29,640,DIMY,252);
       title16(2,575,7,2,255); Show();
       if(mscanf(filenamein)==-1)  {
	 Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
	 mputs(25,36,"Return to MainMenu...",252,255); break; }
       if(strrchr(filenamein,'.')==NULL) strcat(filenamein,".*");
       if(findfirst(filenamein,&f_blk,FA_ARCH)!=-1) {
	 fnsplit(filenamein,drive,dir,name,ext);
	 do {
	   Set_Mouse(IDC_WAIT);
	   strcpy(name,f_blk.ff_name);
	   get_base_name(name,name,"");
	   if(strcmp(name,Old)!=NULL) {
	     fnmerge(filenamein,drive,dir,name,"");
	     Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
	     mputs(25,36,"Converting the Image...",252,255);
	     i=ColorChange(filenamein);
	     switch(i) {
	       case  1 : ColorSelect(filenamein,Width,Height,OFF);
			 Image_Viewer(filenamein);
			 Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
			 get_base_name(filenamein,filenamein,"");
			 ColorDct(filenamein);
			 break;
	       case -3 : ErrorProc("UnKnown Image Format!");
			 break;
	       case -2 : ErrorProc("Memory Not Enough!");
			 break;
	       case -1 : ErrorProc("File Open Error!");
			 break;
	      }
	     Set_Mouse(IDC_CURSOR);
	     strcpy(Old,name);
	     bell(800);
	    }
	   Set_Mouse(IDC_CURSOR);
	  } while(findnext(&f_blk)!=-1);
	}
       else {
	 Set_Mouse(IDC_CURSOR);
	 mputs(25,36,filenamein,252,255);
	 mputs(50,36,"File Not Found!",252,251);
	 bell(800); mdelay(20); }
      }
    return 0;
   }

/* ����+ɫ�� ==> R G B ɫ�ռ�ת�� */
int  ColorIChange(char *name)
  {  float temp;
     unsigned long len,count;
     int hR,hG,hB,hY,i,j,step,he;
     unsigned int segment,Seg_R,Seg_G,Seg_B,Seg_Y,Seg_Cr,Seg_Cb;

     strcpy(fy,name); strcpy(fr,name);
     strcpy(fg,name); strcpy(fb,name);
     strcat(fr,".R$$"); strcat(fg,".G$$");
     strcat(fb,".B$$"); strcat(fy,".SWP");
     len=(unsigned long)(64*4+32)*64;
     if((i=allocmem(len,&segment))!=-1) {
       ErrorProc("Not Enough Memory!");
       return(-1); }
     Seg_R=segment;     Seg_G=segment+4096;
     Seg_B=Seg_G+4096;  Seg_Y=Seg_B+4096;
     Seg_Cr=Seg_Y+4096; Seg_Cb=Seg_Cr+1024;
     if((hY=open(fy,O_RDONLY|O_BINARY,S_IREAD))==-1) {
       ErrorProc("Open File Error!");
       freemem(segment);
       return(-1); }
     if((hR=open(fr,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE))==-1) {
       ErrorProc("Open File Error!");
       close(hY); freemem(segment);
       return(-1); }
     if((hG=open(fg,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE))==-1) {
       ErrorProc("Open File Error!");
       close(hY); close(hR);
       freemem(segment); return(-1); }
     if((hB=open(fb,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE))==-1) {
       ErrorProc("Open File Error!");
       close(hR); close(hG); close(hY);
       freemem(segment); return(-1); }
     read(hY,&Width,2);
     read(hY,&Height,2);
     step=65536L/Width;
     step&=0xfff0; he=Height;
     while(he>0) {
       step=(he<step)?he:step;
       he-=step;
       pY=MK_FP(Seg_Y,0);
       pCr=MK_FP(Seg_Cr,0);
       pCb=MK_FP(Seg_Cb,0);
       for(i=0;i<step;i++) {
	 read(hY,(void *)pY,Width);    pY+=Width;
	 read(hY,(void *)pCr,Width/4); pCr+=(Width/4);
	 read(hY,(void *)pCb,Width/4); pCb+=(Width/4); }
       pY=MK_FP(Seg_Y,0); pCr=MK_FP(Seg_Cr,0);
       pCb=MK_FP(Seg_Cb,0); pR=MK_FP(Seg_R,0);
       pG=MK_FP(Seg_G,0); pB=MK_FP(Seg_B,0);
       count=(unsigned long)Width*step;
       i=0;
       do {
	 temp=(*pCr-128)*1.6+*pY;
	 *pR=(unsigned char)(temp<0)?0:temp;
	 if(temp>255) *pR=255;
	 temp=(*pCb-128)*2+*pY;
	 *pB=(unsigned char)(temp<0)?0:temp;
	 if(temp>255) *pB=255;
	 temp=((unsigned char)*pY-*pR*0.3-temp*0.1)/0.6;
	 *pG++=(unsigned char)(temp<0)?0:temp;
	 if(temp>255) *(pG-1)=255;
	 pR++; pB++; pY++; count--;
	 if((count%2)==0) {
	   pCr++; pCb++; }
	 if((count%Width)==0) {
	   if((++i)%2) {
	     pCr-=(Width/2); pCb-=(Width/2); }
	  }
	} while(count>0);
       pR=MK_FP(Seg_R,0); pB=MK_FP(Seg_B,0);
       pG=MK_FP(Seg_G,0);
       for(i=0;i<step;i++) {
	 write(hR,(void *)pR,Width); pR+=Width;
	 write(hG,(void *)pG,Width); pG+=Width;
	 write(hB,(void *)pB,Width); pB+=Width;
	}
      }
     close(hR);  close(hG);
     close(hB);  close(hY);
     remove(fy); freemem(segment);
     Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
   }

/* ��ɫͼ����� */
int  ColorIDct(char *name)
  {  int hY,hc,i,j,tw,th,step;
     unsigned long len,count,post;
     unsigned int segment,Code,Seg_Y,Seg_Cr,Seg_Cb,times,size;

     strcpy(fc,name);   strcpy(fy,name);
     strcat(fc,".JPG"); strcat(fy,".SWP");
     len=(unsigned long)(64+32)*64*2;
     if((i=allocmem(len,&segment))!=-1) {
       ErrorProc("Not Enough Memory!");
       return(-1); }
     if((hc=open(fc,O_RDONLY|O_BINARY,S_IREAD))==-1) {
       ErrorProc("Open File Error!");
       freemem(segment);
       return(-1); }
     if((hY=open(fy,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE))==-1) {
       ErrorProc("Open File Error!");
       close(hc); freemem(segment);
       return(-1); }
     read(hc,&fc[0],8);
     if(strcmp(fc,"JPEG C")==NULL) {
       read(hc,&Width,2);
       read(hc,&Height,2);
       step=65536L/Width; step&=0xfff0;
       times=Height/step;
       if((Height%step)!=0) times++;
       post=times*2+12;
       write(hY,&Width,2);
       write(hY,&Height,2);
       for(j=0;j<times;j++) {
	 lseek(hc,12+j*2,SEEK_SET);
	 read(hc,&size,2);
	 lseek(hc,(unsigned long)post,SEEK_SET);
	 Code=segment+size/16+1;
	 pc=MK_FP(segment,0);
	 read(hc,(void *)pc,size);
	 post+=size;
	 len=(unsigned long)CDecompress(Code,segment);
	 bell(800); bell(800);
	 Height=len/0x10000; Width=len&0x0000ffff;
	 Seg_Y=Code; Seg_Cr=Seg_Y+4096; Seg_Cb=Seg_Cr+1024;
	 pY=MK_FP(Seg_Y,0); pCr=MK_FP(Seg_Cr,0);
	 pCb=MK_FP(Seg_Cb,0);
	 for(i=0;i<Height;i++) {
	   write(hY,(void *)pY,Width);    pY+=Width;
	   write(hY,(void *)pCr,Width/4); pCr+=Width/4;
	   write(hY,(void *)pCb,Width/4); pCb+=Width/4;
	  }
	}
      }
     close(hc); close(hY);
     freemem(segment);
     if(strcmp(fc,"JPEG C")!=NULL) {
       Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
       mputs(25,36,name,252,255);
       mputs(40,36,"Not A Chrominance Image Code File!",252,251);
       remove(fy); mdelay(20); return 3; }
     else return 0;
   }

/* ��ɫͼ���ѹ������ */
int  ColorUnStacker()
  {  int i;

     while(1) {
       fseek(ovlp,-12*32,2);
       Hide(); title16(2,575,7,2,255); Show();
       if(mscanf(filenamein)==-1) {
	 Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
	 mputs(25,36,"Return to MainMenu...",252,255); return 0; }
       if(strstr(filenamein,".")==NULL) strcat(filenamein,".JPG");
       if(findfirst(filenamein,&f_blk,FA_ARCH)!=-1) {
	 fnsplit(filenamein,drive,dir,name,ext);
	 do {
	   Set_Mouse(IDC_WAIT);
	   strcpy(name,f_blk.ff_name);
	   fnmerge(filenamein,drive,dir,name,"");
           Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
	   mputs(25,36,"Decompressing Image Code",252,255);
	   mputs(50,36,filenamein,252,255);
           get_base_name(filenamein,filenamein,"");
	   i=ColorIDct(filenamein);
           Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
	   if(i==0) {
	     mputs(25,36,"Converting the Image...",252,255);
	     ColorIChange(filenamein);
	     mputs(25,36,"Creating Color Image...",252,255);
	     ColorSelect(filenamein,Width,Height,ON);
	     bell(800);
             get_base_name(filenamein,filenamein,"");
	     Image_Viewer(filenamein);
	     Set_Mouse(IDC_CURSOR);
	    }
	   Set_Mouse(IDC_CURSOR);
	   Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
	  } while(findnext(&f_blk)!=-1);
	 }
	else {
	  Set_Mouse(IDC_CURSOR);
	  mputs(25,36,filenamein,252,255);
	  mputs(50,36,"File Not Found!",252,251);
	  bell (800); delay(4000); }
      }
    Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
   }

/* JPEG ϵͳ���˵� */
int  mainmenu()
  {  int cn,handle,key=0,use=0;

     color();
     Close_display();
     cn=mainframe();
     select(box_box[0]);
     Open_display();
     if(cn==-1) return -1;
     Set_Mouse(IDC_CURSOR);
     Mouse_ON();
     while(1) {
       while(key!=CRKEY) {
	 if(bioskey(1)!=0) {
	 key=bioskey(0);
	 if((key==UP)||(key==DOWN)||(key==TAB)) {
	   if(key==UP) level=level<=0?6:level-1;
	   if((key==DOWN)||(key==TAB)) level=level>=6?0:level+1;
	   Hide(); bclose(box_box[prev]);
	   select(box_box[level]);
	   mbar(0,DIMY-29,640,DIMY,252);
	   Show();
	  }
	 }
       prev=level;
       use=0;
       for(cn=0;cn<7;cn++)
	 if(Mouse_in_Box(&box_box[cn][0])) use++;
       if(use==0) Set_Mouse(IDC_CURSOR);
	else Set_Mouse(IDC_HAND);
       if(Left_Pressed()) {
	 do {
	   for(cn=0;cn<7;cn++) {
	     switch(BOX[cn]) {
	       case OFF: if(Mouse_in_Box(&box_box[cn][0])) {
			   Set_Mouse(IDC_HAND);
			   Hide(); box_down(box_box[cn]);
			   bclose(box_box[prev]);
			   select(box_box[cn]); Show();
			   BOX[cn]=ON; level=cn;
			   prev=cn; key=CRKEY; }
			 break;
	       case  ON:   if(!Mouse_in_Box(&box_box[cn][0])) {
			   Set_Mouse(IDC_CURSOR);
			   Hide(); box_up(box_box[cn]); Show();
			   BOX[cn]=OFF;
			   key=level==cn?0:key; }
	      }
	     }
	   } while(Left_Pressed());
	  Hide();
	  box_up(box_box[level]);
	  mbar(0,DIMY-29,640,DIMY,252);
	  Show(); BOX[level]=OFF;
	 }
	}
       key=0;
       Set_Mouse(IDC_CURSOR);
       switch(level) {
	 case 0: Image_Stacker();     break;
	 case 1: Image_UnStacker();   break;
	 case 2: ColorStacker();      break;
	 case 3: ColorUnStacker();    break;
	 case 4: Image_Viewer("");    break;
	 case 5: Image_Manger();      break;
	 case 6: Mouse_OFF();
		 fclose(ovlp);
		 freemem(BitMap);
		 return(1);
	}
      }
   }
