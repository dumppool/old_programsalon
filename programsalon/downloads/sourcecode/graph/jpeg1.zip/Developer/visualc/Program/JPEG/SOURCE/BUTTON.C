/* �������ƺ��� */
void select(int b[4])
   { mrectangle(b[0]-5,b[1]-5,b[2]+5,b[3]+5,0);
     mrectangle(b[0]-6,b[1]-6,b[2]+6,b[3]+6,0);
    }

void bclose(int b[4])
   { mrectangle(b[0]-5,b[1]-5,b[2]+5,b[3]+5,255);
     mrectangle(b[0]-6,b[1]-6,b[2]+6,b[3]+6,255);
    }

/* ������ͼ */
void button(int box[4])
   { mbar(box[0],box[1],box[2],box[3],253);
     mline(box[2]+1,box[1]-1,box[2]+1,box[3]+2,254);
     mline(box[0]-1,box[3]+1,box[2]+1,box[3]+2,254);
     mline(box[2]+2,box[1]-2,box[2]+2,box[3]+3,254);
     mline(box[0]-2,box[3]+2,box[2]+2,box[3]+3,254);
     mline(box[2]+3,box[1]-3,box[2]+3,box[3]+4,254);
     mline(box[0]-3,box[3]+3,box[2]+3,box[3]+3,254);
     mrectangle(box[0]-4,box[1]-4,box[2]+4,box[3]+4,0);
    }

/* λͼд�� */
int  draw_bmp256(int idx_num,int x,int y)
   { unsigned char huge *dot,far *buf,huge *q;
     unsigned int i,j,loc,block,ww;
     unsigned long a;

     if((idx_num>0)&&(idx_num<9)) {
       dot=MK_FP(BitMap,11878+(idx_num-1)*1418+1078);
       bmpinfo.Width=17;
       bmpinfo.Heigth=17;
      }
      else if(idx_num==0) {
       dot=MK_FP(BitMap,0+1078);
       bmpinfo.Width=360;
       bmpinfo.Heigth=30;
      }
      else {
       dot=MK_FP(BitMap,11878+8*1418+1078);
       bmpinfo.Width=32;
       bmpinfo.Heigth=32;
      }
     ww=bmpinfo.Width;
     if((bmpinfo.Width%4)!=0) bmpinfo.Width+=4-(bmpinfo.Width%4);
     a=(unsigned long)y*DIMX+x;
     block=(unsigned long)a>>16;
     buf=MK_FP(0xA000,(unsigned int)(a&0xffff));
     a&=0xffff;
     outportb(0x3c4,0x0e);
     outportb(0x3c5,block^2);
     for(i=0;i<bmpinfo.Heigth;i++) {
       q=dot+(long)bmpinfo.Width*(long)(bmpinfo.Heigth-1-i);
       a+=DIMX;
       if(a<65536L) {
	 memcpy(buf,q,ww);
	 buf+=DIMX; q+=bmpinfo.Width; }
	else {
	  a-=65536L;
	  loc=min(DIMX-a,ww);
	  memcpy(buf,q,loc);
	  q+=loc; block++;
	  buf=MK_FP(0xA000,0);
	  outportb(0x3c4,0x0e);
	  outportb(0x3c5,block^2);
	  loc=ww-loc;
	  if(loc>0) memcpy(buf,q,loc);
	  buf=MK_FP(0xA000,a);
	  q+=bmpinfo.Width;
	 }
	}
    }

/* ��ϵͳ���� */
int  systemtitle()
   { int file;
     unsigned int seg;
     char far * pointer;
     unsigned long size;
     char fname[MAXPATH],*filep;

     seg=getpsp();
     filep=Search(seg);
     strcpy(fname,filep);
     fnsplit(fname,drive,dir,name,ext);
     fnmerge(fname,drive,dir,"JPEG",".OV2");
     if((file=open(fname,O_RDWR|O_BINARY,S_IREAD))==-1) return -1;
     lseek(file,0,SEEK_END);
     size=tell(file);
     lseek(file,0,SEEK_SET);
     if(allocmem((long)size/16+1,&BitMap)!=-1) {
       close(file); return -2; }
     pointer=MK_FP(BitMap,0);
     read(file,(void *)pointer,size);
     close(file);
     draw_bmp256(0,200,5);
     return 1;
    }

void FormatHelp()
  {  fseek(ovlp,284*72,SEEK_SET);
     Hide();
     mbar(220,140,779,558,253);
     mcrectangle(228,144,771,554,254,255);
     mcrectangle(229,145,770,553,254,255);
     title(250,155,18,3,249);
     title(250,181,18,3,249);
     title(250,207,5,3,249);
     title(277,240,16,5,249);
     title(250,268,18,5,249);
     title(277,301,15,5,249);
     title(250,330,17,5,249);
     title(250,358,9,5,249);
     fseek(ovlp,2*72,SEEK_CUR);
     title(250,388,12,5,249);
     title(277,418,8,5,249);
     title(250,458,17,5,249);
     title(250,488,10,5,249);
     Show();
    }

/* �Ӳ˵������� */
int  format()
  {  int i;

     Hide(); mbar(200,48,799,90,253);
     mcrectangle(205,51,794,87,0,255);
     fseek(ovlp,38*72,SEEK_SET);
     title(360,57,7,16,252);
     for(i=0;i<4;i++) button(SUB_box[i]);
     title(SUB_box[0][0]+6,SUB_box[0][1]+5,4,9,247);
     title(SUB_box[1][0]+6,SUB_box[1][1]+5,4,9,247);
     title(SUB_box[2][0]+6,SUB_box[2][1]+5,4,9,247);
     title(SUB_box[3][0]+20,SUB_box[3][1]+5,2,45,247);
     Show();
    }

/* ���˵����� */
int  mainframe()
  {  int i;
     unsigned int seg;
     char fname[MAXPATH],*filep;

     mbar(0,0,800,39,253);
     mcrectangle(5,3,794,36,254,255);
     mbar(0,48,190,562,255);
     mbar(200,48,799,562,255);
     mbar(0,570,799,599,252);
     seg=getpsp();
     filep=Search(seg);
     strcpy(fname,filep);
     fnsplit(fname,drive,dir,name,ext);
     fnmerge(fname,drive,dir,"JPEG",".OV1");
     if((ovlp=fopen(fname,"rb"))==NULL) return(-1);
     i=systemtitle();
     if(i!=1)  return i;
     for(i=0;i<4;i++) {
       button(box_box[i]);
       title(box_box[i][0]+1,box_box[i][1]+10,6,1,247);
      }
     for(;i<7;i++) {
       button(box_box[i]);
       title(box_box[i][0]+13,box_box[i][1]+10,4,10,247);
      }
    fseek(ovlp,68*72,SEEK_SET);
    mbar(220,52,779,558,253);
    mcrectangle(228,56,771,554,254,255);
    mcrectangle(229,57,770,553,254,255);
    title(380,68,6,20,249);
    fseek(ovlp,2*72,1);
    title(298,108,16,5,249);
    title(240,137,18,5,249);
    title(240,166,14,5,249);
    fseek(ovlp,2*72,1);
    title(298,195,16,5,249);
    title(240,224,12,5,249);
    fseek(ovlp,2*72,1);
    title(240,258,17,5,249);
    fseek(ovlp,2*72,1);
    title(298,287,15,5,249);
    title(240,316,18,5,249);
    fseek(ovlp,2*72,1);
    title(298,345,15,5,249);
    title(240,374,18,5,249);
    title(240,403,3,5,249);
    fseek(ovlp,2*72,1);
    title(228,432,19,5,249);
    fseek(ovlp,7*72,1);
    title(478,480,3,10,249);
    title(580,480,2,10,249);
    title(660,480,3,10,249);
    fseek(ovlp,-15*72,1);
    title(518,514,7,6,249);
   }

/* �������� */
int  box_down(int b[4])
  {  mline(b[0]-2,b[3]+2,b[2]+2,b[3]+2,253);
     mline(b[2]+2,b[1]-2,b[2]+2,b[3]+4,253);
     mline(b[0]-2,b[1]-2,b[0]-2,b[3]+4,254);
     mline(b[0]-2,b[1]-2,b[2]+4,b[1]-2,254);
     mline(b[0]-1,b[3]+1,b[2]+1,b[3]+1,253);
     mline(b[2]+1,b[1]-1,b[2]+1,b[3]+4,253);
     mline(b[0]-1,b[1]-1,b[0]-1,b[3]+4,254);
     mline(b[0]-1,b[1]-1,b[2]+4,b[1]-1,254);
     mrectangle(b[0]-3,b[1]-3,b[2]+3,b[3]+3,0);
    }

/* �������� */
int  box_up(int b[4])
  {  mline(b[0]-3,b[1]-3,b[0]-3,b[3]+3,255);
     mline(b[0]-3,b[1]-3,b[2]+3,b[1]-3,255);
     mline(b[0]-3,b[3]+3,b[2]+3,b[3]+3,254);
     mline(b[2]+3,b[1]-3,b[2]+3,b[3]+4,254);
     mline(b[0]-2,b[1]-2,b[0]-2,b[3]+2,255);
     mline(b[0]-2,b[1]-2,b[2]+2,b[1]-2,255);
     mline(b[0]-2,b[3]+2,b[2]+2,b[3]+2,254);
     mline(b[2]+2,b[1]-2,b[2]+2,b[3]+4,254);
     mline(b[0]-1,b[1]-1,b[0]-1,b[3]+1,255);
     mline(b[0]-1,b[1]-1,b[2]+1,b[1]-1,255);
     mline(b[0]-1,b[3]+1,b[2]+1,b[3]+1,254);
     mline(b[2]+1,b[1]-1,b[2]+1,b[3]+4,254);
    }