/* ��ʱ */
void mdelay(unsigned int delta)
   { unsigned int time;

     time=peek(0x40,0x6c);
     while((peek(0x40,0x6c)-time)<=delta);
    }

/* ���� */
void bell(int f)
   { sound(f);
     mdelay(1);
     nosound();
    }

void FailSnd()
   { int i;

     for(i=800;i>795;i--)  {
       sound(i); delay(150); }
     nosound();
    }

/* ������ʾ */
void ErrorProc(char *ErrorMsg)
   { bell(800);
     Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
     mputs(25,36,ErrorMsg,252,251);
     mdelay(36);
     Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
    }

/* �ӹܼ����ж� */
void interrupt int_9()
   { unsigned char byte,key;

     key=inportb(0x60);
     if(key==46||key==224) {
       if((peekb(0x40,0x17)&4)||(peekb(0x40,0x96)&4)) {
	 byte=peekb(0x40,0x17);
	 pokeb(0x40,0x17,byte&0xfb);
	 byte=peekb(0x40,0x96);
	 pokeb(0x40,0x96,byte&0xfb);
	 key=inportb(0x61);
	 key|=0x80; outportb(0x61,key);
	 key&=0x7f; outportb(0x61,key);
	 outportb(0x20,0x20);
	}
       else (*old_int_9)();
      }
     else (*old_int_9)();
    }

/* ��ȡ�����ַ��� */
int  mscanf(char *cmd)
  {  int c,count;

     count=2; cur=16; s=cmd;
     Hide(); mline(8*cur+5,579,8*cur+2,592,255); Show();
     while(1) {
       while(bioskey(1)==0) {
	 if(Right_Pressed()) {
	   while(Right_Pressed());
	   return -1; }
	}
       if(count<=1) count=2;
       if(cur<16) cur=16;
       c=bioskey(0);
       if((c>>8)==0) c=0xffff;
	else c&=0xff;
       if((c==0x0c)||(c==0x0d)) { *s='\0'; return 1; }
       if(c==0x1b) return -1;
       if((!isalnum(c))&&(c!=8)&&(c!='.')&&(c!='\\')&&(c!=':')
	&&(c!='_')&&(c!='*')&&(c!='?')) bell(300);
	else {
	  if(c==8) {
	    if(count>=2) {
	      in.h.dl=--cur; in.x.cx=2;
	      c=0x20; count--; s--;
	     }
	    }
	   else {
	     if(count<=30) {
	       in.h.dl=cur++; in.x.cx=1;
	       *s++=c; count++; }
	      else bell(300);
	    }
	   if((count>=2)&&(count<=30)) {
	     Hide();
	     in.h.ah=2;    in.h.bh=0;
	     in.h.dh=36;
	     int86(0x10,&in,&out);
	     in.h.ah=0x09; in.h.al=c;
	     in.h.bl=255;  in.h.bh=252;
	     int86(0x10,&in,&out);
	     mline(8*cur+5,579,8*cur+2,592,255);
	     Show();
	    }
	   }
      }
    }

/* �ļ���չ���滻 */
int  get_base_name(char *file_in,char *file_out,char *ext)
   { int i=0;

     strcpy(file_out,file_in);
     if(strrchr(file_out,'.')==NULL) strcat(file_out,ext);
      else {
	while(*(file_out+i)!='.') i++;
	file_out[i]='\x0';
	strcat(file_out,ext); }
     }

/* EMS ���� */
int  EmmClose(unsigned int handle)
  {  in.h.ah=0x45;
     in.x.dx=handle;
     int86(EMM,&in,&in);
     return(in.h.ah==0);
    }

int  EmmVer()
  {  in.h.ah=0x46;
     int86(EMM,&in,&in);
     return(in.h.al);
    }

int  EmmNum(int *total,int *NotUse)
  {  in.h.ah=0x42;
     int86(EMM,&in,&in);
     if(in.h.ah==0) {
       *total=in.x.dx;
       *NotUse=in.x.bx;
      }
    }

int  EmmGet(int page,char far *str,int offset,int len)
  {  char far *ptr;

     ptr=EMMbase+page*0x4000+offset;
     memcpy(str,ptr,len);
    }

int  EmmMove(int page,unsigned int file)
  {  char far *ptr;

     ptr=EMMbase+page*0x4000;
     read(file,(void *)ptr,Block);
    }

int  EmmMap(int page,int phys,unsigned int handle)
  {  in.h.ah=0x44;
     in.h.al=page;
     in.x.bx=phys;
     in.x.dx=handle;
     int86(EMM,&in,&in);
     return(in.h.ah==0);
    }

int  EmmAlloc(int n)
  {  in.h.ah=0x43;
     in.x.bx=n;
     int86(EMM,&in,&in);
     if(in.h.ah!=0) return(0xffff);
      else return(in.x.dx);
    }

int  EmmOk()
  {  in.h.ah=0x40;
     int86(EMM,&in,&in);
     if(in.h.ah!=0) return(FALSE);
     in.h.ah=0x41;
     int86(EMM,&in,&in);
     if(in.h.ah!=0) return(FALSE);
     EMMbase=MK_FP(in.x.bx,0);
     return(TRUE);
    }

int  EmmTest()				/* EMS ������� */
  {  int result;
     unsigned int handle;

     in.x.ax=0x3d00;
     in.x.dx=(int)"EMMXXXX0";
     sreg.ds=_DS;
     intdosx(&in,&in,&sreg);
     handle=in.x.ax;
     result=(in.x.cflag==0);
     if(result){
       in.h.ah=0x3e;
       in.x.bx=handle;
       intdos(&in,&in);
      }
     return(result);
   }

/* ���ɫͼ����ɫѡ�� */
/* ���ɫ ==> COLOR_NUM ����ɫ */
int  ColorSelect(char *filename,int Width,int Height,char flags)
  {  struct ffblk file;
     register int i,j,k;
     int f1,f2,f3,f4,f5,pos,l;
     unsigned long imagesize;
     unsigned char far * pal,far * keep;
     char drive[3],dir[MAXDIR],name[9],ext[4],my[80];
     unsigned char far *p1,far *p2,far *p3,far *p4;
     unsigned int EMMhandle,offset,sgm,ex1,ex2,ex3,p,num,seg,seg1,posy;

     strcpy(my,filename);
     if(strstr(my,".")==NULL) strcat(my,".*");
     if(!findfirst(my,&file,0x20)) {
       fnsplit(file.ff_name,drive,dir,name,ext);
       fnmerge(my,drive,dir,name,"");
       strcpy(fr,my); strcat(fr,".R$$");
       strcpy(fg,my); strcat(fg,".G$$");
       strcpy(fb,my); strcat(fb,".B$$");
       strcpy(fout,my); strcat(fout,".IMG");
       strcpy(fpal,my); strcat(fpal,".PAL");
       l=20;
       if(flags==OFF) {
	 p=strlen(fr)-2; l=10;
	 fr[p]='\x0'; fg[p]='\x0'; fb[p]='\x0'; }
      }
     else {
       ErrorProc("File Not Found!");
       return -1; }
     f1=open(fr,O_RDONLY|O_BINARY,S_IREAD);
     f2=open(fg,O_RDONLY|O_BINARY,S_IREAD);
     f3=open(fb,O_RDONLY|O_BINARY,S_IREAD);
     f4=open(fout,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE);
     f5=open(fpal,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE);
     if((f1==-1)||(f2==-1)||(f3==-1)||(f4==-1)||(f5==-1)) {
	ErrorProc("File Open ERROR!");
	return -1; }
     if(flags==OFF) {
       lseek(f1,12,SEEK_SET);
       lseek(f2,12,SEEK_SET);
       lseek(f3,12,SEEK_SET); }
     write(f4,"JPEG R\x0\x0",8);
     write(f4,&Width,2);
     write(f4,&Height,2);
     COLOR_CUT=8;
     PAGE_LINE=16384/Width;
     Block=Width*PAGE_LINE;
     imagesize=(unsigned long)Width*Height;
     PAGE_NUM=((imagesize%Block)!=0)?(imagesize/16384+1):(imagesize/16384);
     if(!EmmTest()||!EmmOk()) {
	ErrorProc("Expanded Memory is NOT available!");
	close(f1); close(f2); close(f3);
	close(f4); close(f5); return -1; }
     if((EMMhandle=EmmAlloc(PAGE_NUM*3))==0xffff) {
       ErrorProc("Expanded Memory Allocation Error!");
       close(f1); close(f2); close(f3);
       close(f4); close(f5); return -1; }
     if(allocmem(64*(64+16),&seg)!=-1) {
       ErrorProc("Not Enough Memory!");
       close(f1); close(f2); close(f3);
       close(f4); close(f5); return -1; }
     coll[0]=MK_FP(seg,0);
     coll[1]=MK_FP(seg+1924,0);
     coll[2]=MK_FP(seg+1024*2,0);
     for(k=0;k<PAGE_NUM;k++) {
       EmmMap(0,k,EMMhandle);	          EmmMove(0,f1);
       EmmMap(0,k+PAGE_NUM,EMMhandle);	  EmmMove(0,f2);
       EmmMap(0,k+PAGE_NUM*2,EMMhandle);  EmmMove(0,f3); }
     close(f2); close(f3); close(f1);
     seg1=seg+4096;
     for(i=0;i<LM;i++)
       for(j=0;j<LM;j++) {
	 buf[i][j]=(unsigned char far *)MK_FP(seg1,0);
	 for(k=0;k<LM/2;k++) buf[i][j][k]=0;
	 seg1+=1; }
     seg1=seg+3072;
     p1=(unsigned char far *)MK_FP(seg1,0);
     p2=(unsigned char far *)MK_FP(seg1,Width);
     p3=(unsigned char far *)MK_FP(seg1,Width*2);
     p4=(unsigned char far *)MK_FP(seg1,Width*3);
     pal=(unsigned char far *)MK_FP(seg1,Width*4);
     memset(pal,0,768);
     keep=pal; pal+=DAC_BEGIN*3;
     Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
     mputs(25,36,"Creating Palettes...",252,255);
     pos=50; Hide();
     posy=390+Height/PAGE_LINE*8+16;
     if((Height%PAGE_LINE)!=0) posy+=8;
     mrectangle(394,573,posy,594,255);
     Show();
     for(j=0;j<Height;j++) {
       p=j%PAGE_LINE;
       if(!p) {
	 mputs(pos++,36,"�",252,246);
	 i=j/PAGE_LINE;
	 EmmMap(0,i,EMMhandle);
	 EmmMap(1,i+PAGE_NUM,EMMhandle);
	 EmmMap(2,i+PAGE_NUM*2,EMMhandle); }
       offset=(unsigned int)p*Width;
       EmmGet(0,p1,offset,Width);
       EmmGet(1,p2,offset,Width);
       EmmGet(2,p3,offset,Width);
       for(k=0;k<Width;k++) {
	 p1[k]>>=3; p2[k]>>=3; p3[k]>>=4;
	 if(buf[p1[k]][p2[k]][p3[k]]<=COLOR_CUT) buf[p1[k]][p2[k]][p3[k]]++;
	}
     }
    num=DAC_BEGIN;
    for(i=0;i<LM;i++)
      for(j=0;j<LM;j++)
	for(k=0;k<LM/2;k++)
	  if(buf[i][j][k]>COLOR_CUT) {
	    coll[0][num]=i;
	    coll[1][num]=j;
	    coll[2][num]=k;
	    num++; }
    sgm=0;
    while(num>COLOR_NUM) {
      sgm++;
      for(i=DAC_BEGIN;i<num-1;i++) {
	ex2=256;
	if(num<COLOR_NUM) break;
	for(k=i+1;k<i+l;k++) {
	  if(k>num-1) break;
	  ex1=abs(coll[0][i]-coll[0][k])+abs(coll[1][i]-coll[1][k])+abs(coll[2][i]-coll[2][k]);
	  if(ex1<ex2) { ex2=ex1; j=k; }
	 }
	if(ex2<=sgm) {
	  for(;j<num-1;j++)
	    for(k=0;k<3;k++) coll[k][j]=coll[k][j+1];
	  num--; }
       }
     }
    for(k=DAC_BEGIN;k<COLOR_NUM;k++) {
      *pal++=coll[0][k]<<1;
      *pal++=coll[1][k]<<1;
      *pal++=coll[2][k]<<2; }
    write(f5,(void *)keep,768);
    close(f5); pos=50;
    Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
    mputs(25,36,"Selecting Colors...",252,255);
    Hide();
    mrectangle(394,573,posy,594,255);
    Show();
    for(i=0;i<Height;i++) {
      p=i%PAGE_LINE;
      if(!p) {
	j=i/PAGE_LINE;
	mputs(pos++,36,"�",252,246);
	EmmMap(0,j,EMMhandle);
	EmmMap(1,j+PAGE_NUM,EMMhandle);
	EmmMap(2,j+PAGE_NUM*2,EMMhandle); }
      offset=(unsigned int)p*Width;
      EmmGet(0,p1,offset,Width);
      EmmGet(1,p2,offset,Width);
      EmmGet(2,p3,offset,Width);
      for(k=0;k<Width;k++) {
	p1[k]>>=3; p2[k]>>=3; p3[k]>>=4; }
	for(j=0;j<Width;j++) {
	ex1=256;
	for(k=DAC_BEGIN;k<COLOR_NUM;k++) {
	  ex2=abs(p1[j]-coll[0][k])+
	      abs(p2[j]-coll[1][k])+abs(p3[j]-coll[2][k]);
	  if(ex2<ex1) {
	    p4[j]=k; ex1=ex2;
	    if(ex1<4) break; }
	   }
	 }
	write(f4,(void *)p4,Width);
       }
      close(f4); freemem(seg);
      if(flags==ON) {
	remove(fr); remove(fg); remove(fb); }
      EmmClose(EMMhandle);
    }

/* BMP �ļ�  ==> R G B ���ɫͼ�� */
int  Change(int fin,int ftr,int ftg,int ftb)
  {  unsigned int 	seg;
     BITCOLOR       	color[256];
     int      		i,j,k=1,ww,hh;
     unsigned char	far *soc,far *dest,ct[256];

     read(fin,&bmphead,sizeof(bmphead));
     read(fin,&bmpinfo,sizeof(bmpinfo));
     read(fin,&color,sizeof(color));
     if(bmphead.Type!=0x4d42) return -1;
     if(bmpinfo.Compression!=0) return 2;
     if((bmpinfo.Width%4)!=0) ww=bmpinfo.Width+4-(bmpinfo.Width%4);
       else ww=bmpinfo.Width;
     hh=bmpinfo.Heigth;
     for(i=0;i<bmpinfo.Bitcount;i++) k*=2;
     if(k!=256) return 3;
     if(allocmem((unsigned long)ww/8+2,&seg)!=-1) return 4;
     soc=(unsigned char far *)MK_FP(seg,0);
     dest=(unsigned char far *)MK_FP(seg,ww+1);
     lseek(fin,-ww,SEEK_END);
     if((ftg==-1)||(ftb==-1)) {
       for(i=0;i<k;i++)
	 ct[i]=(unsigned char)(0.59*(float)color[i].R
	  +0.3*(float)color[i].G+0.11*(float)color[i].B);
       write(ftr,"JPEG R\x0\x0",8);
       write(ftr,&ww,2);
       write(ftr,&hh,2);
       read(fin,(void *)soc,ww);
       for(i=0;i<ww;i++) dest[i]=ct[soc[i]];
       write(ftr,(void *)dest,ww);
       for(i=1;i<ww;i++) {
	 lseek(fin,(long)-2*ww,SEEK_CUR);
	 read(fin,(void *)soc,ww);
	 for(j=0;j<ww;j++) dest[j]=ct[soc[j]];
	 write(ftr,(void *)dest,ww);
	}
      }
     else {
       write(ftr,"JPEG R\x0\x0",8);
       write(ftr,&ww,2); write(ftr,&hh,2);
       write(ftg,"JPEG R\x0\x0",8);
       write(ftg,&ww,2); write(ftg,&hh,2);
       write(ftb,"JPEG R\x0\x0",8);
       write(ftb,&ww,2); write(ftb,&hh,2);
       read(fin,(void *)soc,ww);
       for(i=0;i<ww;i++) dest[i]=color[soc[i]].R;
       write(ftr,(void *)dest,ww);
       for(i=0;i<ww;i++) dest[i]=color[soc[i]].G;
       write(ftg,(void *)dest,ww);
       for(i=0;i<ww;i++) dest[i]=color[soc[i]].B;
       write(ftb,(void *)dest,ww);
       for(i=1;i<hh;i++) {
	 lseek(fin,(long)-2*ww,SEEK_CUR);
	 read(fin,(void *)soc,ww);
	 for(k=0;k<ww;k++) dest[k]=color[soc[k]].R;
	 write(ftr,(void *)dest,ww);
	 for(k=0;k<ww;k++) dest[k]=color[soc[k]].G;
	 write(ftg,(void *)dest,ww);
	 for(k=0;k<ww;k++) dest[k]=color[soc[k]].B;
	 write(ftb,(void *)dest,ww);
	}
      }
     freemem(seg);
     return 1;
   }

/* IMG ��ʽ ==> BMP ��ʽ */
int  Creat(int fp_r,char *tab,int fp_w,int flag)
   { unsigned int seg;
     BITCOLOR bmpcolor[256];
     unsigned char *buf,pal;
     int i,k,width,ftab,height;

     lseek(fp_r,8,SEEK_SET);
     read(fp_r,&width,2);  bmpinfo.Width=width;
     read(fp_r,&height,2); bmpinfo.Heigth=height;
     if((width%4)!=0) width+=4-(width%4);
     bmphead.Type=0x4d42;     bmphead.bfsize=1078;
     bmphead.Reserve1=0;      bmphead.Reserve2=0;
     bmphead.Offset=1078;     bmpinfo.Size=40;
     bmpinfo.Planes=1;        bmpinfo.Bitcount=8;
     bmpinfo.Compression=0;   bmpinfo.SizeImage=0;
     bmpinfo.XpelsPerMeter=0; bmpinfo.YpelsPerMeter=0;
     bmpinfo.ClrUsed=256;     bmpinfo.ClrImportant=0;
     bmpinfo.SizeImage=(unsigned long)bmpinfo.Width*bmpinfo.Heigth;
     bmphead.bfsize+=(unsigned long)bmpinfo.SizeImage;
     if(allocmem(2048/16,&seg)==-1) {
       buf=(unsigned char *)MK_FP(seg,0);
       if((ftab=open(tab,O_RDWR|O_BINARY,S_IREAD))!=-1) {
	 for (i=0;i<256;i++)  {
	   read(ftab,&bmpcolor[i],3);
	   pal=bmpcolor[i].B;
	   bmpcolor[i].B=(unsigned char)(bmpcolor[i].R<<2);
	   bmpcolor[i].G=(unsigned char)(bmpcolor[i].G<<2);
	   bmpcolor[i].R=(unsigned char)(pal<<2);
	   bmpcolor[i].Reserved=0;
	  }
	  close(ftab);
	 }
	 else
	   for(i=0;i<256;i++)  {
	    bmpcolor[i].R=(unsigned char)i;
	    bmpcolor[i].G=(unsigned char)i;
	    bmpcolor[i].B=(unsigned char)i;
	    bmpcolor[i].Reserved=(unsigned char)0;
	   }
       if(flag==OFF)
	 for(i=0;i<256;i++) {
	   bmpcolor[i].R=(unsigned char)(0.59*(float)bmpcolor[i].R
	    +0.3*(float)bmpcolor[i].G+0.11*(float)bmpcolor[i].B);
	   bmpcolor[i].R=bmpcolor[i].R;
	   bmpcolor[i].G=bmpcolor[i].R;
	   bmpcolor[i].B=bmpcolor[i].R; }
       write(fp_w,&bmphead,sizeof(bmphead));
       write(fp_w,&bmpinfo,sizeof(bmpinfo));
       write(fp_w,&bmpcolor,sizeof(bmpcolor));
       lseek(fp_r,(long)-width,SEEK_END);
       read(fp_r,buf,width);
       write(fp_w,buf,bmpinfo.Width);
       for (i=1;i<bmpinfo.Heigth;i++) {
	 lseek(fp_r,(long)-2*width,SEEK_CUR);
	 read(fp_r,buf,width);
	 write(fp_w,buf,bmpinfo.Width);
	}
       freemem(seg);
      }
      else {
       ErrorProc("Not Enough Memory!");
       return -1; }
     return 1;
    }

/* IMG ��ʽ ==> BMP ��ʽ���� */
int  img2bmp(char *fname,int flag)
  {  int br,bw;
     char name[MAXPATH],msg[80];

     strcpy(name,fname);
     strcpy(msg,name);
     if((br=open(name,O_RDWR|O_BINARY,S_IREAD))!=-1) {
       strcat(msg," ==> ");
       get_base_name(name,name,".BMP");
       strcat(msg,name);
       if((bw=open(name,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE))!=-1) {
	 get_base_name(name,name,".PAL");
	 mputs(25,36,msg,252,255);
	 Creat(br,name,bw,flag);
	 strcat(msg," Over!");
	 bell(800);  mputs(25,36,msg,252,255);
	 mdelay(20); close(bw); }
	else ErrorProc("File Can't be Created!");
       close(br);
      }
     else ErrorProc("File Can't be Opened!");
    }

/* BMP ��ʽ ==> IMG ��ʽ���� */
int  bmp2img(char *filename,int flag)
  {  int hr,hw,hR,hG,hB,result;
     struct ffblk file_blk;
     char fname[MAXPATH],ext[5],msg[80];

     strcpy(fname,filename);
     if(strrchr(fname,'.')==NULL) strcat(fname,".BMP");
     if(findfirst(fname,&file_blk,FA_ARCH)==-1) {
       ErrorProc("File Not Found!"); return -1; }
     fnsplit(fname,drive,dir,name,ext);
     do {
       fnmerge(fname,drive,dir,file_blk.ff_name,"");
       if((hr=open(fname,O_RDWR|O_BINARY,S_IREAD))!=-1) {
	 strcpy(msg,fname);
	 switch(flag) {
	   case OFF : get_base_name(fname,fname,".Y");
		      if((hw=open(fname,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,
			S_IREAD|S_IWRITE))!=-1) {
			strcat(msg," ==> ");
			strcat(msg,fname);
			mputs(25,36,msg,252,255);
			result=Change(hr,hw,-1,-1);
			close(hw);
			switch(result) {
			  case 1 : strcat(msg,"  Change Over!");
				   bell(800); mputs(25,36,msg,252,255);
				   mdelay(20); break;
			  case 2 : ErrorProc("Not an UnCompressed BMP File!");
				   remove(fname); break;
			  case 4 : ErrorProc("Not Enougn Memory!");
				   remove(fname); break;
			  case 3 : ErrorProc("Not an 256 Color BMP File!");
				   remove(fname); break;
			 }
			}
		       else ErrorProc("File Can't be Created!");
		       break;
	   case  ON :  get_base_name(fname,fname,".R");
		       hR=open(fname,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,
			S_IREAD|S_IWRITE);
		       get_base_name(fname,fname,".G");
		       hG=open(fname,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,
			S_IREAD|S_IWRITE);
		       get_base_name(fname,fname,".B");
		       hB=open(fname,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,
			S_IREAD|S_IWRITE);
		       if((hR!=-1)&&(hG!=-1)&&(hB!=-1)) {
			 get_base_name(fname,fname," RGB TURE COLOR");
			 strcat(msg," ==> ");
			 strcat(msg,fname);
			 mputs(25,36,msg,252,255);
			 result=Change(hr,hR,hG,hB);
			 close(hR); close(hB); close(hG);
			 if(result!=1) {
			   fname[strlen(fname)-14]='\x2e';
                           get_base_name(fname,fname,".R"); remove(fname);
			   get_base_name(fname,fname,".G"); remove(fname);
			   get_base_name(fname,fname,".B"); remove(fname); }
			 switch(result) {
			  case 1 : strcat(msg,"  Change Over!");
				   bell(800); mputs(25,36,msg,252,255);
				   mdelay(20); break;
			  case 2 : ErrorProc("Not an UnCompressed BMP File!");
				   break;
			  case 4 : ErrorProc("Not Enougn Memory!");
				   break;
			  case 3 : ErrorProc("Not an 256 Color BMP File!");
				   break;
			 }
			}
		       else ErrorProc("File Can't be Created!");
		       break;
	  }
	 close(hr);
	}
      else ErrorProc("File Can't be Opened!");
     } while(findnext(&file_blk)!=-1);
    return 1;
   }

/* PCX ��ʽ ==> IMG ��ʽ */
int  pcx2img(char *fname,int flag)
  {  unsigned char p256;
     unsigned int segm;
     int raw,pcxw,pcxd,result;

     if(allocmem(64,&segm)!=-1) {
       ErrorProc("Alloc Memory Failure!");
       return -1; }
     if((raw=open(fname,O_RDWR|O_BINARY,S_IREAD))!=-1) {
       palette=(unsigned char *)MK_FP(segm,0);
       read(raw,(char *)&pcxhead,sizeof(pcxhead));
       lseek(raw,-769L,SEEK_END);
       read(raw,palette,769);
       p256=*palette;
       if(p256==0x0c) {
	 palette=(unsigned char *)MK_FP(segm,1);
	 pcxw=(pcxhead.xmax-pcxhead.xmin)+1;
	 if(pcxw%4!=0) pcxw+=4-(pcxw%4);
	 pcxd=(pcxhead.ymax-pcxhead.ymin);
	 result=unpackpcxfile(fname,raw,pcxw,pcxd,flag);
         switch(result) {
	   case 2 : ErrorProc("Not Enougn Memory!");
		    break;
	   case 3 : ErrorProc("Error Creatint Object File!");
		    break;
	  }
	 close(raw); }
	else ErrorProc("Error Doing Color Palette!");
      }
     else ErrorProc("Error Opening File!");
    freemem(segm);
   }

/* PCX �ļ� RLL ���� */
int  unpackpcxfile(char *fname,int fp,int pcxw,int pcxd,int flag)
  {  float temp;
     unsigned long len;
     unsigned int seg;
     char name[MAXPATH],msg[80];
     int i,j,m,x,count,hR,hG,hB;
     unsigned char far *buffs,huge *ps,*kr,*kg,*kb,ch;

     lseek(fp,0,SEEK_END);
     len=(unsigned long)tell(fp);
     if(allocmem(pcxw/4+len/16+2,&seg)!=-1) return 2;
     strcpy(msg,fname); strcpy(name,fname);
     strcat(msg," ==> ");
     if(flag==ON) {
       get_base_name(name,name,".R");
       hR=open(name,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE);
       get_base_name(name,name,".G");
       hG=open(name,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE);
       get_base_name(name,name,".B");
       hB=open(name,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE);
       if((hR==-1)||(hG==-1)||(hB==-1)) {
	 freemem(seg); return 3; }
       write(hR,"JPEG R\x0\x0",8);
       write(hR,&pcxw,2); write(hR,&pcxd,2);
       write(hG,"JPEG R\x0\x0",8);
       write(hG,&pcxw,2); write(hG,&pcxd,2);
       write(hB,"JPEG R\x0\x0",8);
       write(hB,&pcxw,2); write(hB,&pcxd,2);
       get_base_name(name,name," RGB TURE COLOR");
      }
      else {
       get_base_name(name,name,".Y");
       hR=open(name,O_CREAT|O_TRUNC|O_RDWR|O_BINARY,S_IREAD|S_IWRITE);
       if(hR==-1) { freemem(seg); return 3; }
       write(hR,"JPEG R\x0\x0",8);
       write(hR,&pcxw,2); write(hR,&pcxd,2);
       get_base_name(name,name,".Y");
      }
     strcat(msg,name);
     mputs(25,36,msg,252,255);
     ps=(unsigned char far *)MK_FP(seg,pcxw*4);
     buffs=(unsigned char far *)ps; len-=0x80L;
     i=len/SIZE; len%=SIZE;
     lseek(fp,0x80L,SEEK_SET);
     for(m=0;m<i;m++) {
       read(fp,(void *)ps,SIZE);
       ps+=SIZE; }
     if(len!=0) read(fp,(void *)ps,(unsigned int)len);
     ps=buffs;
     buffs=(unsigned char *)MK_FP(seg,0);
     kr=(unsigned char *)MK_FP(seg,pcxw);
     kg=(unsigned char *)MK_FP(seg,pcxw*2);
     kb=(unsigned char *)MK_FP(seg,pcxw*3);
     for(j=0;j<=pcxd;j++) {
       i=0;
       while(i<pcxw) {
	 ch=(unsigned char)(*ps++)&0xff;
	 if((ch&0xc0)!=0xc0) buffs[i++]=ch;
	  else {
	   count=ch&0x3f;
	   ch=(unsigned char)(*ps++);
	   for(m=0;m<count;m++)
	   buffs[i++]=ch; }
	 }
	switch(flag) {
	  case  ON : for(x=0;x<pcxw;x++) {
		       i=3*(unsigned char)buffs[x];
		       *(kr+x)=(unsigned char)palette[i];
		       *(kg+x)=(unsigned char)palette[i+1];
		       *(kb+x)=(unsigned char)palette[i+2]; }
		     write(hR,(void *)kr,pcxw);
		     write(hG,(void *)kg,pcxw);
		     write(hB,(void *)kb,pcxw);
		     break;
	  case OFF : for(x=0;x<pcxw;x++) {
		       i=3*(unsigned char)buffs[x];
		       temp=0.59*(unsigned char)palette[i]+
			 0.3*(unsigned char)palette[i+1]+
			 0.11*(unsigned char)palette[i+2];
		       *(kr+x)=(unsigned char)temp; }
		     write(hR,(void *)kr,pcxw);
		     break;
	}
       }
      close(hR); close(hG); close(hB);
      freemem(seg); bell(800);
      strcat(msg," Change Over!");
      mputs(25,36,msg,252,255);
      mdelay(20); return 1;
     }


/* ͼ���ʽȷ�� */
/* ����ֵ����  -1  ==> ���ļ����� 
	          0 ==> IMG ��ʽ
                      1 ==> BMP ��ʽ
	          2 ==> PCX ��ʽ 
	         -2 ==> ��ʽ����ʶ��  */
int  DecideFormat(char *filename)
  {  char size[9];
     int handle,idx_num=-2;

     if((handle=open(filename,O_RDWR|O_BINARY,S_IREAD))==-1) {
       ErrorProc("Open File Error!"); return -1; }
     read(handle,size,8);
     if(strcmp(size,"JPEG R")==NULL) idx_num=0;
     lseek(handle,0,SEEK_SET);
     read(handle,&bmphead,sizeof(bmphead));
     read(handle,&bmpinfo,sizeof(bmpinfo));
     if(bmphead.Type==0x4d42) idx_num=1;
     lseek(handle,0,SEEK_SET);
     read(handle,&pcxhead,sizeof(pcxhead));
     if(pcxhead.manufacturer==0x0a&&pcxhead.version==5) idx_num=2;
     close(handle);
     return (idx_num);
    }

/* ��ʽת������ */
/* FLAG=ON ��ɫת��    =OFF �Ҷ�ת�� */
int  FormatChange(int flag)
  {  int i,idx;
     struct ffblk f_blk;
     char fname[MAXDIR],drive[4],dir[MAXDIR],name[9],ext[5],msg[80];

     fseek(ovlp,-12*32,2);
     Hide(); mbar(0,DIMY-29,640,DIMY,252);
     title16(2,575,7,2,255); Show();
     if(mscanf(fname)==-1) {
     Hide(); mbar(0,DIMY-29,640,DIMY,252);
       Show(); return -1; }
     if(strrchr(fname,'.')==NULL) strcat(fname,".BMP");
     if(findfirst(fname,&f_blk,FA_ARCH)!=-1) {
       fnsplit(fname,drive,dir,name,ext);
       do {
	 Set_Mouse(IDC_WAIT);
	 strcpy(name,f_blk.ff_name);
	 fnmerge(fname,drive,dir,name,"");
	 Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
	 i=DecideFormat(fname);
	 switch(i) {
	   case -1 : ErrorProc("File Open Error!"); break;
	   case -2 : ErrorProc("UnKnown Image Format!"); break;
	   case  0 : img2bmp(fname,flag); break;
	   case  1 : bmp2img(fname,flag); break;
	   case  2 : pcx2img(fname,flag); break;
	  }
	} while(findnext(&f_blk)!=-1);
        Set_Mouse(IDC_CURSOR);
       }
      else {
	bell(800); Hide();
	mbar(0,DIMY-29,640,DIMY,252); Show();
	mputs(25,36,fname,252,255);
	mputs(50,36,"File Not Found",252,251); }
     Hide(); mbar(0,DIMY-29,640,DIMY,252); Show();
    }
