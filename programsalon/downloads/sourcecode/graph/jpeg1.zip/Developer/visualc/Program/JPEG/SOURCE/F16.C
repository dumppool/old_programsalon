#include <stdio.h>
#include <graphics.h>
#include <conio.h>
extern setpixel(int,int,int);

main()
{
FILE	*fp,*ofp,*ifp;
int i,i1,i2,i3,row=0,col=0,trow=0;
int gd=DETECT,gm;
int c,c1,c2,f=0,rr;
char by[32];
long length;
/*registerbgidriver(EGAVGA_driver);*/
initgraph(&gd,&gm,"c:\\tc");
if ((fp=fopen("\\pic\\hzk16","rb"))==NULL)
	{
	closegraph();
	  puts("\7 can't open file1");
	exit(0);
	}
if ((ifp=fopen("hz16.dat","rb"))==NULL)
	{
	closegraph();
	  puts("\7 can't open file2");
	exit(0);
	}
if ((ofp=fopen("hz16.ovl","wb"))==NULL)
	{
	closegraph();
	  puts("\7 can't open file3");
	exit(0);
	}
fseek(ofp,0,SEEK_SET);
c=getc(ifp);
while(c!=EOF)
	{if(c>0xa0)
		if(f==0){f=1;c1=(c-0xa1)&0x07f;	}
		else{f=0;c2=(c-0xa1)&0x7f;
		length=c1*94*32L+c2*32L;c1=24;rr=8;}
	  else goto  next;
	if(f==0)
		{fseek(fp,length,SEEK_SET);
		fread(by,1,32,fp);fwrite(by,1,32,ofp);
		for(i1=0;i1<16;i1++)
			{for(i2=0;i2<2;i2++)
			    for(i3=0;i3<rr;i3++)
			    if(getbit(by[i1*2+i2],7-i3))
			    putpixel(col+i2*8+i3,row,GREEN);row++;
			}
		row=trow;col=col+16;
		if(col>639){col=0;trow+=20;row=trow;}
		if(trow>479) {getch();cleardevice();trow=0;row=trow;col=0;}
		}
	next:c=getc(ifp);
	}
fclose(ofp);getch();closegraph();
}

int getbit(unsigned char c,int n)
{return((c>>n)&1);
}
