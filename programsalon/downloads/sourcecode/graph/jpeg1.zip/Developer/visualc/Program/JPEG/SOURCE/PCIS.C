/* PCIS.C JPEG System Main File 6-13-1995 */
/* Written in TURBO C V2.0 */

#include "public.h"
#include "mouse.c"
#include "button.c"
#include "dialog.c"
#include "graph.c"
#include "menu.c"

int Error_24()
   { int ret=-1;
     char choice;

     switch(_DI&0xff) {
       case 0x00 : mputs(25,36,"Write Pretect Error!",252,251);
		   break;
       case 0x01 : mputs(25,36,"UnKnown Unit!",252,251);
		   break;
       case 0x02 : mputs(25,36,"Driver Not Ready!",252,251);
		   break;
       case 0x03:  mputs(25,36,"UnKnown Command!",252,251);
		   break;
       case 0x04:  mputs(25,36,"CRC Error!",252,251);
		   break;
       case 0x05:  mputs(25,36,"Requist Structure Error!",252,251);
		   break;
       case 0x06:  mputs(25,36,"Seek Error!",252,251);
		   break;
       case 0x07:  mputs(25,36,"UnKnown Media!",252,251);
		   break;
       case 0x08:  mputs(25,36,"Sector Not Found!",252,251);
		   break;
       case 0x09:  mputs(25,36,"No Paper!",252,251);
		   break;
       case 0x0A:  mputs(25,36,"Write Disk Error!",252,251);
		   break;
       case 0x0B:  mputs(25,36,"Read Disk Error!",252,251);
		   break;
       case 0x0C:  mputs(25,36,"General Failure!",252,251);
		   break;
       case 0x0F:  mputs(25,36,"Can't Change Disk!",252,251);
		   break;
      }
     mputs(45,36,"Abort, Ingore, Retry, Fail?",252,251);
     while(ret==-1) {
       FailSnd();
       choice=getch();
       if(choice=='A'||choice=='a') ret=2;
       if(choice=='I'||choice=='i') ret=0;
       if(choice=='R'||choice=='r') ret=1;
       if(choice=='F'||choice=='f') ret=3; }
     Hide(); mbar(0,DIMY-29,DIMX,DIMY,252); Show();
     return ret;
    }

main ()
   { int result;

     switch(ChkTVGA()) {		/* ��ʾ����� */
       case 256:
       case -1 : puts("\7This Program Requires at least 512KB TVGA!");
		 break;
       default : OldMode=peekb(0x40,0x49);
		 set_mode(0x5e);
		 FPU=IDX_87()<=2?0xff:1;		/* 80387 ��� */
		 old_int_9=getvect(0x9);
		 old_int_24=getvect(0x24);
		 setvect(0x9,int_9);
		 setvect(0x24,New_24);
		 result=mainmenu();			/* ���˵����� */
		 set_mode(OldMode);
		 if(result==-1) puts("\7JPEG Overlay File Not Found!");
		  else if(result==-2) puts("\7Memory Not Enough!");
		 setvect(0x9,*old_int_9);
		 setvect(0x24,*old_int_24);
		 break;
      }
    }
