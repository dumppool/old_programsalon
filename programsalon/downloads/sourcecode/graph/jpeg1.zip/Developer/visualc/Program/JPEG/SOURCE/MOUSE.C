/* MOUSE.C Mouse Functions */
/* Written in TURBO C V2.0 1-16-1995 */
/* ��꺯��ʵ�� */
#include	<conio.h>
#include	<time.h>
#include	"mouse.h"

char Reset()					/* ��긴λ */
   { inr.x.ax=0;
     int86(0x33,&inr,&outr);
     if(outr.x.ax==0) { M_FLAG=OFF; return(0); }
      else { M_FLAG=ON; return(1); }
    }

/* ��갴��״̬��ѯ */
char Left_Pressed()
   { if(M_FLAG==ON) {
       inr.x.ax=3;
       int86(0x33,&inr,&outr);
       return(outr.x.bx&1); }
      else return 0;
    }

char Mid_Pressed()
   { if(M_FLAG==ON) {
       inr.x.ax=3;
       int86(0x33,&inr,&outr);
       return(outr.x.bx&4); }
      else return 0;
    }

char Right_Pressed()
   { if(M_FLAG==ON) {
       inr.x.ax=3;
       int86(0x33,&inr,&outr);
       return(outr.x.bx&2); }
      else return 0;
    }

/* ���λ�ò�ѯ */
void Get_XY(int *x,int *y)
   { if(M_FLAG==ON) {
       inr.x.ax=3;
       int86(0x33,&inr,&outr);
       *x=outr.x.cx; *y=outr.x.dx; }
      else { *x=0; *y=0; }
    }

/* �ù��λ�� */
void Set_XY(int x,int y)
   { if(M_FLAG==ON) {
       inr.x.ax=4;
       inr.x.cx=x;
       inr.x.dx=y;
       int86(0x33,&inr,&outr); }
    }

/* ���ù�귶Χ */
void Set_X_Range(int min,int max)
   { if(M_FLAG==ON) {
       inr.x.ax=7;
       inr.x.cx=min;
       inr.x.dx=max;
       int86(0x33,&inr,&outr); }
    }

void Set_Y_Range(int min,int max)
   { if(M_FLAG==ON) {
       inr.x.ax=8;
       inr.x.cx=min;
       inr.x.dx=max;
       int86(0x33,&inr,&outr); }
    }

/* ����ƶ���� */
int  Motion(int *x,int *y)
   { if(M_FLAG==ON) {
       inr.x.ax=11;
       int86(0x33,&inr,&outr);
       *x=outr.x.cx; *y=outr.x.dx;
       return(*x||*y); }
      else return 0;
    }

/* ��׼ģʽ������ͼ�ι����״ */
void Set_Graphic_Cursor(int x,int y,unsigned int *pattern)
   { if(M_FLAG==ON) {
       inr.x.ax=9;
       inr.x.bx=x;
       inr.x.cx=y;
       inr.x.dx=FP_OFF(pattern);
       sireg.es=FP_SEG(pattern);
       int86x(0x33,&inr,&outr,&sireg); }
    }

/* ���λ�ü�� */
int  Mouse_in_Box(int *b)
  {  if(M_FLAG==ON) {
       inr.x.ax=3;
       int86(0x33,&inr,&outr);
       return((outr.x.cx>=b[0])&&(outr.x.cx<=b[2])&&
	 (outr.x.dx>=b[1])&&(outr.x.dx<=b[3]))?1:0; }
      else return 0;
    }

/* ��չģʽ��ͼ�ι����ͼ */
int  Draw_Cursor(int x,int y)
   { unsigned long a;
     char i,j;
     unsigned int loc,block;
     unsigned char huge *dot,far *buf,huge *q;

     switch(CURSOR) {							/* ���λͼ���� */
       case IDC_WAIT   : dot=MK_FP(BitMap,11878+8*1418+1078);	
			 break;						/* ��ʱɳ© */
       case IDC_CURSOR : dot=MK_FP(BitMap,11878+8*1418+2102+1078);
			 break;						/* ��׼��ͷ */
       case IDC_HAND   : dot=MK_FP(BitMap,11878+8*1418+2102*2+1078);
			 break;						/* ���� */
      }
     a=(unsigned long)y*DIMX+x;						/* ֱ��д�� */
     block=(unsigned long)a>>16;
     a&=0xffff;
     buf=MK_FP(0xA000,(unsigned int)a);
     outportb(0x3c4,0x0e);
     outportb(0x3c5,block^2);
     for(i=0;i<CUR_DIM;i++) {
       q=dot+(unsigned long)CUR_DIM*(CUR_DIM-1-i);
       a+=DIMX;
       if(a<65536L) {
	 for(j=0;j<CUR_DIM;j++)
	   if((unsigned char)*(q+j)!=0xf9)
	     *(buf+j)=*(q+j);
	 buf+=DIMX; q+=CUR_DIM; }
	else {
	  a-=65536L;
	  loc=min(DIMX-a,CUR_DIM);
	  for(j=0;j<loc;j++)
	    if((unsigned char)*(q+j)!=0xf9) *(buf+j)=*(q+j);
	  q+=loc; block++;
	  buf=MK_FP(0xA000,0);
	  outportb(0x3c4,0x0e);
	  outportb(0x3c5,block^2);
	  loc=CUR_DIM-loc;
	  for(j=0;j<loc;j++)
	    if((unsigned char)*(q+j)!=0xf9) *(buf+j)=*(q+j);
	  buf=MK_FP(0xA000,a);
	  q+=CUR_DIM;
	 }
	}
    }

void move_mouse_cursor()				/* �ƶ���� */
   { if(CursorStatus==ON) {
       mputimage(X,Y,X+32,Y+32,undercur);
       Get_XY(&X,&Y);
       mgetimage(X,Y,X+32,Y+32,undercur);
       Draw_Cursor(X,Y);
      }
    }

void interrupt far mouse_int()				/* ����жϺ��� */
   { old_int();
     ireg.x.ax=11;
     int86(0x33,&ireg,&oreg);
     if((ireg.x.cx!=0)||(oreg.x.dx!=0)) move_mouse_cursor();
      else if(CKeep==ON) move_mouse_cursor();
     CKeep=OFF;
    }

void Show()						/* ��ʾ��� */
   { if(M_FLAG==ON) {
       mgetimage(X,Y,X+32,Y+32,undercur);
       Set_X_Range(0,783);
       Set_Y_Range(0,583);
       Draw_Cursor(X,Y);
       setvect(0x1c,mouse_int); }
    }

void Hide()						/* ���ع�� */
   { if(M_FLAG==ON) {
       setvect(0x1c,old_int);
       Set_X_Range(0,783);
       Set_Y_Range(0,583);
       mputimage(X,Y,X+32,Y+32,undercur); }
    }

void Mouse_ON()					/* �򿪹�� */
   { Reset();
     if(M_FLAG==ON) {
       if(allocmem(80,&MouseKeep)!=-1) M_FLAG=OFF;
       undercur=(char *)MK_FP(MouseKeep,0);
       if((CursorStatus==OFF)&&(M_FLAG==ON)) {
	 old_int=getvect(0x1c);
	 Set_X_Range(0,783);
	 Set_Y_Range(0,583);
	 Set_XY(0,0);
	 Get_XY(&X,&Y);
	 mgetimage(X,Y,X+32,X+32,undercur);
	 Draw_Cursor(X,Y);
	 CursorStatus=ON;
	 setvect(0x1c,mouse_int);
	}
       enable();
      }
    }

void Mouse_OFF()				/* �رչ�� */
   { if((CursorStatus==ON)&&(M_FLAG==ON)) {
       CursorStatus=OFF;
       setvect(0x1c,old_int);
       mputimage(X,Y,X+32,Y+32,undercur); }
     freemem(MouseKeep); M_FLAG=OFF;
    }

void Set_Mouse(int IDC)
   { if(CURSOR!=IDC) CKeep=ON;
     CURSOR=IDC;
    }