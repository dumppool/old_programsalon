#ifndef _RBDCIRCLE_H
#define _RBDCIRCLE_H

// **********************************************
// Class: RBD_ROUND
// Function: Display a rubberbanding
// **********************************************

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

class RBD_CIRCLE : public RBD_DRIVER {
protected:
	CPoint m_nStart;

public:
	RBD_CIRCLE(const CPoint& start);
	virtual ~RBD_CIRCLE();

	virtual void DrawXor(CDC *pDC, const PICK_EVENT& pe);
};

#endif
