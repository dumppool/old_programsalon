#include "stdafx.h"
#include "pickevent.h"

IMPLEMENT_DYNAMIC(MOUSE_TOOL, CObject)

int MOUSE_TOOL::ProcessEvent(int evType, const PICK_EVENT& pe)
{
	switch( evType ) {
	case WM_MOUSEMOVE:
		if( RBD_DRIVER::CurrentRBD )
			RBD_DRIVER::CurrentRBD->Update(pe);
		break;
	}
	m_nLP = pe;
	return 0;
}

