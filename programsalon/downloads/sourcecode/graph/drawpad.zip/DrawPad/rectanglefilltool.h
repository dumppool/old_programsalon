#ifndef _RECTANGLEFILLTOOL_H
#define _RECTANGLEFILLTOOL_H

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

// ********************************************
// Class name: LINE_TOOL
// Function:   tool to process mouse events
// ********************************************

class RBD_RECTANGLEFILL;

class RECTANGLEFILL_TOOL : public MOUSE_TOOL {
protected:
	CPoint m_nStart;
	CPoint m_nEnd;
	CView *m_pView;
	RBD_RECTANGLEFILL *m_pRbdLine;

public:
	RECTANGLEFILL_TOOL();
	virtual ~RECTANGLEFILL_TOOL();

	virtual int ProcessEvent(int evType, const PICK_EVENT& pe);

private:
	void CreateRECTANGLEFILL();
};

#endif
