#include "stdafx.h"
#include "DrawPadDoc.h"

#include "rbdrectanglefill.h"
#include "rectanglefilltool.h"
#include "erectanglefill.h"

RECTANGLEFILL_TOOL::RECTANGLEFILL_TOOL()
{
	m_pRbdLine = NULL;
	m_pView = NULL;
}

RECTANGLEFILL_TOOL::~RECTANGLEFILL_TOOL()
{
	if( m_pRbdLine ) delete m_pRbdLine;
}

int RECTANGLEFILL_TOOL::ProcessEvent(int evType, const PICK_EVENT& pe)
{
	switch( evType ) {
	case WM_LBUTTONDOWN:
		m_nStart = pe.pick();
		m_pView = pe.view();
		if( m_pRbdLine ) delete m_pRbdLine;
		m_pRbdLine = new RBD_RECTANGLEFILL(m_nStart);
		m_pRbdLine->Start(pe);
		evType = 0;
		break;
	case WM_LBUTTONUP:
		delete m_pRbdLine;
		m_pRbdLine = NULL;
		m_nEnd = pe.pick();
		CreateRECTANGLEFILL();
		evType = 0;
		break;
	}
	return MOUSE_TOOL::ProcessEvent(evType, pe);
}

void RECTANGLEFILL_TOOL::CreateRECTANGLEFILL()
{
	ASSERT_VALID(m_pView);
	CDrawPadDoc *pDoc = (CDrawPadDoc *)m_pView->GetDocument();
	ASSERT_VALID(pDoc);
	if( m_nStart != m_nEnd )
	{
		UNDO_BEGIN
		pDoc->AddEntity(new ERECTANGLEFILL(m_nStart, m_nEnd,pDoc->m_nColor,pDoc->m_brush));
		UNDO_END
	}
}

