#ifndef _RBDELLIPSE_H
#define _RBDELLIPSE_H
// Class: RBD_LINE
// Function: Display a rubberbanding
// **********************************************

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

class RBD_ELLIPSE : public RBD_DRIVER {
protected:
	CPoint m_nStart;

public:
	RBD_ELLIPSE(const CPoint& start);
	virtual ~RBD_ELLIPSE();

	virtual void DrawXor(CDC *pDC, const PICK_EVENT& pe);
};

#endif
