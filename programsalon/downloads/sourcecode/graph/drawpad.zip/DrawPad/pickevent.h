#ifndef _PICKEVENT_H
#define _PICKEVENT_H

// ********************************************
// Base classes for graphical interactions:
//    PICK_EVENT      represent a mouse event
//    MOUSE_TOOL      base class for processing mouse events
//    RBD_DRIVER      base class for rubberbanding
// ********************************************

class CPoint;
class CView;
class PICK_EVENT;
class RBD_DRIVER;
class MOUSE_TOOL;

// ********************************************
// Class name: PICK_EVENT
// Function:   Describe a mouse event
// ********************************************
class PICK_EVENT {
protected:
	CPoint m_nPick;
	int m_nButton;
	UINT m_nFlags;
	CView *m_pView;
public:
	int x() const { return m_nPick.x; }
	int y() const { return m_nPick.y; }
	CPoint pick() const { return m_nPick; }
	int button() const { return m_nButton; }
	UINT flags() const { return m_nFlags; }
	CView *view() const { return m_pView; }
	void set_pick(const CPoint& pick) { m_nPick = pick; }
	void set_pick(int x, int y) { m_nPick.x = x, m_nPick.y = y; }
	void set_button(int button) { m_nButton = button; }
	void set_flags(UINT flags) { m_nFlags = flags; }
	void set_view(CView *view) { m_pView = view; }

	PICK_EVENT();
	PICK_EVENT(int x, int y, int button, CView *view, UINT flags=0);
	PICK_EVENT(const CPoint& p, int button, CView *view, UINT flags=0);

	BOOL operator== (const PICK_EVENT& pe) const;
};

class RBD_DRIVER {
public:
	RBD_DRIVER();
	virtual ~RBD_DRIVER();
	virtual void Start(const PICK_EVENT&);
//	virtual void Start();
	virtual void Update(const PICK_EVENT&);
	virtual void Stop();
	virtual void Repaint(const CView*);
	virtual void DeleteViewNotify(const CView*);
protected:
	CView *m_pLastView;
	PICK_EVENT m_nLP;
	void DrawAll();
	void EraseAll();
public:
	virtual void Draw(CDC *pDC, const PICK_EVENT& pe) {}
	virtual void Erase(CDC *pDC, const PICK_EVENT& pe) {}
	virtual void DrawXor(CDC *pDC, const PICK_EVENT& pe) {}
public:
	static RBD_DRIVER* CurrentRBD;
};

// ********************************************
// Class name: MOUSE_TOOL
// Function:   Base tool to process mouse events
// ********************************************
class MOUSE_TOOL:public CObject {
protected:
	DECLARE_DYNAMIC(MOUSE_TOOL)
protected:
	PICK_EVENT m_nLP;

public:
	PICK_EVENT GetLP() const { return m_nLP; }

	MOUSE_TOOL() {}
	virtual ~MOUSE_TOOL() {}

	virtual int ProcessEvent(int evType, const PICK_EVENT& pe);
};

#endif
