#ifndef _ELLIPSETOOL_H
#define _ELLIPSETOOL_H

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

// ********************************************
// Class name: LINE_TOOL
// Function:   tool to process mouse events
// ********************************************

class RBD_ELLIPSE;

class ELLIPSE_TOOL : public MOUSE_TOOL {
protected:
	CPoint m_nStart;
	CPoint m_nEnd;
	CView *m_pView;
	RBD_ELLIPSE *m_pRbdLine;

public:
	ELLIPSE_TOOL();
	virtual ~ELLIPSE_TOOL();

	virtual int ProcessEvent(int evType, const PICK_EVENT& pe);

private:
	void CreateEllipse();
};

#endif
