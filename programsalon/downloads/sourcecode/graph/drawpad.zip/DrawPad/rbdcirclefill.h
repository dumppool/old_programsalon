#ifndef _RBDCIRCLEFILL_H
#define _RBDCIRCLEFILL_H

// **********************************************
// Class: RBD_CIRCLEFILL
// Function: Display a rubberbanding
// **********************************************

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

class RBD_CIRCLEFILL : public RBD_DRIVER {
protected:
	CPoint m_nStart;

public:
	RBD_CIRCLEFILL(const CPoint& start);
	virtual ~RBD_CIRCLEFILL();

	virtual void DrawXor(CDC *pDC, const PICK_EVENT& pe);
};

#endif
