// DrawPadDoc.h : interface of the CDrawPadDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DRAWPADDOC_H__5B46346D_355B_11D3_B695_000021DE748F__INCLUDED_)
#define AFX_DRAWPADDOC_H__5B46346D_355B_11D3_B695_000021DE748F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define HS_SOLID 101
class ENT;
class ENTITY;
class PICK_EVENT;

#include "eundo.h"

class CDrawPadDoc : public CDocument
{
protected: // create from serialization only
	CDrawPadDoc();
	DECLARE_DYNCREATE(CDrawPadDoc)

protected:
//	CObArray entities;        // entity tables
	CObList entities;           // entity table

// Paul add: Redo Buffer

public:
	UndoBuffer undoBuf;       // Paul add: Undo Buffer
	UndoBuffer redoBuf; 
	int UndoNestLevel;          // Undo nest level
	UINT m_line,m_brush;
	CString m_String;
	LOGFONT m_Font;
	UINT m_Vertex;
//	CObArray *GetEntities() { return &entities; }
	CObList *GetEntities() { return &entities; }

protected:
	// Insert and Delete are called without consideration of undo
	int Insert(ENTITY *ent);
	int Remove(ENTITY *ent);
	//int Insert(void *object);
	//int Remove(void *object);
	//void *Find(int type, void *key);

public:
	// Insert new entity
	void AddEntity(ENTITY *ent);
	void RemoveEntity(ENTITY *ent);
	void DrawEntity(ENTITY *ent, int method);

	// convenients for entity
//	void DrawEntity(void *item, int method);

	virtual void Draw(CDC *pDC);
	virtual int PickEntity(const PICK_EVENT &pe, ENTITY *&ent);

// Attributes
public:
	void ClearSelection();
	static CDrawPadDoc *CurrentDoc();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDrawPadDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	COLORREF m_nColor;
	int m_nWidth;
	virtual ~CDrawPadDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDrawPadDoc)
	afx_msg void OnColor();
	afx_msg void OnCBlue();
	afx_msg void OnUpdateCBlue(CCmdUI* pCmdUI);
	afx_msg void OnCGreen();
	afx_msg void OnUpdateCGreen(CCmdUI* pCmdUI);
	afx_msg void OnCRed();
	afx_msg void OnUpdateCRed(CCmdUI* pCmdUI);
	afx_msg void OnCYellow();
	afx_msg void OnUpdateCYellow(CCmdUI* pCmdUI);
	afx_msg void OnLine1();
	afx_msg void OnUpdateLine1(CCmdUI* pCmdUI);
	afx_msg void OnLine2();
	afx_msg void OnUpdateLine2(CCmdUI* pCmdUI);
	afx_msg void OnLine3();
	afx_msg void OnUpdateLine3(CCmdUI* pCmdUI);
	afx_msg void OnEditRedo();
	afx_msg void OnUpdateEditRedo(CCmdUI* pCmdUI);
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateEditUndo(CCmdUI* pCmdUI);
	afx_msg void OnPsDash();
	afx_msg void OnUpdatePsDash(CCmdUI* pCmdUI);
	afx_msg void OnPsDashdot();
	afx_msg void OnUpdatePsDashdot(CCmdUI* pCmdUI);
	afx_msg void OnPsDashdotdot();
	afx_msg void OnUpdatePsDashdotdot(CCmdUI* pCmdUI);
	afx_msg void OnPsDot();
	afx_msg void OnUpdatePsDot(CCmdUI* pCmdUI);
	afx_msg void OnPsSolid();
	afx_msg void OnUpdatePsSolid(CCmdUI* pCmdUI);
	afx_msg void OnHsBdiagonal();
	afx_msg void OnUpdateHsBdiagonal(CCmdUI* pCmdUI);
	afx_msg void OnHsCross();
	afx_msg void OnUpdateHsCross(CCmdUI* pCmdUI);
	afx_msg void OnHsDiagcross();
	afx_msg void OnUpdateHsDiagcross(CCmdUI* pCmdUI);
	afx_msg void OnHsFdiagonal();
	afx_msg void OnUpdateHsFdiagonal(CCmdUI* pCmdUI);
	afx_msg void OnHsHorizontal();
	afx_msg void OnUpdateHsHorizontal(CCmdUI* pCmdUI);
	afx_msg void OnHsSolid();
	afx_msg void OnUpdateHsSolid(CCmdUI* pCmdUI);
	afx_msg void OnHsVertical();
	afx_msg void OnUpdateHsVertical(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRAWPADDOC_H__5B46346D_355B_11D3_B695_000021DE748F__INCLUDED_)
