#include "stdafx.h"
#include "pickevent.h"

PICK_EVENT::PICK_EVENT()
{
	m_nPick = CPoint(0,0);
	m_nButton = 0;
	m_nFlags = 0;
	m_pView = NULL;
}

PICK_EVENT::PICK_EVENT(int x, int y, int button, CView *view, UINT flags)
{
	m_nPick = CPoint(x,y);
	m_nButton = button;
	m_nFlags = flags;
	m_pView = view;
}

PICK_EVENT::PICK_EVENT(const CPoint& p, int button, CView *view, UINT flags)
{
	m_nPick = p;
	m_nButton = button;
	m_nFlags = flags;
	m_pView = view;
}

BOOL PICK_EVENT::operator== (const PICK_EVENT& pe) const
{
	if( m_nPick != pe.pick() ) return FALSE;
	if( m_nButton != pe.button() ) return FALSE;
	if( m_nFlags != pe.flags() ) return FALSE;
	if( m_pView != pe.view() ) return FALSE;
	return TRUE;
}

