#include "stdafx.h"
#include "DrawPadDoc.h"

#include "rbdTEXT.h"
#include "TEXTtool.h"
#include "eTEXT.h"

IMPLEMENT_DYNAMIC(TEXT_TOOL, MOUSE_TOOL)

TEXT_TOOL::TEXT_TOOL()
{
	m_pRbdTEXT = NULL;
	m_pView = NULL;
}

TEXT_TOOL::~TEXT_TOOL()
{
	if( m_pRbdTEXT ) delete m_pRbdTEXT;
}

int TEXT_TOOL::ProcessEvent(int evType, const PICK_EVENT& pe)
{
	switch( evType ) {
	case WM_LBUTTONDOWN:
		m_nStart = pe.pick();
		m_pView = pe.view();
		if( m_pRbdTEXT ) delete m_pRbdTEXT;
		m_pRbdTEXT = new RBD_TEXT(m_nStart);
		m_pRbdTEXT->Start(pe);

		delete m_pRbdTEXT;
		m_pRbdTEXT = NULL;
		m_nEnd = pe.pick();
		CreateText();
		evType = 0;
		break;
	case WM_LBUTTONUP:
//		delete m_pRbdTEXT;
//		m_pRbdTEXT = NULL;
//		m_nEnd = pe.pick();
//		CreateText();
		evType = 0;
		break;
	}
	return MOUSE_TOOL::ProcessEvent(evType, pe);
}

void TEXT_TOOL::CreateText()
{
	ASSERT_VALID(m_pView);
	CDrawPadDoc *pDoc = (CDrawPadDoc *)m_pView->GetDocument();
	ASSERT_VALID(pDoc);
//	if( m_nStart != m_nEnd )
	UNDO_BEGIN
		pDoc->AddEntity(new ETEXT(m_nStart, m_nEnd,pDoc->m_String,pDoc->m_nColor,pDoc->m_Font));
	UNDO_END
}

