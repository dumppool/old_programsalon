#ifndef _SELECTTOOL_H
#define _SELECTTOOL_H

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

// ********************************************
// Class name: LINE_TOOL
// Function:   tool to process mouse events
// ********************************************

class RBD_RECT;

class SELECT_TOOL : public MOUSE_TOOL {
protected:
	DECLARE_DYNAMIC(SELECT_TOOL)
protected:
	CPoint m_nStart;
	CPoint m_nEnd;
	CView *m_pView;
	RBD_RECT *m_pRbdRect;

public:
	SELECT_TOOL();
	virtual ~SELECT_TOOL();

	virtual int ProcessEvent(int evType, const PICK_EVENT& pe);

private:
	// Pick calculation and entity highlighting using Start/End
	void Pick();
};

#endif
