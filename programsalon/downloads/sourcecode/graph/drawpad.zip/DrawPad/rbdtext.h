#ifndef _RBDTEXT_H
#define _RBDTEXT_H

// **********************************************
// Class: RBD_TEXT
// Function: Display a rubberbanding
// **********************************************

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

class RBD_TEXT : public RBD_DRIVER {
protected:
	CPoint m_nStart;

public:
	RBD_TEXT(const CPoint& start);
	virtual ~RBD_TEXT();

	virtual void DrawXor(CDC *pDC, const PICK_EVENT& pe);
};

#endif
