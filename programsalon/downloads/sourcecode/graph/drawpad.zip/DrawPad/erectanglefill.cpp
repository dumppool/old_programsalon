#include "stdafx.h"

#include "erectanglefill.h"
#include "pickevent.h"

// This file gives implementation of following class
//   ELINE

// ************************************************************
// implementation of ELINE
// ************************************************************

IMPLEMENT_SERIAL(ERECTANGLEFILL, ENTITY, 0);

void ERECTANGLEFILL::Serialize(CArchive &ar)
{
	ENTITY::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_nStart << m_nEnd;
	}
	else
	{
		ar >> m_nStart >> m_nEnd;
	}
}

// copy data from another entity.
int ERECTANGLEFILL::CopyData(ENT *another)
{
	if( !another ) return 0;
	ASSERT(another->IsKindOf(RUNTIME_CLASS(ERECTANGLEFILL)));
	ERECTANGLEFILL *other = (ERECTANGLEFILL *)another;
	ENTITY::CopyData(another);
	m_nStart = other->get_start();
	m_nEnd = other->get_end();
	return 1;
}

ERECTANGLEFILL::ERECTANGLEFILL()
{
}

ERECTANGLEFILL::ERECTANGLEFILL(const CPoint &p1, const CPoint &p2,COLORREF color,UINT Brush)
{
	m_nStart = p1;
	m_nEnd = p2;
	set_color(color);
	set_brush(Brush);
}

int ERECTANGLEFILL::GetGripper(int iGrip, CPoint &pnt)
{
  switch( iGrip ) {
  case 1:
    pnt = m_nStart;
    return 1;
  case 2:
    pnt = m_nEnd;
    return 1;
  default:
    return 0;
  }
}

void ERECTANGLEFILL::Draw(CDC *pDC, int state)
{
//	SetPen(pDC, state);
	SetBrush(pDC, state);
	//pDC->MoveTo(m_nStart); 
	//pDC->LineTo(m_nEnd);
//	CBrush brush(get_color());
	CBrush *oldbrush = pDC->SelectObject(&DTBrush);
//	CPen *oldpen = pDC->SelectObject(&DTPen);
//	CPen pen(PS_SOLID,get_line_width(),get_color());
//	CPen *oldpen = pDC->SelectObject(&pen);
	CRect rect(m_nStart,m_nEnd);
	pDC->Rectangle(rect);
//	pDC->SelectObject(oldpen);
	ENTITY::Draw(pDC, state);
	pDC->SelectObject(oldbrush);

}

int ERECTANGLEFILL::HitTest(CDC *pDC, const PICK_EVENT& pe)
{

	CPoint p(pe.x(),pe.y());
	CRect rect(m_nStart,m_nEnd);
	if(rect.PtInRect(p))
		return 1;
	else
		return 0;


}

