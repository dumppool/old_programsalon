#ifndef _ELLIPSEFILLTOOL_H
#define _ELLIPSEFILLTOOL_H

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

// ********************************************
// Class name: LINE_TOOL
// Function:   tool to process mouse events
// ********************************************

class RBD_ELLIPSEFILL;

class ELLIPSEFILL_TOOL : public MOUSE_TOOL {
protected:
	CPoint m_nStart;
	CPoint m_nEnd;
	CView *m_pView;
	RBD_ELLIPSEFILL *m_pRbdLine;

public:
	ELLIPSEFILL_TOOL();
	virtual ~ELLIPSEFILL_TOOL();

	virtual int ProcessEvent(int evType, const PICK_EVENT& pe);

private:
	void CreateEllipsefill();
};

#endif
