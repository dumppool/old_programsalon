#ifndef _RBDRECTANGLEFILL_H
#define _RBDRECTANGLEFILL_H

// **********************************************
// Class: RBD_LINE
// Function: Display a rubberbanding
// **********************************************

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

class RBD_RECTANGLEFILL : public RBD_DRIVER {
protected:
	CPoint m_nStart;

public:
	RBD_RECTANGLEFILL(const CPoint& start);
	virtual ~RBD_RECTANGLEFILL();

	virtual void DrawXor(CDC *pDC, const PICK_EVENT& pe);
};

#endif
