#ifndef _ECIRCLEFILL_H
#define _ECIRCLEFILL_H

#ifndef _ENTITY_H
#include "entity.h"
#endif

class ECIRCLEFILL;

// *********************************************************
// class ELINE
// *********************************************************
class ECIRCLEFILL : public ENTITY {
  DECLARE_SERIAL(ECIRCLEFILL);

private:
	CPoint  m_nStart;
	CPoint  m_nEnd;

public:
	ECIRCLEFILL();
	ECIRCLEFILL(const CPoint &p1, const CPoint &p2,COLORREF color,UINT Brush);

	// access data
	CPoint get_start() const { return m_nStart; }
	CPoint get_end() const { return m_nEnd; }
	void set_start(const CPoint &start) { backup(); m_nStart = start; }
	void set_end(const CPoint &end) { backup(); m_nEnd = end; }

	DECLARE_BACKUP(ECIRCLEFILL)

	virtual int GetMaxGrip() { return 2; }
	virtual int GetGripper(int iGrip, CPoint& pnt);

	virtual void Draw(CDC *pDC, int state);
	virtual int HitTest(CDC *pDC, const PICK_EVENT& pe);

};


#endif