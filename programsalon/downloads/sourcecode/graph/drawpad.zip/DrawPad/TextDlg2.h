#if !defined(AFX_TEXTDLG2_H__BB299CE3_398D_11D3_A77A_0000E866782A__INCLUDED_)
#define AFX_TEXTDLG2_H__BB299CE3_398D_11D3_A77A_0000E866782A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// TextDlg2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTextDlg2 dialog

class CTextDlg2 : public CDialog
{
// Construction
public:
	CTextDlg2(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTextDlg2)
	enum { IDD = IDD_TEXT_DIALOG };
	CEdit	m_wndText;
	CString m_edit1;
	UINT m_radio;
	LOGFONT m_dlgFont;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTextDlg2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTextDlg2)
	afx_msg void OnHRadio();
	afx_msg void OnVRadio();
	afx_msg void OnFontButton();
	afx_msg void OnCanButton();
	afx_msg void OnOkButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEXTDLG2_H__BB299CE3_398D_11D3_A77A_0000E866782A__INCLUDED_)
