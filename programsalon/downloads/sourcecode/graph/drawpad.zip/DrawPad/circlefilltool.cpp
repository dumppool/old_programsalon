#include "stdafx.h"
#include "DrawPadDoc.h"

#include "rbdcirclefill.h"
#include "circlefilltool.h"
#include "ecirclefill.h"

CIRCLEFILL_TOOL::CIRCLEFILL_TOOL()
{
	m_pRbdLine = NULL;
	m_pView = NULL;
}

CIRCLEFILL_TOOL::~CIRCLEFILL_TOOL()
{
	if( m_pRbdLine ) delete m_pRbdLine;
}

int CIRCLEFILL_TOOL::ProcessEvent(int evType, const PICK_EVENT& pe)
{
	switch( evType ) {
	case WM_LBUTTONDOWN:
		m_nStart = pe.pick();
		m_pView = pe.view();
		if( m_pRbdLine ) delete m_pRbdLine;
		m_pRbdLine = new RBD_CIRCLEFILL(m_nStart);
		m_pRbdLine->Start(pe);
		evType = 0;
		break;
	case WM_LBUTTONUP:
		delete m_pRbdLine;
		m_pRbdLine = NULL;
		m_nEnd = pe.pick();
		CreateCIRCLEFILL();
		evType = 0;
		break;
	}
	return MOUSE_TOOL::ProcessEvent(evType, pe);
}

void CIRCLEFILL_TOOL::CreateCIRCLEFILL()
{
	ASSERT_VALID(m_pView);
	CDrawPadDoc *pDoc = (CDrawPadDoc *)m_pView->GetDocument();
	ASSERT_VALID(pDoc);
	if( m_nStart != m_nEnd )
	{
		UNDO_BEGIN
		pDoc->AddEntity(new ECIRCLEFILL(m_nStart, m_nEnd,pDoc->m_nColor,pDoc->m_brush));
		UNDO_END
	}
}

