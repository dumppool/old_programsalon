//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DrawPad.rc
//
#define IDD_ABOUTBOX                    100
#define HS_SOLID                        101
#define IDR_MAINFRAME                   128
#define IDR_DRAWPATYPE                  129
#define IDD_WIDTH                       130
#define IDR_CL_TOOLBAR                  131
#define IDR_ST_TOOLBAR                  133
#define IDD_TEXT_DIALOG                 135
#define IDI_ICON_ORBIT                  136
#define IDC_WIDTH                       1000
#define IDC_SPIN_WIDTH                  1001
#define IDC_EDIT1                       1002
#define IDC_V_RADIO                     1003
#define IDC_H_RADIO                     1004
#define IDC_FONT_BUTTON                 1006
#define IDC_OK_BUTTON                   1007
#define IDC_CAN_BUTTON                  1008
#define ID_LINE                         32771
#define ID_ELLIPSE                      32772
#define ID_RECTANGLE                    32773
#define ID_TEXT                         32779
#define ID_ELLIPSEFILL                  32780
#define ID_ROUNDRECTANGLEFILL           32782
#define ID_WIDTH                        32783
#define ID_COLOR                        32784
#define ID_STYLE                        32785
#define ID_CIRCLE                       32786
#define ID_CIRCLEFILL                   32787
#define ID_RECTANGLEFILL                32788
#define ID_ROUNDRECTANGLE               32789
#define ID_C_RED                        32791
#define ID_C_GREEN                      32792
#define ID_C_BLUE                       32793
#define ID_C_YELLOW                     32794
#define ID_LINE_1                       32795
#define ID_LINE_2                       32796
#define ID_LINE_3                       32797
#define ID_SELECT                       32799
#define ID_PS_SOLID                     32801
#define ID_PS_DASH                      32802
#define ID_PS_DOT                       32803
#define ID_PS_DASHDOT                   32804
#define ID_PS_DASHDOTDOT                32805
#define ID_HS_BDIAGONAL                 32808
#define ID_HS_CROSS                     32809
#define ID_HS_DIAGCROSS                 32810
#define ID_HS_FDIAGONAL                 32811
#define ID_HS_HORIZONTAL                32812
#define ID_HS_VERTICAL                  32813
#define ID_HS_SOLID                     32814

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32817
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
