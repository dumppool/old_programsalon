#ifndef _RBDRECTANGLE_H
#define _RBDRECTANGLE_H

// **********************************************
// Class: RBD_LINE
// Function: Display a rubberbanding
// **********************************************

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

class RBD_RECTANGLE : public RBD_DRIVER {
protected:
	CPoint m_nStart;

public:
	RBD_RECTANGLE(const CPoint& start);
	virtual ~RBD_RECTANGLE();

	virtual void DrawXor(CDC *pDC, const PICK_EVENT& pe);
};

#endif
