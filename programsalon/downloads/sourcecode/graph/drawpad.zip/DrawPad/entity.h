#ifndef _ENTITY_H
#define _ENTITY_H

#define DRAWNORM       0
#define DRAWDEL        1
#define DRAWSEL        2
#define DRAWACTIVE     3
#define DRAWAUTO       4

class CDrawPadDoc;
class PICK_EVENT;

#define DECLARE_BACKUP(name) \
	public: \
	virtual void bufferout(void *&buf ) const \
	{ \
		buf = new char[sizeof(*this)]; \
		memcpy(buf, this, sizeof(*this)); \
	} \
	virtual void bufferin(void *&buf) \
	{ \
		memcpy(this, buf, sizeof(*this)); \
	} \
	virtual int CopyData(ENT *); \
	name(name &other) { CopyData((ENT *)&other); } \
	virtual ENT *Clone() { return (ENT *)(new name(*this)); } \
	virtual void Serialize(CArchive& ar);

  
// The generic data structure entity. Provide rollback and saving
// mechanism.
class ENT : public CObject {
	DECLARE_SERIAL(ENT);
protected:
	CDrawPadDoc* m_pDocument;

protected:
	// make backup record of the entity to bulletin
	// This routine usually calls bufferize() method.
	void backup();

public:
	// Entity constructor, initialising common entries, and
	// creating a bulletin.
	ENT() { m_pDocument = NULL; }
	~ENT() {}
	virtual void lose() { delete this; }

	// access protected data
	CDrawPadDoc* GetDocument() const { return m_pDocument; }
	virtual void SetDocument(CDrawPadDoc* pDoc) { m_pDocument = pDoc; }

	DECLARE_BACKUP(ENT)

	virtual void Draw(CDC *pDC, int state) {}

};

class ENTITY : public ENT {
	DECLARE_SERIAL(ENTITY);
private:
	COLORREF m_nColor;
	int m_nLineWidth;
	UINT m_linestyle;
	UINT m_brushstyle;
	LOGFONT m_font;
	CString m_str;
public:
	CString get_string() const { return m_str; }
	COLORREF get_color() const { return m_nColor; }
	int get_line_width() const { return m_nLineWidth; }
	UINT get_line_style() const {return m_linestyle;}
	UINT get_brush() const {return m_brushstyle;}
	LOGFONT get_font() const { return m_font;}
	void set_string(CString str) {backup(); m_str = str;}
	void set_color(COLORREF newcolor) { backup(); m_nColor = newcolor; }
	void set_line_width(int newlw) { backup(); m_nLineWidth = newlw; }
	void set_line_style(UINT style) { backup(); m_linestyle = style; }
	void set_brush(UINT style) { backup(); m_brushstyle = style; }
	void set_font(LOGFONT font) {backup();m_font=font;}
	int SetBrush(CDC *pDC,int state);
	int SetPen(CDC *pDC, int state);

	ENTITY();
	~ENTITY();

	DECLARE_BACKUP(ENTITY)

	int IsGrip(const CPoint& key);
	void DrawGripper(CDC *pDC, const CPoint &pnt);
	void DrawGrippers(CDC *pDC);

	virtual int GetMaxGrip() { return 0; }
	virtual int GetGripper(int iGrip, CPoint& pnt) { return 0; }

	virtual void Draw(CDC *pDC, int state) { if( state==DRAWACTIVE ) DrawGrippers(pDC); }
	virtual int HitTest(CDC *pDC, const PICK_EVENT& pe) { return 0; }
public:
	static CPen    DTPen;
	static CBrush  DTBrush;
	static CFont   DTFont;
	static void InitGDIObjects();

};

#endif

