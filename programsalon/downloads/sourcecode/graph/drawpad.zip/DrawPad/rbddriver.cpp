#include "stdafx.h"
#include "pickevent.h"

RBD_DRIVER* RBD_DRIVER::CurrentRBD = NULL;

RBD_DRIVER::RBD_DRIVER()
{
	RBD_DRIVER::CurrentRBD = this;
	m_pLastView = NULL;
}

RBD_DRIVER::~RBD_DRIVER()
{
	Stop();
	RBD_DRIVER::CurrentRBD = NULL;
}

void RBD_DRIVER::Start(const PICK_EVENT& pe)
{
	if( m_pLastView != pe.view() ) {
		Stop();
		m_pLastView = pe.view();
	}
	if( m_pLastView ) {
		m_nLP = pe;
		DrawAll();
	}
}
/*void RBD_DRIVER::Start()
{
	if( m_pLastView ) {
		DrawAll();
	}
}*/

void RBD_DRIVER::Update(const PICK_EVENT& pe)
{
	if( m_pLastView != pe.view() ) {
		Stop();
		Start(pe);
	}
	else if( m_pLastView ) {
		EraseAll();
		m_nLP = pe;
		DrawAll();
	}
}

void RBD_DRIVER::Stop()
{
	if( m_pLastView ) {
		EraseAll();
		m_pLastView = NULL;
	}
}

void RBD_DRIVER::Repaint(const CView* view)
{
	if( view == m_pLastView )
		DrawAll();
}

void RBD_DRIVER::DeleteViewNotify(const CView* view)
{
	if( view == m_pLastView ) {
		EraseAll();
		m_pLastView = NULL;
	}
}

void RBD_DRIVER::DrawAll()
{
	if( !m_pLastView ) return;
	CDC* pDC = m_pLastView->GetDC();
	if( pDC ) {
		Draw(pDC, m_nLP);
		int ROP = pDC->SetROP2(R2_XORPEN);
		int BKM = pDC->SetBkMode(TRANSPARENT);
		DrawXor(pDC, m_nLP);
		pDC->SetROP2(ROP);
		pDC->SetBkMode(BKM);
		m_pLastView->ReleaseDC(pDC);
	}
}

void RBD_DRIVER::EraseAll()
{
	if( !m_pLastView ) return;
	CDC* pDC = m_pLastView->GetDC();
	if( pDC ) {
		Erase(pDC, m_nLP);
		int ROP = pDC->SetROP2(R2_XORPEN);
		int BKM = pDC->SetBkMode(TRANSPARENT);
		DrawXor(pDC, m_nLP);
		pDC->SetROP2(ROP);
		pDC->SetBkMode(BKM);
		m_pLastView->ReleaseDC(pDC);
	}
}

