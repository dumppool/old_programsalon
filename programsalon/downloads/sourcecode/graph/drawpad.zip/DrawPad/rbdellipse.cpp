#include "stdafx.h"
#include "rbdellipse.h"
#include "DrawPadDoc.h"

RBD_ELLIPSE::RBD_ELLIPSE(const CPoint& start)
{
	m_nStart = start;
}

RBD_ELLIPSE::~RBD_ELLIPSE()
{
}

void RBD_ELLIPSE::DrawXor(CDC *pDC, const PICK_EVENT& pe)
{
	CPen pen, *oldpen;
	CDrawPadDoc *pDoc;
	pDoc = (CDrawPadDoc*)m_pLastView->GetDocument();
	int width = pDoc->m_nWidth;
	pen.CreatePen(PS_SOLID, width, pDoc->m_nColor);
	
	oldpen = pDC->SelectObject(&pen);
	CRect rect(m_nStart,pe.pick());
	pDC->SelectStockObject(NULL_BRUSH);
	pDC->Ellipse(rect);
	//pDC->SelectObject(oldbursh);
	//pDC->MoveTo(m_nStart);
	//pDC->LineTo(pe.pick());
	pDC->SelectObject(oldpen);
}
