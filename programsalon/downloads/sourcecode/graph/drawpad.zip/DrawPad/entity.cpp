#include "stdafx.h"
#include "DrawPadDoc.h"
#include "entity.h"

//////////////////////////////////////////////////////////////
// Class ENT
//////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL(ENT, CObject, 0);

void ENT::Serialize(CArchive& ar)
{
	CObject::Serialize(ar);
}

// make backup record of the entity to bulletin
// This routine usually calls bufferize() method.
void ENT::backup()
{
	if( GetDocument() ) {
		GetDocument()->undoBuf.modifyObject(this);
		GetDocument()->SetModifiedFlag();
	}
}

// copy data from another entity.
int ENT::CopyData(ENT *another)
{
	return 1;
}


//////////////////////////////////////////////////////////////
// Class ENTITY
//////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL(ENTITY, ENT, 0);
CPen ENTITY::DTPen;
CBrush ENTITY::DTBrush;
CFont ENTITY::DTFont;
void ENTITY::InitGDIObjects()
{
	DTPen.CreatePen(PS_SOLID,1,RGB(0,0,0));
	DTBrush.CreateSolidBrush(RGB(0,0,0));
	DTFont.CreateFont(-12,8,0,0,0,0,0,0,0,0,0,0,0,"Arial");
}

void ENTITY::Serialize(CArchive& ar)
{
  ENT::Serialize(ar);
  if (ar.IsStoring())
  {
    ar << m_nColor << m_nLineWidth<<m_linestyle<<m_brushstyle<<m_str;
	ar.Write(&m_font,sizeof(LOGFONT));
  }
  else
  {
    ar >> m_nColor >> m_nLineWidth>>m_linestyle>>m_brushstyle>>m_str;
	ar.Read(&m_font,sizeof(LOGFONT));
  }
}

ENTITY::ENTITY()
{
  m_nColor = RGB(0,0,0);
  m_nLineWidth = 1;
  m_str="";
}

ENTITY::~ENTITY() {}

// copy data from another entity.
int ENTITY::CopyData(ENT *another)
{
  if( !another ) return 0;
  ASSERT(another->IsKindOf(RUNTIME_CLASS(ENTITY)));
  ENTITY *other = (ENTITY *)another;
  ENT::CopyData(another);
  m_nColor = other->get_color();
  m_nLineWidth = other->get_line_width();
  return 1;
}

int ENTITY::SetPen(CDC *pDC, int state)
{
  switch (state) {
  case DRAWNORM:
  		DTPen.DeleteObject();
		DTPen.CreatePen(m_linestyle, m_nLineWidth, m_nColor);
		return DRAWNORM;
	  
  case DRAWDEL:
  		DTPen.DeleteObject();
		DTPen.CreatePen(m_linestyle, m_nLineWidth, RGB(255,255,255));
		return DRAWDEL;
  case DRAWSEL:
  		DTPen.DeleteObject();
		DTPen.CreatePen(m_linestyle, m_nLineWidth, RGB(255,0,255));
		return DRAWSEL;
  case DRAWACTIVE:
  		DTPen.DeleteObject();
		DTPen.CreatePen(m_linestyle, m_nLineWidth, RGB(255,0,255));
		return DRAWACTIVE;
	case DRAWAUTO:
		SetPen(pDC, DRAWNORM);

  }
  return DRAWNORM;
}

int ENTITY::SetBrush(CDC *pDC, int state)
{
  switch (state) {
  case DRAWNORM:
  		DTBrush.DeleteObject();
		if(m_brushstyle==HS_SOLID)
			DTBrush.CreateSolidBrush(m_nColor);
		else 
			DTBrush.CreateHatchBrush(m_brushstyle,m_nColor);
		return DRAWNORM;
  case DRAWDEL:
  		DTBrush.DeleteObject();
		if(m_brushstyle==HS_SOLID)
			DTBrush.CreateSolidBrush(RGB(255,255,255));
		else 
			DTBrush.CreateHatchBrush(m_brushstyle,RGB(255,255,255));
		return DRAWDEL;
  case DRAWSEL:
  		DTBrush.DeleteObject();
		if(m_brushstyle==HS_SOLID)
			DTBrush.CreateSolidBrush(RGB(255,0,255));
		else 
			DTBrush.CreateHatchBrush(m_brushstyle,RGB(255,0,255));
		return DRAWSEL;
  case DRAWACTIVE:
  		DTBrush.DeleteObject();
		if(m_brushstyle==HS_SOLID)
			DTBrush.CreateSolidBrush(RGB(255,0,255));
		else 
			DTBrush.CreateHatchBrush(m_brushstyle,RGB(255,0,255));
		return DRAWACTIVE;
	case DRAWAUTO:
		SetBrush(pDC, DRAWNORM);

  }
  return DRAWNORM;
}
int ENTITY::IsGrip(const CPoint &key)
{
  return 0;
}
  
void ENTITY::DrawGripper(CDC *pDC, const CPoint& pnt)
{
	CPen *oldpen = pDC->SelectObject(&DTPen);
	pDC->MoveTo(pnt.x-3, pnt.y-3);
	pDC->LineTo(pnt.x+3, pnt.y-3);
	pDC->LineTo(pnt.x+3, pnt.y+3);
	pDC->LineTo(pnt.x-3, pnt.y+3);
	pDC->LineTo(pnt.x-3, pnt.y-3);
	pDC->SelectObject(oldpen);

}

void ENTITY::DrawGrippers(CDC *pDC)
{
	CPoint pnt;
	for( int i = 0; i < GetMaxGrip(); i ++ ) {
		if( GetGripper(i, pnt) )
			DrawGripper(pDC, pnt);
	}
}

