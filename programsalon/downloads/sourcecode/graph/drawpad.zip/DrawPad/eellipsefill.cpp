#include "stdafx.h"

#include "eellipsefill.h"
#include "pickevent.h"

// This file gives implementation of following class
//   ELINE


IMPLEMENT_SERIAL(EELLIPSEFILL, ENTITY, 0);

void EELLIPSEFILL::Serialize(CArchive &ar)
{
	ENTITY::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_nStart << m_nEnd;
	}
	else
	{
		ar >> m_nStart >> m_nEnd;
	}
}

// copy data from another entity.
int EELLIPSEFILL::CopyData(ENT *another)
{
	if( !another ) return 0;
	ASSERT(another->IsKindOf(RUNTIME_CLASS(EELLIPSEFILL)));
	EELLIPSEFILL *other = (EELLIPSEFILL *)another;
	ENTITY::CopyData(another);
	m_nStart = other->get_start();
	m_nEnd = other->get_end();
	return 1;
}

EELLIPSEFILL::EELLIPSEFILL()
{
}

EELLIPSEFILL::EELLIPSEFILL(const CPoint &p1, const CPoint &p2,COLORREF color,UINT Brush)
{
	m_nStart = p1;
	m_nEnd = p2;
	set_color(color);
	set_brush(Brush);
//	m_nFill = 0;
}

int EELLIPSEFILL::GetGripper(int iGrip, CPoint &pnt)
{
  switch( iGrip ) {
  case 1:
    pnt = m_nStart;
    return 1;
  case 2:
    pnt = m_nEnd;
    return 1;
  default:
    return 0;
  }
}

void EELLIPSEFILL::Draw(CDC *pDC, int state)
{
//	SetPen(pDC, state);
	SetBrush(pDC, state);
//	CBrush brush(get_color());
	CBrush *oldbrush = pDC->SelectObject(&DTBrush);

//	CPen pen(PS_SOLID,get_line_width(),get_color());
//CPen *oldpen = pDC->SelectObject(&DTPen);
	
	CRect rect(m_nStart,m_nEnd);
	pDC->Ellipse(rect);
	//pDC->MoveTo(m_nStart);
	//pDC->LineTo(m_nEnd);
//	pDC->SelectObject(oldpen);
	ENTITY::Draw(pDC, state);
	pDC->SelectObject(oldbrush);
}

int EELLIPSEFILL::HitTest(CDC *pDC, const PICK_EVENT& pe)
{
	CPoint p(pe.x(),pe.y());
	CRect rect(m_nStart,m_nEnd);
	float a=abs(m_nEnd.x-m_nStart.x)/2.0;
	float b=abs(m_nEnd.y-m_nStart.y)/2.0;
	if(rect.PtInRect(p))
		return 1;
	else
		return 0;
}
