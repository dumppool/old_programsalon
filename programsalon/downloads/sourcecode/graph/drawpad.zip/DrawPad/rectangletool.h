#ifndef _RECTANGLETOOL_H
#define _RECTANGLETOOL_H

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

// ********************************************
// Class name: LINE_TOOL
// Function:   tool to process mouse events
// ********************************************

class RBD_RECTANGLE;

class RECTANGLE_TOOL : public MOUSE_TOOL {
protected:
	CPoint m_nStart;
	CPoint m_nEnd;
	CView *m_pView;
	RBD_RECTANGLE *m_pRbdLine;

public:
	RECTANGLE_TOOL();
	virtual ~RECTANGLE_TOOL();

	virtual int ProcessEvent(int evType, const PICK_EVENT& pe);

private:
	void CreateRectangle();
};

#endif
