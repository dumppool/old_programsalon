// DrawPadView.cpp : implementation of the CDrawPadView class
//

#include "stdafx.h"
#include "DrawPad.h"

#include "DrawPadDoc.h"
#include "DrawPadView.h"
#include "entity.h"
#include "eselection.h"

#include "linetool.h"
#include "selecttool.h"
#include "ellipsetool.h"
#include "rectangletool.h"
#include "circletool.h"
#include "circlefilltool.h"
#include "ellipsefilltool.h"
#include "rectanglefilltool.h"
#include "texttool.h"
#include "textdlg2.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CDrawPadView

IMPLEMENT_DYNCREATE(CDrawPadView, CScrollView)

BEGIN_MESSAGE_MAP(CDrawPadView, CScrollView)
	//{{AFX_MSG_MAP(CDrawPadView)
	ON_COMMAND(ID_LINE, OnLine)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_UPDATE_COMMAND_UI(ID_LINE, OnUpdateLine)
	ON_COMMAND(ID_CIRCLE, OnCircle)
	ON_UPDATE_COMMAND_UI(ID_CIRCLE, OnUpdateCircle)
	ON_COMMAND(ID_STYLE, OnStyle)
	ON_UPDATE_COMMAND_UI(ID_STYLE, OnUpdateStyle)
	ON_COMMAND(ID_TEXT, OnText)
	ON_UPDATE_COMMAND_UI(ID_TEXT, OnUpdateText)
	ON_COMMAND(ID_SELECT, OnSelect)
	ON_UPDATE_COMMAND_UI(ID_SELECT, OnUpdateSelect)
	ON_COMMAND(ID_RECTANGLE, OnRectangle)
	ON_UPDATE_COMMAND_UI(ID_RECTANGLE, OnUpdateRectangle)
	ON_COMMAND(ID_ELLIPSE, OnEllipse)
	ON_UPDATE_COMMAND_UI(ID_ELLIPSE, OnUpdateEllipse)
	ON_COMMAND(ID_CIRCLEFILL, OnCirclefill)
	ON_UPDATE_COMMAND_UI(ID_CIRCLEFILL, OnUpdateCirclefill)
	ON_COMMAND(ID_ELLIPSEFILL, OnEllipsefill)
	ON_UPDATE_COMMAND_UI(ID_ELLIPSEFILL, OnUpdateEllipsefill)
	ON_COMMAND(ID_RECTANGLEFILL, OnRectanglefill)
	ON_UPDATE_COMMAND_UI(ID_RECTANGLEFILL, OnUpdateRectanglefill)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDrawPadView construction/destruction

CDrawPadView::CDrawPadView()
{
	// TODO: add construction code here
	selection = new SELECTION(this);
	selection->SetNotify(TRUE);
	m_HArrow=AfxGetApp()->LoadStandardCursor(IDC_ARROW);
	m_HCross=AfxGetApp()->LoadStandardCursor(IDC_CROSS);
	m_Drawing = 0;
}

CDrawPadView::~CDrawPadView()
{
		delete selection;
}

BOOL CDrawPadView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	m_ClassName=AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW,0,
		(HBRUSH)::GetStockObject(WHITE_BRUSH),0);
	cs.lpszClass=m_ClassName;
	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CDrawPadView drawing

void CDrawPadView::OnDraw(CDC* pDC)
{
	CDrawPadDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
	pDoc->Draw(pDC);
	GetSelection()->Draw();
}
void CDrawPadView::DrawEntity(ENTITY *ent, int method)
{
	CDC *pDC = GetDC();
	ent->Draw(pDC, method);
	ReleaseDC(pDC);
}

/////////////////////////////////////////////////////////////////////////////
// CDrawPadView printing

BOOL CDrawPadView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDrawPadView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CDrawPadView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CDrawPadView diagnostics

#ifdef _DEBUG
void CDrawPadView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CDrawPadView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CDrawPadDoc* CDrawPadView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDrawPadDoc)));
	return (CDrawPadDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDrawPadView message handlers
CDrawPadView *CDrawPadView::CurrentView()
{
	CMDIFrameWnd *fWnd = (CMDIFrameWnd *)AfxGetMainWnd();
	CMDIChildWnd *pWnd = fWnd->MDIGetActive();
	if( !pWnd ) return 0;
	return (CDrawPadView *)pWnd->GetActiveView();
}


MOUSE_TOOL *CDrawPadView::CurrentTool = new SELECT_TOOL;

void CDrawPadView::OnLine() 
{
	// TODO: Add your command handler code here
	SetTool(new LINE_TOOL);
	m_Drawing = ID_LINE;
}

/*void CDrawPadView::OnEllipse() 
{
	// TODO: Add your command handler code here
	SetTool(new ELLIPSE_TOOL);
	m_Drawing = ID_ELLIPSE;
}*/

//MOUSE_TOOL *CDrawPadView::CurrentTool =new SELECT_TOOL;

void CDrawPadView::SetTool(MOUSE_TOOL *newtool)
{
	if( CurrentTool ) delete CurrentTool;
	if( newtool )
		CurrentTool = newtool;
	else
		CurrentTool = new SELECT_TOOL;
}

void CDrawPadView::OnMouseEvent(int evType, UINT nFlags, CPoint point)
{
	if( CurrentTool ) {
		PICK_EVENT pe(point, 0, this, nFlags);
		CurrentTool->ProcessEvent(evType, pe);
	}
}

void CDrawPadView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CClientDC ClientDC(this);
	OnPrepareDC(&ClientDC);
	ClientDC.DPtoLP(&point);
	CSize ScrollSize=GetTotalSize();
	CRect ScrollRect(0,0,ScrollSize.cx,ScrollSize.cy);
	if(ScrollRect.PtInRect(point))
		::SetCursor(m_HCross);
	else
		::SetCursor(m_HArrow);
	OnMouseEvent(WM_MOUSEMOVE, nFlags, point);
	CScrollView::OnMouseMove(nFlags, point);
}

void CDrawPadView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CClientDC ClientDC(this);
	OnPrepareDC(&ClientDC);
	ClientDC.DPtoLP(&point);
	OnMouseEvent(WM_LBUTTONDOWN, nFlags, point);
	m_bPoint=point;
	CScrollView::OnLButtonDown(nFlags, point);
}

void CDrawPadView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CClientDC ClientDC(this);
	OnPrepareDC(&ClientDC);
	ClientDC.DPtoLP(&point);	
	OnMouseEvent(WM_LBUTTONUP, nFlags, point);
	CRect rect(m_bPoint,point);
	InvalidateRect(rect);
	CScrollView::OnLButtonUp(nFlags, point);
}


void CDrawPadView::OnUpdateLine(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(CurrentTool && CurrentTool->IsKindOf(RUNTIME_CLASS(LINE_TOOL)));
	//	pCmdUI->SetCheck(m_Drawing == ID_LINE?TRUE:FALSE);
}

/*void CDrawPadView::OnRectangle() 
{
	// TODO: Add your command handler code here
	SetTool(new RECTANGLE_TOOL);
	m_Drawing = ID_RECTANGLE;
}*/

/*void CDrawPadView::OnUpdateRectangle(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_RECTANGLE?TRUE:FALSE);
}*/



/*void CDrawPadView::OnUpdateEllipseSolid(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_CIRCLEFILL?TRUE:FALSE);	
}*/

/*void CDrawPadView::OnRectangleSolid() 
{
	// TODO: Add your command handler code here
	m_Drawing = ID_RECTANGLEFILL;
}*/

/*void CDrawPadView::OnUpdateRectangleSolid(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_RECTANGLEFILL?TRUE:FALSE);	
}*/

void CDrawPadView::OnCircle() 
{
	// TODO: Add your command handler code here
	m_Drawing = ID_CIRCLE;
	SetTool(new CIRCLE_TOOL);
}

void CDrawPadView::OnUpdateCircle(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_CIRCLE?TRUE:FALSE);
}

/*void CDrawPadView::OnRoundSolid() 
{
	// TODO: Add your command handler code here
	m_Drawing = ID_ROUNDRECTANGLEFILL;
}

void CDrawPadView::OnUpdateRoundSolid(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_ROUNDRECTANGLEFILL?TRUE:FALSE);
}*/

void CDrawPadView::OnStyle() 
{
	// TODO: Add your command handler code here
	
}

void CDrawPadView::OnUpdateStyle(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}

void CDrawPadView::OnText() 
{
	// TODO: Add your command handler code here
	CDrawPadDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CTextDlg2 dlg;
	dlg.m_edit1=pDoc->m_String;
	dlg.m_dlgFont=pDoc->m_Font;
	if(dlg.DoModal()==IDOK)
	{
		m_Drawing = ID_TEXT;
		SetTool(new TEXT_TOOL);
		pDoc->m_String=dlg.m_edit1;
		pDoc->m_Font=dlg.m_dlgFont;
		pDoc->m_Vertex=dlg.m_radio;
	}
}

void CDrawPadView::OnUpdateText(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_TEXT?TRUE:FALSE);
}



/*void CDrawPadView::OnEllipseSolid() 
{
	// TODO: Add your command handler code here
	m_Drawing = ID_CIRCLEFILL;
	
}*/

/*void CDrawPadView::OnUpdateEllipse(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_ELLIPSE?TRUE:FALSE);
}*/

void CDrawPadView::OnSelect() 
{
	// TODO: Add your command handler code here
	SetTool(new SELECT_TOOL);
}

void CDrawPadView::OnUpdateSelect(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(CurrentTool && CurrentTool->IsKindOf(RUNTIME_CLASS(SELECT_TOOL)));
}

/*void CDrawPadView::OnUpdateEllipse(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}*/

/*void CDrawPadView::OnEllipsefill() 
{
	// TODO: Add your command handler code here
	
}*/

/*void CDrawPadView::OnUpdateEllipsefill(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}*/


void CDrawPadView::OnRectangle() 
{
	// TODO: Add your command handler code here
	SetTool(new RECTANGLE_TOOL);
	m_Drawing = ID_RECTANGLE;	
}

void CDrawPadView::OnUpdateRectangle(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_RECTANGLE?TRUE:FALSE);
	
}

void CDrawPadView::OnEllipse() 
{
	// TODO: Add your command handler code here
	SetTool(new ELLIPSE_TOOL);
	m_Drawing = ID_ELLIPSE;	
	
}

void CDrawPadView::OnUpdateEllipse(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_ELLIPSE?TRUE:FALSE);
	
}

void CDrawPadView::OnCirclefill() 
{
	// TODO: Add your command handler code here
	SetTool(new CIRCLEFILL_TOOL);
	m_Drawing = ID_CIRCLEFILL;	
}

void CDrawPadView::OnUpdateCirclefill(CCmdUI* pCmdUI) 
{
 	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_CIRCLEFILL?TRUE:FALSE);	
}

void CDrawPadView::OnEllipsefill() 
{
	// TODO: Add your command handler code here
	SetTool(new ELLIPSEFILL_TOOL);
	m_Drawing = ID_ELLIPSEFILL;		
}

void CDrawPadView::OnUpdateEllipsefill(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_ELLIPSEFILL?TRUE:FALSE);		
}

void CDrawPadView::OnRectanglefill() 
{
	// TODO: Add your command handler code here
	SetTool(new RECTANGLEFILL_TOOL);
	m_Drawing = ID_RECTANGLEFILL;			
}

void CDrawPadView::OnUpdateRectanglefill(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_Drawing == ID_RECTANGLEFILL?TRUE:FALSE);			
}

void CDrawPadView::OnInitialUpdate() 
{
	CScrollView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	SIZE Size={800,600};
	SetScrollSizes(MM_TEXT,Size);
}
