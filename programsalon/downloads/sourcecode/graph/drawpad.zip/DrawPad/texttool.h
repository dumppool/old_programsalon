#ifndef _TEXTTOOL_H
#define _TEXTTOOL_H

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

// ********************************************
// Class name: TEXT_TOOL
// Function:   tool to process mouse events
// ********************************************

class RBD_TEXT;

class TEXT_TOOL : public MOUSE_TOOL {
protected:
	DECLARE_DYNAMIC(TEXT_TOOL)
protected:
	CPoint m_nStart;
	CPoint m_nEnd;
	CView *m_pView;
	RBD_TEXT *m_pRbdTEXT;

public:
	TEXT_TOOL();
	virtual ~TEXT_TOOL();

	virtual int ProcessEvent(int evType, const PICK_EVENT& pe);

private:
	void CreateText();
};

#endif
