#include "stdafx.h"
#include "DrawPadDoc.h"

#include "rbdcircle.h"
#include "circletool.h"
#include "ecircle.h"

CIRCLE_TOOL::CIRCLE_TOOL()
{
	m_pRbdCircle = NULL;
	m_pView = NULL;
}

CIRCLE_TOOL::~CIRCLE_TOOL()
{
	if( m_pRbdCircle ) delete m_pRbdCircle;
}

int CIRCLE_TOOL::ProcessEvent(int evType, const PICK_EVENT& pe)
{
	switch( evType ) {
	case WM_LBUTTONDOWN:
		m_nStart = pe.pick();
		m_pView = pe.view();
		if( m_pRbdCircle ) delete m_pRbdCircle;
		m_pRbdCircle = new RBD_CIRCLE(m_nStart);
		m_pRbdCircle->Start(pe);
		evType = 0;
		break;
	case WM_LBUTTONUP:
		delete m_pRbdCircle;
		m_pRbdCircle = NULL;
		m_nEnd = pe.pick();
		CreateCircle();
		evType = 0;
		break;
	}
	return MOUSE_TOOL::ProcessEvent(evType, pe);
}

void CIRCLE_TOOL::CreateCircle()
{
	ASSERT_VALID(m_pView);
	CDrawPadDoc *pDoc = (CDrawPadDoc *)m_pView->GetDocument();
	ASSERT_VALID(pDoc);
	if( m_nStart != m_nEnd )
	{
		UNDO_BEGIN
		pDoc->AddEntity(new ECIRCLE(m_nStart, m_nEnd,pDoc->m_nWidth,pDoc->m_nColor,pDoc->m_line));
		UNDO_END
	}
}

