#ifndef _ESELECTION_H
#define _ESELECTION_H

typedef int (*ArgCallback) (void *);
typedef struct _CallbackSet {
  ArgCallback func;
  void *arg;
  void *option;
} CallbackSet;

class CView;
class PICK_ENT;
class ENTITY;

class SELECTION : public CObject {
protected:
	// As this selection is only owned by CView, we note it here
	CView *m_pOwner;
	// This is the list of selected ENTITIES
	CObList m_pEntityList;
	// record PICK_ENT (using single picking)
	CObList m_pPickList;

	// if set, the operation will notify display.
	int notify;
	// if set, adding entities using xor mode
	int xormode;
	// define here a callback when selection is changed
	CallbackSet selCB;
	int selCBOn;

public:
	SELECTION(CView *view);
	virtual ~SELECTION();

public:
	// Set the respond of view display to selection operations
	int SetNotify(int aNotify) { int oldn=notify; notify = aNotify; return oldn; }
	int GetNotify() const { return notify; }
  
	// set the mode for adding
	int SetXor(int aXor) { int oldx=xormode; xormode = aXor; return oldx; }
	int GetXor() const { return xormode; }

	// Get the number of ENTITIES in the selection
	int GetCount() const { return m_pEntityList.GetCount(); }
	CObList *GetEntities() { return &m_pEntityList; }
	CView *GetOwner() const { return m_pOwner; }
  
	// Get possible pick ray record of an entity, return TRUE if success
	int GetPickRay(ENTITY *ent, PICK_ENT *&pick_ent);
  
	// Add an entity to the selection.
	void add(ENTITY *);
	void Add(ENTITY *);
	void Add(ENTITY *, const CPoint&);
	void Add(CObList *);

	// Remove and entity from the selection
	// Returns the number of ENTITIES in the selection
	void remove(ENTITY *);
	void Remove(ENTITY *);
	void Remove(CObList *);

	// Clear the selection
	void Clear();
	void Clear(int display);

	// See if the selection is empty
	int IsEmpty() const { return m_pEntityList.GetCount() == 0; }

	// Test to see if the Selection contains a given entity
	BOOL Contains(ENTITY *);
	BOOL Contains(CObList *);

	// Draw this selection using highlight
	void Draw();

	// set selection change callback
	void SetSelChangeCallback(ArgCallback func=0, void *arg=0);

	// The Highlight method uses aht procedure api_gi_highlight_entity which
	// is defined in the 3D Toolkit.  If you are not using the 3D Toolkit, you
	// will have to change the implementation of this method.
	void SetHighlight(BOOL onoff = TRUE);

// override:
	// highlight an entity in selection
	virtual void Highlight(ENTITY *ent, BOOL onoff);

private:
	// calls defined callback if selection is changed
	void onSelChange();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

// ===========================================================
// Define a selected entity, with pick ray binded with it.
// This is recorded in selection set.
// If an entity is not got via picking, such as window selection,
// this record will not be in the selection.
class PICK_ENT : public CObject {
protected:
	ENTITY *Ent;
	CPoint Pick;
public:
	PICK_ENT();
	PICK_ENT(ENTITY *, const CPoint &);

	ENTITY* entity() const { return Ent; }
	CPoint pick() { return Pick; }

	void set_entity(ENTITY *ent) { Ent = ent; }
	void set_pick(const CPoint &pick) { Pick = pick; }

};

#endif
