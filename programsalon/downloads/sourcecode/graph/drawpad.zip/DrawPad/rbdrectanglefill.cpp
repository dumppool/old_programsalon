#include "stdafx.h"
#include "rbdRECTANGLEfill.h"
#include "DrawPadDoc.h"

RBD_RECTANGLEFILL::RBD_RECTANGLEFILL(const CPoint& start)
{
	m_nStart = start;
}

RBD_RECTANGLEFILL::~RBD_RECTANGLEFILL()
{

}

void RBD_RECTANGLEFILL::DrawXor(CDC *pDC, const PICK_EVENT& pe)
{
	CPen pen, *oldpen;
	CDrawPadDoc *pDoc;
	pDoc = (CDrawPadDoc*)m_pLastView->GetDocument();
	int width = pDoc->m_nWidth;
	pen.CreatePen(PS_SOLID, width, pDoc->m_nColor);
//	pen.CreatePen(PS_SOLID, 1, RGB(192,192,192));
	oldpen = pDC->SelectObject(&pen);
	pDC->SelectStockObject(NULL_BRUSH);
	CRect rect(m_nStart,pe.pick());
	pDC->Rectangle(rect);
	//pDC->MoveTo(m_nStart);
	//pDC->LineTo(pe.pick());
	pDC->SelectObject(oldpen);
	
}
