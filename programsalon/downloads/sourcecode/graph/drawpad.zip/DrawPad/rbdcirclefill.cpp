#include "stdafx.h"
#include "rbdcirclefill.h"
#include "DrawPadDoc.h"
#include "math.h"

RBD_CIRCLEFILL::RBD_CIRCLEFILL(const CPoint& start)
{
	m_nStart = start;
}

RBD_CIRCLEFILL::~RBD_CIRCLEFILL()
{

}

void RBD_CIRCLEFILL::DrawXor(CDC *pDC, const PICK_EVENT& pe)
{
	CPen pen, *oldpen;
	CDrawPadDoc *pDoc;
	pDoc = (CDrawPadDoc*)m_pLastView->GetDocument();
	int width = pDoc->m_nWidth;
	pen.CreatePen(PS_SOLID, width, pDoc->m_nColor);
	pDC->SelectStockObject(NULL_BRUSH);
	CPoint m_nEnd;
	m_nEnd = pe.pick();
	long r;
	r = (long)sqrt(pow((float)(m_nEnd.x - m_nStart.x),2) +
		pow((float)(m_nEnd.y - m_nStart.y),2));

	CRect rect(m_nStart.x - r,m_nStart.y - r,
		m_nStart.x + r,m_nStart.y + r);
//	pen.CreatePen(PS_SOLID, 1, RGB(192,192,192));
	oldpen = pDC->SelectObject(&pen);
	//pDC->MoveTo(m_nStart);
	//pDC->LineTo(pe.pick());
	pDC->Ellipse(rect);
	
	pDC->SelectObject(oldpen);
}
