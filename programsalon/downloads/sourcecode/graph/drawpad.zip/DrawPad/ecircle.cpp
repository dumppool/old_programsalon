#include "stdafx.h"
#include "math.h"
#include "ecircle.h"
#include "pickevent.h"

// This file gives implementation of following class
//   ELINE


IMPLEMENT_SERIAL(ECIRCLE, ENTITY, 0);

void ECIRCLE::Serialize(CArchive &ar)
{
	ENTITY::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_nStart << m_nEnd;
	}
	else
	{
		ar >> m_nStart >> m_nEnd;
	}
}

// copy data from another entity.
int ECIRCLE::CopyData(ENT *another)
{
	if( !another ) return 0;
	ASSERT(another->IsKindOf(RUNTIME_CLASS(ECIRCLE)));
	ECIRCLE *other = (ECIRCLE *)another;
	ENTITY::CopyData(another);
	m_nStart = other->get_start();
	m_nEnd = other->get_end();
	return 1;
}

ECIRCLE::ECIRCLE()
{
}

ECIRCLE::ECIRCLE(const CPoint &p1, const CPoint &p2,int iWidth,COLORREF Color,UINT linestyle)
{
	m_nStart = p1;
	m_nEnd = p2;
	set_line_width(iWidth);
	set_color(Color);
	set_line_style(linestyle);
}

int ECIRCLE::GetGripper(int iGrip, CPoint &pnt)
{
  switch( iGrip ) {
  case 1:
    pnt = m_nStart;
    return 1;
  case 2:
    pnt = m_nEnd;
    return 1;
  default:
    return 0;
  }
}

void ECIRCLE::Draw(CDC *pDC, int state)
{
	SetPen(pDC, state);
	pDC->SelectStockObject(NULL_BRUSH);
	CPen *oldpen = pDC->SelectObject(&DTPen);
	long r;
	r = (long)sqrt(pow((float)(m_nEnd.x - m_nStart.x),2) +
		pow((float)(m_nEnd.y - m_nStart.y),2));

	CRect rect(m_nStart.x - r,m_nStart.y - r,
		m_nStart.x + r,m_nStart.y + r);
	pDC->Ellipse(rect);
	ENTITY::Draw(pDC, state);
	pDC->SelectObject(oldpen);
}

int ECIRCLE::HitTest(CDC *pDC, const PICK_EVENT& pe)
{
	int x,y;
	long d1,d2 ;
	x = pe.x();
	y = pe.y();
	d1 = (long)sqrt((m_nEnd.x - m_nStart.x)*(m_nEnd.x - m_nStart.x)
		+(m_nEnd.y - m_nStart.y)*(m_nEnd.y - m_nStart.y));
	d2 = (long)sqrt((x - m_nStart.x)*(x - m_nStart.x)
		+(y - m_nStart.y)*(y - m_nStart.y));
	if( abs(d1 - d2) < 1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
