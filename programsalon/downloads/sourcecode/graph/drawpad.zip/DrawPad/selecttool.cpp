#include "stdafx.h"
#include "DrawPadDoc.h"
#include "DrawPadView.h"
#include "eselection.h"
#include "selecttool.h"

IMPLEMENT_DYNAMIC(SELECT_TOOL, MOUSE_TOOL)

SELECT_TOOL::SELECT_TOOL()
{
	m_pRbdRect = NULL;
	m_pView = NULL;
}

SELECT_TOOL::~SELECT_TOOL()
{
	//if( m_pRbdRect ) delete m_pRbdRect;
}

int SELECT_TOOL::ProcessEvent(int evType, const PICK_EVENT& pe)
{
	switch( evType ) {
	case WM_LBUTTONDOWN:
		m_nStart = pe.pick();
		m_nEnd = pe.pick();
		m_pView = pe.view();
		//if( m_pRbdRect ) delete m_pRbdRect;
		//m_pRbdRect = new RBD_RECT(m_nStart);
		//m_pRbdRect->Start(pe);
		evType = 0;
		break;
	case WM_LBUTTONUP:
		//delete m_pRbdRect;
		//m_pRbdRect = NULL;
		m_nEnd = pe.pick();
		Pick();
		evType = 0;
		break;
	}
	return MOUSE_TOOL::ProcessEvent(evType, pe);
}

void SELECT_TOOL::Pick()
{
	
	if( !m_pView ) return ;
	CDrawPadDoc *pDoc = (CDrawPadDoc *)m_pView->GetDocument();
	ASSERT_VALID(pDoc);
	SELECTION *pSel = ((CDrawPadView *)m_pView)->GetSelection();
	if( m_nStart == m_nEnd ) {               // Pick one entity
		ENTITY *ent = NULL;
		if( pDoc->PickEntity(m_nLP, ent) ) {
			if( !(m_nLP.flags() & MK_SHIFT) ) 
				pSel->Clear(TRUE);
			pSel->Add(ent, m_nLP.pick());
		}
		else {
			if( !(m_nLP.flags() & MK_SHIFT) )
				pSel->Clear(TRUE);
		}
	}
	else if( m_nStart.x < m_nEnd.x ) {       // Window selection
	}
	else {                                   // Cross window selection
	}
}

