#include "stdafx.h"

#include "etext.h"

// This file gives implementation of following class
//   ETEXT

// ************************************************************
// implementation of ETEXT
// ************************************************************

IMPLEMENT_SERIAL(ETEXT, ENTITY, 0);

void ETEXT::Serialize(CArchive &ar)
{
	ENTITY::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_nStart << m_nEnd;
	}
	else
	{
		ar >> m_nStart >> m_nEnd;
	}
}

// copy data from another entity.
int ETEXT::CopyData(ENT *another)
{
	if( !another ) return 0;
	ASSERT(another->IsKindOf(RUNTIME_CLASS(ETEXT)));
	ETEXT *other = (ETEXT *)another;
	ENTITY::CopyData(another);
	m_nStart = other->get_start();
	m_nEnd = other->get_end();
	return 1;
}

ETEXT::ETEXT()
{
}

ETEXT::ETEXT(const CPoint &p1, const CPoint &p2,CString str,COLORREF color,LOGFONT font)
{
	m_nStart = p1;
	m_nEnd = p2;
	set_string(str);
	set_color(color);
	set_font(font);
}

int ETEXT::GetGripper(int iGrip, CPoint &pnt)
{
  switch( iGrip ) {
  case 1:
    pnt = m_nStart;
    return 1;
  case 2:
    pnt = m_nEnd;
    return 1;
  default:
    return 0;
  }
}

void ETEXT::Draw(CDC *pDC, int state)
{
	SetPen(pDC, state);
//	set_TEXT_width(2);
	CPen pen(get_line_style(),get_line_width(),get_color());
	CPen *oldpen = pDC->SelectObject(&pen);
	
//	pDC->MoveTo(m_nStart);
//	pDC->TextOut(10,10,"fdsafdsa");
	pDC->SetTextColor(get_color());
	pDC->SetBkMode(TRANSPARENT);
	CFont fnt;
	fnt.CreateFontIndirect(&(get_font()));
	CFont *oldfont = pDC->SelectObject(&fnt);
	pDC->TextOut(m_nStart.x,m_nStart.y,get_string());
	pDC->SelectObject(oldfont);
//	pDC->LineTo(m_nEnd);
	
	pDC->SelectObject(oldpen);
	ENTITY::Draw(pDC, state);
}

int ETEXT::HitTest(CDC *pDC, const PICK_EVENT& pe)
{
	return 0;
}
 
