#include "stdafx.h"
#include "DrawPadDoc.h"

#include "rbdrectangle.h"
#include "rectangletool.h"
#include "erectangle.h"

RECTANGLE_TOOL::RECTANGLE_TOOL()
{
	m_pRbdLine = NULL;
	m_pView = NULL;
}

RECTANGLE_TOOL::~RECTANGLE_TOOL()
{
	if( m_pRbdLine ) delete m_pRbdLine;
}

int RECTANGLE_TOOL::ProcessEvent(int evType, const PICK_EVENT& pe)
{
	switch( evType ) {
	case WM_LBUTTONDOWN:
		m_nStart = pe.pick();
		m_pView = pe.view();
		if( m_pRbdLine ) delete m_pRbdLine;
		m_pRbdLine = new RBD_RECTANGLE(m_nStart);
		m_pRbdLine->Start(pe);
		evType = 0;
		break;
	case WM_LBUTTONUP:
		delete m_pRbdLine;
		m_pRbdLine = NULL;
		m_nEnd = pe.pick();
		CreateRectangle();
		evType = 0;
		break;
	}
	return MOUSE_TOOL::ProcessEvent(evType, pe);
}

void RECTANGLE_TOOL::CreateRectangle()
{
	ASSERT_VALID(m_pView);
	CDrawPadDoc *pDoc = (CDrawPadDoc *)m_pView->GetDocument();
	ASSERT_VALID(pDoc);
	if( m_nStart != m_nEnd )
	{
		UNDO_BEGIN
		pDoc->AddEntity(new ERECTANGLE(m_nStart, m_nEnd,pDoc->m_nWidth,pDoc->m_nColor,pDoc->m_line));
		UNDO_END
	}
}

