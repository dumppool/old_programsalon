// DrawPadView.h : interface of the CDrawPadView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DRAWPADVIEW_H__5B46346F_355B_11D3_B695_000021DE748F__INCLUDED_)
#define AFX_DRAWPADVIEW_H__5B46346F_355B_11D3_B695_000021DE748F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class MOUSE_TOOL;
class ENTITY;
class SELECTION;

class CDrawPadView : public CScrollView
{
protected: // create from serialization only
	CDrawPadView();
	DECLARE_DYNCREATE(CDrawPadView)
	SELECTION *selection;         // selected entity table
	HCURSOR m_HArrow,m_HCross;
	CString m_ClassName;

// Attributes
public:
	CDrawPadDoc* GetDocument();
	CPoint m_bPoint;
	SELECTION *GetSelection() { return selection; }

// Operations
public:
	static MOUSE_TOOL *CurrentTool;
	static void SetTool(MOUSE_TOOL *newtool);
	static CDrawPadView *CurrentView();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDrawPadView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	UINT m_Drawing;
	virtual ~CDrawPadView();
	void DrawEntity(ENTITY *ent, int method);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	void OnMouseEvent(int evType, UINT nFlags, CPoint point);

// Generated message map functions
protected:
	//{{AFX_MSG(CDrawPadView)
	afx_msg void OnLine();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnUpdateLine(CCmdUI* pCmdUI);
	afx_msg void OnCircle();
	afx_msg void OnUpdateCircle(CCmdUI* pCmdUI);
	afx_msg void OnStyle();
	afx_msg void OnUpdateStyle(CCmdUI* pCmdUI);
	afx_msg void OnText();
	afx_msg void OnUpdateText(CCmdUI* pCmdUI);
	afx_msg void OnSelect();
	afx_msg void OnUpdateSelect(CCmdUI* pCmdUI);
	afx_msg void OnRectangle();
	afx_msg void OnUpdateRectangle(CCmdUI* pCmdUI);
	afx_msg void OnEllipse();
	afx_msg void OnUpdateEllipse(CCmdUI* pCmdUI);
	afx_msg void OnCirclefill();
	afx_msg void OnUpdateCirclefill(CCmdUI* pCmdUI);
	afx_msg void OnEllipsefill();
	afx_msg void OnUpdateEllipsefill(CCmdUI* pCmdUI);
	afx_msg void OnRectanglefill();
	afx_msg void OnUpdateRectanglefill(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DrawPadView.cpp
inline CDrawPadDoc* CDrawPadView::GetDocument()
   { return (CDrawPadDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRAWPADVIEW_H__5B46346F_355B_11D3_B695_000021DE748F__INCLUDED_)
