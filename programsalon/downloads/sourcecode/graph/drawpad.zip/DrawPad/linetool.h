#ifndef _LINETOOL_H
#define _LINETOOL_H

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

// ********************************************
// Class name: LINE_TOOL
// Function:   tool to process mouse events
// ********************************************

class RBD_LINE;

class LINE_TOOL : public MOUSE_TOOL {
protected:
	DECLARE_DYNAMIC(LINE_TOOL)
protected:
	CPoint m_nStart;
	CPoint m_nEnd;
	CView *m_pView;
	RBD_LINE *m_pRbdLine;

public:
	LINE_TOOL();
	virtual ~LINE_TOOL();

	virtual int ProcessEvent(int evType, const PICK_EVENT& pe);

private:
	void CreateLine();
};

#endif
