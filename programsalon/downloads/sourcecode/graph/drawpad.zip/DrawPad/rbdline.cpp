#include "stdafx.h"
#include "rbdline.h"
#include "DrawPadDoc.h"

RBD_LINE::RBD_LINE(const CPoint& start)
{
	m_nStart = start;
}

RBD_LINE::~RBD_LINE()
{

}

void RBD_LINE::DrawXor(CDC *pDC, const PICK_EVENT& pe)
{
	CPen pen, *oldpen;
	CDrawPadDoc *pDoc;
	pDoc = (CDrawPadDoc*)m_pLastView->GetDocument();
	int width = pDoc->m_nWidth;
	pen.CreatePen(PS_SOLID, width, pDoc->m_nColor);
//	pen.CreatePen(PS_SOLID, 1, RGB(192,192,192));
	oldpen = pDC->SelectObject(&pen);
	pDC->MoveTo(m_nStart);
	pDC->LineTo(pe.pick());
	pDC->SelectObject(oldpen);
}
