#ifndef _HCENTITY_H
#define _HCENTITY_H

#define DRAWNORM       0
#define DRAWDEL        1
#define DRAWSEL        2
#define DRAWACTIVE     3

class CDrawPadDoc;
class PICK_EVENT;

#define DECLARE_BACKUP(name) \
	public: \
	virtual void bufferout(void *&buf ) const \
	{ \
		buf = new char[sizeof(*this)]; \
		memcpy(buf, this, sizeof(*this)); \
	} \
	virtual void bufferin(void *&buf) \
	{ \
		memcpy(this, buf, sizeof(*this)); \
	} \
	virtual int CopyData(ENT *); \
	name(name &other) { CopyData((ENT *)&other); } \
	virtual ENT *Clone() { return (ENT *)(new name(*this)); } \
	virtual void Serialize(CArchive& ar);

  
// The generic data structure entity. Provide rollback and saving
// mechanism.
class ENT : public CObject {
	DECLARE_SERIAL(ENT);
protected:
	CDrawPadDoc* m_pDocument;

protected:
	// make backup record of the entity to bulletin
	// This routine usually calls bufferize() method.
	void backup();

public:
	// Entity constructor, initialising common entries, and
	// creating a bulletin.
	ENT();
	~ENT();
	virtual void lose();

	// access protected data
	CDrawPadDoc* GetDocument() const { return m_pDocument; }
	virtual void SetDocument(CDrawPadDoc* pDoc) { m_pDocument = pDoc; }

	DECLARE_BACKUP(ENT)

	virtual void Draw(CDC *pDC, int state) {}
	void Invalidate();

};

class ENTITY : public ENT {
	DECLARE_SERIAL(ENTITY);
private:
	int m_nColor;
	int m_nLineWidth;

public:
	int get_color() const { return m_nColor; }
	int get_line_width() const { return m_nLineWidth; }
	void set_color(int newcolor) { backup(); m_nColor = newcolor; }
	void set_line_width(int newlw) { backup(); m_nLineWidth = newlw; }

	int SetPen(CDC *pDC);

	ENTITY();
	~ENTITY();

	DECLARE_BACKUP(ENTITY)

	int IsGrip(const CPoint& key);
	void DrawGripper(CDC *pDC, const Vector &pnt);
	void DrawGrippers(CDC *pDC);

	virtual int GetMaxGrip() { return 0; }
	virtual int GetGripper(int iGrip, CPoint& pnt) { return 0; }

	virtual void Draw(CDC *pDC, int state) { if( state==DRAWACTIVE ) DrawGrippers(pDC); }
	virtual int HitTest(CDC *pDC, const PICK_EVENT& pe) { return 0; }

};

#endif

