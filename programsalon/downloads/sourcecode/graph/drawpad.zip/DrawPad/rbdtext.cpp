#include "stdafx.h"
#include "rbdTEXT.h"
#include "DrawPadDoc.h"

RBD_TEXT::RBD_TEXT(const CPoint& start)
{
	m_nStart = start;
}

RBD_TEXT::~RBD_TEXT()
{

}

void RBD_TEXT::DrawXor(CDC *pDC, const PICK_EVENT& pe)
{
	CPen pen, *oldpen;
	CDrawPadDoc *pDoc;
	pDoc = (CDrawPadDoc*)m_pLastView->GetDocument();
	int width = pDoc->m_nWidth;
	pen.CreatePen(PS_SOLID, width, pDoc->m_nColor);
	oldpen = pDC->SelectObject(&pen);
	pDC->SelectStockObject(NULL_BRUSH);
//	CPoint point(m_nStart.x + 50,m_nStart.y + 20);
//	CRect rect(m_nStart,point);
	pDC->SetBkMode(TRANSPARENT);
	CFont fnt;
	fnt.CreateFontIndirect(&(pDoc->m_Font));
	CFont *oldfont = pDC->SelectObject(&fnt);
	pDC->TextOut(m_nStart.x,m_nStart.y,pDoc->m_String);
	pDC->SelectObject(oldfont);

	//	pDC->Rectangle(rect);
	pDC->SelectObject(oldpen);
}
