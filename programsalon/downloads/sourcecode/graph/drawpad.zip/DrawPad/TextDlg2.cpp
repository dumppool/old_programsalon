// TextDlg2.cpp : implementation file
//

#include "stdafx.h"
#include "drawpad.h"
#include "TextDlg2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTextDlg2 dialog


CTextDlg2::CTextDlg2(CWnd* pParent /*=NULL*/)
	: CDialog(CTextDlg2::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTextDlg2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTextDlg2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTextDlg2)
	DDX_Control(pDX, IDC_EDIT1, m_wndText);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTextDlg2, CDialog)
	//{{AFX_MSG_MAP(CTextDlg2)
	ON_BN_CLICKED(IDC_H_RADIO, OnHRadio)
	ON_BN_CLICKED(IDC_V_RADIO, OnVRadio)
	ON_BN_CLICKED(IDC_FONT_BUTTON, OnFontButton)
	ON_BN_CLICKED(IDC_CAN_BUTTON, OnCanButton)
	ON_BN_CLICKED(IDC_OK_BUTTON, OnOkButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTextDlg2 message handlers

void CTextDlg2::OnHRadio() 
{
	// TODO: Add your control notification handler code here
	
}

void CTextDlg2::OnVRadio() 
{
	// TODO: Add your control notification handler code here
	
}

void CTextDlg2::OnFontButton() 
{
	// TODO: Add your control notification handler code here
	CFontDialog dlg;
	if(dlg.DoModal()==IDOK)
	{
		dlg.GetCurrentFont(&m_dlgFont);
	}
}

void CTextDlg2::OnCanButton() 
{
	// TODO: Add your control notification handler code here
	OnCancel();
}

void CTextDlg2::OnOkButton() 
{
	// TODO: Add your control notification handler code here
	m_wndText.GetWindowText(m_edit1);
	OnOK();
}
