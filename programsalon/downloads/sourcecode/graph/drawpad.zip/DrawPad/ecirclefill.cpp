#include "stdafx.h"
#include "math.h"
#include "ecirclefill.h"
#include "pickevent.h"

// This file gives implementation of following class
//   ELINE


IMPLEMENT_SERIAL(ECIRCLEFILL, ENTITY, 0);

void ECIRCLEFILL::Serialize(CArchive &ar)
{
	ENTITY::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_nStart << m_nEnd;
	}
	else
	{
		ar >> m_nStart >> m_nEnd;
	}
}

// copy data from another entity.
int ECIRCLEFILL::CopyData(ENT *another)
{
	if( !another ) return 0;
	ASSERT(another->IsKindOf(RUNTIME_CLASS(ECIRCLEFILL)));
	ECIRCLEFILL *other = (ECIRCLEFILL *)another;
	ENTITY::CopyData(another);
	m_nStart = other->get_start();
	m_nEnd = other->get_end();
	return 1;
}

ECIRCLEFILL::ECIRCLEFILL()
{
}

ECIRCLEFILL::ECIRCLEFILL(const CPoint &p1, const CPoint &p2,COLORREF color,UINT Brush)
{
	m_nStart = p1;
	m_nEnd = p2;
	set_color(color);
	set_brush(Brush);
}

int ECIRCLEFILL::GetGripper(int iGrip, CPoint &pnt)
{
  switch( iGrip ) {
  case 1:
    pnt = m_nStart;
    return 1;
  case 2:
    pnt = m_nEnd;
    return 1;
  default:
    return 0;
  }
}

void ECIRCLEFILL::Draw(CDC *pDC, int state)
{
//	SetPen(pDC, state);
	SetBrush(pDC,state);
	CBrush *oldbrush = pDC->SelectObject(&DTBrush);
	long r;
	r = (long)sqrt(pow((float)(m_nEnd.x - m_nStart.x),2) +
		pow((float)(m_nEnd.y - m_nStart.y),2));

	CRect rect(m_nStart.x - r,m_nStart.y - r,
		m_nStart.x + r,m_nStart.y + r);
	pDC->Ellipse(rect);
	//pDC->MoveTo(m_nStart);
	//pDC->LineTo(m_nEnd);
	ENTITY::Draw(pDC, state);
	pDC->SelectObject(oldbrush);
}

int ECIRCLEFILL::HitTest(CDC *pDC, const PICK_EVENT& pe)
{
	int x,y;
	long d1,d2 ;
	x = pe.x();
	y = pe.y();
	d1 = (long)sqrt((m_nEnd.x - m_nStart.x)*(m_nEnd.x - m_nStart.x)
		+(m_nEnd.y - m_nStart.y)*(m_nEnd.y - m_nStart.y));
	d2 = (long)sqrt((x - m_nStart.x)*(x - m_nStart.x)
		+(y - m_nStart.y)*(y - m_nStart.y));
	if( d1 - d2 > 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
	
	
}
