#include "stdafx.h"
#include "DrawPadDoc.h"

#include "rbdline.h"
#include "linetool.h"
#include "eline.h"

IMPLEMENT_DYNAMIC(LINE_TOOL, MOUSE_TOOL)

LINE_TOOL::LINE_TOOL()
{
	m_pRbdLine = NULL;
	m_pView = NULL;
}

LINE_TOOL::~LINE_TOOL()
{
	if( m_pRbdLine ) delete m_pRbdLine;
}

int LINE_TOOL::ProcessEvent(int evType, const PICK_EVENT& pe)
{
	switch( evType ) {
	case WM_LBUTTONDOWN:
		m_nStart = pe.pick();
		m_pView = pe.view();
		if( m_pRbdLine ) delete m_pRbdLine;
		m_pRbdLine = new RBD_LINE(m_nStart);
		m_pRbdLine->Start(pe);
		evType = 0;
		break;
	case WM_LBUTTONUP:
		delete m_pRbdLine;
		m_pRbdLine = NULL;
		m_nEnd = pe.pick();
		CreateLine();
		evType = 0;
		break;
	}
	return MOUSE_TOOL::ProcessEvent(evType, pe);
}

void LINE_TOOL::CreateLine()
{
	ASSERT_VALID(m_pView);
	CDrawPadDoc *pDoc = (CDrawPadDoc *)m_pView->GetDocument();
	ASSERT_VALID(pDoc);
	if( m_nStart != m_nEnd )
	{
		UNDO_BEGIN
		pDoc->AddEntity(new ELINE(m_nStart, m_nEnd,pDoc->m_nWidth,pDoc->m_nColor,pDoc->m_line));
		UNDO_END
	}
}

