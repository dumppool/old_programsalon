#ifndef _RBDLINE_H
#define _RBDLINE_H

// **********************************************
// Class: RBD_LINE
// Function: Display a rubberbanding
// **********************************************

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

class RBD_LINE : public RBD_DRIVER {
protected:
	CPoint m_nStart;

public:
	RBD_LINE(const CPoint& start);
	virtual ~RBD_LINE();

	virtual void DrawXor(CDC *pDC, const PICK_EVENT& pe);
};

#endif
