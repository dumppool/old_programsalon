// DrawPadDoc.cpp : implementation of the CDrawPadDoc class
//

#include "stdafx.h"
#include "DrawPad.h"

#include "DrawPadDoc.h"
#include "DrawPadView.h"
#include "pickevent.h"
#include "entity.h"
#include "eselection.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDrawPadDoc

IMPLEMENT_DYNCREATE(CDrawPadDoc, CDocument)

BEGIN_MESSAGE_MAP(CDrawPadDoc, CDocument)
	//{{AFX_MSG_MAP(CDrawPadDoc)
	ON_COMMAND(ID_COLOR, OnColor)
	ON_COMMAND(ID_C_BLUE, OnCBlue)
	ON_UPDATE_COMMAND_UI(ID_C_BLUE, OnUpdateCBlue)
	ON_COMMAND(ID_C_GREEN, OnCGreen)
	ON_UPDATE_COMMAND_UI(ID_C_GREEN, OnUpdateCGreen)
	ON_COMMAND(ID_C_RED, OnCRed)
	ON_UPDATE_COMMAND_UI(ID_C_RED, OnUpdateCRed)
	ON_COMMAND(ID_C_YELLOW, OnCYellow)
	ON_UPDATE_COMMAND_UI(ID_C_YELLOW, OnUpdateCYellow)
	ON_COMMAND(ID_LINE_1, OnLine1)
	ON_UPDATE_COMMAND_UI(ID_LINE_1, OnUpdateLine1)
	ON_COMMAND(ID_LINE_2, OnLine2)
	ON_UPDATE_COMMAND_UI(ID_LINE_2, OnUpdateLine2)
	ON_COMMAND(ID_LINE_3, OnLine3)
	ON_UPDATE_COMMAND_UI(ID_LINE_3, OnUpdateLine3)
	ON_COMMAND(ID_EDIT_REDO, OnEditRedo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REDO, OnUpdateEditRedo)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_COMMAND(ID_PS_DASH, OnPsDash)
	ON_UPDATE_COMMAND_UI(ID_PS_DASH, OnUpdatePsDash)
	ON_COMMAND(ID_PS_DASHDOT, OnPsDashdot)
	ON_UPDATE_COMMAND_UI(ID_PS_DASHDOT, OnUpdatePsDashdot)
	ON_COMMAND(ID_PS_DASHDOTDOT, OnPsDashdotdot)
	ON_UPDATE_COMMAND_UI(ID_PS_DASHDOTDOT, OnUpdatePsDashdotdot)
	ON_COMMAND(ID_PS_DOT, OnPsDot)
	ON_UPDATE_COMMAND_UI(ID_PS_DOT, OnUpdatePsDot)
	ON_COMMAND(ID_PS_SOLID, OnPsSolid)
	ON_UPDATE_COMMAND_UI(ID_PS_SOLID, OnUpdatePsSolid)
	ON_COMMAND(ID_HS_BDIAGONAL, OnHsBdiagonal)
	ON_UPDATE_COMMAND_UI(ID_HS_BDIAGONAL, OnUpdateHsBdiagonal)
	ON_COMMAND(ID_HS_CROSS, OnHsCross)
	ON_UPDATE_COMMAND_UI(ID_HS_CROSS, OnUpdateHsCross)
	ON_COMMAND(ID_HS_DIAGCROSS, OnHsDiagcross)
	ON_UPDATE_COMMAND_UI(ID_HS_DIAGCROSS, OnUpdateHsDiagcross)
	ON_COMMAND(ID_HS_FDIAGONAL, OnHsFdiagonal)
	ON_UPDATE_COMMAND_UI(ID_HS_FDIAGONAL, OnUpdateHsFdiagonal)
	ON_COMMAND(ID_HS_HORIZONTAL, OnHsHorizontal)
	ON_UPDATE_COMMAND_UI(ID_HS_HORIZONTAL, OnUpdateHsHorizontal)
	ON_COMMAND(ID_HS_SOLID, OnHsSolid)
	ON_UPDATE_COMMAND_UI(ID_HS_SOLID, OnUpdateHsSolid)
	ON_COMMAND(ID_HS_VERTICAL, OnHsVertical)
	ON_UPDATE_COMMAND_UI(ID_HS_VERTICAL, OnUpdateHsVertical)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDrawPadDoc construction/destruction

CDrawPadDoc::CDrawPadDoc()
{
	// TODO: add one-time construction code here
	m_nColor = RGB(0,192,192);
	m_nWidth = 1;
	UndoNestLevel = 0;
	m_line=PS_SOLID;
	m_brush=HS_SOLID;
	m_String="";
//	m_Font={-12,8,0,0,0,0,0,0,0,0,0,0,0,"Arial"}
}

CDrawPadDoc::~CDrawPadDoc()
{
	for( POSITION pos = entities.GetHeadPosition(); pos != NULL; ) {
		delete entities.GetNext(pos);
	}
}

BOOL CDrawPadDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}
int CDrawPadDoc::Insert(ENTITY *ent)
{
	if( !ent || entities.Find(ent) ) return FALSE;
	entities.AddTail(ent);
    ent->SetDocument(this);
    DrawEntity(ent, DRAWNORM);
    SetModifiedFlag();
	return TRUE;
}
int CDrawPadDoc::Remove(ENTITY *ent)
{
	POSITION pos;
	if( !ent || (pos = entities.Find(ent)) == NULL ) return FALSE;
	DrawEntity(ent, DRAWDEL);
	entities.RemoveAt(pos);
	SetModifiedFlag();
	return TRUE;
}

void CDrawPadDoc::AddEntity(ENTITY *ent)
{
/*	((ENTITY*)object)->set_line_width(m_nWidth);
	((ENTITY*)object)->set_color(m_nColor);
	entities.Add((CObject *)object);*/
/*	entities.AddTail(ent);
	DrawEntity(ent, DRAWNORM);*/
	if( Insert(ent) )
		undoBuf.insertObject(ent);
	
}
void CDrawPadDoc::RemoveEntity(ENTITY *ent)
{
	if( Remove(ent) )
		undoBuf.deleteObject(ent);
}

void CDrawPadDoc::Draw(CDC *pDC)
{
/*	for( int i = 0; i < entities.GetSize(); i ++ )
	{
		((ENTITY *)entities[i])->Draw(pDC, DRAWNORM);
		
	}*/
	for( POSITION pos = entities.GetHeadPosition(); pos != NULL; ) {
		ENTITY *ent = (ENTITY *)entities.GetNext(pos);
		ent->Draw(pDC, DRAWNORM);
	}
}

void CDrawPadDoc::DrawEntity(ENTITY * ent, int method)
{
	for( POSITION pos = GetFirstViewPosition(); pos != NULL; ) {
		CDrawPadView *view = (CDrawPadView *)GetNextView(pos);
		ASSERT(view->IsKindOf(RUNTIME_CLASS(CDrawPadView)));
		view->DrawEntity(ent, method);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDrawPadDoc serialization
int CDrawPadDoc::PickEntity(const PICK_EVENT &pe, ENTITY *&ent)
{
	ent = NULL;
	int success = 0;
	for( POSITION pos = entities.GetHeadPosition(); pos != NULL; ) {
		ENTITY *anent = (ENTITY *)entities.GetNext(pos);
		if( anent->HitTest(0, pe) ) {
			success = 1;
			ent = anent;
			break;
		}
	}
	return success;
}

void CDrawPadDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
		ar << entities.GetCount();
		for( POSITION pos = entities.GetHeadPosition(); pos != NULL; ) {
			ENTITY *ent = (ENTITY *)entities.GetNext(pos);
			ar << ent;
		}
	}
	else
	{
		// TODO: add loading code here
		int count;
		ar >> count;
		for( ; count > 0; count -- ) {
			ENTITY *ent = NULL;
			ar >> ent;
			AddEntity(ent);
		}

	}
}

/////////////////////////////////////////////////////////////////////////////
// CDrawPadDoc diagnostics

#ifdef _DEBUG
void CDrawPadDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDrawPadDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG
CDrawPadDoc *CDrawPadDoc::CurrentDoc()
{
	CDrawPadView *view = CDrawPadView::CurrentView();
	if( !view ) return 0;
	return view->GetDocument();
}
void CDrawPadDoc::ClearSelection()
{
	for( POSITION pos = GetFirstViewPosition(); pos != NULL; ) {
		CDrawPadView *view = (CDrawPadView *)GetNextView(pos);
		view->GetSelection()->Clear(TRUE);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDrawPadDoc commands

void CDrawPadDoc::OnColor() 
{
	// TODO: Add your command handler code here
	CColorDialog dlg;
	int answer = dlg.DoModal();
	if (answer == IDOK)
	{
		m_nColor = dlg.GetColor();
	}
}


void CDrawPadDoc::OnCBlue() 
{
	// TODO: Add your command handler code here
	m_nColor=RGB(0,0,255);
}

void CDrawPadDoc::OnUpdateCBlue(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_nColor==RGB(0,0,255)?TRUE:FALSE);
}

void CDrawPadDoc::OnCGreen() 
{
	// TODO: Add your command handler code here
	m_nColor=RGB(0,255,0);
}

void CDrawPadDoc::OnUpdateCGreen(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_nColor==RGB(0,255,0)?TRUE:FALSE);	
}

void CDrawPadDoc::OnCRed() 
{
	// TODO: Add your command handler code here
	m_nColor=RGB(255,0,0);
}

void CDrawPadDoc::OnUpdateCRed(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_nColor==RGB(255,0,0)?TRUE:FALSE);	
}

void CDrawPadDoc::OnCYellow() 
{
	// TODO: Add your command handler code here
	m_nColor=RGB(255,255,0);
}

void CDrawPadDoc::OnUpdateCYellow(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_nColor==RGB(255,255,0)?TRUE:FALSE);	
}

void CDrawPadDoc::OnLine1() 
{
	// TODO: Add your command handler code here
	m_nWidth=1;
}

void CDrawPadDoc::OnUpdateLine1(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_nWidth==1?TRUE:FALSE);		
}

void CDrawPadDoc::OnLine2() 
{
	// TODO: Add your command handler code here
	m_nWidth=2;	
}

void CDrawPadDoc::OnUpdateLine2(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_nWidth==2?TRUE:FALSE);			
}

void CDrawPadDoc::OnLine3() 
{
	// TODO: Add your command handler code here
	m_nWidth=3;	
}

void CDrawPadDoc::OnUpdateLine3(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_nWidth==3?TRUE:FALSE);			
}


void CDrawPadDoc::OnEditRedo() 
{
	// TODO: Add your command handler code here
	if( !redoBuf.readyUndo() ) return ;
	ClearSelection();
	undoBuf.startRecord();
	EventItem *event;
	if( RBD_DRIVER::CurrentRBD )
		RBD_DRIVER::CurrentRBD->Stop();
	while( (event = redoBuf.popEventItem()) != NULL ) {
		switch (event->type) {
		case EventItem::INSOBJ:
			RemoveEntity((ENTITY *)event->obj);
			break;
		case EventItem::MODOBJ:
			undoBuf.modifyObject(event->obj);
			DrawEntity((ENTITY *)event->obj, DRAWDEL);
			event->obj->CopyData(event->clone);
			DrawEntity((ENTITY *)event->obj, DRAWAUTO);
			delete event->clone;
			break;
		case EventItem::DELOBJ:
			AddEntity((ENTITY *)event->obj);
			break;
		}
		delete event;
	}
	if( RBD_DRIVER::CurrentRBD )
//		RBD_DRIVER::CurrentRBD->Start();
	redoBuf.popEventGroup();	
}

void CDrawPadDoc::OnUpdateEditRedo(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(redoBuf.readyUndo());
	
}

void CDrawPadDoc::OnEditUndo() 
{
	// TODO: Add your command handler code here
	if ( !undoBuf.readyUndo() ) return ;
	ClearSelection();
	undoBuf.stopRecord();
	redoBuf.startRecord();
	EventItem *event;
	if( RBD_DRIVER::CurrentRBD )
		RBD_DRIVER::CurrentRBD->Stop();
	while( (event = undoBuf.popEventItem()) != NULL ) {
		switch (event->type) {
		case EventItem::INSOBJ:
			redoBuf.deleteObject(event->obj);
			RemoveEntity((ENTITY *)event->obj);
			break;
		case EventItem::MODOBJ:
			redoBuf.modifyObject(event->obj);
			DrawEntity((ENTITY *)event->obj, DRAWDEL);
			event->obj->CopyData(event->clone);
			delete event->clone;
			DrawEntity((ENTITY *)event->obj, DRAWAUTO);
			break;
		case EventItem::DELOBJ:
			redoBuf.insertObject(event->obj);
			AddEntity((ENTITY *)event->obj);
			break;
		}
		delete event;
	}
	if( RBD_DRIVER::CurrentRBD )
//		RBD_DRIVER::CurrentRBD->Start();
	undoBuf.popEventGroup();	
}

void CDrawPadDoc::OnUpdateEditUndo(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(undoBuf.readyUndo());
	
}

void CDrawPadDoc::OnPsDash() 
{
	// TODO: Add your command handler code here
	m_line=PS_DASH;
}

void CDrawPadDoc::OnUpdatePsDash(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_line==PS_DASH?TRUE:FALSE);			
}

void CDrawPadDoc::OnPsDashdot() 
{
	// TODO: Add your command handler code here
	m_line=PS_DASHDOT;	
}

void CDrawPadDoc::OnUpdatePsDashdot(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_line==PS_DASHDOT?TRUE:FALSE);				
}

void CDrawPadDoc::OnPsDashdotdot() 
{
	// TODO: Add your command handler code here
	m_line=PS_DASHDOTDOT;	
}

void CDrawPadDoc::OnUpdatePsDashdotdot(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_line==PS_DASHDOTDOT?TRUE:FALSE);				
}

void CDrawPadDoc::OnPsDot() 
{
	// TODO: Add your command handler code here
	m_line=PS_DOT;	
}

void CDrawPadDoc::OnUpdatePsDot(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_line==PS_DOT?TRUE:FALSE);				
}

void CDrawPadDoc::OnPsSolid() 
{
	// TODO: Add your command handler code here
	m_line=PS_SOLID;	
}

void CDrawPadDoc::OnUpdatePsSolid(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_line==PS_SOLID?TRUE:FALSE);				
}

void CDrawPadDoc::OnHsBdiagonal() 
{
	// TODO: Add your command handler code here
	m_brush=HS_BDIAGONAL;
}

void CDrawPadDoc::OnUpdateHsBdiagonal(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_brush==HS_BDIAGONAL?TRUE:FALSE);					
}

void CDrawPadDoc::OnHsCross() 
{
	// TODO: Add your command handler code here
	m_brush=HS_CROSS;	
}

void CDrawPadDoc::OnUpdateHsCross(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_brush==HS_CROSS?TRUE:FALSE);						
}

void CDrawPadDoc::OnHsDiagcross() 
{
	// TODO: Add your command handler code here
	m_brush=HS_DIAGCROSS;	
}

void CDrawPadDoc::OnUpdateHsDiagcross(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_brush==HS_DIAGCROSS?TRUE:FALSE);						
}

void CDrawPadDoc::OnHsFdiagonal() 
{
	// TODO: Add your command handler code here
	m_brush=HS_FDIAGONAL;	
}

void CDrawPadDoc::OnUpdateHsFdiagonal(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_brush==HS_FDIAGONAL?TRUE:FALSE);						
}

void CDrawPadDoc::OnHsHorizontal() 
{
	// TODO: Add your command handler code here
	m_brush=HS_HORIZONTAL;	
}

void CDrawPadDoc::OnUpdateHsHorizontal(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_brush==HS_HORIZONTAL?TRUE:FALSE);						
}

void CDrawPadDoc::OnHsSolid() 
{
	// TODO: Add your command handler code here
	m_brush=HS_SOLID;	
}

void CDrawPadDoc::OnUpdateHsSolid(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_brush==HS_SOLID?TRUE:FALSE);						
}

void CDrawPadDoc::OnHsVertical() 
{
	// TODO: Add your command handler code here
	m_brush=HS_VERTICAL;	
}

void CDrawPadDoc::OnUpdateHsVertical(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_brush==HS_VERTICAL?TRUE:FALSE);						
}
