#ifndef _EUNDO_H
#define _EUNDO_H

#include <afxtempl.h>

class ENT;

class EventItem {
public:
	enum EventType { INSOBJ,MODOBJ,DELOBJ,MODVAR };
	EventItem() {}
	EventItem(EventType t, ENT *o, ENT *p) { type=t; obj=o; clone=p; }
	EventType type;
	ENT *clone;
	ENT *obj;
};

class EventGroup {
public:
	EventGroup() {}
	CList<EventItem*,EventItem*> events;
};

class UndoBuffer {
public:
	UndoBuffer();
	~UndoBuffer();
	void startRecord();
	void stopRecord();
	void pushEventItem(EventItem *e);
	int insertObject(ENT *obj);
	int deleteObject(ENT *obj);
	int modifyObject(ENT *obj);
	int modifySysVar(ENT *obj);
  
	void clear();
	int getStatus(){ return status;};
	BOOL readyUndo();
	int popEventGroup();
	EventItem *popEventItem();
  
private:
	int existObject(ENT *obj);
	CList<EventGroup*,EventGroup*> eventGroups;
	EventGroup *curEventGroup;
	int status;
		
};

void api_undo_rec_start();
void api_undo_rec_stop();

#define UNDO_BEGIN api_undo_rec_start(); {
#define UNDO_END   } api_undo_rec_stop();

#endif
