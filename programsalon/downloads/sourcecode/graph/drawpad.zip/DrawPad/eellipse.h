#ifndef _EELLIPSE_H
#define _EELLIPSE_H

#ifndef _ENTITY_H
#include "entity.h"
#endif

class EELLIPSE;

// *********************************************************
// class ELINE
// *********************************************************
class EELLIPSE : public ENTITY {
  DECLARE_SERIAL(EELLIPSE);

private:
	CPoint  m_nStart;
	CPoint  m_nEnd;

public:
	EELLIPSE();
	EELLIPSE(const CPoint &p1, const CPoint &p2,int iWidth,COLORREF Color,UINT linestyle);

	// access data
	CPoint get_start() const { return m_nStart; }
	CPoint get_end() const { return m_nEnd; }
	void set_start(const CPoint &start) { backup(); m_nStart = start; }
	void set_end(const CPoint &end) { backup(); m_nEnd = end; }

	DECLARE_BACKUP(EELLIPSE)

	virtual int GetMaxGrip() { return 2; }
	virtual int GetGripper(int iGrip, CPoint& pnt);

	virtual void Draw(CDC *pDC, int state);
	virtual int HitTest(CDC *pDC, const PICK_EVENT& pe);

};


#endif