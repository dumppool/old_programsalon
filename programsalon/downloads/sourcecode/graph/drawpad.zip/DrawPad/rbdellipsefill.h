#ifndef _RBDELLIPSEFILL_H
#define _RBDELLIPSEFILL_H
// Class: RBD_LINE
// Function: Display a rubberbanding
// **********************************************

#ifndef _PICKEVENT_H
#include "pickevent.h"
#endif

class RBD_ELLIPSEFILL : public RBD_DRIVER {
protected:
	CPoint m_nStart;

public:
	RBD_ELLIPSEFILL(const CPoint& start);
	virtual ~RBD_ELLIPSEFILL();

	virtual void DrawXor(CDC *pDC, const PICK_EVENT& pe);
};

#endif
