#include "stdafx.h"
#include "pickevent.h"
#include "eline.h"

// This file gives implementation of following class
//   ELINE

// ************************************************************
// implementation of ELINE
// ************************************************************

IMPLEMENT_SERIAL(ELINE, ENTITY, 0);

void ELINE::Serialize(CArchive &ar)
{
	ENTITY::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_nStart << m_nEnd;
	}
	else
	{
		ar >> m_nStart >> m_nEnd;
	}
}

// copy data from another entity.
int ELINE::CopyData(ENT *another)
{
	if( !another ) return 0;
	ASSERT(another->IsKindOf(RUNTIME_CLASS(ELINE)));
	ELINE *other = (ELINE *)another;
	ENTITY::CopyData(another);
	m_nStart = other->get_start();
	m_nEnd = other->get_end();
	return 1;
}

ELINE::ELINE()
{

}

ELINE::ELINE(const CPoint &p1, const CPoint &p2,int iWidth,COLORREF Color,UINT linestyle)
{
	m_nStart = p1;
	m_nEnd = p2;
	set_line_width(iWidth);
	set_color(Color);
	set_line_style(linestyle);
}

int ELINE::GetGripper(int iGrip, CPoint &pnt)
{
  switch( iGrip ) {
  case 1:
    pnt = m_nStart;
    return 1;
  case 2:
    pnt = m_nEnd;
    return 1;
  default:
    return 0;
  }
}

void ELINE::Draw(CDC *pDC, int state)
{
/*	SetPen(pDC, state);
//	set_line_width(2);
	CPen pen(PS_SOLID,get_line_width(),get_color());
	CPen *oldpen = pDC->SelectObject(&pen);

	pDC->MoveTo(m_nStart);
	pDC->LineTo(m_nEnd);
	
	pDC->SelectObject(oldpen);
	ENTITY::Draw(pDC, state);*/
	SetPen(pDC, state);
	pDC->SelectStockObject(NULL_BRUSH);
	CPen *oldpen = pDC->SelectObject(&DTPen);
	pDC->MoveTo(m_nStart);
	pDC->LineTo(m_nEnd);
	ENTITY::Draw(pDC, state);
	pDC->SelectObject(oldpen);
}

int ELINE::HitTest(CDC *pDC, const PICK_EVENT& pe)
{
	extern void SetClipWindow(double x1, double y1, double x2, double y2);
	extern int LineThrough(double x1, double y1, double x2, double y2);
	SetClipWindow(pe.x()-3, pe.y()-3, pe.x()+3, pe.y()+3);
	return LineThrough(m_nStart.x, m_nStart.y, m_nEnd.x, m_nEnd.y);
}
 

#define LEFT    1
#define RIGHT   2
#define BOTTOM  4
#define TOP     8
static double XMIN,XMAX,YMIN,YMAX;

// return Cohen-Sutherland code for clipping or picking
static int Cohen_encode(double x, double y)
{
	int code = 0;
	if( x<XMIN ) code += LEFT;
	else if( x>XMAX ) code += RIGHT;
	if( y<YMIN ) code += BOTTOM;
	else if( y>YMAX ) code += TOP;
	return code;
}

void SetClipWindow(double x1, double y1, double x2, double y2)
{
	XMIN = x1;
	YMIN = y1;
	XMAX = x2;
	YMAX = y2;
}

// check if the the line cross through the pick box. The clipped end points
// of the line is not returned.
int LineThrough(double x1, double y1, double x2, double y2)
{
	int bm1, bm2, bm, bm12;
	bm1 = Cohen_encode(x1, y1);
	bm2 = Cohen_encode(x2, y2);
	double x, y;
	while( bm1!=0 && bm2!=0 ) {
		if( (bm1 & bm2) != 0 ) return 0;
		bm12 = bm1|bm2;
		if( bm12==12 || bm12==3 ) return 1;
		bm = bm1;
		if( bm&LEFT )
			x = XMIN, y = y1+(y2-y1)*(x-x1)/(x2-x1);
		else if( bm&RIGHT )
			x = XMAX, y = y1+(y2-y1)*(x-x1)/(x2-x1);
		else if( bm&BOTTOM )
			y = YMIN, x = x1+(x2-x1)*(y-y1)/(y2-y1);
		else if( bm&TOP )
			y = YMAX, x = x1+(x2-x1)*(y-y1)/(y2-y1);
		x1 = x, y1 = y, bm1 = Cohen_encode(x1,y1);
	}
	return 1;
}


