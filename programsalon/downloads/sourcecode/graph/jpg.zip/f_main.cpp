//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#define HAVE_BOOLEAN
#include "jpglib/jpeglib.h"
#include "f_main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------


void TForm1::ReadJPEGBitmap(const char * file_name, Graphics::TBitmap *bitmap)
{
	jpeg_decompress_struct cinfo;
    jpeg_error_mgr jerr;
    FILE *input_file;

    input_file = fopen(file_name, "rb");
    if (input_file == NULL)
    	throw "Can't open file";

	/* Initialize the JPEG decompression object with default error handling. */
	cinfo.err = jpeg_std_error(&jerr);
	jpeg_create_decompress(&cinfo);

    jpeg_stdio_src(&cinfo, input_file);
    if (!jpeg_read_header(&cinfo, TRUE))
    	throw "Jpeg header do not match";

    jpeg_start_decompress(&cinfo);
    bitmap->HandleType = bmDIB;
    bitmap->PixelFormat = pf24bit;
    bitmap->Width = cinfo.output_width;
    bitmap->Height = cinfo.output_height;
    while (cinfo.output_scanline < cinfo.output_height)
    {
        unsigned char *scanline = (unsigned char *)bitmap->ScanLine[cinfo.output_scanline];
    	int num_scanlines = jpeg_read_scanlines(&cinfo, &scanline, 1);
        if (num_scanlines != 1)
        	throw "Error while decompressing Jpeg file";
        // exchange the order of R & B
        for (unsigned int i=0; i<cinfo.output_width; i++)
        {
        	unsigned char t;
        	t = scanline[i*3];
            scanline[i*3] = scanline[i*3+2];
            scanline[i*3+2] = t;
        }
    }

	jpeg_finish_decompress(&cinfo);
	jpeg_destroy_decompress(&cinfo);
}

void __fastcall TForm1::Button1Click(TObject *Sender)
{
	if (OpenDialog1->Execute())
    {
    	Graphics::TBitmap *bitmap = new Graphics::TBitmap;
    	ReadJPEGBitmap(OpenDialog1->FileName.c_str(), bitmap);
        PaintBox1->Canvas->Draw(0, 0, bitmap);
        delete bitmap;
    }
}
//---------------------------------------------------------------------------

