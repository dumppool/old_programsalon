//---------------------------------------------------------------------------
#ifndef f_mainH
#define f_mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TButton *Button1;
	TPaintBox *PaintBox1;
	TOpenDialog *OpenDialog1;
	void __fastcall Button1Click(TObject *Sender);
private:
    void ReadJPEGBitmap(const char * file_name, Graphics::TBitmap *bitmap);	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
