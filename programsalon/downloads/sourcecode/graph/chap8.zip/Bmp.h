#include "windows.h"
#define IDM_LOADBMP   1
#define IDM_EXIT      2 

#define IDM_HPROJECTION                 40050
#define IDM_VPROJECTION                 40051
#define IDM_SUBTRACTION                 40052
#define IDC_STATIC                      65535
