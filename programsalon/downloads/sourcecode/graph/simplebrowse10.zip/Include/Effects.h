#if !defined(AFX_EFFECT_H__C96CB5BA_13DD_11D1_998B_0000E8CF7630__INCLUDED_)
#define AFX_EFFECT_H__C96CB5BA_13DD_11D1_998B_0000E8CF7630__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define ISLINEPAGE		1
#define ISFILLCOLOR		2
#define ISTEXTURE		4
#define ISFRAME			8
#define ISSHADOW		16

#define IsLineProp		1
#define IsFillProp		2
#define IsFrameProp		3
#define IsShadowProp	4

#include <afxtempl.h>       // MFC template

#define WIDTHBYTE(bits)    (((bits) + 31) / 32 * 4)

typedef CArray <CPoint,CPoint&> CPointArray;

struct Effect 
{
	int	m_nEffectStyle; // Indicates effect style, 
	                    // it can be any combination of : 
	                    // ISLINEPAGE, ISFILLCOLOR, ISTEXTURE, ISFRAME, ISSHADOW
	
	// line attribures, if m_nEffectStyle don't include ISLINEPAGE, they are ignored
	BOOL	 m_bPen;	// If true, the object's frame need a pen.
	BOOL     m_bArrow;  // indicates whether the object has arrow
	LOGPEN   m_logpen;	// Defines the style, width, and color of a pen
	int		 m_ArrBeginstyle; // 
	int		 m_ArrEndstyle;
	int		 m_ArrBeginSize;
	int		 m_ArrEndSize;
	BOOL  	 m_nIsDrawLine;
	BOOL     m_bPaintBrush;      //Indicate the pen is paint brush type
	int      m_nCurrentLine;     //Plain style
	int      m_nCurrentBrush;    //Paint brush style.

	// gradient fill attribure, if m_nEffectStyle don't include ISFILLCOLOR, they are ignored
	int	  m_nSelStyle;       //Record the selected color button
	int	  m_nSelShading;     //Record the selected direction to fill
    int 	  m_nSelColor;
	int      m_nSemiTrans;   // it is not useful now
    int      m_nPreSet;
	float    m_nPerBar;          //record the bar value
	COLORREF m_nFirstColor;     //the from color
	COLORREF m_nSecondColor;    // the to color
	BOOL	 m_bBrush;
	LOGBRUSH m_logbrush;	// Defines the style, color, and pattern of a physical brush.

	// texture fill attribute, if m_nEffectStyle don't include ISTEXTURE, they are ignored
	CString  m_strTtureFile;  // file name of texture thumbnail 
	int      m_nTextureStyle; // 
	// following variables are not useful now, only for being compatible with prev version, 
	// they are remained here
	int      m_nTtureFileNum; 
	int      m_nTtureArry;
	// end
	int      m_nTxSWidth;
	int      m_nTxSHeight;
	BITMAPINFO* m_pTxBitInfo;
	HGLOBAL  m_hTxDipData;
	BITMAPFILEHEADER  m_TxBmFileHeader;

	// fill transparent setting
	int m_nTransparentMode; // 0 --- none transparent, 1 --- semi transparent
	                        // 2 --- gradual transparent.
		// if m_nTransparentMode is 0 or 1, following attributes are ignored
	int m_nConstantAlpha; // alpha transparency value to be used on the entire source bitmap
	BITMAPINFO* m_pAlphaInfo; // alpha channel dib info
	HGLOBAL m_hAlphaData; // alpha channel dib data


	// frame effect attribute, if m_nEffectStyle don't include ISFRAME, they are ignored
    int      m_nCaseStyle;
	int		 m_nCaseWidth;
	int      m_nFrameFileNum;
	int      m_nFrameArry;
	CString  m_strFrameFile;
	COLORREF m_refCaseColor[2];
	HGLOBAL  m_hCsDipData;
	BITMAPINFO* m_pCsBitInfo;
	BITMAPFILEHEADER  m_CsBmFileHeader;
	int      m_nLateWidth;
	int		 m_nCsSWidth;
	int      m_nCsSHeight;

	// shadow effect attribute, if m_nEffectStyle don't include ISSHADOW, they are ignored
    int      m_nShadowStyle;
	int      m_nShadowDirect;
	COLORREF m_refShadowColor;
	CSize    m_sizeShadowWidth;
	CSize    m_sizeLateWidth;
};

/////////////////////////////////////////////////////////////////////////////
// CEffect document

//class:
/*******************************************************************
** @Description:
**	%This% class
**  is used to set and draw all kinds of effect

** @Usage:
**  1. Set all kinds of effect parameter
**  2. Fill color to any region.
**  3. Fill gradient color to any region.   
**  4. Fill texture to any region.  
**  5. Draw frame to any region.    
**  6. Draw shadow to any region.   
**  7. Have ablity to decide which propertypages to show
**  8. Extend the region

** @Creator:  LiuChangwei @Date:     8/29/97
** @Modifier:  CW
*******************************************************************  */

class AFX_EXT_CLASS CEffect : public CObject
{
public:
	CEffect();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CEffect)

// Attributes
public:
//DRAW EFFECT
	void	OnEffect(CRect invaRect, CWnd* pWnd = NULL, UINT nFlags = 5, UINT IDTitle = 0);
	void	DrawEffect(CDC* pDC, CRgn* pRgn, CRect posRect, BOOL bOut, CRect outRect);
	void    DrawOutline(CDC* pDC, CPointArray& ptArray, int nZoomRatio);

	int		HasEffect();
	CSize	GetEffectSize();
	void	GetMatchRgn(CRgn* ExtRgn);
	void    TranDPtoLP(CDC* selDC, CRect dpRect);
//END 

	CWnd*   m_pWnd;
private:

//It's the number combined with four effect
	int      m_nSetActivePage;
	CSize    m_szReciWdHt;

public:
	Effect   m_effect;

	CSize    m_sizeToLP;

	BOOL     m_bDlgOK;
// Operations
public:
	virtual void Serialize(CArchive& ar, float fDocStorageVersion);   // overridden for document i/o
	Effect* GetEffect() { return &m_effect; }
// Implementation
public:
	virtual ~CEffect();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EFFECT_H__C96CB5BA_13DD_11D1_998B_0000E8CF7630__INCLUDED_)
