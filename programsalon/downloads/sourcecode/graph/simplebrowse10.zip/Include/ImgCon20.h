#ifndef _IMGCON20_
#define _IMGCON20_
//#ifdef __cplusplus
//extern "C" {
//#endif  /* __cplusplus */
typedef struct _ImageFileInfo
{
	char  strFormat[8];
	BITMAPINFOHEADER bmiHeader;
	DWORD dwColorSpace;
	WORD  wCompressMode;//No,CCITT,JPEG,LZW,Packbits,RLE
	WORD  wComQulity;//1- 100.
	WORD  wProgressive; //1 or 0.
	WORD  wVersion;
	WORD  nInterLace;
}ImageFileInfo;

extern "C" void FAR PASCAL EXPORT FreeImgMemory(HGLOBAL& hPixelData);
extern "C" long FAR PASCAL EXPORT ReadFileToMem(BITMAPINFO* lpBmpInfo, HGLOBAL& hPixelData, LPCTSTR lpFileName);
extern "C" long FAR PASCAL EXPORT WriteMemToFile(LPCTSTR lpFileName,BITMAPINFO* lpBmpInfo, HGLOBAL hPixelData,
												 LPCTSTR lpszFormt,ImageFileInfo* pImgInfo = NULL);
//note : The name use TIFF and JPEG.
extern "C" BSTR FAR PASCAL EXPORT GetImgFormat(LPCTSTR lpFileName) ;
extern "C" long FAR PASCAL EXPORT ConvertFileToFile(LPCTSTR lpszDestFileName, LPCTSTR lpszSrcFileName,
													LPCTSTR lpszFormt,ImageFileInfo* pImgInfo = NULL) ;
extern "C" BOOL FAR PASCAL EXPORT CreateNewThumbnail( BITMAPINFO* pThumbInfo, //1064 bytes.
														HGLOBAL& hThumbData,
														BITMAPINFO* pLargeHeader, //1064 bytes.
														LPCTSTR lpstrSrcFileName,
														CSize& ThumbSize,
														CRect  rcCrop = CRect(-1,-1,-1,-1), // default is all image.
														int nMode = 0);
extern "C" BOOL FAR PASCAL EXPORT GetImageFileInfo(BITMAPINFOHEADER* pbmiHeader, LPCTSTR lpszSrcFileName);

//1999-04-05
// Default it is use for create thumbnail.
extern "C" BOOL FAR PASCAL EXPORT MemScaleCrop( BITMAPINFO* pThumbInfo,HGLOBAL& hThumbData,
												BITMAPINFO* pSrcInfo,  HGLOBAL  hSrcData,
												CSize& ThumbSize,
												CRect rcCrop = CRect(-1,-1,-1,-1),
												int nMode = 0) ;

extern "C" BOOL FAR PASCAL EXPORT ConvertTo24Bit(BITMAPINFO* pbmpInfo,HGLOBAL& hBits);

//if the awd file have mult page ,read it into multiple bmp file
//such as tt.bmp -->tt~tmp0.bmp,tt~tmp1.bmp
extern "C" int FAR PASCAL EXPORT AwdToMultBmp(LPCTSTR lpszAwdName, LPCTSTR lszBmpName);


//#ifdef __cplusplus
//}
//#endif
#endif
