#if !defined(AFX_THUMBLISTCTRL_H__754753A6_3406_11D3_A63F_0000E8778115__INCLUDED_)
#define AFX_THUMBLISTCTRL_H__754753A6_3406_11D3_A63F_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ThumbListCtrl.h : header file
//
#include "SortedListCtrl.h"
#include "ThumbObj.h"

#define WM_USER_THUMBNAIL_CREATE  (WM_USER + 1)

/////////////////////////////////////////////////////////////////////////////
// CThumbListCtrl window

// thread state
enum THREADSTATE 
{ 
	READY = 0,
	PROCESSING = 1,
	FINISH = 2,
	WAITING = 3,
	INIT = 4
};

// thumbnail creation thread information
typedef struct _THUMBTHREADINFO
{
	HANDLE m_hEventThumbThreadKill;
	HANDLE m_hEventThumbThreadDead;
	HANDLE m_hEventCreateThumb;

	int m_nItem;
	CString m_szFilePath;
	CThumbObj *m_pThumbObj;

	THREADSTATE m_uState;
	
	CWnd *m_wndOwner;

} THUMBTHREADINFO, *LPTHUMBTHREADINFO;

// worker thread: to create thumbnails
UINT ThumbThreadProc(LPVOID pParam);

class AFX_EXT_CLASS CThumbListCtrl : public CSortedListCtrl
{
// Construction
public:
	CThumbListCtrl();
	virtual ~CThumbListCtrl();

// Attributes
public:
// Operations
public:
	// build columns and browse a folder
	BOOL BuildColumns();
	void BrowseFolder(CString strFolder);

	// "thumbnail view" style
	BOOL GotoThumbnailView();
	BOOL LeaveThumbnailView();
	BOOL IsInThumbnailView();

	// selected file
	CString GetSelectedFilePath();
	// multi selected
	void GetSelectedFilesPath(CStringList& listFilesPath);

	// modify flag
	BOOL IsModified();
	void SetModifiedFlag(BOOL bModified = TRUE);

	// compare
	virtual int CompareItems(CItemInfo *pItemInfo1, CItemInfo *pItemInfo2);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CThumbListCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:

protected:
	// clean tasks include: SaveBrowseFile(), CleanUpThumbObjList(), DeleteAllItems()
	void Clean();
	BOOL SaveBrowseFile();
	int ThumbObjListFromItems();
	long CalNeedStorageSize();
	void CleanUpThumbObjList();

	// init tasks include: ReadBrowseFile(), FillListCtrl(), CreateThumbnails()
	void Init();
	BOOL ReadBrowseFile();
	void FillListCtrl();

	// worker thread: create thumbnail
	CWinThread* BeginThumbThread();
	void CreateThumbnails();
	BOOL GetThumbCreateInfo(THUMBTHREADINFO *pThreadInfo);
	int GetFirstVisibleItem();
	void EndThumbThread();

	void DoClose();

	// For speed up the browse procedure, CThumbListCtrl save those image files' thumbnail data
	// in a browse file. This browse file name is "brwseimg.tf".
	// browse file read/write
	CString m_strFolder;		// current browse folder
	CString m_strBrowseFile;	// browse file name
	//image			---------"brwseimg.tf"

	CString m_strFileID;		// browse file ID
	//"brwseimg.tf" --- "Image Thumbnail File"

	float m_fAppStorageVersion;		// application storage version (tool)
	float m_fDocStorageVersion;		// document storage version    (data)

	CThumbObjList m_listThumbObj;	// thumbnail object list, use when read/write browse file

	// modify flag, if true, the browse file should be update
	BOOL m_bModified;

	// large, small and thumbnail icons
	CImageList m_LargeIcons;
	CImageList m_SmallIcons;
	CImageList *m_pImageList;

	// "thumbnail view" style
	BOOL m_bLVS_THUMBNAIL;

	// build columns ok
	BOOL m_bInitColumn;

	// thread, events and thread info
	CWinThread *m_pThumbThread;
	HANDLE m_hEventThumbThreadKill;
	HANDLE m_hEventThumbThreadDead;
	HANDLE m_hEventCreateThumb;
	THUMBTHREADINFO m_ThumbThreadInfo;

	// first visible item
	int m_nFirstVisibleItem;

	// thumbnail size
	CSize m_sizeThumbSize;
	// Generated message map functions
protected:
	//{{AFX_MSG(CThumbListCtrl)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
    afx_msg void OnGetDispInfo(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult) ;
	afx_msg void OnClose();
	//}}AFX_MSG
	afx_msg void OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct);
	LRESULT OnThumbnailCreate(WPARAM wParam, LPARAM lParam);
	
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THUMBLISTCTRL_H__754753A6_3406_11D3_A63F_0000E8778115__INCLUDED_)
