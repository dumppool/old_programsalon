#if !defined(AFX_NEWEDIT_H__31818E05_90FF_11D2_A6AF_0020AFF6D01D__INCLUDED_)
#define AFX_NEWEDIT_H__31818E05_90FF_11D2_A6AF_0020AFF6D01D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NewEdit.h : header file
//
/** 
@Creator: Hejinjun	Date: 02/22/99
*/
#define BEGINFONTSIZE 12

#include "rtftype.h"
/////////////////////////////////////////////////////////////////////////////
// CNewEdit class
//typedef CTypedPtrList<CObList, CNewString*> CListNewStr;
/** **********************************************************************
** @Description: %This% class is used for intput & output text,
**		it is a member of PalText
** @Creater:  Hejinjun
** @Date:     12/23/98
** @Version:  2.00 alpha
**********************************************************************  */
class AFX_EXT_CLASS CNewEdit : public CObject
{
	DECLARE_SERIAL(CNewEdit);

// Construction
public:
	CNewEdit();
	void Draw(CDC* pDC,	BOOL bGetPosition = TRUE);
	void ChangeBarFont();
	void SetWorkArea(CRect rcWorkArea);//Make it is same as docupal.

	int  ShowTextToolBar(int nCmdShow);
	void NotifyPalView(UINT nCode);
	int CreateTextToolBar();

	void DisplayText(CDC* pDC);
	
	void PaintSelect(CDC* pDC);
	void DrawBound(CDC* pDC);

	void DeviceShowText(CDC* pDC,BOOL bGetPosition = TRUE);
	void MemShowText(CDC* pDC,BOOL bGetPosition = TRUE) ;

	void GetEditPosition(CDC* pDC);
	void InitEdit(CWnd* pWnd);

	BOOL GetRgnFromRect(CRgn* pRgn,CRect rc);
	CRect GetBoxFromRotateRect(CRect rc,int nAngle);

	int m_nEditIndex; //The index of char in all edit.
	int m_nLastIndex; // The index of char in all edit last time.
	CPtrArray m_aPtrString;
//	CPtrArray m_aPtrRect;
	CRect m_rect; // the rectangle of display for text.
	CRect m_rcWorkArea; // the rectangle of work area.

	CString m_strFontTable;
	BOOL m_bInDrag;

	int m_nEditStatue;
	CRgn* m_pAroundRgn;

	BOOL m_bVeriPublish;
	int m_nEditAngle;// The angle of text rotate
	int m_nFontAngle;
	// ���ڽ��Text�����ţ�
	// �������� m_nEditAngle = m_nFontAngle  + 90.
	// ���ں��� m_nEditAngle = m_nFontAngle,

	// if it is set to 0,do not around the char.
	int m_nRoundMode,m_nAlignMode;
	int m_nPointType; //0,no data,1-- no color ,2 ,have color.

	CFont* m_pOldFont;
	CFont  m_cfNewFont;

	void InitTextFont(CDC* pDC,LOGFONT* stFont,NewFont* pNewFont = NULL);

	CString GetFontTable(){ return m_strFontTable;}
	void SetTextData(CString strFontTable,CString strData);
	CRect GetDisplayRect();
	CRgn* GetDisplayRgn();

	//11/01/1999
	CString MergeString(int nFirstChar,int nFirstString,
						  int nNextChar,int nNextString);

	BOOL GetSelectInfo(int& nFirstString,int& nFirstChar,
						 int& nNextString,int& nNextChar); 
	BOOL GeReDrawInfo(CDC* pDC,int& nFirstString,int& nFirstChar,
							 int& nNextString,int& nNextChar);

	int EditIndexFromString(int nStringIndex,int nCharIndex);
	
	BOOL EditIndexToString(int& nStringIndex,int& nCharIndex,int nEditIndex);
	int GetEditLineHeight(int nRow);
	int GetEditLineRect(CRect& rcLine,int nRow);

	void NormalizeEdit();
	CString GetAllString();

	BOOL InsertCharIntoEdit(CString strText,BOOL bDeleteSelect = TRUE);
	int GetEditCharCount();

	void GetCursorPos(int nEditIndex);
	void SetEditModify(int nCharIndex);
	
	void SetPositionModify();
	void DeleteOneChar(int nEditIndex);

	void ModifySelect(NewFont ftControl,int nFunctaion);
	BOOL GetSelectString(CString& strSelect);
	BOOL GetSelStringForFind(CString& strSelect);

	CString GetFontString(NewFont ftCurText);

	BOOL GetEditFont(NewFont* ftCurEdit,int nEditIndex);

	BOOL GetNewFontSelection(NewFont* ftCurEdit);
	DWORD GetCharFormatSelection(CHARFORMAT& cf);
	// Get CRgn from the charindex of edit .
	BOOL GetRgnFromEditChar(CRgn* pRgn,int nFirstEdit1,int nNextEdit2);
	int EditIndexFromPos(CPoint pt);
	void DrawMoveSelect(CDC* pDC,int nBegin,int nMid,int nEnd);
	
	void SetEditMask(int nFunction);
	BOOL EqualUseFont(NewFont ftControl1,NewFont ftControl2,int nFunctaion);
	void InvalidEdit(CDC* pDC) ;

	BOOL HaveControl();
	BOOL IsIndex(CString strText,int& nIndex);// It is use for mult-language.
	CPoint MapRotatePoint(CPoint ptOri,BOOL bNegitive = FALSE);

	void SelectAllText();
	int CharIsMid(int nEditIndex);
	CSize GetEditCharSize(int nEditIndex);

	int GetEditRow(int nEditIndex);
	void SetAroundMode(int nRoundMode)
	{
		m_nRoundMode = nRoundMode;
	}
	void DoOnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	void DoKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	void SetShowRect(CRect rc,int nEditAngle);
	void SetDisplayRgn(CRgn* pRgn);

	void GetShowRect(CRect& rc);
	void InvalidateTextRgn(BOOL bReDraw);

	int PtInTextRgn(CPoint pt,BOOL bChangeFocus = TRUE);
	int HasFocus() {return (m_nEditStatue == 1);}
	void SetEditStatue(int nEditStatue) { m_nEditStatue = nEditStatue;}

	void SetDefaultFontName();
	CString GetDefaultFontName(BYTE& bCharSet);
	CString GetFontNameInTbl(CString strFontTable,int nIndex,BYTE& bCharSet);

	// 03/18/99,use rtf format.
	int GetFoneNmaeIdx(TCHAR* lfFaceName,BYTE bCharSet);

	void AdjustString(CString strFontTable,CString& stNewText);

	void ShowCaretInCurrentPos(CDC* pDC = NULL);
	void DeleteContents(void);

	int GetMaxFontTbl(CString strFontTable);
	CString GetPureText(CString strMulttext);

	static int AlphaToInt(int ch);
	static int StringToNum(CString strNum,int nPosition);
	BOOL IsTextFormatAvailable(COleDataObject* dataObject,BOOL bAttach = FALSE);

	static MASK_TABLE maskTable[18];

public : // it the edit have
	BOOL CNewEdit::CanCutAndCopy();
	void Cut( );
	void Copy( );
	void Paste( );
	void Clear( );

//	void EmptyUndoBuffer( );

//	BOOL FmtLines( BOOL bAddEOL );

//	int GetFirstVisibleLine( ) const;

//	void GetSel( int& nStartChar, int& nEndChar ) ;

//	void ReplaceSel( LPCTSTR lpszNewText, BOOL bCanUndo = FALSE );

//	void SetSel( int nStartChar, int nEndChar, BOOL bNoScroll = FALSE );

// Attributes
private:
	CPoint m_ptCurrent;
	int m_nPageHeight ;
	CWnd* m_pParentWnd;
	BOOL m_bTextEdit;

	int m_nPosOfLine; // it is may be -1,0,1map to left,mid ,right
	// if it is -1,do't rezie rect, if it is > -1,it is the rect to be resize.
	int m_nResizeRect;

	UINT m_nHeightByte;// it is use for china code, if ch >0x80.
	int m_nTabSize;    // The width of TAB.
//	BOOL m_bChangeLine;

	//It is uesed for restore path of text.
	LPPOINT m_lpPoints;
	LPBYTE  m_lpTypes;
	int		m_iNumPts;

	BOOL	m_bSameLanguage;
	USHORT  m_sPriLangID;
	CString m_strDefaultFaceName;
	BYTE    m_bDefaultCharSet;

	int m_nRedrawTimes;

//Attributes of font
	NewFont m_ftUseDefine;
	FontMask m_fmCurrent;
	CString m_strCurCtrl;

	BOOL m_bTwoTimes;
	CPoint m_ptSrcCursor,m_ptCurCursor;
	CWnd* m_pwndTextToolBar; //text tool bar

	//01/01/99
	int PosFromString(CPoint& ptPos, int nIndex,int nStringIndex ) ;

	int CharFromPos(int& nCharIndex ,int& nStringIndex , CPoint pt) ;

	CSize GetCharSize(int nEditIndex);
	int CharFromPos(CPoint pt) ;
	CPoint PosFromChar( UINT nChar ) ;

	BOOL GetAroundInfo(int nAroundID);

	void DisplayCursor() ;
	void DeleteSelect();

	BOOL GetSerialpoint();
	BOOL RenderPathPoints(HDC hDC, LPPOINT lpPoints, LPBYTE lpTypes, int iNumPts, BOOL bOutline);
	BOOL PolyDraw95(HDC  hdc,              // handle of a device context 
					CONST LPPOINT lppt,	   // address of array of points 
					CONST LPBYTE lpbTypes, // address of line and curve identifiers  
					int  cCount); 	       // count of points 
	void SerializePointOfPath( CArchive& ar );
	void SerializeUndoRedo( CArchive& ar );
	BOOL HaveDoubleBytes();

	void InsertData(int nFormat,CString& strSelect,BOOL bDeleteSelect);

// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewEdit)
	public:
	virtual void Serialize( CArchive& ar );
	//}}AFX_VIRTUAL

// Implementation
public:
	int AnalizeString(CStringArray* pStrArray,CString strlarge,CRect rcDisplay,int nFormat);

	void InsertDataToPoint(int nFormat,CString& strSelect,CPoint pt);
	void DoOnDrop(int nFormat,CString& strSelect,CPoint pt,DROPEFFECT dropEffect);

	void SetTextProperty();
	void SetTextFont(int nFunction,DWORD dwValue);
	void SetEditFont(int nFunction);

	int SetFontName(TCHAR* lfFaceName,BYTE bCharSet);
	int SetFontSize(int nFontSize);
	int SetFontColor(COLORREF clrFont);

	int SetFontBold(BOOL bBold);
	int SetFontItalic(BOOL bItalic);
	int SetFontUnderline(BOOL bUnderline);
	int SetFontOutLine(BOOL bOutline);

	BOOL WriteNewText(CString strFileName,int nFormat);
	long ConvertTextFile(LPCTSTR lpDestFileName,short iDestFormat,
						LPCTSTR lpSrcFileName,short iSrcFormat);

	BOOL m_bCapture;
	BOOL m_bDbClick;

	int m_nSelectLength;
	CPoint 	m_DownPoint,m_PreMovePoint,m_UpPoint;

	void DoLButtonDown(UINT nFlags, CPoint point) ;
	void DoLButtonUp(UINT nFlags, CPoint point) ;
	void DoMouseMove(UINT nFlags, CPoint point) ;
	
	void LocateTextPos(CPoint ptDoc) ;
	void DoLButtonDblClk(UINT nFlags, CPoint point) ;

	virtual ~CNewEdit();
	
	void DoOnTimer(UINT nIDEvent);

	// it is use to undo/redo.
private:
	CObList	m_undolist;		// Stores undo states
	CObList	m_redolist;		// Stores redo states
	long	m_growsize;		// Adjust for faster saves
	long	m_undoLevels;	// Requested Undolevels 
	long	m_chkpt;

	void AddUndo(CMemFile*);
	void AddRedo(CMemFile *pFile); 
	void Load(CMemFile*);
	void Store(CMemFile*);
	void ClearRedoList();

public:

	// Here are the hooks into the CDocument class
//	CTxtUndo(long undolevels = 40, long = 4096);	// Constructor
//	~CTxtUndo();			// Destructor
	BOOL CanUndo();		// Returns TRUE if can Undo
	BOOL CanRedo();		// Returns TRUE if can Redo
	BOOL Undo();		// Restore next Undo state
	BOOL Redo();		// Restore next Redo state	
	void Cancel();		// Roll changes back to previous Undo state
	void CheckPoint();	// Save current state 
	void EnableCheckPoint();
	void DisableCheckPoint();

	long FindAndReplace(long nFlag, long nFind, LPCTSTR strFind,
					LPCTSTR strReplace, BOOL bReplace,BOOL bReplaceAll);

	//the follow is used to scroll view
	void ScrollToCurrent();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWEDIT_H__31818E05_90FF_11D2_A6AF_0020AFF6D01D__INCLUDED_)
