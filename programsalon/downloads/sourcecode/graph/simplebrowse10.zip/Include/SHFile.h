#if !defined(AFX_SHFILE_H__841CAA45_3E3D_11D3_A658_0000E8778115__INCLUDED_)
#define AFX_SHFILE_H__841CAA45_3E3D_11D3_A658_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SHFile.h : header file
//
#include "OXUNC.h"



/////////////////////////////////////////////////////////////////////////////
// CSHFile command target

class AFX_EXT_CLASS CSHFile : public COXUNC
{
	DECLARE_SERIAL(CSHFile)


// Attributes
public:
	CSHFile(LPCTSTR pszUNC = NULL);
	virtual ~CSHFile();

// Operations
public:
	int 	GetIconIndex();
	CString	GetDisplayName();
	CString	GetDescription();
	static void	GetSystemImageList(CImageList * pSmallList, CImageList * pLargeList);

	//File information
	CFileStatus GetFileStatus();
	BOOL SetFileStatus(CFileStatus fs);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSHFile)
	//}}AFX_VIRTUAL

// Implementation
protected:
	//File information
	CFileStatus m_fs;

	// Generated message map functions
	//{{AFX_MSG(CSHFile)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

//	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHFILE_H__841CAA45_3E3D_11D3_A658_0000E8778115__INCLUDED_)
