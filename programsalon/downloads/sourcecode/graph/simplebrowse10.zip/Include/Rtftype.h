#ifndef _RTFTYPE_H_
#define _RTFTYPE_H_

//Rtftype.h
#define fTrue 1
#define fFalse 0

typedef struct char_prop
{
    char fBold;
    char fUnderline;
    char fItalic;
} CHP;                  // CHaracter Properties

typedef enum {justL, justR, justC, justF } JUST;
typedef struct para_prop
{
    int xaLeft;                 // left indent in twips
    int xaRight;                // right indent in twips
    int xaFirst;                // first line indent in twips
    JUST just;                  // justification
} PAP;                  // PAragraph Properties

typedef enum {sbkNon, sbkCol, sbkEvn, sbkOdd, sbkPg} SBK;
typedef enum {pgDec, pgURom, pgLRom, pgULtr, pgLLtr} PGN;
typedef struct sect_prop
{
    int cCols;                  // number of columns
    SBK sbk;                    // section break type
    int xaPgn;                  // x position of page number in twips
    int yaPgn;                  // y position of page number in twips
    PGN pgnFormat;              // how the page number is formatted
} SEP;                  // SEction Properties

typedef struct doc_prop
{
    int xaPage;                 // page width in twips
    int yaPage;                 // page height in twips
    int xaLeft;                 // left margin in twips
    int yaTop;                  // top margin in twips
    int xaRight;                // right margin in twips
    int yaBottom;               // bottom margin in twips
    int pgnStart;               // starting page number in twips
    char fFacingp;              // facing pages enabled?
    char fLandscape;            // landscape or portrait??
} DOP;                  // DOcument Properties

typedef enum { rdsNorm, rdsSkip } RDS;              // Rtf Destination State
typedef enum { risNorm, risBin, risHex } RIS;       // Rtf Internal State

typedef struct save             // property save structure
{
    struct save *pNext;         // next save
    CHP chp;
    PAP pap;
    SEP sep;
    DOP dop;
    RDS rds;
    RIS ris;
} SAVE;

// What types of properties are there?
typedef enum 
{
	ipropBold, ipropItalic, ipropUnderline, ipropLeftInd,
    ipropRightInd, ipropFirstInd, ipropCols, ipropPgnX,
	ipropPgnY, ipropXaPage, ipropYaPage, ipropXaLeft,
	ipropXaRight, ipropYaTop, ipropYaBottom, ipropPgnStart,
	ipropSbk, ipropPgnFormat, ipropFacingp, ipropLandscape,
	ipropJust, ipropPard, ipropPlain, ipropSectd,
	ipropMax 
} IPROP;

typedef enum {actnSpec, actnByte, actnWord} ACTN;
typedef enum {propChp, propPap, propSep, propDop} PROPTYPE;

typedef struct propmod
{
    ACTN actn;              // size of value
    PROPTYPE prop;          // structure containing value
    int  offset;            // offset of value from base of structure
} PROP;

typedef enum {ipfnBin, ipfnHex, ipfnSkipDest } IPFN;
typedef enum {idestPict, idestSkip } IDEST;
typedef enum {kwdChar, kwdDest, kwdProp, kwdSpec} KWD;

typedef struct symbol
{
    char *szKeyword;        // RTF keyword
    int  dflt;              // default value to use
    bool fPassDflt;         // true to use default value from this table
    KWD  kwd;               // base action to take
    int  idx;               // index into property table if kwd == kwdProp
                            // index into destination table if kwd == kwdDest
                            // character to print if kwd == kwdChar
} SYM;

typedef struct _NewFont//tatol is 20 + 32 bytes.
{
	COLORREF lfFontColor ;  //the color of char
	LONG lfWeight;			//the weight of char,BOLD
	WORD lfFaceNameIdx;		// the name index of font 
	WORD lfFontSize ;		// the size of char
	
	WORD lfWidth;			// the width of char�����ű�����
	BYTE bCharSet;
	BYTE lfItalic;			// determind of italic
	
	DWORD lfUnderline;		// determind of underline,first byte is style,3 bytes is color.
    
	BYTE lfStrikeOut;		// ɾ���ߡ�0 --- ������1-- ���� 2-- ˫�ߡ�
    BYTE lfTopLine;			// �ϻ��ߡ�
	BYTE lfCharCase;		// 0 -- ����,1 --- ��д,2 -- Сд��
	BYTE lfSetDefault;      // set default value.

	DWORD lfCharEffect;		// 0 -- ����,1 -- �����ַ�,2 -- ���ģ�3 -- ���ġ�4 -- ��Ӱ��
	BYTE lfCharFrame;		// �߿�.
	BYTE lfCharBack;		// ����.
	
	char lfCharSpace ;		// the space between two chars
	char lfLineSpace  ;		// the space between two lines
	char lfCharIncrease;	// �ַ�������
}NewFont;

typedef struct _FontMask//
{
	BOOL lfFontColor ;	    //the color of char
	BOOL lfWeight;			//the weight of char
	BOOL lfFaceNameIdx;		// the name index of font 
	BOOL lfFontSize ;		// the size of char
	BOOL lfWidth;			// the width of char
	BOOL bCharSet;
	BOOL lfItalic;			// determind of italic
	BOOL lfUnderline;		// determind of underline
    BOOL lfStrikeOut;		// ɾ���ߡ�

    BOOL lfTopLine;			// �ϻ��ߡ�
	BOOL lfCharCase;		// 0 -- �ޱ仯��1 --- ��д��2 -- Сд��
	BOOL lfSetDefault;		// 0 -- �ޱ仯��1 --- ��д��2 -- Сд��


	BOOL lfCharEffect;// 0 --������1 -- �����ַ���2 -- ���ģ�3 -- ���ġ�4 -- ��Ӱ��
	BOOL lfCharFrame;		// �߿�.
	BOOL lfCharBack;		// ����.

	BOOL lfCharSpace ;		// the space between two chars
	BOOL lfLineSpace  ;		// the space between two lines
	BOOL lfCharIncrease;	// �ַ�������
}FontMask;

enum CONTROL_CODE
{
	lfFontColor,
	lfWeight,	  
	lfFaceNameIdx,		  
	lfFontSize,			
	lfWidth,				  
	bCharSet,			
	lfItalic,					  
	lfUnderline,
	lfStrikeOut,	
	
    lfTopLine,		// �ϻ��ߡ�
	lfCharCase,		// 0 -- �ޱ仯��1 --- ��д��2 -- Сд��
	lfSetDefault,		// 0 -- �ޱ仯��1 --- ��д��2 -- Сд��

	lfCharEffect,// 0 --������1 -- �����ַ���2 -- ���ģ�3 -- ���ġ�4 -- ��Ӱ��
	lfCharFrame,	// �߿�.
	lfCharBack,		// ����.
	
	lfCharSpace,	
	lfLineSpace,
	lfCharIncrease
};

typedef struct strTab
{
    int  idx;               //
    char *szKeyWord;        //
	int  nType;
	int  nOffset;
}KEY_TABLE;

typedef struct mask_Tab
{
    int  idx;               //
	int  nOffset;
}MASK_TABLE;

// map new text to rtf.
typedef struct mapkey_Tab
{
    int  idx;               //
    char *szNewTextKey;        //
    char *szRtfKeyWord;        //
}MAPKEY_TABLE;
#endif
