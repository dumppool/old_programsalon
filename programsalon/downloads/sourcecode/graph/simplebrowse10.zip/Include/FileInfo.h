#if !defined(AFX_FILEINFO_H__E78F6C21_3DB6_11D3_A657_0000E8778115__INCLUDED_)
#define AFX_FILEINFO_H__E78F6C21_3DB6_11D3_A657_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FileInfo.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CFileInfo command target

class CFileInfo : public CObject
{
	DECLARE_SERIAL(CFileInfo)


// Attributes
public:
	CFileInfo();
	virtual ~CFileInfo();

	CString		m_strFileName;
	CFileStatus m_fs;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileInfo)
	//}}AFX_VIRTUAL

// Implementation
protected:
	char		m_szDrive[_MAX_DRIVE];
	char		m_szDir[_MAX_DIR];
	char		m_szFname[_MAX_FNAME];
	char		m_szExt[_MAX_EXT];

	// Generated message map functions
	//{{AFX_MSG(CFileInfo)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILEINFO_H__E78F6C21_3DB6_11D3_A657_0000E8778115__INCLUDED_)
