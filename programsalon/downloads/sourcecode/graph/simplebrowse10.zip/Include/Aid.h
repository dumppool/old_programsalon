#if !defined(AFX_AID_H__1ADFCC04_4AB7_11D1_B120_0020AFF6D01D__INCLUDED_)
#define AFX_AID_H__1ADFCC04_4AB7_11D1_B120_0020AFF6D01D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Aid.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CAid command target
/** *************************************************************************
** @Description: 
**	%This% class
**  is used as a aid to do some global function.
**  
** @Usage:
**  direct call its static methods.
** @Creator:   Michael Zhang
** @Date:     11/10/97
** @Version:  0.600
************************************************************************** */
class AFX_EXT_CLASS CAid : public CObject
{
	DECLARE_SERIAL(CAid)


// Attributes
public:
	CAid();           
	virtual ~CAid();
	virtual void Serialize(CArchive& ar);

// Operations
public:
	//file system and string
	static CString GetPathString(CString strFilePath);
	static CString GetFolderString(CString strFilePath);
	static CString GetNameString(CString strFilePath);
	static CString GetTitleString(CString strFilePath);
	static CString GetExtString(CString strFilePath);
	static void ResolveFilePath(CString strFilePath, CString& strFolder, CString& strName);
	static void ResolveFilePath(CString strFilePath, CString& strFolder, CString& strTitle, CString& strExt);
	static CString MakeFullPathName(CString strPath, CString strName, CString strExt);
	static BOOL ExtStringFilter(CString strFilePath, CString strFilter);
	static BOOL StringFilter(CString strString, CString strFilter);
	static void SearchFiles(CString strFolder, CString strNameFilter, CString strExtFilter, 
		CStringList& listFoundFiles, BOOL bSearchSubFolder = false, BOOL bRecordFullPathName = false);
	static void SearchSubFolders(CString strFolder, CString strNameFilter, 
		CStringList& listFoundFolders, BOOL bSearchSubFolder = false, BOOL bRecordFullPathName = false);
	static CString AddNameSuffix(CString strFileName, CString strSuffix = "");
	static CString ChangeExt(CString strFileName, CString strExt = "");
	static CString GetRelativePath(CString strBasePath = "", CString strTargetPath = "");
	static void QuickSort(CStringList& listString, BOOL bUp = true);
	static void BubbleSort(CStringList& listString, BOOL bUp = true);

	static CString GetExeFilePath();
	static CString GetPath(CString strFilePath);
	static CString GetFilePath(CString strPath, CString strName);
	static CString LowerFileNameExt(CString strFileName);
	static CString RemoveNumber(CString strFileName);
	static CString SeperateTo3(CString strSource);
	static CString GetNextName(CString strFileName);

	static BOOL MakeFileWritable(CString strFilePath, BOOL bWritable = true);
	static BOOL DeleteFileEx(CString strFilePath);
	static BOOL SaveHGlobalToFile(HGLOBAL hBuffer, CString strFilePathName);	
	static BOOL SaveBufferToFile(void* pBuffer, DWORD dwSize, CString strFilePathName);
	static HGLOBAL MakeMediaData(CStringList& listStrFileName);
	static HGLOBAL MakeMediaData(CString strFileName);
	static BOOL IsTheSameFile(CFileStatus fs1, CFileStatus fs2);
	
	static int QueryFiles(LPTSTR lpBuffer, CStringList& listString);
	//rect,size and point
	static CRect GetInnerRect(CRect rectOuter, CRect rectMargin);
	static float RectFitToRect(CRect rectDest, 
							  CRect rectSrc, 
							  CRect & rectFit);
	static void PrepareDC(CDC* pDC, int nZoomNumView, int nZoomNumWin);

	//bmp calulate
	static LONG CalBmpBitsDataSize(LONG lWidth, LONG lHeight, WORD wBitCount);

	static void DrawArrLine(LPPOINT lpPoints, CPoint point1, CPoint point2, BOOL bl1, BOOL bl2);


	static BOOL	SaveDcBlockToDibMemory(CDC *pDC, CRect rect, BITMAPINFOHEADER* pInfoHeader, HGLOBAL& hBitData);
	static void	ScaleBits(  long lOldWidth, long lOldHeight, BYTE *pOldBits,
						long lNewWidth, long lNewHeight, BYTE *pNewBits);
	static BOOL PutTogether(CString strNewFile, CSize sizeFrame,
					 int nRows, int nColumns,
					 COLORREF clrBackground, CPtrArray& arrOldBMPData);

	static BOOL IsMAPISupportedModule(CString strModuleName);
	static CString GetMAPIModuleFromDirectory(CString strFolderName);
	static CString GetTempName(long RDiskSize);

	///ZhangYuelong
	static BOOL	SaveDcBlockToDibFile(CDC *pDC, CString fileName, CRect rect, CSize sizeBmp);
	static BOOL	SaveDcBlockToDibAndRgnFile(CDC *pDC, CString fileName, CRect rect);

	static int Sign(int nData);
	static int Sign(double dData);
	static BOOL SeeEnoughDiskSpace97(LPCTSTR lpszPathName, long lNeedSize);
	static BOOL SeeEnoughDiskSpace95(LPCTSTR lpszPathName, long lNeedSize);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAid)
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAid)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	//DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AID_H__1ADFCC04_4AB7_11D1_B120_0020AFF6D01D__INCLUDED_)
