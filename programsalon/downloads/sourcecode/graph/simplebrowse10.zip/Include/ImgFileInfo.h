#if !defined(AFX_IMGFILEINFO_H__52717BF6_34CF_11D3_A640_0000E8778115__INCLUDED_)
#define AFX_IMGFILEINFO_H__52717BF6_34CF_11D3_A640_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ImgFileInfo.h : header file
//

#include "SHFile.h"


/////////////////////////////////////////////////////////////////////////////
// CImgFileInfo command target

class AFX_EXT_CLASS CImgFileInfo : public CSHFile
{


// Attributes
public:
	CImgFileInfo(LPCTSTR lpszFileName = NULL);
	virtual ~CImgFileInfo();

// Operations
public:
	CString GetFileSize();
	CString GetLastWriteTimeString();
	static BOOL	IsImageFile(CString strFileName);
	BOOL IsImageFile();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImgFileInfo)
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CImgFileInfo)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMGFILEINFO_H__52717BF6_34CF_11D3_A640_0000E8778115__INCLUDED_)
