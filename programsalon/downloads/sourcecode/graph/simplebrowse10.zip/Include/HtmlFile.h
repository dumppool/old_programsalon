#if !defined(AFX_HTMLFILE_H__144D3EC5_0EAE_11D3_B7E9_0000E8778115__INCLUDED_)
#define AFX_HTMLFILE_H__144D3EC5_0EAE_11D3_B7E9_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HtmlFile.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CHtmlFile command target

/** *************************************************************************
** @Description: 
**	%This% class purpose:
**  read and write html file for gallery and dcp to html convertion.
**  
**  
** @Usage:
** @Creator:   Michael Zhang @Date:     5/22/99
************************************************************************** */
class AFX_EXT_CLASS CHtmlFile : public CStdioFile
{
	DECLARE_DYNAMIC(CHtmlFile)


// Attributes
public:
	CHtmlFile();           // protected constructor used by dynamic creation
	virtual ~CHtmlFile();

// Operations
public:
	void WriteArea(CString strShape = "", CString strCoords = "", CString strHref = "", 
		CString strAlt = "");
	void WriteMapEnd();
	void WriteMap(CString strName = "");
	void WriteNoframesEnd();
	void WriteNoframes();
	void WriteFrame(CString strSrc = "", CString strName = "");
	void WriteFramesetEnd();
	void WriteFrameset(CString strCols = "");
	void WriteTabs(int nTabs = 1, BOOL bWithNewline = true);
	void WriteNewlines(int nNewlines = 1);
	void WriteCommentsEnd();
	void WriteComments();
	void WriteScriptEnd();
	void WriteScript(CString strLanguage);
	void WriteStyleEnd();
	void WriteStyle(CString strType);
	void WriteImg(CString strSrc = "", CString strId = "", CString strAlt = "", 
		CString strBorder = "", CString strUsemap = "");
	void WriteHr();
	void WriteAEnd();
	void WriteA(CString strHref = "", CString strTarget = "");
	void WritePEnd();
	void WriteP(CString strAlign);
	void WriteBodyEnd();
	void WriteBody(CString strBgcolor);
	void WriteTitleEnd();
	void WriteTitle();
	void WriteHeadEnd();
	void WriteHead();
	void WriteHtmlEnd();
	void WriteHtml();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHtmlFile)
	//}}AFX_VIRTUAL

// Implementation
protected:

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HTMLFILE_H__144D3EC5_0EAE_11D3_B7E9_0000E8778115__INCLUDED_)
