#if !defined(AFX_RESOURCEOBJ_H__59A497A5_3580_11D1_B120_0020AFF6D01D__INCLUDED_)
#define AFX_RESOURCEOBJ_H__59A497A5_3580_11D1_B120_0020AFF6D01D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ResourceObj.h : header file
#include "SHFile.h"


#define INTERSPACE 7 //interspace between two ThumbObj, FrameBox and 
					 //ThumbnailBox and LabelBox.

/////////////////////////////////////////////////////////////////////////////
// CResourceObj command target

/** *************************************************************************
** @Description: 
**	%This% class
**  is used as a base class for all resouce object(include image, text, 
**  docupal document(dcp),etc.
**  
** @Usage:
** @Creator:   Michael Zhang
** @Date:     99/07/20
** @Version:  1.0
************************************************************************** */
class AFX_EXT_CLASS CResourceObj : public CSHFile
{
	DECLARE_SERIAL(CResourceObj)


// Attributes
public:
	CResourceObj(LPCTSTR pszUNC = NULL);           
	virtual ~CResourceObj();

	virtual void Serialize(CArchive& ar);
	virtual long CalNeedStorageSize();

	void operator =( CResourceObj& src );


// Operations
public:

	//Selection
	void SetSelectedFlag(BOOL bSelected);
	BOOL GetSelectedFlag();

	//Order
	void SetIndex(int nIndex);
	int GetIndex(void);

	//Layout
	void SetFrameSize(CSize sizeFrame);
	CSize GetFrameSize();
	void SetThumbSize(CSize sizeThumb);
	CSize GetThumbSize();
	virtual void SetPosition(CRect rectFrame, LONG lCharHeight);
	CRect GetFramePosition();
	void SetThumbPosition(CRect rectThumb) {m_rectThumbPos = rectThumb;};
	CRect GetThumbPosition(){return m_rectThumbPos;}

	int HitMe(CPoint ptHit);

	//Paint
	virtual void Paint(CDC* pDC,int nYPos = 0);

	//Thumbnail
	virtual BOOL CreateThumbnail();


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CResourceObj)
	//}}AFX_VIRTUAL

// Implementation
protected:

	//Selection
	BOOL m_bSelected;				//it is selected?

	//Order
	int m_nIndex;					//its order

	//Layout
	CSize m_sizeFrameSize;
	CSize m_sizeThumbnailSize;
	CSize m_sizeActulThumbSize;
	CRect m_rectFramePos;				//FramePos = ThumbPos + LabelPos
	CRect m_rectThumbPos;
	CRect m_rectLabelPos;

	//Paint
	virtual void PaintLabel(CDC* pDC,int nYPos  = 0);
	virtual void PaintThumbnail(CDC* pDC,int nYPos = 0);
	virtual void PaintFrame(CDC* pDC,int nYPos  = 0);


	// Generated message map functions
	//{{AFX_MSG(CResourceObj)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	//DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RESOURCEOBJ_H__59A497A5_3580_11D1_B120_0020AFF6D01D__INCLUDED_)
