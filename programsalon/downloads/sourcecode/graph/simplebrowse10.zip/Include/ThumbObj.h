#if !defined(AFX_THUMBOBJ_H__FBB65042_FF45_11D0_97CA_444553540000__INCLUDED_)
#define AFX_THUMBOBJ_H__FBB65042_FF45_11D0_97CA_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ThumbObj.h : header file
#include "ResourceObj.h"
#include "oxdib.h"
#include <afxtempl.h>


/////////////////////////////////////////////////////////////////////////////
// CThumbObj command target

/** *************************************************************************
** @Description: 
**	%This% class
**  is used as the image resource object.
**  
**  
** @Usage:
** @Creator:   Michael Zhang
** @Date:     99/07/20
** @Version:  1.0
************************************************************************** */
class AFX_EXT_CLASS CThumbObj : public CResourceObj
{
	DECLARE_SERIAL(CThumbObj)


// Attributes
public:
	CThumbObj(LPCTSTR pszUNC = NULL, CWnd* pOwner = NULL);
	virtual ~CThumbObj();

	virtual void Serialize(CArchive& ar);
	virtual long CalNeedStorageSize();

	void operator =( CThumbObj& src );

// Operations
public:
	
	//create
	virtual BOOL CreateThumbnail();
	BOOL SetOwnerSet(CWnd* pOwner);

	//paint
	virtual void PaintFrame(CDC* pDC,int nYPos  = 0);
	virtual void PaintLabel(CDC* pDC,int nYPos  = 0);
	virtual void PaintThumbnail(CDC* pDC,int nYPos  = 0);
	
	//information
	BITMAPINFOHEADER* GetOrgImgInfo();
	HANDLE GetImgHandle();

	// have try to create thumbnail?
	BOOL HaveTryToCreateThumb();
	void SetHaveTryToCreateThumbFlag(BOOL bFlag = true);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CThumbObj)
	//}}AFX_VIRTUAL

// Implementation
protected:
	//owner set
	CWnd* m_pOwnerSet;				//owner window

	//image data
	COXDIB *m_pDIB;
	BITMAPINFOHEADER m_sOrgInfoHeader;	//original bitmap information

	// have try to create thumbnail?
	BOOL m_bHaveTryToCreateThumb;

	// Generated message map functions
	//{{AFX_MSG(CThumbObj)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	//DECLARE_MESSAGE_MAP()
};

//list type
typedef CTypedPtrList<CObList, CThumbObj*> CThumbObjList;

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THUMBOBJ_H__FBB65042_FF45_11D0_97CA_444553540000__INCLUDED_)
