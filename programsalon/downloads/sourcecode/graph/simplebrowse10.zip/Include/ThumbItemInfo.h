#if !defined(AFX_THUMBITEMINFO_H__754753A7_3406_11D3_A63F_0000E8778115__INCLUDED_)
#define AFX_THUMBITEMINFO_H__754753A7_3406_11D3_A63F_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ThumbItemInfo.h : header file
//

#include "ItemInfo.h"
#include "ImgFileInfo.h"
#include "ThumbObj.h"

/////////////////////////////////////////////////////////////////////////////
// CThumbItemInfo command target

class AFX_EXT_CLASS CThumbItemInfo : public CItemInfo, public CImgFileInfo
{


// Attributes
public:
	CThumbItemInfo(int nItem = 0, LPCTSTR lpszFileName = NULL);           
	virtual ~CThumbItemInfo();

	BOOL SetThumb(CThumbObj *pThumbObj);
	CThumbObj* GetThumb();
	BOOL IsThumbReady();
	void PaintThumb(CDC *pDC, CRect rectPos);
	BOOL CreateThumb();

	// have try to create thumbnail?
	BOOL HaveTryToCreateThumb();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CThumbItemInfo)
	//}}AFX_VIRTUAL

// Implementation
protected:
	CThumbObj *m_pThumbObj;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THUMBITEMINFO_H__754753A7_3406_11D3_A63F_0000E8778115__INCLUDED_)
