// SimpleBrowse.h : main header file for the SIMPLEBROWSE application
//

#if !defined(AFX_SIMPLEBROWSE_H__66876707_4162_11D3_A65F_0000E8778115__INCLUDED_)
#define AFX_SIMPLEBROWSE_H__66876707_4162_11D3_A65F_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSimpleBrowseApp:
// See SimpleBrowse.cpp for the implementation of this class
//

class CSimpleBrowseApp : public CWinApp
{
public:
	CSimpleBrowseApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimpleBrowseApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CSimpleBrowseApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMPLEBROWSE_H__66876707_4162_11D3_A65F_0000E8778115__INCLUDED_)
