// SimpleBrowseView.cpp : implementation of the CSimpleBrowseView class
//

#include "stdafx.h"
#include "SimpleBrowse.h"

#include "SimpleBrowseDoc.h"
#include "SimpleBrowseView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimpleBrowseView

IMPLEMENT_DYNCREATE(CSimpleBrowseView, CView)

BEGIN_MESSAGE_MAP(CSimpleBrowseView, CView)
	//{{AFX_MSG_MAP(CSimpleBrowseView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimpleBrowseView construction/destruction

CSimpleBrowseView::CSimpleBrowseView()
{
	// TODO: add construction code here

}

CSimpleBrowseView::~CSimpleBrowseView()
{
}

BOOL CSimpleBrowseView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSimpleBrowseView drawing

void CSimpleBrowseView::OnDraw(CDC* pDC)
{
	CSimpleBrowseDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CSimpleBrowseView::OnInitialUpdate()
{
	CView::OnInitialUpdate();


	// TODO: You may populate your ListView with items by directly accessing
	//  its list control through a call to GetListCtrl().

	m_ThumbListCtrl.BuildColumns();
}

/////////////////////////////////////////////////////////////////////////////
// CSimpleBrowseView printing

BOOL CSimpleBrowseView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSimpleBrowseView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSimpleBrowseView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSimpleBrowseView diagnostics

#ifdef _DEBUG
void CSimpleBrowseView::AssertValid() const
{
	CView::AssertValid();
}

void CSimpleBrowseView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSimpleBrowseDoc* CSimpleBrowseView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSimpleBrowseDoc)));
	return (CSimpleBrowseDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSimpleBrowseView message handlers
void CSimpleBrowseView::OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct)
{
	//TODO: add code to react to the user changing the view style of your window
}

int CSimpleBrowseView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	
	// Create thumb list control
	// must use LVS_REPORT style to create column header correctly
	if (!m_ThumbListCtrl.Create(
		WS_VISIBLE | LVS_REPORT,
		CRect(0,0,0,0), this, IDC_SHELL_LIST))
	{
		TRACE0("Unable to create list view control.\n");
		return -1;
	}
	// to entry "thumbnail view", must:
	// 1.set LVS_ICON style
	// 2.call CThumbListCtrl::GotoThumbnailView()
	m_ThumbListCtrl.GotoThumbnailView();
	DWORD dwStyle = LVS_ICON;
	m_ThumbListCtrl.ModifyStyle(LVS_TYPEMASK, dwStyle);
	
	return 0;
}

void CSimpleBrowseView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if (m_ThumbListCtrl.GetSafeHwnd())
		m_ThumbListCtrl.MoveWindow(0,0,cx,cy);
	
}

void CSimpleBrowseView::FormatList(CString csPath)
{
	m_strCurDirectory = csPath;

	if (m_strCurDirectory.GetAt(m_strCurDirectory.GetLength()-1) == '\\')
		m_strCurDirectory = m_strCurDirectory.Left(m_strCurDirectory.GetLength() - 1);

	// the parameter pass to CThumbListCtrl::BrowseFolder() must be like "c:\folder" instead of "c:\folder\"
	m_ThumbListCtrl.BrowseFolder(m_strCurDirectory);
}

