// SimpleBrowseView.h : interface of the CSimpleBrowseView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIMPLEBROWSEVIEW_H__6687670F_4162_11D3_A65F_0000E8778115__INCLUDED_)
#define AFX_SIMPLEBROWSEVIEW_H__6687670F_4162_11D3_A65F_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ThumbListCtrl.h"

class CSimpleBrowseView : public CView/*CListView*/
{
protected: // create from serialization only
	CSimpleBrowseView();
	DECLARE_DYNCREATE(CSimpleBrowseView)

// Attributes
public:
	CSimpleBrowseDoc* GetDocument();
	CThumbListCtrl m_ThumbListCtrl;		// use thumb list control
	// how to use the CThumbListCtrl class? It is very simple:
	// 1.call CThumbListCtrl::Create() and CThumbListCtrl::GotoThumbnailView() in OnCreate()
	// 2.call CThumbListCtrl::MoveWindow() in OnSize()
	// 3.call CThumbListCtrl::BuildColumns() in OnInitialUpdate()
	// 4.call CThumbListCtrl::BrowseFolder() in FormatList()
	// that is all!

	CString m_strCurDirectory;

// Operations
public:
	void FormatList(CString csPath);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimpleBrowseView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSimpleBrowseView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSimpleBrowseView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	afx_msg void OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SimpleBrowseView.cpp
inline CSimpleBrowseDoc* CSimpleBrowseView::GetDocument()
   { return (CSimpleBrowseDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMPLEBROWSEVIEW_H__6687670F_4162_11D3_A65F_0000E8778115__INCLUDED_)
