// CDrawLineView.cpp : implementation of the CCDrawLineView class
//

#include "stdafx.h"
#include "CDrawLine.h"

#include "CDrawLineDoc.h"
#include "CDrawLineView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCDrawLineView

IMPLEMENT_DYNCREATE(CCDrawLineView, CView)

BEGIN_MESSAGE_MAP(CCDrawLineView, CView)
	//{{AFX_MSG_MAP(CCDrawLineView)
	ON_COMMAND(ID_MENURECTANGLE, OnMenurectangle)
	ON_COMMAND(ID_MENUPIE, OnMenupie)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCDrawLineView construction/destruction

CCDrawLineView::CCDrawLineView()
{
	// TODO: add construction code here
   	testGraph=NULL;
	 graphComplete=TRUE;
}

CCDrawLineView::~CCDrawLineView()
{
}

BOOL CCDrawLineView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CCDrawLineView drawing

void CCDrawLineView::OnDraw(CDC* pDC)
{
	CCDrawLineDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	
	if(	graphComplete==TRUE)
	{ 
		if(testGraph !=NULL)
		 {
			 delete testGraph ;
		     testGraph =NULL;
		 }
	testGraph = new CGraph(1,1);
	testGraph->SetGraphTitle("��������");//Line Graph

	
	testGraph->SetTickSpace(70);
	testGraph->SetTickRange(300);
	testGraph->SetXAxisAlignment(0);

	testGraph->SetXAxisLabel("ʱ�䣨���꣩");//Games
	testGraph->SetYAxisLabel("�ɼۣ����ۣ�Ԫ��");//Scores

	//��ͼ
	
	CGraphSeries::AddLineTitle(0,"��������");
	CGraphSeries::AddLineTitle(1,"���ݻƺ�");
	CGraphSeries::AddLineTitle(2,"�Ĵ�����");
    
	CGraphSeries* series1 = new CGraphSeries();
	CGraphSeries* series2 = new CGraphSeries();
	CGraphSeries* series3 = new CGraphSeries();
	series1->SetLabel("�Ű�");
	series2->SetLabel("�ž�");
	series3->SetLabel("������");
	series1->SetData(0, 150);
	series1->SetData(1, 202);
	series1->SetData(2, 230);
	series2->SetData(0, 199);
	series2->SetData(1, 140);
	series2->SetData(2, 279);
	series3->SetData(0, 240);
	series3->SetData(1, 264);
	series3->SetData(2, 230);
	testGraph->AddSeries(series1);
	testGraph->AddSeries(series2);
	testGraph->AddSeries(series3);

	//����ͼ��
	testGraph->SetLegend(0, "1:���� ");
	testGraph->SetLegend(1, "2:�ƺ� ");
	testGraph->SetLegend(2, "3:���� ");
		
	}
	testGraph->DrawGraph(pDC);
	

}

/////////////////////////////////////////////////////////////////////////////
// CCDrawLineView diagnostics

#ifdef _DEBUG
void CCDrawLineView::AssertValid() const
{
	CView::AssertValid();
}

void CCDrawLineView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CCDrawLineDoc* CCDrawLineView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCDrawLineDoc)));
	return (CCDrawLineDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCDrawLineView message handlers

void CCDrawLineView::OnMenurectangle() 
{
	// TODO: Add your command handler code here
         if(testGraph !=NULL)
		 {
			 delete testGraph ;
		     testGraph =NULL;
		 }
		testGraph = new CGraph(0,1);
	testGraph->SetGraphTitle("ֱ��ͼ");//Bar Chart

	testGraph->SetTickSpace(3000);
	testGraph->SetTickRange(30000);
	testGraph->SetXAxisAlignment(0);

	testGraph->SetXAxisLabel("����");//Games
	testGraph->SetYAxisLabel("����");//Scores

	//��ͼ
	CGraphSeries* series1 = new CGraphSeries();
	CGraphSeries* series2 = new CGraphSeries();
	CGraphSeries* series3 = new CGraphSeries();
	series1->SetLabel("ʱ��1");
	series2->SetLabel("ʱ��2");
	series3->SetLabel("ʱ��3");
	series1->SetData(0, 15000);
	series1->SetData(1, 202000);
	series1->SetData(2, 230000);
	series1->SetData(3, 185000);
	series1->SetData(4, 198000);
	series1->SetData(5, 2340);
	series1->SetData(6, 17000);
	series1->SetData(7, 19000);
	series1->SetData(8, 18800);
	series1->SetData(9, 2090);
	series2->SetData(0, 19900);
	series2->SetData(1, 14000);
	series2->SetData(2, 2790);
	series3->SetData(0, 2040);
	series3->SetData(1, 2210);
	series3->SetData(2, 2080);
	testGraph->AddSeries(series1);
	testGraph->AddSeries(series2);
	testGraph->AddSeries(series3);

	//����ͼ��
	testGraph->SetLegend(0, "1��Ŀ ");
	testGraph->SetLegend(1, "2��Ŀ ");
	testGraph->SetLegend(2, "3��Ŀ ");
	testGraph->SetLegend(3, "4��Ŀ ");
	testGraph->SetLegend(4, "5��Ŀ");
	testGraph->SetLegend(5, "6��Ŀ ");
	testGraph->SetLegend(6, "7��Ŀ ");
	testGraph->SetLegend(7, "8��Ŀ ");
	testGraph->SetLegend(8, "9��Ŀ ");
	testGraph->SetLegend(9, "10��Ŀ ");
	
	graphComplete = !graphComplete;
	Invalidate(TRUE);
	
}

void CCDrawLineView::OnMenupie() 
{
	// TODO: Add your command handler code here
	 if(testGraph !=NULL)
		 {
			 delete testGraph ;
		     testGraph =NULL;
		 }
	{
	// TODO: Add your command handler code here
	testGraph = new CGraph(2);
	testGraph->SetGraphTitle("��ͼ");//Pie Chart
	
	//����ͼ��
	testGraph->SetLegend(0, "1��Ŀ ");
	testGraph->SetLegend(1, "2��Ŀ ");
	testGraph->SetLegend(2, "3��Ŀ ");
	testGraph->SetLegend(3, "4��Ŀ ");
	testGraph->SetLegend(4, "5��Ŀ ");
	testGraph->SetLegend(5, "6��Ŀ ");
	testGraph->SetLegend(6, "7��Ŀ ");
	testGraph->SetLegend(7, "8��Ŀ ");
	testGraph->SetLegend(8, "9��Ŀ");
	testGraph->SetLegend(9, "10��Ŀ ");

	//��ͼ
	CGraphSeries* series1 = new CGraphSeries();
	CGraphSeries* series2 = new CGraphSeries();
	CGraphSeries* series3 = new CGraphSeries();
	series1->SetLabel("ʱ�� 1");
	series2->SetLabel("ʱ�� 2");
	series3->SetLabel("ʱ�� 3");
	series1->SetData(0, 15);
	series1->SetData(1, 5);
	series1->SetData(2, 2);
	series1->SetData(3, 8);
	series1->SetData(4, 30);
	series1->SetData(5, 6);
	series1->SetData(6, 7);
	series1->SetData(7, 9);
	series1->SetData(8, 8);
	series1->SetData(9, 10);
	series2->SetData(0, 15);
	series2->SetData(1, 15);
	series2->SetData(2, 15);
	series3->SetData(0, 10);
	series3->SetData(1, 20);
	series3->SetData(2, 30);
	series3->SetData(3, 40);
	series3->SetData(4, 50);

	testGraph->AddSeries(series1);
	testGraph->AddSeries(series2);
	testGraph->AddSeries(series3);

	graphComplete = !graphComplete;
	
	Invalidate(TRUE);	
}
	
}
