// CDrawLineView.h : interface of the CCDrawLineView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CDRAWLINEVIEW_H__42B6827D_4D1C_401F_921B_FF2A158AB793__INCLUDED_)
#define AFX_CDRAWLINEVIEW_H__42B6827D_4D1C_401F_921B_FF2A158AB793__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Graph.h"

class CCDrawLineView : public CView
{
protected: // create from serialization only
	CCDrawLineView();
	DECLARE_DYNCREATE(CCDrawLineView)

// Attributes
public:
	CCDrawLineDoc* GetDocument();
    CGraph* testGraph;
	BOOL graphComplete;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCDrawLineView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCDrawLineView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CCDrawLineView)
	afx_msg void OnMenurectangle();
	afx_msg void OnMenupie();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in CDrawLineView.cpp
inline CCDrawLineDoc* CCDrawLineView::GetDocument()
   { return (CCDrawLineDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CDRAWLINEVIEW_H__42B6827D_4D1C_401F_921B_FF2A158AB793__INCLUDED_)
