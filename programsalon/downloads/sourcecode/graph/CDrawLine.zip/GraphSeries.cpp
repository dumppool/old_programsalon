// GraphSeries.cpp : implementation file
//

#include "stdafx.h"
#include "CDrawLine.h"//Ӧ��Ϊ��ӦӦ�ó����ͷ�ļ�
#include "GraphSeries.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGraphSeries

BOOL CGraphSeries::m_addLine=FALSE;
CString CGraphSeries::m_pLineTitle[10]={"","","","","","","","","",""};
CGraphSeries::CGraphSeries()
{
	for(int i = 0; i < 10; i++)
		dataValue[i] = 0;
    
}

CGraphSeries::~CGraphSeries()
{
	
	
}


BEGIN_MESSAGE_MAP(CGraphSeries, CStatic)
	//{{AFX_MSG_MAP(CGraphSeries)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGraphSeries message handlers

void CGraphSeries::SetLabel(CString label)
{
	seriesLabel = label;
}

void CGraphSeries::SetData(int group, int dValue)
{
	dataValue[group] = dValue;
}

CString CGraphSeries::GetLabel()
{
	return seriesLabel;
}

int CGraphSeries::GetData(int group)
{
	return dataValue[group];
}


void CGraphSeries::AddLineTitleTag(BOOL addorremove)
{
    m_addLine=addorremove;
}

void CGraphSeries::AddLineTitle(int index, CString strTitle)
{
	if(m_pLineTitle[index]!=_T(""))
    m_pLineTitle[index].Empty();
	m_pLineTitle[index]=strTitle;
	m_addLine=TRUE;

}

CString CGraphSeries::GetLineTitle(int index)
{
    
return	m_pLineTitle[index];
}

BOOL CGraphSeries::GetTitleFlag()
{
	return m_addLine;

}
