// CDrawLine.h : main header file for the CDRAWLINE application
//

#if !defined(AFX_CDRAWLINE_H__C2F3BC0A_6458_42EC_A176_6F6571B80D5F__INCLUDED_)
#define AFX_CDRAWLINE_H__C2F3BC0A_6458_42EC_A176_6F6571B80D5F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCDrawLineApp:
// See CDrawLine.cpp for the implementation of this class
//

class CCDrawLineApp : public CWinApp
{
public:
	CCDrawLineApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCDrawLineApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CCDrawLineApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CDRAWLINE_H__C2F3BC0A_6458_42EC_A176_6F6571B80D5F__INCLUDED_)
