// flt_steff.h : main header file for the FLT_STEFF DLL
//

#if !defined(AFX_FLT_STEFF_H__BE5E74A6_AC41_11D4_815D_00D0B79C40FB__INCLUDED_)
#define AFX_FLT_STEFF_H__BE5E74A6_AC41_11D4_815D_00D0B79C40FB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "..\public\gol_proc.h"		// added by lzg 2000.10.10

/////////////////////////////////////////////////////////////////////////////
// CFlt_steffApp
// See flt_steff.cpp for the implementation of this class
//

class CFlt_steffApp : public CWinApp
{
public:
	CFlt_steffApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlt_steffApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CFlt_steffApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

// Inside Standard image format pixel data structure
typedef struct 
{
	BYTE blue;
	BYTE green;
	BYTE red;
	BYTE alpha;
} *pStdPix;

// �ӿں������� �� ��һ�㣬Ψһ�������ϵ�Ľӿ�
BOOL WINAPI AccessStEffFilter(LPIMAGEPROCSTR lpInfo);

// ������ͺ��� �� �ڶ�����ͺ���
void _fnCMD_EMBOSS(LPIMAGEPROCSTR lpInfo);			// ����Ч��
void _fnCMD_VARIATIONS(LPIMAGEPROCSTR lpInfo);		// ɫ������		
void _fnCMD_BLUR(LPIMAGEPROCSTR lpInfo);			// ģ��
void _fnCMD_BUTTON(LPIMAGEPROCSTR lpInfo);			// ��ť������
void _fnCMD_TWIRL(LPIMAGEPROCSTR lpInfo);			// Ť��
void _fnCMD_INTERLACE(LPIMAGEPROCSTR lpInfo);		// ��˿
void _fnCMD_MOSAIC(LPIMAGEPROCSTR lpInfo);			// ������

// �ڲ�ʹ�ù������� --�������ͺ���
// Get pixel value in inside standard format
BOOL _fnCOM_GetPixel(LPIMAGEPROCSTR lpInfo, int x, int y, DWORD* pPixel);
// Set pixel value in inside standard format
BOOL _fnCOM_SetPixel(LPIMAGEPROCSTR lpInfo, int x, int y, DWORD* pPixel);
// Fill some rect region
BOOL _fnCOM_FillRect(LPIMAGEPROCSTR lpInfo, RECT rect, DWORD* pPixel);
// Get zoom image information and data
BOOL _fnCOM_GetZoomImage(LPIMAGEPROCSTR lpInfo, float fXzoom, float fYzoom, LPBITMAPINFOHEADER lpBi, LPVOID lpBits);

// Special functions
// Mosaic a special region
BOOL _fnSPE_MOSAIC(LPIMAGEPROCSTR lpInfo, int Size, RECT* pRect=NULL );			// ������
// Bilinear intervalue to abtain pixel from image
DWORD _fnSPE_BilinearInterValue(LPIMAGEPROCSTR lpInfo, float x, float y);

// To show dialog in dll
BOOL CALLBACK WINAPI MosaicProc(HWND hWnd,UINT uMsg,UINT wParam,LONG lParam);

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FLT_STEFF_H__BE5E74A6_AC41_11D4_815D_00D0B79C40FB__INCLUDED_)
