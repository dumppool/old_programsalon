// PreviewDlg.cpp : implementation file
//

#include "stdafx.h"
#include "flt_steff.h"
#include "PreviewDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreviewDlg dialog


CPreviewDlg::CPreviewDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPreviewDlg::IDD, pParent)
{

	//{{AFX_DATA_INIT(CPreviewDlg)
	m_iMosaic_Unit = 8;
	//}}AFX_DATA_INIT
}


void CPreviewDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreviewDlg)
	DDX_Control(pDX, IDC_MOSIC_UNIT, m_tracebar);
	DDX_Text(pDX, IDC_EDIT_MOSAIC_UNIT, m_iMosaic_Unit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPreviewDlg, CDialog)
	//{{AFX_MSG_MAP(CPreviewDlg)
	ON_WM_VSCROLL()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreviewDlg message handlers

BOOL CPreviewDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// To get the zoom of the image
	CStatic *pStatic = (CStatic*)GetDlgItem( IDC_PREVIEW_WINDOW );
	m_zoom = 1.0;
	CRect rect;

	pStatic->GetClientRect(&rect);
	rect.right -= 8;
	rect.bottom -= 8;	// YZ add 2000-11-22

	float fXzoom, fYzoom;
	fXzoom= (rect.right-rect.left+1)/(float)m_lpInfo->dImageInfo.width;
	fYzoom= (rect.bottom-rect.top+1)/(float)m_lpInfo->dImageInfo.height;
	if(fXzoom<1.0 || fYzoom<1.0)
		m_zoom = fXzoom<fYzoom ? fXzoom : fYzoom;

	m_Ox = (rect.right-rect.left+1)/2 - (int)(m_lpInfo->dImageInfo.width * m_zoom)/2;
	m_Oy = (rect.bottom-rect.top+1)/2 - (int)(m_lpInfo->dImageInfo.height * m_zoom)/2;
	m_Ox += 2;
	m_Oy += 2;	// YZ YZ add 2000-11-22
	m_Preview_width = (int)(m_lpInfo->dImageInfo.width * m_zoom);
	m_Preview_height= (int)(m_lpInfo->dImageInfo.height * m_zoom);
                     
	m_tracebar.SetRange(2,32,TRUE);
	m_tracebar.SetTicFreq(2);
	m_tracebar.SetLineSize(1);
	m_tracebar.SetPageSize(2);
	m_tracebar.SetTic(8);
	m_tracebar.SetPos(m_iMosaic_Unit);
	// TODO: Add extra initialization here
	
	hdd = DrawDibOpen();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}



void CPreviewDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	CSliderCtrl* slider=(CSliderCtrl*)pScrollBar;
	int position=slider->GetPos();
	m_iMosaic_Unit=position;
	// Record Mosaic unit for furture use
	m_lpInfo->annexdata.siAnnData[1]= m_iMosaic_Unit;

	if (m_pRect == NULL)
		 _fnSPE_MOSAIC(m_lpInfo, m_iMosaic_Unit);
	else
		_fnSPE_MOSAIC(m_lpInfo,m_iMosaic_Unit, m_pRect);
	UpdateData(FALSE);
	// display bitmap into preview control
	//CStatic *pStatic = (CStatic*)GetDlgItem( IDC_PREVIEW_WINDOW );
	//pStatic->Invalidate(FALSE);
	//slider->Invalidate(FALSE);
	Invalidate(FALSE);
	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CPreviewDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	// Show image in preview window		
	CStatic *pStatic = (CStatic*)GetDlgItem( IDC_PREVIEW_WINDOW );

/*********************Drawlib****************************/
	// Use Drawlib to display image 
	HWND hWnd = pStatic->m_hWnd;
	HDC hDC = ::GetDC(hWnd);

    UINT wFlags;
    //wFlags = DDF_DONTDRAW;
    wFlags = DDF_NOTKEYFRAME;

    if (hdd != NULL) 
    { 
		DrawDibDraw(hdd,
					hDC,
					m_Ox,
					m_Oy,
					m_Preview_width ,
					m_Preview_height,
					(LPBITMAPINFOHEADER)m_lpbi,
					m_lpInfo->_pdbdata,
					0,
					0,
					m_lpInfo->dImageInfo.width-1,
					m_lpInfo->dImageInfo.height-1,
					wFlags);
    }
/*********************Drawlib****************************/

	// Do not call CDialog::OnPaint() for painting messages
}

/********* Transmit image process packet into dlg class*******/
void CPreviewDlg::SendPreviewImage(LPIMAGEPROCSTR lpInfo)
{
	m_lpInfo=lpInfo;
	// Set bi value
	HWND hWnd = ::GetDesktopWindow();
	HDC hDC = ::GetDC(hWnd);

	bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bi.bmiHeader.biPlanes = 1;
	bi.bmiHeader.biBitCount = m_lpInfo->sImageInfo.bitperpix;
	bi.bmiHeader.biCompression = BI_RGB;
	bi.bmiHeader.biSizeImage = 0;
	bi.bmiHeader.biWidth = m_lpInfo->dImageInfo.width;
	bi.bmiHeader.biHeight =  m_lpInfo->dImageInfo.height;
	bi.bmiHeader.biClrImportant = 0;
	bi.bmiHeader.biClrUsed = 0;
	bi.bmiHeader.biXPelsPerMeter = (int)(::GetDeviceCaps(hDC,LOGPIXELSX)*(float)39.373);
	bi.bmiHeader.biYPelsPerMeter = (int)(::GetDeviceCaps(hDC,LOGPIXELSY)*(float)39.373);
	
	m_lpbi = (LPBITMAPINFO)&bi;
	
	
	m_pRect = new CRect;
	if (lpInfo->annexdata.siAnnData[0]==0)
	{
		_fnSPE_MOSAIC(lpInfo, m_iMosaic_Unit);
	}
	else
	{
		m_pRect->left=lpInfo->annexdata.siAnnData[2];
		m_pRect->top=lpInfo->annexdata.siAnnData[3];
		m_pRect->right=lpInfo->annexdata.siAnnData[4];
		m_pRect->bottom=lpInfo->annexdata.siAnnData[5];
		_fnSPE_MOSAIC(lpInfo,m_iMosaic_Unit, m_pRect);
	}
	delete m_pRect;
	m_pRect = NULL;

	// Record Mosaic unit for furture use
	lpInfo->annexdata.siAnnData[1]= m_iMosaic_Unit;
}



void CPreviewDlg::OnOK() 
{
	if (hdd)
		DrawDibClose(hdd);

	CDialog::OnOK();
}

void CPreviewDlg::OnCancel() 
{
	if (hdd)
		DrawDibClose(hdd);
	
	CDialog::OnCancel();
}
