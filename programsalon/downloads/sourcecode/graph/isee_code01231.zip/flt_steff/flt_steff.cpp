// flt_steff.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "flt_steff.h"
#include "previewdlg.h"		// added by lzg

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CFlt_steffApp

BEGIN_MESSAGE_MAP(CFlt_steffApp, CWinApp)
	//{{AFX_MSG_MAP(CFlt_steffApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFlt_steffApp construction

CFlt_steffApp::CFlt_steffApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CFlt_steffApp object

CFlt_steffApp theApp;

BOOL WINAPI AccessStEffFilter(LPIMAGEPROCSTR lpInfo)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	// ����������Բ����޸ĵ�ʹ�ã�������ķ���ֵ�������֡�

	switch(lpInfo->comm)
	{
	case	PCM_EMBOSS:			// ����Ч��
		_fnCMD_EMBOSS(lpInfo);
		break;
	case	PCM_VARIATIONS:     // ɫ������
		_fnCMD_VARIATIONS(lpInfo);
		break;
	case	PCM_BLUR:           // ģ��
		_fnCMD_BLUR(lpInfo);
		break;
	case	PCM_BUTTON:         // ��ť������
		_fnCMD_BUTTON(lpInfo);
		break;
	case	PCM_TWIRL:          // Ť��
		_fnCMD_TWIRL(lpInfo);
		break;
	case	PCM_INTERLACE:      // ��˿
		_fnCMD_INTERLACE(lpInfo);
		break;
	case	PCM_MOSAIC:         // ������
		_fnCMD_MOSAIC(lpInfo);
		break;
	default:
		lpInfo->result = PR_ILLCOMM;	// �Ƿ�ָ��ͻ���������������벻��ȷ��
		ASSERT(FALSE);					// �����ߵĳ������������ :-)
		break;
	}

	// ִ������ɹ�����TRUE, ʧ�ܷ���FALSE
	return (lpInfo->result==PR_SUCCESS)? TRUE:FALSE;
}

int WINAPI Dll_Function(int i)
{
	CString str;
	str.Format("%d",i);
	//sprintf(str,"%d",i);
	AfxMessageBox(str);
	return 20+i;
}
// ������ͺ��� �� �ڶ�����ͺ���
void _fnCMD_EMBOSS(LPIMAGEPROCSTR lpInfo)			// ����Ч��
{
	
	// Initialize the destine image infomation
	lpInfo->dImageInfo.height=lpInfo->sImageInfo.height;
	lpInfo->dImageInfo.width=lpInfo->sImageInfo.width;
	lpInfo->dImageInfo.bitperpix=lpInfo->sImageInfo.bitperpix;
	lpInfo->dImageInfo.byteperline=lpInfo->sImageInfo.byteperline;
	lpInfo->dImageInfo.bAlpha=lpInfo->sImageInfo.bAlpha;
	
	// Set Modify flag
	lpInfo->modify=1;

	// �������ڴ�ű�׼ͼ��λ���ݵ��ڴ��
	unsigned char * _pbdata = (unsigned char * )::GlobalAlloc(GPTR, lpInfo->dImageInfo.width * 4 * lpInfo->dImageInfo.height);
	if (!_pbdata)
	{
		lpInfo->result=PR_MEMORYERR;
		return ;
	}
	lpInfo->_pdbdata=_pbdata;
	// �������ڴ��ÿһɨ���е�ַ��ָ�����鲢��ʼ��
	unsigned long** pLineAddr = (unsigned long**)::GlobalAlloc(GPTR, lpInfo->dImageInfo.height*sizeof(DWORD*));
	if (!pLineAddr)
	{
		::GlobalFree(_pbdata);
		lpInfo->result=PR_MEMORYERR;
		return ;
	}
	// ��ʼ����������
	for (int y=0;y<lpInfo->dImageInfo.height;y++)
		pLineAddr[y] = (DWORD*)(_pbdata+((lpInfo->dImageInfo.height-y-1)*(lpInfo->dImageInfo.width *4)));
	lpInfo->pdLineAddr=pLineAddr;
	// Test emboss effect
	lpInfo->_pdbdata=lpInfo->_psbdata;
	lpInfo->pdLineAddr=lpInfo->psLineAddr;
	int i;
	DWORD TempPixel;
	BYTE* pByte;
	
	for(i=30;i<=60;i++)
	{
		_fnCOM_GetPixel(lpInfo,i,30,&TempPixel);
		pByte = (BYTE*)&TempPixel;
		*pByte++ =(BYTE)(*pByte*0.9);
		*pByte++ =(BYTE)(*pByte*0.9);
		*pByte =(BYTE)(*pByte*0.9);
		_fnCOM_SetPixel(lpInfo,i,30,&TempPixel);

		_fnCOM_GetPixel(lpInfo,i,60,&TempPixel);
		pByte = (BYTE*)&TempPixel;
		*pByte++ =(BYTE)(*pByte*0.9);
		*pByte++ =(BYTE)(*pByte*0.9);
		*pByte =(BYTE)(*pByte*0.9);
		_fnCOM_SetPixel(lpInfo,i,60,&TempPixel);

		_fnCOM_GetPixel(lpInfo,30,i,&TempPixel);
		pByte = (BYTE*)&TempPixel;
		*pByte++ =(BYTE)(*pByte*0.9);
		*pByte++ =(BYTE)(*pByte*0.9);
		*pByte =(BYTE)(*pByte*0.9);
		_fnCOM_SetPixel(lpInfo,30,i,&TempPixel);

		_fnCOM_GetPixel(lpInfo,60,i,&TempPixel);
		pByte = (BYTE*)&TempPixel;
		*pByte++ =(BYTE)(*pByte*0.9);
		*pByte++ =(BYTE)(*pByte*0.9);
		*pByte =(BYTE)(*pByte*0.9);
		_fnCOM_SetPixel(lpInfo,60,i,&TempPixel);
	}
	for(i=32;i<=58;i++)
	{
		_fnCOM_GetPixel(lpInfo,i,32,&TempPixel);
		pByte = (BYTE*)&TempPixel;
		*pByte++ =(BYTE)(*pByte*1.1);
		*pByte++ =(BYTE)(*pByte*1.1);
		*pByte =(BYTE)(*pByte*1.1);
		_fnCOM_SetPixel(lpInfo,i,32,&TempPixel);

		_fnCOM_GetPixel(lpInfo,i,58,&TempPixel);
		pByte = (BYTE*)&TempPixel;
		*pByte++ =(BYTE)(*pByte*1.1);
		*pByte++ =(BYTE)(*pByte*1.1);
		*pByte =(BYTE)(*pByte*1.1);
		_fnCOM_SetPixel(lpInfo,i,58,&TempPixel);

		_fnCOM_GetPixel(lpInfo,32,i,&TempPixel);
		pByte = (BYTE*)&TempPixel;
		*pByte++ =(BYTE)(*pByte*1.1);
		*pByte++ =(BYTE)(*pByte*1.1);
		*pByte =(BYTE)(*pByte*1.1);
		_fnCOM_SetPixel(lpInfo,32,i,&TempPixel);

		_fnCOM_GetPixel(lpInfo,58,i,&TempPixel);
		pByte = (BYTE*)&TempPixel;
		*pByte++ =(BYTE)(*pByte*1.1);
		*pByte++ =(BYTE)(*pByte*1.1);
		*pByte =(BYTE)(*pByte*1.1);
		_fnCOM_SetPixel(lpInfo,58,i,&TempPixel);
	}
	lpInfo->result=PR_SUCCESS;
}
void _fnCMD_VARIATIONS(LPIMAGEPROCSTR lpInfo)		// ɫ������		
{
	lpInfo->result=PR_SUCCESS;
}
void _fnCMD_BLUR(LPIMAGEPROCSTR lpInfo)				// ģ��
{
	lpInfo->result=PR_SUCCESS;
}
void _fnCMD_BUTTON(LPIMAGEPROCSTR lpInfo)			// ��ť������
{
	lpInfo->result=PR_SUCCESS;
}
void _fnCMD_TWIRL(LPIMAGEPROCSTR lpInfo)			// Ť��
{
	lpInfo->result=PR_SUCCESS;
}
void _fnCMD_INTERLACE(LPIMAGEPROCSTR lpInfo)		// ��˿
{
	lpInfo->result=PR_SUCCESS;
}


void _fnCMD_MOSAIC(LPIMAGEPROCSTR lpInfo)			// ������
{
	// ������ڲ����Ƿ���Ͻӿڶ���
	ASSERT(lpInfo->_psbdata != NULL);
	ASSERT(lpInfo->sImageInfo.bitperpix == 32);
	ASSERT(lpInfo->sImageInfo.height > 0);	
	ASSERT(lpInfo->sImageInfo.width > 0);	
	ASSERT(lpInfo->annexdata.siAnnData[0]<2);		// full image or region

	// Initialize the destine image infomation
	lpInfo->dImageInfo.height=lpInfo->sImageInfo.height;
	lpInfo->dImageInfo.width=lpInfo->sImageInfo.width;
	lpInfo->dImageInfo.bitperpix=lpInfo->sImageInfo.bitperpix;
	lpInfo->dImageInfo.byteperline=lpInfo->sImageInfo.byteperline;
	lpInfo->dImageInfo.bAlpha=lpInfo->sImageInfo.bAlpha;

	// Set Modify flag
	lpInfo->modify=1;

	// �������ڴ�ű�׼ͼ��λ���ݵ��ڴ��
	unsigned char * _pbdata = (unsigned char * )::GlobalAlloc(GPTR, lpInfo->dImageInfo.width * 4 * lpInfo->dImageInfo.height);
	if (!_pbdata)
	{
		lpInfo->result=PR_MEMORYERR;
		return ;
	}
	lpInfo->_pdbdata=_pbdata;
	// �������ڴ��ÿһɨ���е�ַ��ָ�����鲢��ʼ��
	unsigned long** pLineAddr = (unsigned long**)::GlobalAlloc(GPTR, lpInfo->dImageInfo.height*sizeof(DWORD*));
	if (!pLineAddr)
	{
		::GlobalFree(_pbdata);
		lpInfo->result=PR_MEMORYERR;
		return ;
	}
	// ��ʼ����������
	for (int y=0;y<lpInfo->dImageInfo.height;y++)
		pLineAddr[y] = (DWORD*)(_pbdata+((lpInfo->dImageInfo.height-y-1)*(lpInfo->dImageInfo.width *4)));
	lpInfo->pdLineAddr=pLineAddr;
	
	// Initialize destine image use source image
	// memcpy(lpInfo->_pdbdata, lpInfo->_psbdata, lpInfo->dImageInfo.width * 4 * lpInfo->dImageInfo.height);

	// To show the preview windows
	CPreviewDlg preViewDlg;    // ��ʾ�����˶Ի���
	preViewDlg.SendPreviewImage(lpInfo);
	if(preViewDlg.DoModal()!=IDOK)
	{
		::GlobalFree(lpInfo->_pdbdata); 
		lpInfo->_pdbdata=NULL;
		::GlobalFree(lpInfo->pdLineAddr);
		lpInfo->pdLineAddr=NULL;
		lpInfo->result=PR_NULL;
		return ;
	}
	
	lpInfo->result=PR_SUCCESS;
	return ;
}

// Get pixel value in inside standard format
BOOL _fnCOM_GetPixel(LPIMAGEPROCSTR lpInfo, int x, int y, DWORD* pPixel)
{
	// Make sure the point inside the image
	ASSERT(x>= 0 );		
	ASSERT(x< lpInfo->sImageInfo.width);
	ASSERT(y>= 0 );		
	ASSERT(y< lpInfo->sImageInfo.height);
	// Get pixel value, for speed use DWORD
	*pPixel = *(lpInfo->psLineAddr[y] + x );
	
	return TRUE;
}

// Set pixel value in inside standard format
BOOL _fnCOM_SetPixel(LPIMAGEPROCSTR lpInfo, int x, int y, DWORD* pPixel)
{
	// Make sure the point inside the image
	ASSERT(x>= 0 );		
	ASSERT(x< lpInfo->dImageInfo.width);
	ASSERT(y>= 0 );		
	ASSERT(y< lpInfo->dImageInfo.height);
	
	// Set pixel value ,for speed use DWORD
	*(lpInfo->pdLineAddr[y] + x ) = *pPixel;

	return TRUE;
}

// Fill rect region if coordinate is equal, line is drawed
BOOL _fnCOM_FillRect(LPIMAGEPROCSTR lpInfo, RECT rect, DWORD* pPixel)
{
	// Make sure the rect inside the image
	if (rect.left<0 ||rect.left>rect.right||rect.right > lpInfo->dImageInfo.width-1)
		return FALSE;
	if (rect.top<0 ||rect.top>rect.bottom||rect.bottom > lpInfo->dImageInfo.height-1)
		return FALSE;
	// Fill rect use given pixel
	for (int i=rect.left; i<=rect.right; i++)
		for(int j=rect.top; j<=rect.bottom; j++)
			_fnCOM_SetPixel(lpInfo, i, j, pPixel);
	return TRUE;
}

// Get zoom image 
BOOL _fnCOM_GetZoomImage(LPIMAGEPROCSTR lpInfo, float fXzoom, float fYzoom, LPBITMAPINFOHEADER lpBi, LPVOID lpBits)
{
	int zoom_width, zoom_height;
	zoom_width= (int)(lpInfo->sImageInfo.width * fXzoom);
	zoom_height= (int)(lpInfo->sImageInfo.height * fYzoom);
	
	lpBi = new BITMAPINFOHEADER;
	lpBits= malloc(zoom_width* zoom_height *4);
	// Set bi value
	HWND hWnd = ::GetDesktopWindow();
	HDC hDC = ::GetDC(hWnd);
	lpBi->biSize = sizeof(BITMAPINFOHEADER);
	lpBi->biPlanes = 1;
	lpBi->biBitCount = 32;
	lpBi->biCompression = BI_RGB;
	lpBi->biSizeImage = 0;
	lpBi->biWidth = zoom_width;
	lpBi->biHeight =  zoom_height;
	lpBi->biClrImportant = 0;
	lpBi->biClrUsed = 0;
	lpBi->biXPelsPerMeter = (int)(::GetDeviceCaps(hDC,LOGPIXELSX)*(float)39.373);
	lpBi->biYPelsPerMeter = (int)(::GetDeviceCaps(hDC,LOGPIXELSY)*(float)39.373);

	// x0= gx(x,y)= ax+by+cxy+d
	// y0= gy(x,y)= ex+fy+gxy+h
	// (0,0)--(0,0), (zoom_with-1,0)--(width-1, 0),
	// (0,zoom_height-1)--(0,height-1),(zoom_width-1,zoom_height-1)--(width-1, height-1)
	//	b=0; c=0; d=0; e=0;g=0;h=0
	float a,f, x0,y0;
	a=((float)(lpInfo->sImageInfo.width-1))/(zoom_width-1);
	f=((float)(lpInfo->sImageInfo.height-1))/(zoom_height-1);
	for(int i=0; i<=zoom_width-1; i++)
		for(int j=0; j<=zoom_height; j++)
		{
			x0= a* i;
			y0= f*j;
			// Get pixel
			DWORD temp =_fnSPE_BilinearInterValue(lpInfo, x0, y0);
			// Set pixel

		}

	return TRUE;
}

///////////////////////////////////////////////////////////////
//  Special function is added here


// Mosaic a special region
BOOL _fnSPE_MOSAIC(LPIMAGEPROCSTR lpInfo, int Size, RECT* pRect)			// ������
{
	// The mosaic unit size should not be too large
	ASSERT(Size<= 32);
	ASSERT(Size>= 2 );
	
	// Temp pixel value
	DWORD dwPixel;
	// Make sure the rect is large than mosaic unit size
	if (pRect!=NULL)
	{
		// Copy the unchanged part in source image into destine image
		int i, j;
		for(i=0; i< pRect->top; i++)
			for(j=0; j<lpInfo->dImageInfo.width; j++)
			{
				_fnCOM_GetPixel(lpInfo, j, i, &dwPixel);
				_fnCOM_SetPixel(lpInfo, j, i, &dwPixel);
			}
		for(i=pRect->top; i<= pRect->bottom; i++)
		{
			for(j=0; j<pRect->left; j++)
			{
				_fnCOM_GetPixel(lpInfo, j, i, &dwPixel);
				_fnCOM_SetPixel(lpInfo, j, i, &dwPixel);
			}
			for(j=pRect->right+1; j< lpInfo->dImageInfo.width; j++)
			{
				_fnCOM_GetPixel(lpInfo, j, i, &dwPixel);
				_fnCOM_SetPixel(lpInfo, j, i, &dwPixel);
			}
		}
		for(i=pRect->bottom+1; i< lpInfo->dImageInfo.height; i++)
			for(j=0; j<lpInfo->dImageInfo.width; j++)
			{
				_fnCOM_GetPixel(lpInfo, j, i, &dwPixel);
				_fnCOM_SetPixel(lpInfo, j, i, &dwPixel);
			}
	}
	// Mosaic a certain image
	RECT UnitRect, WholeRect;
	if (pRect==NULL)
	{
		WholeRect.left=0;
		WholeRect.right=lpInfo->dImageInfo.width-1;
		WholeRect.top=0;
		WholeRect.bottom=lpInfo->dImageInfo.height-1;
	}
	else
	{
		WholeRect.left=pRect->left;
		WholeRect.right=pRect->right;
		WholeRect.top=pRect->top;
		WholeRect.bottom=pRect->bottom;
	}
	// initialize mosaic unit 
	UnitRect.left=WholeRect.left;
	UnitRect.right=UnitRect.left+Size;
	UnitRect.top=WholeRect.top;
	UnitRect.bottom=UnitRect.top+Size;
	
	while(UnitRect.bottom<=WholeRect.bottom)
	{
		while(UnitRect.right<=WholeRect.right)
		{
			_fnCOM_GetPixel(lpInfo, UnitRect.left+Size/2,UnitRect.top+Size/2, &dwPixel);
			_fnCOM_FillRect(lpInfo, UnitRect, &dwPixel);
			UnitRect.left=UnitRect.right+1;
			UnitRect.right=UnitRect.left+Size;
		}
		if (UnitRect.left<=WholeRect.right)
		{
			UnitRect.right=WholeRect.right;
			_fnCOM_GetPixel(lpInfo, (UnitRect.left+UnitRect.right)/2,(UnitRect.top+UnitRect.bottom)/2, &dwPixel);
			_fnCOM_FillRect(lpInfo, UnitRect, &dwPixel);
		}
		UnitRect.left=WholeRect.left;
		UnitRect.right=UnitRect.left+Size;
		UnitRect.top=UnitRect.bottom+1;
		UnitRect.bottom=UnitRect.top+Size;
	}
	
	if (UnitRect.top<=WholeRect.bottom)
	{
		UnitRect.bottom=WholeRect.bottom;
		UnitRect.left=WholeRect.left;
		UnitRect.right=UnitRect.left+Size;
		while(UnitRect.right<=WholeRect.right)
		{
			_fnCOM_GetPixel(lpInfo, UnitRect.left,UnitRect.top, &dwPixel);
			_fnCOM_FillRect(lpInfo, UnitRect, &dwPixel);
			UnitRect.left=UnitRect.right+1;
			UnitRect.right=UnitRect.left+Size;
		}
		if (UnitRect.left<=WholeRect.right)
		{
			WholeRect.right=WholeRect.right;
			_fnCOM_GetPixel(lpInfo, UnitRect.left,UnitRect.top, &dwPixel);
			_fnCOM_FillRect(lpInfo, UnitRect, &dwPixel);
		}
	}
	return TRUE;
}
// Get pixel value for image, use bilinear method
DWORD _fnSPE_BilinearInterValue(LPIMAGEPROCSTR lpInfo, float x, float y)
{
	DWORD pixel, point1, point2, point3, point4;
	pStdPix pPixel;
	//pPixel=(pStdPix)pixel;
	pPixel=(pStdPix)&pixel;		// YZ Modify at 2000-11-22
	int ix, iy;
	float ddx, ddy, f_ddx_y, f_ddx_y1, f_ddx_ddy;

	ix= (int)x;
	iy= (int)y;

	// get the difference
	ddx=x-ix;
	ddy=y-iy;

	// If the point is on the right_bottom point
	if (x==lpInfo->sImageInfo.width-1 && y==lpInfo->sImageInfo.height-1)
	{
		_fnCOM_GetPixel(lpInfo,ix,iy,&point1);
		return point1;
	}

	// If point is on the right edge of image
	if(ix==lpInfo->sImageInfo.width-1)
	{
		_fnCOM_GetPixel(lpInfo,ix,iy,&point1);
		_fnCOM_GetPixel(lpInfo,ix,iy+1,&point2);
		pPixel->blue= (BYTE)(((pStdPix)&point1)->blue +
						ddx * (((pStdPix)&point2)->blue - ((pStdPix)&point1)->blue));
		pPixel->green= (BYTE)(((pStdPix)&point1)->green +
						ddx * (((pStdPix)&point2)->green - ((pStdPix)&point1)->green));
		pPixel->red= (BYTE)(((pStdPix)&point1)->red +
						ddx * (((pStdPix)&point2)->red- ((pStdPix)&point1)->red));
		pPixel->alpha=(BYTE)0;
		return pixel;
	}

	// If point is on the bottom edge of image
	if(iy==lpInfo->sImageInfo.height-1)
	{
		_fnCOM_GetPixel(lpInfo,ix,iy,&point1);
		_fnCOM_GetPixel(lpInfo,ix+1,iy,&point2);
		pPixel->blue= (BYTE)(((pStdPix)&point1)->blue +
						ddx * (((pStdPix)&point2)->blue - ((pStdPix)&point1)->blue));
		pPixel->green= (BYTE)(((pStdPix)&point1)->green +
						ddx * (((pStdPix)&point2)->green - ((pStdPix)&point1)->green));
		pPixel->red= (BYTE)(((pStdPix)&point1)->red +
						ddx * (((pStdPix)&point2)->red- ((pStdPix)&point1)->red));
		pPixel->alpha=(BYTE)0;
		return pixel;
	}
	// The point is in image
	_fnCOM_GetPixel(lpInfo,ix,iy,&point1);
	_fnCOM_GetPixel(lpInfo,ix,iy+1,&point2);
	_fnCOM_GetPixel(lpInfo,ix+1,iy+1,&point3);
	_fnCOM_GetPixel(lpInfo,ix+1,iy,&point4);
	// red color
	f_ddx_y= ((pStdPix)&point1)->red+ ddx*(((pStdPix)&point4)->red -((pStdPix)&point1)->red);
	f_ddx_y1= ((pStdPix)&point2)->red+ ddx*(((pStdPix)&point3)->red-((pStdPix)&point2)->red);
	f_ddx_ddy=f_ddx_y + ddy*(f_ddx_y1 - f_ddx_y);
	pPixel->red=(BYTE)f_ddx_ddy;
	// green color
	f_ddx_y= ((pStdPix)&point1)->green+ ddx*(((pStdPix)&point4)->green-((pStdPix)&point1)->green);
	f_ddx_y1= ((pStdPix)&point2)->green+ ddx*(((pStdPix)&point3)->green-((pStdPix)&point2)->green);
	f_ddx_ddy=f_ddx_y + ddy*(f_ddx_y1 - f_ddx_y);
	pPixel->green=(int)f_ddx_ddy;
	// blue color
	f_ddx_y= ((pStdPix)&point1)->blue+ ddx*(((pStdPix)&point4)->blue-((pStdPix)&point1)->blue);
	f_ddx_y1= ((pStdPix)&point2)->blue+ ddx*(((pStdPix)&point3)->blue-((pStdPix)&point2)->blue);
	f_ddx_ddy=f_ddx_y + ddy*(f_ddx_y1 - f_ddx_y);
	pPixel->blue=(int)f_ddx_ddy;
	
	return pixel;
}
BOOL CALLBACK WINAPI MosaicProc(HWND hWnd,UINT uMsg,UINT wParam,LONG lParam)
{
	return FALSE;
}
