// PngModule.h : main header file for the PNGMODULE DLL
//

#if !defined(AFX_PNGMODULE_H__C03B0E6D_460A_11D4_8853_C6A14464AE19__INCLUDED_)
#define AFX_PNGMODULE_H__C03B0E6D_460A_11D4_8853_C6A14464AE19__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "..\public\gol_isee.h"	// ���ļ������˽ӿ����ݰ�
#include ".\pnginc\png.h"


#define DIBSCANLINE_WIDTHBYTES(bits)    (((bits)+31)/32*4)


/////////////////////////////////////////////////////////////////////////////
// CPngModuleApp
// See PngModule.cpp for the implementation of this class
//

class CPngModuleApp : public CWinApp
{
public:
	CPngModuleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPngModuleApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CPngModuleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


// ����ģ��汾
#define	MODULE_BUILDID		1
#define RWPROGRESSSIZE			100		// �ܵĽ�����ֵ����ֵ���ܸĶ���


struct _tagPNGINFOHEADER;
typedef _tagPNGINFOHEADER PNGINFOHEADER;

// �ӿں������� �� ��һ�㣬Ψһ�������ϵ�Ľӿ�
long WINAPI GetLong(void);
int WINAPI AccessPNGModule(INFOSTR *pInfo);


// ������ͺ��� �� �ڶ�����ͺ���
void _fnCMD_GETPROCTYPE(INFOSTR *pInfo);
void _fnCMD_GETWRITERS(INFOSTR *pInfo);
void _fnCMD_GETWRITERMESS(INFOSTR *pInfo);
void _fnCMD_GETBUILDID(INFOSTR *pInfo);
void _fnCMD_IS_VALID_FILE(INFOSTR *pInfo);
void _fnCMD_GET_FILE_INFO(INFOSTR *pInfo);
void _fnCMD_LOAD_FROM_FILE(INFOSTR *pInfo);
void _fnCMD_SAVE_TO_FILE(INFOSTR *pInfo);
void _fnCMD_IS_SUPPORT(INFOSTR *pInfo);
void _fnCMD_RESIZE(INFOSTR *pInfo);

// �ڲ�ִ�к��� - ������ִ�к���.....
BOOL Image24to32(INFOSTR *pInfo, PBYTE pImage, PBYTE* pLineAddr);
BOOL Image24to16(INFOSTR *pInfo, PBYTE pImage, PBYTE* pLineAddr);
BOOL Image24to24(INFOSTR *pInfo, PBYTE pImage, PBYTE* pLineAddr);


void pngSetIHDR(png_structp pPng, png_infop pPngInfo, INFOSTR *pInfo);
BOOL TransformImage16(INFOSTR *pInfo, PBYTE pngImage);
BOOL TransformImage24(INFOSTR *pInfo, PBYTE pngImage);
BOOL TransformImage32(INFOSTR* pInfo, PBYTE pngImage);
BOOL TransformImage1_4_8(INFOSTR* pInfo, PBYTE pngImage);


//PNG�û��Զ����д����������������
static void PngErrorHandler(png_structp png_ptr, png_const_charp message);
static void PngRead4Win32(png_structp png_ptr, png_bytep data, png_size_t length);
static void PngWrite4Win32(png_structp png_ptr, png_bytep data, png_size_t length);
static void PngFlush4Win32(png_structp png_ptr);


//PNGDLL�������ȫ�ֱ����ͽṹ����

/* PNGͼ����Ϣ�ṹ */
struct _tagPNGINFOHEADER
{
	DWORD Width;
	DWORD Height;
	int color_type; 
	int bit_depth;
	int interlace_type;
	int filter_type;
	int compression_type;
	int number_passes;
};	


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PNGMODULE_H__C03B0E6D_460A_11D4_8853_C6A14464AE19__INCLUDED_)
