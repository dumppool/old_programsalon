// IcoModule.h : main header file for the ICOMODULE DLL
//

#if !defined(AFX_ICOMODULE_H__C03B0E3D_460A_11D4_8853_C6A14464AE19__INCLUDED_)
#define AFX_ICOMODULE_H__C03B0E3D_460A_11D4_8853_C6A14464AE19__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "..\public\gol_isee.h"	// ���ļ������˽ӿ����ݰ�


#define ICONTYPE	1
#define CURTYPE		2

// ɨ���п���
#define WIDTHBYTES(bits)      ((((bits)+31)>>5)<<2)
#define RWPROGRESSSIZE		  100

#define BORDERSPEC	16
#define IMGTXTSPEC	4
#define TXTIMGSPEC	8

// ����ͼ��ͼ�����Ϣͷ�ṹ
typedef struct
{
	BYTE	bWidth;               // Width of the image
	BYTE	bHeight;              // Height of the image (times 2)
	BYTE	bColorCount;          // Number of colors in image (0 if >=8bpp)
	BYTE	bReserved;            // Reserved
	WORD	wPlanes;              // Color Planes
	WORD	wBitCount;            // Bits per pixel
	DWORD	dwBytesInRes;         // how many bytes in this resource?
	DWORD	dwImageOffset;        // where in the file is this image
} ICONDIRENTRY, *LPICONDIRENTRY;

// ͼ���ļ���Ϣͷ�ṹ
typedef struct 
{
	WORD			idReserved;   // Reserved
	WORD			idType;       // resource type (1 for icons)
	WORD			idCount;      // how many images?
	ICONDIRENTRY	idEntries[1]; // the entries for each image
} ICONDIR, *LPICONDIR;


// ͼ����Ϣ�ṹ
typedef struct
{
	int			index;
	int			colnum;				// ��ɫ���������λ�����8bpp��Ϊ0��
	SIZE		imgsize;			// ͼ��ߴ�
	SIZE		txtsize;			// ͼ���������ߴ�
	char		string[32];			// ͼ��ߴ��ִ�
} IMGINFO, *LPIMGINFO;

/////////////////////////////////////////////////////////////////////////////
// CIcoModuleApp
// See IcoModule.cpp for the implementation of this class
//

class CIcoModuleApp : public CWinApp
{
public:
	CIcoModuleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIcoModuleApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CIcoModuleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


// ����ģ��汾
#define	MODULE_BUILDID		11


// �ӿں������� �� ��һ�㣬Ψһ�������ϵ�Ľӿ�
int WINAPI AccessICOModule(INFOSTR *pInfo);


// ������ͺ��� �� �ڶ�����ͺ���
void _fnCMD_GETPROCTYPE(INFOSTR *pInfo);
void _fnCMD_GETWRITERS(INFOSTR *pInfo);
void _fnCMD_GETWRITERMESS(INFOSTR *pInfo);
void _fnCMD_GETBUILDID(INFOSTR *pInfo);
void _fnCMD_IS_VALID_FILE(INFOSTR *pInfo);
void _fnCMD_GET_FILE_INFO(INFOSTR *pInfo);
void _fnCMD_LOAD_FROM_FILE(INFOSTR *pInfo);
void _fnCMD_SAVE_TO_FILE(INFOSTR *pInfo);
void _fnCMD_IS_SUPPORT(INFOSTR *pInfo);
void _fnCMD_RESIZE(INFOSTR *pInfo);

// �ڲ�ִ�к��� - ������ִ�к���.....

BOOL IsFileExist(char *lpFileName);
LPICONDIR ReadIconInfo(CFile& file);
UINT ReadICOHeader(CFile file);
LPSTR FindDIBBits(LPSTR lpbi);
WORD DIBNumColors(LPSTR lpbi);
WORD PaletteSize(LPSTR lpbi);
DWORD BytesPerLine(LPBITMAPINFOHEADER lpBMIH);

void _get_image_info(LPICONDIR lpIR, int index, LPSIZE lpSize, int *pColnum);
void _get_string_info(LPSIZE lpImgSize, int colnum, LPTSTR lpString, LPSIZE lpTxtSize);
void _get_synthesis_imgsize(int imgcount, LPIMGINFO lpImgInfo, LPSIZE lpSize);
void _do_sort(int imgcount, LPIMGINFO lpImgInfo);
HBITMAP _get_hbmp(CFile& file, LPICONDIR lpIR, LPIMGINFO lpImgInfo, int index);

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ICOMODULE_H__C03B0E3D_460A_11D4_8853_C6A14464AE19__INCLUDED_)
