#ifndef _PCX_DECLARE_H_
#define _PCX_DECLARE_H_
typedef struct pcxheader
{
	BYTE byManufacturer;
	BYTE byVersion;
	BYTE byEncoding;
	BYTE byBits;
	WORD wLeft;
	WORD wTop;
	WORD wRight;
	WORD wBottom;
	WORD wXResolution;
	WORD wYResolution;
	BYTE byPalette[48];
	BYTE byReserved;
	BYTE byPlanes;
	WORD wLineBytes;
	WORD wPaletteType;
	WORD wScrWidth;
	WORD wScrDepth;
	BYTE byFiller[54];
}  PCXFILEHEADER;
const BYTE PCX_FILE_FLAG=0x0A;
#endif// _PCX_DECLARE_H_