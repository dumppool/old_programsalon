#include "stdafx.h"
#include "PcxSave.h"
void Pcx_Save_To_File(INFOSTR *pInfo)
{
	return;
};