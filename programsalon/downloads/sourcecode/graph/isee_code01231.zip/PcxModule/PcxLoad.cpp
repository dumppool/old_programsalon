#include "stdafx.h"
#include "PcxDeclare.h"
#include "PcxModule.h"
#include "FuncFromYz.h"
#include "PcxError.h"
#include "PcxPalette.h"
#define PCX_BUF_MAX 124

#define DIBSCANLINE_WIDTHBYTES(bits)    (((bits)+31)/32*4)
EXERESULT api_Isee_Check_Command_Load(INFOSTR *pInfo)
{
	// ������ڲ����Ƿ���Ͻӿڶ���
	ASSERT(pInfo->result == ER_EMPTY);
	ASSERT(::strlen(pInfo->filename));
	// ��ʱ�����ļ�������һ���Ѵ��ڵġ���Ч��PCX�ļ����������ݰ���
	// ���и��ļ�����Ϣ��imginfo�ṹ�У�
	ASSERT(pInfo->state == PKST_PASSINFO);
	ASSERT(pInfo->imginfo.imgformat == IMF_PCX);
	ASSERT(pInfo->pImgInfo == NULL);
	// �������ñ�׼ͼ���ʽ��Ϣ
	ASSERT(pInfo->sDIBInfo.bmi.biSize == sizeof(BITMAPINFOHEADER));
	ASSERT(pInfo->pLineAddr != NULL);
	ASSERT(pInfo->_pbdata != NULL);

	return ER_SUCCESS;
};
EXERESULT Isee_Api_Access_Progress(INFOSTR *pInfo, int MaxPreg, int CurrentPreg)
{
	if (pInfo->fpProgress)
	{
		if ((*pInfo->fpProgress)(MaxPreg, CurrentPreg))
		{	// ������Ⱥ�������1����˵���û����жϲ��������ء�
			pInfo->result = ER_USERBREAK;
			return ER_USERBREAK;
		}
	}
	return ER_SUCCESS;
};
void Pcx_Access_Progress(INFOSTR *pInfo, int MaxPreg = 0, int CurrentPreg = 0)
{
	if (pInfo->fpProgress)
	{
		if ((*pInfo->fpProgress)(100, 6))
		{	// ������Ⱥ�������1����˵���û����жϲ���������(throw)��
			pInfo->result = ER_USERBREAK;//���˺������ķ���ֵ
			ApiThrowMyExce(ENO_USERBREAK);//throw ���� catch
		}
	}
}

BOOL Success(int tag_param)
{
	return (tag_param == ER_SUCCESS);
};

EXERESULT Pcx_Load_sub_1(INFOSTR * pInfo, LPCSTR lpData, int iDataSize);
EXERESULT Pcx_Load_sub_4(INFOSTR * pInfo, LPCSTR lpData, int iDataSize);
EXERESULT Pcx_Load_sub_8(INFOSTR * pInfo, LPCSTR lpData, int iDataSize);
EXERESULT Pcx_Load_sub_24(INFOSTR * pInfo, LPCSTR lpData, int iDataSize);

void PcxFitPinfo(INFOSTR * pInfo)
{
	HGLOBAL p = (HGLOBAL)pInfo->pImgInfo;
//	::GlobalUnlock(p);
	if(p == NULL)return;
	::GlobalFree(p);
	pInfo->pImgInfo = NULL;
}

void Pcx_Load_From_File(INFOSTR * pInfo)
{
	EXERESULT rt = ER_SUCCESS;//ϣ����˳��ִ�У�^_^

	rt = api_Isee_Check_Command_Load(pInfo);
	if(! Success(rt))
	{
		pInfo->result = rt;
		return;
	}

	unsigned long	bitcount = 0;
	ENUM_EXCE_NO no = ENO_OK;

	HANDLE hf = NULL;
	DWORD filesize = 0;
	HANDLE hMapping = NULL;
	LPSTR lpData = NULL;
	const char * pcStrFileName = pInfo->filename;

	rt = Isee_Api_Access_Progress(pInfo,100,100);//rt ����

	filesize = (DWORD)pInfo->imginfo.filesize;
	try
	{
		hf = CreateFile(pcStrFileName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
		if( hf == INVALID_HANDLE_VALUE)
		{
			rt = ER_FILERWERR;
			ApiThrowMyExce(ENO_CREATE_FILE_EX);
		}
		hMapping = CreateFileMapping(hf,NULL,PAGE_READONLY,0,filesize,NULL);
		if(hMapping == NULL)
		{
			rt = ER_MEMORYERR;
			ApiThrowMyExce(ENO_CREATE_MAP_EX);
		}
		
		lpData = (LPSTR)MapViewOfFile(hMapping,FILE_MAP_READ,0,0,0);
		if(lpData == NULL)
		{
			rt = ER_MEMORYERR;
			ApiThrowMyExce(ENO_MAP_VIEW_EX);
		}

		PcxDoWithPalette(pInfo, lpData,filesize);

		bitcount = pInfo->imginfo.bitcount;
		switch(bitcount)
		{
		case 1:
			rt = Pcx_Load_sub_1(pInfo, lpData, filesize);
			break;
		case 4:
			rt = Pcx_Load_sub_4(pInfo, lpData, filesize);
			break;
		case 8:
			rt = Pcx_Load_sub_8(pInfo, lpData, filesize);
			break;
		case 24:
			rt = Pcx_Load_sub_24(pInfo, lpData, filesize);
			break;
		}
	}
	catch(CMyException myExce)
	{
		no = myExce.GetNo();
		CString str;

	}
	switch(no)
	{
		default:
		case ENO_OK:
		case ENO_USERBREAK:
			//rt ����
		rt = pInfo->result;

		UnmapViewOfFile(lpData);
		case ENO_MAP_VIEW_EX:
		CloseHandle(hMapping);
		case ENO_CREATE_MAP_EX:
		CloseHandle(hf);
		case ENO_CREATE_FILE_EX:
				rt = ER_FILERWERR;
	}
	Isee_Api_Access_Progress(pInfo,100,100);//rt ����
//***************************
	PcxFitPinfo(pInfo);
	pInfo->state = PKST_INFOANDBITS;
	pInfo->modify = 0;
	pInfo->result = ER_SUCCESS;

	//�������ж�
	return;
};
EXERESULT Pcx_Load_sub_4(INFOSTR * pInfo, LPCSTR lpData, int iDataSize)
{

	const PCXFILEHEADER *const pcxFileHead=(const PCXFILEHEADER *) lpData;//�ļ�ͷ
	LPCSTR const pImage = lpData + sizeof(PCXFILEHEADER);//ͼ�����ݡ���ȡ���
	const struct PcxPalette * const lpPalette = (struct PcxPalette * )pcxFileHead->byPalette;//��ɫ��

//from yz
	DWORD imgheight = pInfo->imginfo.height;	// ͼ��ĸ߶�
	DWORD imgwidth  = pInfo->imginfo.width;	// ͼ��Ŀ���
	DWORD dwDestFormat = _get_desformat(pInfo);//Ŀ���ʽ

	DWORD dwPcxOneScanLineSize  = pcxFileHead->wLineBytes;// ÿһɨ���еĿ���(in byte)
	DWORD dwPcxLineSizeCount = pcxFileHead->wLineBytes * pcxFileHead->byPlanes;

	DWORD dwImageHeightCount, dwImageWidthCount;//���ڼ���
	//

	char * const pScanLineBuf = (char *)new char[dwPcxLineSizeCount + 16];//16 for ��ȫ
	//��ѹ������
	if(pScanLineBuf == NULL)
		ApiMyThrowMem();


	WORD * pLineDest = NULL;//Ŀ�����׵�ַ��
	WORD * pLineSource = NULL;//Դ���׵�ַ��
	pLineSource = (WORD *)pScanLineBuf;//Դ....
//	WORD * pPixDest = NULL;//Ŀ���ַ��(Ŀ���ַ�ֱ���)

	BYTE ch1,ch2;
	char * pScan = NULL;////��ѹָ��
	DWORD ScanLinePoint = 0;//��ѹ����

	// �Ը��ָ�ʽ�ĵ�ɫ������
	//..����ѭ���⡢�Կռ任ȡʱ��
	WORD descol555[16];
	WORD descol565[16];
	DWORD descol888[16];
	WORD * pDesPixAddr555 = NULL;
	WORD * pDesPixAddr565 = NULL;
	BYTE * pDesPixAddr24 = NULL;
	DWORD * pDesPixAddr888 = NULL;
	int i;
	switch(dwDestFormat)	// ��׼ͼ���ʽ��Ŀ���ʽ��
	{
	case	DF_16_555:
		{
		for (i=0;i<16;i++)	// ��ʼ��ɫ����ɫ����
			descol555[i] = _cnv_rgb_to_555(lpPalette[i].byRed, lpPalette[i].byGreen, lpPalette[i].byBlue);
		}
		break;
	case	DF_16_565:
		{
		for (i=0;i<16;i++)	// ��ʼ��ɫ����ɫ����
			descol565[i] = _cnv_rgb_to_565(lpPalette[i].byRed, lpPalette[i].byGreen, lpPalette[i].byBlue);
		}
		break;
	case	DF_32:
		{
		for (i=0;i<16;i++)	// ��ʼ��ɫ����ɫ����
			descol888[i] = _cnv_rgb_to_888(lpPalette[i].byRed, lpPalette[i].byGreen, lpPalette[i].byBlue);
		}
		break;
	default:
		break;
	}

//	int i, j;//, isou;
//		DWORD dwPCXLineSizeCount;
	//char * pSrc = ;
	char k;//��ѹ����
	
//	char *lpPlane0,*lpPlane1,*lpPlane2,*lpPlane3;//����ָ��
	BYTE byPlane0,byPlane1,byPlane2,byPlane3;//��ֵ
//	BYTE byIndex1,byIndex2,byIndex3,byIndex4;//����ֵ
//	BYTE byIndex5,byIndex6,byIndex7,byIndex8;//����ֵ

	LPCSTR pSrc = pImage;//��ȡ���//������������:-)
	for(dwImageHeightCount=0;dwImageHeightCount<imgheight;dwImageHeightCount++)//Pcx ��������
	{
			pScan = (char *)(pScanLineBuf);
			ScanLinePoint = 0;
			//while(ScanLinePoint <dwPCXScanLineSize&&!feof(f1))//base 0;Index
			while(ScanLinePoint <dwPcxLineSizeCount)//base 0;Index
			{
				if((pSrc - lpData)>=iDataSize)break;
				ch1=(*pSrc ++)&0xFF;//fgetc() return int;
				if((ch1&0xc0)==0xC0)
				{
					k = ch1&0x3F;
					ch2 = (*pSrc ++)&0xFF;
					while(k--)//&&ScanLinePoint<dwPCXScanLineSize)
					{
						pScan[ScanLinePoint++] = ch2;//
					}
				}
				else
				{
					pScan[ScanLinePoint++] = ch1;
				}
			}//while (pcxLineWidth)//��ѹһ��


			pLineDest = (WORD*)pInfo->pLineAddr[dwImageHeightCount];//��ǰĿ�� (��)
			//Դ��pLineBuf
			pLineSource = (WORD *)pScanLineBuf;//Դ....
			//Դ��ַ���ǲ���

			//Ŀ�� ���ڴ˳�ʼ��
			pDesPixAddr555 = (WORD * )pLineDest;
			pDesPixAddr565 = (WORD * )pLineDest;
			pDesPixAddr24 = (BYTE * )pLineDest;

			pDesPixAddr888 = (DWORD * )pLineDest;
			dwImageWidthCount = 0;

		for(ScanLinePoint=0;ScanLinePoint<dwPcxOneScanLineSize;ScanLinePoint++)//����һ��
		{
			//****************************************//read 1 byte;
			byPlane0 = *((char *)pScanLineBuf+dwPcxOneScanLineSize*0+ScanLinePoint);
			byPlane1 = *((char *)pScanLineBuf+dwPcxOneScanLineSize*1+ScanLinePoint);
			byPlane2 = *((char *)pScanLineBuf+dwPcxOneScanLineSize*2+ScanLinePoint);
			byPlane3 = *((char *)pScanLineBuf+dwPcxOneScanLineSize*3+ScanLinePoint);
			//****************************************
			//point 1-2 in 1st byte
			int i;
			BYTE byFlag = 1; //����
			BYTE byIndex;
			for(i = 7; i>=0;i--)//(��λ��ǰ)
			{
				byFlag = 1<<i;
				
				byIndex=0x00;
				byIndex |=((byPlane3 & byFlag)? 0x08:byIndex);
				byIndex |=((byPlane2 & byFlag)? 0x04:byIndex);
				byIndex |=((byPlane1 & byFlag)? 0x02:byIndex);
				byIndex |=((byPlane0 & byFlag)? 0x01:byIndex);
				{
				}
				
				switch(dwDestFormat)	// ��׼ͼ���ʽ��Ŀ���ʽ��
				{
				case	DF_16_555:
					{
						if(dwImageWidthCount < imgwidth)
						{
							*pDesPixAddr555++ = descol555[byIndex];
							dwImageWidthCount ++;
						}
					break;
					}
				case	DF_16_565:
					{
						if(dwImageWidthCount < imgwidth)
						{
							*pDesPixAddr565++ = descol565[byIndex];
							dwImageWidthCount ++;
						}

						break;
					}

				case	DF_24:
					{
						if(dwImageWidthCount < imgwidth)
						{
							*pDesPixAddr24++ = lpPalette[byIndex].byBlue;
							*pDesPixAddr24++ = lpPalette[byIndex].byGreen;
							*pDesPixAddr24++ = lpPalette[byIndex].byRed;
						}
						break;
					}
				case	DF_32:
					{
						if(dwImageWidthCount < imgwidth)
						{
							*pDesPixAddr888++ = descol888[byIndex];
							dwImageWidthCount ++;
						}
						break;
					}
				case	DF_NULL:
				default:
					ASSERT(FALSE);
					pInfo->result = ER_ILLCOMM;
					return ER_ILLCOMM;
					break;
				}//switch(dwDestFormat)
			}//for ÿ8������
	}//for dwScanLineSize;
	}//for imageheight
	delete pScanLineBuf;
	return ER_SUCCESS;
};
EXERESULT Pcx_Load_sub_8(INFOSTR * pInfo, LPCSTR lpData, int iDataSize)
{

	const PCXFILEHEADER *const pcxFileHead=(const PCXFILEHEADER *) lpData;//�ļ�ͷ
	LPCSTR const pImage = lpData + sizeof(PCXFILEHEADER);//ͼ�����ݡ���ȡ���
	const struct PcxPalette * lpPalette = NULL;//��ɫ��
	DWORD tempPaletteCount;
	GetPcxPalette((struct PcxImgInfo *)pInfo->pImgInfo, (void ** )&lpPalette, &tempPaletteCount);
	ASSERT(lpPalette != NULL);
	ASSERT(tempPaletteCount == 256);

//from yz
	DWORD imgheight = pInfo->imginfo.height;	// ͼ��ĸ߶�
	DWORD imgwidth  = pInfo->imginfo.width;	// ͼ��Ŀ���
	DWORD dwDestFormat = _get_desformat(pInfo);//Ŀ���ʽ

	DWORD dwPcxOneScanLineSize  = pcxFileHead->wLineBytes;// ÿһɨ���еĿ���(in byte)
	DWORD dwPcxLineSizeCount = pcxFileHead->wLineBytes * pcxFileHead->byPlanes;

	DWORD dwImageHeightCount, dwImageWidthCount;//���ڼ���
	//

	char * const pScanLineBuf = (char *)new char[dwPcxLineSizeCount + 16];//16 for ��ȫ
	//��ѹ������
	if(pScanLineBuf == NULL)
		ApiMyThrowMem();


	WORD * pLineDest = NULL;//Ŀ�����׵�ַ��
	BYTE * pLineSource = NULL;//Դ���׵�ַ��
	pLineSource = (BYTE *)pScanLineBuf;//Դ....
//	WORD * pPixDest = NULL;//Ŀ���ַ��(Ŀ���ַ ����ʽ�ֱ���)

	BYTE ch1,ch2;
	char * pScan = NULL;////��ѹָ��
	DWORD ScanLinePoint = 0;//��ѹ����

	// �Ը��ָ�ʽ�ĵ�ɫ������
	//..����ѭ���⡢�Կռ任ȡʱ��
	//WORD descol555[256];
	//WORD descol565[256];
	//DWORD descol888[256];
	//<��Լһ�°� ^_^ >

	WORD * descol555 = NULL;
	WORD * descol565 = NULL;
	DWORD * descol888 = NULL;

	WORD * pDesPixAddr555 = NULL;
	WORD * pDesPixAddr565 = NULL;
	BYTE * pDesPixAddr24 = NULL;
	DWORD * pDesPixAddr888 = NULL;
	int i;
	switch(dwDestFormat)	// ��׼ͼ���ʽ��Ŀ���ʽ��
	{
	case	DF_16_555:
		{
			if(descol555 == NULL)
				ApiMyThrowMem();
			descol555 = new WORD[256];
		for (i=0;i<256;i++)	// ��ʼ��ɫ����ɫ����
			descol555[i] = _cnv_rgb_to_555(lpPalette[i].byRed, lpPalette[i].byGreen, lpPalette[i].byBlue);
		}
		break;
	case	DF_16_565:
		{
			descol565 = new WORD[256];
			if(descol565 == NULL)
				ApiMyThrowMem();
			for (i=0;i<256;i++)	// ��ʼ��ɫ����ɫ����
				descol565[i] = _cnv_rgb_to_565(lpPalette[i].byRed, lpPalette[i].byGreen, lpPalette[i].byBlue);
		}
		break;
	case	DF_32:
		{
			descol888 = new DWORD[256];
				if(descol888 == NULL)
			ApiMyThrowMem();
		for (i=0;i<256;i++)	// ��ʼ��ɫ����ɫ����
			descol888[i] = _cnv_rgb_to_888(lpPalette[i].byRed, lpPalette[i].byGreen, lpPalette[i].byBlue);
		}
		break;
	default:
		break;
	}

	char k;//��ѹ����
	
	LPCSTR pSrc = pImage;//��ȡ���//������������:-)
	for(dwImageHeightCount=0;dwImageHeightCount<imgheight; dwImageHeightCount++)//Pcx ��������
	{
			pScan = (char *)(pScanLineBuf);
			ScanLinePoint = 0;
			//while(ScanLinePoint <dwPCXScanLineSize&&!feof(f1))//base 0;Index
			while(ScanLinePoint <dwPcxLineSizeCount)//base 0;Index
			{
				if((pSrc - lpData)>=iDataSize)break;
				ch1=(*pSrc ++)&0xFF;//fgetc() return int;
				if((ch1&0xc0)==0xC0)
				{
					k = ch1&0x3F;
					ch2 = (*pSrc ++)&0xFF;
					while(k--)//&&ScanLinePoint<dwPCXScanLineSize)
					{
						pScan[ScanLinePoint++] = ch2;//
					}
				}
				else
				{
					pScan[ScanLinePoint++] = ch1;
				}
			}//while (pcxLineWidth)//��ѹһ��


			pLineDest = (WORD*)pInfo->pLineAddr[dwImageHeightCount];//��ǰĿ�� (��)
			//Դ��pLineBuf
			pLineSource = (BYTE *)pScanLineBuf;//Դ....
			//Դ��ַ���ǲ���

			//Ŀ�� ���ڴ˳�ʼ��
			pDesPixAddr555 = (WORD * )pLineDest;
			pDesPixAddr565 = (WORD * )pLineDest;
			pDesPixAddr24 = (BYTE * )pLineDest;
			pDesPixAddr888 = (DWORD * )pLineDest;

			dwImageWidthCount = 0;
			BYTE byIndex = 0;
		for(dwImageWidthCount = 0;dwImageWidthCount<imgwidth;dwImageWidthCount++)//����һ��
		{
			//****************************************//read 1 byte;
			byIndex = *((BYTE *)pLineSource + dwImageWidthCount);
			
			switch(dwDestFormat)	// ��׼ͼ���ʽ��Ŀ���ʽ��
			{
			case	DF_16_555:
				{
					if(dwImageWidthCount < imgwidth)
					{
						*pDesPixAddr555++ = descol555[byIndex];
					}
					break;
				}
			case	DF_16_565:
				{
					if(dwImageWidthCount < imgwidth)
					{
						*pDesPixAddr565++ = descol565[byIndex];
					}
					break;
				}
				
			case	DF_24:
				{
					if(dwImageWidthCount < imgwidth)
					{
						*pDesPixAddr24++ = lpPalette[byIndex].byBlue;
						*pDesPixAddr24++ = lpPalette[byIndex].byGreen;
						*pDesPixAddr24++ = lpPalette[byIndex].byRed;
					}
					break;
				}
			case	DF_32:
				{
					if(dwImageWidthCount < imgwidth)
					{
						*pDesPixAddr888 = descol888[byIndex];
						pDesPixAddr888 ++;
					}
					break;
				}
			case	DF_NULL:
			default:
				ASSERT(FALSE);
				pInfo->result = ER_ILLCOMM;
				return ER_ILLCOMM;
				break;
			}//switch(dwDestFormat)
		}//for dwScanLineSize;
	}//for imageheight
	delete pScanLineBuf;
	switch(dwDestFormat)	// ��׼ͼ���ʽ��Ŀ���ʽ��
	{
	case	DF_16_555:
		{
			if(descol555 != NULL)
			delete descol555;
		}
		break;
	case	DF_16_565:
		{
			if(descol565 != NULL)
			delete descol565;
		}
		break;
	case	DF_32:
		{
			if(descol888 != NULL)
			delete descol888;
		}
		break;
	default:
		break;
	}
	return ER_SUCCESS;
};
EXERESULT Pcx_Load_sub_24(INFOSTR * pInfo, LPCSTR lpData, int iDataSize)
{
	const PCXFILEHEADER *const pcxFileHead=(const PCXFILEHEADER *) lpData;//�ļ�ͷ
	LPCSTR const pImage = lpData + sizeof(PCXFILEHEADER);//ͼ�����ݡ���ȡ���
//	const struct PcxPalette * const lpPalette = (struct PcxPalette * )pcxFileHead->byPalette;//��ɫ��

//from yz
	DWORD imgheight = pInfo->imginfo.height;	// ͼ��ĸ߶�
	DWORD imgwidth  = pInfo->imginfo.width;	// ͼ��Ŀ���
	DWORD dwDestFormat = _get_desformat(pInfo);//Ŀ���ʽ

	DWORD dwPcxOneScanLineSize  = pcxFileHead->wLineBytes;// ÿһɨ���еĿ���(in byte)
	DWORD dwPcxLineSizeCount = pcxFileHead->wLineBytes * pcxFileHead->byPlanes;

	DWORD dwImageHeightCount, dwImageWidthCount;//���ڼ���
	//

	char * const pScanLineBuf = (char *)new char[dwPcxLineSizeCount + 16];//16 for ��ȫ
	//��ѹ������
	if(pScanLineBuf == NULL)
		ApiMyThrowMem();


	WORD * pLineDest = NULL;//Ŀ�����׵�ַ��
	WORD * pLineSource = NULL;//Դ���׵�ַ��
	pLineSource = (WORD *)pScanLineBuf;//Դ....
//	WORD * pPixDest = NULL;//Ŀ���ַ��(Ŀ���ַ�ֱ���)

	BYTE ch1,ch2;
	char * pScan = NULL;////��ѹָ��
	DWORD ScanLinePoint = 0;//��ѹ����

	WORD * pDesPixAddr555 = NULL;
	WORD * pDesPixAddr565 = NULL;
	BYTE * pDesPixAddr24 = NULL;
	DWORD * pDesPixAddr888 = NULL;
//	int i;

//	int i, j;//, isou;
//		DWORD dwPCXLineSizeCount;
	//char * pSrc = ;
	char k;//��ѹ����
	
//	char *lpPlane0,*lpPlane1,*lpPlane2,*lpPlane3;//����ָ��
	BYTE byPlane0,byPlane1,byPlane2;//,byPlane3;//��ֵ
//	BYTE byIndex1,byIndex2,byIndex3,byIndex4;//����ֵ
//	BYTE byIndex5,byIndex6,byIndex7,byIndex8;//����ֵ

	LPCSTR pSrc = pImage;//��ȡ���//������������:-)
	for(dwImageHeightCount=0;dwImageHeightCount<imgheight;dwImageHeightCount++)//Pcx ��������
	{
			pScan = (char *)(pScanLineBuf);
			ScanLinePoint = 0;
			//while(ScanLinePoint <dwPCXScanLineSize&&!feof(f1))//base 0;Index
			while(ScanLinePoint <dwPcxLineSizeCount)//base 0;Index
			{
				if((pSrc - lpData)>=iDataSize)break;
				ch1=(*pSrc ++)&0xFF;//fgetc() return int;
				if((ch1&0xc0)==0xC0)
				{
					k = ch1&0x3F;
					ch2 = (*pSrc ++)&0xFF;
					while(k--)//&&ScanLinePoint<dwPCXScanLineSize)
					{
						pScan[ScanLinePoint++] = ch2;//
					}
				}
				else
				{
					pScan[ScanLinePoint++] = ch1;
				}
			}//while (pcxLineWidth)//��ѹһ��


			pLineDest = (WORD*)pInfo->pLineAddr[dwImageHeightCount];//��ǰĿ�� (��)
			//Դ��pLineBuf
			pLineSource = (WORD *)pScanLineBuf;//Դ....
			//Դ��ַ���ǲ���

			//Ŀ�� ���ڴ˳�ʼ��
			pDesPixAddr555 = (WORD * )pLineDest;
			pDesPixAddr565 = (WORD * )pLineDest;
			pDesPixAddr24 = (BYTE * )pLineDest;

			pDesPixAddr888 = (DWORD * )pLineDest;
			dwImageWidthCount = 0;

		for(ScanLinePoint=0;ScanLinePoint<dwPcxOneScanLineSize;ScanLinePoint++)//����һ��
		{
			//****************************************//read 1 byte;
			byPlane0 = *((char *)pScanLineBuf+dwPcxOneScanLineSize*0+ScanLinePoint);
			byPlane1 = *((char *)pScanLineBuf+dwPcxOneScanLineSize*1+ScanLinePoint);
			byPlane2 = *((char *)pScanLineBuf+dwPcxOneScanLineSize*2+ScanLinePoint);
			
			switch(dwDestFormat)	// ��׼ͼ���ʽ��Ŀ���ʽ��
			{
			case	DF_16_555:
				{
					if(dwImageWidthCount < imgwidth)
					{
						*pDesPixAddr555++ = _cnv_rgb_to_555(byPlane0, byPlane1, byPlane2);
						dwImageWidthCount ++;
					}
					break;
				}
			case	DF_16_565:
				{
					if(dwImageWidthCount < imgwidth)
					{
						*pDesPixAddr565++ =  _cnv_rgb_to_565(byPlane0, byPlane1, byPlane2);
						dwImageWidthCount ++;
					}
					
					break;
				}
				
			case	DF_24:
				{
					if(dwImageWidthCount < imgwidth)
					{
						*pDesPixAddr24++ = byPlane0;
						*pDesPixAddr24++ = byPlane1;
						*pDesPixAddr24++ = byPlane2;
					}
					break;
				}
			case	DF_32:
				{
					if(dwImageWidthCount < imgwidth)
					{
						*pDesPixAddr888++ =  _cnv_rgb_to_888(byPlane0, byPlane1, byPlane2);
						dwImageWidthCount ++;
					}
					break;
				}
			case	DF_NULL:
			default:
				ASSERT(FALSE);
				pInfo->result = ER_ILLCOMM;
				return ER_ILLCOMM;
				break;
			}//switch(dwDestFormat)
		}//for dwScanLineSize;
	}//for imageheight
	delete pScanLineBuf;
	return ER_SUCCESS;
};
EXERESULT Pcx_Load_sub_1(INFOSTR * pInfo, LPCSTR lpData, int iDataSize)
{

	const PCXFILEHEADER *const pcxFileHead=(const PCXFILEHEADER *) lpData;
	LPCSTR const pImage = lpData + sizeof(PCXFILEHEADER);//ͼ�����ݡ���ȡ���
	struct PcxPalette * lpPalette = (struct PcxPalette * )pcxFileHead->byPalette;


//?*** from yz
	DWORD imgheight = pInfo->imginfo.height;	// ͼ��ĸ߶�
	DWORD imgwidth  = pInfo->imginfo.width;	// ͼ��Ŀ���
	DWORD pcxLineWidth = pcxFileHead->wLineBytes * pcxFileHead->byPlanes;
	DWORD scansize  = pInfo->imginfo.linesize;// ÿһɨ���еĿ���(in byte)
	DWORD heigCount, widthCount;
	DWORD dwDestFormat = _get_desformat(pInfo);

	PBYTE pCurPixAddr;
	try
	{
		BYTE pix;
		BYTE ch1,ch2;
		char *pScanLineBuf = (char *)new char[pcxLineWidth + 16];//16 for ��ȫ
		if(pScanLineBuf == NULL)
			ApiMyThrowMem();
		char * pScan = NULL;
		WORD * pLineDest = NULL;

		DWORD ScanLinePoint = 0;
		int i, j;//, isou;
//		DWORD dwPCXLineSizeCount;
		//char * pSrc = ;
		char k;
		
		//	char *lpPlane0,*lpPlane1,*lpPlane2,*lpPlane3;
		//	BYTE byPlane0,byPlane1,byPlane2,byPlane3;
//		char * pReceiveLine; //= new char[dwBmpLineSize];

		LPCSTR pSrc = pImage;//ͼ�����ݡ���ȡ���

		for(heigCount=0;heigCount<imgheight;heigCount++)//Pcx ��������
		{
			pScan = (char *)(pScanLineBuf);
			ScanLinePoint = 0;
			//while(ScanLinePoint <dwPCXScanLineSize&&!feof(f1))//base 0;Index
			while(ScanLinePoint <pcxLineWidth)//base 0;Index
			{
				if((pSrc - lpData)>=iDataSize)break;
				ch1=(*pSrc ++)&0xFF;//fgetc() return int;
				if((ch1&0xc0)==0xC0)
				{
					k = ch1&0x3F;
					ch2 = (*pSrc ++)&0xFF;
					while(k--)//&&ScanLinePoint<dwPCXScanLineSize)
					{
						pScan[ScanLinePoint++] = ch2;//
					}
				}
				else
				{
					pScan[ScanLinePoint++] = ch1;
				}
			}//line

			pLineDest = (WORD*)pInfo->pLineAddr[heigCount];//Ŀ��
			//Դ��pLineBuf
			pCurPixAddr  = (PBYTE)(pScanLineBuf);	// Դͼ��ǰ�еĵ�һ�����ص�ַ

			switch(dwDestFormat)//from yz
			{
			case	DF_16_555:
				{
					// ��555λ��ʽ�ĵ�ɫ������
					WORD descol555_0 = 0;
					WORD descol555_1 = 0;
					
					descol555_0 = _cnv_rgb_to_555(lpPalette[0].byRed, lpPalette[0].byGreen, lpPalette[0].byBlue);
					descol555_1 = _cnv_rgb_to_555(lpPalette[1].byRed, lpPalette[1].byGreen, lpPalette[1].byBlue);
					WORD *pDesPixAddr555;
					
					// ����λͼ��top-down��
					{
						{
							//pCurPixAddr  = pLineBuf;	// Դͼ��ǰ�еĵ�һ�����ص�ַ
							pDesPixAddr555  = (WORD *)pLineDest;// Ŀ�껺������ǰ�е�һ�����صĵ�ַ
							for (widthCount=0;widthCount<imgwidth;widthCount+=8)
							{
								pix = *pCurPixAddr++;
								
								if ((imgwidth-widthCount)<8)	// ��β�ж�
									j = imgwidth-widthCount;
								else
									j = 8;
								
								for (i=0;i<j;i++)
								{
									if (((BYTE)(0x80>>i))&pix)	// ��λ������
									{
										*pDesPixAddr555++ = descol555_1;
									}
									else
									{
										*pDesPixAddr555++ = descol555_0;
									}
								}
							}
						}
					}
				}
				break;
			case	DF_16_565:
				{
					// ��565λ��ʽ�ĵ�ɫ������
					WORD descol565_0 = 0;
					WORD descol565_1 = 0;
					
					descol565_0 = _cnv_rgb_to_565(lpPalette[0].byRed, lpPalette[0].byGreen, lpPalette[0].byBlue);
					descol565_1 = _cnv_rgb_to_565(lpPalette[1].byRed, lpPalette[1].byGreen, lpPalette[1].byBlue);
					
					WORD *pDesPixAddr565;
					
					// ����λͼ��top-down��
					{
						{
							pDesPixAddr565  = (WORD *)pLineDest;// Ŀ�껺������ǰ�е�һ�����صĵ�ַ
							for (widthCount=0;widthCount<imgwidth;widthCount+=8)
							{
								pix = *pCurPixAddr++;
								
								if ((imgwidth-widthCount)<8)	// ��β�ж�
									j = imgwidth-widthCount;
								else
									j = 8;
								
								for (i=0;i<j;i++)
								{
									if (((BYTE)(0x80>>i))&pix)	// ��λ������
									{
										*pDesPixAddr565++ = descol565_1;
									}
									else
									{
										*pDesPixAddr565++ = descol565_0;
									}
								}
							}
						}
					}
				}
				break;
			case	DF_24:
				{
					// 24λ��ʽ�ĵ�ɫ������
					BYTE red0, red1, green0, green1, blue0, blue1;
					
					red0 = lpPalette[0].byRed;
					green0 = lpPalette[0].byGreen;
					blue0 = lpPalette[0].byBlue;
					red1 = lpPalette[1].byRed;
					green1 = lpPalette[1].byGreen;
					blue1 = lpPalette[1].byBlue;
					
					PBYTE pDesPixAddr24;
					
					// ����λͼ��top-down��
					{
						{
							pDesPixAddr24  = (PBYTE)pLineDest;// Ŀ�껺������ǰ�е�һ�����صĵ�ַ
							for (widthCount=0;widthCount<imgwidth;widthCount+=8)
							{
								pix = *pCurPixAddr++;
								
								if ((imgwidth-widthCount)<8)	// ��β�ж�
									j = imgwidth-widthCount;
								else
									j = 8;
								
								for (i=0;i<j;i++)
								{
									if (((BYTE)(0x80>>i))&pix)	// ��λ������
									{
										*pDesPixAddr24++ = blue1;
										*pDesPixAddr24++ = green1;
										*pDesPixAddr24++ = red1;
									}
									else
									{
										*pDesPixAddr24++ = blue0;
										*pDesPixAddr24++ = green0;
										*pDesPixAddr24++ = red0;
									}
								}
							}
						}
					}
				}
				break;
			case	DF_32:
				{
					// ��888λ��ʽ�ĵ�ɫ������
					DWORD descol888_0 = 0;
					DWORD descol888_1 = 0;
					
					descol888_0 = _cnv_rgb_to_888(lpPalette[0].byRed, lpPalette[0].byGreen, lpPalette[0].byBlue);
					descol888_1 = _cnv_rgb_to_888(lpPalette[1].byRed, lpPalette[1].byGreen, lpPalette[1].byBlue);
					
					DWORD *pDesPixAddr888;
					
					// ����λͼ��top-down��
					{
						///for (heigCount=0;heigCount<imgheight;heigCount++)
						{
							//pCurPixAddr  = (PBYTE)(lpSou+heigCount*scansize);	// Դͼ��ǰ�еĵ�һ�����ص�ַ
							pDesPixAddr888  = (DWORD *)pLineDest;// Ŀ�껺������ǰ�е�һ�����صĵ�ַ
							for (widthCount=0;widthCount<imgwidth;widthCount+=8)
							{
								pix = *pCurPixAddr++;
								
								if ((imgwidth-widthCount)<8)	// ��β�ж�
									j = imgwidth-widthCount;
								else
									j = 8;
								
								for (i=0;i<j;i++)
								{
									if (((BYTE)(0x80>>i))&pix)	// ��λ������
									{
										*pDesPixAddr888++ = descol888_1;
									}
									else
									{
										*pDesPixAddr888++ = descol888_0;
									}
								}
							}
						}
					}
				}
				break;
			case	DF_NULL:
			default:
				ASSERT(FALSE);
				pInfo->result = ER_ILLCOMM;
				//return ;
				break;
			}//switch
		}//for height

		delete pScanLineBuf;
		
	}//try
	catch(...)
	{
		throw;
	}
	return ER_SUCCESS;
};