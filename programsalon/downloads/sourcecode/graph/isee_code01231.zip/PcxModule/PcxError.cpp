#include "stdafx.h"
#include "PcxError.h"
void ApiThrowMyExce(ENUM_EXCE_NO no)//catch throw ֮��Ҫ��Ҫset pInfo->result???
{
	throw CMyException(no);
}
void ApiMyThrowMem()
{
	throw CMyException(ENO_MENONYERR);
}