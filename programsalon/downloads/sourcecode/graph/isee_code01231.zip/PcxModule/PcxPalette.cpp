#include "stdafx.h"
#include "PcxDeclare.h"
#include "PcxError.h"
#include "PcxModule.h"
#include "PcxPalette.h"
extern 	HGLOBAL hImgInfo = NULL;
struct PcxImgInfo * SetPcxImgInfo(INFOSTR * pInfo ,PCXFILEHEADER *pFileheader)
{
	struct PcxImgInfo * pImgInfo = NULL;
	DWORD dwBitCount = pInfo->imginfo.bitcount;//λ���
	BYTE byUsedAdd256Pal = 0;//�Ƿ�ʹ���˸��ӵ�256��ɫ��//1 ʹ�� //0 NONE
	DWORD dwPalAccount = 0;
	if(dwBitCount <= 8 )
	{
		dwPalAccount = 1 << dwBitCount;

		if(dwBitCount == 8 )
		{
			byUsedAdd256Pal = 1;
		}
		else
		{
			byUsedAdd256Pal = 0;
			
		}
		
	}
	else
	{
		dwPalAccount = 0;
		byUsedAdd256Pal = 0;
	}

	DWORD dwSize =0;
	if(byUsedAdd256Pal == 1)
	{
//		dwSize = sizeof(PcxImgInfo) + (256 -1)* sizeof(PcxPalette) +3;//768 - 3;//3 for ��ȫ
		dwSize = sizeof(PcxImgInfo) + 768 +3;//768 - 3;//3 for ��ȫ
	}
	else
	{
		dwSize = sizeof(PcxImgInfo);
	}

	pImgInfo = (PcxImgInfo *)::GlobalAlloc(GPTR, dwSize);
	if (pImgInfo == NULL)
	{
		pInfo->result = ER_MEMORYERR;
		ApiMyThrowMem();	// �ڴ治��
	}
/*
	pImgInfo = (struct PcxImgInfo *)GlobalLock(hImgInfo);
	if (pImgInfo == NULL)
	{
		pInfo->result = ER_MEMORYERR;
		ApiMyThrowMem();	// �ڴ治��
	}
*/
	pImgInfo->dwInfoSize=dwSize;
	pImgInfo->byUsedAdd256PAL = byUsedAdd256Pal;
	pImgInfo->dwPalAccount = dwPalAccount;

	memcpy(&pImgInfo->pcxFileheader, pFileheader, (size_t)sizeof(PCXFILEHEADER));

	// ����Ķ�ȡ������Ҫ��ָ�룬�����ڴ˴���ֵ
	pInfo->pImgInfo = pImgInfo;
	//don't delete ();
	return pImgInfo;
};
void GetPcxPalette(PcxImgInfo *pPcxInfo, void ** ppRgb,DWORD * pdwPalAccount)
{
	if(pPcxInfo == NULL)
	{
		(*ppRgb) = NULL;
		(*pdwPalAccount) =0;
		return;
	}

	(*pdwPalAccount) = pPcxInfo->dwPalAccount;
	if(*pdwPalAccount == 256)
		ASSERT(pPcxInfo->byUsedAdd256PAL);

	if((*pdwPalAccount) != 0)
	{
		if(1 == pPcxInfo->byUsedAdd256PAL)//or|| dwPalAccount == 256
		{
			(*ppRgb) = pPcxInfo->pcxFileheader.byPalette;
		}
		else
		{
			(*ppRgb) = pPcxInfo->pcxPal;
		}
	}
	else
	{
		(*ppRgb) =NULL;
	}
	return;
};
void SetDefGrayPal(struct PcxImgInfo * pImgInfo, LPCSTR lpData, int iDataSize)
{
	DWORD dwPalAccount = 0;
	BYTE * pRgb = NULL;

	GetPcxPalette(pImgInfo,(void **)&pRgb, & dwPalAccount);
	
	BYTE * dest = pRgb;
	unsigned int bt;
	switch(dwPalAccount)
	{
	case 2://1
		memset(dest, 0, (size_t) 3);
		memset(dest, 0xFF, (size_t) 3);
		break;
	case 16://4
	case 256://8
		for(bt=0;bt<dwPalAccount;bt++)
		{
			//�Ӽ��
			memset(dest, bt, (size_t) 3);
			dest +=3;
		}
		break;
	default://24, (//16)
		return;
	}
	return;
};
void SetDefSystemPal(struct PcxImgInfo * pImgInfo, LPCSTR lpData, int iDataSize)
{
//	BYTE bt;
	DWORD dwPalAccount = 0;
	BYTE * pRgb = NULL;

	GetPcxPalette(pImgInfo,(void **)&pRgb,& dwPalAccount);
	
	BYTE * dest = pRgb;

	HDC hdc;
	DWORD i;
//	unsigned int bt;

	switch(dwPalAccount)
	{
	case 2://1
		memset(dest, 0, (size_t) 3);
		memset(dest, 0xFF, (size_t) 3);
		break;
	case 16://4
	case 256://8
		{
			LPPALETTEENTRY pColor;
			pColor = new PALETTEENTRY[dwPalAccount];
			hdc = ::GetDC(NULL);
			::GetSystemPaletteEntries(hdc,0,dwPalAccount,pColor);//RGB+FLAG //BYTE
			::ReleaseDC(NULL,hdc);
			BYTE * src;
			src =(BYTE *)pColor;
			for(i=0;(i<dwPalAccount);i++)
			{
				//bt = pClrBGR[i].rgbBlue;
				//pClrBGR[i].rgbBlue = pClrBGR[i].rgbRed;
				//pClrBGR[i].rgbRed = bt;
				memcpy(dest, src, 3);//RGB+FLAG //BYTE//rgb ��˳��
				dest +=3;
				src += sizeof(PALETTEENTRY);
			}
			delete pColor;
		}
		break;
	default://24, (//16)
		return;
	}
	return;
};
void PcxDoWithPalette(INFOSTR * pInfo, LPCSTR lpData, int iDataSize)
{
	DWORD dwColorHeight = pInfo->imginfo.bitcount;
	DWORD dwPalAccount;
	if(dwColorHeight <= 8 )
	dwPalAccount = 1 << dwColorHeight;
	else
	{
		dwPalAccount =0;
		//return;
	}
	struct PcxImgInfo * pImgInfo;
	pImgInfo = SetPcxImgInfo(pInfo, (struct pcxheader *)lpData);//may be throw;
	BYTE * pRgb = NULL;

	GetPcxPalette(pImgInfo, (void**)&pRgb, &dwPalAccount);
	TRACE1("pRgb is %X\n",(int)pRgb);
	TRACE1("palAccount is %X\n",(int)dwPalAccount);

	if(dwPalAccount ==0)
		return;

	PCXFILEHEADER *pFlhd=(PCXFILEHEADER*)lpData;
	BYTE byVersion = pFlhd->byVersion;
	bool bGray = (pFlhd->wPaletteType == 2 )?true:false;//�Ƿ�Ҷ�ͼ��
	if(dwColorHeight<=8)// = PCXFH.byBits*PCXFH.byPlanes;//
	{
		if(byVersion==3)//ȱʡ��ɫ��
		{
			if(bGray)
			{
				SetDefGrayPal(pImgInfo, lpData, iDataSize);
			}
			else
			{
				SetDefSystemPal(pImgInfo, lpData, iDataSize);
			}
		}
		else
		{
			switch(dwColorHeight)//	wColorHeight = PCXFH.byBits*PCXFH.byPlanes;
			{
			case 1://2 color//�Ѿ�copy��PcxFileHeader,����������
				break;//ok
			case 4://16 color
				break;//ok
			case 8://256 color
				const BYTE * pColor;
				pColor = (const BYTE * )(lpData + iDataSize);//Eof?//End of file;
				pColor -= 768;//(256 * 3) start or 256 PcxPalette;
				pColor -= 1;//Flag
				//fseek(f1,-769,SEEK_END);
				//fread(pColor, 769,1,f1);
				ASSERT((*pColor)==0x0C);//0x0C ��256ɫ��ɫ�忪ʼ��־
				//if(0)
				//{
				//	//throw;
				//}
				pColor++;//start or 256 PcxPalette;
				memcpy(pRgb, pColor, 768);//256 * sizeof(PcxPalette);
				break;
			default:
				break;
			}
		}
	}
};