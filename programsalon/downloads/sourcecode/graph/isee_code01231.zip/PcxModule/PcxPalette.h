#ifndef _PCX_PALETTE_H_
#define _PCX_PALETTE_H_
#include "stdafx.h"
#include "PcxDeclare.h"
#include "PcxError.h"
#include "PcxModule.h"
extern 	HGLOBAL hImgInfo;
struct PcxPalette
{
BYTE byRed;
BYTE byGreen;
BYTE byBlue;
};
struct PcxImgInfo
{
DWORD dwInfoSize;
DWORD dwPalAccount;
BYTE byUsedAdd256PAL;//�Ƿ�ʹ���˸��ӵ�256��ɫ��//1 ʹ�� //0 NONE
PCXFILEHEADER pcxFileheader;
PcxPalette pcxPal[1];//�����С��С1����Խ����dwInfoSize�޶���Сsize of PcxPalette pcxRgb[..] + size of DWORD
					//�����˷�3 BYTE
};
struct PcxImgInfo * SetPcxImgInfo(INFOSTR * pInfo ,PCXFILEHEADER *pFileheader);
void GetPcxPalette(PcxImgInfo *pPcxInfo, void ** ppRgb,DWORD *pdwPalAccount);
void SetDefGrayPal(struct PcxImgInfo * pImgInfo, LPCSTR lpData, int iDataSize);
void SetDefSystemPal(struct PcxImgInfo * pImgInfo, LPCSTR lpData, int iDataSize);
void PcxDoWithPalette(INFOSTR * pInfo, LPCSTR lpData, int iDataSize);

#endif //_PCX_PALETTE_H_