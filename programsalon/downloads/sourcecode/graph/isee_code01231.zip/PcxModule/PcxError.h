#ifndef _PCX_ERROR_H_
#define _PCX_ERROR_H_

#include "stdafx.h"
enum ENUM_EXCE_NO
{
	ENO_OK,//0
	ENO_GENERAL_ERR,//1

	ENO_USERBREAK,//2
	ENO_MENONYERR,//3

	ENO_CREATE_FILE_EX,//�ض���//4
	ENO_CREATE_MAP_EX,//�ض���//5
	ENO_MAP_VIEW_EX,//�ض���//6
};
class CMyException
{
private:
	ENUM_EXCE_NO m_no;
public:
	ENUM_EXCE_NO GetNo(){return m_no;};

	CMyException(){m_no = ENO_GENERAL_ERR;};
	CMyException(ENUM_EXCE_NO no){m_no = no;};
	virtual ~CMyException(){};

};
void ApiThrowMyExce(ENUM_EXCE_NO no);//catch throw ֮��Ҫ��Ҫset pInfo->result???
void ApiMyThrowMem();
#endif _PCX_ERROR_H_