#include "stdafx.h"
#include "EdgeEnhance.h"
#include "Convolute.h"
#include "ConvoluteKernel.h"
#include "math.h"

#define MAX( a, b ) ( a > b ? a : b )

BOOL _fnCOM_Convolute(LPIMAGEPROCSTR lpInfo,int nKernel,int nStrength,KERNEL* kernel)
{
//	CopyMemory(lpInfo->_pdbdata ,lpInfo->_psbdata ,lpInfo->sImageInfo.width*lpInfo->sImageInfo.height*(lpInfo->sImageInfo.bitperpix/8));
	WORD skip=lpInfo->sImageInfo .byteperline ;

	UINT i,j;
	for(i=1;i<(UINT)lpInfo->sImageInfo.height-1;i++)
	{
		for(j=1;j<(UINT)lpInfo->sImageInfo.width-1;j++)
		{
			int red=0,green=0,blue=0;	
			for(int k=0;k<nKernel;++k)
			{
				int r=0,g=0,b=0;
				_fnSPE_Convolute(&r,&g,&b,i,j,skip,lpInfo->_psbdata,kernel+k);

				if(r>red)
					red=r;
				if(g>green)
					green=g;
				if(b>blue)
					blue=b;
			}
			LONG lOffset=(LONG)(i*skip)+(LONG)(j*4);
			if(nStrength!=100)
			{
				BYTE Oldb=*(lpInfo->_psbdata+lOffset++);
				BYTE Oldg=*(lpInfo->_psbdata+lOffset++);
				BYTE Oldr=*(lpInfo->_psbdata+lOffset);
				red=Oldr+(((red-Oldr)*nStrength)/100);
				green=Oldg+(((green-Oldg)*nStrength)/100);
				blue=Oldb+(((blue-Oldb)*nStrength)/100);
				lOffset=(LONG)(i*skip)+(LONG)(j*4);
			}
			*(lpInfo->_pdbdata+lOffset++)=(BYTE)((blue)<(0)?(0):((blue)>(255)?(255):(blue)));
			*(lpInfo->_pdbdata+lOffset++)=(BYTE)((green)<(0)?(0):((green)>(255)?(255):(green)));
			*(lpInfo->_pdbdata+lOffset)=(BYTE)((red)<(0)?(0):((red)>(255)?(255):(red)));
		}
	}

	return PROCERR_SUCCESS;
}

BOOL _fnCOM_Edge(LPIMAGEPROCSTR lpInfo,int nStrength,BOOL Algorith)
{
//	CopyMemory(lpInfo->_pdbdata ,lpInfo->_psbdata ,lpInfo->sImageInfo.width*lpInfo->sImageInfo.height*(lpInfo->sImageInfo.bitperpix/8));
	WORD skip=lpInfo->sImageInfo .byteperline ;

	UINT i,j;
	for(i=1;i<(UINT)lpInfo->sImageInfo.height-1;i++)
	{
		for(j=1;j<(UINT)lpInfo->sImageInfo.width-1;j++)
		{
			int red=0,green=0,blue=0;	
			_fnSPE_Edge(&red,&green,&blue,i,j,skip,lpInfo->_psbdata,nStrength,Algorith);
		
			LONG lOffset=(LONG)(i*skip)+(LONG)(j*4);
			*(lpInfo->_pdbdata+lOffset++)=(BYTE)((blue)<(0)?(0):((blue)>(255)?(255):(blue)));
			*(lpInfo->_pdbdata+lOffset++)=(BYTE)((green)<(0)?(0):((green)>(255)?(255):(green)));
			*(lpInfo->_pdbdata+lOffset)=(BYTE)((red)<(0)?(0):((red)>(255)?(255):(red)));
		}
	}

	return PROCERR_SUCCESS;
}

void _fnSPE_Edge(int *red,int *green,int *blue,int i,int j,
				WORD wBytesPerLine,LPBYTE lpData,
				int nStrength,BOOL bAlgorithm)
{
	BYTE b[9],g[9],r[9];
	LONG lOffset;

	DWORD dwLineAEIAveBelow, dwLineAEIAveAbove, dwLineAEIMaxDif;
	DWORD dwLineBEHAveBelow, dwLineBEHAveAbove, dwLineBEHMaxDif;
	DWORD dwLineCEGAveBelow, dwLineCEGAveAbove, dwLineCEGMaxDif;
	DWORD dwLineDEFAveBelow, dwLineDEFAveAbove, dwLineDEFMaxDif;
	DWORD dwMaxDif;
	DWORD  dwTemp, dwGrayList[9];

	lOffset=(LONG)(i-1)*(LONG)wBytesPerLine+(LONG)((j-1)*4);
	b[0]=*(lpData+lOffset++);
	g[0]=*(lpData+lOffset++);
	r[0]=*(lpData+lOffset);

	lOffset=(LONG)(i-1)*(LONG)wBytesPerLine+(LONG)((j)*4);
	b[1]=*(lpData+lOffset++);
	g[1]=*(lpData+lOffset++);
	r[1]=*(lpData+lOffset);

	lOffset=(LONG)(i-1)*(LONG)wBytesPerLine+(LONG)((j+1)*4);
	b[2]=*(lpData+lOffset++);
	g[2]=*(lpData+lOffset++);
	r[2]=*(lpData+lOffset);

	lOffset=(LONG)(i)*(LONG)wBytesPerLine+(LONG)((j-1)*4);
	b[3]=*(lpData+lOffset++);
	g[3]=*(lpData+lOffset++);
	r[3]=*(lpData+lOffset);

	lOffset=(LONG)(i)*(LONG)wBytesPerLine+(LONG)((j)*4);
	b[4]=*(lpData+lOffset++);
	g[4]=*(lpData+lOffset++);
	r[4]=*(lpData+lOffset);

	lOffset=(LONG)(i)*(LONG)wBytesPerLine+(LONG)((j+1)*4);
	b[5]=*(lpData+lOffset++);
	g[5]=*(lpData+lOffset++);
	r[5]=*(lpData+lOffset);

	lOffset=(LONG)(i+1)*(LONG)wBytesPerLine+(LONG)((j-1)*4);
	b[6]=*(lpData+lOffset++);
	g[6]=*(lpData+lOffset++);
	r[6]=*(lpData+lOffset);

	lOffset=(LONG)(i+1)*(LONG)wBytesPerLine+(LONG)((j)*4);
	b[7]=*(lpData+lOffset++);
	g[7]=*(lpData+lOffset++);
	r[7]=*(lpData+lOffset);

	lOffset=(LONG)(i+1)*(LONG)wBytesPerLine+(LONG)((j+1)*4);
	b[8]=*(lpData+lOffset++);
	g[8]=*(lpData+lOffset++);
	r[8]=*(lpData+lOffset);

	for(int k=0;k<9;k++)
	{
		dwGrayList[k]=(r[k]*30+g[k]*59+b[k]*11)/100;
	}

	dwLineAEIAveBelow = ( dwGrayList[3] + dwGrayList[6] + dwGrayList[7] ) / 3;
	dwLineAEIAveAbove = ( dwGrayList[1] + dwGrayList[2] + dwGrayList[5] ) / 3;
	if( dwLineAEIAveBelow > dwLineAEIAveAbove )
		dwLineAEIMaxDif = dwLineAEIAveBelow - dwLineAEIAveAbove;
	else 
		dwLineAEIMaxDif = dwLineAEIAveAbove - dwLineAEIAveBelow;

	dwLineBEHAveBelow = ( dwGrayList[0] + dwGrayList[3] + dwGrayList[6] ) / 3;
	dwLineBEHAveAbove = ( dwGrayList[2] + dwGrayList[5] + dwGrayList[8] ) / 3;
	if( dwLineBEHAveBelow > dwLineBEHAveAbove )
		dwLineBEHMaxDif = dwLineBEHAveBelow - dwLineBEHAveAbove;
	else
		dwLineBEHMaxDif = dwLineBEHAveAbove - dwLineBEHAveBelow;

	dwLineCEGAveBelow = ( dwGrayList[5] + dwGrayList[7] + dwGrayList[8] ) / 3;
	dwLineCEGAveAbove = ( dwGrayList[0] + dwGrayList[1] + dwGrayList[3] ) / 3;
	if( dwLineCEGAveBelow > dwLineCEGAveAbove ) 
		dwLineCEGMaxDif = dwLineCEGAveBelow - dwLineCEGAveAbove;
	else 
		dwLineCEGMaxDif = dwLineCEGAveAbove - dwLineCEGAveBelow;

	dwLineDEFAveBelow = ( dwGrayList[6] + dwGrayList[7] + dwGrayList[8] ) / 3;
	dwLineDEFAveAbove = ( dwGrayList[0] + dwGrayList[1] + dwGrayList[2] ) / 3;
	if( dwLineDEFAveBelow > dwLineDEFAveAbove )
		dwLineDEFMaxDif = dwLineDEFAveBelow - dwLineDEFAveAbove;
	else 
		dwLineDEFMaxDif = dwLineDEFAveAbove - dwLineDEFAveBelow;

	dwMaxDif = MAX( dwLineAEIMaxDif, dwLineBEHMaxDif );
	dwMaxDif = MAX( dwLineCEGMaxDif, dwMaxDif );
	dwMaxDif = MAX( dwLineDEFMaxDif, dwMaxDif );

	lOffset=(LONG)(i)*(LONG)wBytesPerLine+(LONG)((j)*4);
	if(bAlgorithm==TRUE)
	{
		if( dwMaxDif >(UINT)nStrength )
		{
			dwTemp = ( ( *(lpData+lOffset++) * 15) / 10 );
			if( dwTemp > 255 )
				dwTemp = 255;
			*blue = (unsigned char) dwTemp;
			dwTemp = ( ( *(lpData+lOffset++) * 15) / 10 );
			if( dwTemp > 255 ) 
				dwTemp = 255;
			*green = (unsigned char) dwTemp;
			dwTemp = ( ( *(lpData+lOffset) * 15) / 10 );
			if( dwTemp > 255 ) 
				dwTemp = 255;
			*red = (unsigned char) dwTemp;
		}
		else
		{
			*blue = *(lpData+lOffset++);
			*green = *(lpData+lOffset++);
			*red = *(lpData+lOffset);
		}
	}
	else
	{
		if( dwMaxDif >(UINT)nStrength )
		{
			dwTemp =0;
			if( dwTemp > 255 )
				dwTemp = 255;
			*blue = (unsigned char) dwTemp;
			dwTemp = 0;
			if( dwTemp > 255 ) 
				dwTemp = 255;
			*green = (unsigned char) dwTemp;
			dwTemp = 0;
			if( dwTemp > 255 ) 
				dwTemp = 255;
			*red = (unsigned char) dwTemp;
		}
		else
		{
			*blue = 255;
			*green = 255;
			*red = 255;
		}
	}
}
