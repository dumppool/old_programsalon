#if !defined(AFX_FILTERDLG_H__2DB7EAC6_3E53_4CFA_BAB0_D6289628A191__INCLUDED_)
#define AFX_FILTERDLG_H__2DB7EAC6_3E53_4CFA_BAB0_D6289628A191__INCLUDED_

#include "ModuleLogo.h"
#include "LineTrackBar.h"	// Added by ClassView
#include "SignEdit.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FilterDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFilterDlg dialog

class CFilterDlg : public CDialog
{
// Construction
public:
	CFilterDlg(CWnd* pParent = NULL);   // standard constructor
	CModuleLogo	  m_wndLogo;

// Dialog Data
	//{{AFX_DATA(CFilterDlg)
	enum { IDD = IDD_DLG_FILTER };
	CButton	m_ButEdit;
	CSignEdit	m_EditFilter;
	CTabCtrl	m_TabInfo;
	CComboBox	m_Combo_Stype;
	BOOL	m_Check_PreView;
	CString	m_strFilter;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilterDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFilterDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnSelchangeComboFilter();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnCheckPrevfilter();
	afx_msg void OnSelchangeTabFilter(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChangeEditFilter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void PreView();
	void InitCombo();
	void Filter();
	HCURSOR	m_curDown,m_curUp,m_curNormal;
	CDC      m_MemDC;
	CBitmap  m_Bitmap;
	int m_nPosx;
	int m_nPosy;
	CPoint Oldpoint;
	BOOL m_bMouseShow;
	BOOL m_bMouseDown;
	int m_nFilter;	
	CLineTrackBar m_wndFilterBar;
	int m_nStrength;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILTERDLG_H__2DB7EAC6_3E53_4CFA_BAB0_D6289628A191__INCLUDED_)
