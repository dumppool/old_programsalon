#include "..\public\gol_proc.h"

#ifndef	_REVERSE_H
#define	_REVERSE_H

void _fnSPE_Reverse(BYTE *pRed,BYTE *pGrn,BYTE *pBlu);
int	_fnCOM_Reverse(LPIMAGEPROCSTR lpInfo);

#endif	//!_REVERSE_H
