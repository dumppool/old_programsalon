#if !defined(AFX_MODULELOGO_H__E68978D1_39F9_48E3_9363_665D9A9704AD__INCLUDED_)
#define AFX_MODULELOGO_H__E68978D1_39F9_48E3_9363_665D9A9704AD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ModuleLogo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CModuleLogo window

class CModuleLogo : public CStatic
{
// Construction
public:
	CModuleLogo();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CModuleLogo)
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL RegisterWndClass(HINSTANCE hInstance);
	void SetLogoText(CString Text);
	void SetLogoFont(CString Name, int nHeight= 24,int nWeight= FW_BOLD, BYTE bItalic = true, BYTE bUnderline= false);
	CFont m_fontLogo;
	CString m_LogoText;
	virtual ~CModuleLogo();

	// Generated message map functions
protected:
	//{{AFX_MSG(CModuleLogo)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MODULELOGO_H__E68978D1_39F9_48E3_9363_665D9A9704AD__INCLUDED_)
