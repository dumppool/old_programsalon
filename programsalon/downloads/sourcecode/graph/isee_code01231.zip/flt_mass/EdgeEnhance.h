#include "..\public\gol_proc.h"
#include "ConvoluteKernel.h"

#ifndef	_EDGEENHANCE_H
#define	_EDGEENHANCE_H

BOOL _fnCOM_Convolute(LPIMAGEPROCSTR lpInfo,int nKernel,int nStrength,
				 KERNEL* kernel);
BOOL _fnCOM_Edge(LPIMAGEPROCSTR lpInfo,	int nStrength,BOOL bAlgorithm);
void _fnSPE_Edge(int *red,int *green,int *blue,int i,int j,
				WORD wBytesPerLine,LPBYTE lpData,
				int nStrength,BOOL bAlgorithm);

#endif	//!_EDGEENHANCE_H