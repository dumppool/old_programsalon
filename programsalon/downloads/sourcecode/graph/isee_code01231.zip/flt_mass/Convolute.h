#ifndef	_CONVOLUTE_H
#define	_CONVOLUTE_H

#define KERNELCOLS		3
#define KERNELROWS		3
#define KERNELELEMENTS	(KERNELCOLS*KERNELROWS)

typedef struct
{
	int Element[KERNELELEMENTS];
	int Divisor;
}KERNEL;

void _fnSPE_Convolute(int *red,int *green,int *blue,int i,int j,
				WORD wBytesPerLine,LPBYTE lpData,KERNEL *lpKernel);

#endif	//	!_CONVOLUTE_H