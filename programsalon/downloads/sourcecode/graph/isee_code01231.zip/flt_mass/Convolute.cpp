//	δ����ļ�
#include "stdafx.h"
#include "Convolute.h"
#include "math.h"

void _fnSPE_Convolute(int *red,int *green,int *blue,int i,int j,
				WORD wBytesPerLine,LPBYTE lpData,KERNEL *lpKernel)
{
	BYTE b[9],g[9],r[9];
	LONG lOffset;

	lOffset=(LONG)(i-1)*(LONG)wBytesPerLine+(LONG)((j-1)*4);
	b[0]=*(lpData+lOffset++);
	g[0]=*(lpData+lOffset++);
	r[0]=*(lpData+lOffset);

	lOffset=(LONG)(i-1)*(LONG)wBytesPerLine+(LONG)((j)*4);
	b[1]=*(lpData+lOffset++);
	g[1]=*(lpData+lOffset++);
	r[1]=*(lpData+lOffset);

	lOffset=(LONG)(i-1)*(LONG)wBytesPerLine+(LONG)((j+1)*4);
	b[2]=*(lpData+lOffset++);
	g[2]=*(lpData+lOffset++);
	r[2]=*(lpData+lOffset);

	lOffset=(LONG)(i)*(LONG)wBytesPerLine+(LONG)((j-1)*4);
	b[3]=*(lpData+lOffset++);
	g[3]=*(lpData+lOffset++);
	r[3]=*(lpData+lOffset);

	lOffset=(LONG)(i)*(LONG)wBytesPerLine+(LONG)((j)*4);
	b[4]=*(lpData+lOffset++);
	g[4]=*(lpData+lOffset++);
	r[4]=*(lpData+lOffset);

	lOffset=(LONG)(i)*(LONG)wBytesPerLine+(LONG)((j+1)*4);
	b[5]=*(lpData+lOffset++);
	g[5]=*(lpData+lOffset++);
	r[5]=*(lpData+lOffset);

	lOffset=(LONG)(i+1)*(LONG)wBytesPerLine+(LONG)((j-1)*4);
	b[6]=*(lpData+lOffset++);
	g[6]=*(lpData+lOffset++);
	r[6]=*(lpData+lOffset);

	lOffset=(LONG)(i+1)*(LONG)wBytesPerLine+(LONG)((j)*4);
	b[7]=*(lpData+lOffset++);
	g[7]=*(lpData+lOffset++);
	r[7]=*(lpData+lOffset);

	lOffset=(LONG)(i+1)*(LONG)wBytesPerLine+(LONG)((j+1)*4);
	b[8]=*(lpData+lOffset++);
	g[8]=*(lpData+lOffset++);
	r[8]=*(lpData+lOffset);

	*red=*green=*blue=0;
	for(int k=0;k<8;++k)
	{
		*red+=lpKernel->Element [k]*r[k];
		*green+=lpKernel->Element [k]*g[k];
		*blue+=lpKernel->Element [k]*b[k];
	}
	if(lpKernel->Divisor !=1)
	{
		*red/=lpKernel->Divisor ;
		*green/=lpKernel->Divisor ;
		*blue/=lpKernel->Divisor ;

	}

	*red=abs(*red);
	*green=abs(*green);
	*blue=abs(*blue);
}
