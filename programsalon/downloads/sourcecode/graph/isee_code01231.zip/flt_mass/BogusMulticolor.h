//	δ����ļ�

#include "..\public\gol_proc.h"

#ifndef	_BOGUS_H
#define	_BOGUS_H

extern LPIMAGEPROCSTR lpProcInfo;

void _fnSPE_BogusRed(BYTE *pRed);
void _fnSPE_BogusGreen(BYTE *pGrn);
void _fnSPE_BogusBlue(BYTE *pBlu);
void _fnSPE_BogusMulticolor(BYTE *pRed,BYTE *pGrn,BYTE *pBlu);
BOOL _fnCOM_BogusMulticolor(LPIMAGEPROCSTR lpInfo);

#endif	//	!_BOGUS_H