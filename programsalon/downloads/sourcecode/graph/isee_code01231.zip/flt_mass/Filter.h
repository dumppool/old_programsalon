//	δ����ļ�
#include "..\public\gol_proc.h"
#include "ConvoluteKernel.h"

#ifndef	_FILER_H
#define	_FILER_H

extern LPIMAGEPROCSTR lpProcInfo;

void _fnSPE_MedianFilter(int *red,int *green,int *blue,int i,int j,
						 int nPels,WORD wBytesPerLine,LPBYTE lpDIBits,
						 int nStype);
BOOL _fnCOM_MedianFilter(LPIMAGEPROCSTR lpInfo,int nPels,int nStype);
void _fnSPE_Filter(int *red,int *green,int *blue,int i,int j,
				   WORD wBytesPerLine,LPBYTE lpData,DWORD *dwFact);
BOOL _fnCOM_HighFilter(LPIMAGEPROCSTR lpInfo,int nStrength,int nStype);

#endif	//	!_FILER_H