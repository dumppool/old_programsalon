//	δ����ļ�
#include "stdafx.h"
#include "BogusMulticolor.h"
#include "AdjustContrast.h"
#include "System.h"

void _fnSPE_BogusRed(BYTE *pRed)
{
	if(*pRed>=0 && *pRed<=63)
	{
		*pRed=0;
	}
	else if(*pRed>=64 && *pRed<=127)
	{
		*pRed=0;
	}
	else if(*pRed>=128 && *pRed<=191)
	{
		*pRed=*pRed*4-510;
	}
	else if(*pRed>=192 && *pRed<=255)
	{
		*pRed=255;
	}
}

void _fnSPE_BogusGreen(BYTE *pGrn)
{
	if(*pGrn>=0 && *pGrn<=63)
	{
		*pGrn=254-4*(*pGrn);
	}
	else if(*pGrn>=64 && *pGrn<=127)
	{
		*pGrn=4*(*pGrn)-254;
	}
	else if(*pGrn>=128 && *pGrn<=191)
	{
		*pGrn=255;
	}
	else if(*pGrn>=192 && *pGrn<=255)
	{
		*pGrn=1022-4*(*pGrn);
	}
}

void _fnSPE_BogusBlue(BYTE *pBlu)
{
	if(*pBlu>=0 && *pBlu<=63)
	{
		*pBlu=255;
	}
	else if(*pBlu>=64 && *pBlu<=127)
	{
		*pBlu=510-4*(*pBlu);
	}
	else if(*pBlu>=128 && *pBlu<=191)
	{
		*pBlu=0;
	}
	else if(*pBlu>=192 && *pBlu<=255)
	{
		*pBlu=0;
	}
}

void _fnSPE_BogusMulticolor(BYTE *pRed,BYTE *pGrn,BYTE *pBlu)
{
	_fnSPE_BogusRed(pRed);
	_fnSPE_BogusGreen(pGrn);
	_fnSPE_BogusBlue(pBlu);
}

//	α��ɫ���ڴ�������
BOOL _fnCOM_BogusMulticolor(LPIMAGEPROCSTR lpInfo)
{
	static HANDLE hCursor;
	hCursor=GetCursor();
	SetCursor(LoadCursor(NULL, IDC_WAIT));

	CreatMemImage(lpProcInfo);
	CopyMemory(lpInfo->_pdbdata ,lpInfo->_psbdata ,lpInfo->sImageInfo.width*lpInfo->sImageInfo.height*(lpInfo->sImageInfo.bitperpix/8));

	LPBYTE pRed=(LPBYTE)lpInfo->_pdbdata;
	LPBYTE pGrn=pRed+1, pBlu=pRed+2;
	WORD skip=lpInfo->sImageInfo.bitperpix/8;

	UINT i,j;
	for(i=0;i<(UINT)lpInfo->sImageInfo.width;i++)
	{
		for(j=0;j<(UINT)lpInfo->sImageInfo.height;j++)
		{
			_fnSPE_BogusMulticolor(pRed,pGrn,pBlu);
			pRed+=skip;
 			pGrn+=skip;
       		pBlu+=skip;  		
		}
	}
	SetCursor((HICON)hCursor);

	return PROCERR_SUCCESS;
}