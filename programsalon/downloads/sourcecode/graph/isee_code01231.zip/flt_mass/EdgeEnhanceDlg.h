#if !defined(AFX_EDGEENHANCEDLG_H__EAD25DE9_A16B_404E_8246_F197F8B9A0CC__INCLUDED_)
#define AFX_EDGEENHANCEDLG_H__EAD25DE9_A16B_404E_8246_F197F8B9A0CC__INCLUDED_

#include "LineTrackBar.h"	// Added by ClassView
#include "SignEdit.h"
#include "ModuleLogo.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EdgeEnhanceDlg.h : header file
//
#define	BLACK		0
#define	HIGHT		1
#define	VERT		2
#define	HORZ		3
#define	VERTHORZ	4
#define	NORTH		5
#define	NORTHEAST	6
#define	EAST		7
#define	SOUTH		8
#define	SOUTHEAST	9
#define	SOUTHWEST	10
#define	WEST		11
#define	NORTHWEST	12
#define	LAP1		13
#define	LAP2		14
#define	LAP3		15
#define	LAP4		16
#define	SOBEL		17
#define	HOUGH		18
/////////////////////////////////////////////////////////////////////////////
// CEdgeEnhanceDlg dialog

class CEdgeEnhanceDlg : public CDialog
{
// Construction
public:
	int m_nPosx;
	int m_nPosy;
	CPoint Oldpoint;
	CEdgeEnhanceDlg(CWnd* pParent = NULL);   // standard constructor
// Dialog Data
	//{{AFX_DATA(CEdgeEnhanceDlg)
	enum { IDD = IDD_DLG_EDGE };
	CComboBox	m_Combo_Filter;
	CSignEdit	m_EditEdge;
	CString	m_strEdge;
	BOOL	m_Check_PreView;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEdgeEnhanceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEdgeEnhanceDlg)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnChangeEditEdge();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSelchangeComboFilter();
	afx_msg void OnCheckPrview();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL m_bMouseShow;
	BOOL m_bMouseDown;
	BOOL m_bDetay;
	BOOL m_bDetax;
	int m_nEdge;
	int m_nComboIndex;
	CLineTrackBar m_wndEdgeBar;
	CModuleLogo	  m_wndLogo;
	HCURSOR	m_curDown,m_curUp,m_curNormal;
	CDC      m_MemDC;
	CBitmap  m_Bitmap;

	void PreViewEdge();
	void EdgeEnhance();
	void InitComBo();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDGEENHANCEDLG_H__EAD25DE9_A16B_404E_8246_F197F8B9A0CC__INCLUDED_)
