//	δ����ļ�
#include "stdafx.h"
#include "System.h"
#include "AdjustContrast.h"
#include "Reverse.h"

void _fnSPE_Reverse(BYTE *pRed,BYTE *pGrn,BYTE *pBlu)
{
	*pRed=255-*pRed;
	*pGrn=255-*pGrn;
	*pBlu=255-*pBlu;
}

int	_fnCOM_Reverse(LPIMAGEPROCSTR lpInfo)
{
	static HANDLE hCursor;
	hCursor=GetCursor();
	SetCursor(LoadCursor(NULL, IDC_WAIT));
	//�����ڴ�ͼ��
	CreatMemImage(lpInfo);

	CopyMemory(lpInfo->_pdbdata ,lpInfo->_psbdata ,lpInfo->sImageInfo.width*lpInfo->sImageInfo.height*(lpInfo->sImageInfo.bitperpix/8));

	LPBYTE pRed=(LPBYTE)lpInfo->_pdbdata;
	LPBYTE pGrn=pRed+1, pBlu=pRed+2;
	WORD skip=lpInfo->sImageInfo.bitperpix/8;

	UINT i,j;
	for(i=0;i<(UINT)lpInfo->sImageInfo.width;i++)
	{
		for(j=0;j<(UINT)lpInfo->sImageInfo.height;j++)
		{
			_fnSPE_Reverse(pRed,pGrn,pBlu);
      		pRed+=skip;
      		pGrn+=skip;
      		pBlu+=skip;
		}
	}

	return PROCERR_SUCCESS;
}