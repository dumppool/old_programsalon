#include "StdAfx.h"
#include "DrawPreView.h"
#include "System.h"
#include "draw.h"
#include "Contrast.h"
#include "EdgeEnhance.h"
#include "Filter.h"
#include "Resource.h"

static int prev_width,prev_height,mem_size,Img_size;
static RECT rt;

//	�����ڴ溯��������������ٷ�ĸ�ʽ
void ClearPreView()
{
	EndDraw();
	Del(lptemp);
	Del(lpPreView);
	Del(lpPreBack);
	lptemp=NULL;
	lpPreView=NULL;
	lpPreBack=NULL;
}

//	Ԥ������Ԥ�����ƺ���
void _fnSPE_DrawPreView(LPDRAWITEMSTRUCT lpInfo,int x,int y,int nStype)
{
	WORD skip=lpProcInfo->sImageInfo.bitperpix/8;
		
	//��Ԥ��ͼƬ�ߴ�
	int rcw=lpInfo->rcItem.right-lpInfo->rcItem.left;
	int rch=lpInfo->rcItem.bottom-lpInfo->rcItem.top;

	if(lpPreView==NULL)
	{
		lpPreView=(LPBYTE)lpProcInfo->_psbdata;

		if(lpPreView==NULL)
		{
   			lpProcInfo->result=PR_MEMORYERR;
	   		return;
		}

		if(lpProcInfo->sImageInfo.width < rcw || lpProcInfo->sImageInfo.height < rch)
		{
			if(lpProcInfo->sImageInfo.width >= rcw )
			{
	      		prev_width=PREV_WIDTH;
				prev_height=lpProcInfo->sImageInfo.height;
				rt.left=0;
				rt.top=(rch-prev_height)/2;
				rt.right=rt.left+prev_width;
				rt.bottom=rt.top+prev_height;
			}
			else if(lpProcInfo->sImageInfo.height >= rch)
			{
	      		prev_width=lpProcInfo->sImageInfo.width;
				prev_height=PREV_HEIGHT;
				rt.left=(rcw-prev_width)/2;
				rt.top=0;
				rt.right=rt.left+prev_width;
				rt.bottom=rt.top+prev_height;
			}
			else
			{
				prev_width=lpProcInfo->sImageInfo.width;
				prev_height=lpProcInfo->sImageInfo.height;
				rt.left=(rcw-prev_width)/2;
				rt.top=(rch-prev_height)/2;
				rt.right=rt.left+prev_width;
				rt.bottom=rt.top+prev_height;

			}
			//����Ԥ���ڴ�ͼ��
			mem_size=prev_height*prev_width*skip;
			lptemp=(LPBYTE)New(mem_size);
			if(lptemp==NULL)
			{
   				lpProcInfo->result=PR_MEMORYERR;
	   			return;
			}
			lpPreBack=(LPBYTE)New(mem_size);
			if(lpPreBack==NULL)
			{
   				lpProcInfo->result=PR_MEMORYERR;
	   			return;
			}
			if(lpProcInfo->sImageInfo.width >= rcw )
			{
				for(int i=0;i<prev_height;i++)
				{
					CopyMemory(lptemp+i*(PREV_WIDTH)*skip,lpProcInfo->_psbdata+i*lpProcInfo->sImageInfo.byteperline+x*skip,PREV_WIDTH*skip);
				}
			}
			else if(lpProcInfo->sImageInfo.height >= rch)
			{
				for(int j=0,i=y;i<PREV_HEIGHT+y;i++,j++)
				{
					CopyMemory(lptemp+j*(prev_width)*skip,lpProcInfo->_psbdata+i*lpProcInfo->sImageInfo.byteperline,prev_width*skip);
				}
			}
			else
			{
			//����Ԥ��ͼ��
			CopyMemory(lptemp,lpProcInfo->_psbdata ,mem_size);
			}
		}
		else
		{
     		prev_height=PREV_HEIGHT;
			prev_width=PREV_WIDTH;
   			rt.left=0;
      		rt.top=(prev_width-prev_height)/2;
			rt.right=prev_width;
			rt.bottom=rt.top+prev_height;
					
			//����Ԥ���ڴ�ͼ��
			mem_size=prev_height*prev_width*skip;
			lptemp=(LPBYTE)New(mem_size);
			if(lptemp==NULL)
			{
   				lpProcInfo->result=PR_MEMORYERR;
	   			return;
			}
			lpPreBack=(LPBYTE)New(mem_size);
			if(lpPreBack==NULL)
			{
   				lpProcInfo->result=PR_MEMORYERR;
	   			return;
			}

			//����Ԥ��ͼ��
			for(int j=0,i=y;i<PREV_HEIGHT+y;i++,j++)
			{
				CopyMemory(lptemp+j*(PREV_WIDTH)*skip,lpProcInfo->_psbdata+i*lpProcInfo->sImageInfo.byteperline+x*skip ,(PREV_WIDTH)*skip);
			}
		}

		lpPreView=lptemp;
		CopyMemory(lpPreBack,lpPreView,mem_size);
	}

	DoDlgDraw(lpInfo->hDC,&rt,prev_width,prev_height,lpPreView);
}

//	Ԥ�����ڣ����ȣ����ƺ���,����������ٷ�ĸ�ʽ
void _fnSPE_DrawResizePreView(LPDRAWITEMSTRUCT lpInfo)
{
	float x,y;
	if(lpPreView==NULL)
	{
   		lpPreView=(LPBYTE)lpProcInfo->_psbdata;
		if(lpPreView==NULL)
      		return;

		//��Ԥ��ͼƬ�ߴ�
		int rcw=lpInfo->rcItem.right-lpInfo->rcItem.left;
		int rch=lpInfo->rcItem.bottom-lpInfo->rcItem.top;

		x=(float)lpProcInfo->sImageInfo.width;
		y=(float)lpProcInfo->sImageInfo.height;

		if(lpProcInfo->sImageInfo.width > rcw || lpProcInfo->sImageInfo.height > rch)
		{
      		if(lpProcInfo->sImageInfo.width >= lpProcInfo->sImageInfo.height)
			{
   	   			prev_width=rcw;
      			x=y/x;
         		x=x*prev_width;
				if(x<8)
            		x=8;
				prev_height=(int)x;

   				rt.left=0;
      			rt.top=(prev_width-prev_height)/2;
         		rt.right=prev_width;
				rt.bottom=rt.top+prev_height;
   			}
      		else
			{
   				prev_height=rch;
	      		x=x/y;
		     	x=x*prev_height;
			    if(x<8)
					x=8;
				prev_width=(int)x;

   				rt.left=(prev_height-prev_width)/2;
      			rt.top=0;
	         	rt.right=rt.left+prev_width;
		        rt.bottom=prev_height;
   			}
		}
		else
		{
      		prev_width=lpProcInfo->sImageInfo.width;
			prev_height=lpProcInfo->sImageInfo.height;
			rt.left=(rcw-prev_width)/2;
			rt.top=(rch-prev_height)/2;
			rt.right=rt.left+prev_width;
			rt.bottom=rt.top+prev_height;
		}

	   //����prev_width*prev_height�ڴ�ͼ��
		mem_size=prev_width*prev_height*(lpProcInfo->sImageInfo.bitperpix/8);
		lpPreBack=(LPBYTE)New(mem_size);
		if(lpPreBack==NULL)
		{
   			lpProcInfo->result=PR_MEMORYERR;
//			SendMessage(NULL ,WM_CLOSE,0,0);
	   		return;
		}
		lptemp=(LPBYTE)New(mem_size);
		if(lptemp==NULL)
		{
   			lpProcInfo->result=PR_MEMORYERR;
//			SendMessage(NULL,WM_CLOSE,0,0);
	   		return;
		}

		//����Ԥ��ͼ��
		_fnSPE_Output_Resize(prev_width,prev_height,(LPBYTE)lptemp);

		lpPreView=lptemp;
		CopyMemory(lpPreBack,lpPreView,mem_size);
   }
	DoDlgDraw(lpInfo->hDC,&rt,prev_width,prev_height,lpPreView);
}

//	�ض���ߴ�,����������ٷ�ĸ�ʽ
int _fnSPE_Output_Resize(int width,int height,LPBYTE lpDestData)
{
	LPBYTE lpData=(LPBYTE)lpProcInfo->_psbdata,lpBak,lpBako;
	LPBYTE lpdData=lpDestData;

	if(lpDestData==NULL )
   		return PROCERR_FALSE;

	int skip = lpProcInfo->sImageInfo.bitperpix/8;

   	float x=(float)lpProcInfo->sImageInfo.width/(float)width;
    float y=(float)lpProcInfo->sImageInfo.height/(float)height;
	float x_cnt,y_cnt=0.00;

    lpBak=lpBako=lpData;
    for(int j=0;j<height;j++)
    {
		x_cnt=0.00;
      	for(int i=0;i<width;i++)
        {
			for(int k=0;k<skip;k++)
            {
				*lpdData=*lpData;
				lpdData++;
				lpData++;
			}
            x_cnt+=x;
	        lpData=lpBak+skip*(int)x_cnt;
		}
		y_cnt+=y;
     	lpBak=lpBako+lpProcInfo->sImageInfo.width*skip*(int)y_cnt;
		lpData=lpBak;
	}
	return TRUE;
}

//	����Ԥ��ͼ�����ȣ�,����������ٷ�ĸ�ʽ
void _fnCOM_DrawResizePrView(int nCtlID,LPDRAWITEMSTRUCT lpInfo)
{
	switch(nCtlID)
    {
		case IDC_PRVIEW_CONTRAST:
			_fnSPE_DrawResizePreView(lpInfo);
            return;
		case IDC_PRVIEW_EDGE:
			_fnSPE_DrawResizePreView(lpInfo);
            return;
		case IDC_PRVIEW_FILTER:
			_fnSPE_DrawResizePreView(lpInfo);
			return;
	}
}

void _fnCOM_SetPos_xy(int x,int y)
{
	nPos_x=x;
	nPos_y=y;
}

int _fnCOM_GetPosx()
{
	return nPos_x;
}

int _fnCOM_GetPosy()
{
	return nPos_y;
}

//	����Ԥ��ͼ��,����������ٷ�ĸ�ʽ
void _fnCOM_DrawPrView(int nCtlID,LPDRAWITEMSTRUCT lpInfo)
{
	switch(nCtlID)
    {
		case IDC_PRVIEW_CONTRAST:
			_fnSPE_DrawPreView(lpInfo,nPos_x,nPos_y,nStype);
            return;
		case IDC_PRVIEW_EDGE:
			_fnSPE_DrawPreView(lpInfo,nPos_x,nPos_y,nStype);
            return;
		case IDC_PRVIEW_FILTER:
			_fnSPE_DrawPreView(lpInfo,nPos_x,nPos_y,nStype);
            return;

	}
}

//	Ԥ��ͼ�������,�Աȶȵ��ڴ�������
void _fnCOM_AdjustContrastPreView(int Brightness,int Contrast)
{
	CopyMemory(lpPreView,lpPreBack,mem_size);
	LPBYTE pRed=(LPBYTE)lpPreView;
	LPBYTE pGrn=pRed+1, pBlu=pRed+2;
	int skip=mem_size/prev_width/prev_height;

	for(UINT i=0;i<(UINT)prev_width;i++)
	{
		for(UINT j=0;j<(UINT)prev_height;j++)
		{
			_fnSPE_ChangeBrightness(Brightness,pRed,pGrn,pBlu);
			_fnSPE_ChangeContrast(Contrast,pRed,pGrn,pBlu);
      		pRed+=skip;
      		pGrn+=skip;
      		pBlu+=skip;
		}
	}
}

//	Ԥ��ͼ�������,�Աȶȵ��ڴ�������
void _fnCOM_AdjustConvolutePreView(int nKernel,int nStrength,KERNEL* kernel)
{
	CopyMemory(lpPreView,lpPreBack,mem_size);

	WORD skip=mem_size/prev_height;

	UINT i,j;
	for(i=1;i<(UINT)prev_height-1;i++)
	{
		for(j=1;j<(UINT)prev_width-1;j++)
		{
			int red=0,green=0,blue=0;			
			for(int k=0;k<nKernel;++k)
			{
				int r=0,g=0,b=0;
				_fnSPE_Convolute(&r,&g,&b,i,j,skip,lpPreBack,kernel+k);
				if(r>red)
					red=r;
				if(g>green)
					green=g;
				if(b>blue)
					blue=b;
			}

			LONG lOffset=(LONG)(i*skip)+(LONG)(j*4);
			if(nStrength!=100)
			{
				BYTE Oldb=*(lpPreBack+lOffset++);
				BYTE Oldg=*(lpPreBack+lOffset++);
				BYTE Oldr=*(lpPreBack+lOffset);
				red=Oldr+(((red-Oldr)*nStrength)/100);
				green=Oldg+(((green-Oldg)*nStrength)/100);
				blue=Oldb+(((blue-Oldb)*nStrength)/100);
				lOffset=(LONG)(i*skip)+(LONG)(j*4);
			}
			*(lpPreView+lOffset++)=(BYTE)((blue)<(0)?(0):((blue)>(255)?(255):(blue)));
			*(lpPreView+lOffset++)=(BYTE)((green)<(0)?(0):((green)>(255)?(255):(green)));
			*(lpPreView+lOffset)=(BYTE)((red)<(0)?(0):((red)>(255)?(255):(red)));
		}
	}
}

//	Ԥ��ͼ�������,�Աȶȵ��ڴ�������
void _fnCOM_AdjustEdgePreView(int nStrength,BOOL bAlgorith)
{
	CopyMemory(lpPreView,lpPreBack,mem_size);

	WORD skip=mem_size/prev_height;

	UINT i,j;
	for(i=1;i<(UINT)prev_height-1;i++)
	{
		for(j=1;j<(UINT)prev_width-1;j++)
		{
			int red=0,green=0,blue=0;
			_fnSPE_Edge(&red,&green,&blue,i,j,skip,lpPreBack,nStrength,bAlgorith);
			LONG lOffset=(LONG)(i*skip)+(LONG)(j*4);
			*(lpPreView+lOffset++)=(BYTE)((blue)<(0)?(0):((blue)>(255)?(255):(blue)));
			*(lpPreView+lOffset++)=(BYTE)((green)<(0)?(0):((green)>(255)?(255):(green)));
			*(lpPreView+lOffset)=(BYTE)((red)<(0)?(0):((red)>(255)?(255):(red)));
		}
	}
}

void _fnCOM_MedianFilterPreView(int nPels,int nStype)
{
	CopyMemory(lpPreView,lpPreBack,mem_size);

	WORD skip=mem_size/prev_height;

	UINT i,j;
	for(i=1;i<(UINT)prev_height-1-1;i++)
	{
		for(j=1;j<(UINT)prev_width-1;j++)
		{
			int red=0,green=0,blue=0;
			
			_fnSPE_MedianFilter(&red,&green,&blue,i,j,1,skip,lpPreBack,nStype);
			LONG lOffset=(LONG)(i*skip)+(LONG)(j*4);

			*(lpPreView+lOffset++)=(BYTE)((blue)<(0)?(0):((blue)>(255)?(255):(blue)));
			*(lpPreView+lOffset++)=(BYTE)((green)<(0)?(0):((green)>(255)?(255):(green)));
			*(lpPreView+lOffset)=(BYTE)((red)<(0)?(0):((red)>(255)?(255):(red)));
		}
	}
}

void _fnCOM_HighFilterPreView(int nStrength,int nStype)
{
	CopyMemory(lpPreView,lpPreBack,mem_size);

	WORD skip=mem_size/prev_height;
	static DWORD dwFact[9];

	switch(nStype)
	{
	case 0:
		dwFact[0]=10;
		dwFact[1]=10;
		dwFact[2]=10;
		dwFact[3]=10;
		dwFact[4]=160+nStrength;
		dwFact[5]=10;
		dwFact[6]=10;
		dwFact[7]=10;
		dwFact[8]=10;
		break;
	case 1:
		dwFact[0]=10;
		dwFact[1]=10;
		dwFact[2]=10;
		dwFact[3]=10;
		dwFact[4]=10;
		dwFact[5]=10;
		dwFact[6]=10;
		dwFact[7]=10;
		dwFact[8]=10;
		break;
	}

	UINT i,j;
	for(i=1;i<(UINT)prev_height-1-1;i++)
	{
		for(j=1;j<(UINT)prev_width-1;j++)
		{
			int red=0,green=0,blue=0;
			
			_fnSPE_Filter(&red,&green,&blue,i,j,skip,lpPreBack,dwFact);
			LONG lOffset=(LONG)(i*skip)+(LONG)(j*4);

			*(lpPreView+lOffset++)=(BYTE)((blue)<(0)?(0):((blue)>(255)?(255):(blue)));
			*(lpPreView+lOffset++)=(BYTE)((green)<(0)?(0):((green)>(255)?(255):(green)));
			*(lpPreView+lOffset)=(BYTE)((red)<(0)?(0):((red)>(255)?(255):(red)));
		}
	}
}