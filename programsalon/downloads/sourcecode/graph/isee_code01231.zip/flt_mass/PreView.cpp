// PreView.cpp : implementation file
//

#include "stdafx.h"
#include "flt_mass.h"
#include "PreView.h"
#include "Resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreView

CPreView::CPreView()
{
	CPreView::RegisterWndClass(AfxGetInstanceHandle());
	pItem=NULL;
}

CPreView::~CPreView()
{
	int nCount = m_items.GetSize();
	
	for (int i = 0; i < nCount; i++)
		delete m_items.GetAt(i);
	m_items.RemoveAll();
}


BEGIN_MESSAGE_MAP(CPreView, CStatic)
	//{{AFX_MSG_MAP(CPreView)
	ON_WM_PAINT()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreView message handlers

BOOL CPreView::RegisterWndClass(HINSTANCE hInstance)
{
	WNDCLASS wc;
	wc.lpszClassName = "PREVIEW_CTRL"; // matches class name in client
	wc.hInstance = hInstance;
	wc.lpfnWndProc = ::DefWindowProc;
	wc.hCursor = ::LoadCursor(NULL, MAKEINTRESOURCE(IDC_MOVE_UP));
	wc.hIcon = 0;
	wc.lpszMenuName = NULL;
	wc.hbrBackground = (HBRUSH) ::GetStockObject(LTGRAY_BRUSH);
	wc.style = CS_GLOBALCLASS; // To be modified
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;//WS_BORDER | SS_OWNERDRAW;

	return (::RegisterClass(&wc) != 0);
}

BOOL CPreView::InitControl(int width, int height)
{
	pItem = new CPreViewObj;
	pItem->m_nPosX =0;
	pItem->m_nPosY =0;

	try 
	{
		m_items.Add(pItem);
		this->SetWindowPos(this,0,0,width,height,SWP_NOMOVE|SWP_NOZORDER|
			SWP_SHOWWINDOW|SWP_NOACTIVATE);
		InvalidateCtrl();

		return TRUE;
	}
	catch (CMemoryException* e)
	{
		if (pItem !=NULL) 
			delete pItem;
		e->Delete();
		return FALSE;
	}
}

int CPreView::GetPos_X()
{
	return pItem->m_nPosX;
}

int CPreView::GetPos_Y()
{
	return pItem->m_nPosY;
}

void CPreView::InvalidateCtrl()
{
	CClientDC dc(this);
	CRect rcClient;

	pItem = m_items.GetAt(0);
	GetClientRect(rcClient);

	if (m_MemDC.GetSafeHdc() == NULL)
	{
		m_MemDC.CreateCompatibleDC(&dc);
		m_Bitmap.CreateCompatibleBitmap(&dc,rcClient.Width(),rcClient.Height());
		m_MemDC.SelectObject(m_Bitmap);
		
		// draw scale
		m_MemDC.SetBkColor(RGB(255,255,255));
		CBrush bkBrush;
		bkBrush.CreateSysColorBrush(COLOR_ACTIVEBORDER);
		m_MemDC.FillRect(rcClient,&bkBrush);
	}
	InvalidateRect(rcClient, FALSE);
}

void CPreView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	CRect rcClient;
	GetClientRect(rcClient);

	// draw scale
	if (m_MemDC.GetSafeHdc() != NULL)
		dc.BitBlt(0, 0, rcClient.Width(), rcClient.Height(), &m_MemDC, 0, 0, SRCCOPY);

	// Do not call CStatic::OnPaint() for painting messages
}

void CPreView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
/*	CRect rcClient;
	GetClientRect(rcClient);
	pItem->m_nPosX =point.x-rcClient.left;
	pItem->m_nPosY =point.y-rcClient.top;
	static HANDLE hCursor;
	hCursor=GetCursor();

	if(nFlags==MK_LBUTTON)
	{
		SetCursor(LoadCursor(NULL, MAKEINTRESOURCE(IDC_MOVE_DOWN)));
	}
	else
	{
		SetCursor((HICON)hCursor);
	}
*/
	CStatic::OnMouseMove(nFlags, point);
}
/////////////////////////////////////////////////////////////////////////////
// CPreView

CPreView::CPreView()
{
}

CPreView::~CPreView()
{
}


BEGIN_MESSAGE_MAP(CPreView, CStatic)
	//{{AFX_MSG_MAP(CPreView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreView message handlers
