#include "Convolute.h"

#ifndef	_CONVOLUTEKERNEL_H
#define	_CONVOLUTEKERNEL_H

static KERNEL	LP1=
{
	{	
		1,1,1,
		1,1,1,
		1,1,1
	},
	9
};

static KERNEL	LP2=
{
	{
		1,1,1,
		1,2,1,
		1,1,1
	},
	10
};

static KERNEL	LP3=
{
	{
		1,2,1,
		2,4,2,
		1,2,1
	},
	16
};

static KERNEL	HP1=
{
	{
		-1,-1,-1,
		-1,	9,-1,
		-1,-1,-1
	},
	1
};

static KERNEL	HP2=
{
	{
		 0,-1, 0,
		-1, 5,-1,
		 0,-1, 0
	},
	1
};
static KERNEL	HP3=
{
	{
		 1,-2, 1,
		-2, 5,-2,
		 1,-2, 1
	},
	1
};

//	�������ڱ�Ե̽��
static KERNEL	VertEdge=
{
	{
		 0, 0, 0,
		-1, 1, 0,
		 0, 0, 0
	},
	1
};

static KERNEL	HorzEdge=
{
	{
		 0,-1, 0,
		 0, 1, 0,
		 0, 0, 0
	},
	1
};

static KERNEL	VertHorzEdge=
{
	{
		-1, 0, 0,
		 0, 1, 0,
		 0, 0, 0
	},
	1
};

static KERNEL	EdgeNorth=
{
	{
		 1, 1, 1,
		 1,-2, 1,
		-1,-1,-1
	},
	1
};

static KERNEL	EdgeNorthEast=
{
	{
		 1, 1, 1,
		-1,-2, 1,
		-1,-1, 1
	},
	1
};

static KERNEL	EdgeEast=
{
	{
		-1, 1, 1,
		-1,-2, 1,
		-1, 1, 1
	},
	1
};

static  KERNEL	EdgeSouthEast=
{
	{
		-1,-1, 1,
		-1,-2, 1,
		 1, 1, 1
	},
	1
};

static KERNEL	EdgeSouth=
{
	{
		-1,-1,-1,
		 1,-2, 1,
		 1, 1, 1
	},
	1
};

static KERNEL	EdgeSouthWest=
{
	{
		 1,-1,-1,
		 1,-2,-1,
		 1, 1, 1
	},
	1
};

static KERNEL	EdgeWest=
{
	{
		 1, 1,-1,
		 1,-2,-1,
		 1, 1,-1
	},
	1
};

static KERNEL	EdgeNorthWest=
{
	{
		 1, 1, 1,
		 1,-2,-1,
		 1,-1,-1
	},
	1
};

static KERNEL	Lap1=
{
	{
		 0, 1, 0,
		 1,-4, 1,
		 0, 1, 0
	},
	1
};

static KERNEL	Lap2=
{
	{
		-1,-1,-1,
		-1, 8,-1,
		-1,-1,-1
	},
	1
};

static KERNEL	Lap3=
{
	{
		-1,-1,-1,
		-1, 9,-1,
		-1,-1,-1
	},
	1
};

static KERNEL	Lap4=
{
	{
		 1,-2, 1,
		-2, 4,-2,
		 1,-2, 1
	},
	1
};

static KERNEL	Sobel2[2]=
{
	{
		{
			-1, 0, 1,
			-2, 0, 2,
			-1, 0, 1
		},
		1
	},
	{
		{
			 1, 2, 1,
			 0, 0, 0,
			-1,-2,-1
		},
		1
	}
};

static KERNEL	Sobel[4]=
{
	{
		{
			-1, 0, 1,
			-2, 0, 2,
			-1, 0, 1
		},
		1
	},
	{
		{
			-1,-2,-1,
			 0, 0, 0,
			 1, 2, 1
		},
		1
	},
	{
		{
			-2,-1, 0,
			-1, 0, 1,
			 0, 1, 2
		},
		1
	},
	{
		{
			 0,-1,-2,
			 1, 0,-1,
			 2, 1, 0
		},
		1
	}
};

static KERNEL	Hough[4]=
{
	{
		{
			-1, 0, 1,
			-1, 0, 1,
			-1, 0, 1
		},
		1
	},
	{
		{
			-1,-1, 0,
			-1, 0, 1,
			 0, 1, 1
		},
		1
	},
	{
		{
			-1,-1,-1,
			 0, 0, 0,
			 1, 1, 1
		},
		1
	},
	{
		{
			 0,-1,-1,
			 1, 0,-1,
			 1, 1, 0
		},
		1
	}
};

#endif	//	!_CONVOLUTEKERNEL_H