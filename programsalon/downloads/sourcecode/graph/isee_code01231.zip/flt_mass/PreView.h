#if !defined(AFX_PREVIEW_H__68D7ED2A_85C5_40F7_81DE_DD076A4ABB93__INCLUDED_)
#define AFX_PREVIEW_H__68D7ED2A_85C5_40F7_81DE_DD076A4ABB93__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPreView window

class CPreView : public CStatic
{
// Construction
public:
	CPreView();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPreView)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPreView();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPreView)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREVIEW_H__68D7ED2A_85C5_40F7_81DE_DD076A4ABB93__INCLUDED_)
