//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by flt_mass.rc
//
#define IDC_MOVE_UP                     102
#define IDC_MOVE_DOWN                   103
#define IDD_DLG_CONTRAST                1000
#define IDC_CHECK_PRVIEW                1000
#define IDD_DLG_EDGE                    1001
#define IDC_LINETRACKBRIGHT             1004
#define IDD_DLG_FILTER                  1004
#define IDC_EDIT_BRIGHT                 1005
#define IDD_DLG_EDIT                    1005
#define IDC_EDIT_CONTRAST               1006
#define IDC_LINETRACKCONTRAST           1007
#define IDC_BUTTON1                     1008
#define IDC_BUTTON_EDIT                 1008
#define IDC_PRVIEW                      1009
#define IDC_PRVIEW_CONTRAST             1009
#define IDC_CHECK_PERVIEW               1010
#define IDC_PRVIEW_EDGE                 1011
#define IDC_COMBO1                      1012
#define IDC_COMBO_FILTER                1012
#define IDC_CHECK_                      1013
#define IDC_EDIT_EDGE                   1014
#define IDC_LINETRACK_EDGE              1015
#define IDC_LOGO_EDGE                   1018
#define IDC_LOGO_CONTRAST               1020
#define IDC_PRVIEW_FILTER               1021
#define IDC_CHECK_PREVFILTER            1024
#define IDC_LOGO_FILTER                 1025
#define IDC_TAB_FILTER                  1033
#define IDC_LINETRACK_FILTER            1036
#define IDC_EDIT_FILTER                 1037
#define IDC_STATIC_FILTER               1038
#define IDC_EDIT1                       1039
#define IDC_EDIT2                       1040
#define IDC_EDIT3                       1041
#define IDC_EDIT4                       1042
#define IDC_EDIT5                       1043
#define IDC_EDIT6                       1044
#define IDC_EDIT7                       1045
#define IDC_EDIT8                       1046
#define IDC_EDIT9                       1047
#define IDC_EDIT10                      1048
#define IDC_EDIT11                      1049
#define IDC_EDIT12                      1050
#define IDC_EDIT13                      1051
#define IDC_EDIT14                      1052
#define IDC_EDIT15                      1053
#define IDC_EDIT16                      1054
#define IDC_EDIT17                      1055
#define IDC_EDIT18                      1056
#define IDC_EDIT19                      1057
#define IDC_EDIT20                      1058
#define IDC_EDIT21                      1059
#define IDC_EDIT22                      1060
#define IDC_EDIT23                      1061
#define IDC_EDIT24                      1062
#define IDC_EDIT25                      1063
#define IDC_EDIT_NAME                   1064

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1006
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1065
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
