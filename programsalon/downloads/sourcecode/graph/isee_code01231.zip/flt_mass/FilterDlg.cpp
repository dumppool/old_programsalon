// FilterDlg.cpp : implementation file
//

#include "stdafx.h"
#include "flt_mass.h"
#include "FilterDlg.h"
#include "DrawPreView.h"
#include "System.h"
#include "ConvoluteKernel.h"
#include "EdgeEnhance.h"
#include "Filter.h"
#include "draw.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	HIGH_FILTER			0
#define	MEDIAN_FILTER		1
#define	LOW_FILTER			2
#define	DELAYTIME			500
#define	LEFT				8
#define TOP					8

/////////////////////////////////////////////////////////////////////////////
// CFilterDlg dialog


CFilterDlg::CFilterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFilterDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFilterDlg)
	m_Check_PreView = TRUE;
	m_strFilter = _T("");
	//}}AFX_DATA_INIT
	m_bMouseDown=FALSE;
	m_bMouseShow=TRUE;
	m_nFilter=0;
	m_nStrength=100;

}


void CFilterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFilterDlg)
	DDX_Control(pDX, IDC_BUTTON_EDIT, m_ButEdit);
	DDX_Control(pDX, IDC_EDIT_FILTER, m_EditFilter);
	DDX_Control(pDX, IDC_TAB_FILTER, m_TabInfo);
	DDX_Control(pDX, IDC_COMBO_FILTER, m_Combo_Stype);
	DDX_Check(pDX, IDC_CHECK_PREVFILTER, m_Check_PreView);
	DDX_Text(pDX, IDC_EDIT_FILTER, m_strFilter);
	DDV_MaxChars(pDX, m_strFilter, 3);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFilterDlg, CDialog)
	//{{AFX_MSG_MAP(CFilterDlg)
	ON_WM_DRAWITEM()
	ON_CBN_SELCHANGE(IDC_COMBO_FILTER, OnSelchangeComboFilter)
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_BN_CLICKED(IDC_CHECK_PREVFILTER, OnCheckPrevfilter)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_FILTER, OnSelchangeTabFilter)
	ON_EN_CHANGE(IDC_EDIT_FILTER, OnChangeEditFilter)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFilterDlg message handlers

BOOL CFilterDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	//�����ڴ�ͼ��
	CreatMemImage(lpProcInfo);

	if(lpProcInfo->sImageInfo .height <PREV_HEIGHT && lpProcInfo->sImageInfo .width <PREV_WIDTH)
	{
		m_bMouseShow=FALSE;
	}
	m_nPosx=(lpProcInfo->sImageInfo .width -PREV_WIDTH)/2;
	m_nPosy=(lpProcInfo->sImageInfo .height-PREV_HEIGHT)/2;
	
	_fnCOM_SetPos_xy(m_nPosx,m_nPosy);
	Oldpoint.x=Oldpoint.y=-1;

	m_curDown = LoadCursor(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDC_MOVE_DOWN));
	m_curUp = LoadCursor(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDC_MOVE_UP));
	m_curNormal=GetCursor();

	m_wndFilterBar.SubclassDlgItem(IDC_LINETRACK_FILTER, this);
	m_wndFilterBar.InitControl(IDC_EDIT_FILTER,RGB(0,0,0),0, m_nStrength,200,1);
//	m_wndFilterBar.SetDisabled ();
//	DWORD dwStyle=GetWindowLong((HWND)m_wndFilterBar.GetDlgItem (IDC_LINETRACK_FILTER),GWL_STYLE);
//	dwStyle+=WS_DISABLED;
//	SetWindowLong((HWND)m_wndFilterBar.GetDlgItem (IDC_LINETRACK_FILTER),GWL_STYLE,dwStyle);

	m_wndLogo.SubclassDlgItem (IDC_LOGO_FILTER,this);
	m_wndLogo.SetLogoFont ("SIMSUN");
	m_wndLogo.SetLogoText ("iSee��Ч�˾�");

	InitDraw();
	InitCombo();

	if(m_TabInfo.GetItemCount()!=3)
	{
		m_TabInfo.InsertItem (0,"��ͨ�˲�");
		m_TabInfo.InsertItem (1,"��ֵ�˲�");
		m_TabInfo.InsertItem (2,"��ͨ�˲�");
		m_TabInfo.InsertItem (3,"�Զ���");
	}
	m_wndFilterBar.ShowWindow (SW_SHOWNORMAL);
		
//	GetDlgItem(IDC_BUTTON_EDIT)->ShowWindow(SW_SHOWNORMAL);
	m_ButEdit.EnableWindow (FALSE);
	KillTimer(1);
	SetTimer(1,DELAYTIME,NULL);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFilterDlg::OnOK() 
{
	// TODO: Add extra validation here
	KillTimer(1);
	BeginWaitCursor ();
	ClearPreView();

	CDialog::OnOK();
	Filter();

	EndWaitCursor ();
}

void CFilterDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	KillTimer(1);
	ClearPreView();
	Del(lpProcInfo->_pdbdata );

	CDialog::OnCancel();
}

void CFilterDlg::Filter()
{
	static int nSelect=m_Combo_Stype.GetCurSel();

	switch(m_nFilter)
	{
	case 0:
		switch(nSelect)
		{
		case 0:
//			 _fnCOM_Convolute(lpProcInfo,1,100,&HP1);
			 _fnCOM_HighFilter(lpProcInfo,m_nStrength,0);
			break;
		case 1:
			_fnCOM_Convolute(lpProcInfo,1,m_nStrength,&HP1);
			break;
		case 2:
			_fnCOM_Convolute(lpProcInfo,1,m_nStrength,&HP2);
			break;
		case 3:
			_fnCOM_Convolute(lpProcInfo,1,m_nStrength,&HP3);
			break;

		}
		break;
	case 1:
		_fnCOM_MedianFilter(lpProcInfo,m_nStrength,nSelect);
		break;
	case 2:
		switch(nSelect)
		{
		case 0:
			 _fnCOM_Convolute(lpProcInfo,1,m_nStrength,&LP1);
			break;
		case 1:
			 _fnCOM_Convolute(lpProcInfo,1,m_nStrength,&LP2);
			break;
		case 2:
			 _fnCOM_Convolute(lpProcInfo,1,m_nStrength,&LP3);
			break;
		}
		break;
	case 3:
		switch(m_Combo_Stype.GetCurSel())
		{
		case 0:
			break;
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		case 8:
			break;		
		}
		break;

	}
}

void CFilterDlg::InitCombo()
{
	m_Combo_Stype.ResetContent ();
	switch(m_nFilter)
	{
	case 0:
		m_Combo_Stype.AddString ("��������-[ǿ����Ч]");
		m_Combo_Stype.AddString ("��ͨ�˲�1");
		m_Combo_Stype.AddString ("��ͨ�˲�2");
		m_Combo_Stype.AddString ("��ͨ�˲�3");
//		GetDlgItem(IDC_STATIC_FILTER)->SetWindowText("ǿ�ȣ�");
		m_ButEdit.EnableWindow (FALSE);

		break;
	case 1:
		m_Combo_Stype.AddString ("�м�ֵ-[ȥ�ߵ�]");
		m_Combo_Stype.AddString ("��Сֵ");
		m_Combo_Stype.AddString ("���ֵ");
//		GetDlgItem(IDC_STATIC_FILTER)->SetWindowText("�뾶��");
		m_ButEdit.EnableWindow (FALSE);

		break;
	case 2:
		m_Combo_Stype.AddString ("��ͨ�˲�1");
		m_Combo_Stype.AddString ("��ͨ�˲�2");
		m_Combo_Stype.AddString ("��ͨ�˲�3");
//		GetDlgItem(IDC_STATIC_FILTER)->SetWindowText("ǿ�ȣ�");
		m_ButEdit.EnableWindow (FALSE);
		break;
	case 3:
		m_Combo_Stype.AddString ("�Զ�����1");
		m_Combo_Stype.AddString ("�Զ�����2");
		m_Combo_Stype.AddString ("�Զ�����3");
		m_Combo_Stype.AddString ("�Զ�����4");
		m_Combo_Stype.AddString ("�Զ�����5");
		m_Combo_Stype.AddString ("�Զ�����6");
		m_Combo_Stype.AddString ("�Զ�����7");
		m_Combo_Stype.AddString ("�Զ�����8");
		m_Combo_Stype.AddString ("�Զ�����9");

		m_ButEdit.EnableWindow ();
//		GetDlgItem(IDC_STATIC_FILTER)->SetWindowText("ǿ�ȣ�");
		break;
	}
	m_Combo_Stype.SetCurSel (0);
}

void CFilterDlg::PreView()
{
	switch(m_nFilter)
	{
	case 0:
		switch(m_Combo_Stype.GetCurSel())
		{
		case 0:	
			_fnCOM_HighFilterPreView(m_nStrength,0);
			break;
		case 1:
			 _fnCOM_AdjustConvolutePreView(1,m_nStrength,&HP1);
			break;
		case 2:
			_fnCOM_AdjustConvolutePreView(1,m_nStrength,&HP2);
			break;
		case 3:
			_fnCOM_AdjustConvolutePreView(1,m_nStrength,&HP3);
			break;
		}
		break;
	case 1:
		_fnCOM_MedianFilterPreView(m_nStrength,m_Combo_Stype.GetCurSel());
		break;
	case 2:
		switch(m_Combo_Stype.GetCurSel())
		{
		case 0:
			 _fnCOM_AdjustConvolutePreView(1,m_nStrength,&LP1);
			break;
		case 1:
			 _fnCOM_AdjustConvolutePreView(1,m_nStrength,&LP2);
			break;
		case 2:
			 _fnCOM_AdjustConvolutePreView(1,m_nStrength,&LP3);
			break;
		}
		break;
	case 3:
		switch(m_Combo_Stype.GetCurSel())
		{
		case 0:
			break;
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		case 8:
			break;		
		}
		break;
	}
	GetDlgItem (IDC_PRVIEW_FILTER)->InvalidateRect (NULL,TRUE);
	GetDlgItem (IDC_PRVIEW_FILTER)->UpdateWindow();
}

void CFilterDlg::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_Check_PreView==TRUE)
		_fnCOM_DrawResizePrView(nIDCtl,lpDrawItemStruct);
	else
		_fnCOM_DrawPrView(nIDCtl,lpDrawItemStruct);

	CDialog::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void CFilterDlg::OnSelchangeComboFilter() 
{
	// TODO: Add your control notification handler code here
	KillTimer(1);
	SetTimer(1,DELAYTIME,NULL);
}

void CFilterDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	PreView();

	switch(nIDEvent)
	{
	case 1:
		KillTimer(1);
		break;
	}

	CDialog::OnTimer(nIDEvent);
}

void CFilterDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	CRect rcClient;
	GetClientRect(rcClient);

	// draw scale
	if (m_MemDC.GetSafeHdc() == NULL)
	{
		m_MemDC.CreateCompatibleDC(&dc);
		m_Bitmap.CreateCompatibleBitmap(&dc,rcClient.Width(),rcClient.Height());
		m_MemDC.SelectObject(m_Bitmap);
		
		// draw scale
		m_MemDC.SetBkColor(RGB(255,255,255));
		CBrush bkBrush;
		bkBrush.CreateSysColorBrush(COLOR_ACTIVEBORDER);
		m_MemDC.FillRect(rcClient,&bkBrush);
	}
	if (m_MemDC.GetSafeHdc() != NULL)
		dc.BitBlt(0, 0, rcClient.Width(), rcClient.Height(), &m_MemDC, 0, 0, SRCCOPY);

	// Do not call CDialog::OnPaint() for painting messages
}

void CFilterDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(point.x>LEFT && point.x<LEFT+PREV_WIDTH && point.y>TOP && 
		point.y<TOP+PREV_HEIGHT && m_Check_PreView==FALSE && m_bMouseShow==TRUE)
	{
		SetCursor(m_curDown);
		::SetCapture((HWND)(*this));
		m_bMouseDown=TRUE;
	}
	Oldpoint.x=point.x;
	Oldpoint.y=point.y;
	CDialog::OnLButtonDown(nFlags, point);
}

void CFilterDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(point.x>LEFT && point.x<LEFT+PREV_WIDTH && point.y>TOP && 
		point.y<TOP+PREV_HEIGHT && m_Check_PreView==FALSE && m_bMouseShow==TRUE)
	{
		SetCursor(m_curUp);
		::SetCapture((HWND)(*this));
	}
	else
	{
		SetCursor(m_curNormal);
		::ReleaseCapture();		
	}
	m_bMouseDown=FALSE;
	
	CDialog::OnLButtonUp(nFlags, point);
}

void CFilterDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	static x,y;
	CRect rcClient;
	GetClientRect(rcClient);
	if(nFlags==MK_LBUTTON && m_Check_PreView==FALSE && m_bMouseDown==TRUE && m_bMouseShow==TRUE)
	{
		SetCursor(m_curDown);
		::SetCapture((HWND)(*this));

		ClearPreView();
		InitDraw();
		x=point.x-Oldpoint.x;
		y=point.y-Oldpoint.y;

		if(m_nPosx<lpProcInfo->sImageInfo.width-PREV_WIDTH+3 && m_nPosx>=0)
		{
			m_nPosx=_fnCOM_GetPosx()-x;
		}
		else if(m_nPosx>=lpProcInfo->sImageInfo.width-PREV_WIDTH+3 && x>=0)
		{
			m_nPosx=_fnCOM_GetPosx()-x;
		}
		else if(m_nPosx<=0 && x<0)
		{
			m_nPosx=_fnCOM_GetPosx()-(point.x-Oldpoint.x);
		}

		if(m_nPosy<lpProcInfo->sImageInfo.height -PREV_HEIGHT && m_nPosy>=0)
		{
			m_nPosy=_fnCOM_GetPosy()+y;
		}
		else if(m_nPosy>=lpProcInfo->sImageInfo.height -PREV_HEIGHT && y<0)
		{
			m_nPosy=_fnCOM_GetPosy()+y;
		}
		else if(m_nPosy<0 && y>=0)
		{
			m_nPosy=_fnCOM_GetPosy()+y;
		}

		if(lpProcInfo->sImageInfo.height>PREV_HEIGHT && lpProcInfo->sImageInfo.width>PREV_WIDTH)
		{
			if(m_nPosx<=lpProcInfo->sImageInfo.width-PREV_WIDTH+3 &&
				m_nPosx>=0 && m_nPosy<=lpProcInfo->sImageInfo.height -PREV_HEIGHT &&
				m_nPosy>=0)
			{
				_fnCOM_SetPos_xy(m_nPosx,m_nPosy);
			}
		}
		else if(lpProcInfo->sImageInfo.height>PREV_HEIGHT && lpProcInfo->sImageInfo.width<=PREV_WIDTH)
		{
			if(m_nPosy<lpProcInfo->sImageInfo.height -PREV_HEIGHT &&
				m_nPosy>=0)
			{
				_fnCOM_SetPos_xy(m_nPosx,m_nPosy);
			}
		}
		else if(lpProcInfo->sImageInfo.height<=PREV_HEIGHT && lpProcInfo->sImageInfo.width>PREV_WIDTH)
		{
			if(m_nPosx<=lpProcInfo->sImageInfo.width-PREV_WIDTH+3 &&
				m_nPosx>=0 )
			{
				_fnCOM_SetPos_xy(m_nPosx,m_nPosy);
			}
		}
		Oldpoint.x=point.x;
		Oldpoint.y=point.y;

		GetDlgItem (IDC_PRVIEW_FILTER)->InvalidateRect (NULL,TRUE);
		GetDlgItem (IDC_PRVIEW_FILTER)->UpdateWindow();
		KillTimer(1);
		SetTimer(1,DELAYTIME,NULL);
	}
	else if(m_Check_PreView==FALSE && m_bMouseShow==TRUE && m_bMouseDown==FALSE && 
		point.x>LEFT && point.x<LEFT+PREV_WIDTH && point.y>TOP && 
		point.y<TOP+PREV_HEIGHT)
	{
		SetCursor(m_curUp);
		::SetCapture((HWND)(*this));

	}
	else
	{
		SetCursor(m_curNormal);
		::ReleaseCapture();		
	}	
	CDialog::OnMouseMove(nFlags, point);
}

void CFilterDlg::OnCheckPrevfilter() 
{
	// TODO: Add your control notification handler code here
	m_Check_PreView=!m_Check_PreView;
	UpdateData(FALSE);
	ClearPreView();
	InitDraw();
	GetDlgItem (IDC_PRVIEW_FILTER)->InvalidateRect (NULL,TRUE);
	GetDlgItem (IDC_PRVIEW_FILTER)->UpdateWindow();
	CRect rcClient;
	rcClient.left=LEFT;
	rcClient.top =TOP;
	rcClient.right =LEFT+PREV_WIDTH+3;
	rcClient.bottom =TOP+PREV_HEIGHT+3;
	InvalidateRect (rcClient,TRUE);
	UpdateWindow();

	KillTimer(1);
	SetTimer(1,DELAYTIME,NULL);

}

void CFilterDlg::OnSelchangeTabFilter(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	m_nFilter=m_TabInfo.GetCurSel ();
	InitCombo();
	KillTimer(1);
	SetTimer(1,DELAYTIME,NULL);

	*pResult = 0;
}

void CFilterDlg::OnChangeEditFilter() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData();
	m_nStrength=atoi(m_strFilter);
	m_nStrength=atoi(m_strFilter);

	if(m_nStrength>200)
	{
		m_nStrength=200;
	}

	m_wndFilterBar.SetPos (m_nStrength);
	KillTimer(1);
	SetTimer(1,DELAYTIME,NULL);

	UpdateData(FALSE);
}
