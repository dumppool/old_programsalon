// EdgeEnhanceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "flt_mass.h"
#include "draw.h"
#include "AdjustContrast.h"
#include "DrawPreView.h"
#include "System.h"
#include "EdgeEnhance.h"
#include "ConvoluteKernel.h"
#include "EdgeEnhanceDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	DELAYTIME	300
#define	LEFT		8
#define TOP			8

/////////////////////////////////////////////////////////////////////////////
// CEdgeEnhanceDlg dialog


CEdgeEnhanceDlg::CEdgeEnhanceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEdgeEnhanceDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEdgeEnhanceDlg)
	m_strEdge = _T("100");
	m_Check_PreView = TRUE;
	//}}AFX_DATA_INIT
	m_nComboIndex=0;
	m_bMouseDown=FALSE;
	m_bMouseShow=TRUE;
	m_nEdge=90;
}


void CEdgeEnhanceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEdgeEnhanceDlg)
	DDX_Control(pDX, IDC_COMBO_FILTER, m_Combo_Filter);
	DDX_Control(pDX, IDC_EDIT_EDGE, m_EditEdge);
	DDX_Text(pDX, IDC_EDIT_EDGE, m_strEdge);
	DDV_MaxChars(pDX, m_strEdge, 3);
	DDX_Check(pDX, IDC_CHECK_PRVIEW, m_Check_PreView);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEdgeEnhanceDlg, CDialog)
	//{{AFX_MSG_MAP(CEdgeEnhanceDlg)
	ON_WM_DRAWITEM()
	ON_EN_CHANGE(IDC_EDIT_EDGE, OnChangeEditEdge)
	ON_WM_TIMER()
	ON_CBN_SELCHANGE(IDC_COMBO_FILTER, OnSelchangeComboFilter)
	ON_BN_CLICKED(IDC_CHECK_PRVIEW, OnCheckPrview)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEdgeEnhanceDlg message handlers

BOOL CEdgeEnhanceDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	CreatMemImage(lpProcInfo);
	
	if(lpProcInfo->sImageInfo .height <PREV_HEIGHT && lpProcInfo->sImageInfo .width <PREV_WIDTH)
	{
		m_bMouseShow=FALSE;
	}
	m_nPosx=(lpProcInfo->sImageInfo .width -PREV_WIDTH)/2;
	m_nPosy=(lpProcInfo->sImageInfo .height-PREV_HEIGHT)/2;
	
	_fnCOM_SetPos_xy(m_nPosx,m_nPosy);
	Oldpoint.x=Oldpoint.y=-1;

	m_wndEdgeBar.SubclassDlgItem(IDC_LINETRACK_EDGE, this);
	m_wndEdgeBar.InitControl(IDC_EDIT_EDGE,RGB(0,0,0),0, m_nEdge,100,2);

	m_wndLogo.SubclassDlgItem (IDC_LOGO_EDGE,this);
	m_wndLogo.SetLogoFont ("SIMSUN");
	m_wndLogo.SetLogoText ("iSee��Ч�˾�");

	m_curDown = LoadCursor(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDC_MOVE_DOWN));
	m_curUp = LoadCursor(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDC_MOVE_UP));
	m_curNormal=GetCursor();
	InitDraw();

	InitComBo();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEdgeEnhanceDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	KillTimer(1);
	ClearPreView();
	Del(lpProcInfo->_pdbdata );

	CDialog::OnCancel();
}

void CEdgeEnhanceDlg::OnOK() 
{
	// TODO: Add extra validation here
	KillTimer(1);
	BeginWaitCursor ();
	ClearPreView();

	if(m_nEdge>100)
	{
		m_nEdge=100;
	}
	CDialog::OnOK();
	EdgeEnhance();

	EndWaitCursor ();
}

void CEdgeEnhanceDlg::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_Check_PreView==TRUE)
		_fnCOM_DrawResizePrView(nIDCtl,lpDrawItemStruct);
	else
		_fnCOM_DrawPrView(nIDCtl,lpDrawItemStruct);

	CDialog::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void CEdgeEnhanceDlg::OnChangeEditEdge() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData();
	m_nEdge=atoi(m_strEdge);
	m_nEdge=atoi(m_strEdge);

	if(m_nEdge>100)
	{
		m_nEdge=100;
	}

	m_wndEdgeBar.SetPos (m_nEdge);
	KillTimer(1);
	SetTimer(1,DELAYTIME,NULL);

	UpdateData(FALSE);
}

void CEdgeEnhanceDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	PreViewEdge();

	switch(nIDEvent)
	{
	case 1:
		KillTimer(1);
		break;
	}

	CDialog::OnTimer(nIDEvent);
}

void CEdgeEnhanceDlg::InitComBo()
{
	m_Combo_Filter.AddString ("̿�ʹ���");
	m_Combo_Filter.AddString ("������Ե");
	m_Combo_Filter.AddString ("ˮƽ��ǿ-[ƽ����ǿ]");
	m_Combo_Filter.AddString ("��ֱ��ǿ-[ƽ����ǿ]");
	m_Combo_Filter.AddString ("��ֱˮƽ��ǿ-[ƽ����ǿ]");
	m_Combo_Filter.AddString ("��������ǿ-[�ݶ���ǿ]");
	m_Combo_Filter.AddString ("����������ǿ-[�ݶ���ǿ]");
	m_Combo_Filter.AddString ("��������ǿ-[�ݶ���ǿ]");
	m_Combo_Filter.AddString ("�Ϸ�����ǿ-[�ݶ���ǿ]");
	m_Combo_Filter.AddString ("���Ϸ�����ǿ-[�ݶ���ǿ]");
	m_Combo_Filter.AddString ("���Ϸ�����ǿ-[�ݶ���ǿ]");
	m_Combo_Filter.AddString ("���Ϸ�����ǿ-[�ݶ���ǿ]");
	m_Combo_Filter.AddString ("����������ǿ-[�ݶ���ǿ]");
	m_Combo_Filter.AddString ("����������1-[������˹����]");
	m_Combo_Filter.AddString ("����������2-[������˹����]");
	m_Combo_Filter.AddString ("����������3-[������˹����]");
	m_Combo_Filter.AddString ("����������4-[������˹����]");
	m_Combo_Filter.AddString ("SOBEL��Ե��ǿ");
	m_Combo_Filter.AddString ("HOUGH��Ե��ǿ");
	
	m_Combo_Filter.SetCurSel (0);
}

void CEdgeEnhanceDlg::OnSelchangeComboFilter() 
{
	// TODO: Add your control notification handler code here
	KillTimer(1);
	SetTimer(1,DELAYTIME,NULL);

}

void CEdgeEnhanceDlg::OnCheckPrview() 
{
	// TODO: Add your control notification handler code here
	m_Check_PreView=!m_Check_PreView;
	UpdateData(FALSE);
	ClearPreView();
	InitDraw();
	GetDlgItem (IDC_PRVIEW_EDGE)->InvalidateRect (NULL,TRUE);
	GetDlgItem (IDC_PRVIEW_EDGE)->UpdateWindow();
	CRect rcClient;
	rcClient.left=LEFT;
	rcClient.top =TOP;
	rcClient.right =LEFT+PREV_WIDTH+3;
	rcClient.bottom =TOP+PREV_HEIGHT+3;
	InvalidateRect (rcClient,TRUE);
	UpdateWindow();

	KillTimer(1);
	SetTimer(1,DELAYTIME,NULL);
}

void CEdgeEnhanceDlg::EdgeEnhance()
{
	switch(m_Combo_Filter.GetCurSel())
	{
	case BLACK:
		_fnCOM_Edge(lpProcInfo,110-m_nEdge,FALSE);
		break;
	case HIGHT:
		_fnCOM_Edge(lpProcInfo,110-m_nEdge,TRUE);
		break;
	case VERT:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&VertEdge);
		break;
	case HORZ:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&HorzEdge);
		break;
	case VERTHORZ:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&VertHorzEdge);
		break;
	case NORTH:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&EdgeNorth);
		break;
	case NORTHEAST:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&EdgeNorthEast);
		break;
	case EAST:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&EdgeEast);
		break;
	case SOUTH:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&EdgeSouth);
		break;
	case SOUTHEAST:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&EdgeSouthEast);
		break;
	case SOUTHWEST:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&EdgeSouthWest);
		break;
	case WEST:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&EdgeWest);
		break;
	case NORTHWEST:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&EdgeNorthWest);
		break;
	case LAP1:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&Lap1);
		break;
	case LAP2:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&Lap2);
		break;
	case LAP3:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&Lap3);
		break;
	case LAP4:
		_fnCOM_Convolute(lpProcInfo,1,m_nEdge+10,&Lap4);
		break;
	case SOBEL:
		_fnCOM_Convolute(lpProcInfo,4,m_nEdge+10,Sobel);
		break;
	case HOUGH:
		_fnCOM_Convolute(lpProcInfo,4,m_nEdge+10,Hough);
		break;
	}
}

void CEdgeEnhanceDlg::PreViewEdge()
{
	switch(m_Combo_Filter.GetCurSel())
	{
	case BLACK:
		_fnCOM_AdjustEdgePreView(110-m_nEdge,FALSE);
		break;
	case HIGHT:
		_fnCOM_AdjustEdgePreView(110-m_nEdge,TRUE);
		break;
	case VERT:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&VertEdge);
		break;
	case HORZ:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&HorzEdge);
		break;
	case VERTHORZ:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&VertHorzEdge);
		break;
	case NORTH:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&EdgeNorth);
		break;
	case NORTHEAST:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&EdgeNorthEast);
		break;
	case EAST:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&EdgeEast);
		break;
	case SOUTH:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&EdgeSouth);
		break;
	case SOUTHEAST:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&EdgeSouthEast);
		break;
	case SOUTHWEST:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&EdgeSouthWest);
		break;
	case WEST:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&EdgeWest);
		break;
	case NORTHWEST:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&EdgeNorthWest);
		break;
	case LAP1:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&Lap1);
		break;
	case LAP2:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&Lap2);
		break;
	case LAP3:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&Lap3);
		break;
	case LAP4:
		_fnCOM_AdjustConvolutePreView(1,m_nEdge+10,&Lap4);
		break;
	case SOBEL:
		_fnCOM_AdjustConvolutePreView(4,m_nEdge+10,Sobel);
		break;
	case HOUGH:
		_fnCOM_AdjustConvolutePreView(4,m_nEdge+10,Hough);
		break;
	}

//	_fnCOM_PreThresh();
	GetDlgItem (IDC_PRVIEW_EDGE)->InvalidateRect (NULL,TRUE);
	GetDlgItem (IDC_PRVIEW_EDGE)->UpdateWindow();
}

void CEdgeEnhanceDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	static x,y;
	CRect rcClient;
	GetClientRect(rcClient);
	if(nFlags==MK_LBUTTON && m_Check_PreView==FALSE && m_bMouseDown==TRUE && m_bMouseShow==TRUE)
	{
		SetCursor(m_curDown);
		::SetCapture((HWND)(*this));

		ClearPreView();
		InitDraw();
		x=point.x-Oldpoint.x;
		y=point.y-Oldpoint.y;

		if(m_nPosx<lpProcInfo->sImageInfo.width-PREV_WIDTH+3 && m_nPosx>=0)
		{
			m_nPosx=_fnCOM_GetPosx()-x;
		}
		else if(m_nPosx>=lpProcInfo->sImageInfo.width-PREV_WIDTH+3 && x>=0)
		{
			m_nPosx=_fnCOM_GetPosx()-x;
		}
		else if(m_nPosx<=0 && x<0)
		{
			m_nPosx=_fnCOM_GetPosx()-(point.x-Oldpoint.x);
		}

		if(m_nPosy<lpProcInfo->sImageInfo.height -PREV_HEIGHT && m_nPosy>=0)
		{
			m_nPosy=_fnCOM_GetPosy()+y;
		}
		else if(m_nPosy>=lpProcInfo->sImageInfo.height -PREV_HEIGHT && y<0)
		{
			m_nPosy=_fnCOM_GetPosy()+y;
		}
		else if(m_nPosy<0 && y>=0)
		{
			m_nPosy=_fnCOM_GetPosy()+y;
		}

		if(lpProcInfo->sImageInfo.height>PREV_HEIGHT && lpProcInfo->sImageInfo.width>PREV_WIDTH)
		{
			if(m_nPosx<=lpProcInfo->sImageInfo.width-PREV_WIDTH+3 &&
				m_nPosx>=0 && m_nPosy<=lpProcInfo->sImageInfo.height -PREV_HEIGHT &&
				m_nPosy>=0)
			{
				_fnCOM_SetPos_xy(m_nPosx,m_nPosy);
			}
		}
		else if(lpProcInfo->sImageInfo.height>PREV_HEIGHT && lpProcInfo->sImageInfo.width<=PREV_WIDTH)
		{
			if(m_nPosy<lpProcInfo->sImageInfo.height -PREV_HEIGHT &&
				m_nPosy>=0)
			{
				_fnCOM_SetPos_xy(m_nPosx,m_nPosy);
			}
		}
		else if(lpProcInfo->sImageInfo.height<=PREV_HEIGHT && lpProcInfo->sImageInfo.width>PREV_WIDTH)
		{
			if(m_nPosx<=lpProcInfo->sImageInfo.width-PREV_WIDTH+3 &&
				m_nPosx>=0 )
			{
				_fnCOM_SetPos_xy(m_nPosx,m_nPosy);
			}
		}
		Oldpoint.x=point.x;
		Oldpoint.y=point.y;

		GetDlgItem (IDC_PRVIEW_EDGE)->InvalidateRect (NULL,TRUE);
		GetDlgItem (IDC_PRVIEW_EDGE)->UpdateWindow();
		KillTimer(1);
		SetTimer(1,DELAYTIME,NULL);
	}
	else if(m_Check_PreView==FALSE && m_bMouseShow==TRUE && m_bMouseDown==FALSE && 
		point.x>LEFT && point.x<LEFT+PREV_WIDTH && point.y>TOP && 
		point.y<TOP+PREV_HEIGHT)
	{
		SetCursor(m_curUp);
		::SetCapture((HWND)(*this));

	}
	else
	{
		SetCursor(m_curNormal);
		::ReleaseCapture();		
	}

	CDialog::OnMouseMove(nFlags, point);
}

void CEdgeEnhanceDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(point.x>LEFT && point.x<LEFT+PREV_WIDTH && point.y>TOP && 
		point.y<TOP+PREV_HEIGHT && m_Check_PreView==FALSE && m_bMouseShow==TRUE)
	{
		SetCursor(m_curDown);
		::SetCapture((HWND)(*this));
		m_bMouseDown=TRUE;
	}
	Oldpoint.x=point.x;
	Oldpoint.y=point.y;

	CDialog::OnLButtonDown(nFlags, point);
}

void CEdgeEnhanceDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(point.x>LEFT && point.x<LEFT+PREV_WIDTH && point.y>TOP && 
		point.y<TOP+PREV_HEIGHT && m_Check_PreView==FALSE && m_bMouseShow==TRUE)
	{
		SetCursor(m_curUp);
		::SetCapture((HWND)(*this));
	}
	else
	{
		SetCursor(m_curNormal);
		::ReleaseCapture();		
	}
	m_bMouseDown=FALSE;

	CDialog::OnLButtonUp(nFlags, point);
}

void CEdgeEnhanceDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	CRect rcClient;
	GetClientRect(rcClient);

	// draw scale
	if (m_MemDC.GetSafeHdc() == NULL)
	{
		m_MemDC.CreateCompatibleDC(&dc);
		m_Bitmap.CreateCompatibleBitmap(&dc,rcClient.Width(),rcClient.Height());
		m_MemDC.SelectObject(m_Bitmap);
		
		// draw scale
		m_MemDC.SetBkColor(RGB(255,255,255));
		CBrush bkBrush;
		bkBrush.CreateSysColorBrush(COLOR_ACTIVEBORDER);
		m_MemDC.FillRect(rcClient,&bkBrush);
	}
	if (m_MemDC.GetSafeHdc() != NULL)
		dc.BitBlt(0, 0, rcClient.Width(), rcClient.Height(), &m_MemDC, 0, 0, SRCCOPY);

	// Do not call CDialog::OnPaint() for painting messages
}
