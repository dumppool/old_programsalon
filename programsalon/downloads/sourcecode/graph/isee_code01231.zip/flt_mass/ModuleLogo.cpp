#include "StdAfx.h"
#include "ModuleLogo.h"

/////////////////////////////////////////////////////////////////////////////
// CModuleLogo

CModuleLogo::CModuleLogo()
{
	CModuleLogo::RegisterWndClass(AfxGetInstanceHandle());
}

CModuleLogo::~CModuleLogo()
{
}


BEGIN_MESSAGE_MAP(CModuleLogo, CStatic)
	//{{AFX_MSG_MAP(CModuleLogo)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CModuleLogo message handlers

void CModuleLogo::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	if(m_LogoText.IsEmpty())
		return;

	dc.SetBkMode(TRANSPARENT);

	CRect rectText;
	rectText.left = 10;
	rectText.top = 0;
	rectText.bottom = 35;
	rectText.right = 155;

	CFont * OldFont = dc.SelectObject(&m_fontLogo);

	// draw text in DC
	COLORREF OldColor = dc.SetTextColor( ::GetSysColor( COLOR_3DHILIGHT));

	dc.DrawText( m_LogoText, rectText + CPoint(1,1), DT_SINGLELINE | DT_LEFT | DT_VCENTER);
	dc.SetTextColor( ::GetSysColor( COLOR_3DSHADOW));
	dc.DrawText( m_LogoText, rectText, DT_SINGLELINE | DT_LEFT | DT_VCENTER);

	// restore old text color
	dc.SetTextColor( OldColor);
	// restore old font
	dc.SelectObject(OldFont);

	// Do not call CDialog::OnPaint() for painting messages
}

void CModuleLogo::SetLogoFont(CString Name, int nHeight, int nWeight, BYTE bItalic, BYTE bUnderline)
{
	if(m_fontLogo.m_hObject)
		m_fontLogo.Detach();

	m_fontLogo.CreateFont(nHeight, 0, 0, 0, nWeight, bItalic, bUnderline,0,0,0,0,0,0, Name);
}

void CModuleLogo::SetLogoText(CString Text)
{
	m_LogoText = Text;
}

BOOL CModuleLogo::RegisterWndClass(HINSTANCE hInstance)
{
	WNDCLASS wc;
	wc.lpszClassName = "MODULELOGO_CTRL"; // matches class name in client
	wc.hInstance = hInstance;
	wc.lpfnWndProc = ::DefWindowProc;
	wc.hCursor = ::LoadCursor(NULL, IDC_ARROW);
	wc.hIcon = 0;
	wc.lpszMenuName = NULL;
	wc.hbrBackground = (HBRUSH) ::GetStockObject(NULL_BRUSH);
	wc.style = CS_GLOBALCLASS; // To be modified
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;

	return (::RegisterClass(&wc) != 0);
}
