// test8View.cpp : implementation of the CTest8View class
//

#include "stdafx.h"
#include "test8.h"

#include "test8Doc.h"
#include "test8View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTest8View

IMPLEMENT_DYNCREATE(CTest8View, CView)  

BEGIN_MESSAGE_MAP(CTest8View, CView)
	//{{AFX_MSG_MAP(CTest8View)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTest8View construction/destruction

CTest8View::CTest8View()
{
	// TODO: add construction code here

	client.SetRect(0,0,0,0);
	// ��DrawDIB������
	hdraw = ::DrawDibOpen();

}

CTest8View::~CTest8View()
{
	// �ر�DrawDIB������
	::DrawDibClose(hdraw);
}

BOOL CTest8View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTest8View drawing

void CTest8View::OnDraw(CDC* pDC)
{
	CTest8Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	static char buf[256];
	if ((pDoc->pk.GetState() >= PKST_PASSINFO)&&(pDoc->pkState == 0))
	{
		// ��ʾͼ��������Ϣ��ͼƬ�ߴ硢λ��ȡ��ļ�����޸����ڵ���Ϣ��
		// ��Щ��Ϣ�����ڵ���CMD_GET_FILE_INFO����֮���õ�
		::ZeroMemory((PVOID)buf, sizeof(buf));

		pDoc->pk.comm = CMD_GETPROCTYPE;
		pDoc->pk.result = ER_EMPTY;
		::ZeroMemory((PVOID)pDoc->pk.annexdata.scAnnData, DPK_ANNEXINFOSIZE);
		(*pDoc->lpAccess)(&pDoc->pk);
		::sprintf(buf, "ģ�鴦�����ͣ�%s", (char*)pDoc->pk.annexdata.scAnnData);
		pDC->TextOut(pDoc->pk.imginfo.width, 10, buf, ::strlen(buf));

		pDoc->pk.comm = CMD_GETWRITERS;
		pDoc->pk.result = ER_EMPTY;
		::ZeroMemory((PVOID)pDoc->pk.annexdata.scAnnData, DPK_ANNEXINFOSIZE);
		(*pDoc->lpAccess)(&pDoc->pk);
		::sprintf(buf, "ģ�鿪���ߣ�%s", (char*)pDoc->pk.annexdata.scAnnData);
		pDC->TextOut(pDoc->pk.imginfo.width, 30, buf, ::strlen(buf));

		pDoc->pk.comm = CMD_GETWRITERMESS;
		pDoc->pk.result = ER_EMPTY;
		::ZeroMemory((PVOID)pDoc->pk.annexdata.scAnnData, DPK_ANNEXINFOSIZE);
		(*pDoc->lpAccess)(&pDoc->pk);
		::sprintf(buf, "���������ԣ�%s", (char*)pDoc->pk.annexdata.scAnnData);
		pDC->TextOut(pDoc->pk.imginfo.width, 50, buf, ::strlen(buf));

		pDoc->pk.comm = CMD_GETBUILDID;
		pDoc->pk.result = ER_EMPTY;
		pDoc->pk.annexdata.dwAnnData = 0;
		(*pDoc->lpAccess)(&pDoc->pk);
		::sprintf(buf, "ģ��汾��%d", pDoc->pk.annexdata.dwAnnData);
		pDC->TextOut(pDoc->pk.imginfo.width, 70, buf, ::strlen(buf));

		::sprintf(buf, "ͼ�����ͣ�%d", pDoc->pk.imginfo.imgtype);
		pDC->TextOut(pDoc->pk.imginfo.width, 90, buf, ::strlen(buf));
		::sprintf(buf, "ͼ���ļ���ʽ��%d", pDoc->pk.imginfo.imgformat);
		pDC->TextOut(pDoc->pk.imginfo.width, 110, buf, ::strlen(buf));
		::sprintf(buf, "�ļ��ߴ磺%d", pDoc->pk.imginfo.filesize);
		pDC->TextOut(pDoc->pk.imginfo.width, 130, buf, ::strlen(buf));
		::sprintf(buf, "ͼ�����ݣ�%d��%d��%d", 
			pDoc->pk.imginfo.width, 
			pDoc->pk.imginfo.height, 
			pDoc->pk.imginfo.bitcount);		  
		pDC->TextOut(pDoc->pk.imginfo.width, 150, buf, ::strlen(buf));
		::sprintf(buf, "ͼ�������%d", pDoc->pk.imginfo.imgnumbers);
		pDC->TextOut(pDoc->pk.imginfo.width, 170, buf, ::strlen(buf));
		::sprintf(buf, "�ļ����ڣ�%d-%d-%d  %d:%d:%d", 
			pDoc->pk.imginfo.year, 
			(int)((pDoc->pk.imginfo.monday&0xff00)>>8),
			(int)(pDoc->pk.imginfo.monday&0xff),
			(int)((pDoc->pk.imginfo.time>>16)&0xff), 
			(int)((pDoc->pk.imginfo.time>>8)&0xff), 
			(int)(pDoc->pk.imginfo.time&0xff)
			);
		pDC->TextOut(pDoc->pk.imginfo.width, 190, buf, ::strlen(buf));

		if (pDoc->pk.GetState() >= PKST_INFOANDBITS)
		{
			DrawDibDraw( hdraw, pDC->GetSafeHdc(), 0, 0, -1, -1, 
				(LPBITMAPINFOHEADER)&pDoc->pk.sDIBInfo, 
				(LPVOID)pDoc->pk._pbdata, 0, 0, 
				pDoc->pk.imginfo.width, pDoc->pk.imginfo.height, 
				DDF_SAME_HDC); 
		}
	}
	else
		pDC->TextOut(10, 10, "û��ָ���ļ�!", 13);

}

/////////////////////////////////////////////////////////////////////////////
// CTest8View diagnostics

#ifdef _DEBUG
void CTest8View::AssertValid() const
{
	CView::AssertValid();
}

void CTest8View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTest8Doc* CTest8View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTest8Doc)));
	return (CTest8Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTest8View message handlers



void CTest8View::Serialize(CArchive& ar) 
{
	if (ar.IsStoring())
	{	// storing code
	}
	else
	{	// loading code
	}
}

void CTest8View::PreSubclassWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CView::PreSubclassWindow();
}

void CTest8View::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class
	InvalidateRect(NULL);
}

void CTest8View::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
}



void CTest8View::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	client.SetRect(0,0,cx,cy);
}

