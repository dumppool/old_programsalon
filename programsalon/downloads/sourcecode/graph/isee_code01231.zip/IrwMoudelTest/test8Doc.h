// test8Doc.h : interface of the CTest8Doc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEST8DOC_H__0DB7DF80_4120_11D4_8853_CB775DC66518__INCLUDED_)
#define AFX_TEST8DOC_H__0DB7DF80_4120_11D4_8853_CB775DC66518__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTest8Doc : public CDocument
{
protected: // create from serialization only
	CTest8Doc();
	DECLARE_DYNCREATE(CTest8Doc)

// Attributes
public:
	int			dibitcount;	// ��ǰλ��ֵ
	int			palnum;		// ��ɫ������
	int			pkState;
	CInfoStr	pk;		// ͼ�����ݰ�
	int (WINAPI*lpAccess)(LPINFOSTR);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTest8Doc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void DeleteContents();
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual void SetPathName(LPCTSTR lpszPathName, BOOL bAddToMRU = TRUE);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTest8Doc();
	LPCTSTR GetAccessIO(void);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTest8Doc)
	afx_msg void On1();
	afx_msg void On4();
	afx_msg void On8();
	afx_msg void On16();
	afx_msg void On24();
	afx_msg void On32();
	afx_msg void OnFileSaveAs();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEST8DOC_H__0DB7DF80_4120_11D4_8853_CB775DC66518__INCLUDED_)
