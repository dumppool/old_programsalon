// test8Doc.cpp : implementation of the CTest8Doc class
//

#include "stdafx.h"
#include "test8.h"

#include "test8Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTest8Doc

IMPLEMENT_DYNCREATE(CTest8Doc, CDocument)

BEGIN_MESSAGE_MAP(CTest8Doc, CDocument)
	//{{AFX_MSG_MAP(CTest8Doc)
	ON_COMMAND(BITCOUNT_1, On1)
	ON_COMMAND(BITCOUNT_4, On4)
	ON_COMMAND(BITCOUNT_8, On8)
	ON_COMMAND(BITCOUNT_16, On16)
	ON_COMMAND(BITCOUNT_24, On24)
	ON_COMMAND(BITCOUNT_32, On32)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTest8Doc construction/destruction

CTest8Doc::CTest8Doc()
{
	// TODO: add one-time construction code here
	dibitcount = 8;
	palnum = 256;
	pkState = 0;
	lpAccess = (int (WINAPI*)(LPINFOSTR))GetAccessIO();
}

CTest8Doc::~CTest8Doc()
{
}

BOOL CTest8Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
	//return FALSE;
}



/////////////////////////////////////////////////////////////////////////////
// CTest8Doc serialization

void CTest8Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add storing code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTest8Doc diagnostics

#ifdef _DEBUG
void CTest8Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTest8Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTest8Doc commands


BOOL CTest8Doc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	if (strlen(lpszPathName))
	{
		pkState++;
		if( pk.LoadFromFile(lpszPathName, CMD_IS_VALID_FILE, lpAccess ) )
		{
			if( pk.state != PKST_PASSVER )
			{
				MessageBox(NULL, "��ʽ��֧��", "Error", 0 ) ;
				pkState-- ;
				return FALSE ;
			}
			pk.LoadFromFile(lpszPathName, CMD_LOAD_FROM_FILE, lpAccess);
		}
		pkState--;
	}

	// TODO: Add your specialized creation code here
	return TRUE;
}


LPCTSTR CTest8Doc::GetAccessIO()
{
	CTest8App	*lpApp = (CTest8App*)::AfxGetApp();
	ASSERT(lpApp);

	return (LPCTSTR)lpApp->pAccess;
}



void CTest8Doc::DeleteContents() 
{
	// TODO: Add your specialized code here and/or call the base class
	pk.Clear();	// ��ʼ�����ݰ�Ϊ��
	
	CDocument::DeleteContents();
}

BOOL CTest8Doc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDocument::OnSaveDocument(lpszPathName);
}

void CTest8Doc::SetPathName(LPCTSTR lpszPathName, BOOL bAddToMRU) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CDocument::SetPathName(lpszPathName, bAddToMRU);
}

void CTest8Doc::On1() 
{
	// TODO: Add your command handler code here
	dibitcount = 1;
	palnum = 2;
}

void CTest8Doc::On4() 
{
	// TODO: Add your command handler code here
	dibitcount = 4;
	palnum = 16;
}

void CTest8Doc::On8() 
{
	// TODO: Add your command handler code here
	dibitcount = 8;
	palnum = 256;
}

void CTest8Doc::On16() 
{
	// TODO: Add your command handler code here
	dibitcount = 16;
	palnum = 0;
}

void CTest8Doc::On24() 
{
	// TODO: Add your command handler code here
	dibitcount = 24;
	palnum = 0;
}

void CTest8Doc::On32() 
{
	// TODO: Add your command handler code here
	dibitcount = 32;
	palnum = 0;
}

void CTest8Doc::OnFileSaveAs() 
{
	// TODO: Add your command handler code here
	int result;

	CDocument::OnFileSaveAs();	

	CString fn = GetPathName();

	if (pk.GetState() > PKST_PASSINFO)
	{
		pk.comm = CMD_SAVE_TO_FILE;
		pk.result = ER_EMPTY;
		pk.annexdata.siAnnData[0] = dibitcount;
		pk.annexdata.siAnnData[1] = 0;	// ʹ��ԭʼ��ɫ��
		strcpy(pk.filename, fn);

		result = (*lpAccess)(&pk);

		if (!result)
			TRACE("д�ļ�ʧ�ܣ�");
	}
}
