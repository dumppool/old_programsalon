// test8View.h : interface of the CTest8View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEST8VIEW_H__0DB7DF82_4120_11D4_8853_CB775DC66518__INCLUDED_)
#define AFX_TEST8VIEW_H__0DB7DF82_4120_11D4_8853_CB775DC66518__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CTest8View : public CView
{
protected: // create from serialization only
	CTest8View();
	DECLARE_DYNCREATE(CTest8View)

// Attributes
public:
	CTest8Doc* GetDocument();

	CRect		client;
	HDRAWDIB	hdraw;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTest8View)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void Serialize(CArchive& ar);
	virtual void OnInitialUpdate();
	protected:
	virtual void PreSubclassWindow();
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	//LPCTSTR GetAccessIO(void);
	virtual ~CTest8View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTest8View)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in test8View.cpp
inline CTest8Doc* CTest8View::GetDocument()
   { return (CTest8Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEST8VIEW_H__0DB7DF82_4120_11D4_8853_CB775DC66518__INCLUDED_)
