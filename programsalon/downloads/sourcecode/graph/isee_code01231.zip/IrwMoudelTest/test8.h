// test8.h : main header file for the TEST8 application
//

#if !defined(AFX_TEST8_H__0DB7DF7A_4120_11D4_8853_CB775DC66518__INCLUDED_)
#define AFX_TEST8_H__0DB7DF7A_4120_11D4_8853_CB775DC66518__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include <vfw.h>
#include "..\public\gol_isee.h"
#include "gol_rwcc.h"


/////////////////////////////////////////////////////////////////////////////
// CTest8App:
// See test8.cpp for the implementation of this class
//

class CTest8App : public CWinApp
{
public:
	CTest8App();

	HMODULE	hBmpLib;
	HMODULE	hLib;

	int (WINAPI *pAccess)(LPINFOSTR);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTest8App)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CTest8App)
	afx_msg void OnAppAbout();
	afx_msg void OnFileOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


int WINAPI fnp(int total, int cur);

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEST8_H__0DB7DF7A_4120_11D4_8853_CB775DC66518__INCLUDED_)
