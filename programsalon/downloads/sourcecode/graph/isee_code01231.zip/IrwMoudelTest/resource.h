//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by test8.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TEST8TYPE                   129
#define BITCOUNT_1                      32771
#define BITCOUNT_4                      32772
#define BITCOUNT_8                      32773
#define BITCOUNT_16                     32774
#define BITCOUNT_24                     32775
#define BITCOUNT_32                     32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
