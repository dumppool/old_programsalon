//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IRWConv.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_IRWCONV_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDI_LOGO                        132
#define IDC_OPEN_FILE                   1000
#define IDC_CONV_TO_IRW                 1001
#define IDC_CONV_TO_DLL                 1002
#define IDC_SOU_TYPE                    1005
#define IDC_SOU_MODULE                  1006
#define IDC_SOU_MAJVER                  1008
#define IDC_SOU_PROCTYPE_STR            1010
#define IDC_SOU_WRITER                  1011
#define IDC_SOU_EMAIL                   1012
#define IDC_SOU_HAHA                    1014
#define IDC_DES_FILENAME                1015
#define IDC_SOU_FILENAME                1016
#define IDC_SOU_SUBVER                  1017
#define IDC_LOGO                        1018
#define IDC_FILE_TYPE                   1019
#define IDC_SOU_PROCTYPE_NUM            1020
#define IDC_FULL_IRW                    1021
#define IDC_DESFN_EXIST                 1022
#define IDC_FUN_SAVE_IMAGE              1023
#define IDC_FUN_READ_IMAGE              1024
#define IDC_MODULE_NAME                 1025
#define IDC_FUN_REREAD_IMAGE            1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
