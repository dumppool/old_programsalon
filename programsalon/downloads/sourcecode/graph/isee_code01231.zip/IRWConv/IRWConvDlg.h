// IRWConvDlg.h : header file
//

#if !defined(AFX_IRWCONVDLG_H__E2531526_9B7D_11D4_8853_8E29DD707221__INCLUDED_)
#define AFX_IRWCONVDLG_H__E2531526_9B7D_11D4_8853_8E29DD707221__INCLUDED_

#include "..\public\gol_isee.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// DLL�ӿں�����ַ
typedef int (WINAPI *IRWP_INTERFACE)(LPINFOSTR);

/////////////////////////////////////////////////////////////////////////////
// CIRWConvDlg dialog

class CIRWConvDlg : public CDialog
{
// Construction
public:
	CIRWConvDlg(CWnd* pParent = NULL);	// standard constructor

	int _GetProcTypeData(LPTSTR pSouStr, LPTSTR pDesStr);
	int _CopyFileToIRW(HANDLE hDes, HANDLE hSou);
	int _CopyFileToDLL(HANDLE hDes, HANDLE hSou);
	int _FillToIrw(HANDLE hDes);

// Dialog Data
	//{{AFX_DATA(CIRWConvDlg)
	enum { IDD = IDD_IRWCONV_DIALOG };
	CButton	m_FunReReadImage;
	CEdit	m_ModuleName;
	CButton	m_FunSaveImage;
	CButton	m_FunReadImage;
	CButton	m_DesFileExist;
	CButton	m_FillIRW;
	CStatic	m_ProcTypeNumber;
	CStatic	m_FileType;
	CEdit	m_Writer;
	CComboBox	m_PlugsInType;
	CComboBox	m_SubVer;
	CEdit	m_ProcTypeStr;
	CComboBox	m_Module;
	CComboBox	m_MajVer;
	CEdit	m_HaHa;
	CStatic	m_SouFileName;
	CEdit	m_EMail;
	CButton	m_OpenFile;
	CStatic	m_LogoBmp;
	CEdit	m_DesFileName;
	CButton	m_ConvToIRW;
	CButton	m_ConvToDLL;
	CString	m_SouFileNameStr;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIRWConvDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	CString	m_SouFn;
	PLUGSIN m_Info;
	int		m_State;
	// Generated message map functions
	//{{AFX_MSG(CIRWConvDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnOpenFile();
	afx_msg void OnConvToDll();
	afx_msg void OnConvToIrw();
	afx_msg void OnFillIrw();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IRWCONVDLG_H__E2531526_9B7D_11D4_8853_8E29DD707221__INCLUDED_)
