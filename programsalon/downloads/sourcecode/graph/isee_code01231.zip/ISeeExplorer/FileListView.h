#if !defined(AFX_FILELISTVIEW_H__BD5DE797_44EC_40C9_A673_7466A65E5C02__INCLUDED_)
#define AFX_FILELISTVIEW_H__BD5DE797_44EC_40C9_A673_7466A65E5C02__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FileListView.h : header file
//

#include "ieshelllistview.h"

/////////////////////////////////////////////////////////////////////////////
// CFileListView command target

class CISeeExplorerDoc;

class CFileListView : public CIEShellListView
{
	DECLARE_DYNCREATE(CFileListView)

	CFileListView();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
	CISeeExplorerDoc * GetDocument();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileListView)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual void ItemChanged( UINT nItem );
	virtual ~CFileListView();

	// Generated message map functions
	//{{AFX_MSG(CFileListView)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILELISTVIEW_H__BD5DE797_44EC_40C9_A673_7466A65E5C02__INCLUDED_)
