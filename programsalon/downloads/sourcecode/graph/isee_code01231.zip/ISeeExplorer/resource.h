//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ISeeExplorer.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ISEEEXTYPE                  129
#define IDR_TB2_IP                      135
#define IDB_CONTAINER_BTN               137
#define IDC_HAND_FREE                   138
#define IDC_HAND_MOVE                   139
#define IDC_MEMBER                      1000
#define IDC_CONTAINER_HIDE              2000
#define IDC_CONTAINER_MINI              2001
#define ID_A_RELOAD                     32771
#define ID_B_REDO                       32772
#define ID_C_SWITCH                     32773
#define ID_C_DIRTREE                    32774
#define ID_C_FILELIST                   32775
#define ID_C_ZOOMOUT                    32776
#define ID_C_ZOOM                       32777
#define ID_C_ZOOMIN                     32778
#define ID_C_PREV                       32779
#define ID_C_NEXT                       32780
#define ID_C_MAGICLANTERN               32781
#define ID_C_REFRESH                    32782
#define ID_C_A_LICON                    32784
#define ID_C_B_SICON                    32785
#define ID_C_C_LIST                     32786
#define ID_C_D_REPORT                   32787
#define ID_C_E_THUM                     32788
#define ID_D_SIZE                       32789
#define ID_D_ROTATE                     32790
#define ID_D_CONTRAST                   32791
#define ID_D_GREYSCALE                  32792
#define ID_E_MOSAIC                     32793
#define ID_E_EX_A                       32794
#define ID_E_EX_B                       32795
#define ID_E_DETECTEDGE                 32796
#define ID_E_FILTER                     32797
#define ID_F_A_CENTER                   32799
#define ID_F_B_TILE                     32800
#define ID_F_C_SEL                      32801
#define ID_G_ABOUT_VCHELP_COPATHWAY     32802
#define IDS_REGTAB_LOCAL                61204
#define IDS_CONTAINER_FOLDER_WNDNAME    61205
#define IDS_CONTAINER_FILELIST_WNDNAME  61206

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32835
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
