#if !defined(AFX_WORKSPACE_H__1192FFF5_DAB1_11D4_8853_84ABD091D12C__INCLUDED_)
#define AFX_WORKSPACE_H__1192FFF5_DAB1_11D4_8853_84ABD091D12C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WorkSpace.h : header file
//


#define ISEE_EXPLORER_WS_FIRST		1400

#define ISEE_EXPLORER_WS_WNDID		(ISEE_EXPLORER_WS_FIRST+1)

#define IMN_CHANGING_IMAGE			(WM_USER+ISEE_EXPLORER_WS_FIRST+1)
#define IMN_CHANGING_FOCI			(WM_USER+ISEE_EXPLORER_WS_FIRST+2)
#define IMN_CHANGING_DEM			(WM_USER+ISEE_EXPLORER_WS_FIRST+3)

#define ISEE_EXPLORER_WS_LAST		1500


class CISeeExplorerView;

/////////////////////////////////////////////////////////////////////////////
// CWorkSpace window

class CWorkSpace : public CWnd
{
// Construction
public:
	CWorkSpace();

// Attributes
public:
	HDRAWDIB	m_hDrawDib;

	CString		m_WSClassName;
	CBrush		m_brGround;
	HCURSOR		m_auto;
	HCURSOR		m_hand_free, m_hand_move;

	CReturnReceipt *m_pImage;

	CRect		m_imgrect;
	CRect		m_imgdisprect;
	CRect		m_wndrect;

	BOOL		m_bmove;
	CPoint		m_cursor;

// Operations 
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWorkSpace)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	afx_msg LONG OnChangFoci(UINT parm1, LONG parm2);
	afx_msg LONG OnChangImage(UINT parm1, LONG parm2);
	CReturnReceipt * GetCurCRRt(void);
	virtual ~CWorkSpace();

	// Generated message map functions
protected:
	//{{AFX_MSG(CWorkSpace)
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WORKSPACE_H__1192FFF5_DAB1_11D4_8853_84ABD091D12C__INCLUDED_)
