#if !defined(AFX_ABOUTMEMBER_H__DEA83740_DEB5_11D4_8853_A98FB3A92171__INCLUDED_)
#define AFX_ABOUTMEMBER_H__DEA83740_DEB5_11D4_8853_A98FB3A92171__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AboutMember.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAboutMember window

class CAboutMember : public CStatic
{
// Construction
public:
	CAboutMember();

// Attributes
public:
	HDRAWDIB		m_hDrawDib;
	CReturnReceipt *m_pImage;

	int				m_count;
	int				m_timer;

	int				infonum;
	LPDEVELOPERINFO	lpInfo;
	CFont			infofont;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutMember)
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL RegisterWndClass(HINSTANCE hInstance);
	int InitControl(void);
	virtual ~CAboutMember();

	// Generated message map functions
protected:
	//{{AFX_MSG(CAboutMember)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ABOUTMEMBER_H__DEA83740_DEB5_11D4_8853_A98FB3A92171__INCLUDED_)
