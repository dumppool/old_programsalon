// AboutMember.cpp : implementation file
//

#include "stdafx.h"
#include "iseeexplorer.h"
#include "AboutMember.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static TCHAR titleimagepath[] = _T(".\\title.tga");

/////////////////////////////////////////////////////////////////////////////
// CAboutMember

CAboutMember::CAboutMember()
{
	m_hDrawDib = DrawDibOpen();
	CAboutMember::RegisterWndClass(AfxGetInstanceHandle());
	m_pImage = ISeeGetIRWEngine()->LoadImageFromFile((LPCTSTR)titleimagepath);
	infofont.CreatePointFont(90, _T("����"));

	infonum  = ISeeGetIRWEngine()->GetDeveloperInfo(&lpInfo);

	m_timer = FALSE;
	m_count = 0;
}

CAboutMember::~CAboutMember()
{
	if (m_pImage)
		delete m_pImage;
	if(m_hDrawDib)
		DrawDibClose(m_hDrawDib);
	if (infonum)
		::GlobalFree(lpInfo);
}


BEGIN_MESSAGE_MAP(CAboutMember, CStatic)
	//{{AFX_MSG_MAP(CAboutMember)
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAboutMember message handlers

BOOL CAboutMember::OnEraseBkgnd(CDC* pDC) 
{
	CRect	rect;

	GetClientRect(rect);

	pDC->FillSolidRect(rect, (COLORREF)RGB(255,255,255));
	
	return TRUE;
}

void CAboutMember::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	int		i, start;
	CRect	rect;

	GetClientRect(rect);

	while (m_pImage->GetResult() == IRWERRT_ING);

	if ((m_pImage)&&(m_pImage->GetDataPackState() >= PKST_PASSINFO))
	{
		if (lpInfo)
		{
			CFont *pOldFont = dc.SelectObject(&infofont);
			CRect rtmp;
			start = rect.bottom-m_count;

			for (i=0;i<infonum;i++)
			{
				rtmp.SetRect(rect.left+10, start+i*80, rect.right-10, start+i*80+16);
				dc.DrawText((LPCTSTR)lpInfo[i].modulename, -1, rtmp, DT_SINGLELINE|DT_NOCLIP|DT_RIGHT|DT_VCENTER);
				rtmp.SetRect(rect.left+10, start+i*80+16, rect.right-10, start+i*80+32);
				dc.DrawText((LPCTSTR)lpInfo[i].author, -1, rtmp, DT_SINGLELINE|DT_NOCLIP|DT_RIGHT|DT_VCENTER);
				rtmp.SetRect(rect.left+10, start+i*80+32, rect.right-10, start+i*80+48);
				dc.DrawText((LPCTSTR)lpInfo[i].EMail, -1, rtmp, DT_SINGLELINE|DT_NOCLIP|DT_RIGHT|DT_VCENTER);
				rtmp.SetRect(rect.left+10, start+i*80+48, rect.right-10, start+i*80+64);
				dc.DrawText((LPCTSTR)lpInfo[i].messages, -1, rtmp, DT_SINGLELINE|DT_NOCLIP|DT_RIGHT|DT_VCENTER);
			}
			if ((start+i*80) < rect.bottom)
				m_count = -48;

			dc.SelectObject(pOldFont);
		}

		CRect	imgrect(0, 0, m_pImage->GetImageWidth(), m_pImage->GetImageHeight());
		DrawDibDraw(m_hDrawDib, dc.GetSafeHdc(), 0, 0, 
			imgrect.Width(), imgrect.Height(),
			(LPBITMAPINFOHEADER)(m_pImage->GetImageBitmapInfo()), 
			(LPVOID)(m_pImage->GetImageBitData()), 
			0, 0, imgrect.Width(), imgrect.Height(),
			DDF_HALFTONE);
	}

}


int CAboutMember::InitControl()
{
	m_timer = SetTimer(1, 60, NULL);

	return 0;
}

void CAboutMember::OnTimer(UINT nIDEvent) 
{
	m_count++;
	
	CRect rect;
	
	GetClientRect(rect);

	rect.top = m_pImage->GetImageHeight();

	ScrollWindow(0, -1, rect);

	UpdateWindow();

	CStatic::OnTimer(nIDEvent);
}

void CAboutMember::OnDestroy() 
{
	if (m_timer)
		KillTimer(m_timer);

	CStatic::OnDestroy();
}

BOOL CAboutMember::RegisterWndClass(HINSTANCE hInstance)
{
	WNDCLASS wc;

	wc.lpszClassName = "ISEE_ABOUTMEMBER"; // matches class name in client
	wc.hInstance = hInstance;
	wc.lpfnWndProc = ::DefWindowProc;
	wc.hCursor = ::LoadCursor(NULL, IDC_ARROW);
	wc.hIcon = 0;
	wc.lpszMenuName = NULL;
	wc.hbrBackground = (HBRUSH) ::GetStockObject(LTGRAY_BRUSH);
	wc.style = CS_GLOBALCLASS; // To be modified
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;

	return (::RegisterClass(&wc) != 0);
}
