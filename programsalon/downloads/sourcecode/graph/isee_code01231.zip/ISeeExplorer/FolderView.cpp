// FolderView.cpp : implementation file
//

#include "stdafx.h"
#include "ISeeExplorer.h"

#include "FolderView.h"
#include "FileServer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFolderView

IMPLEMENT_DYNCREATE(CFolderView, CIEShellTreeView)

CFolderView::CFolderView()
{
}

CFolderView::~CFolderView()
{
}


BEGIN_MESSAGE_MAP(CFolderView, CIEShellTreeView)
	//{{AFX_MSG_MAP(CFolderView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFolderView message handlers


