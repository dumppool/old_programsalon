// FSFolder.cpp : implementation file
//

#include "stdafx.h"
#include "ISeeExplorer.h"

#include "FSFolder.h"
#include "FileServer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFSFolder

CFSFolder::CFSFolder(CFileServer* pFS) : m_pFileServer(pFS), m_pView(NULL)
{
}

CFSFolder::~CFSFolder()
{
}


BEGIN_MESSAGE_MAP(CFSFolder, CCJControlBar)
	//{{AFX_MSG_MAP(CFSFolder)
	ON_WM_WINDOWPOSCHANGED()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFSFolder message handlers

// ��λ�ӿ�λ��
void CFSFolder::OnWindowPosChanged(WINDOWPOS FAR* lpwndpos) 
{
	if (m_pView)
	{
		if (IsFloating())
			m_pView->MoveWindow( 5, 5, lpwndpos->cx-10, lpwndpos->cy-7 );
		else if (IsHorzDocked()) 
			m_pView->MoveWindow( 15 , 4 , lpwndpos->cx-25, lpwndpos->cy-17 );
		else
			m_pView->MoveWindow( 4 , 16 , lpwndpos->cx-14, lpwndpos->cy-28 );
	}
	CCJControlBar::OnWindowPosChanged(lpwndpos);
}


// �����ļ����������ӿ�
BOOL CFSFolder::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	CSize	size(rect.right-rect.left, rect.bottom-rect.top);

	if (!CCJControlBar::Create(pParentWnd, nID, lpszWindowName, size, dwStyle))
		return FALSE;

	ASSERT(pContext);	// CFSFolder �಻�����ñ���ΪNULL
	ASSERT(!m_pView);	// ��ʱ��Ӧ�����ӿ�

	CRuntimeClass *pViewClass = RUNTIME_CLASS(CFolderView);
	CWnd* pWnd;

	TRY
	{
		pWnd = (CWnd*)pViewClass->CreateObject();
		if (pWnd == NULL)
			AfxThrowMemoryException();
	}
	CATCH_ALL(e)
	{
		TRACE0("Out of memory creating a folder view.\n");
		return FALSE;
	}
	END_CATCH_ALL

	CCreateContext context;

	context.m_pCurrentDoc = pContext->m_pCurrentDoc;
	context.m_pNewViewClass = pViewClass;

	CRect	defrect(0,0,0,0);
	
	if (!pWnd->Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, defrect, 
		this, ISEE_EXPLORER_FOLDER_VIEW_ID, pContext))
	{
		TRACE0("Warning: couldn't create folder view.\n");
		return FALSE;
	}

	m_pView = (CFolderView*)pWnd;

	return TRUE;
}


// ��ȡ�ļ����ӿ����ַ
CFolderView * CFSFolder::GetFolderView()
{
	return m_pView;
}
