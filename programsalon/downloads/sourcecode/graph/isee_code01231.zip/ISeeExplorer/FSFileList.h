#if !defined(AFX_FSFILELIST_H__BEB4EF60_D4CD_11D4_8853_444553540000__INCLUDED_)
#define AFX_FSFILELIST_H__BEB4EF60_D4CD_11D4_8853_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FSFileList.h : header file
//
#include "cjcontrolbar.h"
class CFileServer;
class CFileListView;

/////////////////////////////////////////////////////////////////////////////
// CFSFileList window

class CFSFileList : public CCJControlBar
{
// Construction
public:
	CFSFileList(CFileServer*);

// Attributes
public:
	CFileServer		*m_pFileServer;
	CFileListView	*m_pView;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFSFileList)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL OnIdle( LONG lCount );
	CFileListView * GetFileListView(void);
	virtual ~CFSFileList();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFSFileList)
	afx_msg void OnWindowPosChanged(WINDOWPOS FAR* lpwndpos);
	afx_msg void OnISeeUpdateImage( WPARAM wParam , LPARAM lParam);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FSFILELIST_H__BEB4EF60_D4CD_11D4_8853_444553540000__INCLUDED_)
