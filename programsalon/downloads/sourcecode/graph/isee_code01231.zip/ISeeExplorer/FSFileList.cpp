// FSFileList.cpp : implementation file
//

#include "stdafx.h"
#include "ISeeExplorer.h"

#include "FSFileList.h"
#include "FileServer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFSFileList

CFSFileList::CFSFileList(CFileServer* pFS) : m_pFileServer(pFS), m_pView(NULL)
{
}

CFSFileList::~CFSFileList()
{
}


BEGIN_MESSAGE_MAP(CFSFileList, CCJControlBar)
	//{{AFX_MSG_MAP(CFSFileList)
	ON_WM_WINDOWPOSCHANGED()
	//}}AFX_MSG_MAP
	ON_MESSAGE( WM_ISEE_UPDATE_IMAGE , OnISeeUpdateImage )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFSFileList message handlers

// �����ļ��б��������ӿ�
BOOL CFSFileList::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	CSize	size(rect.right-rect.left, rect.bottom-rect.top);

	if (!CCJControlBar::Create(pParentWnd, nID, lpszWindowName, size, dwStyle))
		return FALSE;

	ASSERT(pContext);	// CFSFileList �಻�����ñ���ΪNULL
	ASSERT(!m_pView);	// ��ʱ��Ӧ�����ӿ�

	CRuntimeClass *pViewClass = RUNTIME_CLASS(CFileListView);
	CWnd* pWnd;

	TRY
	{
		pWnd = (CWnd*)pViewClass->CreateObject();
		if (pWnd == NULL)
			AfxThrowMemoryException();
	}
	CATCH_ALL(e)
	{
		TRACE0("Out of memory creating a file list view.\n");
		return FALSE;
	}
	END_CATCH_ALL

	CCreateContext context;

	context.m_pCurrentDoc = pContext->m_pCurrentDoc;
	context.m_pNewViewClass = pViewClass;

	CRect	defrect(0,0,0,0);
	
	if (!pWnd->Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, defrect, 
		this, ISEE_EXPLORER_FILELIST_VIEW_ID, pContext))
	{
		TRACE0("Warning: couldn't create file list view.\n");
		return FALSE;
	}

	m_pView = (CFileListView*)pWnd;

	return TRUE;
}

void CFSFileList::OnWindowPosChanged(WINDOWPOS FAR* lpwndpos) 
{
	if (m_pView)
	{
		if (IsFloating())
			m_pView->MoveWindow( 5, 5, lpwndpos->cx-10, lpwndpos->cy-7 );
		else if (IsHorzDocked()) 
			m_pView->MoveWindow( 15 , 4 , lpwndpos->cx-25, lpwndpos->cy-17 );
		else
			m_pView->MoveWindow( 4 , 16 , lpwndpos->cx-14, lpwndpos->cy-28 );
	}
	CCJControlBar::OnWindowPosChanged(lpwndpos);
}

CFileListView * CFSFileList::GetFileListView()
{
	return m_pView;
}

void CFSFileList::OnISeeUpdateImage(WPARAM wParam, LPARAM lParam)
{
	GetParent()->GetParent()->PostMessage( WM_ISEE_UPDATE_IMAGE , wParam , lParam );
}

BOOL CFSFileList::OnIdle(LONG lCount)
{	
	return m_pView->GetShellListCtrl().OnIdle( lCount );
}
