// ISeeExplorer.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ISeeExplorer.h"

#include "AboutMember.h"
#include "WorkSpace.h"
#include "MainFrm.h"
#include "ISeeExplorerDoc.h"
#include "ISeeExplorerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// ����ͼ���д�����
#ifdef _DEBUG
#pragma comment(lib, "..\\IRWEngine\\Debug\\IRWEngine.lib")
#pragma comment(lib, "..\\shelllib\\Debug\\shelllib.lib")
#else
#pragma comment(lib, "..\\IRWEngine\\Release\\IRWEngine.lib")
#pragma comment(lib, "..\\shelllib\\Release\\shelllib.lib")
#endif

// ����DrawDib������
#pragma comment(lib,"vfw32.lib")


/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerApp

BEGIN_MESSAGE_MAP(CISeeExplorerApp, CWinApp)
	//{{AFX_MSG_MAP(CISeeExplorerApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerApp construction

CISeeExplorerApp::CISeeExplorerApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CISeeExplorerApp object

CISeeExplorerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerApp initialization

BOOL CISeeExplorerApp::InitInstance()
{
	if (!AfxOleInit())
	{
		TRACE("Fail to Initialize OLE libraries.\n");
		return FALSE;
	}

	AfxEnableControlContainer();

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	if (!::LoadString(m_hInstance, IDS_REGTAB_LOCAL, (LPTSTR)_regtab_local, _MAX_PATH))
		return FALSE;

	SetRegistryKey((LPCTSTR)_regtab_local);

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	if (ISeeBeginIRWEngine())
		return FALSE;

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CISeeExplorerDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CISeeExplorerView));
	AddDocTemplate(pDocTemplate);

	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	OnFileNew();
	// Dispatch commands specified on the command line
	//if (!ProcessShellCommand(cmdInfo))
	//	return FALSE;

	// The one and only window has been initialized, so show and update it.
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerApp message handlers


void CISeeExplorerApp::OnFileOpen() 
{
	CWinApp::OnFileOpen();
}

BOOL CISeeExplorerApp::OnIdle(LONG lCount) 
{
	// TODO: Add your specialized code here and/or call the base class
	CMainFrame * pFrame = (CMainFrame *)m_pMainWnd;
	return pFrame->m_pDoc->m_FileServer.OnIdle( lCount );
}

int CISeeExplorerApp::ExitInstance() 
{
	ISeeEndIRWEngine();
	
	return CWinApp::ExitInstance();
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

	CAboutMember	m_member;

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CISeeExplorerApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}


BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_member.SubclassDlgItem(IDC_MEMBER, this);
	m_member.InitControl();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAboutDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
}
