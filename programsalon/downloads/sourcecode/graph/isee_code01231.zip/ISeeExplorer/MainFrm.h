// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__2788F1E8_D2CA_11D4_8853_92C688B84649__INCLUDED_)
#define AFX_MAINFRM_H__2788F1E8_D2CA_11D4_8853_92C688B84649__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define	ISEE_EXPLORER_MAINFRAME_FIRST		1000

#define	ISEE_EXPLORER_MAINFRAME_LAST		1100


class CISeeExplorerDoc;


class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	void OnISeeUpdateImage( WPARAM wParam , LPARAM lParam );
	CISeeExplorerDoc * m_pDoc;
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CToolBar    m_wndTBIP;
	CReBar      m_wndReBar;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnCALicon();
	afx_msg void OnCBSicon();
	afx_msg void OnCCList();
	afx_msg void OnCDReport();
	afx_msg void OnCEThum();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__2788F1E8_D2CA_11D4_8853_92C688B84649__INCLUDED_)
