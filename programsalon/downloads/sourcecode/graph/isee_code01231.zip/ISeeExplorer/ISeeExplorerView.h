// ISeeExplorerView.h : interface of the CISeeExplorerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISEEEXPLORERVIEW_H__1192FFEC_DAB1_11D4_8853_84ABD091D12C__INCLUDED_)
#define AFX_ISEEEXPLORERVIEW_H__1192FFEC_DAB1_11D4_8853_84ABD091D12C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define ISEE_EXPLORER_VIEW_FIRST	1500
#define ISEE_EXPLORER_VIEW_LAST		1600

#define ISEE_EXPLORER_VIEW_DEM_HEAD	6				// �̶��߳���
#define ISEE_EXPLORER_VIEW_DEM_NAML	3
#define ISEE_EXPLORER_VIEW_DEM_TAIL	5

#define ISEE_EXPLORER_VIEW_WNDREV_WIDTH_LEFT	8
#define ISEE_EXPLORER_VIEW_WNDREV_WIDTH_RIGHT	16
#define ISEE_EXPLORER_VIEW_WNDREV_HEIGHT_TOP	24
#define ISEE_EXPLORER_VIEW_WNDREV_HEIGHT_BOTTOM	16

#define ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO		0
#define ISEE_EXPLORER_VIEW_SWITCH_DISP_HAND		1

#define ISEE_EXPLORER_VIEW_FOCI_IN				-7
#define ISEE_EXPLORER_VIEW_FOCI_ZOOM			0
#define ISEE_EXPLORER_VIEW_FOCI_OUT				7

// dec
class CWorkSpace;

class CISeeExplorerView : public CView
{
protected: // create from serialization only
	CISeeExplorerView();
	DECLARE_DYNCREATE(CISeeExplorerView)

// Attributes
public:
	CISeeExplorerDoc* GetDocument();

	CReturnReceipt *m_pCRRt;

	BOOL			m_bsil;			// ��ʾ��ǰͼ���Ƿ���С��ʾ��TRUE�������ü�����С��
	CRect			m_rcur;			// �������ߴ�
	CRect			m_rloc;			// ���������ڳߴ缰λ��
	CRect			m_rmax;			// �����ɹ���������󴰿�
	BOOL			m_bmini;		// ��ʾ�������Ƿ���С����TRUE������С����

	int				m_wsfoci;		// ���౶��
	int				m_wsdisp;		// ͼ�����ʾ��ʽ���Զ����š��ֶ����ţ�
	CWorkSpace		m_ws;			// ������

	CPoint			m_xl, m_xr;
	CPoint			m_yt, m_yb;
	CRect			m_rdisploc;		// ��ǰ��ʾλ��
	CRect			m_rimgrect;		// ͼ��ߴ�
	CRect			m_rdemx, m_rdemy;//��ǰ�̶�����ʾ����

	CPen			m_sbn;
	CPen			m_scn;			// locate

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CISeeExplorerView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	LONG OnSelChanged(UINT pm1, LONG pm2);
	afx_msg LONG OnChangDem(UINT parm1, LONG parm2);
	BOOL GetSliMark(void);
	int GetFoci(void);
	int GetDispMode(void);
	void DrawDem(CDC* pDC);
	void UpdateWSize(void);
	CReturnReceipt * GetCurCRRt(void);
	virtual ~CISeeExplorerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CISeeExplorerView)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnViewSwitch();
	afx_msg void OnUpdateViewSwitch(CCmdUI* pCmdUI);
	afx_msg void OnViewZoom();
	afx_msg void OnUpdateViewZoom(CCmdUI* pCmdUI);
	afx_msg void OnViewZoomin();
	afx_msg void OnUpdateViewZoomin(CCmdUI* pCmdUI);
	afx_msg void OnViewZoomout();
	afx_msg void OnUpdateViewZoomout(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ISeeExplorerView.cpp
inline CISeeExplorerDoc* CISeeExplorerView::GetDocument()
   { return (CISeeExplorerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ISEEEXPLORERVIEW_H__1192FFEC_DAB1_11D4_8853_84ABD091D12C__INCLUDED_)
