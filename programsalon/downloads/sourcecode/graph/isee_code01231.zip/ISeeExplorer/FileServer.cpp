// FileServer.cpp : implementation file
//

#include "stdafx.h"
#include "ISeeExplorer.h"

#include "FileServer.h"
#include "ISeeExplorerDoc.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileServer

CFileServer::CFileServer()
{
}

CFileServer::~CFileServer()
{
	if (m_pFolder)
		delete m_pFolder;
	if (m_pFileList)
		delete m_pFileList;
}


/////////////////////////////////////////////////////////////////////////////
// CFileServer message handlers

// ��ʼ���ļ�������
BOOL CFileServer::InitialFileServer(CISeeExplorerDoc *pParentDoc)
{
	ASSERT(pParentDoc);
	ASSERT(pParentDoc->IsKindOf(RUNTIME_CLASS(CISeeExplorerDoc))); 

	m_pDoc = pParentDoc;
	m_pFolder = NULL;
	m_pFileList = NULL;

	m_strFolder.LoadString(IDS_CONTAINER_FOLDER_WNDNAME);
	m_strFileList.LoadString(IDS_CONTAINER_FILELIST_WNDNAME);

	if (!m_Imagelist.Create(IDB_CONTAINER_BTN, 13, 1, (COLORREF)RGB(0,255,0)))
	{
		TRACE0("Failed to create FS container image list!\n");
		return FALSE;      // fail to create
	}

	return TRUE;
}

// �����ļ����������Ӿ�������������ӿڣ�
int CFileServer::CreateVisualComponents(CMainFrame *pParentFrm, CCreateContext* pContext)
{
	ASSERT((pParentFrm)&&(pParentFrm->IsKindOf(RUNTIME_CLASS(CMainFrame))));
	ASSERT(pContext);
	ASSERT(m_pDoc);		// �ļ������������ѱ���ʼ����
	ASSERT(!m_pFolder);
	ASSERT(!m_pFileList);

	// �����ļ���
	m_pFolder = (CFSFolder*) new CFSFolder(this);
	if (!m_pFolder)
	{
		TRACE("Out of memory then create CFSFolder!\n");
		return -1;
	}

	m_pFolder->SetBtnImageList(&m_Imagelist);

	CRect	rect(0,0,200,200);
	if (!m_pFolder->Create(NULL, (LPCTSTR)m_strFolder, WS_CHILD|WS_VISIBLE|CBRS_TOP, 
		rect, (CWnd*)pParentFrm, ISEE_EXPLORER_CONTAINER_FOLDER_ID, pContext))
	{
		TRACE0("fail to create FSFolder container!\n");
		return -1;
	}
	m_pFolder->SetBarStyle(m_pFolder->GetBarStyle() | 
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	m_pFolder->EnableDocking(CBRS_ALIGN_ANY);
	pParentFrm->DockControlBar(m_pFolder, AFX_IDW_DOCKBAR_LEFT);


	// �����ļ��б�
	m_pFileList = (CFSFileList*) new CFSFileList(this);
	if (!m_pFileList)
	{
		TRACE("Out of memory then create CFSFileList!\n");
		return -1;
	}

	m_pFileList->SetBtnImageList(&m_Imagelist);

	if (!m_pFileList->Create(NULL, (LPCTSTR)m_strFileList, WS_CHILD|WS_VISIBLE|CBRS_TOP, 
		rect, (CWnd*)pParentFrm, ISEE_EXPLORER_CONTAINER_FILELIST_ID, pContext))
	{
		TRACE0("fail to create FSFileList container!\n");
		return -1;
	}

	m_pFileList->SetBarStyle(m_pFileList->GetBarStyle() | 
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	m_pFileList->EnableDocking(CBRS_ALIGN_ANY);
	pParentFrm->DockControlBar(m_pFileList, AFX_IDW_DOCKBAR_RIGHT);


	// ����������ϵ
	ASSERT(m_pFolder->GetFolderView());
	ASSERT(m_pFileList->GetFileListView());

	m_pFolder->GetFolderView()->GetShellTreeCtrl().SetListCtrlWnd(
		m_pFileList->GetFileListView()->GetShellListCtrl().GetSafeHwnd());
	m_pFileList->GetFileListView()->GetShellListCtrl().SetTreeCtrlWnd(
		m_pFolder->GetFolderView()->GetShellTreeCtrl().GetSafeHwnd());

	
	return 0;	// �ɹ�
}


void * CFileServer::GetIdleFuncAddr()
{
	return (m_pFileList->m_pView->GetShellListCtrl().GetIdleFuncAddr());
}

void CFileServer::SetListViewType(UINT Style)
{
	m_pFileList->m_pView->GetShellListCtrl().SetViewType( Style );
}


BOOL CFileServer::OnIdle(LONG lCount)
{
	return m_pFileList->OnIdle( lCount );
}
