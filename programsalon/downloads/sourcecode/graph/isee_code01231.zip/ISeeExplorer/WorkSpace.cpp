// WorkSpace.cpp : implementation file
//

#include "stdafx.h"
#include "ISeeExplorer.h"

#include "WorkSpace.h"
#include "ISeeExplorerDoc.h"
#include "ISeeExplorerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWorkSpace

CWorkSpace::CWorkSpace()
{
	m_WSClassName.Empty();

	m_brGround.CreateSolidBrush((COLORREF)::GetSysColor(COLOR_3DFACE));
	m_hand_free = ::AfxGetApp()->LoadCursor(IDC_HAND_FREE);
	m_hand_move = ::AfxGetApp()->LoadCursor(IDC_HAND_MOVE);

	m_auto = ::LoadCursor(NULL, (LPCTSTR)MAKEINTRESOURCE(IDC_ARROW));

	m_pImage = NULL;

	m_bmove = FALSE;
	m_wndrect.SetRectEmpty();
	m_imgrect.SetRectEmpty();
	m_imgdisprect.SetRectEmpty();

	m_hDrawDib = DrawDibOpen();
}

CWorkSpace::~CWorkSpace()
{
	if(m_hDrawDib)
		DrawDibClose(m_hDrawDib);
}


BEGIN_MESSAGE_MAP(CWorkSpace, CWnd)
	//{{AFX_MSG_MAP(CWorkSpace)
	ON_WM_SETCURSOR()
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
	ON_MESSAGE(IMN_CHANGING_IMAGE, OnChangImage)
	ON_MESSAGE(IMN_CHANGING_FOCI, OnChangFoci)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CWorkSpace message handlers

BOOL CWorkSpace::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (cs.lpszClass == NULL)
	{
		m_WSClassName = ::AfxRegisterWndClass(CS_DBLCLKS, NULL, m_brGround);
		cs.lpszClass = (LPCTSTR)m_WSClassName;
	}

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	
	return CWnd::PreCreateWindow(cs);
}

BOOL CWorkSpace::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	CISeeExplorerView *pView = (CISeeExplorerView*)GetParent();
	ASSERT(pView);

	if (pView->GetDispMode() == ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO)
		::SetCursor(m_auto);
	else
	{
		if (pView->GetSliMark())
		{
			if (m_bmove == FALSE)
				::SetCursor(m_hand_free);
			else
				::SetCursor(m_hand_move);
		}
		else
			::SetCursor(m_auto);
	}
	
	return TRUE;
}

void CWorkSpace::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CISeeExplorerView *pView = (CISeeExplorerView*)GetParent();
	ASSERT(pView);

	if ((m_pImage)&&(m_pImage->GetDataPackState() >= PKST_PASSINFO))
	{
		DrawDibDraw(m_hDrawDib, dc.GetSafeHdc(), m_wndrect.left, 
			m_wndrect.top, m_wndrect.Width(), m_wndrect.Height(),
			(LPBITMAPINFOHEADER)(m_pImage->GetImageBitmapInfo()), 
			(LPVOID)(m_pImage->GetImageBitData()), 
			m_imgdisprect.left, m_imgdisprect.top, 
			m_imgdisprect.Width(), m_imgdisprect.Height(), 
			DDF_HALFTONE);

		pView->SendMessage(IMN_CHANGING_DEM, 
			(LPARAM)(CRect*)&m_imgdisprect, 
			(LPARAM)(CRect*)&m_imgrect);
	}
}

CReturnReceipt * CWorkSpace::GetCurCRRt()
{
	CISeeExplorerView *pView = (CISeeExplorerView*)GetParent();
	ASSERT(pView);

	return pView->GetCurCRRt();
}

void CWorkSpace::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	CISeeExplorerView *pView = (CISeeExplorerView*)GetParent();
	ASSERT(pView);
	
	int ccx, ccy;

	m_wndrect.SetRect(0,0,cx,cy);

	if (m_pImage)
	{
		if (pView->GetDispMode() == ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO)
		{
			m_imgdisprect = m_imgrect;
		}
		else
		{
			ASSERT(pView->GetDispMode() == ISEE_EXPLORER_VIEW_SWITCH_DISP_HAND);

			if (pView->GetFoci() == ISEE_EXPLORER_VIEW_FOCI_ZOOM)
			{	// ԭʼ�ߴ�
				ccx = cx;
				ccy = cy;
			}
			else if ((ISEE_EXPLORER_VIEW_FOCI_ZOOM < pView->GetFoci())&&(pView->GetFoci() < ISEE_EXPLORER_VIEW_FOCI_OUT))
			{	// �Ŵ���ʾ��ʽ
				ccx = cx/pView->GetFoci();
				ccy = cy/pView->GetFoci();
			}
			else if ((ISEE_EXPLORER_VIEW_FOCI_IN < pView->GetFoci())&&(pView->GetFoci() < ISEE_EXPLORER_VIEW_FOCI_ZOOM))
			{	// ��С��ʾ��ʽ
				ASSERT(pView->GetFoci());
				ccx = cx*::abs(pView->GetFoci());
				ccy = cy*::abs(pView->GetFoci());
			}
			else
				ASSERT(FALSE);	// �Ƿ������ű���ֵ

			if ((m_imgdisprect.left+ccx) <= m_imgrect.right)
				m_imgdisprect.right = m_imgdisprect.left+ccx;
			else
			{
				m_imgdisprect.right = m_imgrect.right;
				m_imgdisprect.left  = m_imgdisprect.right-ccx;
			}
			if ((m_imgdisprect.top+ccy) <= m_imgrect.bottom)
				m_imgdisprect.bottom = m_imgdisprect.top+ccy;
			else
			{
				m_imgdisprect.bottom = m_imgrect.bottom;
				m_imgdisprect.top    = m_imgdisprect.bottom-ccy;
			}
		}
	}
}

void CWorkSpace::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CISeeExplorerView *pView = (CISeeExplorerView*)GetParent();
	ASSERT(pView);

	if ((pView->GetDispMode() == ISEE_EXPLORER_VIEW_SWITCH_DISP_HAND)&&
		(pView->GetSliMark()))
	{
		m_bmove = TRUE;
		m_cursor = point;
		::SetCursor(m_hand_move);
		::SetCapture((HWND)(*this));
	}
	
	CWnd::OnLButtonDown(nFlags, point);
}

void CWorkSpace::OnLButtonUp(UINT nFlags, CPoint point) 
{
#ifdef _DEBUG
	CISeeExplorerView *pView = (CISeeExplorerView*)GetParent();
	ASSERT(pView);
#endif

	if (m_bmove == TRUE)
	{
		ASSERT(pView->GetDispMode() == ISEE_EXPLORER_VIEW_SWITCH_DISP_HAND);
		::ReleaseCapture();
		::SetCursor(m_hand_free);
		m_cursor = point;
		m_bmove = FALSE;
	}
	
	CWnd::OnLButtonUp(nFlags, point);
}

void CWorkSpace::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CWnd::OnLButtonDblClk(nFlags, point);
}

void CWorkSpace::OnMouseMove(UINT nFlags, CPoint point) 
{
	CPoint	cpt = m_cursor;
	BOOL	bMark = FALSE;
	CISeeExplorerView *pView = (CISeeExplorerView*)GetParent();
	ASSERT(pView);

	if (m_bmove == TRUE)
	{
		ASSERT(nFlags & MK_LBUTTON);

		cpt -= point;

		if (pView->GetDispMode() == ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO)
		{
			ASSERT(FALSE);
		}
		else
		{
			ASSERT(pView->GetDispMode() == ISEE_EXPLORER_VIEW_SWITCH_DISP_HAND);

			if (pView->GetFoci() == ISEE_EXPLORER_VIEW_FOCI_ZOOM)
			{	// ԭʼ�ߴ�
				bMark = TRUE;
			}
			else if ((ISEE_EXPLORER_VIEW_FOCI_ZOOM < pView->GetFoci())&&(pView->GetFoci() < ISEE_EXPLORER_VIEW_FOCI_OUT))
			{	// �Ŵ���ʾ��ʽ
				cpt.x /= pView->GetFoci();
				cpt.y /= pView->GetFoci();
				if ((cpt.x+cpt.y) == 0) 
					bMark = FALSE;
				else
					bMark = TRUE;
			}
			else if ((ISEE_EXPLORER_VIEW_FOCI_IN < pView->GetFoci())&&(pView->GetFoci() < ISEE_EXPLORER_VIEW_FOCI_ZOOM))
			{	// ��С��ʾ��ʽ
				ASSERT(pView->GetFoci());
				cpt.x *= ::abs(pView->GetFoci());
				cpt.y *= ::abs(pView->GetFoci());
				if ((cpt.x+cpt.y) == 0) 
					bMark = FALSE;
				else
					bMark = TRUE;
			}
			else
				ASSERT(FALSE);	// �Ƿ������ű���ֵ
		}

		if (bMark == TRUE)
		{
			m_imgdisprect.OffsetRect(cpt);

			if (m_imgdisprect.left < m_imgrect.left)
				m_imgdisprect.OffsetRect(-m_imgdisprect.left, 0);
			if (m_imgdisprect.right > m_imgrect.right)
				m_imgdisprect.OffsetRect(-(m_imgdisprect.right-m_imgrect.right), 0);
			if (m_imgdisprect.top < m_imgrect.top)
				m_imgdisprect.OffsetRect(0, -m_imgdisprect.top);
			if (m_imgdisprect.bottom > m_imgrect.bottom)
				m_imgdisprect.OffsetRect(0, -(m_imgdisprect.bottom-m_imgrect.bottom));

			m_cursor = point;

			RedrawWindow(NULL, NULL, RDW_INVALIDATE|RDW_UPDATENOW);
		}
	}
	
	CWnd::OnMouseMove(nFlags, point);
}

LONG CWorkSpace::OnChangImage(UINT parm1, LONG parm2)
{
	CRect	*pRect = (CRect*)parm2;
	CISeeExplorerView *pView = (CISeeExplorerView*)GetParent();
	ASSERT(pView);

	m_pImage = GetCurCRRt();

	m_imgrect.SetRect(0,0,m_pImage->GetImageWidth(),m_pImage->GetImageHeight());

	m_wndrect = *pRect;

	if (pView->GetDispMode() == ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO)
	{
		m_imgdisprect = m_imgrect;
	}
	else
	{
		ASSERT(pView->GetDispMode() == ISEE_EXPLORER_VIEW_SWITCH_DISP_HAND);
		ASSERT(pView->GetFoci() == ISEE_EXPLORER_VIEW_FOCI_ZOOM);

		m_imgdisprect = m_wndrect;
	}

	RedrawWindow();

	return 0L;
}

LONG CWorkSpace::OnChangFoci(UINT parm1, LONG parm2)
{
	CISeeExplorerView *pView = (CISeeExplorerView*)GetParent();
	ASSERT(pView);

	CRect	*pRect = (CRect*)parm2;
	int cx, cy, ccx, ccy;

	cx = pRect->Width(); cy = pRect->Height();

	m_wndrect = *pRect;

	if (m_pImage)
	{
		if (pView->GetDispMode() == ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO)
		{
			m_imgdisprect = m_imgrect;
		}
		else
		{
			ASSERT(pView->GetDispMode() == ISEE_EXPLORER_VIEW_SWITCH_DISP_HAND);

			if (pView->GetFoci() == ISEE_EXPLORER_VIEW_FOCI_ZOOM)
			{	// ԭʼ�ߴ�
				ccx = cx;
				ccy = cy;
			}
			else if ((ISEE_EXPLORER_VIEW_FOCI_ZOOM < pView->GetFoci())&&(pView->GetFoci() < ISEE_EXPLORER_VIEW_FOCI_OUT))
			{	// �Ŵ���ʾ��ʽ
				ccx = cx/pView->GetFoci();
				ccy = cy/pView->GetFoci();
			}
			else if ((ISEE_EXPLORER_VIEW_FOCI_IN < pView->GetFoci())&&(pView->GetFoci() < ISEE_EXPLORER_VIEW_FOCI_ZOOM))
			{	// ��С��ʾ��ʽ
				ASSERT(pView->GetFoci());
				ccx = cx*::abs(pView->GetFoci());
				ccy = cy*::abs(pView->GetFoci());
			}
			else
				ASSERT(FALSE);	// �Ƿ������ű���ֵ

			if ((m_imgdisprect.left+ccx) <= m_imgrect.right)
				m_imgdisprect.right = m_imgdisprect.left+ccx;
			else
			{
				m_imgdisprect.right = m_imgrect.right;
				m_imgdisprect.left  = m_imgdisprect.right-ccx;
			}
			if ((m_imgdisprect.top+ccy) <= m_imgrect.bottom)
				m_imgdisprect.bottom = m_imgdisprect.top+ccy;
			else
			{
				m_imgdisprect.bottom = m_imgrect.bottom;
				m_imgdisprect.top    = m_imgdisprect.bottom-ccy;
			}
		}
		pView->SendMessage(IMN_CHANGING_DEM, 
			(LPARAM)(CRect*)&m_imgdisprect, 
			(LPARAM)(CRect*)&m_imgrect);
		RedrawWindow();
	}

	return 0L;
}
