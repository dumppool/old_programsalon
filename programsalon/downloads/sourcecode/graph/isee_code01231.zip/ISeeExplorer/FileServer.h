#if !defined(AFX_FILESERVER_H__BEB4EF61_D4CD_11D4_8853_444553540000__INCLUDED_)
#define AFX_FILESERVER_H__BEB4EF61_D4CD_11D4_8853_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FileServer.h : header file
//

#define	ISEE_EXPLORER_FILESERVER_FIRST		1100

#define	ISEE_EXPLORER_CONTAINER_FOLDER_ID	ISEE_EXPLORER_FILESERVER_FIRST+1
#define	ISEE_EXPLORER_CONTAINER_FILELIST_ID	ISEE_EXPLORER_FILESERVER_FIRST+2
#define	ISEE_EXPLORER_FOLDER_VIEW_ID		ISEE_EXPLORER_FILESERVER_FIRST+3
#define	ISEE_EXPLORER_FILELIST_VIEW_ID		ISEE_EXPLORER_FILESERVER_FIRST+4

#define	ISEE_EXPLORER_FILESERVER_LAST		1200


class CMainFrame;
class CISeeExplorerDoc;

class CFSFileList;
class CFSFolder;
class CFolderView;
class CFileListView;
class CFileServer;


/////////////////////////////////////////////////////////////////////////////
// CFileServer window

#include "viewctrlbar.h"

class CFileServer : public CObject
{
// Construction
public:
	CFileServer();

// Attributes
public:
	CISeeExplorerDoc	*m_pDoc;

	CString			m_strFolder;
	CString			m_strFileList;
	CImageList		m_Imagelist;	// �ļ���������������ťͼ��
	CFSFolder		*m_pFolder;		// �ļ���
	CFSFileList		*m_pFileList;	// �ļ��б�

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileServer)
	//}}AFX_VIRTUAL

// Implementation
public:
	CViewCtrlBar m_bar;
	BOOL OnIdle(LONG lCount);
	void SetListViewType( UINT Style );
	void * GetIdleFuncAddr();
	int CreateVisualComponents(CMainFrame *pParentFrm, CCreateContext* pContext);
	BOOL InitialFileServer(CISeeExplorerDoc *pParentDoc);
	virtual ~CFileServer();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILESERVER_H__BEB4EF61_D4CD_11D4_8853_444553540000__INCLUDED_)
