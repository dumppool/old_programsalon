// IRWETs1Doc.cpp : implementation of the CISeeExplorerDoc class
//

#include "stdafx.h"
#include "ISeeExplorer.h"

#include "WorkSpace.h"
#include "ISeeExplorerview.h"
#include "ISeeExplorerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
 
/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerDoc

IMPLEMENT_DYNCREATE(CISeeExplorerDoc, CDocument)

BEGIN_MESSAGE_MAP(CISeeExplorerDoc, CDocument)
	//{{AFX_MSG_MAP(CISeeExplorerDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerDoc construction/destruction 

CISeeExplorerDoc::CISeeExplorerDoc()
{
//	m_pDirTree = NULL;
//	m_pFileList = NULL;
	m_pWorkView = NULL;

	m_pRReceipt = NULL;
	m_FileServer.InitialFileServer( this );
}

CISeeExplorerDoc::~CISeeExplorerDoc()
{
	m_pRReceipt = NULL;
}

BOOL CISeeExplorerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerDoc serialization

void CISeeExplorerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerDoc diagnostics 

#ifdef _DEBUG
void CISeeExplorerDoc::AssertValid() const
{
	CDocument::AssertValid();
}
 
void CISeeExplorerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerDoc commands

int CISeeExplorerDoc::SelChanged(CReturnReceipt *pReturnReceipt)
{
	ASSERT( pReturnReceipt );

	m_pRReceipt = pReturnReceipt;
	m_pWorkView->PostMessage(WM_ISEE_UPDATE_IMAGE);

	return 0;
}

CReturnReceipt * CISeeExplorerDoc::GetCurrentRReceipt()
{
	return m_pRReceipt;
}
