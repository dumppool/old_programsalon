#if !defined(AFX_FOLDERVIEW_H__71FC9758_97F6_490B_B68E_CCE45FC9230F__INCLUDED_)
#define AFX_FOLDERVIEW_H__71FC9758_97F6_490B_B68E_CCE45FC9230F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FolderView.h : header file
//

#include "ieshelltreeview.h"

/////////////////////////////////////////////////////////////////////////////
// CFolderView command target

class CFolderView : public CIEShellTreeView
{
	DECLARE_DYNCREATE(CFolderView)

	CFolderView();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFolderView)
	public:
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CFolderView();

	// Generated message map functions
	//{{AFX_MSG(CFolderView)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOLDERVIEW_H__71FC9758_97F6_490B_B68E_CCE45FC9230F__INCLUDED_)
