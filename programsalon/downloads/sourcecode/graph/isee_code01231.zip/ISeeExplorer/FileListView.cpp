// FileListView.cpp : implementation file
//

#include "stdafx.h"
#include "ISeeExplorer.h"

#include "FileListView.h"
#include "ISeeExplorerDoc.h"
#include "FileServer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileListView

IMPLEMENT_DYNCREATE(CFileListView, CIEShellListView)

CFileListView::CFileListView()
{
}

CFileListView::~CFileListView()
{

}


BEGIN_MESSAGE_MAP(CFileListView, CIEShellListView)
	//{{AFX_MSG_MAP(CFileListView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileListView message handlers

void CFileListView::ItemChanged(UINT nItem)
{
	LPLVITEMDATA pItemData = (LPLVITEMDATA)GetShellListCtrl().GetItemData( nItem );
	GetParent()->SendMessage( WM_ISEE_UPDATE_IMAGE , 0 , (LPARAM)pItemData->pRReceipt );
}

CISeeExplorerDoc * CFileListView::GetDocument()
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CISeeExplorerDoc)));
	return (CISeeExplorerDoc*)m_pDocument;
}