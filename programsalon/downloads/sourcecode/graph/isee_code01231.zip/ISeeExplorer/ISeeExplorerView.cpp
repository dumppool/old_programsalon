// ISeeExplorerView.cpp : implementation of the CISeeExplorerView class
//

#include "stdafx.h"
#include "ISeeExplorer.h"

#include "WorkSpace.h"
#include "ISeeExplorerDoc.h"
#include "ISeeExplorerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerView

IMPLEMENT_DYNCREATE(CISeeExplorerView, CView)

BEGIN_MESSAGE_MAP(CISeeExplorerView, CView)
	//{{AFX_MSG_MAP(CISeeExplorerView)
	ON_WM_ERASEBKGND()
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_C_SWITCH, OnViewSwitch)
	ON_UPDATE_COMMAND_UI(ID_C_SWITCH, OnUpdateViewSwitch)
	ON_COMMAND(ID_C_ZOOM, OnViewZoom)
	ON_UPDATE_COMMAND_UI(ID_C_ZOOM, OnUpdateViewZoom)
	ON_COMMAND(ID_C_ZOOMIN, OnViewZoomin)
	ON_UPDATE_COMMAND_UI(ID_C_ZOOMIN, OnUpdateViewZoomin)
	ON_COMMAND(ID_C_ZOOMOUT, OnViewZoomout)
	ON_UPDATE_COMMAND_UI(ID_C_ZOOMOUT, OnUpdateViewZoomout)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
	ON_MESSAGE(IMN_CHANGING_DEM, OnChangDem)
	ON_MESSAGE(WM_ISEE_UPDATE_IMAGE, OnSelChanged)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerView construction/destruction

CISeeExplorerView::CISeeExplorerView()
{
	m_bmini = TRUE;
	m_bsil  = FALSE;
	m_rmax.SetRectEmpty();
	m_rcur.SetRectEmpty();
	m_rloc.SetRectEmpty();
	m_pCRRt = NULL;

	m_wsfoci = ISEE_EXPLORER_VIEW_FOCI_ZOOM;
	m_wsdisp = ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO;

	m_xl.x = m_xl.y = 0;
	m_xr.x = m_xr.y = 0;
	m_yt.x = m_yt.y = 0;
	m_yb.x = m_yb.y = 0;

	m_rdisploc.SetRectEmpty();
	m_rimgrect.SetRectEmpty();
	m_rdemx.SetRectEmpty();
	m_rdemy.SetRectEmpty();

	m_sbn.CreatePen(PS_SOLID,1,(COLORREF)RGB(255,255,255));
	m_scn.CreatePen(PS_SOLID,1,(COLORREF)RGB(128,128,128));
}

CISeeExplorerView::~CISeeExplorerView()
{
	m_sbn.DeleteObject();
	m_scn.DeleteObject();
}

BOOL CISeeExplorerView::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= WS_CLIPCHILDREN;

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerView drawing

void CISeeExplorerView::OnDraw(CDC* pDC)
{
	CISeeExplorerDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	DrawDem(pDC);
}

/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerView printing

BOOL CISeeExplorerView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CISeeExplorerView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CISeeExplorerView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerView diagnostics

#ifdef _DEBUG
void CISeeExplorerView::AssertValid() const
{
	CView::AssertValid();
}

void CISeeExplorerView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CISeeExplorerDoc* CISeeExplorerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CISeeExplorerDoc)));
	return (CISeeExplorerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CISeeExplorerView message handlers

void CISeeExplorerView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	CISeeExplorerDoc * pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->m_pWorkView = this;

	ModifyStyleEx(WS_EX_CLIENTEDGE, 0, FALSE);
}

BOOL CISeeExplorerView::OnEraseBkgnd(CDC* pDC) 
{
	CRect	rect;
	GetClientRect(rect);

	pDC->FillSolidRect(rect, (COLORREF)::GetSysColor(COLOR_3DFACE));
	pDC->DrawEdge(rect, EDGE_ETCHED, BF_RECT);

	return TRUE;
}

int CISeeExplorerView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_ws.Create(NULL, NULL, WS_CHILD|WS_VISIBLE, CRect(0,0,0,0), 
					this, ISEE_EXPLORER_WS_WNDID))
		return -1;

	return 0;
}

void CISeeExplorerView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	if ((cx <= (ISEE_EXPLORER_VIEW_WNDREV_WIDTH_LEFT+ISEE_EXPLORER_VIEW_WNDREV_WIDTH_RIGHT))||
		(cy <= (ISEE_EXPLORER_VIEW_WNDREV_HEIGHT_TOP+ISEE_EXPLORER_VIEW_WNDREV_HEIGHT_BOTTOM)))
	{
		m_bmini = TRUE;
		m_rmax.SetRectEmpty();
		m_xl.x = m_xl.y = 0;
		m_xr.x = m_xr.y = 0;
		m_yt.x = m_yt.y = 0;
		m_yb.x = m_yb.y = 0;
	}
	else
	{
		m_bmini = FALSE;
		m_rmax.SetRect(ISEE_EXPLORER_VIEW_WNDREV_WIDTH_LEFT, 
				ISEE_EXPLORER_VIEW_WNDREV_HEIGHT_TOP, 
				cx-ISEE_EXPLORER_VIEW_WNDREV_WIDTH_RIGHT, 
				cy-ISEE_EXPLORER_VIEW_WNDREV_HEIGHT_BOTTOM);
		m_xl.x = m_rmax.left;
		m_xl.y = cy-ISEE_EXPLORER_VIEW_WNDREV_HEIGHT_BOTTOM/2-2;
		//m_xr.x = cx-ISEE_EXPLORER_VIEW_WNDREV_WIDTH_RIGHT/2-2;
		m_xr.x = m_rmax.right;
		m_xr.y = cy-ISEE_EXPLORER_VIEW_WNDREV_HEIGHT_BOTTOM/2-2;
		m_yt.x = cx-ISEE_EXPLORER_VIEW_WNDREV_WIDTH_RIGHT/2-2;
		m_yt.y = m_rmax.top;
		m_yb.x = cx-ISEE_EXPLORER_VIEW_WNDREV_WIDTH_RIGHT/2-2;
		//m_yb.y = cy-ISEE_EXPLORER_VIEW_WNDREV_HEIGHT_BOTTOM/2-2;
		m_yb.y = m_rmax.bottom;
	}

	if (m_ws.GetSafeHwnd())
	{
		UpdateWSize();
		m_ws.PostMessage(IMN_CHANGING_FOCI, 0, (LPARAM)(CRect*)&m_rcur);
		m_ws.MoveWindow(m_rloc, TRUE);
	}
}

void CISeeExplorerView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
}

CReturnReceipt * CISeeExplorerView::GetCurCRRt()
{
	return GetDocument()->m_pRReceipt;
}

void CISeeExplorerView::UpdateWSize()
{
	if (!m_pCRRt)
		return;

	if (m_pCRRt->GetDataPackState() < PKST_PASSINFO)
		return;

	float	fy;
	CRect	rect(0,0,m_pCRRt->GetImageWidth(),m_pCRRt->GetImageHeight());

	if (m_wsdisp == ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO)
	{
		fy = (float)m_pCRRt->GetImageWidth()/(float)m_pCRRt->GetImageHeight();
		if ((rect.Width() > m_rmax.Width())||(rect.Height() > m_rmax.Height()))
		{
			m_bsil = TRUE;
			if (rect.Width() > m_rmax.Width())
				rect.DeflateRect(0, 0, rect.Width()-m_rmax.Width(), (int)((rect.Width()-m_rmax.Width())/fy));
			if (rect.Height() > m_rmax.Height())
				rect.DeflateRect(0, 0, (int)((rect.Height()-m_rmax.Height())*fy), rect.Height()-m_rmax.Height());
		}
		else
			m_bsil = FALSE;

	}
	else
	{
		ASSERT(m_wsdisp == ISEE_EXPLORER_VIEW_SWITCH_DISP_HAND);

		if (m_wsfoci == ISEE_EXPLORER_VIEW_FOCI_ZOOM)
		{	// ԭʼ�ߴ�
			;
		}
		else if ((ISEE_EXPLORER_VIEW_FOCI_ZOOM < m_wsfoci)&&(m_wsfoci < ISEE_EXPLORER_VIEW_FOCI_OUT))
		{	// �Ŵ���ʾ��ʽ
			rect.right = rect.right*m_wsfoci;
			rect.bottom= rect.bottom*m_wsfoci;
		}
		else if ((ISEE_EXPLORER_VIEW_FOCI_IN < m_wsfoci)&&(m_wsfoci < ISEE_EXPLORER_VIEW_FOCI_ZOOM))
		{	// ��С��ʾ��ʽ
			ASSERT(m_wsfoci);
			rect.right = rect.right/::abs(m_wsfoci);
			rect.bottom= rect.bottom/::abs(m_wsfoci);
		}
		else
			ASSERT(FALSE);	// �Ƿ������ű���ֵ

		if ((rect.Width() > m_rmax.Width())||(rect.Height() > m_rmax.Height()))
		{
			m_bsil = TRUE;
			if (rect.Width() > m_rmax.Width())
				rect.right = m_rmax.Width();
			if (rect.Height() > m_rmax.Height())
				rect.bottom= m_rmax.Height();
		}
		else
			m_bsil = FALSE;
	}
	m_rcur = rect;

	rect.OffsetRect((m_rmax.Width()-rect.Width())/2, (m_rmax.Height()-rect.Height())/2);
	rect.OffsetRect(m_rmax.left, m_rmax.top);
	m_ws.CalcWindowRect(rect, CWnd::adjustOutside);
	m_rloc = rect;

	return;
}

void CISeeExplorerView::DrawDem(CDC *pDC)
{
	if (m_wsdisp == ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO)
		return;

	CPen *pOldPen = pDC->SelectObject((CPen*)&m_sbn);

	if ((m_pCRRt)&&(!m_rdisploc.IsRectNull())&&(m_bsil))
	{
		ASSERT(!m_rimgrect.IsRectNull());

		int   i;
		float fdemx = (m_xr.x-m_xl.x)/(float)m_rimgrect.Width();
		float fdemy = (m_yb.y-m_yt.y)/(float)m_rimgrect.Height();
		float fx = ((float)m_rmax.Width())/10;
		float fy = ((float)m_rmax.Height())/10;

		m_rdemx.left = (LONG)((float)m_xl.x + m_rdisploc.left*fdemx);
		m_rdemx.top  = m_xl.y;
		m_rdemx.right  = (LONG)((float)m_xl.x + m_rdisploc.right*fdemx);
		m_rdemx.bottom = m_xl.y;
		m_rdemy.left = m_yt.x;
		m_rdemy.top  = (LONG)((float)m_yt.y + m_rdisploc.top*fdemy);
		m_rdemy.right  = m_yt.x;
		m_rdemy.bottom = (LONG)((float)m_yt.y + m_rdisploc.bottom*fdemy);

		int foci = (m_wsfoci == 0) ? 1 : ::abs(m_wsfoci);
		BOOL  bSing = ((m_rdisploc.Width()/foci<m_rimgrect.Width()/foci)&&
			(m_rdisploc.Height()/foci<m_rimgrect.Height()/foci)) ? TRUE:FALSE;

		if (m_rdisploc.Width()/foci < m_rimgrect.Width()/foci)
		{
			for (i=0;i<=10;i++)
			{
				if (i == 0)
				{
					pDC->MoveTo(m_xl);
					pDC->LineTo(m_xl.x, m_xl.y-ISEE_EXPLORER_VIEW_DEM_HEAD);
				}
				else if (i == 10)
				{
					pDC->MoveTo(m_xl.x+(int)(i*fx+0.5), m_xl.y);
					pDC->LineTo(m_xl.x+(int)(i*fx+0.5), m_xl.y-ISEE_EXPLORER_VIEW_DEM_TAIL);
				}
				else
				{
					pDC->MoveTo(m_xl.x+(int)(i*fx+0.5), m_xl.y);
					pDC->LineTo(m_xl.x+(int)(i*fx+0.5), m_xl.y-ISEE_EXPLORER_VIEW_DEM_NAML);
				}
			}
			pDC->MoveTo(m_xl);
			pDC->LineTo(m_rdemx.TopLeft());
			pDC->SelectObject((CPen*)&m_scn);
			pDC->LineTo(m_rdemx.BottomRight());
			pDC->SelectObject((CPen*)&m_sbn);
			pDC->LineTo(m_xr);
		}

		if (m_rdisploc.Height()/foci < m_rimgrect.Height()/foci)
		{
			for (i=0;i<=10;i++)
			{
				if (i == 0)
				{
					pDC->MoveTo(m_yt);
					pDC->LineTo(m_yt.x-ISEE_EXPLORER_VIEW_DEM_HEAD, m_yt.y);
				}
				else if (i == 10)
				{
					pDC->MoveTo(m_yt.x, m_yt.y+(int)(i*fy+0.5));
					pDC->LineTo(m_yt.x-ISEE_EXPLORER_VIEW_DEM_TAIL, m_yt.y+(int)(i*fy+0.5));
				}
				else
				{
					pDC->MoveTo(m_yt.x, m_yt.y+(int)(i*fy+0.5));
					pDC->LineTo(m_yt.x-ISEE_EXPLORER_VIEW_DEM_NAML, m_yt.y+(int)(i*fy+0.5));
				}
			}
			pDC->MoveTo(m_yt);
			pDC->LineTo(m_rdemy.TopLeft());
			pDC->SelectObject((CPen*)&m_scn);
			pDC->LineTo(m_rdemy.BottomRight());
			pDC->SelectObject((CPen*)&m_sbn);
			pDC->LineTo(m_yb);
		}

		if (bSing)
			pDC->Rectangle(m_xr.x+1, m_yb.y+1, m_yb.x+1, m_xr.y+1);
	}

	pDC->SelectObject(pOldPen);
}

void CISeeExplorerView::OnViewSwitch() 
{
	m_wsdisp = (ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO == m_wsdisp) ? ISEE_EXPLORER_VIEW_SWITCH_DISP_HAND:ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO;
	UpdateWSize();
	m_ws.PostMessage(IMN_CHANGING_FOCI, 0, (LPARAM)(CRect*)&m_rcur);
	m_ws.MoveWindow(m_rloc, TRUE);
	RedrawWindow();
}

void CISeeExplorerView::OnUpdateViewSwitch(CCmdUI* pCmdUI) 
{
	if (ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO == m_wsdisp)
		pCmdUI->SetCheck(0);
	else
		pCmdUI->SetCheck(1);
}

void CISeeExplorerView::OnViewZoom() 
{
	m_wsfoci = ISEE_EXPLORER_VIEW_FOCI_ZOOM;
	UpdateWSize();
	m_ws.SendMessage(IMN_CHANGING_FOCI, 0, (LPARAM)(CRect*)&m_rcur);
	m_ws.MoveWindow(m_rloc, TRUE);
	RedrawWindow();
}

void CISeeExplorerView::OnUpdateViewZoom(CCmdUI* pCmdUI) 
{
	if (m_wsdisp == ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO)
		pCmdUI->Enable(FALSE);
	else
	{
		if (m_wsfoci == ISEE_EXPLORER_VIEW_FOCI_ZOOM)
			pCmdUI->Enable(FALSE);
		else
			pCmdUI->Enable();
	}
}

void CISeeExplorerView::OnViewZoomin() 
{
	ASSERT(m_wsfoci > ISEE_EXPLORER_VIEW_FOCI_IN);

	if (::abs(--m_wsfoci) == 1)
		m_wsfoci--;
	UpdateWSize();
	m_ws.SendMessage(IMN_CHANGING_FOCI, 0, (LPARAM)(CRect*)&m_rcur);
	m_ws.MoveWindow(m_rloc, TRUE);
	RedrawWindow();
}

void CISeeExplorerView::OnUpdateViewZoomin(CCmdUI* pCmdUI) 
{
	if (m_wsdisp == ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO)
		pCmdUI->Enable(FALSE);
	else
	{
		if (m_wsfoci > (ISEE_EXPLORER_VIEW_FOCI_IN+1))
			pCmdUI->Enable();
		else
			pCmdUI->Enable(FALSE);
	}
}

void CISeeExplorerView::OnViewZoomout() 
{
	ASSERT(m_wsfoci < ISEE_EXPLORER_VIEW_FOCI_OUT);

	if (::abs(++m_wsfoci) == 1)
		m_wsfoci++;
	UpdateWSize();
	m_ws.SendMessage(IMN_CHANGING_FOCI, 0, (LPARAM)(CRect*)&m_rcur);
	m_ws.MoveWindow(m_rloc, TRUE);
	RedrawWindow();
}

void CISeeExplorerView::OnUpdateViewZoomout(CCmdUI* pCmdUI) 
{
	if (m_wsdisp == ISEE_EXPLORER_VIEW_SWITCH_DISP_AUTO)
		pCmdUI->Enable(FALSE);
	else
	{
		if (m_wsfoci < (ISEE_EXPLORER_VIEW_FOCI_OUT-1))
			pCmdUI->Enable();
		else
			pCmdUI->Enable(FALSE);
	}
}

int CISeeExplorerView::GetDispMode()
{
	return m_wsdisp;
}

int CISeeExplorerView::GetFoci()
{
	return m_wsfoci;
}

BOOL CISeeExplorerView::GetSliMark()
{
	return m_bsil;
}

LONG CISeeExplorerView::OnChangDem(UINT parm1, LONG parm2)
{
	m_rdisploc = *((CRect*)parm1);
	m_rimgrect = *((CRect*)parm2);

	CDC dc;
	HDC hDC = ::GetDC(GetSafeHwnd());
	dc.Attach(hDC);

	DrawDem(&dc);

	hDC = dc.Detach();
	::ReleaseDC(GetSafeHwnd(), hDC);

	return 0L;
}

LONG CISeeExplorerView::OnSelChanged(UINT pm1, LONG pm2)
{
	if (!GetCurCRRt())
		return -1;

	m_pCRRt = GetCurCRRt();

	while (m_pCRRt->GetResult() == IRWERRT_ING);

	m_wsfoci = ISEE_EXPLORER_VIEW_FOCI_ZOOM;

	UpdateWSize();
	m_ws.PostMessage(IMN_CHANGING_IMAGE, 0, (LPARAM)(CRect*)&m_rcur);
	m_ws.MoveWindow(m_rloc, TRUE);
	InvalidateRect(NULL);

	return 0L;
}
