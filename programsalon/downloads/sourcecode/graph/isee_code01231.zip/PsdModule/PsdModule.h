// PsdModule.h : main header file for the PSDMODULE DLL
//

#if !defined(AFX_PSDMODULE_H__C03B0EB5_460A_11D4_8853_C6A14464AE19__INCLUDED_)
#define AFX_PSDMODULE_H__C03B0EB5_460A_11D4_8853_C6A14464AE19__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "..\public\gol_isee.h"	// ���ļ������˽ӿ����ݰ�

/////////////////////////////////////////////////////////////////////////////
/////               ������ PSD �ļ��Ľṹ
/////////////////////////////////////////////////////////////////////////////

#define PSD_SIGNATURE_MARKER		0x53504238	//	((WORD)('S'<<24)|(WORD)('P'<<16)|(WORD)('B'<<8)|'8')
#define PSD_VERSION_MARKER			0x0100		//	(WORD)(1<<8)

#define ExchangeDWord(dword) ((dword&0xff)<<24)+((dword&0xff00)<<8)+((dword&0xff0000)>>8)+((dword&0xff000000)>>24)
#define ExchangeWord(word)	((word&0xff)<<8)+((word&0xff00)>>8)

#define RWPROGRESSSIZE					100

// Ŀ��ͼλ��ȸ�ʽ
enum DESFORMAT
{
	DF_NULL,		// ��Ч��Ŀ���ʽ
	DF_16_555,		// 16λ555��ʽ��Ҳ����15λͼ��
	DF_16_565,		// 16λ565��ʽ
	DF_24,			// 24λ��ʽ
	DF_32,			// 32λ��ʽ
	DF_MAX			// ��Чֵ�߽�
};

// ͼ��Ĵ洢��ʽ
enum IMAGEMODE
{
	BITMAP_Image = 0,		// Bitmap ��λͼ,ÿ������ֻҪһ��λ(�ڰ�)
	GRAYSCALE_Image = 1,	// �Ҷ�ͼ(��8λ��16λ)
	INDEXED_Image = 2,		// ����ͼ����ɫ��(ֻ��8λ)
	RGB_Image = 3,			// ��R,G,B��ɫ��ͼ( RRR..GGG..BBB.. )
	CMYK_Image = 4,			// ��C,M,Y,K��ɫ��ͼ( CCC..MMM..YYY..KKK.. )
	MULTICHANNEL_Image = 7,	// ��ͨ��
	DUOTONE_Image = 8,		// ˫ɫ
	LAB_Image = 9			// Labɫ
};

// PSD �ļ���Ϣͷ�ṹ

typedef struct
{
	DWORD		Signature;	// Always equal to 8BPS
	WORD		Version;	// Always equal to 1
	WORD		Reserved0;	////////////////////////
	WORD		Reserved1;	// Reserved 6 bytes
	WORD		Reserved2;	//
	WORD		Channels;	// (range: 1 to 24 )
	// The number of channels in the image.
	DWORD		Rows;		// Rows		(range: 1 to 30000)
	DWORD		Columns;	// Columns	(range: 1 to 30000)
	WORD		Depth;		// bits per channel (Values: 1, 8, 16)
	WORD		Mode;		// Color mode
	// Values are:
	// Bitmap=0, Grayscale=1, Indexed=2, RGB=3, CMYK=4, Multichannel=7, Duotone=8, Lab=9
}PSDFILEHEADER, *LPPSDFILEHEADER;

/////////////////////////////////////////////////////////////////////////////
// CPsdModuleApp
// See PsdModule.cpp for the implementation of this class
//

class CPsdModuleApp : public CWinApp
{
public:
	CPsdModuleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPsdModuleApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CPsdModuleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


// ����ģ��汾
#define	MODULE_BUILDID		15


// �ӿں������� �� ��һ�㣬Ψһ�������ϵ�Ľӿ�
int WINAPI AccessPSDModule(INFOSTR *pInfo);


// ������ͺ��� �� �ڶ�����ͺ���
void _fnCMD_GETPROCTYPE(INFOSTR *pInfo);
void _fnCMD_GETWRITERS(INFOSTR *pInfo);
void _fnCMD_GETWRITERMESS(INFOSTR *pInfo);
void _fnCMD_GETBUILDID(INFOSTR *pInfo);
void _fnCMD_IS_VALID_FILE(INFOSTR *pInfo);
void _fnCMD_GET_FILE_INFO(INFOSTR *pInfo);
void _fnCMD_LOAD_FROM_FILE(INFOSTR *pInfo);
void _fnCMD_SAVE_TO_FILE(INFOSTR *pInfo);
void _fnCMD_IS_SUPPORT(INFOSTR *pInfo);
void _fnCMD_RESIZE(INFOSTR *pInfo);

// �ڲ�ִ�к��� - ������ִ�к���.....

int ReadFormPSDFile(CFile& file, LPINFOSTR pInfo);
int	IsSupportFormat( WORD ColorMode, WORD ColorPixel ) ;

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PSDMODULE_H__C03B0EB5_460A_11D4_8853_C6A14464AE19__INCLUDED_)
