// IRWERegTabFunction.h - ͼ���д����ϵͳע������ֺ���ԭ�Ͷ����ļ�
//

#ifndef __IRWE_REGTAB_FUNCTION_INC__
#define __IRWE_REGTAB_FUNCTION_INC__


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IRWERegTabFunction.h : header file
//

HKEY	_IRWERTF_OpenRegTab(void);
HKEY	_IRWERTF_CreateRegTab(void);
LONG	_IRWERTF_CloseRegTab(HKEY hKey);
DWORD	_IRWERTF_GetPluginNumber(HKEY hKey);
DWORD	_IRWERTF_SetPluginNumber(HKEY hKey, DWORD dwNewNum);
LPTSTR	_IRWERTF_GetPluginNames(HKEY hKey);
LPCTSTR _IRWERTF_SetPluginNames(HKEY hKey, LPCTSTR lpNewNames);
LPTSTR	_IRWERTF_GetPluginsPath(HKEY hKey);
LPCTSTR _IRWERTF_SetPluginsPath(HKEY hKey, LPCTSTR lpNewPath);

LONG	_IRWERTF_CloseKey(HKEY hKey);

HKEY	_IRWERTF_OpenPlugins(HKEY hKey, LPCTSTR PluginsName);
HKEY	_IRWERTF_CreatePlugins(HKEY hKey, LPCTSTR PluginsName);
LPTSTR	_IRWERTF_GetPluginsFileName(HKEY hPlugKey);
LPCTSTR _IRWERTF_SetPluginsFileName(HKEY hPlugKey, LPCTSTR lpNewFileName);
DWORD	_IRWERTF_GetPluginPRI(HKEY hPlugKey);
DWORD	_IRWERTF_SetPluginPRI(HKEY hPlugKey, DWORD dwNewPRI);


#endif /*__IRWE_REGTAB_FUNCTION_INC__*/
