// SetupDlg.h : header file
//

#if !defined(AFX_SETUPDLG_H__533F2566_BA34_11D4_8853_444553540000__INCLUDED_)
#define AFX_SETUPDLG_H__533F2566_BA34_11D4_8853_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSetupDlg dialog

class CSetupDlg : public CDialog
{
// Construction
public:
	CSetupDlg(CWnd* pParent = NULL);	// standard constructor

	struct FindInfo
	{
		BYTE	m_FileName[MAX_PATH];
		BYTE	m_DesFile[MAX_PATH];
		BYTE	m_SouFile[MAX_PATH];
	};

// Dialog Data
	//{{AFX_DATA(CSetupDlg)
	enum { IDD = IDD_SETUP_DIALOG };
	CButton	m_OK;
	CStatic	m_Opr;
	CEdit	m_Edit;
	CButton	m_Dir;
	CProgressCtrl	m_Progress;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetupDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Attrib
	BYTE	m_FinPath[MAX_PATH];
	BYTE	m_SouPath[MAX_PATH];
	BYTE	m_DesPath[MAX_PATH];

	int			m_FineCount;
	FindInfo	m_FindInfo[256];

	HKEY	m_hKey;		//	����ܾ��
	BOOL	m_RegMark;
	CString	m_RegNameSpace;
	DWORD	m_RegNameCount;
	CString	m_RegPluginsPath;

// Implementation
protected:
	BOOL CopyIRWFile(LPCTSTR desfn, LPCTSTR soufn, LPCTSTR fn);
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSetupDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDir();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETUPDLG_H__533F2566_BA34_11D4_8853_444553540000__INCLUDED_)
