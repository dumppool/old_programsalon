// SetupDlg.cpp : implementation file
//

#include "stdafx.h"
#include <shlobj.h>

#include "..\public\gol_isee.h"
#include "Setup.h"
#include "SetupDlg.h"
#include "IRWERegTabFunction.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetupDlg dialog

CSetupDlg::CSetupDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetupDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetupDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSetupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetupDlg)
	DDX_Control(pDX, IDOK, m_OK);
	DDX_Control(pDX, IDC_OPR, m_Opr);
	DDX_Control(pDX, IDC_EDIT, m_Edit);
	DDX_Control(pDX, IDC_DIR, m_Dir);
	DDX_Control(pDX, ID_PROGRESS, m_Progress);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSetupDlg, CDialog)
	//{{AFX_MSG_MAP(CSetupDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_DIR, OnDir)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetupDlg message handlers

BOOL CSetupDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	m_RegNameSpace.Empty();
	m_RegPluginsPath.Empty();
	m_RegNameCount = 0;

	LPTSTR pbuf;

	HKEY hKey = _IRWERTF_OpenRegTab();
	if (hKey)
	{	// ˵���û���ϵͳ�Ѱ�װ��ĳЩ�������ȡ���ǵ���Ϣ
		m_RegMark = TRUE;

		m_RegNameCount = _IRWERTF_GetPluginNumber(hKey);
		pbuf = _IRWERTF_GetPluginNames(hKey);
		m_RegNameSpace = pbuf;
		::GlobalFree(pbuf);

		pbuf = _IRWERTF_GetPluginsPath(hKey);
		m_RegPluginsPath = pbuf;
		::GlobalFree(pbuf);

		_IRWERTF_CloseKey(hKey);

		m_Edit.SetWindowText((LPCTSTR)m_RegPluginsPath);
		m_Edit.EnableWindow(FALSE);
		m_Dir.EnableWindow(FALSE);
	}
	else
	{
		m_RegMark = FALSE;

		m_Edit.SetWindowText((LPCTSTR)"C:\\Program Files\\ISee\\ISee Explorer\\");
	}
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSetupDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSetupDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSetupDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSetupDlg::OnDir() 
{
	char  caSubPathName[_MAX_PATH];
	char  caFullPathName[_MAX_PATH];  
	BROWSEINFO brFolder;  

	brFolder.hwndOwner = this->m_hWnd;  
	brFolder.pidlRoot = NULL;  
	brFolder.pszDisplayName = caSubPathName;  
	brFolder.lpszTitle = "��ѡ��һ����װĿ¼�������ԭ����ISeeĿ¼����";  
	brFolder.ulFlags = BIF_RETURNONLYFSDIRS ;  
	brFolder.lpfn = NULL;  

	if (::SHGetPathFromIDList(::SHBrowseForFolder(&brFolder), caFullPathName))
	{
		if (caFullPathName[::strlen((const char*)caFullPathName)-1] != '\\')
			::strcat((char*)caFullPathName, (const char*)"\\");

		m_Edit.SetWindowText((LPCTSTR)caFullPathName);
	}
}

void CSetupDlg::OnOK() 
{
	m_Opr.SetWindowText((LPCTSTR)"�����ռ���װ��Ϣ...");

	// ��ȡԴĿ¼
	::GetCurrentDirectory(MAX_PATH, (LPTSTR)m_SouPath);
	if (m_SouPath[::strlen((const char*)m_SouPath)-1] != '\\')
		::strcat((char*)m_SouPath, (const char*)"\\");

	::strcpy((char*)m_FinPath, (const char*)m_SouPath);
	::strcat((char*)m_FinPath, (const char*)"*.irw");

	// ��ȡĿ��·��
	m_Edit.GetWindowText((LPTSTR)m_DesPath, MAX_PATH);
	if (m_RegMark == FALSE)
	{
		::strcat((char*)m_DesPath, (const char*)"IRW-PlugIn\\");
		m_RegPluginsPath = m_DesPath;
	}

	// У��Ŀ��·���Ƿ��Ѿ����ڣ�����������򴴽�Ŀ¼
	if (!::SetCurrentDirectory((LPCTSTR)m_DesPath))
	{
		if (!::CreateDirectory((LPCTSTR)m_DesPath, (LPSECURITY_ATTRIBUTES)NULL))
		{
			::AfxMessageBox((LPCTSTR)"�޷�����ָ����Ŀ¼�´���\"IRW-PlugIn\"��Ŀ¼����������ϵͳ�����Ƿ����������Ժ����ԡ�");
			CDialog::OnOK();
			return;
		}
	}

	WIN32_FIND_DATA	file;
	HANDLE			hFind;

	m_FineCount = 0;

	hFind = ::FindFirstFile((LPCTSTR)m_FinPath, &file);

	if (INVALID_HANDLE_VALUE == hFind)
	{
		::AfxMessageBox((LPCTSTR)"ϵͳ�����޷���������ѭ�����ڵ�ǰĿ¼���Ҳ���.irw�ļ�������������ԡ�");
		CDialog::OnOK();
		return;
	}

	do
	{
		::strcpy((char*)(m_FindInfo[m_FineCount].m_FileName), (char*)(file.cFileName)); 
		::strcpy((char*)(m_FindInfo[m_FineCount].m_SouFile), (char*)m_SouPath);
		::strcat((char*)(m_FindInfo[m_FineCount].m_SouFile), (char*)(file.cFileName));
		::strcpy((char*)(m_FindInfo[m_FineCount].m_DesFile), (char*)m_DesPath);
		::strcat((char*)(m_FindInfo[m_FineCount].m_DesFile), (char*)(file.cFileName));
		m_FineCount++;
	}while(::FindNextFile(hFind, &file));

	::FindClose(hFind);

	m_Progress.SetRange(0, m_FineCount);
	m_Progress.SetPos(0);

	BYTE tmpbuf[MAX_PATH];

	if (m_RegMark == FALSE)	
		m_hKey = _IRWERTF_CreateRegTab();
	else
		m_hKey = _IRWERTF_OpenRegTab();

	for (int i=0;i<m_FineCount;i++)
	{
		::sprintf((char*)tmpbuf, (const char*)"���ڸ���%s��Ŀ��Ŀ¼...", (char*)(m_FindInfo[i].m_FileName));
		m_Opr.SetWindowText((LPCTSTR)tmpbuf);

		if (!CopyIRWFile((LPCTSTR)(m_FindInfo[i].m_DesFile), (LPCTSTR)(m_FindInfo[i].m_SouFile), (LPCTSTR)(m_FindInfo[i].m_FileName)))
		{
			::AfxMessageBox((LPCTSTR)"�����ļ��Ĺ����з���������������ԡ�");
			_IRWERTF_CloseKey(m_hKey);
			CDialog::OnOK();
			return;
		}
		m_Progress.SetPos(i+1);
	}

	_IRWERTF_SetPluginNumber(m_hKey, m_RegNameCount);
	_IRWERTF_SetPluginNames(m_hKey, (LPCTSTR)m_RegNameSpace);
	_IRWERTF_SetPluginsPath(m_hKey, (LPCTSTR)m_RegPluginsPath);

	_IRWERTF_CloseKey(m_hKey);

	::AfxMessageBox((LPCTSTR)"��ϲ����ϲ����װ�ɹ���");

	CDialog::OnOK();
}

BOOL CSetupDlg::CopyIRWFile(LPCTSTR desfn, LPCTSTR soufn, LPCTSTR fn)
{
	CFile	df;
	CFile	sf;
	PBYTE	pbuf;
	HKEY	hKey;
	LPPLUGSIN pluginfo;

	if (!df.Open(desfn, CFile::modeCreate|CFile::modeWrite|CFile::shareDenyNone|CFile::typeBinary))
		return FALSE;	// �޷�����Ŀ���ļ�

	if (!sf.Open(soufn, CFile::modeRead|CFile::shareDenyNone|CFile::typeBinary))
	{
		df.Close();
		return FALSE;	// �޷���Դ�ļ�
	}

	DWORD len = sf.GetLength();

	pbuf = (PBYTE)::GlobalAlloc(GPTR, sf.GetLength());
	if (!pbuf)
	{
		df.Close();
		sf.Close();
		return FALSE;
	}

	TRY
	{
		df.SeekToBegin();
		sf.SeekToBegin();

		LPTSTR ptmp = (LPTSTR)pbuf;
		DWORD  blocksize;

		for (DWORD l=0;l<len;l+=10240)
		{
			blocksize = ((l+10240)<len) ? 10240:(len-l);
			sf.Read((void*)ptmp, blocksize);
			df.Write((const void*)ptmp, blocksize);
			ptmp += blocksize;
		}

		pluginfo = (LPPLUGSIN)&(((PBYTE)pbuf)[sf.GetLength()-sizeof(PLUGSIN)]);

		hKey = NULL;

		if (m_RegNameSpace.Find((LPCTSTR)(pluginfo->modulename), 0) == -1)
		{	// �µĲ��
			if (m_RegNameCount)
				m_RegNameSpace += (LPCTSTR)" ";
			m_RegNameSpace += (LPCTSTR)(pluginfo->modulename);
			m_RegNameCount++;

			hKey = _IRWERTF_CreatePlugins(m_hKey, (LPCTSTR)(pluginfo->modulename));
			_IRWERTF_SetPluginsFileName(hKey, fn);
			_IRWERTF_SetPluginPRI(hKey, 30);	// 30Ϊ��ͨ���ȼ�
		}
		else
		{
			hKey = _IRWERTF_OpenPlugins(m_hKey, (LPCTSTR)(pluginfo->modulename));
			_IRWERTF_SetPluginsFileName(hKey, fn);
		}

		::RegCloseKey(hKey);

		sf.Close();
		df.Close();
	}
	CATCH(CFileException, e)
	{
		::GlobalFree(pbuf);
		df.Close();
		sf.Close();
		return FALSE;
	}
	END_CATCH

	::GlobalFree(pbuf);

	return TRUE;
}
