#if !defined(AFX_VIEWCTRLBAR_H__50CC4856_7CCF_4418_83E0_B15C23D70190__INCLUDED_)
#define AFX_VIEWCTRLBAR_H__50CC4856_7CCF_4418_83E0_B15C23D70190__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// viewctrlbar.h : header file
//

#include "cjcontrolbar.h"

/////////////////////////////////////////////////////////////////////////////
// CViewCtrlBar command target

class CViewCtrlBar : public CCJControlBar
{
	DECLARE_DYNCREATE(CViewCtrlBar)

	CViewCtrlBar();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
	CView * GetView();
	bool AddView( CRuntimeClass * pViewClass ,DWORD dwStyle=AFX_WS_DEFAULT_VIEW ,
				  CCreateContext * pContext=NULL  );
	virtual ~CViewCtrlBar();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewCtrlBar)
	//}}AFX_VIRTUAL

// Implementation
protected:
	CView * m_pView;

	// Generated message map functions
	//{{AFX_MSG(CViewCtrlBar)
	afx_msg void OnWindowPosChanged(WINDOWPOS FAR* lpwndpos);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VIEWCTRLBAR_H__50CC4856_7CCF_4418_83E0_B15C23D70190__INCLUDED_)
