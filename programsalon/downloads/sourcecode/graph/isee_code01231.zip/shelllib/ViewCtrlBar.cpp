// ViewCtrlBar.cpp : implementation file
//

#include "stdafx.h"
#include "include\viewctrlbar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewCtrlBar

IMPLEMENT_DYNCREATE(CViewCtrlBar, CCJControlBar)

CViewCtrlBar::CViewCtrlBar()
{
	m_pView = NULL;
}

CViewCtrlBar::~CViewCtrlBar()
{
}


BEGIN_MESSAGE_MAP(CViewCtrlBar, CCJControlBar)
	//{{AFX_MSG_MAP(CViewCtrlBar)
	ON_WM_WINDOWPOSCHANGED()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewCtrlBar message handlers

bool CViewCtrlBar::AddView(CRuntimeClass *pViewClass, DWORD dwStyle , CCreateContext *pContext )
{
#ifdef _DEBUG
	ASSERT_VALID(this);
	ASSERT(pViewClass != NULL);
	ASSERT(pViewClass->IsDerivedFrom(RUNTIME_CLASS(CWnd)));
	ASSERT(AfxIsValidAddress(pViewClass, sizeof(CRuntimeClass), FALSE));
#endif
	CCreateContext context;
	if (pContext == NULL)
		pContext = &context;
	
	CWnd* pWnd;
	TRY
	{
		pWnd = (CWnd*)pViewClass->CreateObject();
		if (pWnd == NULL)
			AfxThrowMemoryException();
	}
	CATCH_ALL(e)
	{
		TRACE0("Out of memory creating a view.\n");
		// Note: DELETE_EXCEPTION(e) not required
		return false;
	}
	END_CATCH_ALL
		
    ASSERT_KINDOF(CWnd, pWnd);
	ASSERT(pWnd->m_hWnd == NULL);       // not yet created
	
	CRect rect;
	// Create with the right size and position
	if (!pWnd->Create(NULL, NULL, dwStyle, rect, this, 0, pContext))
	{
		TRACE0("Warning: couldn't create client pane for view.\n");
		// pWnd will be cleaned up by PostNcDestroy
		return false;
	}
	if ( m_pView )
		delete m_pView;
	m_pView = (CView *)pWnd;
	return true;
}

void CViewCtrlBar::OnWindowPosChanged(WINDOWPOS FAR* lpwndpos) 
{
	if ( m_pView )
	{
		if (IsFloating())
			m_pView->MoveWindow( 5, 5, lpwndpos->cx-10, lpwndpos->cy-7 );
		else if (IsHorzDocked()) 
			m_pView->MoveWindow( 15 , 4 , lpwndpos->cx-25, lpwndpos->cy-17 );
		else
			m_pView->MoveWindow( 4 , 16 , lpwndpos->cx-14, lpwndpos->cy-28 );
	}
	CCJControlBar::OnWindowPosChanged(lpwndpos);
}

CView * CViewCtrlBar::GetView()
{
	return m_pView;
}
