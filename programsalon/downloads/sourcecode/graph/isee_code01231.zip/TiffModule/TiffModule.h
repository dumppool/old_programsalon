// TiffModule.h : main header file for the TIFFMODULE DLL
//

#if !defined(AFX_TIFFMODULE_H__C03B0E85_460A_11D4_8853_C6A14464AE19__INCLUDED_)
#define AFX_TIFFMODULE_H__C03B0E85_460A_11D4_8853_C6A14464AE19__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "..\public\gol_isee.h"	// ���ļ������˽ӿ����ݰ�

/////////////////////////////////////////////////////////////////////////////
// CTiffModuleApp
// See TiffModule.cpp for the implementation of this class
//

class CTiffModuleApp : public CWinApp
{
public:
	CTiffModuleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTiffModuleApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CTiffModuleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


// ����ģ��汾
#define	MODULE_BUILDID		1


// �ӿں������� �� ��һ�㣬Ψһ�������ϵ�Ľӿ�
int WINAPI AccessTIFFModule(INFOSTR *pInfo);


// ������ͺ��� �� �ڶ�����ͺ���
void _fnCMD_GETPROCTYPE(INFOSTR *pInfo);
void _fnCMD_GETWRITERS(INFOSTR *pInfo);
void _fnCMD_GETWRITERMESS(INFOSTR *pInfo);
void _fnCMD_GETBUILDID(INFOSTR *pInfo);
void _fnCMD_IS_VALID_FILE(INFOSTR *pInfo);
void _fnCMD_GET_FILE_INFO(INFOSTR *pInfo);
void _fnCMD_LOAD_FROM_FILE(INFOSTR *pInfo);
void _fnCMD_SAVE_TO_FILE(INFOSTR *pInfo);
void _fnCMD_IS_SUPPORT(INFOSTR *pInfo);
void _fnCMD_RESIZE(INFOSTR *pInfo);

// �ڲ�ִ�к��� - ������ִ�к���.....


BOOL IsFileExist(char *lpFileName);



/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TIFFMODULE_H__C03B0E85_460A_11D4_8853_C6A14464AE19__INCLUDED_)
