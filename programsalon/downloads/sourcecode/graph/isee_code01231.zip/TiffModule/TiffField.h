//by xuhappy				2000-7-10
//˵��:���µĶ������Adobe��Tiff6.0��˵���ĵ�
//tiff �ļ�ͷ�ṹ

#define TIFF_MARKER1	0x4949
#define TIFF_MARKER2	0x4D4D


struct _tagTiffHeader{
	WORD wImageType;   //II or MM
	WORD wVersion;     //version should be 42
	LONG dwIFDOffset;  //the first IFD offset
};

typedef _tagTiffHeader	TIFFHEADER;




union _tagTiffOffOrVal{
	DWORD dwOffset;
	DWORD dwValue;
};

typedef _tagTiffOffOrVal TiffOffOrVal;



struct _tagTiffTag{
	WORD wTag;
	WORD wType;
	DWORD dwCount;
	TiffOffOrVal OffVal;
};

typedef _tagTiffTag TiffTag;



//tiff�ļ��ĸ�������Ƽ����Ӧ�ĳ���    (decimal)
#define NEWSUBFILETYPE					254
#define SUBFILETYPE						255
#define IMAGEWIDTH						256
#define IMAGELENGTH						257
#define BITSPERSAMPLE					258
#define COMPRESSION						259
#define PHOTOMETRICINTERPRETATION		262
#define THRESHHOLDING					263
#define CELLWIDTH						264
#define CELLLENGTH						265
#define FILLORDER						266
#define IMAGEDESCRIPTION				270
#define MAKE							271
#define MODEL							272
#define STRIPOFFSETS					273
#define ORIENTATION						274
#define SAMPLESPERPIXEL					277
#define ROWSPERSTRIP					278
#define STRIPBYTECOUNTS					279
#define MINSAMPLEVALUE					280
#define MAXSAMPLEVALUE					281
#define XRESOLUTION						282
#define YRESOLUTION						283
#define PLANARCONFIGURATION				284
#define FREEOFFSETS						288
#define FREEBYTECOUNT					289
#define GRAYRESPONSEUNIT				290
#define GRAYRESPONSECURVE				291
#define RESOLUTIONUNIT					296
#define SOFTWARE						305
#define DATETIME						306
#define ARTIST							315
#define HOSTCOMPUTER					316
#define COLORMAP						320
#define EXTRASAMPLE						338

#define COPYRIGHT						33432







