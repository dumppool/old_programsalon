#include "windows.h"
#define IDM_EXIT      2 
#define IDM_RUNLENGTH                   40056
#define IDM_JPEG                        40058
