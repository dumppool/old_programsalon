//---------------------------------------------------------------------------
#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <vcl\sysutils.hpp>
#include <vcl\windows.hpp>
#include <vcl\messages.hpp>
#include <vcl\sysutils.hpp>
#include <vcl\classes.hpp>
#include <vcl\graphics.hpp>
#include <vcl\controls.hpp>
#include <vcl\forms.hpp>
#include <vcl\dialogs.hpp>
#include <vcl\stdctrls.hpp>
#include <vcl\buttons.hpp>
#include <vcl\extctrls.hpp>
#include <vcl\menus.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <StdCtrls.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:   
  TImage *Image1;
  TEdit *Edit1;
  TLabel *Label1;
  TLabel *Label2;
  TEdit *Edit2;
  TLabel *Label3;
  TEdit *Edit3;
  TLabel *Label4;
  TEdit *Edit4;
  TEdit *Edit5;
  TLabel *Label5;
  TLabel *Label6;
  TLabel *Label7;
  TLabel *Label8;
  TButton *Reset;
  TButton *Zoom;
  TButton *Save;
  TLabel *STS;
  TLabel *Label9;
  TEdit *Edit6;
  TShape *Shape1;
  TButton *About;
  TButton *Exit;
  void __fastcall ResetClick(TObject *Sender);
  
  void __fastcall ZoomClick(TObject *Sender);
  
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall Image1MouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
  
  
  void __fastcall Image1MouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
  
  void __fastcall SaveClick(TObject *Sender);
  void __fastcall Image1MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
  void __fastcall ExitClick(TObject *Sender);
  void __fastcall AboutClick(TObject *Sender);
  void __fastcall FormPaint(TObject *Sender);
private:
  double x,y;
  double x0,y0,width;
  int detail;
  double x1,y1,width1;
  double ltx,lty,rbx,rby;
  int ltX,ltY;
  bool finish;
  bool mousedown;
      // private user declarations
public:         // public user declarations
	virtual __fastcall TMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif

