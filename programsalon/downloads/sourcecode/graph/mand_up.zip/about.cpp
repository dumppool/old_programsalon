//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "about.h"
//--------------------------------------------------------------------- 
#pragma resource "*.dfm"
TAboutBox *AboutBox;
//--------------------------------------------------------------------- 
__fastcall TAboutBox::TAboutBox(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------
void __fastcall TAboutBox::FormPaint(TObject *Sender)
{
int width=ClientWidth,h=ClientHeight;
for(int i=h;i>=0;i--)
  {
  Canvas->Pen->Color=RGB(i*255/h/10,i*255/h/20,i*255/h);
  Canvas->MoveTo(0,(h-i));
  Canvas->LineTo(width,(h-i));
  }
  
}
//---------------------------------------------------------------------------

