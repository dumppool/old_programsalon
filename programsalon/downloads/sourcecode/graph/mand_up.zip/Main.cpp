//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "Main.h"
#include "about.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
	: TForm(Owner)
{
}
//----------------------------------------------------------------------------

void __fastcall TMainForm::ResetClick(TObject *Sender)
{
x1=-2.5;
y1=-2;
width1=4.0;
ZoomClick(Reset);
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::ZoomClick(TObject *Sender)
{
int i,j;
int red,green,blue,times;
long double zx,zy,zxs,zys;
bool inset;
finish=false;
Reset->Enabled=false;
Zoom->Enabled=false;
Save->Enabled=false;
About->Enabled=false;
Exit->Enabled=false;
Shape1->Left=Image1->Left;
Shape1->Top=Image1->Top;
Shape1->Height=1;
Shape1->Width=1;
if(width1>0)
  {
  width=width1;
  x0=x1;
  y0=y1;
  detail=Edit3->Text.ToInt();
  Edit1->Text=x0;
  Edit2->Text=y0;
  Edit4->Text=(x0+width);
  Edit5->Text=(y0+width);
  Edit6->Text=4/width;
  for(i=0;i<400;i++)
    {
    x=x0+((double)i)*width/400.0;
    for(j=0;j<400;j++)
      {
      y=y0+((double)(400-j))*width/400.0;
      zx=0;
      zy=0;
      inset=true;
      times=0;
      while(inset&&times<detail)
        {
        times++;
        zxs=zx*zx;
        zys=zy*zy;
        zy=2*zx*zy+y;
        zx=zxs-zys+x;
        if(zxs+zys>=4.0)inset=false;
        }
      if(inset)
        {
        Image1->Canvas->Pixels[i][j]=RGB(0,0,0);
        }
      else
        {
        red=(times+100)%200+50;
        green=(times+red)%200+50;
        blue=(red+green)%200+50;
        Image1->Canvas->Pixels[i][j]=RGB(red,green,blue);
        }
      }
    Update();
    STS->Caption="Running..."+IntToStr(i)+"/400";
    }
  }
STS->Caption="Completed.";
Reset->Enabled=true;
Zoom->Enabled=true;
Save->Enabled=true;
About->Enabled=true;
Exit->Enabled=true;
finish=true;
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::FormCreate(TObject *Sender)
{
Image1->Canvas->Pen->Color=clBlack;
for(int i=0;i<400;i++)
  {
  Image1->Canvas->MoveTo(i,0);
  Image1->Canvas->LineTo(i,400);
  }
mousedown=false;
Zoom->Enabled=false;
Save->Enabled=false;

}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Image1MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
if(finish&&Button==mbLeft)
  {
  Shape1->Left=Image1->Left+X;
  Shape1->Top=Image1->Top+Y;
  Shape1->Height=1;
  Shape1->Width=1;
  ltX=X;
  ltY=Y;
  mousedown=true;
  ltx=x0+((double)X)*width/400.0;
  lty=y0+((double)(400-Y))*width/400.0;
  }
}
//---------------------------------------------------------------------------



void __fastcall TMainForm::Image1MouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
int Wide;
if(finish&&Button==mbLeft)
  {
  mousedown=false;
  rbx=x0+((double)X)*width/400.0;
  width1=rbx-ltx;
  rby=lty-width1;
  x1=ltx;
  y1=rby;
  Wide=X-ltX;
  Shape1->Height=Wide;
  Shape1->Width=Wide;
  Edit1->Text=x1;
  Edit2->Text=y1;
  Edit4->Text=x1+width1;
  Edit5->Text=y1+width1;
  }
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::SaveClick(TObject *Sender)
{
static int index;
AnsiString fn;
index++;
fn="mand-"+IntToStr(index)+".bmp";
Image1->Picture->SaveToFile(fn);
Application->MessageBox((fn+" saved.").c_str(),"���μ��εİ���",0);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Image1MouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
int Wide;
if(mousedown)
  {
  rbx=x0+((double)X)*width/400.0;
  width1=rbx-ltx;
  rby=lty-width1;
  x1=ltx;
  y1=rby;
  Wide=X-ltX;
  Shape1->Height=Wide;
  Shape1->Width=Wide;
  Shape1->Update();
  }
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ExitClick(TObject *Sender)
{
Close();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::AboutClick(TObject *Sender)
{
AboutBox->ShowModal();  
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::FormPaint(TObject *Sender)
{
int width=ClientWidth,h=ClientHeight;
for(int i=0;i<=h;i++)
  {
  Canvas->Pen->Color=RGB(i*255/h/10,i*255/h/20,i*255/h);
  Canvas->MoveTo(0,(h-i));
  Canvas->LineTo(width,(h-i));
  }
  
}
//---------------------------------------------------------------------------

