#include <malloc.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define _SCREEN_VAR

#include "e:\\wimg\\h\\image.h"
#include "e:\\wimg\\h\\imgfile.h"
#include "e:\\wimg\\h\\imgproc.h"
#include "e:\\wimg\\h\\utility.h"

imagedes  img;
imagedes  des;
void __busy(int percent)
{
  if(percent > 100)    printf("Busy \b\b\b\b\b");
  else if(percent<= 0) printf("Idle \b\b\b\b\b");
  else                 printf("%3d%% \b\b\b\b\b", percent);
}            

int main(int argc, char **argv)
{
  int tmp;
  char ifname[257];
  char ofname[257];
  char ext[4];
  BOOL csplit;
  BOOL togray;
  BOOL to256;
  
  ifname[0]=0;
  ofname[0]=0;
  ext[0] = 0;
  csplit=FALSE;
  togray=FALSE;
  to256=FALSE;
  fputs("Image File Format Converter Version 1.0a\n"
        "Released 05/25/1999, Yang YuDong.\n"
        "   yangyd@yahoo.com\n"
	    "   http://pcvideo.yeah.net\n", stderr);
  for(tmp=1; tmp <argc; tmp++)
    if(argv[tmp][0] != '/' && argv[tmp][0] != '-')
      if(!*ifname)  strcpy(ifname, argv[tmp]);
      else strcpy(ofname, argv[tmp]);
    else 
      switch (argv[tmp][1]){
       case '?' :
         fputs("Usage :  Img2Img infilename [outfilename] [options]\n", stderr);
         fputs("Options :  \n", stderr);
         fputs("      /? : command line help\n", stderr);
         fputs("      /S : split true color image to  r, g, b (defalut no) \n", stderr);
         fputs("      /G : force converting to gray scale (defalut no) \n", stderr);
         fputs("      /P : force converting to 256 color (defalut no) \n", stderr);
         fputs("   /Xext : Specify the destination image type by extension\n", stderr);
         fputs("           ext = RAW TIF BMP JPG TGA", stderr);
         return 0;
       case 'x' :
       case 'X' :
         strncpy(ext, argv[tmp]+2, 3);
         ext[3]=0;
         break;
       case 's' :
       case 'S' :
         csplit=TRUE;
         break;
       case 'g' :
       case 'G' :
         togray=TRUE;
         break;
       case 'p' :
       case 'P' :
         to256=TRUE;
         break;
       default :
           fputs("Unknown option :", stderr); fputs(argv[tmp], stderr); fputs("\n", stderr);
           return 0;
     }
  if(!*ifname){
    fputs("Use: 'Img2Img /?' for help\n", stderr);
    return 0;
  }
  if(!*ofname) strcpy(ofname, ifname);
  
  if(ext[0]) replace_extension(ofname, ext);

  des.alloc=img.alloc=FALSE;
  if(!Loadfile_on_extension(ifname, &img, -1, -1)) {
    fprintf(stderr, "Error: unable to load image '%s'\n", ifname);
    return 0;
  }
  if(csplit && img.imagetype == TrueColor) {
    des.alloc = des.load = TRUE;
    des.imagetype = Grey; des.xsize = img.xsize; des.ysize = img.ysize;
    des.r = img.r;
    replace_extension(ofname, "R");
    SaveRawGrey(ofname, des);
    des.r = img.g;
    replace_extension(ofname, "G");
    SaveRawGrey(ofname, des);
    des.r = img.b;
    replace_extension(ofname, "B");
    SaveRawGrey(ofname, des);
    des.alloc = FALSE;
    goto img_done;
  }
  else if(togray  && img.imagetype != Gray) img_color2grey(&img);
  else if(to256 && img.imagetype == TrueColor)
    if(img_color24to8(&des, img, 256, 0)) { FreePicture(&img); img=des; }  
    else { 
      fprintf(stderr, "Error: unable to convert image '%s'\n", ifname);
      return 0;
    }
  if(!Savefile_on_extension(ofname, img)) {
    FreePicture(&des);
    FreePicture(&img);
    fprintf(stderr, "Error: unable to save image '%s'\n", ofname);
    return 0;
  }
img_done:
  FreePicture(&img);
  printf("Done %s\n", ofname);
  return 1;
}
