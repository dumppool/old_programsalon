#include <malloc.h>
#include <string.h>
#include <stdio.h>

#include "image.h"
#include "display.h"
#include "menu.h"
#define _VARDEF
#include "modelist.h"
#undef _VARDEF


int vmodelist[VMODE_NUM];
 
int register_all_video_mode(void) 
{
    int i,j;
    
    vmodelist[v320x200x256  -v320x200x256] = m_video_register(320, 200, 8);
    vmodelist[v320x240x256  -v320x200x256] = m_video_register(320, 240, 8);
    vmodelist[v640x350x256  -v320x200x256] = m_video_register(640, 350, 8);
    vmodelist[v640x400x256  -v320x200x256] = m_video_register(640, 400, 8);
    vmodelist[v640x480x256  -v320x200x256] = m_video_register(640, 480, 8);
    vmodelist[v800x600x256  -v320x200x256] = m_video_register(800, 600, 8);
    vmodelist[v1024x768x256 -v320x200x256] = m_video_register(1024,768, 8);

    vmodelist[v320x200x32k  -v320x200x256] = m_video_register(320, 200, 15);
    vmodelist[v320x240x32k  -v320x200x256] = m_video_register(320, 240, 15);
    vmodelist[v640x350x32k  -v320x200x256] = m_video_register(640, 350, 15);
    vmodelist[v640x400x32k  -v320x200x256] = m_video_register(640, 400, 15);
    vmodelist[v640x480x32k  -v320x200x256] = m_video_register(640, 480, 15);
    vmodelist[v800x600x32k  -v320x200x256] = m_video_register(800, 600, 15);
    vmodelist[v1024x768x32k -v320x200x256] = m_video_register(1024,768, 15);

    vmodelist[v320x200x64k  -v320x200x256] = m_video_register(320, 200, 16);
    vmodelist[v320x240x64k  -v320x200x256] = m_video_register(320, 240, 16);
    vmodelist[v640x350x64k  -v320x200x256] = m_video_register(640, 350, 16);
    vmodelist[v640x400x64k  -v320x200x256] = m_video_register(640, 400, 16);
    vmodelist[v640x480x64k  -v320x200x256] = m_video_register(640, 480, 16);
    vmodelist[v800x600x64k  -v320x200x256] = m_video_register(800, 600, 16);
    vmodelist[v1024x768x64k -v320x200x256] = m_video_register(1024,768, 16);

    vmodelist[v320x200x16m  -v320x200x256] = m_video_register(320, 200, 24);
    vmodelist[v320x240x16m  -v320x200x256] = m_video_register(320, 240, 24);
    vmodelist[v640x350x16m  -v320x200x256] = m_video_register(640, 350, 24);
    vmodelist[v640x400x16m  -v320x200x256] = m_video_register(640, 400, 24);
    vmodelist[v640x480x16m  -v320x200x256] = m_video_register(640, 480, 24);
    vmodelist[v800x600x16m  -v320x200x256] = m_video_register(800, 600, 24);
    vmodelist[v1024x768x16m -v320x200x256] = m_video_register(1024,768, 24);
    for(i=0, j=0; i<VMODE_NUM; i++) if(vmodelist[i]) j++; 
    return j;
}  
