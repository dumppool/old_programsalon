#include "testlib.h"

#include "modelist.h"

imagedes img, dup;

int currentmode;

int mmframe=6;
int glbwin = -1;
char start_path[256];

char *progname = "RainMan Release 1.31a";

int callback1(int);

void *_globalBuf=NULL;

extern BOOL _videoLinear;

extern choisetype  helpchoise[];
extern menutype    helpmenu;

char *initall()
{
   helpchoise[2].menu = &helpmenu;  // for fun

   _videoLinear = TRUE;
   register_all_video_mode();
   img.alloc = FALSE;
   dup.alloc = FALSE;
   _globalBuf = malloc(256*1024);    // a 256KByte global buffer
   if(_globalBuf == NULL) return "Out of memory";
   if(menuinit(mmframe)) {
     free(_globalBuf);
     return "Menu System Failed !\n";
   }
   glbwin=open_window(" System Console ", 1, 0, 
                      scrymax-2, scrxmax-1, 0x1f, 0x17);
                      
   return NULL;
}

BOOL deinitall()
{
   if (dup.alloc) FreePicture(&dup);
   if (img.alloc) FreePicture(&img);
   if(_globalBuf != NULL)  free(_globalBuf);
   menuexit();
   if(glbwin >= 0) close_window(glbwin);
   crt_cls(scrymax-1,0, scrymax-1, scrxmax-1, 0x07);
   return TRUE;
}

void __busy(int bsy) {
  menu_busy(bsy);
}

void main(int argc, char *argv[])
{
   extern menutype mainmenu;
   char *msg;
   
 
   fputs(progname, stderr);   fputs("\n", stderr);
   fputs("Released May/25/1999, Yang YuDong.\n"
        "    yangyd@yahoo.com\n"
        "    http://pcvideo.yeah.net\n", stderr);
   
   if(argc > 1) {
     if(argv[1][0] == '/' && argv[1][1] >= '0' && argv[1][1] <= '6' ) mmframe = argv[1][1] - '0';
     else  {
       fputs("Unrecognized option: '", stderr);
       fputs(argv[1], stderr);
       fputs("'\nAccepted commond line options are: \n  /n n=0 to 6 menu fashon.\n",stderr);
       return;
     }
   } 
   fputs("System is being initialized, please wait...\n", stderr);
   fflush(stderr);
   strcpy(start_path, argv[0]);
   {
    int i;
    i = strlen(start_path)-1;
    while(i>=0 && start_path[i] != '\\')  start_path[i--]=0;
   }
   
   if((msg=initall())!= NULL) {
       fputs("Failed to start program : ", stderr);
       fputs(msg, stderr);
       fputs("\n", stderr);
       exit(-1);
   }
   { int i;
     for(i=0; i<scrymax-1; i++) win_printf(glbwin, 0x17, "\n");
     win_printf(glbwin, 0x2e, " %s ", progname);
     win_printf(glbwin, 0x1a, " is an free image processing tool\n");
     win_printf(glbwin, 0x17, " by ");
     win_printf(glbwin, 0x1c, "Yang Yudong");
     win_printf(glbwin, 0x17, ", 1999\n\n");
                         
     win_printf(glbwin, 0x17, " This is a free software. You are encouraged to\n" 
                           " distribute it freely. Please report bugs to \n");
     win_printf(glbwin, 0x1c, "    yangyd@yahoo.com\n");
     win_printf(glbwin, 0x1c, "    http://pcvideo.yeah.net\n");
     win_printf(glbwin, 0x19, " JPEG file I/O are using Independent JPEG Group's free software library\n"
                           " which is Copyright (C) 1994-1995, Thomas G. Lane.\n");
     win_printf(glbwin, 0x4f, " * Any modification to this program is NOT allowed ! \n");
     win_printf(glbwin, 0x17, "\nSystem Ready.");
   }

   domenu(&mainmenu, 0,0, callback1); 
   deinitall();
}
