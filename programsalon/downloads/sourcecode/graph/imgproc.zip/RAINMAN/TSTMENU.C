#include "menu.h"
#include "message1.h"


extern menutype  procmenu;

choisetype loadchoise[] =
   {
        {"Load &BMP 24/8 bits    ", idmload_bmp24, 0, "Load Windows BMP 24 or 8 bits image file"},
        {"Load &TIFF 24 bits   ", idmload_tif24, 0, "Load TIFF 24 bits image file"},
        {"Load T&argar 24 bits  ", idmload_tga24, 0, "Load Targar 24 bits image file"},
        {"Load &JPEG TrueColor/Gray ", idmload_jpeg, 0, "Load JPEG image file"},
        {"Load &PCX 8 bits  ", idmload_pcx8, 0,    "Load PCX 8 bits image file"},
        {"Load &Grey Scale Raw ", idmload_raw,   0, "Load Grey Scale Raw 8 bits image file"},
        MNULL
   };
menutype  loadmenu = {mvertical|mframe|mshadow, loadchoise, 0,0};

choisetype savechoise[] =
   {
        {"Save &BMP 24 bits    ", idmsave_bmp24, 0, "Save Windows BMP 24 bits image file"},
        {"Save B&MP 8 bits    ", idmsave_bmp8, 0, "Save Windows BMP 8 bits image file"},
        {"Save &TIFF 24 bits   ", idmsave_tif24, 0, "Save TIFF 24 bits image file"},
        {"Save &JPEG TrueColor/Gray ", idmsave_jpeg, 0, "Save JPEG image file"},
        {"Save T&argar 24 bits  ", idmsave_tga24, 0, "Save Targar 24 bits image file"},
        {"Save &PCX 8 bits    ", idmsave_pcx8, 0, "Save PCX 8 bits image file"},
        {"Save &Grey Scale Raw ", idmsave_raw,   0, "Save Grey Scale Raw 8 bits image file"},
        {"Save Grey Scale AS&CII ", idmsave_raw_ascii,   0, "Save Grey Scale ASCII image file"},
        MNULL
   };
menutype  savemenu = {mvertical|mframe|mshadow, savechoise, 0,0};

choisetype filechoise[] =
    {
        {"&Load        ", idmload,      &loadmenu, "Load Image..."},
        {"&Save        ", idmsave,      &savemenu, "Save Image..."},
        {"&Dos Shell... ", idmdos_shell, 0,         "Goto DOS prompt..."},
        {"E&xit         ", idmexit,      0,         "Say Bye Bye and Exit "},
        MNULL
    };
menutype  filemenu = {mvertical|mframe|mshadow, filechoise, 0,0};

choisetype transchoise[] =
   {
        {"Ro&tate 90 CCW", idmrot90ccw, 0,  "Rotate image 90 degree Counter Clockwise"},
        {"R&otate 90 CW",  idmrot90cw, 0,   "Rotate image 90 degree Clockwise"},
        {"&Rotate abitary angle", idmrotall, 0,  "Rotate image by any angle"},
        {"Rotate abitary angle &Fast", idmrotallfast, 0,  "Rotate image by any angle (Fast mode)"},
        {"Rotate abitary angle F&ine", idmrotallfine, 0,  "Rotate image by any angle (Fine mode)"},
        {"Re&sample", idmresample,     0,  "Resample Image"},
        {"R&esample Fast", idmresamplefast,     0,  "Resample Image (Fast mode)"},
        {"Res&ample Fine", idmresamplefine,     0,  "Resample Image (Fine mode)"},
        {"Flip &horizontal",  idmmirror, 0, "Flip image horizontally "},
        {"Flip &vertical",  idmflip, 0, "Flip image vertically "},
        MNULL
   };
menutype  transmenu = {mvertical|mframe|mshadow, transchoise, 0,0};

choisetype editchoise[] =
   {
        {"&Undo Process            ", idmundo,         0,  "Undo Process "},
        {"Convert to &Grey         ", idmconvert2grey, 0,  "Convert True Color to Grey Scale"},
        {"Convert to &Pseudo Color ", idmconvert2pseudocolor, 0,  "Convert True Color to Pseudo Color"},
        {"Convert to T&rue Color   ", idmconvert2color, 0,  "Convert image to True Color"},
        {"&Transform              ", idmtrans, &transmenu, "Transformation process ..."},
        MNULL
   };
menutype  editmenu = {mvertical|mframe|mshadow, editchoise, 0,0};

choisetype displaychoise[] =
   {
        {"Dis&play", idmdisplaya,  0,    "Display the full image ..."},
        {"Display &R", idmdisplayr,  0,  "Display Red of Image ..."},
        {"Display &G", idmdisplayg,  0,  "Display Green of Image ..."},
        {"Display &B", idmdisplayb,  0,  "Display Blue of Image ..."},
        MNULL
   };
menutype  displaymenu = {mvertical|mframe|mshadow, displaychoise, 0,0};

choisetype v256choise[] =
   {
        {"&1. 320x200  256 colors", idm320x200x256,  0,  "320x200 256 colos video display"},
        {"&2. 320x240  256 colors", idm320x240x256,  0,  "320x240 256 colos video display"},
        {"&3. 640x350  256 colors", idm640x350x256,  0,  "640x350 256 colos video display"},
        {"&4. 640x400  256 colors", idm640x400x256,  0,  "640x400 256 colos video display"},
        {"&5. 640x480  256 colors", idm640x480x256,  0,  "640x480 256 colos video display"},
        {"&6. 800x600  256 colors", idm800x600x256,  0,  "800x600 256 colos video display"},
        {"&7. 1024x768 256 colors", idm1024x768x256, 0,  "1024x768 256 colos video display"},
        MNULL
   };
menutype  v256menu = {mvertical|mframe|mshadow|mselect, v256choise, 0,0, 0,0};

choisetype v32kchoise[] =
   {
        {"&1. 320x200  32k colors", idm320x200x32k,  0,  "320x200 32k colos video display"},
        {"&2. 320x240  32k colors", idm320x240x32k,  0,  "320x240 32k colos video display"},
        {"&3. 640x350  32k colors", idm640x350x32k,  0,  "640x350 32k colos video display"},
        {"&4. 640x400  32k colors", idm640x400x32k,  0,  "640x400 32k colos video display"},
        {"&5. 640x480  32k colors", idm640x480x32k,  0,  "640x480 32k colos video display"},
        {"&6. 800x600  32k colors", idm800x600x32k,  0,  "800x600 32k colos video display"},
        {"&7. 1024x768 32k colors", idm1024x768x32k, 0,  "1024x768 32k colos video display"},
        MNULL
   };
menutype  v32kmenu = {mvertical|mframe|mshadow|mselect, v32kchoise, 0,0, 0,0};

choisetype v64kchoise[] =
   {
        {"&1. 320x200  64k colors", idm320x200x64k,  0,  "320x200 64k colos video display"},
        {"&2. 320x240  64k colors", idm320x240x64k,  0,  "320x240 64k colos video display"},
        {"&3. 640x350  64k colors", idm640x350x64k,  0,  "640x350 64k colos video display"},
        {"&4. 640x400  64k colors", idm640x400x64k,  0,  "640x400 64k colos video display"},
        {"&5. 640x480  64k colors", idm640x480x64k,  0,  "640x480 64k colos video display"},
        {"&6. 800x600  64k colors", idm800x600x64k,  0,  "800x600 64k colos video display"},
        {"&7. 1024x768 64k colors", idm1024x768x64k, 0,  "1024x768 64k colos video display"},
        MNULL
   };
menutype  v64kmenu = {mvertical|mframe|mshadow|mselect, v64kchoise, 0,0, 0,0};

choisetype v16mchoise[] =
   {
        {"&1. 320x200  16m colors", idm320x200x16m,  0,  "320x200 16m colos video display"},
        {"&2. 320x240  16m colors", idm320x240x16m,  0,  "320x240 16m colos video display"},
        {"&3. 640x350  16m colors", idm640x350x16m,  0,  "640x350 16m colos video display"},
        {"&4. 640x400  16m colors", idm640x400x16m,  0,  "640x400 16m colos video display"},
        {"&5. 640x480  16m colors", idm640x480x16m,  0,  "640x480 16m colos video display"},
        {"&6. 800x600  16m colors", idm800x600x16m,  0,  "800x600 16m colos video display"},
        {"&7. 1024x768 16m colors", idm1024x768x16m, 0,  "1024x768 16m colos video display"},
        MNULL
   };
menutype  v16mmenu = {mvertical|mframe|mshadow|mselect, v16mchoise, 0,0, 0,0};

choisetype dispoptchoise[] = 
   {
                {"&1. Auto Set",  idm_autodisplay, 0, "Automatically selection best mode ..."}, 
                {"&2. 256 Colors ", idm256color, &v256menu,     "256 color video modes ..."}, 
                {"&3. 32k Colors ", idm32kcolor, &v32kmenu,     "32k color video modes ..."}, 
                {"&4. 64k Colors ", idm64kcolor, &v64kmenu,     "64k color video modes ..."}, 
                {"&5. 16m Colors ", idm16mcolor, &v16mmenu,     "16m color video modes ..."}, 
                MNULL
   };
menutype  dispoptmenu = {mvertical|mframe|mshadow|mselect, dispoptchoise, 0,0, 0, 0};

choisetype optionschoise[] =
   {
        {"&Vertical menu style ", idmverticalmenu,  0, "Change main menu style to vertical layout"},
        {"Display as 256 &Color", idmconvertview,  0, "Convert full color images to 256 color to display"},
        {"&Enable undo             ", idmenableundo,   0,  "Enable Undo Process "},
        {"&Auto Show ", idmloadshow,  0, "Automatic display image when loaded"},
        {"&Beep when ready ", idmbeep,  0, "Beep when some routines are done"},
        {"&Display Resolution Option ", idmoptdisplay,  &dispoptmenu, "Video Display resolution selections..."},
        {"Enable &Linear Video Buffer", idmlinearvideo,  0, "Enable linear video buffer access display "},
        MNULL
   };
menutype  optionsmenu = {mvertical|mframe|mshadow, optionschoise, 0,0};

choisetype helpchoise[] =
   {
        {"A&bout",       idmabout,  0,  "About this program ..."},
        {"Abou&t tools", idmabout1, 0,  "About the tools used to build this program..."},
        {"Funny &link",  idmhelp,   0,  "Another link to Help menu for fun..."},
        MNULL
   };
menutype  helpmenu = {mvertical|mframe|mshadow, helpchoise, 0,0};


choisetype mainchoise[] =
    {
        {"&File",    idmfile,    &filemenu,   "File I/O, DOS shell, Exit ..."},
        {"&Edit",    idmedit,    &editmenu,   "Convert, Undo ..."},
        {"&Process", idmproc,    &procmenu,   "Image Process ..."},
        {"&Display", idmdisplay, &displaymenu,"Display Image"},
        {"&Options", idmoptions, &optionsmenu,"Options you can set ..."},
        {"&Help",    idmhelp,    &helpmenu,   "Help, about ..."},
        MNULL
    };
menutype  mainmenu = { mfullwidth, mainchoise, 0, 0};
