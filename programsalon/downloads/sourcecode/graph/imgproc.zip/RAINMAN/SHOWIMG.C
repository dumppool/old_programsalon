#include <malloc.h>
#include <string.h>
#include <stdio.h>

#include "testlib.h"
#include "modelist.h"
#include "showimg.h"


extern char *_globalBuf;

BOOL display_image(imagedes img, int mod, BOOL convert, BOOL viewer, char *title)
{
  int i, cur;
  char *mes[6];
  BOOL rtn, alloc;
  imagedes dis;
  
  if(!img.load) return FALSE;
  dis.alloc = FALSE;
  mes[0] = "# Display Image ";
  mes[1] = " ";
  mes[3] = " ";
  mes[4] = "@ OK ";
  mes[5] = 0;
  if(!mod) {
     for(i=v1024x768x16m; i>=v320x200x256; i--)
        if(mod = vmodelist[i-v320x200x256]) break;
     if(!mod) {
         mes[2] = "* Can not select video display mode !";
         dialogbox(mes);
         return FALSE;
     }
  }  

  cur=cursor(CURSOR_ON);
  if(!m_init_display(mod, TRUE, FALSE)) {
    reset_screen();
    cursor(cur);
    sprintf(_globalBuf, "* Video Error : %s ", m_get_video_error());
    mes[2] = _globalBuf;
    dialogbox(mes);
    //if(alloc) FreePicture(&dis);
    return FALSE;
  }  
  if(viewer) {
    m_settextcolor(255,255,0);
    m_setbkcolor(0,0,128);
    m_printf(0, _txtheight, 1, " Scroll: cursor keys   Zoom: mouse RButton   Exit ESC/LButton ");
    rtn = view_image(img, convert, title);
    m_close_display();
    reset_screen();
    cursor(cur);
    if(rtn) return TRUE;
    mes[2] = "* Failed to display image! ";
    dialogbox(mes);
    return FALSE;
  }
  // not viewer
  if(convert && img.imagetype == TrueColor) {
     alloc = img_color24to8(&dis, img, 254, 1);
     if(!alloc) {
         mes[2] = "* Can NOT render display image! ";
         dialogbox(mes);
         return FALSE;
     }
  }  
  else {
     dis = img;
     alloc = FALSE;
  }
  show_image(dis, 0,0, 0,0, dis.xsize, dis.ysize);
  if(alloc) FreePicture(&dis);
  return TRUE;
}      


