#include <stdio.h>
#include "menu.h"
#include "message2.h"


choisetype filterchoise[] = 
   {
        {"&Sharpen        ", idmsharpen,  0, "Sharpen an image "},
        {"&Gental Sharpen ", idmgsharpen, 0, "Gentally sharpen an image "},
        {"&Blur           ", idmlowpass,  0, "Blur an image "},
        {"Sobel &Edge     ", idmsobel,    0, "Sobel edge detection"},
        {"&Median Filter  ", idmmedian,   0, "Median filter"},
        {"M&ajority Filter  ", idmmajor,   0, "Majority filter"},
        MNULL
   };
menutype  filtermenu = {mvertical|mframe|mshadow, filterchoise};

choisetype adjustchoise[] = 
   {
        {"&Negtive       ",  idmnegtive,     0, "Negtive image "},
        {"&Contrast      ",  idmcontrast,    0, "Enhance contrast "},
        {"Histo &Linearize", idmhistoline,   0, "Histogram linearization "},
        {"Histo &Brighten ", idmhistobright, 0, "Histogram brighten "},
        {"&Saturation    ",  idmsaturation,  0, " Adjust color saturation"},
        MNULL
   };
menutype  adjustmenu = {mvertical|mframe|mshadow, adjustchoise};

choisetype specchoise[] = 
   {
        {"&Threshold ", idmthresh,  0, "Apply threshold to image"},
        {"&Mosiac    ", idmmosiac,  0, "Mosiac effect "},
        {"&Posterize ", idmquantiz, 0, "Posterize/Re-quantization "},
        {"&Art trace ", idmtraceart, 0, "Trace edge artically "},
        MNULL
   };
menutype  specmenu = {mvertical|mframe|mshadow, specchoise};

choisetype edgechoise[] = 
   {
        {"Test finder &1", idmedge1,  0, "Test edge finder 1"},
        {"Test finder &2", idmedge2,  0, "Test edge finder 2"},
        {"Test finder &3", idmedge3,  0, "Test edge finder 3"},
        {"&DOG finder",    idmedgedog, 0, "3X3 DOG and zero crossing "},
        MNULL
   };
menutype  edgemenu = {mvertical|mframe|mshadow, edgechoise};

choisetype binchoise[] = 
   {
        {"Area &Shrink", idmshrink,   0, "Area shrink "},
        {"Area &Expand", idmexpand,   0, "Area expand "},
        {"Eliminate &Noise", idmdenoise,   0, "Eliminate dot noise"},
        {"Edge &Thin  ", idmthin,     0, "Edge thinning "},
        {"Trace &4 conn", idmtrace4,  0, "Edge tracing by 4 connections "},
        {"Trace &8 conn", idmtrace8,  0, "Edge tracing by 8 connections "},
        NULL
   };
menutype  binmenu = {mvertical|mframe|mshadow, binchoise};

choisetype procchoise[] = 
   {
        {"&Filter Process        ", idmfilter,  &filtermenu,  "Filter/convolution process routines"},
        {"&Image Adjust          ", idmadjust,  &adjustmenu,  "Adjust image properties"},
        {"&Edge Detect           ", idmedge,    &edgemenu,    "Many edge finders "},
        {"&Special Effect        ", idmspecial, &specmenu,    "Special effect process routines"},
        {"&Binary Image Process  ", idmbinary,  &binmenu,     "Binary image process routines"},
        MNULL
   };
menutype  procmenu = {mvertical|mframe|mshadow, procchoise};


