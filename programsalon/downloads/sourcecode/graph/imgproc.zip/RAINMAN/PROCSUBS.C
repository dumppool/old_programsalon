#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <process.h>
//#include <graph.h>
#include <errno.h>
#include <string.h>

#include "testlib.h"

#include "message1.h"
#include "message2.h"

extern imagedes img;
extern BOOL _autoshow;
extern imagedes dup;
extern BOOL _undo;
extern BOOL _beep;

#define tstbeeper(a) if(_beep)beeper(a)

//void color_merge(imagedes * img);
//void test_bed(imagedes * img);
//void merge_test(imagedes * img);


int callback2(int mess)
{
  char *mes[10];
  
  mes[0] = "# Image Process ";
  mes[1] = " ";
  mes[3] = " ";
  mes[4] = "@ Ok ";
  mes[5] = 0;
  
  switch(mess) {
    case MENUINIT:
       break;
    case MENUCLOSE:
       return 0;
    case MENUREPAINT:
      if(img.load) {
        if(img.imagetype != Grey) reset_menu_status(idmsaturation, menu_grey);
        else set_menu_status(idmsaturation, menu_grey);
        if(img.imagetype != Color256) {
            reset_menu_status(idmfilter, menu_grey);
            reset_menu_status(idmedge, menu_grey);
            reset_menu_status(idmspecial, menu_grey);
            reset_menu_status(idmbinary, menu_grey);
            reset_menu_status(idmhistoline, menu_grey);
            reset_menu_status(idmhistobright, menu_grey);
        }    
        else {
            set_menu_status(idmfilter, menu_grey);
            set_menu_status(idmedge, menu_grey);
            set_menu_status(idmspecial, menu_grey);
            set_menu_status(idmbinary, menu_grey);
            set_menu_status(idmhistoline, menu_grey);
            set_menu_status(idmhistobright, menu_grey);
        }    
      }
      return menu_repaint; 

    case idmsharpen:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_sharpen(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do sharpen !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmgsharpen:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_gentlesharpen(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do gental sharpen !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmlowpass:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_lowpass(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do low pass filtering !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmsobel:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_sobel(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do Sobel filtering !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmmedian:
      {
       int t=getnumber("Median filter size (n*2+1) [1-20]:");
       if(t < 1 || t > 20) {
           tstbeeper(1);
           mes[2] = "* Value must between 1 to 20! ";
           dialogbox(mes);
           break;
        }
       menu_busy(999);
       if(_undo) img_newcopy(&dup, img);
       if(image_median(img, t)) {
          tstbeeper(2);
          if(_autoshow)  raise_message(idmdisplaya);
       }
       else {
          tstbeeper(3);
          mes[2] = "* Failed to do median filtering !";
          dialogbox(mes);
       }  
       menu_busy(0);
       break;
      }

    case idmmajor:
      {
       int t=getnumber("Majority fileter size (n*2+1) [1-20]:");
       if(t < 1 || t > 20) {
           tstbeeper(1);
           mes[2] = "* Value must between 1 to 20! ";
           dialogbox(mes);
           break;
        }
       menu_busy(999);
       if(_undo) img_newcopy(&dup, img);
       if(image_majority(img, t)) {
          tstbeeper(2);
          if(_autoshow)  raise_message(idmdisplaya);
       }
       else {
          tstbeeper(3);
          mes[2] = "* Failed to do majority filtering !";
          dialogbox(mes);
       }  
       menu_busy(0);
       break;
      }

    case idmnegtive:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      image_negative(img);
      tstbeeper(2);
      if(_autoshow)  raise_message(idmdisplaya);
      menu_busy(0);
      break;

    case idmhistoline:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_histolinearize(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do histogram linearizing !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmhistobright:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      image_histobrighten(img);
      tstbeeper(2);
      if(_autoshow)  raise_message(idmdisplaya);
      menu_busy(0);
      break;

    case idmcontrast:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      image_expandcontrast(img, 16, 240);
      tstbeeper(2);
      if(_autoshow)  raise_message(idmdisplaya);
      menu_busy(0);
      break;

    case idmsaturation:
      {
       int t=getnumber("Saturation alpha [-256 to 256]:");
       if(t < -256 || t > 256) {
           tstbeeper(1);
           mes[2] = "* Value must between -256 to 256! ";
           dialogbox(mes);
           break;
        }
       menu_busy(999);
       if(_undo) img_newcopy(&dup, img);
       image_saturation(img, t);
       tstbeeper(2);
       if(_autoshow)  raise_message(idmdisplaya);
       menu_busy(0);
       break;
      }

    case idmthresh:
      {
        int t = getnumber("Input a threshold (0-255):");
        if(t<0 || t>255) {
           tstbeeper(1);
           mes[2] = "* Value must between 0-255! ";
           dialogbox(mes);
           break;
        }
        menu_busy(999);
        if(_undo) img_newcopy(&dup, img);
        image_kodalithprocess(img, t);
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
        menu_busy(0);
        break;
      }

    case idmmosiac:
      {
        int t = getnumber("Input mosiac size (2--63):");
        if(t<2 || t>63) {
           tstbeeper(1);
           mes[2] = "* Value must between 2--63! ";
           dialogbox(mes);
           break;
        }
        menu_busy(999);
        if(_undo) img_newcopy(&dup, img);
        image_mosiac(img, t);
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
        menu_busy(0);
        break;
      }

    case idmquantiz:
      {
        int t = getnumber("Input quantization level (2--128):");
        if(t<2 || t>128) {
           tstbeeper(1);
           mes[2] = "* Value must between 2--128! ";
           dialogbox(mes);
           break;
        }
        menu_busy(999);
        if(_undo) img_newcopy(&dup, img);
        image_posterize(img, t);
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
        menu_busy(0);
        break;
      }

    case idmtraceart:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_trace_art(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do art tracing !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmshrink:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_shrink(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do area shrink !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmexpand:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_expand(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do area expand !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmthin:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_thinning(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do edge thinning !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmtrace4:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_bin_trace4(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do edge trace !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmtrace8:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_bin_trace8(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do edge trace !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmdenoise:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_denoise(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do noise reduction !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmedge1:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_testedge1(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do edge detection !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmedge2:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_testedge2(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do edge detection !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmedge3:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_testedge3(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do edge detection !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;

    case idmedgedog:
      menu_busy(999);
      if(_undo) img_newcopy(&dup, img);
      if(image_DOGedge(img)) {
        tstbeeper(2);
        if(_autoshow)  raise_message(idmdisplaya);
      }
      else {
        tstbeeper(3);
        mes[2] = "* Failed to do edge detection !";
        dialogbox(mes);
      }  
      menu_busy(0);
      break;
  }
  return(close_caller_menu);
}

