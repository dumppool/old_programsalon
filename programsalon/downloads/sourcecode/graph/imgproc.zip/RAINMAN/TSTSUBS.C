#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <process.h>
#include <errno.h>
#include <string.h>
#include <direct.h>

#include "testlib.h"

#include "modelist.h"
#include "message1.h"
#include "showimg.h"


extern imagedes img;
extern imagedes dup;
extern int currentmode;
extern char *progname;

BOOL _convert=FALSE;
extern BOOL _videoLinear;
BOOL _autoshow=TRUE;
BOOL _undo=TRUE;
BOOL _beep=FALSE;


#define tstbeeper(a) if(_beep)beeper(a)

BOOL _mLoadRawGrey(char *fname, imagedes *img)  // this give user a chance to specify a size
{
      int x, y, offset;
      tstbeeper(4);
      x=getnumber("Specify horizontal size (<=0 auto):");
      if(x > 0) { // load automatic
         tstbeeper(4);
         y=getnumber("Specify vertical size :");
         offset=getnumber("Specify header size to be skipped :");
      }
      if(x > 0)    return (LoadRawGreyWithHeader(fname, img, x, y, offset));
      else    return (LoadRawGrey(fname, img, x, y));
}

BOOL _mSaveJPEG(char *fname, imagedes img)  // this give user a chance to specify a size
{
      int quality;
      tstbeeper(4);
      quality=getnumber("Specify quality[1-99, default 75]:");
      if(quality <= 0 || quality >= 100) { // default
         quality = 75;
      }
      return (SaveJPEG(fname, img, quality));
}


BOOL __check_file(char * fname)
{
 FILE *fp;
 fp=fopen(fname,"r");
 if(fp==NULL) return FALSE;
 fclose(fp);
 return TRUE;
}


BOOL callfileiofunc(BOOL func(), char * mess, char * fileext,  BOOL load)
 {
   static char fname[256];
   static char cwd[256];
   char tmp[80];
   char * mes[10];
   mword * tmpsave;
   BOOL rtn;
   
   mes[0]=mess;
   mes[1]=" ";
   tmp[0] = '*'; tmp[1] = '.'; tmp[2] = 0; strcat(tmp, fileext);

   tstbeeper(4);
   if(!cwd[0]) getcwd(cwd, 256);
   if((getfilename(fname, fileext, "Input File Name : ") && (__check_file(fname)||!load ? 1 : !(strcpy(tmp, fname)))) || 
      dirsel(tmp, fname, load ? "[Open Image File]" : "[Save Image File]", 0) > 0) {
     if((tmpsave=malloc((long)scrxmax*2*2)) != NULL) { 
          crt_getblock(tmpsave, scrymax/2, 0, scrymax/2+1, scrxmax-1);
          putnotice(scrymax/2, mess , 0xbc);
     }
     menu_busy(999);
     if(load)
           rtn = func(fname, &img);
     else
           rtn = func(fname, img);
     if(rtn) getcwd(cwd, 256);  // current working directory is ok
     else chdir(cwd); 
     menu_busy(0);
     if(tmpsave != NULL) { 
          crt_putblock(tmpsave, scrymax/2, 0, scrymax/2+1, scrxmax-1);
          free(tmpsave);
     }
     if(!rtn) {
          sprintf(tmp, load ? "Error Reading File '%s' " : " Error Write File '%s' ", fname);
          mes[2]=tmp;
          mes[3]="@ OK ";
          mes[4]=0;
          tstbeeper(1);
          dialogbox(mes);
          return FALSE;
     }
     if(load && _autoshow)   raise_message(idmdisplaya);
     tstbeeper(2);
     return TRUE;
   }
   return FALSE;
}

void dos_shell(void)
{
 int err, cur;
 char *shellpath;
 char *mes[10];

 screen_controlbreak(1);        // control break process
 cur = cursor(CURSOR_INSERT);
 crt_cls(0,0,scrymax-1,scrxmax-1,0x07);
 crt_src(0,0);
 crt_puts(" Type \"EXIT\" to return. ", 0x1e);
 crt_src(1,0);
 fflush(stdin);
 fflush(stdout);
 fflush(stderr);
 shellpath=getenv("COMSPEC");
 err = spawnl(P_WAIT, shellpath, shellpath, NULL);
 screen_controlbreak(0);        // control break process
 reset_screen();
 cursor(cur);
 if (err == -1) {
   mes[0] = "# Running Dos Prompt ";
   mes[1] = " ";
   mes[3] = " ";
   mes[4] = "@ OK ";
   mes[5] = 0;
   switch (errno){
     case ENOENT :
           mes[2] = "* Command Interpreter not found ! ";
           tstbeeper(1);
           dialogbox(mes);
           break;
     case ENOMEM :
           mes[2] = "* Out of Memory ! ";
           tstbeeper(1);
           dialogbox(mes);
           break;
    }
  }
  else  tstbeeper(2);
}



int callback2(int mess);
BOOL deinitall();

int callback1(int mess)
{   char tbuf[40];
    int i;
    BOOL rtn;
    char *mes[10];
    extern menutype mainmenu;
  
    mes[0] = "# Image Process ";
    mes[1] = " ";
    mes[3] = " ";
    mes[4] = "@ Ok ";
    mes[5] = 0;
    
    switch(mess) {
          case MENUINIT:
            for(i=v320x200x256; i<=v1024x768x16m; i++) 
                if(!vmodelist[i-v320x200x256]) set_menu_status(idmvideomodes+i, menu_grey);
            reset_menu_status(idmlinearvideo, menu_checked);
            set_menu_status(idmloadshow,  menu_checked);
            reset_menu_status(idmconvertview, menu_checked);
            callback2(mess);
            break;
          case MENUCLOSE:
             callback2(mess);
             return 0;
          case MENUREPAINT:
            if(_undo) set_menu_status(idmenableundo, menu_checked);
            else reset_menu_status(idmenableundo, menu_checked);
            if(_beep) set_menu_status(idmbeep, menu_checked);
            else reset_menu_status(idmbeep, menu_checked);
            if(_videoLinear) set_menu_status(idmlinearvideo, menu_checked);
            else reset_menu_status(idmlinearvideo, menu_checked);
            if(dup.load && _undo)  reset_menu_status(idmundo, menu_grey);
            else          set_menu_status(idmundo, menu_grey);
            if(img.load) {
              sprintf(tbuf, " %dX%d %s ", img.xsize, img.ysize,
                      img.imagetype==TrueColor ? "TrueColor" :
                             (img.imagetype==Grey ? "GreyScale":
                                                    "PaletteColor"));
              reset_menu_status(idmsave, menu_grey);
              reset_menu_status(idmedit, menu_grey);
              
              if(img.imagetype != Grey) reset_menu_status(idmconvert2grey, menu_grey);
              else set_menu_status(idmconvert2grey, menu_grey);
              if(img.imagetype == TrueColor) {
                set_menu_status(idmconvert2color, menu_grey);
                reset_menu_status(idmconvert2pseudocolor, menu_grey);
                reset_menu_status(idmdisplayr, menu_grey);
                reset_menu_status(idmdisplayg, menu_grey);
                reset_menu_status(idmdisplayb, menu_grey);
              }
              else {
                reset_menu_status(idmconvert2color, menu_grey);
                set_menu_status(idmconvert2pseudocolor, menu_grey);
                set_menu_status(idmdisplayr, menu_grey);
                set_menu_status(idmdisplayg, menu_grey);
                set_menu_status(idmdisplayb, menu_grey);
              }
              reset_menu_status(idmdisplay, menu_grey);
              reset_menu_status(idmproc, menu_grey);
            }
            else {
              set_menu_status(idmsave, menu_grey);
              set_menu_status(idmedit, menu_grey);
              set_menu_status(idmdisplay, menu_grey);
              set_menu_status(idmproc, menu_grey);
              strcpy(tbuf, " No image in buffer ");
            }
            crt_src(scrymax-2, 1);
            crt_putsn(tbuf, 24, 0x3f);
            crt_src(scrymax-2, 30);
            crt_putsn(_undo ? " Undo Enabled  " : " Undo Disabled ", 15, _undo ? 0x2a: 0x28);
            crt_src(scrymax-2, 50);
            crt_putsn(_autoshow ? "  Auto Show  " : " No Auto Show ", 14, _autoshow ? 0x5b: 0x58);
            crt_src(scrymax-2, 69);
            crt_putsn(_beep ? " Beep it " : " No Beep ", 10, _beep ? 0x6e: 0x68);
            //crt_src(scrymax-2, scrxmax-20);
            //crt_putsn("Video Color Type", 25, 0x1c);
            callback2(mess);
            return 0; //menu_repaint; 
          case idmload_bmp24:
             rtn = callfileiofunc(LoadBMP, " Load Windows BMP 24 or 8 bits image file ", "BMP", TRUE);
             if(rtn) FreePicture(&dup);
             return(menu_repaint | refresh_screen | close_caller_menu);
          case idmload_jpeg:
             rtn = callfileiofunc(LoadJPEG, " Load JPEG image file ", "JPG", TRUE);
             if(rtn) FreePicture(&dup);
             return(menu_repaint | refresh_screen | close_caller_menu);
         case idmload_tif24:
             rtn = callfileiofunc(LoadTIFF24b, " Load TIFF 24 bits image file ", "TIF", TRUE);
             if(rtn) FreePicture(&dup);
             return(menu_repaint | close_caller_menu);
         case idmload_tga24:
             rtn = callfileiofunc(LoadTGA24b, " Load Targar 24 bits image file ", "TGA", TRUE);
             if(rtn) FreePicture(&dup);
             return(menu_repaint | close_caller_menu);
         case idmload_pcx8:
             rtn = callfileiofunc(LoadPCX8b, " Load PCX 8 bits image file ", "PCX", TRUE);
             if(rtn) FreePicture(&dup);
             return(menu_repaint | close_caller_menu);
         case idmload_raw:
             rtn = callfileiofunc(_mLoadRawGrey, " Load Grey scale RAW image file ", "RAW", TRUE);
             if(rtn) FreePicture(&dup);
             return(menu_repaint | close_caller_menu);
          case idmsave_bmp24:
             callfileiofunc(SaveBMP24b, " Save Windows BMP 24 bits image file ", "BMP", FALSE);
             return(close_caller_menu);
          case idmsave_bmp8:
             callfileiofunc(SaveBMP8b, " Save Windows BMP 8 bits image file ", "BMP", FALSE);
             return(close_caller_menu);
          case idmsave_tif24:
             callfileiofunc(SaveTIFF24b, " Save TIFF 24 bits image file ", "TIF", FALSE);
             return(close_caller_menu);
         case idmsave_tga24:
             callfileiofunc(SaveTGA24b, " Save Targar 24 bits image file ", "TGA", FALSE);
             return(menu_repaint | close_caller_menu);
          case idmsave_jpeg:
             callfileiofunc(_mSaveJPEG, " Save JPEG image file ", "JPG", FALSE);
             return(close_caller_menu);
          case idmsave_pcx8:
             callfileiofunc(SavePCX8b, " Save PCX 8 bits image file ", "PCX", FALSE);
             return(close_caller_menu);
          case idmsave_raw:
             callfileiofunc(SaveRawGrey, " Save Grey scale RAW image file ", "RAW", FALSE);
             return(close_caller_menu);
          case idmsave_raw_ascii:
             callfileiofunc(SaveRawASCII, " Save Grey scale RAW ASCII image file ", "ASC", FALSE);
             return(close_caller_menu);
          case idmdos_shell:
             dos_shell();
             return(refresh_screen | close_caller_menu);
          case idmexit:
             menu_busy(999);
             tstbeeper(3);
             deinitall();
             exit(0);
          case idmconvert2pseudocolor:
             {
                 int n;
                 imagedes tmp;
                 tmp.alloc = FALSE; 
                 n=getnumber("Input destination color numbers[1-256]:");
                 menu_busy(999);
                 if(n <= 256 && n >= 1) {
                    if(img_color24to8(&tmp, img, n, (256-n)/2)) {
                       if(_undo) {
                         FreePicture(&dup);
                         dup = img;
                       }
                       else FreePicture(&img);
                       img = tmp;
                       tstbeeper(2);
                       if(_autoshow)  raise_message(idmdisplaya);
                    }
                    else { 
                       tstbeeper(3);
                       mes[2] = "* Failed to do conversion !";
                       dialogbox(mes);
                    }  
                 }
                 else { 
                    tstbeeper(1);
                    mes[2] = "* Color number must be 1 to 256 !";
                    dialogbox(mes);
                 }
                 menu_busy(0);
                 return(menu_repaint | close_caller_menu);
             }

          case idmconvert2color:
             menu_busy(999);
             if(_undo) img_newcopy(&dup, img);
             if(img_to_color24(&img)) {
                tstbeeper(2);
                if(_autoshow)  raise_message(idmdisplaya);
             }
             else {
                tstbeeper(3);
                mes[2] = "* Failed to do conversion !";
                dialogbox(mes);
             }  
             menu_busy(0);
             return(menu_repaint | close_caller_menu);
          case idmconvert2grey:
             menu_busy(999);
             if(_undo) img_newcopy(&dup, img);
             if(img_color2grey(&img)) {
                tstbeeper(2);
                if(_autoshow)  raise_message(idmdisplaya);
             }
             else {
                tstbeeper(3);
                mes[2] = "* Failed to do conversion !";
                dialogbox(mes);
             }  
             menu_busy(0);
             return(menu_repaint | close_caller_menu);
          case idmundo:
             menu_busy(999);
             if(dup.load && dup.alloc) {
               FreePicture(&img);
               img=dup;
               dup.alloc = FALSE; dup.load = FALSE;
               tstbeeper(2);
               if(_autoshow)  raise_message(idmdisplaya);
             }
             else  tstbeeper(1);
             menu_busy(0);
             return(menu_repaint | close_caller_menu);
          case idmenableundo:
             if(_undo) {
               _undo = FALSE;
               reset_menu_status(idmenableundo, menu_checked);
               if(dup.alloc) FreePicture(&dup);
             }
             else {
               _undo = TRUE;
               set_menu_status(idmenableundo, menu_checked);
               if(dup.alloc) FreePicture(&dup);
             }   
             tstbeeper(2);
             menu_busy(0);
             return(menu_repaint | close_caller_menu);
          case idmbeep:
             if(_beep) {
               _beep = FALSE;
               reset_menu_status(idmbeep, menu_checked);
             }
             else {
               _beep = TRUE;
               set_menu_status(idmbeep, menu_checked);
             }   
             beeper(2);
             menu_busy(0);
             return(menu_repaint | close_caller_menu);

          case idmmirror:
             menu_busy(999);
             if(_undo) img_newcopy(&dup, img);
             image_mirror(img);
             if(_autoshow)  raise_message(idmdisplaya);
             tstbeeper(2);
             menu_busy(0);
             return(menu_repaint | close_caller_menu);
          case idmflip:
             menu_busy(999);
             if(_undo) img_newcopy(&dup, img);
             image_flip(img);
             if(_autoshow)  raise_message(idmdisplaya);
             tstbeeper(2);
             menu_busy(0);
             return(menu_repaint | close_caller_menu);
          case idmrot90ccw:
             menu_busy(999);
             if(_undo) img_newcopy(&dup, img);
             if(image_rotateccw90(&img)) {
                tstbeeper(2);
                if(_autoshow)  raise_message(idmdisplaya);
             }
             else {
                tstbeeper(3);
                mes[2] = "* Failed to do rotation !";
                dialogbox(mes);
             }  
             menu_busy(0);
             return(menu_repaint | close_caller_menu);
          case idmrot90cw:
             menu_busy(999);
             if(_undo) img_newcopy(&dup, img);
             if(image_rotatecw90(&img)) {
                tstbeeper(2);
                if(_autoshow)  raise_message(idmdisplaya);
             }
             else {
                tstbeeper(3);
                mes[2] = "* Failed to do rotation !";
                dialogbox(mes);
             }  
             menu_busy(0);
             return(menu_repaint | close_caller_menu);
          case idmresample:
          case idmresamplefast:
          case idmresamplefine:
           {
                 int x, y;
                 char buf[80];
                 BOOL rtn;
                 imagedes tmp;

                 tmp.alloc = FALSE; 
                 sprintf(buf, "Orignal size %dX%d,"
                         " New horizontal size:", img.xsize, img.ysize);
                 x=getnumber(buf);
                 if(x<=0) {tstbeeper(1); return(close_caller_menu);}
                 sprintf(buf, "Orignal size %dX%d,"
                         " New vertical size:", img.xsize, img.ysize);
                 y=getnumber(buf);
                 if(y<=0) {tstbeeper(1); return(close_caller_menu);}
                 menu_busy(999);
                 if(mess == idmresample) 
                    rtn = image_resample(&tmp, img, x, y, Interp_normal);
                 else if(mess == idmresamplefast)
                    rtn = image_resample(&tmp, img, x, y, Interp_fast);
                 else rtn = image_resample(&tmp, img, x, y, Interp_fine);
                 if(rtn) {
                      if(_undo) {
                        FreePicture(&dup);
                        dup = img;
                      }
                      else FreePicture(&img);
                      img = tmp;
                      tstbeeper(2);
                      if(_autoshow)  raise_message(idmdisplaya);
                 }
                 else  { 
                       tstbeeper(3);
                       mes[2] = "* Failed to do resample !";
                       dialogbox(mes);
                 }  
                 menu_busy(0);
                 return(close_caller_menu);
           }

          case idmrotall:
          case idmrotallfast:
          case idmrotallfine:
           {
                 double n;
                 BOOL rtn;
                 imagedes tmp;
                 
                 tmp.alloc = FALSE; 
                 n=getfloat("Input rotation angle (degree): ");
                 menu_busy(999);
                 if(n != 0.0) {
                    if(mess == idmrotall) 
                       rtn = image_rotate(&tmp, img, n, 0, Interp_normal);
                    else if(mess == idmrotallfast) 
                       rtn = image_rotate(&tmp, img, n, 0, Interp_fast);
                    else rtn = image_rotate(&tmp, img, n, 0, Interp_fine);
                    if(rtn) {
                      if(_undo) {
                        FreePicture(&dup);
                        dup = img;
                      }
                      else FreePicture(&img);
                      img = tmp;
                      tstbeeper(2);
                      if(_autoshow)  raise_message(idmdisplaya);
                    }
                    else { 
                       tstbeeper(3);
                       mes[2] = "* Failed to do resample !";
                       dialogbox(mes);
                    }
                 }
                 menu_busy(0);
                 return(close_caller_menu);
           }

        case idmdisplaya:
             menu_busy(999);
             display_image(img, currentmode, _convert, TRUE, "Buffer");
             menu_busy(0);
             return(refresh_screen|close_caller_menu);
        case idmdisplayr:
           { imagedes tmp;
             tmp=img;
             img.imagetype = Grey;
             menu_busy(999);
             display_image(img, currentmode, FALSE, TRUE, "Red Buffer");
             menu_busy(0);
             img=tmp;
             return(refresh_screen|close_caller_menu);
           }
        case idmdisplayg:
           { imagedes tmp;
             tmp=img;
             img.imagetype = Grey;
             img.r = img.g;
             menu_busy(999);
             display_image(img, currentmode, FALSE, TRUE, "Green Buffer");
             menu_busy(0);
             img = tmp;
             return(refresh_screen|close_caller_menu);
           }
        case idmdisplayb:
           { imagedes tmp;
             tmp=img;
             img.imagetype = Grey;
             img.r = img.b;
             menu_busy(999);
             display_image(img, currentmode, FALSE, TRUE, "Blue Buffer");
             menu_busy(0);
             img = tmp;
             return(refresh_screen|close_caller_menu);
           }
          case idmabout:   
             {
                char *mes[10];
                char titles[80];
                strcpy(titles,
                         "*     /     "); 
                strcat(titles, progname);
                mes[0] = "# About ";
                mes[1] = titles;
                mes[2] = "*    <->    image processing tool ";
                mes[3] = "*     /     for DOS/32 version";
                mes[4] = " Yang Yudong ";
                mes[5] = " yangyd@yahoo.com ";
                mes[6] = " ";
                mes[7] = "@ OK ";
                mes[8] = 0;
                dialogbox(mes);
                return(close_caller_menu);
             }
          case idmabout1:   
             {
                char *mes[10];
                mes[0] = "# About Tools ";
                mes[1] = "* Tools used to build this software are :    ";
                mes[2] = " Image process routines ";
                mes[3] = " Text based menu tool   ";
                mes[4] = "* * these tools are system independent and ";
                mes[5] = "* * can be ported to other platform easily "; 
                mes[6] = "* Please contact:";
                mes[7] = " yangyd@yahoo.com ";
                mes[8] = "@ OK ";
                mes[9] = 0;
                dialogbox(mes);
                return(close_caller_menu);
             }
          case  idm_autodisplay:
             currentmode=0;
             return(close_caller_menu|menu_repaint);
          case  idm256color:
          case  idm32kcolor:
          case  idm64kcolor:
          case  idm16mcolor:
             return(menu_repaint);
          case  idmverticalmenu:
            if(get_menu_status(idmverticalmenu)&menu_checked) {
               reset_menu_status(idmverticalmenu, menu_checked);
               mainmenu.menutype = mfullwidth;
            }
            else {
               set_menu_status(idmverticalmenu, menu_checked);
               mainmenu.menutype = mvertical|mframe|mshadow;
            }
            return(menu_repaint);
          
          case  idmlinearvideo:
            if(get_menu_status(idmlinearvideo)&menu_checked) {
               reset_menu_status(idmlinearvideo, menu_checked);
                           _videoLinear=FALSE;
            }
            else {
               set_menu_status(idmlinearvideo, menu_checked);
                           _videoLinear=TRUE;
            }
            return(menu_repaint);
          case  idmconvertview:
            if(get_menu_status(idmconvertview)&menu_checked) {
               reset_menu_status(idmconvertview, menu_checked);
                           _convert=FALSE;
            }
            else {
               set_menu_status(idmconvertview, menu_checked);
                           _convert=TRUE;
            }
            return(menu_repaint);
          case  idmloadshow:
            if(get_menu_status(idmloadshow)&menu_checked) {
               reset_menu_status(idmloadshow, menu_checked);
                           _autoshow=FALSE;
            }
            else {
               set_menu_status(idmloadshow, menu_checked);
                           _autoshow=TRUE;
            }
            return(menu_repaint);
          default:
             if(mess >= idmvideomodes+v320x200x256 && mess <= idmvideomodes+v1024x768x16m) {
                 currentmode = vmodelist[mess-idmvideomodes-v320x200x256];
                 return(close_caller_menu|menu_repaint);
             } 
             return(callback2(mess));
    }
    return(0);
}


