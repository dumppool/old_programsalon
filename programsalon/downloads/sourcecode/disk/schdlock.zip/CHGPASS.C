#include<stdio.h>
#include<dos.h>
void ReadStr(char *str)
{
 unsigned char Plength=1;
 unsigned xx,yy,x;
 union REGS r;
 xx=wherex();yy=wherey();
 x=xx;
 do{
     gotoxy(xx,yy);
     r.h.ah=0;
     int86(0x16,&r,&r);
     if((r.h.ah!=28)&&(r.h.ah!=14)&&(r.h.ah!=1))
     {
      *(str+Plength)=(r.h.al-20)|0x80;
      gotoxy(xx,yy);
      putch('*');
      xx++;Plength++;
     }
     else if(r.h.ah==14)
          {
           xx--;
           if(xx<x)xx=x;
           gotoxy(xx,yy);
           putch(' ');
           if(Plength>1)Plength--;
          }
          else if(r.h.ah==1)Plength=0;
    }while((r.h.ah!=28)&&(r.h.ah!=1)&&(Plength<15));
    *(str+0)=Plength-1;
}
int CheckPass(char *src,char *dest)
{
 unsigned char Plength;
 Plength=*(src+0);
 while(Plength>0)
 {
  if(*(src+Plength)!=*(dest+Plength))return -1;
  Plength--;
 }
 return 1;
}
int CopyPass(char *src,char *dest)
{
 char Plength;
 Plength=*(src+0);
 while(Plength>=0)
 {
  *(dest+Plength)=*(src+Plength);
  Plength--;
 }
 return 0;
}
void reboot(void)
{
 void (far *reboot_ptr)(void);
 unsigned int far *i_ptr;
 clrscr();
 i_ptr=MK_FP(0x0040,0x0072);
 *i_ptr=0x1234;
 reboot_ptr=MK_FP(0xF000,0xFFF0);
 reboot_ptr();
}
void copyright()
{
 printf("\n Babysoft  (R) Password Changer for Lockd version 2.0");
 printf("\n Copyright (C) 1997.12 LiuYaDing,Babysoft Corp.\n");
}

void main()
{
 unsigned char part[512],buf[512];
 char passwd[16],passwd1[16];
 char *source;
 char key;
 int lock=0;
 copyright();
 if(biosdisk(0x02,0x80,0,0,1,1,buf)||biosdisk(0x02,0x80,0,0,14,1,part))
 {
   printf("\n\a Read Old Password error!");
   printf("\n Read Backup Info error!");
   exit(0);
 }
 if((buf[0x182]=='B')&&(buf[0x183]=='a')&&(buf[0x184]=='b')&&(buf[0x185]=='y')
  &&(buf[0x186]=='s')&&(buf[0x187]=='o')&&(buf[0x188]=='f')&&(buf[0x189]=='t')
  &&(buf[0x18A]==' ')&&(buf[0x18B]=='L')&&(buf[0x18C]=='o')&&(buf[0x18D]=='c')
  &&(buf[0x18E]=='k')&&(buf[0x18F]=='d')&&(buf[0x190]==' ')&&(buf[0x191]=='v')
  &&(buf[0x192]=='2')&&(buf[0x193]=='.')&&(buf[0x194]=='0'))lock=1;
 if(lock==0)
 {
  printf("\n\a Babysoft-Lockd2.0 hasn't installed on your Hard Disk!\n");
  exit(0);
 }
 source=part+0x5E;
 printf("\n Old Password: ");
 ReadStr(passwd);
 if(CheckPass(source,passwd)==1)
 {
  printf("\n New Password: ");
  ReadStr(passwd);
  printf("\n V e r i f y : ");
  ReadStr(passwd1);
  if(CheckPass(passwd,passwd1)==1)
  {
   CopyPass(passwd,source);
   if(biosdisk(0x03,0x80,0,0,14,1,part))
   {printf("\n\a Password changed failed!\n");exit(0);}
   else {printf("\n Password changed ok.");exit(1);}
   printf("\n Do you want to reboot to enable new password?(Y/N)");
   key=getch();
   if((key=='Y')||(key=='y'))reboot();
  }
  else {printf("\n\a Password Verified error!\n");exit(1);}
 }
 else {printf("\n\a Wrong Password!\n");exit(1);}
}

