#include<stdio.h>
#include<bios.h>
#include<dos.h>
#include<fcntl.h>
#include<sys\stat.h>
void ReadStr(char *str)
{
 unsigned char Plength=1;
 unsigned xx,yy,x;
 union REGS r;
 xx=wherex();
 yy=wherey();
 x=xx;
 do{
     gotoxy(xx,yy);
     r.h.ah=0;
     int86(0x16,&r,&r);
     if((r.h.ah!=28)&&(r.h.ah!=14)&&(r.h.ah!=1))
     {
      *(str+Plength)=(r.h.al-20)|0x80;
      gotoxy(xx,yy);
      putch('*');
      xx++;
      Plength++;
     }
     else if(r.h.ah==14)
          {
           xx--;
           if(xx<x)xx=x;
           gotoxy(xx,yy);
           putch(' ');
           if(Plength>1)Plength--;
          }
          else if(r.h.ah==1)Plength=0;
    }while((r.h.ah!=28)&&(r.h.ah!=1)&&(Plength<15));
    *(str+0)=Plength-1;
}
int CheckPass(char *src,char *dest)
{
 unsigned char Plength,p2;
 Plength=*(src+0);
 p2=*(dest+0);
 if(Plength!=p2)return -1;
 while(Plength>0)
 {
  if(*(src+Plength)!=*(dest+Plength))return -1;
  Plength--;
 }
 return 1;
}
int CopyPass(char *src,char *dest)
{
 char Plength;
 Plength=*(src+0);
 while(Plength>=0)
 {
  *(dest+Plength)=*(src+Plength);
  Plength--;
 }
 return 0;
}
int main()
{
 unsigned char buf[512],part[512],temp[512],k;
 int i,flag,lock=0,wrong=0;
 char *pass;
 char passwd1[16],passwd2[16];
 printf("Yaking (R) Logic Driver D: Locker version 2.1\n");
 printf("Copyright (C) 1997.12 ,Yaking Software Studio.\n\n");
 if(biosdisk(0x02,0x80,0,0,1,1,buf))
 {
   printf("Read Master Boot Sector error!\a\n");
   exit(0);
 }
 if(biosdisk(0x02,0x80,0,0,14,1,part)||biosdisk(0x02,0x80,0,0,14,1,temp))
 {
   printf("Read Backup Info error!\a\n");
   exit(0);
 }
 if((buf[0x182]=='B')&&(buf[0x183]=='a')&&(buf[0x184]=='b')&&(buf[0x185]=='y')
  &&(buf[0x186]=='s')&&(buf[0x187]=='o')&&(buf[0x188]=='f')&&(buf[0x189]=='t')
  &&(buf[0x18A]==' ')&&(buf[0x18B]=='L')&&(buf[0x18C]=='o')&&(buf[0x18D]=='c')
  &&(buf[0x18E]=='k')&&(buf[0x18F]=='d')&&(buf[0x190]==' ')&&(buf[0x191]=='v')
  &&(buf[0x192]=='2')&&(buf[0x193]=='.')&&(buf[0x194]=='0'))lock=1;
 if(part[0x1BE]==0x10&&part[0x1BF]==0x11)flag=1;
 else flag=0;
 for(i=0;i<16;i++)
 {
  if(temp[i]!=0&&temp[i]!=0xFF)temp[i]=~temp[i];
  if(temp[i]!=buf[0x1BE+i])wrong=1;
 }
 switch(lock)
 {
  case 1:
       if(wrong)
       {
	printf("Backup Info was destroyed by Virus or other programs!\a\n");
        printf("Use HDMBG.EXE to restore Partition.\n");
        exit(0);
       }
       if(flag==1)
       {
        printf("Logic Driver D: has been locked before.\n");
        printf("Unlock it?(Y/N)");
        k=getch();
        k=k|0x20;
        if(k=='y')
	{
	 printf("\nPassword: ");
	 ReadStr(passwd1);
	 pass=part+0x5E;
	 CopyPass(pass,passwd2);
	 if(CheckPass(passwd2,passwd1)!=1)
	 {
	  printf("\n\aPassword error! Unlock failed.");
	  exit(1);
	 }
	 part[0x1BE]=0x00;part[0x1BF]=0x00;
	 for(i=0;i<48;i++)
	 {
	  if(part[i+16]!=0x00&&part[i+16]!=0xFF)buf[0x1CE+i]=~part[16+i];
	 }
	 if(biosdisk(0x03,0x80,0,0,1,1,buf)||biosdisk(0x03,0x80,0,0,14,1,part))
	 {
	  printf("\nUnlock Driver D: error!\a\n");
	  exit(0);
	 }
	 printf("\nUnlock Driver D: ok.\n");
	 break;
	}
	else return 0;
       }
       if(flag==0)
       {
	part[0x1BE]=0x10;part[0x1BF]=0x11;
	for(i=0;i<48;i++)buf[0x1CE+i]=0;
	if(biosdisk(0x03,0x80,0,0,1,1,buf)||biosdisk(0x03,0x80,0,0,14,1,part))
	{
	 printf("Lock Driver D: failed!\a\n");
	 exit(0);
	}
	printf("Locked Driver D: ok.\n");
	break;
       }
  case 0:
       printf("Are you using Yakingsoft-Locker v2.1 on this Hard Disk first?\n\a");
       printf("If yes.Please use HDMBG.EXE to Backup Master Boot Sector!\n");
       printf("\nAfter do it...\n");
       printf("If you can't unlock Driver D:,HDMBG.EXE can help you to restore Partition.\n");
       printf("\nQuit and Use HDMBG.EXE to Backup?(Y/N)");
       k=getch();k=k|0x20;
       if(k=='y'){exit(0);}
       buf[0x182]='B';buf[0x183]='a';buf[0x184]='b';buf[0x185]='y';
       buf[0x186]='s';buf[0x187]='o';buf[0x188]='f';buf[0x189]='t';
       buf[0x18A]=' ';buf[0x18B]='L';buf[0x18C]='o';buf[0x18D]='c';
       buf[0x18E]='k';buf[0x18F]='d';buf[0x190]=' ';buf[0x191]='v';
       buf[0x192]='2';buf[0x193]='.';buf[0x194]='0';
       for(i=0;i<32;i++)buf[0x195+i]=0x00;
       for(i=0;i<512;i++)
       {part[i]=0x00;}
       part[0x1BE]=0x10;part[0x1BF]=0x11;
       for(i=0;i<16;i++)
       {
	if(buf[0x1BE+i]!=0x00&&buf[0x1BE+i]!=0xFF)part[i]=~buf[0x1BE+i];
       }
       for(i=0;i<48;i++)
       {
	if(buf[0x1CE+i]!=0x00&&buf[0x1CE+i]!=0xFF)part[16+i]=~buf[0x1CE+i];
	buf[0x1CE+i]=0x00;
       }
       printf("\nPassword: ");
       ReadStr(passwd1);
       printf("\nVerify  : ");
       ReadStr(passwd2);
       if(CheckPass(passwd1,passwd2)!=1)
       {
	printf("\n\aPassword verify error!!! ");
	exit(1);
       }
       pass=part+0x5E;
       CopyPass(passwd1,pass);
       if(biosdisk(0x03,0x80,0,0,1,1,buf)||biosdisk(0x03,0x80,0,0,14,1,part))
       {
	printf("\nLock Driver D: failed!\a\n");
	exit(0);
       }
       printf("\nLocked Driver D: ok.\n");
       break;
  }
  printf("Reboot system to enable the change?(Y/N)");
  k=getch();k=k|0x20;
  if(k=='y')
  {
   asm mov ax,0xf000
   asm push ax
   asm mov ax,0xfff0
   asm push ax
   asm retf
  }
  return 0;
}
