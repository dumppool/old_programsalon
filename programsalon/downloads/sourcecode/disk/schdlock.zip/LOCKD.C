#include<stdio.h>
#include<bios.h>
int main()
{
 unsigned char buf[512],part[512],temp[512],k;
 int i,flag,lock=0,wrong=0;
 printf("Babysoft  (R) Logic Driver D: Locker-II version 1.0\n");
 printf("Copyright (C) 1997.11 LiuYaDing,Babysoft Corp.\n\n");
 if(biosdisk(0x02,0x80,0,0,1,1,buf))
 {
   printf("Read Master Boot Sector error!\a\n");
   exit(0);
 }
 if(biosdisk(0x02,0x80,0,0,14,1,part)||biosdisk(0x02,0x80,0,0,14,1,temp))
 {
   printf("Read Backup Info error!\a\n");
   exit(0);
 }
 if((buf[0x19E]=='B')&&(buf[0x19F]=='a')&&(buf[0x1A0]=='b')&&(buf[0x1A1]=='y')&&(buf[0x1A2]=='s')&&(buf[0x1A3]=='o')&&(buf[0x1A4]=='f')&&(buf[0x1A5]=='t'))lock=1;
 if(part[0x1BE]==0x10&&part[0x1BF]==0x11)flag=1;
 else flag=0;
 for(i=0;i<16;i++)
 {
  if(temp[i]!=buf[0x1BE+i])wrong=1;
 }
 switch(lock)
 {
  case 1:
       if(wrong)
       {
	printf("Backup Info was destroyed by Virus or other programs!\a\n");
        printf("Use HDMBG.EXE to restore Partition.\n");
        exit(0);
       }
       if(flag==1)
       {
        printf("Logic Driver D: has been locked before.\n"); 
        printf("Unlock it?(Y/N)");
        k=getch();
        k=k|0x20;
        if(k=='y')
        {
         part[0x1BE]=0x00;part[0x1BF]=0x00;
	 for(i=0;i<48;i++)
	 {
	  if(part[i+16]!=0x00)buf[0x1CE+i]=part[16+i];
	 }
	 if(biosdisk(0x03,0x80,0,0,1,1,buf)||biosdisk(0x03,0x80,0,0,14,1,part))
	 {
	  printf("\nUnlock Driver D: error!\a\n");
	  exit(0);
	 }
	 printf("\nUnlock Driver D: ok.\n");
	 break;
	}
	else return 0;
       }
       if(flag==0)
       {
	part[0x1BE]=0x10;part[0x1BF]=0x11;
	for(i=0;i<48;i++)buf[0x1CE+i]=0;
	if(biosdisk(0x03,0x80,0,0,1,1,buf)||biosdisk(0x03,0x80,0,0,14,1,part))
	{
	 printf("Lock Driver D: failed!\a\n");
	 exit(0);
	}
	printf("Locked Driver D: ok.\n");
	break;
       }
  case 0:
       printf("Are you use Locker-II on this Hard Disk first?\n\a");
       printf("If yes.Please use HDMBG.EXE to Backup Master Boot Sector!\n");
       printf("\nAfter do it...\n");
       printf("If you can't unlock Driver D:,HDMBG.EXE can help you to restore Partition.\n");
       printf("\nQuit and Use HDMBG.EXE to Backup?(Y/N)");
       k=getch();k=k|0x20;
       if(k=='y'){exit(0);}
       buf[0x19E]='B';buf[0x19F]='a';buf[0x1A0]='b';buf[0x1A1]='y';
       buf[0x1A2]='s';buf[0x1A3]='o';buf[0x1A4]='f';buf[0x1A5]='t';
       for(i=0;i<512;i++)
       {part[i]=0x00;}
       part[0x1BE]=0x10;part[0x1BF]=0x11;
       for(i=0;i<16;i++)
       {
	if(buf[0x1BE+i]!=0x00)part[i]=buf[0x1BE+i];
       }
       for(i=0;i<48;i++)
       {
	if(buf[0x1CE+i]!=0x00)part[16+i]=buf[0x1CE+i];
	buf[0x1CE+i]=0x00;
       }
       if(biosdisk(0x03,0x80,0,0,1,1,buf)||biosdisk(0x03,0x80,0,0,14,1,part))
       {
	printf("\nLock Driver D: failed!\a\n");
	exit(0);
       }
       printf("\nLocked Driver D: ok.\n");
       break;
  }
  printf("Reboot system to enable the change?(Y/N)");
  k=getch();k=k|0x20;
  if(k=='y')
  {
   asm mov ax,0xf000
   asm push ax
   asm mov ax,0xfff0
   asm push ax
   asm retf
  }
  return 0;
}
