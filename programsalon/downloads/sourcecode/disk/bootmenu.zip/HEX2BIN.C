/*
 * hex2bin - a simple hex to binary converter
 */
#include <stdio.h>
main()
{
  int c;

#ifdef MSDOS
  setmode(stdout,O_BINARY);
#endif

  while (scanf("%x", &c) == 1)
    putchar(c);
  exit(0);
}
