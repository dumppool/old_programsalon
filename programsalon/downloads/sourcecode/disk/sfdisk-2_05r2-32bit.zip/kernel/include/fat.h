#if defined( Uses_FATBase ) && !defined( __FATBase )
#define __FATBase

//BPB data block for FAT File System
struct FAT_BPBCommon
{
	BYTE OemID[8];
	WORD BytesPerSector;
	BYTE SectorsPerCluster;
	WORD ReservedSectors;
	BYTE NumberOfFAT;
	WORD RootEntries;
	WORD TotalSectors;
	BYTE MediaDescriptor;
	WORD SectorsPerFAT;
	WORD SectorsPerTrack;
	WORD Heads;
	DWORD HiddenSectors;
	DWORD BigTotalSectors;
} __attribute__((packed));

//BPB data block for FAT16 File System
struct FAT_BPB16
{
	BYTE DriveNumber;
	BYTE BootReserved;
	BYTE ExtBootRecordID;
	DWORD SerialNumber;
	BYTE VolumeLabel[11];
	BYTE SystemType[8];
} __attribute__((packed));

//BPB data block for FAT32 File System
struct FAT_BPB32
{
	DWORD BigSectorsPerFAT;
	WORD ExtFlags;
	WORD FSVersion;
	DWORD RootDirStartCluster;
	WORD FSInfoSector;
	WORD BackupBootSector;
	WORD Reserved[6];
	BYTE DriveNumber;
	BYTE BootReserved;
	BYTE ExtBootRecordID;
	DWORD SerialNumber;
	BYTE VolumeLabel[11];
	BYTE SystemType[8];
} __attribute__((packed));


struct FAT_BPB
{
	FAT_BPBCommon com __attribute__((packed));
	union
	{
		FAT_BPB16 bpb16;
		FAT_BPB32 bpb32;
	} __attribute__((packed));
} __attribute__((packed));

struct FAT_BFFSInfo
{
	DWORD Signature;
	DWORD FreeClusterCount;
	DWORD NextFreeCluster;
	DWORD Reserved[3];
	DWORD EndSig;
} __attribute__((packed));

struct FAT_DirEntry
{
	BYTE Name[8];         /* name and extension */
	BYTE Ext[3];
	BYTE Attribute;       /* attribute bits */
	BYTE LCase;           /* Case for base and extension */
	BYTE CreateTimeMs;    /* Creation time, milliseconds */
	WORD CreateTime;      /* Creation time */
	WORD CreateDate;      /* Creation date */
	WORD AccessDate;      /* Last access date */
	WORD ClusterHi;       /* High 16 bits of cluster in FAT32 */
	WORD Time;            /* time, date and first cluster */
	WORD Data;
	WORD Cluster;
	DWORD Size;           /* file size (in bytes) */
} __attribute__((packed));




class TFileSystem;

/****************************************************************************/
/*Class name: TFATBase                                                      */
/*Discription:                                                              */
/*    Base class for FAT file systems including FAT16 and FAT32.            */
/*    Provide some public functions and some virtual functions.             */
/****************************************************************************/
class TFATBase : public TFileSystem
{
public:
	TFATBase(){ PreInit(); }

	virtual void ShutDown();
	virtual int32 Initialize( TPartition *partition );

	int32 ReadCluster( DWORD start, WORD num, void * buf );
	int32 WriteCluster( DWORD start, WORD num, void * buf );
	int32 VerifyCluster( DWORD start, WORD num );

	virtual int32 Format( CallBackFunc CallBack=NULL,
						  int32 method=0, DWORD MinBlockSize=2048uL );
	virtual TBadBlockList *SurfaceScan( CallBackFunc CallBack=NULL );

	virtual int32 GetFileSysInfo( TFileSysInfo &info );
	virtual int32 GetBlkSizeInfo( WORD & minIndex, WORD & maxIndex , WORD &defIndex);

	virtual DWORD GetBlockSize()
		{
			return  (DWORD)ParamBlock.com.SectorsPerCluster *
					(DWORD)ParamBlock.com.BytesPerSector;
		}

	virtual BYTE GetFileSysType();
	virtual Boolean CanFormat();
	virtual int32 WriteChange();

protected:
	int32 ReadBadBlockRecord();
	int32 WriteBadBlockRecord();

	void PreInit();

	virtual int32 ReadBootRecord()=0;
	virtual int32 WriteBootRecord()=0;
	virtual int32 CreateBootRecord(DWORD MinBlockSize)=0;

	virtual DWORD ReadFATEntry( DWORD cluster )=0;
	virtual int32 WriteFATEntry( DWORD cluster, DWORD entry )=0;
	virtual int32 FlushFATBuf()=0;
	virtual int32 ReadFATtoBuf()=0;
	virtual int32 ClearFATTable()=0;
	virtual int32 ClearRootDir()=0;

	virtual DWORD GetClusterLBA( DWORD cluster )=0;
	virtual DWORD GetTotalClusters()=0;

	DWORD GetSectorsPerCluster()
		{ return (DWORD)ParamBlock.com.SectorsPerCluster; }

	DWORD GetBadClusterID();

	int32 ReadFATTable( DWORD &FreeClusters, DWORD &BadClusters );


	BYTE  *FATBuf;
	int32 FATBufStartSector;
	int32 FATBufSectors;
	Boolean FATBufChanged;

	WORD FATType;

	FAT_BPB ParamBlock;
};

#endif // End of __FATBase

/****************************************************************************/
/* Class TFAT16                                                             */
/****************************************************************************/
#if defined( Uses_FAT16 ) && !defined( __FAT16 )
#define __FAT16


class TFATBase;
class TPartition;

/****************************************************************************/
/*Class name: TFAT16                                                        */
/*Discription:                                                              */
/*    Class for FAT16 File System.                                          */
/****************************************************************************/
class TFAT16 : public TFATBase
{
public:
	TFAT16();
	TFAT16( TPartition * part );

protected:
	virtual int32 ReadBootRecord();
	virtual int32 WriteBootRecord();
	virtual int32 CreateBootRecord(DWORD MinBlockSize);

	virtual DWORD ReadFATEntry( DWORD cluster );
	virtual int32 WriteFATEntry( DWORD cluster, DWORD entry );
	virtual int32 FlushFATBuf();
	virtual int32 ReadFATtoBuf();

	virtual int32 ClearFATTable();
	virtual int32 ClearRootDir();

	virtual DWORD GetClusterLBA( DWORD cluster );
	virtual DWORD GetTotalClusters();

private:
	static BYTE FAT16BootRecord[512];

};
#endif // End of __FAT16

/****************************************************************************/
/* Class TFAT32                                                             */
/****************************************************************************/
#if defined( Uses_FAT32 ) && !defined( __FAT32 )
#define __FAT32


class TFATBase;
class TPartition;

/****************************************************************************/
/*Class name: TFAT32                                                        */
/*Discription:                                                              */
/*    Class for FAT32 File System.                                          */
/****************************************************************************/
class TFAT32 : public TFATBase
{
public:
	TFAT32();
	TFAT32( TPartition * part );

	virtual void ShutDown();

protected:
	void PreInit();

	virtual int32 ReadBootRecord();
	virtual int32 WriteBootRecord();
	virtual int32 CreateBootRecord(DWORD MinBlockSize);

	virtual DWORD ReadFATEntry( DWORD cluster );
	virtual int32 WriteFATEntry( DWORD cluster, DWORD entry );
	virtual int32 FlushFATBuf();
	virtual int32 ReadFATtoBuf();

	virtual int32 ClearFATTable();
	virtual int32 ClearRootDir();

	virtual DWORD GetClusterLBA( DWORD cluster );

	virtual DWORD GetTotalClusters();

private:
	FAT_BFFSInfo ExtFSInfo;

	static BYTE FAT32BootRecord1[512];
	static BYTE FAT32BootRecord2[512];
};
#endif // End of __FAT32
