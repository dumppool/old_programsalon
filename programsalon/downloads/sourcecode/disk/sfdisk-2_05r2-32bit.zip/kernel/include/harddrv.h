#if !defined( __HardDrive ) && defined( Uses_HardDrive )
#define __HardDrive

#define CHSINFOVALID		0x02		//Cylinders / Heads / Sectors info is valid
#define DRIVEREMOVABLE		0x04		//Drive is removable
#define WRITEVERIFYOK		0x08		//Drive support write with verify
#define CHGLINESUPPORT		0x10		//Drive support change line
#define DRIVELOCKABLE		0x20		//Drive is lockable
#define MINDRIVENUM			0x80		//Minimal drive number

#define MAXINT13CYLINDER	1023
#define DEFSECTORSIZE		512

#define MAXDATABUFSIZE		32768L
#define MAXPARAMBUFSIZE		32L

struct TInt13ExtData
{
	BYTE PackageSize;		// ==16 size of struct Int13ExtData
	BYTE Reserved;			// ==0
	WORD BlockCount;		// number of blocks to transfer
	DWORD BufferAddr;		// address of transfer buffer(segment:offset)
	QWORD BlockNum;			// starting absolute block number
} __attribute__((packed));

struct TInt13ExtDriveParam
{
	WORD InfoSize;			// == 26 size of information buffer
	WORD Flags;				// information flags
	DWORD Cylinders;		// number of cylinders on disk
	DWORD Heads;			// number of heads on disk
	DWORD SectorsPerTrack;	// number of sectors per track
	QWORD Sectors;			// number of sectors on requested disk
	WORD SectorSize;		// number of bytes per sector
} __attribute__((packed));

struct TDiskGeometry		// Structure to store Disk Geometry
{
	WORD Cylinders;
	WORD Heads;
	WORD SectorsPerTrack;
	WORD SectorsPerCylinder;
} __attribute__((packed));

/****************************************************************************/
/*Class name: THardDrive                                                    */
/*Discription:                                                              */
/*    Low level programming interface for Hard disk drive                   */
/*    Provide low level read, write, verify etc.                            */
/****************************************************************************/
class TKernelObject;

class THardDrive : public TKernelObject
{
public:
	THardDrive();
	THardDrive(int32 DriveNumber);       // Drive Number =0, 1, 2 ...
	THardDrive(int32 DriveNumber, Boolean UseInt13Ext);

	virtual void ShutDown();

	//Initialize the Hard drive , DriveNumber >= 0x80
	int32 Initialize(int32 DriveNumber, Boolean UseInt13Ext=True);


	// Basic functions for Hard drive
	// BlockNum is the start logical block address
	// BlockCount is the number of blocks to be operated
	// Buffer is the pointer of memory where the data is read from or stored in
	// Return value is the error code, 0 is no error

	int32 Read  ( QWORD BlockNum, WORD BlockCount, void * Buffer );
	int32 Write ( QWORD BlockNum, WORD BlockCount, void * Buffer );
	int32 Verify( QWORD BlockNum, WORD BlockCount );
	int32 Seek  ( QWORD BlockNum );
	int32 Lock  ();							// Lock the drive
	int32 Unlock();							// Unlock the drive
	int32 Eject ();							// Eject the disk if possible

	int32 GetLockStatus(int32 & status);	// Get the lock status,
											// status is the lock count
	int32 GetDriveParam( TInt13ExtDriveParam & dp );
	int32 GetGeometry  ( TDiskGeometry & Geometry );
	int32 SetGeometry  ( TDiskGeometry & Geometry ); 		// Set Disk Geometry manually
	int32 DetectLBAGeometry( TDiskGeometry & Geometry ); 	// Detect Geometry using
															//int 13h, 0x08 function

	// Logical block address and Cylinder / Head / Sector address exchange function
	int32 LBAtoCHS( QWORD BlockNum, WORD & cylinder, WORD & head, WORD & sector );
	int32 CHStoLBA( WORD cylinder, WORD head, WORD sector, QWORD & BlockNum );

	//Inline Functions, to get some status and some useful parameters
	Boolean IsRemovable()
		{ return (Boolean) (IsUseable() && (DriveParam.Flags & DRIVEREMOVABLE)); }
	Boolean IsLockable()
		{ return (Boolean) (IsUseable() && (DriveParam.Flags & DRIVELOCKABLE)); }
	Boolean IsUseable() { return Useable; }
	Boolean IsInt13ExtPresent(){ return Int13ExtPresent; }
	Boolean IsUseInt13Ext(){ return Int13ExtPresent && UseInt13Ext; }

	WORD GetSectorSize(){ return DriveParam.SectorSize; }
	WORD GetDriveNumber() { return DriveNumber; }
	DWORD GetSectors(){ return DriveParam.Sectors; }
	DWORD GetSizeInMega(){ return SizeInMega; }

private:
	void PreInit();
	int32 AllocBuffers();
	void FreeBuffers();

	Boolean CheckInt13Ext();

	void ResetDrive();

	int32 OldRead  ( DWORD BlockNum, WORD BlockCount, void * Buffer );
	int32 OldWrite ( DWORD BlockNum, WORD BlockCount, void * Buffer );
	int32 OldVerify( DWORD BlockNum, WORD BlockCount );
    int32 OldBiosDisk(int cmd, int drive, int head, int track, int sector, int nsects, void *buffer);

//Private data member
	WORD					DriveNumber;
	DWORD					SizeInMega;

	TInt13ExtDriveParam		DriveParam;
	TDiskGeometry			DiskGeometry;

	Boolean					Useable;
	Boolean					Int13ExtPresent;
	Boolean					UseInt13Ext;

	static int32				ParamBufSelector;
	static int32				ParamBufSeg;
	static int32				ParamBufOff;

	static int32				DataBufSelector;
	static int32				DataBufSeg;
	static int32				DataBufOff;
	static int32				BufferUseCount;
};


//Other Utility
int32 GetHDNumber(void);   // Get total number of the Hard drives in the computer

#endif //End of __HardDrive
