#if !defined( __DataType ) && defined( Uses_DataType )
#define __DataType

typedef unsigned short    WORD;
typedef unsigned char     BYTE;
typedef unsigned long     DWORD;
typedef unsigned long long QWORD;
typedef short int16;
typedef int int32;
typedef unsigned short uint16;
typedef unsigned int uint32;
typedef unsigned short ushort;
typedef unsigned char uchar;

#if !defined( __TTYPES_H )

#if defined( __GNUC__ )
#undef Boolean
#undef False
#undef True
#define Boolean bool
#define True true
#define False false
#else
enum Boolean { False, True };
#endif

const char EOS = '\0';

#endif

typedef short (* CallBackFunc)(char *msg);

#endif //End of __DataType