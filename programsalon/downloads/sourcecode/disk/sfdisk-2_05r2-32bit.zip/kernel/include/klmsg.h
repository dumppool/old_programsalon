#if defined( Uses_KernelMessage ) && !defined( __KernelMessage )
#define __KernelMessage

struct TErrorMessage			// Structure to store Error message
{
	int32 Code;
	const char *Message;
};

extern char **KernelMsg;

const char * GetKernelErrorMsg(int32 ErrorNumber);

void SetKernelLanguage( int32 language );

#endif // End of __KernelMessage