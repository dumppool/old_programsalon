#if !defined( __RootPartition ) && defined( Uses_RootPartition )
#define __RootPartition

class TPartition;

/****************************************************************************/
/*Class name: TRootPartition                                                */
/*Discription:                                                              */
/*    High level programming interface for Root Partition                   */
/*    ---- Virtual Hard Disk                                                */
/*    Provide Read Partition Table, Write Partition Table, etc.             */
/****************************************************************************/
struct TBadBlockList;

class TRootPartition : public TPartition
{
public:
	TRootPartition( THardDrive *hd );
	TRootPartition();

	int32 Initialize( THardDrive *hd );

	virtual int32 WriteChange();	//Write any changes

	virtual Boolean IsChanged();	// Check if any changes occured

	Boolean CanCreatePrimary( TPartition *part );
	Boolean CanCreateLogical( TPartition *part );
	Boolean CanDelete( TPartition *part );
	Boolean CanBoot( TPartition *part );
	Boolean CanActive( TPartition *part );
	Boolean CanFormat( TPartition *part );
	Boolean CanSurfaceScan( TPartition *part );

	int32 GetSonLevel( TPartition *part );

	int32 CreatePrimary( TPartition *free, BYTE type,
						 DWORD mega, int32 pos, char * name=NULL );
	int32 CreateLogical( TPartition *free, BYTE type,
						 DWORD mega, int32 pos, char * name=NULL );
	int32 Delete( TPartition *part );
	int32 MarkAsActive( TPartition *part );
	int32 ToggleBootable( TPartition *part );

	int32 GetPrimaryNumber();
	int32 GetLogicalNumber();

private:
	int32 ReadPartitionTable();		//Read Partition Table and
									//create Partition tree.

	int32 WritePartitionTable();	//Write Partition Table

	int32 TransExtPartLink();
	int32 AntiTransExtPartLink();
	int32 CheckFree();
	int32 ReadExtPartTable( TPartition *ext, TPartition *son );
	int32 WriteExtPartTable( TPartition *ext, TPartition *son );
	int32 CreatePartitionTable( TPartitionRecord * table );
	int32 CreateExtPartTable( TPartition *ext, TPartition *son,
							  TPartitionRecord * table );

};

#endif // End of __RootPartition