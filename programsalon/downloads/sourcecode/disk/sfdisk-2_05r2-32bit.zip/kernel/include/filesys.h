#if defined( Uses_FileSystem ) && !defined( __FileSystem )
#define __FileSystem

#define QUICKFORMAT  0
#define FULLFORMAT   1
#define SAFEFORMAT   2

extern DWORD ValidBlockSize[];

// Struct for Summary of File System
struct TFileSysInfo
{
	WORD InfoSize;
	Boolean Formated;
	BYTE FileSysName[16];
	DWORD TotalKBytes;
	DWORD ReservedKBytes;
	DWORD FreeKBytes;
	DWORD BytesPerBlock;
	DWORD TotalBlocks;
	DWORD FreeBlocks;
	DWORD BadBlocks;
} __attribute__((packed));

//Struct for record bad block in File system
struct TBadBlockList
{
	DWORD Start;
	DWORD End;
	TBadBlockList *Next;
} __attribute__((packed));

class TPartition;

/****************************************************************************/
/*Class name: TFileSystem                                                   */
/*Discription:                                                              */
/*    Base class for all File Systems.                                      */
/*    Provide some virtual functions for all file systems.                  */
/****************************************************************************/
class TKernelObject;

class TFileSystem : public TKernelObject
{
public:

	virtual int32 Initialize( TPartition *partition );
	virtual void ShutDown();

	// Format File System, method = 0 Quick, 1 Full or 2 Safe
	virtual int32 Format( CallBackFunc CallBack,
						  int32 method, DWORD MinBlockSize )=0;
	// Scan the Surface of File System
	virtual TBadBlockList *SurfaceScan( CallBackFunc CallBack )=0;
	virtual int32 GetFileSysInfo( TFileSysInfo &info )=0;
    virtual BYTE GetFileSysType()=0;

	virtual Boolean CanFormat();
	virtual Boolean IsFormated();
	virtual DWORD GetBlockSize()=0;
	virtual int32 GetBlkSizeInfo( WORD & minIndex, WORD & maxIndex , WORD &defIndex)=0;
    virtual int32 WriteChange()=0;


	Boolean IsUseable(){ return Useable; }
	Boolean IsChanged(){ return Changed; }
	char * GetFileSysName() { return FileSysName; }

protected:
	Boolean Useable;
	Boolean Formated;
    Boolean Changed;

	TPartition *Partition;
	TBadBlockList *BadBlockList;
	char FileSysName[16];
	void PreInit();
	void DeleteBadBlockList();
};


class TRawFileSystem : public TFileSystem
{
public:

	TRawFileSystem(){ PreInit(); }

	TRawFileSystem(TPartition *part);

	// Format File System, method = 0 Quick, 1 Full or 2 Safe
	virtual int32 Format( CallBackFunc CallBack,
						  int32 method, DWORD MinBlockSize );
	// Scan the Surface of File System
	virtual TBadBlockList *SurfaceScan( CallBackFunc CallBack );
	virtual int32 GetFileSysInfo( TFileSysInfo &info );
	virtual DWORD GetBlockSize();
	virtual int32 GetBlkSizeInfo( WORD & minIndex, WORD & maxIndex , WORD &defIndex);
	virtual Boolean CanFormat()
		{ return False; }
    virtual int32 WriteChange(){ return 0;}
    virtual BYTE GetFileSysType(){ return 0; }
};

#endif // End of __Filesystem

