// Smart FDISK Kernel Version 2 Header File
// Designed by Suzhe 1998.8

#include<dos.h>
#include<bios.h>
#include<string.h>
#include<stdio.h>
#include<mem.h>
#include<stdlib.h>

#define Uses_DataType
#define Uses_KernelMessage
#define Uses_KernelObject

#if defined( Uses_BootManager )
#define Uses_RootPartition
#endif

#if defined( Uses_FAT16 )
#define Uses_FATBase
#endif

#if defined( Uses_FAT32 )
#define Uses_FATBase
#endif

#if defined( Uses_FATBase )
#define Uses_FileSystem
#endif

#if defined( Uses_FileSystem )
#define Uses_Partition
#endif

#if defined( Uses_RootPartition )
#define Uses_Partition
#endif

#if defined( Uses_Partition )
#define Uses_HardDrive
#endif

#if defined( Uses_DataType )
#include "DataType.h"
#endif

#if defined( Uses_KernelObject )
#include "KLObj.h"
#endif

#if defined( Uses_KernelMessage )
#include "KLMSG.h"
#endif

#if defined( Uses_HardDrive )
#include "HardDrv.h"
#endif

#if defined( Uses_Partition )
#include "Part.h"
#endif

#if defined( Uses_RootPartition )
#include "RootPart.h"
#endif

#if defined( Uses_FileSystem )
#include "FileSys.h"
#endif

#if defined( Uses_FATBase )
#include "FAT.h"
#endif

#if defined( Uses_FAT16 )
#include "FAT.h"
#endif

#if defined( Uses_FAT32 )
#include "FAT.h"
#endif

#if defined( Uses_BootManager )
#include "BootMgr.h"


#endif