#if defined( Uses_BootManager ) && !defined( __BootManager )
#define __BootManager

#define	BTMGRENG			0
#define	BTMGRCHN			1

#define MGRCOPYNUM			4
#define	LOADERSIZE			512uL
#define KERNELSECTS			8
#define KERNELSIZE			(512uL*KERNELSECTS)
#define LOADERDATAOFFSET	3
#define KERNELDATAOFFSET    29
#define LOADERVEROFFSET     3
#define KERNELVEROFFSET		32
#define BOOTMENUENTRYNUM	16

#define VIRNOCHECK			0
#define VIRCHECKINT13		1
#define VIRCHECKMEM			2
#define VIRCHECKBOTH		3
#define HIDDENCODE			0xA0

struct TInt13OldAddr
{
	BYTE Head;
	WORD CyldSect;
} __attribute__((packed));

union TInt13Address
{
	TInt13OldAddr old;
	DWORD Sector;
}__attribute__((packed));


struct TLoaderData
{
	BYTE Version[16];
    BYTE NotUseInt13Ext;
	BYTE DriveNumber;
	BYTE VirusSwitch;	//1 = Check Int13  2 = Check Mem  3 = Check Both
	TInt13Address KernelAddr[MGRCOPYNUM];
} __attribute__((packed));

struct TBootPartEntry
{
	BYTE State;			//0 = Not active,  80h = Active
	BYTE Type;			//0 = Free
	BYTE Hidden;		//0 = Not hidden, 0a0h = Hidden
	BYTE Index;			//Index number in father's partition table
	TInt13Address FatherAddr;	//The first sector number of father
	TInt13Address AbsAddr;		//The first abs sector number of this part
	DWORD RelativeSect;	//The relative sector number of this part,
						//equal to the same item in partition entry
	BYTE Name[16];		//Partition name, 15 letters string with zero at tail
} __attribute__((packed));

struct TKernelData
{
	unsigned char NotUseInt13Ext : 4;
	unsigned char AutoHide : 4;
	WORD CheckSum;
	BYTE Version[24];
	TInt13Address KernelAddr[MGRCOPYNUM];

	TBootPartEntry BootPartList[16];	//Store the bootable part info

	BYTE MainPartTable[64];				//A copy of the Main Partition Record
	BYTE DriveNumber;
	BYTE OriginTime;
} __attribute__((packed));

struct TBootMgrInstData
{
	WORD Language;
	WORD VirusCheck;
	WORD DelayTime;
	WORD AutoHide;
} __attribute__((packed));

class TRootPartition;

class TKernelObject;

class TBootManager : public TKernelObject
{
public:
	TBootManager();
	TBootManager( TRootPartition *root );

	virtual void ShutDown();

	int32 Initialize( TRootPartition *root );

	int32 Install(TBootMgrInstData &data);
	int32 Uninstall();
	int32 RepairMBR(Boolean Rescue);
	int32 WriteBootMenu();

	Boolean CanInstall();

	Boolean IsInstalled()
		{ return (Boolean)(LoaderInst && KernelInst && Useable); }
	Boolean IsLoaderInst(){ return LoaderInst; }
	Boolean IsKernelInst(){ return KernelInst; }

	Boolean IsUseable(){ return Useable; }
	Boolean IsPartTableChanged();

private:
	void PreInit();

	WORD CalcKernelCheckSum( BYTE * kernel );

	int32 ReadLoader();
	int32 ReadKernel();

	int32 WriteLoader(int32 virus);
	int32 WriteKernel(int32 language, int32 delayTime, int32 AutoHide);
	void AddrNewToOld();
    void AddrOldToNew();

	TRootPartition *Root;
	Boolean LoaderInst;
	Boolean KernelInst;
	Boolean Useable;
	Boolean UseInt13Ext;

	DWORD KernelSect[MGRCOPYNUM];
	TInt13OldAddr KernelOldAddr[MGRCOPYNUM];

	TPartitionRecord MainPartTable[MAXPTNUMBER];
	BYTE VirusCheck;

	static BYTE MasterBootCode[LOADERSIZE];
	static BYTE LoaderCode[LOADERSIZE];
	static BYTE KernelEngCode[KERNELSIZE];
	static BYTE KernelChnCode[KERNELSIZE];

	static BYTE LoaderCodeOld[LOADERSIZE];
	static BYTE KernelEngCodeOld[KERNELSIZE];
	static BYTE KernelChnCodeOld[KERNELSIZE];

	static BYTE LoaderVersion[17];
	static BYTE KernelVersion[24];

};

#endif // End of __BootManager