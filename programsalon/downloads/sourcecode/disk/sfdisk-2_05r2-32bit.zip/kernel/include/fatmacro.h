#if defined( Uses_FATBase )

#define GOODBOOTID	0xAA550000
#define BOOTIDOFFSET 508
#define OEMID "MSWIN4.1"
#define FIRSTCLUSTER  2

#define BPBOFFSET  0x03
#define EXTBRID    0x29
#define FAT12FSNAME "FAT12"
#define FAT16FSNAME "FAT16"
#define FAT32FSNAME "FAT32"
#define DIRENTRYSIZE 32uL
#define FSINFOSIG  0x61417272uL
#define EXTBOOTSIG 0x41615252uL
#define BFFSINFOOFFSET 0x1E4

#define FATBUFSECTORS 32

#define FD_FILL_BYTE 0xF6 /* format fill byte. */
#define DELETED_FLAG 0xe5 /* marks file as deleted when in name[0] */

#define ATTR_RO      1  /* read-only */
#define ATTR_HIDDEN  2  /* hidden */
#define ATTR_SYS     4  /* system */
#define ATTR_VOLUME  8  /* volume label */
#define ATTR_DIR     16 /* directory */
#define ATTR_ARCH    32 /* archived */

#define ATTR_NONE    0 /* no attribute bits */
#define ATTR_UNUSED  (ATTR_VOLUME | ATTR_ARCH | ATTR_SYS | ATTR_HIDDEN)
	/* attribute bits that are copied "as is" */
#define ATTR_EXT     (ATTR_RO | ATTR_HIDDEN | ATTR_SYS | ATTR_VOLUME)
	/* bits that are used by the Windows 95/Windows NT extended FAT */

#define CASE_LOWER_BASE 8	/* base is lower case */
#define CASE_LOWER_EXT  16	/* extension is lower case */

#define IS_FREE(n) (!*(n) || *(const unsigned char *) (n) == DELETED_FLAG || \
  *(const unsigned char *) (n) == FD_FILL_BYTE)

#define SIZEOFBPB16 ( sizeof(FAT_BPBCommon) + sizeof(FAT_BPB16) )
#define SIZEOFBPB32 ( sizeof(FAT_BPBCommon) + sizeof(FAT_BPB32) )

#endif
