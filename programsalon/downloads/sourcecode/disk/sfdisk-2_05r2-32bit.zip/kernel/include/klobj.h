#if defined( Uses_KernelObject ) && !defined( __KernelObject )
#define __KernelObject

#if !defined( __STDDEF_H )
#include <StdDef.h>
#endif  // __STDDEF_H

class TKernelObject
{

public:

	virtual ~TKernelObject(){ }

	static void destroy( TKernelObject * );
	virtual void ShutDown(){ }

private:

};

inline void TKernelObject::destroy( TKernelObject *o )
{
	if( o != 0 )
		o->ShutDown();
	delete o;
}

#endif  // Uses_KernelObject
