#if !defined( __Partition ) && defined( Uses_Partition )
#define __Partition

#define PTTABOFFSET		0x1BE
#define GOODPTID		0xAA55
#define MAXPTNUMBER		4
#define MAXPTTYPENUMBER	45
#define MAXPTNAMELENGTH	15


// Extended State Mask
#define BOOTABLE		0x01               //Partition is bootable
#define PARTCHANGED		0x10               //Partition is changed
#define NEWPARTITION	0x20			   //New Partition
#define ROOTPARTITION   0x02			   //Root Partition

//Struct for all hard disk partition, including hard disk,free space,
//partition logical driver
struct TPartitionRecord
{
	BYTE State;
	BYTE StartHead;
	WORD StartSC;
	BYTE Type;
	BYTE EndHead;
	WORD EndSC;
	DWORD RelativeSector;
	DWORD Sectors;
} __attribute__((packed));

//Struct for partition type
struct TPartitionType
{
	BYTE Type;
	char Name[13];
} __attribute__((packed));

extern TPartitionType PartitionTypes[];

class THardDrive;
class TFileSystem;
struct TBadBlockList;
class TKernelObject;

/****************************************************************************/
/*Class name: TPartition                                                    */
/*Discription:                                                              */
/*    Low level programming interface for Partition                         */
/*    Provide low level logical read, logical write, verify etc.            */
/****************************************************************************/
class TPartition : public TKernelObject
{

public:
	// Constructions
	// THardDrive *hd is the pointer of the Hard Drive object in which the
	// Partition created.
	// TPartition * father is the father of this Partition, it must be a
	// TExtPartition object
	// DWORD RelativeSector is the start relative LBA Address of this Partition
	// DWORD Sectors is the size of this Partition
	TPartition();
	TPartition( THardDrive *hd, TPartition * father,
				TPartitionRecord & record );
	TPartition( THardDrive *hd, TPartition * father,
				BYTE type, DWORD RelativeSector, DWORD Sectors );

	virtual void ShutDown();

	int32 Initialize( THardDrive *hd, TPartition * father, TPartitionRecord & record );
	int32 Initialize( THardDrive *hd, TPartition * father,
					  BYTE type, Boolean IsNew, DWORD RelativeSector,
					  DWORD Sectors );

	int32 Read  ( DWORD BlockNum, WORD BlockCount, void * Buffer );
	int32 Write ( DWORD BlockNum, WORD BlockCount, void * Buffer );
	int32 Verify( DWORD BlockNum, WORD BlockCount );
	int32 Seek  ( DWORD BlockNum );

	int32 Resize( DWORD size );

	virtual int32 WriteChange();		// Write the change of this
										// partition into hard disk
	virtual Boolean IsChanged();

	Boolean IsUseable()
		{ return Useable; }
	Boolean IsBootable()
		{ return (Boolean) ((ExtState & BOOTABLE) != 0); }
	Boolean IsActive()
		{ return (Boolean) (State == HardDrive->GetDriveNumber()); }
	Boolean IsNewPartition()
		{ return (Boolean) ((ExtState & NEWPARTITION) != 0); }
	Boolean IsRootPartition()
		{ return (Boolean) ((ExtState & ROOTPARTITION) != 0); }

	void MarkBootable( Boolean bootable );
	void MarkActive( Boolean active );
	void MarkChanged( Boolean changed );
	void MarkNewPartition( Boolean newPart );
	void MarkRootPartition( Boolean root );

	// Get parameters
	int32 GetRecord(TPartitionRecord & record);		// Get the Partition Record
													// of this Partition

	const char * GetTypeName();						// Get the type name of
													// this Partition
	const char * GetName()
		{ return Name; }
	DWORD GetSizeInMega()
		{ return SizeInMega; }
	DWORD GetRelativeSector()
		{ return RelativeSector; }
	DWORD GetSectors()
		{ return Sectors; }
	DWORD GetAbsSector()            		// Get the abs LBA address
		{ return AbsSector; }       		// of this Partition
	BYTE  GetType()
		{ return Type; }
	BYTE  GetState()
		{ return State; }
	WORD  GetSectorSize();
	DWORD GetBlockSize();

	THardDrive * GetHardDrive()
		{ return HardDrive; }

	void SetName(const char * name);
	void SetType(BYTE type);

	int32 InsertSon( TPartition * son );
	int32 DeleteSon( TPartition * son );
	int32 RemoveSon( TPartition * son );
	void DeleteAllSon();

	TPartition * GetFirstValidSon();
	TPartition * GetLastSon();
	TPartition * FindSon(TPartition *son);
	TPartition * FindSonByIndex( int32 index );
	int32 GetSonIndex( TPartition *part );
	int32 GetValidSonNumber();
	int32 GetTotalSonNumber();		// Get the total number of sons, include
									// free space but not include extension
									// partition which has any son
	int32 GetLevel();

	int32 ChangeFather( TPartition * newFather );

	TFileSystem * GetFileSystem(){ return FileSystem; }

//	TBadBlockList *SurfaceScan( CallBackFunc CallBack=NULL );

private:
	// Calculate the valid relative sector and sectors that compatiable with
	// the old Int13 routing
	DWORD CalcValidRelativeSector( DWORD relative );
	DWORD CalcValidSectors( DWORD sectors );
	DWORD CalcAbsSector( DWORD relative );
	int32 AttachFileSystem();
	void PreInit();

	char Name[MAXPTNAMELENGTH+1];

	DWORD SizeInMega;
	BYTE State;
	BYTE Type;
	BYTE ExtState;
	DWORD RelativeSector;
	DWORD AbsSector;
	DWORD Sectors;

	TFileSystem * FileSystem;

protected:
	Boolean Useable;
	THardDrive *HardDrive;

public:

	TPartition *Father;
	TPartition *Prev;
	TPartition *Next;
	TPartition *Son;
};

#endif // End of __Partition