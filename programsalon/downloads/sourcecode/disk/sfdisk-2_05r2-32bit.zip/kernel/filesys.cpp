/****************************************************************************
 *
 * Smart FDISK
 *
 * This program is a powerful Harddisk Partitioning Tool including a
 * easy-to-use Boot Manager.
 *
 *
 *     Copyright (C) 1999 Suzhe (suzhe@263.net)
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 ****************************************************************************/
/*
 * filesys.cpp : Source file for Class TFileSystem
 */

#define Uses_FileSystem
#define Uses_HardDrive
#define Uses_Partition
#define Uses_DataType

#include "Kernel.H"

DWORD ValidBlockSize[]=
{1024uL, 2048uL, 4096uL, 8192uL, 16384uL, 32768uL};

void TFileSystem::PreInit()
{
	Formated = False;
	Partition = NULL;
	Useable = False;
	BadBlockList = NULL;
    Changed = False;
	FileSysName[0]=0;
}

int32 TFileSystem::Initialize( TPartition *part )
{
	PreInit();

	if( part==NULL || part->IsUseable()==False )
		return 0x200;
	Partition = part;
	Useable=True;
	return 0;
}

void TFileSystem::ShutDown()
{
	DeleteBadBlockList();
	PreInit();
}

Boolean TFileSystem::CanFormat()
{
	if( !IsUseable() ) return False;
	if( Partition->IsChanged() ) return False;
	return True;
}

Boolean TFileSystem::IsFormated()
{
	if( !IsUseable() ) return False;
	return Formated;
}

void TFileSystem::DeleteBadBlockList()
{
	TBadBlockList *point;
	for( point = BadBlockList; point!=NULL;)
	{
		BadBlockList = point->Next;
		delete point;
		point = BadBlockList;
	}
}

TRawFileSystem::TRawFileSystem(TPartition *part)
{
	Initialize(part);
}

int32 TRawFileSystem::Format( CallBackFunc ,int32 , DWORD )
{
	return 1;
}

TBadBlockList *TRawFileSystem::SurfaceScan( CallBackFunc CallBack )
{
	int32 errno,lastErr;
	DWORD sector, temp;
	DWORD delta, amount, percent;
	TBadBlockList *point;
	DWORD Sectors;
	DWORD SizeInMega;

	char *StatusMsg= KernelMsg[0];
	char *EndMsg   = KernelMsg[1];
	char MsgBuf[80];

	if( !IsUseable() ) return NULL;

	DeleteBadBlockList();

	BadBlockList=NULL;
	point=NULL;
	errno=0;
	lastErr=0;

	SizeInMega = Partition ->GetSizeInMega();
	Sectors = Partition->GetSectors();
	delta = 65535ul / Partition->GetSectorSize();
	percent = Sectors / 100uL;
	if( Sectors % 100uL > 50 )
		percent ++;
	for( sector = 0; sector< Sectors; sector += delta )
	{
		if( CallBack!=NULL )
		{
			sprintf( MsgBuf, StatusMsg, SizeInMega, sector / percent );
			if( CallBack( MsgBuf )!=0 ) break;
		}
		amount = delta;
		if( amount > Sectors - sector )
			amount = Sectors - sector;
		errno = Partition->Verify( sector, amount );
		if( errno!=0 )
		{
			for( temp = sector; temp < sector + amount; temp ++ )
			{
				errno = Partition->Verify( temp, 1 );
				if( errno!=0 )
				{
					if( lastErr==0 )
					{
						if( BadBlockList==NULL )
						{
							BadBlockList = point = new TBadBlockList;
							BadBlockList->Next=NULL;
						}
						else
						{
							point->Next = new TBadBlockList;
							point=point->Next;
							point->Next = NULL;
						}
						point->Start = temp;
						point->End = temp;
					}
					else point->End = temp;
				}
				lastErr = errno;
			}
		}
		else lastErr = errno;
	}
	if( CallBack!=NULL )
		CallBack( EndMsg );
	return BadBlockList;
}

int32 TRawFileSystem::GetFileSysInfo( TFileSysInfo &info )
{
	memset( &info, 0, sizeof( TFileSysInfo ) );
	if( !IsUseable() ) return 0x300;

	info.InfoSize = sizeof(info);
	info.Formated = False;
	strncpy( (char*) info.FileSysName, FileSysName, 16 );
	info.FileSysName[15]=0;

	info.TotalKBytes = Partition->GetSectors() / 1024uL * Partition->GetSectorSize();
	info.TotalKBytes += ( (Partition->GetSectors() % 1024uL) *
						Partition->GetSectorSize() ) / 1024uL;
	info.BytesPerBlock = GetBlockSize();
	info.TotalBlocks = Partition->GetSectors();
	info.FreeKBytes = info.TotalKBytes;
	info.FreeBlocks = info.TotalBlocks;

	return 0;
}

DWORD TRawFileSystem::GetBlockSize()
{
	if( !IsUseable() ) return 0;
	return Partition->GetSectorSize();
}

int32 TRawFileSystem::GetBlkSizeInfo( WORD & minIndex, WORD & maxIndex , WORD & defIndex )
{
	minIndex = 0;
	maxIndex = 5;
	defIndex = 0;
	return 0;
}
