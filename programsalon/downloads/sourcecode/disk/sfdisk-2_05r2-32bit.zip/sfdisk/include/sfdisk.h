// Smart FDISK Header File
// Designed by Suzhe 1995.8
#define NDEBUG
#define Uses_TApplication
#define Uses_TMenuBar
#define Uses_TMenuItem
#define Uses_TStatusLine
#define Uses_TStatusItem
#define Uses_TStatusDef
#define Uses_TSubMenu
#define Uses_TDeskTop
#define Uses_TButton
#define Uses_TDialog
#define Uses_TRadioButtons
#define Uses_TInputLine
#define Uses_TScroller
#define Uses_TStaticText
#define Uses_TKeys
#define Uses_TSItem
#define Uses_TLabel
#define Uses_TListBox
#define Uses_TCollection
#define Uses_TStringCollection
#define Uses_TScrollBar
#define Uses_TInputLong
#define Uses_Constant
#define Uses_MsgBox
#define Uses_TVMemMgr

#define Uses_HardDrive
#define Uses_RootPartition
#define Uses_FAT32
#define Uses_FAT16

#include<tv.h>
#include<dos.h>
#include<bios.h>
#include<string.h>
#include<stdio.h>
#include<mem.h>
#include "kernel.h"


#define Uses_Constant
#define Uses_Help
#define Uses_Utility

#if defined( Uses_TInputLong )
#include "TInpLong.h"
#endif

#if defined( Uses_TColoredText )
#include "TColorTX.h"
#endif

#if defined( Uses_Constant )
#include "Constant.h"
#endif

#if defined( Uses_SmartHelp )
#include "Sfhelp.h"
#endif

#if defined( Uses_Utility )
#include "Utility.h"
#endif

#if defined( Uses_DynamicText )
#include "DynaText.h"
#endif

#if defined( Uses_LineCollection )
#include "Linecoll.h"
#endif

#if defined( Uses_PartListBox )
#include "Plistbox.h"
#endif

#if defined( Uses_MyApplication )
#include "MyApp.h"
#endif

#if defined( Uses_Message )
#include "Msg.h"
#endif

#if defined( Uses_HDDialog )
#include "HDDialog.h"
#endif
