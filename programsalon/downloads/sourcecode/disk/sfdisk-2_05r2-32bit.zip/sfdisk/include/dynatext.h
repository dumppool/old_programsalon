#if defined( Uses_DynamicText ) && !defined(__DynamicText)
#define __DynamicText

class far TRect;

class TDynamicText : public TStaticText
{

public:
	TDynamicText( const TRect& bounds, const char *aText);
	virtual void setData( void *rec );
};
#endif    // End of __DynamicText