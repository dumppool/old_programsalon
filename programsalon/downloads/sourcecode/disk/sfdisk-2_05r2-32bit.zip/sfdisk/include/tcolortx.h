#if defined( Uses_TColoredText ) && !defined( __TColoredText )
#define __TColoredText

class far TRect;

class TColoredText : public TStaticText
{

public:

    TColoredText( const TRect& bounds, const char *aText, ushort attribute );

    virtual void draw();
    virtual ushort getTheColor();

protected:

    ushort attr;

private:

    virtual const char *streamableName() const
      { return name; }

protected:

    TColoredText( StreamableInit );
    virtual void write( opstream& );
    virtual void *read( ipstream& );

public:

    static const char * const near name;
    static TStreamable *build();

};

inline ipstream& operator >> ( ipstream& is, TColoredText& cl )
    { return is >> (TStreamable&)cl; }
inline ipstream& operator >> ( ipstream& is, TColoredText*& cl )
    { return is >> (void *&)cl; }

inline opstream& operator << ( opstream& os, TColoredText& cl )
    { return os << (TStreamable&)cl; }
inline opstream& operator << ( opstream& os, TColoredText* cl )
    { return os << (TStreamable *)cl; }

#endif  // Uses_TColoredText

