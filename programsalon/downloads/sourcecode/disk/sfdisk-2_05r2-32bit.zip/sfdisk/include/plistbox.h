#if !defined( __PartListBox ) && defined( Uses_PartListBox )
#define __PartListBox

class TListBox;
class TCollection;
class TPartition;

class TPartCollection : public TCollection
{
public:
	TPartCollection(ccIndex aLimit,ccIndex aDelta) :
		TCollection(aLimit,aDelta){}
	virtual void freeItem(void *p)
		{	delete p; }
private:
	virtual void *readItem( ipstream& ) { return 0; }
	virtual void writeItem( void *, opstream& ) {}
};

class TPartListBox : public TListBox
{
public:
	TPartListBox(const TRect& bounds, ushort aNumCols, TScrollBar * aScrollBar)
		: TListBox(bounds,aNumCols,aScrollBar){}
	void handleEvent(TEvent& event);
	virtual void getText(char *dest,ccIndex item,short maxLen);
    virtual void focusItem(ccIndex item);

	TPartition *getCurrentPart();
	TPartition *getAPart(ccIndex item);
	ccIndex getCurrentPartNum(){ return focused; }
	ccIndex getMaxPartNum(){ return (list()->getCount())-1; }
	ccIndex getPartIndex(TPartition *part);

	void insertBefore(ccIndex item,TPartition *aPart);
	void insertAfter(ccIndex item,TPartition *aPart);
	void appendAPart(TPartition *aPart){ insertBefore(list()->getCount(),aPart); }
	void replaceAPart(ccIndex item,TPartition *aPart);
	void deleteAPart(ccIndex item);
	void removeAPart(ccIndex item);
	void removeAll(){ list()->removeAll(); setRange(0); draw();}
private:
	virtual void *read( ipstream& ) { return 0; }
	virtual void write( void *, opstream& ) {}
};

inline ccIndex TPartListBox::getPartIndex(TPartition *part)
{
	if(!part) return 0;
    return list()->indexOf((void*)part);
}
#endif //End of __PartListBox