//==========1996=5=1==Suzhe============
// Declared TLineCollection
//
// Description: header file for TLineCollection
// linecoll.h
//
// Created by Suzhe 1996-5-1
//
//=====================================
#if !defined( __LineCollection ) && defined( Uses_LineCollection )
#define __LineCollection

//==========1996=5=1==Suzhe============
// TLineCollection
//
// Description: Derived from TCollection
// used to collect text lines
//
// Created by Suzhe 1996-5-1
//
//=====================================
class TLineCollection : public TCollection
{

public:

	TLineCollection(short lim, short delta) : TCollection(lim, delta) {}
	virtual void  freeItem(void *p) { delete p; }

private:

	virtual void *readItem( ipstream& ) { return 0; }
	virtual void writeItem( void *, opstream& ) {}

};

#endif