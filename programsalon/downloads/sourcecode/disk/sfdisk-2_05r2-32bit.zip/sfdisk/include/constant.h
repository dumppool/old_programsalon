#if !defined( __Constant ) && defined( Uses_Constant )
#define __Constant

const int	cmMyCreatePrimary	= 200,
			cmMyCreateLogical	= 201,
			cmMyDelete			= 202,
			cmMyMarkActive		= 203,
			cmMyToggleBootable	= 204,
			cmMyRename			= 205,
			cmMyInformation		= 206,
			cmMyInstBtMgr		= 210,
			cmMyUninstBtMgr		= 211,
			cmMySave			= 220,
			cmMyFormat			= 230,
			cmMyRepairMBR		= 231,
			cmMySurfaceScan		= 232,
            cmMyChangePartType	= 233,
			cmMyHelp			= 240,
			cmMyAbout			= 241,
			cmMyContents	    = 242,
			cmMyHelpOnUse		= 243,
			cmMyFocusPart		= 250,
			cmMyNextDrive		= 251,
			cmMyPrevDrive		= 252;
#endif //End of __Constant