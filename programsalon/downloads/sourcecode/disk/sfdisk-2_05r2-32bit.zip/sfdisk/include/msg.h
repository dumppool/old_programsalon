#if !defined( __Message ) && defined( Uses_Message )
#define __Message

struct TMessageRecord
{
	ushort Code;
	char *Msg;
};

extern TMessageRecord *MsgTable;
extern TMessageRecord EnglishMsg[];
extern TMessageRecord ChineseMsg[];


void InitMessage( ushort language );
char * getMessage( ushort code );

#endif // End of __Message
