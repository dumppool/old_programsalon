#if !defined( __HDDialog ) && defined( Uses_HDDialog )
#define __HDDialog
#define MAXHDNUMBER		16

extern Boolean ShouldRestart;
extern Boolean UseInt13Ext;

class TPartListBox;
class TDynamicText;
class TRootPartition;
class TPartition;
class TBootManager;
class THardDrive;

class THDDialog : public TDialog
{
public:
	THDDialog( Boolean UseInt13Ext );
	THDDialog( StreamableInit ) :
		   TDialog (streamableInit),
		   TWindowInit(THDDialog::initFrame) {};

	virtual void handleEvent( TEvent& event );
	virtual void shutDown();

	short Initialize( Boolean UseInt13Ext );

private:
	void PreInit();
	void InitDialog();

	void UpdateList();
	void setCommandState(TPartition *part);

	void DispBtmgrStatus();
	void DispEBiosStatus();
	void DispDriveStatus();

	void myCreatePrimary();
	void myCreateLogical();
	void myToggleBootable();
	void myRename();
	void myMarkActive();
	void myDelete();
	void mySaveChanges();
	void myInstallBtMgr();
	void myUninstallBtMgr();
	void myFormat();
	void mySurfaceScan();
	void myInformation();
	void myRepairMBR();
	void myNextDrive();
	void myPrevDrive();
	void myChangePartType();

//Data member
	TPartListBox *PartListBox;
	TDynamicText *DriveIDText;
	TDynamicText *BootMgrStatusText;
	TDynamicText *EBiosStatusText;
	TDynamicText *SizeText;
	TDynamicText *CylindersText;
	TDynamicText *SectorsText;
	TDynamicText *HeadsText;

	THardDrive *HardDrives[MAXHDNUMBER];
	TRootPartition *Roots[MAXHDNUMBER];
	TBootManager *BootMgrs[MAXHDNUMBER];

	ushort DriveNumber;
	ushort curDrive;

};

#endif  //End of __HDDialog