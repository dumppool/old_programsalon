// Smart FDISK Header File -- UTILITY
// Designed by Suzhe 1995.8

#if !defined( __Utility ) && defined( Uses_Utility )
#define __Utility

char * NumToString( char * str, long num );

void Restart();
Boolean CheckWindows();
#endif  //End of __Utility