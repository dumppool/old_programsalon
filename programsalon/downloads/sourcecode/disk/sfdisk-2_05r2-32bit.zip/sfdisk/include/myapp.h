// Smart FDISK Header File -- Application
// Designed by Suzhe 1998.8

#if !defined( __MyApplication) && defined( Uses_MyApplication )
#define __MyApplication

extern Boolean UseInt13Ext;

class THDDialog;
// class THeapView;

class MyApplication: public TApplication
{
public:
	MyApplication();
	~MyApplication();
	virtual void handleEvent(TEvent& event);
	virtual void getEvent(TEvent& event);
    virtual TPalette& getPalette() const;
	static TMenuBar *initMenuBar( TRect );
	static TStatusLine *initStatusLine( TRect );
	virtual void outOfMemory();
//	virtual void idle();              // Updates heap and clock views
private:
	void aboutBox();
	THDDialog *HDDialog;
//	TIDEMemInfo *memInfo;
};


class TMyStatusLine : public TStatusLine
{
public:
	TMyStatusLine(const TRect& bounds, TStatusDef& aDefs) :
		TStatusLine( bounds, aDefs ){}

	virtual const char* hint(ushort aHelpCtx);
};

#endif  //End of __MyApplication
