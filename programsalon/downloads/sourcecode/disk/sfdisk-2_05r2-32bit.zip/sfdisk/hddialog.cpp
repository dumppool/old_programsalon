/****************************************************************************
 *
 * Smart FDISK
 *
 * This program is a powerful Harddisk Partitioning Tool including a
 * easy-to-use Boot Manager.
 *
 *
 *     Copyright (C) 1999 Suzhe (suzhe@263.net)
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 ****************************************************************************/
/*
 * hddialog.cpp : Source file for Class THDDialog
 */

#define Uses_TCheckBoxes
#define Uses_Utility
#define Uses_HDDialog
#define Uses_PartListBox
#define Uses_Constant
#define Uses_LineCollection
#define Uses_SmartHelp
#define Uses_DynamicText
#define Uses_Message

#define Uses_Partition
#define Uses_RootPartition
#define Uses_BootManager
#define Uses_FileSystem

#include"sfdisk.h"
#include"stdlib.h"

#if !defined(__TListBoxRec)
#define __TListBoxRec
struct TListBoxRec
{
	TCollection* collection __attribute__((packed));
	ccIndex focused __attribute__((packed));
};
#endif

struct TInfoDlgData
{
	TDynamicText *FileSysName;
	TDynamicText *Formated;
	TDynamicText *TotalSpace;
	TDynamicText *ReservedSpace;
    TDynamicText *UsedSpace;
	TDynamicText *FreeSpace;
	TDynamicText *BlockSize;
	TDynamicText *TotalBlocks;
	TDynamicText *FreeBlocks;
	TDynamicText *BadBlocks;
};

struct TBadBlkDlgData
{
	TDynamicText *BlockSize;
	TListBox *BadBlockList;
	TDynamicText *Total;
};

struct TCreatePTDlgData
{
	long Size __attribute__((packed));   //TInputLong
	TListBoxRec Type __attribute__((packed));   //TListBox
	ushort Position __attribute__((packed));   //TRadioButtons
};

struct TFormatDlgData
{
	ushort FormatType __attribute__((packed));   //TRadioButtons
	TListBoxRec BlockSize __attribute__((packed));   //TListBox
	ushort ShowSummary __attribute__((packed));
};

struct TInstBtmgrDlgData
{
	ushort Language __attribute__((packed));   //TRadioButtons
	ushort VirusCheck __attribute__((packed));   //TCheckBoxes
	long DelayTime __attribute__((packed));   //TInputLong
	ushort AutoHide __attribute__((packed));
};

static ushort ValidPartTypeIndex[] =
{
	11, 6, 7, 31, 30, 36, 29, 28, 26, 25, 24, 2, 3, 8, 9,
	18, 20, 21, 22, 23, 27, 33, 34, 37, 38, 39, 40, 44, 0
};

bool ShouldRestart;
bool IsChanged;
bool UseInt13Ext=true;

static TDynamicText *statusText;

TDialog* makeRenameDlg(void);
TDialog* makeInstBtmgrDlg(void);
TDialog* makeCreatePTDlg(char * title, long minSize, long maxSize);
TDialog* makeFormatDlg( );
TDialog* makePartInfoDlg( TInfoDlgData &data);
TDialog* makeBadBlkDlg( TBadBlkDlgData &data);
TDialog* makeChgPartTypeDlg();


short CallBack( char * msg );

void DispErrorMsg( char * msg, short errno )
{
	messageBox( mfError|mfOKButton,getMessage(0x40),
				msg, GetKernelErrorMsg( errno ) );
}


THDDialog::THDDialog( bool UseInt13Ext ) :
	   TDialog(TRect(1, 1, 79, 21), getMessage(0x41)),
       TWindowInit(THDDialog::initFrame)
{
	Initialize( UseInt13Ext );
}

void THDDialog::shutDown()
{
	for( curDrive=0; curDrive< DriveNumber; curDrive++ )
	{
		if( Roots[curDrive]!=NULL && Roots[curDrive]->IsUseable() &&
			Roots[curDrive]->IsChanged() )
			if(messageBox(mfConfirmation|mfYesButton|mfNoButton,getMessage(0x42),
				HardDrives[curDrive]->GetDriveNumber() - MINDRIVENUM + 1)==cmYes)
				mySaveChanges();
	TKernelObject::destroy(HardDrives[curDrive]);
	TKernelObject::destroy(Roots[curDrive]);
	TKernelObject::destroy(BootMgrs[curDrive]);
	HardDrives[curDrive] = NULL;
	Roots[curDrive] = NULL;
	BootMgrs[curDrive] = NULL;
	}
}

void THDDialog::PreInit()
{
	for( int i=0; i< MAXHDNUMBER; i++ )
	{
		HardDrives[i]	= NULL;
		Roots[i]		= NULL;
		BootMgrs[i]		= NULL;
	}

	DriveNumber		= 0;
	curDrive		= 0;

	PartListBox			= NULL;
	DriveIDText			= NULL;
	BootMgrStatusText	= NULL;
	EBiosStatusText		= NULL;
	SizeText			= NULL;
	CylindersText		= NULL;
	SectorsText			= NULL;
	HeadsText			= NULL;
	ShouldRestart		= false;
	IsChanged			= false;
}

void THDDialog::InitDialog()
{
	TView *control;
	options |= ofCenterX | ofCenterY;
	flags &= ~wfClose;
	helpCtx = hcHDWindow;

	control = new TStaticText(TRect(2, 2, 16, 3), getMessage(0x43));
	insert(control);

	control = new TStaticText(TRect(2, 3, 16, 4), getMessage(0x44));
	insert(control);

	control = new TStaticText(TRect(2, 4, 16, 5), getMessage(0x45));
	insert(control);

	control = new TStaticText(TRect(2, 5, 16, 6), getMessage(0x46));
	insert(control);

	control = new TStaticText(TRect(38, 2, 48, 3), getMessage(0x47));
	insert(control);

	control = new TStaticText(TRect(38, 4, 48, 5), getMessage(0x48));
	insert(control);

	control = new TStaticText(TRect(38, 3, 48, 4), getMessage(0x49));
	insert(control);

	control = new TStaticText(TRect(3, 6, 75, 7),getMessage(0x4A));
	insert(control);

	control = new TScrollBar(TRect(74, 8, 75, 18));
	insert(control);

	PartListBox = new TPartListBox(TRect(3, 8, 74, 18), 1, (TScrollBar*)control);
	PartListBox->helpCtx = hcHDWindow;
	insert(PartListBox);

	insert(new TLabel(TRect(3, 7, 74, 8),getMessage(0x4B),PartListBox));

	control = new TStaticText(TRect(3, 7, 4, 8), getMessage(0x4C));
	insert(control);

	control = new TStaticText(TRect(74, 7, 75, 8), getMessage(0x4C));
	insert(control);

	control = new TButton(TRect(58, 2, 75, 4), getMessage(0x4E), cmMyPrevDrive, bfNormal);
	control->helpCtx = hcHDWindow;
	insert(control);

	control = new TButton(TRect(58, 4, 75, 6), getMessage(0x4D), cmMyNextDrive, bfNormal);
	control->helpCtx = hcHDWindow;
	insert(control);

	DriveIDText = new TDynamicText(TRect(17, 2, 35, 3), 0);
	insert(DriveIDText);

	BootMgrStatusText = new TDynamicText(TRect(17, 3, 35, 4), 0);
	insert(BootMgrStatusText);

	EBiosStatusText = new TDynamicText(TRect(17, 4, 35, 5), 0);
	insert(EBiosStatusText);

	SizeText = new TDynamicText(TRect(17, 5, 35, 6), 0);
	insert(SizeText);

	CylindersText = new TDynamicText(TRect(49, 2, 57, 3), 0);
	insert(CylindersText);

	SectorsText = new TDynamicText(TRect(49, 3, 57, 4), 0);
	insert(SectorsText);

	HeadsText = new TDynamicText(TRect(49, 4, 57, 5), 0);
	insert(HeadsText);

	selectNext(false);

	PartListBox->newList(new TPartCollection(8,1));
}

short THDDialog::Initialize( bool UseInt13Ext )
{
	short errno;
	PreInit();

	InitDialog();
	DriveNumber = GetHDNumber();

	if( DriveNumber == 0 )
	{
		messageBox(getMessage(0x4F), mfError|mfOKButton);
		return 1;
	}

	if( DriveNumber > MAXHDNUMBER ) DriveNumber = MAXHDNUMBER;

	for( int i=0; i< DriveNumber; i++ )
	{
		HardDrives[i] = new THardDrive;
		Roots[i] = new TRootPartition;
		BootMgrs[i] = new TBootManager;

		if( HardDrives[i] == NULL || Roots[i] == NULL || BootMgrs[i] == NULL )
		{
			messageBox(getMessage(0x29),mfError|mfOKButton);
			return 1;
		}

		if( (errno = HardDrives[i]->Initialize( (short)(i) , (bool)UseInt13Ext )) == 0 )
			if( (errno = Roots[i]->Initialize( HardDrives[i] )) == 0 )
				errno = BootMgrs[i]->Initialize( Roots[i] );

		if( errno != 0 )
		{
			messageBox( mfError|mfOKButton, getMessage(0x50),
						i+1, GetKernelErrorMsg( errno ) );
		}
	}

	DispBtmgrStatus();
	DispEBiosStatus();
	DispDriveStatus();

	UpdateList();

	return 0;
}

void THDDialog::handleEvent( TEvent& event )
{
	switch(event.what)
	{
		case evBroadcast:
			if(event.message.command==cmMyFocusPart)
			{
				setCommandState((TPartition*)event.message.infoPtr);
				clearEvent(event);
			}
			else if(event.message.command==cmReceivedFocus &&
					event.message.infoPtr==this)
				setCommandState(PartListBox->getCurrentPart());
			break;
		case evCommand:
			if(DriveNumber > 0 && curDrive < DriveNumber &&
				Roots[curDrive] != NULL &&
				Roots[curDrive]->IsUseable() )
			{
				switch(event.message.command)
				{
					case cmMyCreatePrimary:
						myCreatePrimary();
						clearEvent(event);
						break;
					case cmMyCreateLogical:
						myCreateLogical();
						clearEvent(event);
						break;
					case cmMyDelete:
						myDelete();
						clearEvent(event);
						break;
					case cmMyMarkActive:
						myMarkActive();
						clearEvent(event);
						break;
					case cmMyToggleBootable:
						myToggleBootable();
						clearEvent(event);
						break;
					case cmMyRename:
						myRename();
						clearEvent(event);
						break;
					case cmMyInformation:
						myInformation();
						clearEvent(event);
						break;
					case cmMyInstBtMgr:
						myInstallBtMgr();
						clearEvent(event);
						break;
					case cmMyUninstBtMgr:
						myUninstallBtMgr();
						clearEvent(event);
						break;
					case cmMySave:
						mySaveChanges();
						clearEvent(event);
						break;
					case cmMyFormat:
						myFormat();
						clearEvent(event);
						break;
					case cmMySurfaceScan:
						mySurfaceScan();
						clearEvent(event);
						break;
					case cmMyRepairMBR:
						myRepairMBR();
						clearEvent(event);
						break;
					case cmMyNextDrive:
						myNextDrive();
						clearEvent(event);
						break;
					case cmMyPrevDrive:
						myPrevDrive();
						clearEvent(event);
						break;
                    case cmMyChangePartType:
                    	myChangePartType();
                        clearEvent(event);
                        break;
				}
			}
			break;
	}
	TDialog::handleEvent(event);
}

void THDDialog::UpdateList()
{
	ccIndex current;
	short total;
	TPartition *part;

	if( curDrive >= DriveNumber ||
		Roots[curDrive] == NULL ||
		!Roots[curDrive]->IsUseable() )
		return;

	lock();

	current = PartListBox->getCurrentPartNum();
	total = Roots[curDrive]->GetTotalSonNumber();

	PartListBox->removeAll();

	for( short i=total-1; i>=0; i-- )
	{
		part = Roots[curDrive]->FindSonByIndex( i );
		if( part!=NULL && part->IsUseable() )
			PartListBox->insertBefore( 0, part );
	}

	PartListBox->focusItem( current );
	PartListBox->drawView();
	unlock();
}

void THDDialog::setCommandState( TPartition *part)
{
	if( DriveNumber <= 0 ||
		curDrive >= DriveNumber ||
		Roots[curDrive] == NULL ||
		!Roots[curDrive]->IsUseable() )
	{
		disableCommand(cmMyCreatePrimary);
		disableCommand(cmMyCreateLogical);
		disableCommand(cmMyDelete);
		disableCommand(cmMyMarkActive);
		disableCommand(cmMyToggleBootable);
		disableCommand(cmMyRename);
		disableCommand(cmMyInformation);
		disableCommand(cmMyInstBtMgr);
		disableCommand(cmMyUninstBtMgr);
		disableCommand(cmMySave);
		disableCommand(cmMyFormat);
		disableCommand(cmMySurfaceScan);
		disableCommand(cmMyRepairMBR);
	}
	else
	{
		if( BootMgrs[curDrive] != NULL )
		{
			if( BootMgrs[curDrive]->IsUseable() &&
				BootMgrs[curDrive]->CanInstall() )
				enableCommand(cmMyInstBtMgr);
			else disableCommand(cmMyInstBtMgr);

			if( BootMgrs[curDrive]->IsUseable() &&
				( BootMgrs[curDrive]->IsKernelInst() ||
					BootMgrs[curDrive]->IsLoaderInst()) )
				enableCommand(cmMyUninstBtMgr);
			else disableCommand(cmMyUninstBtMgr);
		}
		else
		{
			disableCommand(cmMyInstBtMgr);
			disableCommand(cmMyUninstBtMgr);
		}

		if( part==NULL || !part->IsUseable() ||
			Roots[curDrive]->GetSonIndex(part) < 0 )
		{
			disableCommand(cmMyCreatePrimary);
			disableCommand(cmMyCreateLogical);
			disableCommand(cmMyDelete);
			disableCommand(cmMyMarkActive);
			disableCommand(cmMyToggleBootable);
			disableCommand(cmMyRename);
			disableCommand(cmMyInformation);
			disableCommand(cmMyFormat);
			disableCommand(cmMySurfaceScan);
		}
		else
		{
			if( Roots[curDrive]->CanCreatePrimary(part) )
				enableCommand(cmMyCreatePrimary);
			else disableCommand(cmMyCreatePrimary);

			if( Roots[curDrive]->CanCreateLogical(part) )
				enableCommand(cmMyCreateLogical);
			else disableCommand(cmMyCreateLogical);

			if( part->GetType()!=0 &&
				part->GetFileSystem() != NULL &&
				part->GetFileSystem()->IsUseable() )
				enableCommand(cmMyInformation);
			else disableCommand(cmMyInformation);

			if( Roots[curDrive]->CanDelete(part) )
				enableCommand(cmMyDelete);
			else disableCommand(cmMyDelete);

			if( Roots[curDrive]->CanBoot(part) &&
				BootMgrs[curDrive]->IsInstalled() )
			{
				enableCommand(cmMyToggleBootable);
				enableCommand(cmMyRename);
			}
			else
			{
				disableCommand(cmMyToggleBootable);
				disableCommand(cmMyRename);
			}

			if( Roots[curDrive]->CanActive(part) )
				enableCommand(cmMyMarkActive);
			else disableCommand(cmMyMarkActive);

			if( Roots[curDrive]->CanFormat(part))
				enableCommand(cmMyFormat);
			else disableCommand(cmMyFormat);

			if( Roots[curDrive]->CanSurfaceScan(part) )
				enableCommand(cmMySurfaceScan);
			else disableCommand(cmMySurfaceScan);
		}
	}

	if( curDrive < DriveNumber - 1 && curDrive > 0 )
	{
		enableCommand(cmMyNextDrive);
		enableCommand(cmMyPrevDrive);
	}
	else if( curDrive == 0 && curDrive < DriveNumber - 1)
	{
		enableCommand(cmMyNextDrive);
		disableCommand(cmMyPrevDrive);
	}
	else if( curDrive > 0 &&  curDrive == DriveNumber -1 )
	{
		disableCommand(cmMyNextDrive);
		enableCommand(cmMyPrevDrive);
	}
	else
	{
		disableCommand(cmMyNextDrive);
		disableCommand(cmMyPrevDrive);
	}
}

void THDDialog::DispBtmgrStatus()
{
	char *status;
	if( BootMgrStatusText == NULL ) return;

	if( curDrive >= DriveNumber || BootMgrs[curDrive] == NULL ||
		!BootMgrs[curDrive]->IsUseable() )
		status=getMessage(0x51);
	else if( BootMgrs[curDrive]->IsKernelInst() &&
		!BootMgrs[curDrive]->IsLoaderInst() )
		status=getMessage(0x52);
	else if( !BootMgrs[curDrive]->IsKernelInst() &&
		BootMgrs[curDrive]->IsLoaderInst() )
		status=getMessage(0x53);
	else if( BootMgrs[curDrive]->IsInstalled() )
		status=getMessage(0x54);
	else status=getMessage(0x55);

	BootMgrStatusText->setData(status);
}

void THDDialog::DispEBiosStatus()
{
	char status[40];
	if( EBiosStatusText == NULL ) return;

	if( curDrive >= DriveNumber || HardDrives[curDrive] == NULL ||
		!HardDrives[curDrive]->IsUseable() )
		strcpy(status,getMessage(0x51));
	else if( HardDrives[curDrive]->IsInt13ExtPresent() )
	{
		strcpy(status ,getMessage(0x56));
		if( !UseInt13Ext )
			strcat(status, getMessage(0x57));
	}
	else strcpy(status ,getMessage(0x58));

	EBiosStatusText->setData(status);
}
void THDDialog::DispDriveStatus()
{
	char *status, num[16];
	TDiskGeometry geometry;
//	DWORD temp;

	if( curDrive >= DriveNumber || HardDrives[curDrive] == NULL ||
		!HardDrives[curDrive]->IsUseable() )
	{
		status=getMessage(0x59);
		if( SizeText!=NULL ) SizeText->setData(status);
		if(CylindersText!=NULL) CylindersText->setData(status);
		if(SectorsText!=NULL) SectorsText->setData(status);
		if(HeadsText!=NULL) HeadsText->setData(status);
		if(DriveIDText!=NULL) DriveIDText->setData(status);
	}
	else
	{
		HardDrives[curDrive]->GetGeometry(geometry);

		sprintf( num,"%2d",HardDrives[curDrive]->GetDriveNumber() - MINDRIVENUM + 1);
		if(DriveIDText!=NULL)
			DriveIDText->setData(num);

		if( SizeText!=NULL )
			SizeText->setData( NumToString( num,
				HardDrives[curDrive]->GetSizeInMega() ) );

		if(CylindersText!=NULL)
			CylindersText->setData( NumToString( num, geometry.Cylinders ) );

		if(SectorsText!=NULL)
			SectorsText->setData( NumToString( num, geometry.SectorsPerTrack ) );

		if(HeadsText!=NULL)
			HeadsText->setData( NumToString( num, geometry.Heads ) );
	}
}

void THDDialog::myCreatePrimary()
{
	short errno;
	TDialog *dlg;
	ushort result;
	TCreatePTDlgData data;

	TPartition *part;
	if( Roots[curDrive] == NULL || !Roots[curDrive]->IsUseable() )
		return;
	part = PartListBox->getCurrentPart();
	if( !Roots[curDrive]->CanCreatePrimary( part ) )
		return;
	dlg = makeCreatePTDlg( getMessage(0x70),(part->GetSizeInMega()>0) ? 1 : 0,
			part->GetSizeInMega() );

	if( dlg != NULL )
	{
		data.Size = part->GetSizeInMega();
		data.Type.collection = new TLineCollection(20,1);
		for( int i=0; ValidPartTypeIndex[i] != 0; i ++ )
			data.Type.collection->
				insert( newStr( PartitionTypes[ ValidPartTypeIndex[i] ].Name ) );
		data.Type.focused = 0;
		data.Position = 0;
		dlg->setData( &data );
		result=TProgram::deskTop->execView(dlg);
		dlg->getData(&data);
		destroy(dlg);
		if( result == cmOK )
		{
			if( (errno=Roots[curDrive]->CreatePrimary( part,
				PartitionTypes[ ValidPartTypeIndex[data.Type.focused] ].Type,
				data.Size, data.Position )) != 0 )
				DispErrorMsg( getMessage(0x72), errno );
			UpdateList();
			IsChanged = true;
		}
		destroy( data.Type.collection );
	}
}

void THDDialog::myCreateLogical()
{
	short errno;
	TDialog *dlg;
	ushort result;
	TCreatePTDlgData data;

	TPartition *part;
	if( Roots[curDrive] == NULL || !Roots[curDrive]->IsUseable() )
		return;
	part = PartListBox->getCurrentPart();
	if( !Roots[curDrive]->CanCreateLogical( part ) )
		return;
	dlg = makeCreatePTDlg( getMessage(0x71),(part->GetSizeInMega()>0) ? 1 : 0,
			part->GetSizeInMega() );

	if( dlg != NULL )
	{
		data.Size = part->GetSizeInMega();
		data.Type.collection = new TLineCollection(20,1);
		for( int i=0; ValidPartTypeIndex[i] != 0; i ++ )
			data.Type.collection->
				insert( newStr( PartitionTypes[ ValidPartTypeIndex[i] ].Name ) );
		data.Type.focused = 0;
		data.Position = 0;
		dlg->setData( &data );
		result=TProgram::deskTop->execView(dlg);
		dlg->getData(&data);

		destroy(dlg);
		if( result == cmOK )
		{
			if( (errno=Roots[curDrive]->CreateLogical( part,
				PartitionTypes[ ValidPartTypeIndex[data.Type.focused] ].Type,
				data.Size, data.Position )) != 0 )
				DispErrorMsg( getMessage(0x72), errno );
			UpdateList();
			IsChanged = true;
		}
		destroy( data.Type.collection );
	}
}

void THDDialog::myToggleBootable()
{
	short errno;
	TPartition *part;

	if( Roots[curDrive] == NULL || !Roots[curDrive]->IsUseable() )
		return;
	part = PartListBox->getCurrentPart();
	if( !Roots[curDrive]->CanBoot( part ) )
		return;
	if( strlen( part->GetName() ) == 0 && !part->IsBootable() )
	{
    	myRename();
        if( strlen( part->GetName() ) == 0 )
			messageBox(getMessage(0x73),mfInformation|mfOKButton );
		return;
	}

	if( (errno = Roots[curDrive]->ToggleBootable( part )) != 0 )
		DispErrorMsg( getMessage(0x74),errno );

	PartListBox->drawView();
}

void THDDialog::myRename()
{
	char name[17];
	ushort result;
	TDialog *dlg;
	int i;

	TPartition *part;
	if( Roots[curDrive] == NULL || !Roots[curDrive]->IsUseable() )
		return;
	part = PartListBox->getCurrentPart();
	if( Roots[curDrive]->GetSonIndex( part ) < 0 )
		return;

	dlg = makeRenameDlg();

	if( dlg!=NULL )
	{
		strncpy( name, part->GetName(), 15);
		name[15]=0;

		for(i = strlen(name) - 1; name[i] == 0x20 && i>=0; i-- );

		name[i+1] = 0;

		dlg->setData(name);
		result=TProgram::deskTop->execView(dlg);
		dlg->getData(name);
		destroy(dlg);
		if( result == cmOK )
		{
			for(i = strlen(name) - 1; name[i] == 0x20 && i>=0; i-- );

			name[i+1] = 0;
			part->SetName( name );
			if( (strlen(name) > 0 && !part->IsBootable()) ||
				(strlen(name) == 0 && part->IsBootable()) )
				Roots[curDrive]->ToggleBootable( part );
			part->MarkChanged( true );
			PartListBox->drawView();
		}
	}
}

void THDDialog::myMarkActive()
{
	short errno;
	TPartition *part;
	if( Roots[curDrive] == NULL || !Roots[curDrive]->IsUseable() )
		return;
	part = PartListBox->getCurrentPart();
	if( Roots[curDrive]->GetSonIndex( part ) < 0 )
		return;
	if( (errno=Roots[curDrive]->MarkAsActive( part )) != 0 )
		DispErrorMsg( getMessage(0x75), errno );

	PartListBox->drawView();
}

void THDDialog::myDelete()
{
	short errno;

	TPartition *part;
	if( Roots[curDrive] == NULL || !Roots[curDrive]->IsUseable() )
		return;
	part = PartListBox->getCurrentPart();

	if( !Roots[curDrive]->CanDelete( part ) )
		return;
	if( messageBox(getMessage(0x76),mfConfirmation|mfYesButton|mfNoButton )	== cmYes )
	{
		if( (errno=Roots[curDrive]->Delete( part )) != 0 )
			DispErrorMsg(getMessage(0x77), errno );

		UpdateList();
	}
}

void THDDialog::mySaveChanges()
{
	short errno;
	char msg[60];
	TDialog *status;

	if( Roots[curDrive] == NULL || !Roots[curDrive]->IsUseable() )
		return;


	sprintf(msg,getMessage(0x78), curDrive + 1 );

	status=new TDialog(TRect(0,0,43,5),getMessage(0x79));
	status->options|=ofCentered;

	statusText = new TDynamicText(TRect(3,2,40,3),NULL);
	statusText->setData( msg );

	status->insert(statusText);
	TProgram::deskTop->insert(status);

	delay( 500 );

	if( (errno=Roots[curDrive]->WriteChange()) != 0 )
		DispErrorMsg(getMessage(0x7A), errno );

	if( IsChanged )
		ShouldRestart = true;

	if( BootMgrs[curDrive] != NULL && BootMgrs[curDrive]->IsKernelInst() )
		if( (errno=BootMgrs[curDrive]->WriteBootMenu()) != 0 )
			DispErrorMsg(getMessage(0x7B), errno );

	TProgram::deskTop->remove(status);
	destroy(status);

	setCommandState( PartListBox->getCurrentPart() );
}

void THDDialog::myInstallBtMgr()
{
	TDialog *dlg;
	ushort result;
	short errno;
	TInstBtmgrDlgData data;
	TBootMgrInstData instData;
//    TPartition *part;
//    short TotalSon;

	if( BootMgrs[curDrive] == NULL ||
		!BootMgrs[curDrive]->IsUseable() ||
		!BootMgrs[curDrive]->CanInstall() )
		return;
	dlg = makeInstBtmgrDlg();
	if( dlg != NULL )
	{
		data.Language = BTMGRCHN;
		data.VirusCheck = VIRCHECKINT13;
		data.DelayTime = 30;
		data.AutoHide = 0;

		dlg->setData(&data);
		result=TProgram::deskTop->execView(dlg);
		dlg->getData(&data);
		destroy(dlg);
		if( result == cmOK )
		{
			instData.Language = data.Language;
			instData.VirusCheck = data.VirusCheck;
			instData.DelayTime = (WORD) data.DelayTime;
			instData.AutoHide = data.AutoHide;

			if( (errno = BootMgrs[curDrive]->Install( instData )) != 0 )
				DispErrorMsg(getMessage(0x7C), errno );
			else
			{
            	if( !Roots[curDrive]->IsChanged() &&
					BootMgrs[curDrive]->IsKernelInst() &&
					(errno=BootMgrs[curDrive]->WriteBootMenu()) != 0 )
					DispErrorMsg(getMessage(0x7B), errno );
                else messageBox(getMessage(0x7D),mfInformation|mfOKButton);
            }
			DispBtmgrStatus();
			PartListBox->drawView();
			setCommandState( PartListBox->getCurrentPart() );
		}
	}
}

void THDDialog::myUninstallBtMgr()
{
	short errno;

	if( BootMgrs[curDrive] == NULL ||
		!BootMgrs[curDrive]->IsUseable() )
		return;
	if( messageBox( getMessage(0x7E),
		mfConfirmation|mfYesButton|mfNoButton ) == cmYes )
	{
		if( (errno = BootMgrs[curDrive]->Uninstall()) != 0 )
			DispErrorMsg( getMessage(0x7F), errno );
		DispBtmgrStatus();
		PartListBox->drawView();
		setCommandState( PartListBox->getCurrentPart() );
	}
}

short CallBack( char * msg )
{
	int key;
	if( statusText != NULL )
		statusText->setData( msg );
	key  = bioskey(1);
	if( key!=0 ) bioskey(0);
	if( key == kbEsc )
		return 1;
	return 0;
}

void THDDialog::myFormat()
{
	short errno;
	ushort result;
	TDialog *dlg, *status;
	TFormatDlgData data;
	TPartition *part;
	TFileSystem *fs;
	char temp[16],temp1[10];
	ushort minIndex, maxIndex, defIndex;

	if( Roots[curDrive] == NULL || !Roots[curDrive]->IsUseable() )
		return;
	part = PartListBox->getCurrentPart();
	if( ! Roots[curDrive]->CanFormat( part ) )
		return;

	if( messageBox(getMessage(0x80), mfConfirmation|mfYesButton|mfNoButton ) != cmYes )
		return;

	dlg = makeFormatDlg();
	if( dlg != NULL )
	{
		fs = part->GetFileSystem();
		fs->GetBlkSizeInfo( minIndex, maxIndex , defIndex);

		data.FormatType = QUICKFORMAT;
		data.BlockSize.collection = new TLineCollection( maxIndex - minIndex + 1, 1 );


		for( int i=minIndex; i<=maxIndex; i++ )
		{
			sprintf(temp,getMessage(0x81), NumToString( temp1, ValidBlockSize[i] ));
			data.BlockSize.collection->insert(newStr(temp));
		}

		data.BlockSize.focused = defIndex - minIndex;
		data.ShowSummary = 0;

		dlg->setData( &data );
		result=TProgram::deskTop->execView(dlg);
		dlg->getData( &data );
		destroy(dlg);
		if( result == cmOK )
		{
			status=new TDialog(TRect(0,0,48,5),getMessage(0x82));
			status->options|=ofCentered;

			statusText = new TDynamicText(TRect(3,2,45,3),NULL);
			status->insert(statusText);
			TProgram::deskTop->insert(status);

			errno = fs->Format( CallBack, data.FormatType,
							ValidBlockSize[ data.BlockSize.focused + minIndex ] );

			if( errno!= 0 )
				DispErrorMsg( getMessage(0x83), errno );
			else if( data.ShowSummary == 0)
				messageBox( getMessage(0x84), mfInformation|mfOKButton );
			else myInformation();

			TProgram::deskTop->remove(status);
			destroy(status);

			PartListBox->drawView();
			IsChanged = true;
		}
		destroy( data.BlockSize.collection );
	}
}

void THDDialog::mySurfaceScan()
{
	TDialog *dlg,*status;
	TBadBlkDlgData data;
	TBadBlockList *list, *point;
	char temp[40], temp1[20], temp2[20];
//	short errno, count;
	short count;
	TPartition *part;
	TLineCollection *collection;
	DWORD Total;

	if( Roots[curDrive] == NULL || !Roots[curDrive]->IsUseable() )
		return;
	part = PartListBox->getCurrentPart();
	if( !Roots[curDrive]->CanSurfaceScan( part ) )
		return;

	if( messageBox(getMessage(0x85),mfWarning|mfOKButton|mfCancelButton ) != cmOK )
    	return;

	dlg = makeBadBlkDlg(data);
	if( dlg!=NULL )
	{
		status=new TDialog(TRect(0,0,47,5),getMessage(0x86));
		status->options|=ofCentered;

		statusText = new TDynamicText(TRect(3,2,43,3),NULL);
		status->insert(statusText);
		TProgram::deskTop->insert(status);
		list = part->GetFileSystem()->SurfaceScan( CallBack );

		NumToString( temp, part->GetBlockSize() );
		strcat(temp,getMessage(0x87));
		data.BlockSize->setData( temp );

		collection = new TLineCollection( 8, 1 );

		Total = 0;

		if( list == NULL )
			collection->insert(newStr(getMessage(0x88)));
		else
		{
			for( count=1, point=list; point!=NULL; point=point->Next, count++ )
			{
				sprintf(temp,"%2d. %-11s %-11s",count,
						NumToString(temp1, point->Start),
						NumToString(temp2, point->End));
				collection->insert(newStr(temp));
				Total += point->End - point->Start + 1uL;
			}
		}
		data.BadBlockList->newList(collection);

		data.Total->setData( NumToString( temp, Total ) );

		TProgram::deskTop->execView( dlg );
		destroy( dlg );
		TProgram::deskTop->remove(status);
		destroy( status );
		destroy(collection);
	}
}

void THDDialog::myInformation()
{
	TDialog *dlg, *status;
	TInfoDlgData data;
	TFileSystem *fs;
	TPartition *part;
	TFileSysInfo info;
	char temp[40], temp1[20];
	short errno;

	if( Roots[curDrive] == NULL || !Roots[curDrive]->IsUseable() )
		return;
	part = PartListBox->getCurrentPart();
	if( Roots[curDrive]->GetSonIndex( part ) < 0 )
		return;

	fs = part->GetFileSystem();
	if( part->GetType()==0 || fs==NULL || !fs->IsUseable() )
		return;

	dlg =makePartInfoDlg(data);
	if( dlg!=NULL )
	{
		status=new TDialog(TRect(0,0,40,5),getMessage(0x8A));
		status->options|=ofCentered;

		statusText = new TDynamicText(TRect(3,2,37,3),NULL);
		status->insert(statusText);
		statusText->setData(getMessage(0x89));
		TProgram::deskTop->insert(status);
		errno = fs->GetFileSysInfo( info );
		TProgram::deskTop->remove(status);
		destroy(status);

		if( errno!=0 )
		{
			DispErrorMsg(getMessage(0x8A),errno);
			destroy(dlg);
			return;
		}

		if(info.Formated) data.Formated->setData(getMessage(0x8B));
		else data.Formated->setData(getMessage(0x8C));

		sprintf(temp,"%10s",info.FileSysName);
		data.FileSysName->setData(temp);

		sprintf(temp,"%12s KB",NumToString(temp1, info.TotalKBytes));
		data.TotalSpace->setData(temp);

		sprintf(temp,"%12s KB",NumToString(temp1, info.ReservedKBytes));
		data.ReservedSpace->setData(temp);

		sprintf(temp,"%12s KB",NumToString(temp1,
				(info.TotalBlocks - info.FreeBlocks) *
				(info.BytesPerBlock) / 1024uL));

		data.UsedSpace->setData(temp);

		sprintf(temp,"%12s KB",NumToString(temp1, info.FreeKBytes));
		data.FreeSpace->setData(temp);

		sprintf(temp,"%15s",NumToString(temp1, info.BytesPerBlock));
		data.BlockSize->setData(temp);

		sprintf(temp,"%15s",NumToString(temp1, info.TotalBlocks));
		data.TotalBlocks->setData(temp);

		sprintf(temp,"%15s",NumToString(temp1, info.FreeBlocks));
		data.FreeBlocks->setData(temp);

		sprintf(temp,"%15s",NumToString(temp1, info.BadBlocks));
		data.BadBlocks->setData(temp);

		TProgram::deskTop->execView(dlg);
		destroy(dlg);
	}
}

void THDDialog::myRepairMBR()
{
	short errno;
	bool rescue=false;

	if( BootMgrs[curDrive] == NULL || !BootMgrs[curDrive]->IsUseable() )
		return;

	if( BootMgrs[curDrive]->IsKernelInst() &&
		BootMgrs[curDrive]->IsPartTableChanged() )
	{
		if( messageBox(getMessage(0x8D),mfWarning|mfYesButton|mfNoButton)
			== cmYes )
			rescue = true;
	}

	if( (errno = BootMgrs[curDrive]->RepairMBR(rescue)) == 0 )
		if( rescue )
		{
			Roots[curDrive]->ShutDown();
			Roots[curDrive]->Initialize(HardDrives[curDrive]);
            BootMgrs[curDrive]->ShutDown();
			BootMgrs[curDrive]->Initialize( Roots[curDrive] );
			UpdateList();
		}

	if( errno!=0 )
		DispErrorMsg(getMessage(0x8E), errno );
	else messageBox(getMessage(0x8F),mfInformation|mfOKButton);
	DispBtmgrStatus();

	setCommandState( PartListBox->getCurrentPart() );
}

void THDDialog::myNextDrive()
{
	if( curDrive < DriveNumber - 1 &&
		Roots[curDrive+1]!=NULL &&
		Roots[curDrive+1]->IsUseable() )
	{
		curDrive ++;
		DispBtmgrStatus();
		DispEBiosStatus();
		DispDriveStatus();
		UpdateList();
	}
}

void THDDialog::myPrevDrive()
{
	if( curDrive > 0 &&
		Roots[curDrive-1]!=NULL &&
		Roots[curDrive-1]->IsUseable() )
	{
		curDrive --;
		DispBtmgrStatus();
		DispEBiosStatus();
		DispDriveStatus();
		UpdateList();
	}
}


void THDDialog::myChangePartType()
{
//	short errno;
	TDialog *dlg;
	ushort result;
	TListBoxRec data;
	TPartition *part;

	if( Roots[curDrive] == NULL || !Roots[curDrive]->IsUseable() )
		return;
	part = PartListBox->getCurrentPart();

	if( part == NULL )
		return;

	if( messageBox(getMessage(0x104),
		mfConfirmation|mfOKButton|mfCancelButton ) != cmOK )
        return;

	dlg = makeChgPartTypeDlg();

	data.collection = new TLineCollection(20,1);
	for( int i=0; ValidPartTypeIndex[i] != 0; i ++ )
		data.collection->
			insert( newStr( PartitionTypes[ ValidPartTypeIndex[i] ].Name ) );

	data.focused = 0;
	dlg->setData( &data );
	result=TProgram::deskTop->execView(dlg);
	dlg->getData(&data);

	if( result == cmOK )
	{
        if( PartitionTypes[ ValidPartTypeIndex[data.focused] ].Type !=
 			part->GetType())
            {
            part->SetType(PartitionTypes[ ValidPartTypeIndex[data.focused] ].Type);
            part->MarkChanged(True);
            }
		UpdateList();
	}

	destroy(dlg);
	destroy( data.collection );
}

TDialog* makeRenameDlg(void)
{
	TView *control;

	TDialog* dlg = new TDialog(TRect(26, 8, 53, 15), getMessage(0xA0));
	if (!dlg) return 0;

	dlg->options |= ofCenterX | ofCenterY;

	control = new TInputLine(TRect(7, 2, 25, 3), 16);
	control->helpCtx = hcName;
	dlg->insert(control);

	dlg->insert(new TLabel(TRect(1, 2, 7, 3), getMessage(0xA1), control));

	control = new TButton(TRect(3, 4, 13, 6), getMessage(0x01), cmOK, bfDefault);
	dlg->insert(control);

	control = new TButton(TRect(14, 4, 24, 6), getMessage(0x02), cmCancel, bfNormal);
	dlg->insert(control);

	dlg->selectNext(false);
	return dlg;
}

TDialog* makeInstBtmgrDlg(void)
{
	TView *control;

	TDialog* dlg = new TDialog(TRect(21, 6, 58, 19), getMessage(0xA2));
	if (!dlg) return 0;

	dlg->options |= ofCenterX | ofCenterY;

	control = new TRadioButtons(TRect(2, 3, 15, 5),
				new TSItem(getMessage(0xA3),
				new TSItem(getMessage(0xA4), 0)));
	control->helpCtx = hcLanguage;
	dlg->insert(control);

	dlg->insert(new TLabel(TRect(2, 2, 12, 3), getMessage(0xA5), control));

	control = new TCheckBoxes(TRect(16, 3, 35, 5),
				new TSItem(getMessage(0xA6),
				new TSItem(getMessage(0xA7), 0)));
	control->helpCtx = hcVirusSwitch;
	dlg->insert(control);

	dlg->insert(new TLabel(TRect(16, 2, 29, 3), getMessage(0xA8), control));

	control = new TInputLong(TRect(17, 6, 35, 7), 4, 0, 99, 0, getMessage(0xAA) );
	control->helpCtx = hcDelayTime;
	dlg->insert(control);

	dlg->insert(new TLabel(TRect(2, 6, 17, 7), getMessage(0xA9), control));

	control = new TCheckBoxes(TRect(2, 8, 35, 9),
				new TSItem(getMessage(0xAB), 0));
	control->helpCtx = hcAutoHide;
	dlg->insert(control);

	control = new TButton(TRect(6, 10, 16, 12), getMessage(0x01), cmOK, bfDefault);
	dlg->insert(control);

	control = new TButton(TRect(21, 10, 31, 12), getMessage(0x02), cmCancel, bfNormal);
	dlg->insert(control);

	dlg->selectNext(false);
	return dlg;
}

TDialog* makeCreatePTDlg(char * title, long minSize, long maxSize)
{
	TView *control;

	TDialog* dlg = new TDialog(TRect(23, 4, 56, 18), title);
	if (!dlg) return 0;

	dlg->options |= ofCenterX | ofCenterY;
	dlg->flags &= ~wfClose;

	control = new TInputLong(TRect(13, 2, 29, 3), 11, minSize, maxSize, 0, getMessage(0xB5) );
	control->helpCtx = hcSize;
	dlg->insert(control);

	dlg->insert(new TLabel(TRect(3, 2, 13, 3), getMessage(0xB0), control));

	control = new TScrollBar(TRect(17, 5, 18, 12));
	dlg->insert(control);

	control = new TListBox(TRect(3, 5, 17, 12), 1, (TScrollBar*)control);
	control->helpCtx = hcTypeList;
	dlg->insert(control);

	dlg->insert(new TLabel(TRect(3, 4, 9, 5), getMessage(0xB1), control));

	control = new TRadioButtons(TRect(19, 5, 30, 7),
				new TSItem(getMessage(0xB2),
				new TSItem(getMessage(0xB3), 0)));
	control->helpCtx = hcPosition;
	dlg->insert(control);

	dlg->insert(new TLabel(TRect(19, 4, 29, 5), getMessage(0xB4), control));

	control = new TButton(TRect(20, 8, 30, 10), getMessage(0x01), cmOK, bfDefault);
	dlg->insert(control);

	control = new TButton(TRect(20, 10, 30, 12), getMessage(0x02), cmCancel, bfNormal);
	dlg->insert(control);

	dlg->selectNext(false);
	return dlg;
}

TDialog* makeFormatDlg( )
{
	TView *control;

	TDialog* dlg = new TDialog(TRect(22, 5, 58, 17), getMessage(0xC0));
	if (!dlg) return 0;

	dlg->options |= ofCenterX | ofCenterY;
	dlg->flags &= ~wfClose;

	control = new TRadioButtons(TRect(2, 3, 17, 6),
			  new TSItem(getMessage(0xC1),
			  new TSItem(getMessage(0xC2),
			  new TSItem(getMessage(0xC3), 0))));
	control->helpCtx = hcFormatType;

	dlg->insert(control);

	dlg->insert(new TLabel(TRect(2, 2, 15, 3), getMessage(0xC4), control));

	control = new TScrollBar(TRect(33, 3, 34, 6));
	dlg->insert(control);

	control = new TListBox(TRect(19, 3, 33, 6), 1, (TScrollBar*)control);
	control->helpCtx = hcBlockSize;

	dlg->insert(control);

	dlg->insert(new TLabel(TRect(19, 2, 31, 3), getMessage(0xC5), control));

	control = new TCheckBoxes(TRect(2, 7, 33, 8),
			  new TSItem(getMessage(0xC6), 0));
	control->helpCtx = hcShowSummary;
	dlg->insert(control);

	control = new TButton(TRect(7, 9, 17, 11), getMessage(0x01), cmOK, bfNormal);
	dlg->insert(control);

	control = new TButton(TRect(19, 9, 29, 11), getMessage(0x02), cmCancel, bfNormal);
	dlg->insert(control);

	dlg->selectNext(false);
	return dlg;
}

TDialog* makePartInfoDlg( TInfoDlgData &data)
{
	TView *control;

	TDialog* dlg = new TDialog(TRect(20, 3, 59, 20), getMessage(0xD0));
	if (!dlg) return 0;

	dlg->options |= ofCenterX | ofCenterY;
	dlg->helpCtx = hcInfoWindow;

	control = new TStaticText(TRect(12, 2, 24, 3), getMessage(0xD1));
	dlg->insert(control);

	control = new TStaticText(TRect(18, 4, 31, 5), getMessage(0xD2));
	dlg->insert(control);

	control = new TStaticText(TRect(18, 5, 34, 6), getMessage(0xD3));
	dlg->insert(control);

	control = new TStaticText(TRect(18, 6, 30, 7), getMessage(0xD9));
	dlg->insert(control);

	control = new TStaticText(TRect(18, 7, 30, 8), getMessage(0xD4));
	dlg->insert(control);

	control = new TStaticText(TRect(18, 9, 35, 10), getMessage(0xD5));
	dlg->insert(control);

	control = new TStaticText(TRect(18, 10, 32, 11), getMessage(0xD6));
	dlg->insert(control);

	control = new TStaticText(TRect(18, 11, 31, 12), getMessage(0xD7));
	dlg->insert(control);

	control = new TStaticText(TRect(18, 12, 30, 13), getMessage(0xD8));
	dlg->insert(control);

	data.FileSysName = new TDynamicText(TRect(2, 2, 12, 3), 0);
	dlg->insert(data.FileSysName);

	data.Formated = new TDynamicText(TRect(25, 2, 37, 3), 0);
	dlg->insert(data.Formated);

	data.TotalSpace = new TDynamicText(TRect(2, 4, 17, 5), 0);
	dlg->insert(data.TotalSpace);

	data.ReservedSpace = new TDynamicText(TRect(2, 5, 17, 6), 0);
	dlg->insert(data.ReservedSpace);

	data.UsedSpace = new TDynamicText(TRect(2, 6, 17, 7), 0);
	dlg->insert(data.UsedSpace);

	data.FreeSpace = new TDynamicText(TRect(2, 7, 17, 8), 0);
	dlg->insert(data.FreeSpace);

	data.BlockSize = new TDynamicText(TRect(2, 9, 17,10), 0);
	dlg->insert(data.BlockSize);

	data.TotalBlocks = new TDynamicText(TRect(2,10, 17, 11), 0);
	dlg->insert(data.TotalBlocks);

	data.FreeBlocks = new TDynamicText(TRect(2, 11, 17, 12), 0);
	dlg->insert(data.FreeBlocks);

	data.BadBlocks = new TDynamicText(TRect(2, 12, 17, 13), 0);
	dlg->insert(data.BadBlocks);

	control = new TButton(TRect(14, 14, 24, 16), getMessage(0x01), cmOK, bfDefault);
	control->options |= ofCenterX;
	dlg->insert(control);

	dlg->selectNext(false);
	return dlg;
}

TDialog* makeBadBlkDlg( TBadBlkDlgData &data)
{
	TView *control;

	TDialog* dlg = new TDialog(TRect(23, 3, 56, 20), getMessage(0xE0));
	if (!dlg) return 0;

	dlg->options |= ofCenterX | ofCenterY;
	dlg->helpCtx = hcBadBlockList;

	control = new TStaticText(TRect(3, 2, 15, 3), getMessage(0xE1));
	dlg->insert(control);

	control = new TScrollBar(TRect(30, 6, 31, 12));
	dlg->insert(control);

	data.BadBlockList = new TListBox(TRect(2, 6, 30, 12), 1, (TScrollBar*)control);
	dlg->insert(data.BadBlockList);

	data.BadBlockList->helpCtx = hcBadBlockList;

	dlg->insert(new TLabel(TRect(2, 4, 19, 5), getMessage(0xE2), data.BadBlockList));

	control = new TStaticText(TRect(2, 5, 30, 6), getMessage(0xE3));
	dlg->insert(control);

	data.BlockSize = new TDynamicText(TRect(16, 2, 30, 3), 0);
	dlg->insert(data.BlockSize);

	control = new TStaticText(TRect(3, 12, 11, 13), getMessage(0xE4));
	dlg->insert(control);

	data.Total = new TDynamicText(TRect(12, 12, 30, 13), 0);
	dlg->insert(data.Total);

	control = new TButton(TRect(11, 14, 21, 16), getMessage(0x01), cmOK, bfDefault);
	control->options |= ofCenterX;
	dlg->insert(control);

	dlg->selectNext(false);
	return dlg;
}

TDialog* makeChgPartTypeDlg()
{
	TView *control;

	TDialog* dlg = new TDialog(TRect(0, 0, 34, 12), getMessage(0x105));
	if (!dlg) return 0;

	dlg->options |= ofCenterX | ofCenterY;
	dlg->flags &= ~wfClose;

	control = new TScrollBar(TRect(30, 3, 31, 8));
	dlg->insert(control);

	control = new TListBox(TRect(3, 3, 30, 8), 2, (TScrollBar*)control);
	control->helpCtx = hcTypeList;
	dlg->insert(control);

	dlg->insert(new TLabel(TRect(3, 2, 30, 3), getMessage(0x106), control));

	control = new TButton(TRect(4, 9, 14, 11), getMessage(0x01), cmOK, bfDefault);
	dlg->insert(control);

	control = new TButton(TRect(18, 9, 28, 11), getMessage(0x02), cmCancel, bfNormal);
	dlg->insert(control);

	dlg->selectNext(false);
	return dlg;
}

