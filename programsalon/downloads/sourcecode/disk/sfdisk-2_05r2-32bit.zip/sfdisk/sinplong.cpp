#define TV1
/*------------------------------------------------------------*/
/* filename -       sinplong.cpp                              */
/*                                                            */
/* Registeration object for the class TInputLong              */
/*------------------------------------------------------------*/

#define Uses_TInputLong
#define Uses_TInputLine
#define Uses_TStreamableClass

#if defined (TV2)
#   include <tvision\tv.h>
#elif defined (TV1)
#   include <tv.h>
#else
#   error TV1 or TV2 must be defined
#endif

#include "tinplong.h"
__link( RInputLine)

TStreamableClass RInputLong( TInputLong::name,
                              TInputLong::build,
                              __DELTA(TInputLong)
                            );

