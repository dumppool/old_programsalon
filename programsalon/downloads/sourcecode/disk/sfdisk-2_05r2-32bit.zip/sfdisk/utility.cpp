/****************************************************************************
 *
 * Smart FDISK
 *
 * This program is a powerful Harddisk Partitioning Tool including a
 * easy-to-use Boot Manager.
 *
 *
 *     Copyright (C) 1999 Suzhe (suzhe@263.net)
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 ****************************************************************************/
/*
 * utility.cpp : Source file for some utility functions
 */

#define Uses_Utility
#define Uses_Constant
#define Uses_Message
#include"sfdisk.h"
#include<stdlib.h>
#include<dpmi.h>

void Restart()
{
    short rst_mark[2]={0x01234,0};

    dosmemput((void*)rst_mark,2,0x0472);

    _go32_dpmi_registers r;
    r.x.ax = 0;
    r.x.cs = 0xffff;
    r.x.ip = 0;
    r.x.ss = r.x.sp = 0;
    _go32_dpmi_simulate_fcall(&r);
/*
    void (far *reset)(void);
	int far* rst_mark=(int far*)0x0472;
	reset=(void far(*)())MK_FP(0xffff,0);
	*rst_mark=0x01234;
	(*reset)();
*/

}

char * NumToString( char * str, long num )
{
	long temp;
	char *last;

	if( str == NULL ) return NULL;

	last = str;

	if( num < 0 )
	{
		num = -num;
		sprintf( str, "-" );
		str++;
	}

	for( temp = 1uL; num / (temp*1000uL) > 0; temp *= 1000uL );

	sprintf(str, "%u", (unsigned long)(num / temp) );
	num %= temp;
	str += strlen( str );

	for( temp /= 1000uL ; temp >= 1; temp /= 1000uL )
	{
		sprintf(str, ",%03u", (unsigned long)(num / temp));
		num %= temp;
		str += strlen( str );
	}
	return last;
}

Boolean CheckWindows()
{
	__dpmi_regs regs;
	regs.x.ax = 0x1600;
	__dpmi_int( 0x2f, &regs );
	if( regs.h.al == 0 || regs.h.al == 0x80 )
		return False;
	return True;
}