/****************************************************************************
 *
 * Smart FDISK
 *
 * This program is a powerful Harddisk Partitioning Tool including a
 * easy-to-use Boot Manager.
 *
 *
 *     Copyright (C) 1999 Suzhe (suzhe@263.net)
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 ****************************************************************************/
/*
 * plistbox.cpp : Source file for Class TPartListBox
 */

#define Uses_PartListBox
#define Uses_Utility
#define Uses_Constant
#define Uses_Message
#define Uses_FileSystem
#define Uses_Partition

#include "sfdisk.h"


void TPartListBox::getText(char *dest,ccIndex item,short maxLen)
{
	char temp[80];
	static char *format="%2d. %3s %3s  %7s %12s %3s   %8s.%1u Mb  %-16s";
	char *type, *act, *formated, *boot, name[16], size[32];
	DWORD SizeInMega1, Sectors;
	WORD SizeInMega2, SectorsPerMega;

	TFileSystem *fs;

	if( maxLen==0 || dest==0 ) return;
	TPartition *part=(TPartition*)((list())->at(item));

	if(!part || !part->IsUseable())
	{
		*dest=EOS;
		return;
	}

	if( part->GetType()==0 )
	{
		type="Pri/Log";
		act="   ";
		formated="   ";
		boot="   ";
	}
	else
	{
		type = (part->GetLevel() == 0)?"Primary":"Logical";

		if( part->IsActive() ) act="Yes";
		else act=" No";

		fs = part->GetFileSystem();
		if( fs!=NULL && fs->IsFormated() )
			formated="Yes";
		else if( fs!=NULL && !fs->IsFormated() )
			formated=" No";
		else formated=" ? ";
		if( part->IsBootable() ) boot="Yes";
		else boot=" No";
	}

	strncpy(name, part->GetName(), 16);
	name[15]=0;

	Sectors = part->GetSectors();
	SectorsPerMega = 1048576uL / part->GetSectorSize();

	SizeInMega1 = Sectors / SectorsPerMega;
	SizeInMega2 = ( Sectors % SectorsPerMega ) * 10uL / SectorsPerMega;

	sprintf( temp, format, item+1, act, boot, type,
			part->GetTypeName(), formated,
			NumToString( size, SizeInMega1 ), SizeInMega2, name );

	strncpy(dest,temp,maxLen);
}

void TPartListBox::focusItem(ccIndex item)
{
	if( item > getMaxPartNum() )
		item = getMaxPartNum();

	TListBox::focusItem(item);
	message(owner,evBroadcast,cmMyFocusPart,list()->at(item));
}

TPartition *TPartListBox::getCurrentPart()
{
		TCollection *aList=list();
		if(aList==0 || aList->getCount()<=focused)
			return 0;
		return (TPartition*)(aList->at(focused));
}
TPartition *TPartListBox::getAPart(ccIndex item)
{
		TCollection *aList=list();
		if(aList==0 || item>=(aList->getCount()) || item<0)
			return 0;
		return (TPartition*)(aList->at(item));
}
void TPartListBox::insertBefore(ccIndex item,TPartition *aPart)
{
	if(!aPart) return;
	if(item>range) return;
	(list())->atInsert((range==0)?0:item,(void*)aPart);
	setRange((list())->getCount());
}
void TPartListBox::insertAfter(ccIndex item,TPartition *aPart)
{
	if(!aPart) return;
	if((range>0 && item>=range) || (range==0 && item>range)) return;
	(list())->atInsert((range==0)?0:(item+1),(void*)aPart);
	setRange((list())->getCount());
	if(range>1 && focused==item) focusItem(item+1);
}
void TPartListBox::replaceAPart(ccIndex item,TPartition *aPart)
{
	if(!aPart || item>=range) return;
    (list())->atPut(item,aPart);
}
void TPartListBox::deleteAPart(ccIndex item)
{
	if(item<0 || item>=range) return;
	(list())->free((list())->at(item));
	setRange((list())->getCount());
	if(focused>item) focused--;
}
void TPartListBox::removeAPart(ccIndex item)
{
	if(item<0 || item>=range) return;
	(list())->remove((list())->at(item));
	setRange((list())->getCount());
	if(focused>item) focused--;
}

void TPartListBox::handleEvent(TEvent& event)
{
	if( event.what == evKeyDown && event.keyDown.keyCode == kbEnter )
		{
		event.what = evKeyDown;
		event.keyDown.keyCode = kbAltP;
		putEvent( event );
        clearEvent( event );
        }
    else
		TListBox::handleEvent( event );

}