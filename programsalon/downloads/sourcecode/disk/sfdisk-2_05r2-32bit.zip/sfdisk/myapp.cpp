/****************************************************************************
 *
 * Smart FDISK
 *
 * This program is a powerful Harddisk Partitioning Tool including a
 * easy-to-use Boot Manager.
 *
 *
 *     Copyright (C) 1999 Suzhe (suzhe@263.net)
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 ****************************************************************************/
/*
 * myapp.cpp : Main source file of this program
 */

#define Uses_MyApplication
#define Uses_PartListBox
#define Uses_Utility
#define Uses_TStreamableClass
#define Uses_TCollection
#define Uses_TListBox
#define Uses_fpstream
#define Uses_ifpstream
#define Uses_TDeskTop
#define Uses_TBackground
#define Uses_HDDialog
#define Uses_TColoredText
#define Uses_MsgBox
#define Uses_Message
#define Uses_SmartHelp
#define Uses_TPalette
//#define Uses_TMemInfo

#include"sfdisk.h"
#include"dir.h"
#include<help.h>
//#include"gadgets.h"

static char helpFileName[MAXPATH];

const char* TMyStatusLine::hint( ushort aHelpCtx )
{
        int i;

	static char *NoHint="";

	static ushort HintCtxList[]={
		hcCreatePrimary,hcCreateLogical,hcInformation,hcRename,
		hcMarkActive,hcToggleBootable,hcDelete,hcFormat,hcSurfaceScan,
		hcSave,hcInstallBtmgr,hcUninstallBtmgr,hcRepairMBR,hcChangeType,0};
	static ushort HintStringList[]=
	{0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x3A,0x3B,0x3C,0x3D};

	if( aHelpCtx == 0 ) return NoHint;

	for( i=0; i<14; i++ )
		if( aHelpCtx == HintCtxList[i] )
			break;
	if( i<14 )
		return getMessage(HintStringList[i]);
	return NoHint;
}


MyApplication::MyApplication() :
	TProgInit( &MyApplication::initStatusLine,
			   &MyApplication::initMenuBar,
			   &MyApplication::initDeskTop )
{

	HDDialog = new THDDialog( UseInt13Ext );
	deskTop->insert(validView(HDDialog));

/*
	TRect r = getExtent();                            // Create the heap view.
	r.a.x = r.b.x - 13;     r.b.y = r.a.y + 1;
	memInfo = new TIDEMemInfo( r );
	insert(memInfo);
*/
}

MyApplication::~MyApplication()
{
	deskTop->remove(HDDialog);
	destroy(HDDialog);
	if( ShouldRestart )
	{
		if( messageBox( getMessage(0x2E), mfWarning|mfYesButton|mfNoButton) == cmYes )
		{
			Restart();
		}
	}
}

TMenuBar *MyApplication::initMenuBar( TRect r )
{
	r.b.y=r.a.y+1;
	return new TMenuBar( r,
		*new TSubMenu( getMessage(0x10),kbAltP )+
			*new TMenuItem( getMessage(0x11),cmMyCreatePrimary,
				kbAltC,hcCreatePrimary)+
			*new TMenuItem( getMessage(0x12),cmMyCreateLogical,
				kbAltL,hcCreateLogical)+
			*new TMenuItem( getMessage(0x13),cmMyInformation,
				kbAltI,hcInformation)+
			*new TMenuItem( getMessage(0x14),cmMyRename,
				kbAltN,hcRename)+
			*new TMenuItem( getMessage(0x15),cmMyMarkActive,
				kbAltA,hcMarkActive)+
			*new TMenuItem( getMessage(0x16),cmMyToggleBootable,
				kbAltT,hcToggleBootable)+
			*new TMenuItem( getMessage(0x17),cmMyDelete,
				kbAltD,hcDelete)+
			newLine()+
			*new TMenuItem( getMessage(0x18),cmMyFormat,
				(ushort)0,hcFormat )+
			*new TMenuItem( getMessage(0x19),cmMySurfaceScan,
				(ushort)0,hcSurfaceScan )+
			*new TMenuItem( getMessage(0x103),cmMyChangePartType,
            	(ushort)0,hcChangeType )+
			newLine()+
			*new TMenuItem( getMessage(0x1A),cmMySave,
				kbAltS,hcSave)+
			newLine()+
			*new TMenuItem( getMessage(0x1B),cmQuit,
				kbAltX,hcNoContext)+

		*new TSubMenu( getMessage(0x1C),kbAltM )+
			*new TMenuItem( getMessage(0x1D),cmMyInstBtMgr,
				kbAltB,hcInstallBtmgr)+
			*new TMenuItem( getMessage(0x1E),cmMyUninstBtMgr,
				kbAltU,hcUninstallBtmgr)+
			*new TMenuItem( getMessage(0x1F),cmMyRepairMBR,
				kbAltR,hcRepairMBR)+

		*new TSubMenu( getMessage(0x20),kbAltH )+
			*new TMenuItem( getMessage(0x21),cmMyContents,
				kbCtrlF1,hcNoContext)+
			*new TMenuItem( getMessage(0x22),cmMyHelp,
				kbAltF1,hcNoContext)+
			newLine()+
			*new TMenuItem( getMessage(0x23),cmMyAbout,
				kbShiftF1,hcNoContext));
}

TStatusLine *MyApplication::initStatusLine(TRect r)
{
	r.a.y=r.b.y-1;
	return new TMyStatusLine( r,
		*new TStatusDef( hcCreatePrimary, hcChangeType )+
			*new TStatusItem( getMessage(0x24),kbF1,cmMyHelpOnUse )+
		*new TStatusDef( 0, 0xFFFF )+
			*new TStatusItem( getMessage(0x24),kbF1,cmMyHelpOnUse )+
			*new TStatusItem( getMessage(0x25),kbF2,cmMyCreatePrimary )+
			*new TStatusItem( getMessage(0x26),kbF3,cmMyCreateLogical )+
			*new TStatusItem( getMessage(0x27),kbF4,cmMyInformation )+
			*new TStatusItem( getMessage(0x28),kbF5,cmMyDelete )+
            *new TStatusItem( 0,kbF7,cmMyNextDrive )+
            *new TStatusItem( 0,kbF6,cmMyPrevDrive )+
			*new TStatusItem( 0, kbF10,cmMenu ));
}

void MyApplication::outOfMemory()
{
	messageBox(getMessage(0x29),mfError | mfOKButton );
}

void MyApplication::handleEvent(TEvent& event)
{
	TApplication::handleEvent(event);
	if(event.what==evCommand)
	{
		switch(event.message.command)
		{
			case cmMyAbout:
				aboutBox();
				break;
		}
	}
}

void MyApplication::getEvent(TEvent &event)
{
	static Boolean helpInUse = False;
	TWindow *w;
	THelpFile *hFile;
	fpstream *helpStrm;
    ushort helpType=0,result;
    ffblk ffb;

	TApplication::getEvent(event);
	switch (event.what)
	{
		case evCommand:
			if ((event.message.command == cmMyHelpOnUse ||
				event.message.command==cmMyContents ||
				event.message.command==cmMyHelp)
				&& ( helpInUse == False))
			{
				helpInUse=True;
				result=findfirst(helpFileName,&ffb,0);
				if (result!=0)
					messageBox(getMessage(0x2A), mfError | mfOKButton);
				else
				{
					helpStrm = (fpstream*) new ifpstream(helpFileName, ios::in|ios::binary);
					hFile = new THelpFile(*helpStrm);
					if(event.message.command==cmMyHelpOnUse)
						helpType=getHelpCtx();
					else if(event.message.command==cmMyContents)
						helpType=hcContents;
					else helpType=0;
					w = new THelpWindow(hFile,helpType);
					if (validView(w) != 0)
					{
						execView(w);
						destroy( w );
					}
					clearEvent(event);
				}
				helpInUse = False;
			}
			break;
		case evMouseDown:
			if (event.mouse.buttons != 1)
				event.what = evNothing;
			break;
	}
}


TDialog* makeAboutDlg(void)
{
	TView *control;

	TDialog* dlg = new TDialog(TRect(22, 4, 57, 19), getMessage(0x2F));
	if (!dlg) return 0;

	dlg->options |= ofCenterX | ofCenterY;
	dlg->flags &= ~wfClose;

	control = new TColoredText(TRect(5, 2, 30, 5), getMessage(0x2B), 0x71);
	dlg->insert(control);

	control = new TColoredText(TRect(3, 5, 33, 8), getMessage(0x2C), 0x7e);
	dlg->insert(control);

	control = new TStaticText(TRect(2, 9, 33, 11), getMessage(0x2D));
	dlg->insert(control);

	control = new TButton(TRect(13, 12, 23, 14), getMessage(0x01), cmOK, bfDefault);
	dlg->insert(control);

	dlg->selectNext(False);
	return dlg;
}

void MyApplication::aboutBox()
{

	TDialog *about=makeAboutDlg();

	if(about!=NULL)
	{
		deskTop->execView(about);
		destroy(about);
	}
}

TPalette& MyApplication::getPalette() const
{
	static TPalette newcolor ( cpColor cHelpColor, sizeof( cpColor cHelpColor )-1 );
	static TPalette newblackwhite( cpBlackWhite cHelpBlackWhite, sizeof( cpBlackWhite cHelpBlackWhite)-1 );
	static TPalette newmonochrome( cpMonochrome cHelpMonochrome, sizeof( cpMonochrome cHelpMonochrome)-1 );
	static TPalette *palettes[] =
		{
		&newcolor,
		&newblackwhite,
		&newmonochrome
		};
	return *(palettes[appPalette]);
}

int main(int argc,char *argv[])
{	char dir[MAXDIR];
	char driver[MAXDRIVE];
	char name[MAXFILE];
	char ext[MAXEXT];

	fnsplit(argv[0],driver,dir,name,ext);

	fnmerge(helpFileName,driver,dir,"SFDISK",".HLP");
	InitMessage( 0 );
	SetKernelLanguage( 0 );

	for( int i=1; i< argc; i++ )
	{
		if( stricmp(argv[i],"/?")==0 ||
			stricmp(argv[i],"/h")==0 ||
			stricmp(argv[i],"/help")==0 )
		{
			cout << "\nSmart FDISK Version 2.0\n"
					"Usage:\n"
					"    SFDISK [options]\n"
					"\n    options:\n"
					"         /? or /help             Display this information\n"
					"         /c or /chinese          Use Chinese Interface\n"
					"         /noext                  Do not use Extended Bios\n\n";
			bioskey(0);
			return 0;
		}

		if( stricmp(argv[i],"/c")==0 )
		{
			fnmerge(helpFileName,driver,dir,"SFDISKC",".HLP");
			InitMessage( 1 );
			SetKernelLanguage( 1 );
		}

		if( stricmp(argv[i],"/noext")==0 )
		{
			UseInt13Ext = False;
		}

	}

	if( CheckWindows() == True )
	{
		cout << getMessage(0x102) <<"\n";
		bioskey(0);
    	return -1;
	}

	MyApplication myApp;

	myApp.run();
	return 0;
}

/*
void MyApplication::idle()
{
	TProgram::idle();
	memInfo->update();
}
*/
