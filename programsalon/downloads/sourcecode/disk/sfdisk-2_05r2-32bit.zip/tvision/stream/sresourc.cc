#define Uses_TResourceCollection
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RResourceCollection( TResourceCollection::name,
                                      TResourceCollection::build,
                                      __DELTA(TResourceCollection)
                                    );
