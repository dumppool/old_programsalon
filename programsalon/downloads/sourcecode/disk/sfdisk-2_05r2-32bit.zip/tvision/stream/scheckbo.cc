#define Uses_TCheckBoxes
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RCheckBoxes( TCheckBoxes::name,
                              TCheckBoxes::build,
                              __DELTA(TCheckBoxes)
                            );

