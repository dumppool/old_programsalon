#define Uses_TMenuBox
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RMenuBox( TMenuBox::name,
                           TMenuBox::build,
                           __DELTA(TMenuBox)
                         );

