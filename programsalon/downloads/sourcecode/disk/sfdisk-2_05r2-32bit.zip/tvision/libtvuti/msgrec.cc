/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
/*
 $Id: msgrec.cc,v 1.2 1997-09-08 22:40:42+00 rho Exp rho $
*/
#include <rhutils.h>

#define Uses_MsgRec
#include <libtvuti.h>

MsgRec::MsgRec(const char * fname,const char * m,msgType atype,
                 int line, int acolumn)
  : type(atype),lineno(line), column(acolumn)
{
  if (!fname || !*fname) filename = NULL;
  else string_dup(filename,fname);
  if (!m || !*m) msg = NULL;
  else string_dup(msg,m);
}

MsgRec::~MsgRec()
{
  string_free(filename);
  string_free(msg);
}


