/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
/*
 $Id: tenterin.cc,v 1.2 1997-09-08 22:40:42+00 rho Exp rho $
*/
#define Uses_TEvent
#define Uses_TKeys

#define Uses_TEnterInputLine
#include <libtvuti.h>

void TEnterInputLine::handleEvent(TEvent &event)
{
  TInputLine::handleEvent(event);
  if (!(state & sfSelected)) return;
  switch (event.what)
  {
    case evKeyDown:
      switch (event.keyDown.keyCode)
      {
        case kbEnter:
          event.keyDown.keyCode = kbTab;
          break;
        default:
          break;
      }
      break;
    default:
      break;
  }
}
