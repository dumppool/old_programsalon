/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
#define Uses_tvutilFunctions
#include <libtvuti.h>

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>

static char _static_buffer[2048]; // this should be enough


