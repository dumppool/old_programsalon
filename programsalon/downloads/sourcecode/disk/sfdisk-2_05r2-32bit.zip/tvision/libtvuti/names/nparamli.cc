/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
/*
 $Id: nparamli.cc,v 1.2 1997-09-09 00:40:42+02 rho Exp $
*/
#include <ttypes.h>
#include <tvutil.h>

n(TParamList)
