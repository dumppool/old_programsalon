/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
/*
 $Id: tmemstrm.h,v 1.2 1997-09-08 22:40:42+00 rho Exp rho $
*/
#if !defined( __TMemoriStream )
#define __TMemoryStream

class TMemoryStream : public iopstream
{
public:
  TMemoryStream();
  TMemoryStream(const void *, int);
  unsigned long getSize();
  void *getBuffer();
};

#endif

