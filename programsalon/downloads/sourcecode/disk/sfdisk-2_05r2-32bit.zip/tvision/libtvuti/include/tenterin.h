/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
/*
 $Id: tenterin.h,v 1.2 1997-09-08 22:40:42+00 rho Exp rho $
*/
#if !defined( __TEnterInputLine )
#define __TEnterInputLine

class TRect;

class TEnterInputLine : public TInputLine
{
public:
  TEnterInputLine(const TRect &bounds,int aMaxlen) :
    TInputLine(bounds,aMaxlen) {}
  virtual void handleEvent(TEvent &);
};

#endif
