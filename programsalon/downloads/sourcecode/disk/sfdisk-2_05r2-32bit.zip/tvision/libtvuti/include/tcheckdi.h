/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
/*
 $Id: tcheckdi.h,v 1.2 1997-09-08 22:40:42+00 rho Exp rho $
*/
#if !defined( TCheckDialog__ )
#define TCheckDialog__

class MyStaticText;

class TCheckDialog : public TDialog
{
public:
  TCheckDialog(const TRect &,const char *);
  void update(const char *);
private:
  MyStaticText *text;
};

#endif
