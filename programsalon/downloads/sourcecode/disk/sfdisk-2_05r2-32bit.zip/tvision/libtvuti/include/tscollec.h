/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
/*
 $Id: tscollec.h,v 1.2 1997-09-08 22:40:42+00 rho Exp rho $
*/
#if defined( Uses_TSCollection ) && !defined( __TSCollection__ )
#define __TSCollection__

class TSCollection : public TCollection
{
public:
    TSCollection(void) : TCollection(10,10) {}
private:

    virtual void *readItem( ipstream& ) { return 0; }
    virtual void writeItem( void *, opstream& ) {};

};

#endif

