/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
/*
 $Id: tenterli.h,v 1.2 1997-09-08 22:40:42+00 rho Exp rho $
*/
#if !defined( __TEnterListBox )
#define __TEnterListBox

class TRect;
class TScrollBar;
class TNSCollection;

class TEnterListBox : public TListViewer
{
public:
  TEnterListBox(const TRect &bounds,ushort numcols,TScrollBar *bar) :
    TListViewer(bounds,numcols,NULL,bar), items(NULL) {}
  virtual void handleEvent(TEvent &);
  virtual void focusItem(ccIndex);
  virtual void newList( TNSCollection *aList );

  TNSCollection *list()
  {
      return items;
  }

private:

    TNSCollection *items;

};

#endif
