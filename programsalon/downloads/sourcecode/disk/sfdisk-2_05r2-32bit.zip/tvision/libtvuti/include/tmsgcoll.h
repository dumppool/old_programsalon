/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
/*
 $Id: tmsgcoll.h,v 1.2 1997-09-08 22:40:42+00 rho Exp rho $
*/
#if defined( Uses_TMsgCollection ) && !defined( __TMsgCollection__ )
#define __TMsgCollection__

class TMsgCollection : public TNSCollection
{
public:
  TMsgCollection(void) : TNSCollection(5,5) {}
  virtual void freeItem(void *item);
};

#endif

