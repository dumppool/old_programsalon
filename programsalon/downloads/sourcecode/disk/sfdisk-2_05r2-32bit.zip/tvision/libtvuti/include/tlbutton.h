/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
/*
 $Id: tlbutton.h,v 1.2 1997-09-08 22:40:42+00 rho Exp rho $
*/
#if !defined( __TLButton )
#define __TLButton

class TRect;

class TLButton : public TButton
{
public:
  TLButton(TRect& bounds,const char *aTitle,ushort aCommand,ushort aFlags);
};

#endif
