/* Copyright (C) 1996,1997 Robert H�hne, see COPYING.RH for details */
/* This file is part of RHIDE. */
/*
 $Id: tmsgcoll.cc,v 1.2 1997-09-08 22:40:42+00 rho Exp rho $
*/
#define Uses_TMsgCollection
#define Uses_MsgRec
#include <libtvuti.h>

void TMsgCollection::freeItem(void *item)
{
  delete((MsgRec *)item);
}

