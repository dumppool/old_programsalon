/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *

Modified by Robert H�hne to be used for RHIDE.

 *
 *
 */

#define Uses_TScreen
#define Uses_TRadioButtons
#define Uses_TMenuBox
#define Uses_TFrame
#define Uses_TIndicator
#define Uses_THistory
#define Uses_TColorSelector
#define Uses_TMonoSelector
#define Uses_TColorDialog
#define Uses_TInputLine
#define Uses_TStatusLine
#define Uses_TCheckBoxes
#define Uses_TScrollBar
#define Uses_TButton
#define Uses_TDirListBox
#define Uses_TFileEditor
#include <tv.h>


extern const uchar specialChars[] =
{
    '\xAF', '\xAE', '\x1A', '\x1B', ' ', ' '
};

const char * TRadioButtons::button = " ( ) ";

const char * TMenuBox::frameChars = " \xDA\xC4\xBF  \xC0\xC4\xD9  \xB3 \xB3  \xC3\xC4\xB4 ";

const char TFrame::initFrame[19] =
  "\x06\x0A\x0C\x05\x00\x05\x03\x0A\x09\x16\x1A\x1C\x15\x00\x15\x13\x1A\x19";

char TFrame::frameChars[33] =
    "   \xC0 \xB3\xDA\xC3 \xD9\xC4\xC1\xBF\xB4\xC2\xC5   \xC8 \xBA\xC9\xC7 \xBC\xCD\xCF\xBB\xB6\xD1 "; // for UnitedStates code page

const char * TFrame::closeIcon = "[~\xFE~]";
const char * TFrame::zoomIcon = "[~\x18~]";
const char * TFrame::unZoomIcon = "[~\x12~]";
const char * TFrame::dragIcon = "~\xC4\xD9~";

const char TIndicator::dragFrame = '\xCD';
const char TIndicator::normalFrame = '\xC4';

const char * THistory::icon = "\xDE~\x19~\xDD";

const char TColorSelector::icon = '\xDB';

const char * TMonoSelector::button = " ( ) ";
const char TInputLine::rightArrow = '\x10';
const char TInputLine::leftArrow = '\x11';

const char * TStatusLine::hintSeparator = "\xB3 ";

const char * TCheckBoxes::button = " [ ] ";

TScrollChars TScrollBar::vChars = {30, 31, 177, 254, 178};
TScrollChars TScrollBar::hChars = {17, 16, 177, 254, 178};

const char * TButton::shadows = "\xDC\xDB\xDF";
const char * TButton::markers = "[]";

const char * TDirListBox::pathDir   = "\xC0\xC4\xC2";
const char * TDirListBox::firstDir  =   "\xC0\xC2\xC4";
const char * TDirListBox::middleDir =   " \xC3\xC4";
const char * TDirListBox::lastDir   =   " \xC0\xC4";
const char * TDirListBox::graphics = "\xC0\xC3\xC4";


