/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *

Modified by Robert H�hne to be used for RHIDE.

 *
 *
 */

#if !defined( __BUTTON_TYPE )
#define __BUTTON_TYPE

const
    bfNormal    = 0x00,
    bfDefault   = 0x01,
    bfLeftJust  = 0x02,
    bfBroadcast = 0x04,

    cmRecordHistory = 60;

#endif  // __BUTTON_TYPE

#if defined( Uses_TDialog )

#include <class/dialog.h>

#endif

#if defined( Uses_TInputLine )

#include <class/inputln.h>

#endif

#if defined( Uses_TButton )

#include <class/button.h>

#endif

#if defined( Uses_TSItem )

#include <class/sitem.h>

#endif

#if defined( Uses_TCluster )

#include <class/cluster.h>

#endif

#if defined( Uses_TRadioButtons )

#include <class/radiobtn.h>

#endif

#if defined( Uses_TCheckBoxes )

#include <class/checkbox.h>

#endif

#if defined( Uses_TListBox )

#include <class/listbox.h>

#endif

#if defined( Uses_TStaticText )

#include <class/sttctext.h>

#endif

#if defined( Uses_TParamText )

#include <class/parmtext.h>

#endif

#if defined( Uses_TLabel )

#include <class/label.h>

#endif

#if defined( Uses_THistoryViewer )

#include <class/histvwer.h>

#endif

#if defined( Uses_THistoryWindow )

#include <class/histwind.h>

#endif

#if defined( Uses_THistory )

#include <class/history.h>

#endif


