/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *

Modified by Robert H�hne to be used for RHIDE.

 *
 *
 */

#if defined( Uses_TBackground )

#include <class/backgrnd.h>

#endif


#if defined( Uses_TDeskTop )

#include <class/desktop.h>

#endif


#if defined( Uses_TProgram )

#include <class/program.h>

#endif

#if defined( Uses_TApplication )

#include <class/applictn.h>

#endif


