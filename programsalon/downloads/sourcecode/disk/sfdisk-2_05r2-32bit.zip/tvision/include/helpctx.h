const
  hcContents             = 0,
  hcHelpOnHelp           = 2,
  hcIntro                = 4,
  hcOld                  = 5,
  hcTopicA               = 6,
  hcTopicB               = 7,
  hcTopicC               = 8,
  hcUsingHelp            = 3;
