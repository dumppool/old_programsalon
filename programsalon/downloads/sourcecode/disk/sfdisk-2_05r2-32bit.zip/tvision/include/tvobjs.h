/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *

Modified by Robert H�hne to be used for RHIDE.

 *
 *
 */

#if defined( Uses_TObject )

#include <class/object.h>

#endif

#if defined( Uses_TNSCollection )

#include <class/nscoll.h>

#endif

#if defined( Uses_TNSSortedCollection )

#include <class/nssorcol.h>

#endif


