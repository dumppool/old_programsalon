/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *

Modified by Robert H�hne to be used for RHIDE.

 *
 *
 */

typedef unsigned P_id_type;

#if !defined( __fLink_def )
#define __fLink_def
struct fLink
{
    fLink *f;
    class TStreamableClass *t;
};
#endif

#define __link( s )             \
  extern TStreamableClass s;    \
  static fLink force ## s =     \
    { (fLink *)&force ## s, (TStreamableClass *)&s };

#if defined( Uses_TStreamable )

#include <class/streambl.h>

#endif

#if defined( Uses_TStreamableClass )

#include <class/strmblcl.h>

#endif

#if defined( Uses_TStreamableTypes )

#include <class/strmblty.h>

#endif

#if defined( Uses_TPWrittenObjects )

#include <class/pwritobj.h>

#endif

#if defined( Uses_TPReadObjects )

#include <class/preadobj.h>

#endif

#if defined( Uses_pstream )

#include <class/pstream.h>

#endif

#if defined( Uses_ipstream )

#include <class/ipstream.h>

#endif

#if defined( Uses_opstream )

#include <class/opstream.h>

#endif

#if defined( Uses_iopstream )

#include <class/iopstrm.h>

#endif

#if defined( Uses_fpbase )

#include <class/fpbase.h>

#endif

#if defined( Uses_ifpstream )

#include <class/ifpstrm.h>

#endif

#if defined( Uses_ofpstream )

#include <class/ofpstrm.h>

#endif

#if defined( Uses_fpstream )

#include <class/fpstream.h>

#endif


