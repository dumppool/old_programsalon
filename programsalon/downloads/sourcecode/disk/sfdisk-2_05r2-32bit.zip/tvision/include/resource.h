/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *

Modified by Robert H�hne to be used for RHIDE.

 *
 *
 */

#if defined( Uses_TStringCollection )

#include <class/strncoll.h>

#endif

#if defined( Uses_TResourceItem )

#include <class/resitem.h>

#endif

#if defined( Uses_TResourceCollection )

#include <class/rescoll.h>

#endif

#if defined( Uses_TResourceFile )

#include <class/resfile.h>

#endif

#if defined( Uses_TStrIndexRec )

#include <class/strinrec.h>

#endif

#if defined( Uses_TStringList )

#include <class/strilist.h>

#endif

#if defined( Uses_TStrListMaker )

#include <class/strlistm.h>

#endif


