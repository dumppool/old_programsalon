/* 
 * Copyright (c) 2000 by Matt Welsh and The Regents of the University of 
 * California. All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * Author: Matt Welsh <mdw@cs.berkeley.edu>
 * 
 */

/*
 * This file implements the native method bindings for the nbio library.
 * 
 * This has only been tested on Linux with glibc 2.1.1 as well as Solaris.
 * However this should be readily portable to other UNIX systems. 
 * It makes use of nonblocking I/O calls, the poll() system call, as 
 * well as (optionally) /dev/poll.
 */

#include <jni.h>
#include <stdio.h>

#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/stat.h>

#ifdef SOLARIS
#include <stropts.h>
#include <sys/filio.h>
#endif

#ifdef HAS_DEVPOLL
#include <sys/devpoll.h>
#ifndef POLLREMOVE
#define POLLREMOVE 0x1000
#endif
#endif

#include "NonblockingSocket.h"
#include "NonblockingSocketImpl.h"
#include "NonblockingSocketInputStream.h"
#include "mdw-exceptions.h"
#include "mdw-btree.h"

#define DEBUG(_x) 

/* Constants *****************************************************************/

/* These need to stay consistent with the Java code - javah -jni does not
 * include constant definitions
 */
#define SELECTABLE_READ_READY 0x01
#define SELECTABLE_WRITE_READY 0x02
#define SELECTABLE_SELECT_ERROR 0x80

/* System call support *******************************************************/

/* MDW: The below indirection of system calls is required because we want 
 * to circumvent the JDK's own system call wrappers - otherwise on green 
 * threads we don't get the effect of true nonblocking I/O.
 */

static int _nbio_syscalls_init = 0;

typedef struct _nbio_syscall_t {
  char *sym;
  int (*addr)();
} nbio_syscall_t;

nbio_syscall_t nbio_syscalls[] = {
#define SYSCALL_WRITE 0
  { "write", 0 },
#define SYSCALL_READ 1
  { "read", 0 },
#define SYSCALL_FCNTL 2
  { "fcntl", 0 },
#define SYSCALL_POLL 3
  { "poll", 0 },
#define SYSCALL_ACCEPT 4
  { "accept", 0 },
  { NULL, 0 }
};

static inline int nbio_real_fcntl(int fd, int cmd, long arg) {
  return (*nbio_syscalls[SYSCALL_FCNTL].addr)(fd, cmd, arg);
}

static inline int nbio_real_read(int fd, void *buf, size_t count) {
  return (*nbio_syscalls[SYSCALL_READ].addr)(fd, buf, count);
}

static inline int nbio_real_write(int fd, void *buf, size_t count) {
  return (*nbio_syscalls[SYSCALL_WRITE].addr)(fd, buf, count);
}

static inline int nbio_real_poll(struct pollfd *ufds, unsigned int nfds, int timeout) {
  return (*nbio_syscalls[SYSCALL_POLL].addr)(ufds, nfds, timeout);
}

static inline int nbio_real_accept(int fd, struct sockaddr *addr, int *addrlen) {
  return (*nbio_syscalls[SYSCALL_ACCEPT].addr)(fd, addr, addrlen);
}

static void nbio_init_syscalls(JNIEnv *env) {

  nbio_syscall_t *syscall = nbio_syscalls;

#ifdef linux
  void *dlMain = dlopen("/lib/libc.so.6", RTLD_LAZY);
  if (dlMain == NULL) {
    THROW_EXCEPTION(env, "java/lang/UnsatisfiedLinkError", "NBIO: Cannot open libc shared library -- contact mdw@cs.berkeley.edu for details");
    return;
  }
  while (syscall->sym != NULL) { 
    syscall->addr = dlsym(dlMain, syscall->sym);
    if (syscall->addr == NULL) {
      THROW_EXCEPTION(env, "java/lang/UnsatisfiedLinkError", "Cannot find system call -- contact mdw@cs.berkeley.edu for details");
      return;
    }
    syscall++;
  }
#endif /* linux */

#ifdef SOLARIS
  void *dlMain = dlopen("/lib/libc.so", RTLD_LAZY);
  void *dlSock = dlopen("/lib/libsocket.so.1", RTLD_LAZY);
  if (dlMain == NULL) {
    THROW_EXCEPTION(env, "java/lang/UnsatisfiedLinkError", "NBIO: Cannot open libc shared library -- contact mdw@cs.berkeley.edu for details");
    return;
  }
  if (dlSock == NULL) {
    THROW_EXCEPTION(env, "java/lang/UnsatisfiedLinkError", "NBIO: Cannot open libsocket shared library -- contact mdw@cs.berkeley.edu for details");
    return;
  }

  /* First try in libc, then in libsocket */
  while (syscall->sym != NULL) { 
    syscall->addr = dlsym(dlMain, syscall->sym);
    if (syscall->addr == NULL) {
      syscall->addr = dlsym(dlSock, syscall->sym);
      if (syscall->addr == NULL) {
	THROW_EXCEPTION(env, "java/lang/UnsatisfiedLinkError", "Cannot find system call -- contact mdw@cs.berkeley.edu for details");
	return;
      }
    }
    syscall++;
  }
#endif /* SOLARIS */

}

static void nbio_make_nonblocking(JNIEnv *env, int fd) {
  /* Set fd to nonblocking mode */
  if (nbio_real_fcntl(fd, F_SETFL, O_NONBLOCK) < 0) {
    THROW_EXCEPTION(env, "java/net/SocketException", strerror(errno));
    return;
  }
  DEBUG(fprintf(stderr,"Set fd=%d to nonblocking mode\n", fd));
}

static void nbio_make_blocking(JNIEnv *env, int fd) {
  /* Set fd to blocking mode */
  if (nbio_real_fcntl(fd, F_SETFL, 0) < 0) {
    THROW_EXCEPTION(env, "java/net/SocketException", strerror(errno));
    return;
  }
  DEBUG(fprintf(stderr,"Set fd=%d to blocking mode\n", fd));
}

static void nbio_disable_nagle(JNIEnv *env, int fd) {
  int enable = 1;
  if (setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (char *)&enable, sizeof(int)) < 0) {
    THROW_EXCEPTION(env, "java/net/SocketException", strerror(errno));
    return;
  }
}

/* NonblockingSocketImpl *****************************************************/

/*
 * Class:     ninja2_core_io_0005fcore_nbio_NonblockingSocketImpl
 * Method:    nbSocketCreate
 * Signature: (Z)V
 */
JNIEXPORT void JNICALL Java_ninja2_core_io_1core_nbio_NonblockingSocketImpl_nbSocketCreate(JNIEnv *env, jobject this, jboolean stream) {
  int fd;
  jclass cls;
  jfieldID fid;
  jobject fdobj;
  long enable = 1;

  if (!_nbio_syscalls_init) nbio_init_syscalls(env);

  fd = socket(AF_INET, (stream ? SOCK_STREAM: SOCK_DGRAM), 0);
  if (fd == -1) {
    THROW_EXCEPTION(env, "java/io/IOException", strerror(errno));
    return;
  }
 
  DEBUG(fprintf(stderr,"NBIO: Created socket, fd=%d\n", fd));

  // XXX MDW: Turn these on for all sockets
  // XXX MDW: (These are probably best to turn on only for servers)
  setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (char *)&enable, sizeof(int));
  setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, (char *)&enable, sizeof(int));

  // Want this for all sockets
  nbio_disable_nagle(env, fd);

  // XXX Should also turn on SO_LINGER? Apache does for server sockets..
  // XXX Should also set SO_SNDBUF to increase send buffer size?

  nbio_make_nonblocking(env, fd);

  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  fdobj = (*env)->GetObjectField(env, this, fid);
  if (fdobj == NULL) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }
  cls = (*env)->GetObjectClass(env, fdobj);
  fid = (*env)->GetFieldID(env, cls, "fd", "I");
  (*env)->SetIntField(env, fdobj, fid, fd);
  return;
}

/*
 * Class:     ninja2_core_io_0005fcore_nbio_NonblockingSocketImpl
 * Method:    nbSocketConnect
 * Signature: (Ljava/net/InetAddress;I)V
 */
JNIEXPORT void JNICALL Java_ninja2_core_io_1core_nbio_NonblockingSocketImpl_nbSocketConnect (JNIEnv *env, jobject this, jobject address, jint port) {
  int fd, inet_address, inet_family, localport;
  struct sockaddr_in him;
  int ret;
  int myerrno;

  jclass cls = (*env)->GetObjectClass(env, this);
  jfieldID fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  jobject fdobj = (*env)->GetObjectField(env, this, fid);
  if (fdobj == NULL) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }
  cls = (*env)->GetObjectClass(env, fdobj);
  fid = (*env)->GetFieldID(env, cls, "fd", "I");
  fd = (*env)->GetIntField(env, fdobj, fid);
  if (fd == -1) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }

  if (address == NULL) {
    THROW_EXCEPTION(env, "java/lang/NullPointerException", "address is NULL");
    return;
  }
  cls = (*env)->GetObjectClass(env, address);
  fid = (*env)->GetFieldID(env, cls, "address", "I");
  inet_address = (*env)->GetIntField(env, address, fid);
  fid = (*env)->GetFieldID(env, cls, "family", "I");
  inet_family = (*env)->GetIntField(env, address, fid);

  memset((char *)&him,  0, sizeof(him));
  him.sin_port = htons((short)port);
  him.sin_addr.s_addr = (unsigned long)htonl(inet_address);
  him.sin_family = inet_family;

again:
  if ((ret = connect(fd, (struct sockaddr *)&him, sizeof(him))) < 0) {
    myerrno = errno;
    DEBUG(fprintf(stderr,"NBIO: connect returned %d, errno %d\n", ret, myerrno));
    if (myerrno == EINPROGRESS) {
      /* This is ok - connection not yet done */
      goto connect_ok;
    } else if (myerrno == ECONNREFUSED) {
      THROW_EXCEPTION(env, "java/net/ConnectException", strerror(myerrno));
    } else if (myerrno == ETIMEDOUT || myerrno == EHOSTUNREACH) {
      THROW_EXCEPTION(env, "java/net/NoRouteToHostException", strerror(myerrno));
    } else if (myerrno == EINTR) {
      DEBUG(fprintf(stderr,"***** NBIO: connect: Interrupted, trying again\n"));
      goto again;
    } else {
      THROW_EXCEPTION(env, "java/net/SocketException", strerror(myerrno));
    }
    return;
  }

 connect_ok:

  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "address", "Ljava/net/InetAddress;");
  (*env)->SetObjectField(env, this, fid, address);
  fid = (*env)->GetFieldID(env, cls, "port", "I");
  (*env)->SetIntField(env, this, fid, port);
  fid = (*env)->GetFieldID(env, cls, "localport", "I");
  localport = (*env)->GetIntField(env, this, fid);
  if (localport == 0) {
    /* Set localport value -- may have been previously set by bind operation */
    int len = sizeof(him);
    if (getsockname(fd,(struct sockaddr *)&him, &len) == -1) {
      THROW_EXCEPTION(env, "java/net/SocketException", strerror(errno));
      return;
    }
    (*env)->SetIntField(env, this, fid, ntohs(him.sin_port));
  }

  return;
}


JNIEXPORT jboolean JNICALL Java_ninja2_core_io_1core_nbio_NonblockingSocketImpl_nbSocketConnectDone (JNIEnv *env, jobject this) {

  /* This is a bit strange. Although the man pages say you use
   * select() followed by getsockopt() to find out if the connection was
   * established, looks like you do select() and call connect() again...
   */

  int fd, inet_address, inet_family;
  jobject address; 
  jint port;
  struct sockaddr_in him;
  int ret;
  int myerrno;

  jclass cls = (*env)->GetObjectClass(env, this);
  jfieldID fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  jobject fdobj = (*env)->GetObjectField(env, this, fid);
  if (fdobj == NULL) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }
  cls = (*env)->GetObjectClass(env, fdobj);
  fid = (*env)->GetFieldID(env, cls, "fd", "I");
  fd = (*env)->GetIntField(env, fdobj, fid);
  if (fd == -1) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }

  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "address", "Ljava/net/InetAddress;");
  address = (*env)->GetObjectField(env, this, fid);
  fid = (*env)->GetFieldID(env, cls, "port", "I");
  port = (*env)->GetIntField(env, this, fid);

  if (address == NULL) {
    THROW_EXCEPTION(env, "java/lang/NullPointerException", "address is NULL");
    return;
  }

  cls = (*env)->GetObjectClass(env, address);
  fid = (*env)->GetFieldID(env, cls, "address", "I");
  inet_address = (*env)->GetIntField(env, address, fid);
  fid = (*env)->GetFieldID(env, cls, "family", "I");
  inet_family = (*env)->GetIntField(env, address, fid);

  memset((char *)&him,  0, sizeof(him));
  him.sin_port = htons((short)port);
  him.sin_addr.s_addr = (unsigned long)htonl(inet_address);
  him.sin_family = inet_family;

  DEBUG(fprintf(stderr,"NBIO: connectDone: recalling connect on fd %d\n", fd));

again:
  if ((ret = connect(fd, (struct sockaddr *)&him, sizeof(him))) < 0) {
    myerrno = errno;
    DEBUG(fprintf(stderr,"NBIO: connectDone: connect got errorno %d\n", myerrno));
    if (myerrno == EINPROGRESS) return JNI_FALSE;
    else if (myerrno == EALREADY) return JNI_FALSE;
    else if (myerrno == EISCONN) return JNI_TRUE;
    else if (myerrno == EINTR) {
      DEBUG(fprintf(stderr,"NBIO: connectDone: connect returned EINTR, trying again"));
      goto again;
    } else {
      THROW_EXCEPTION(env, "java/net/SocketException", strerror(myerrno));
      return JNI_FALSE;
    }
  }

  return JNI_TRUE;
}

/*
 * Class:     ninja2_core_io_0005fcore_nbio_NonblockingSocketImpl
 * Method:    nbSocketBind
 * Signature: (Ljava/net/InetAddress;I)V
 */
JNIEXPORT void JNICALL Java_ninja2_core_io_1core_nbio_NonblockingSocketImpl_nbSocketBind (JNIEnv *env, jobject this, jobject address, jint port) {
  int fd, inet_address, inet_family, localport;
  struct sockaddr_in him;
  int ret;

  jclass cls = (*env)->GetObjectClass(env, this);
  jfieldID fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  jobject fdobj = (*env)->GetObjectField(env, this, fid);
  if (fdobj == NULL) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }
  cls = (*env)->GetObjectClass(env, fdobj);
  fid = (*env)->GetFieldID(env, cls, "fd", "I");
  fd = (*env)->GetIntField(env, fdobj, fid);
  if (fd == -1) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }
  
  /* A bind address of NULL represents AF_INET/INADDR_ANY */
  if (address == NULL) { 
    inet_address = INADDR_ANY;
    inet_family = AF_INET;
  } else {
    cls = (*env)->GetObjectClass(env, address);
    fid = (*env)->GetFieldID(env, cls, "address", "I");
    inet_address = (*env)->GetIntField(env, address, fid);
    fid = (*env)->GetFieldID(env, cls, "family", "I");
    inet_family = (*env)->GetIntField(env, address, fid);
  }

  memset((char *)&him,  0, sizeof(him));
  him.sin_port = htons((short)port);
  him.sin_addr.s_addr = (unsigned long)htonl(inet_address);
  him.sin_family = inet_family;

  if ((ret = bind(fd, (struct sockaddr *)&him, sizeof(him))) < 0) {
    if (errno == EACCES) {
      THROW_EXCEPTION(env, "java/net/BindException", strerror(errno));
    } else {
      THROW_EXCEPTION(env, "java/net/SocketException", strerror(errno));
    }
    return;
  }

  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "address", "Ljava/net/InetAddress;");
  (*env)->SetObjectField(env, this, fid, address);
  fid = (*env)->GetFieldID(env, cls, "port", "I");
  (*env)->SetIntField(env, this, fid, port);
  fid = (*env)->GetFieldID(env, cls, "localport", "I");

  /* Set local port value */

  if (port == 0) {
    /* Set localport value -- may have been previously set by bind operation */
    int len = sizeof(him);
    if (getsockname(fd,(struct sockaddr *)&him, &len) == -1) {
      THROW_EXCEPTION(env, "java/net/SocketException", strerror(errno));
      return;
    }
    (*env)->SetIntField(env, this, fid, ntohs(him.sin_port));
  } else {
    (*env)->SetIntField(env, this, fid, port);
  }

  return;
}
  
/*
 * Class:     ninja2_core_io_0005fcore_nbio_NonblockingSocketImpl
 * Method:    nbSocketListen
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_ninja2_core_io_1core_nbio_NonblockingSocketImpl_nbSocketListen (JNIEnv *env, jobject this, jint count) {
  int fd;

  jclass cls = (*env)->GetObjectClass(env, this);
  jfieldID fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  jobject fdobj = (*env)->GetObjectField(env, this, fid);
  if (fdobj == NULL) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }
  cls = (*env)->GetObjectClass(env, fdobj);
  fid = (*env)->GetFieldID(env, cls, "fd", "I");
  fd = (*env)->GetIntField(env, fdobj, fid);
  if (fd == -1) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }

  if (listen(fd, count) < 0) {
    THROW_EXCEPTION(env, "java/net/SocketException", strerror(errno));
    return;
  }

}

/*
 * Class:     ninja2_core_io_0005fcore_nbio_NonblockingSocketImpl
 * Method:    nbSocketAccept
 * Signature: (Lninja2/core/io_core/nbio/NonblockingSocketImpl;)V
 */
JNIEXPORT jint JNICALL Java_ninja2_core_io_1core_nbio_NonblockingSocketImpl_nbSocketAccept (JNIEnv *env, jobject this, jobject newsocket, jboolean block) {
  int fd, newfd;
  struct sockaddr_in him;
  int len, localport;
  jobject sptr_inetaddr, sptr_fdobj;

  jclass cls = (*env)->GetObjectClass(env, this);
  jfieldID fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  jobject fdobj = (*env)->GetObjectField(env, this, fid);
  if (fdobj == NULL) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return -1;
  }
  cls = (*env)->GetObjectClass(env, fdobj);
  fid = (*env)->GetFieldID(env, cls, "fd", "I");
  fd = (*env)->GetIntField(env, fdobj, fid);
  if (fd == -1) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return -1;
  }

  if (newsocket == NULL) { 
    THROW_EXCEPTION(env, "java/lang/NullPointerException", "newsocket is NULL");
    return -1;
  }

  /* We expect that the 'fd' field of the newsocket has
   * been created outside of this method (but not initialized).
   */
  cls = (*env)->GetObjectClass(env, newsocket);
  fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  sptr_fdobj = (*env)->GetObjectField(env, newsocket, fid);

  if (sptr_fdobj == NULL) {
    THROW_EXCEPTION(env, "java/lang/NullPointerException", "newsocket uninitialized");
    return -1;
  }

  /* XXX MDW This is not threadsafe */
  if (!block) {
    nbio_make_nonblocking(env, fd);
  } else {
    nbio_make_blocking(env, fd);
  }

  DEBUG(fprintf(stderr,"NBIO: Doing accept() on fd=%d\n", fd));

#ifdef linux
  len = sizeof(him);
#endif 
#ifdef SOLARIS
  len = sizeof(struct sockaddr); 
#endif

  newfd = nbio_real_accept(fd, (struct sockaddr *)&him, &len);
  if (newfd < 0) {
    if (!block && errno == EWOULDBLOCK) return -1;
    else {
      THROW_EXCEPTION(env, "java/net/SocketException", strerror(errno));
      return -1;
    }
  }

  nbio_make_nonblocking(env, newfd);
  nbio_disable_nagle(env, newfd);

  cls = (*env)->GetObjectClass(env, sptr_fdobj);
  fid = (*env)->GetFieldID(env, cls, "fd", "I");
  // fd == -1 indicates not initialized
  (*env)->SetIntField(env, sptr_fdobj, fid, newfd);

  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "localport", "I");
  localport = (*env)->GetIntField(env, this, fid);

  /* Create empty InetAddress and initialize it */

  DEBUG(fprintf(stderr,"NBIO: accept() creating new InetAddress\n"));
  cls = (*env)->FindClass(env, "java/net/InetAddress");
  if (cls == NULL) {
    THROW_EXCEPTION(env, "java/net/SocketException", "Cannot find java.net.InetAddress class");
    return -1;
  }
  sptr_inetaddr = (*env)->AllocObject(env, cls);

  DEBUG(fprintf(stderr,"NBIO: accept() initializing new InetAddress\n"));

  fid = (*env)->GetFieldID(env, cls, "address", "I");

  (*env)->SetIntField(env, sptr_inetaddr, fid, ntohl(him.sin_addr.s_addr));
  fid = (*env)->GetFieldID(env, cls, "family", "I");
  (*env)->SetIntField(env, sptr_inetaddr, fid, him.sin_family);

  cls = (*env)->GetObjectClass(env, newsocket);
  fid = (*env)->GetFieldID(env, cls, "port", "I");
  (*env)->SetIntField(env, newsocket, fid, ntohs(him.sin_port));
  fid = (*env)->GetFieldID(env, cls, "localport", "I");
  (*env)->SetIntField(env, newsocket, fid, localport);
  fid = (*env)->GetFieldID(env, cls, "address", "Ljava/net/InetAddress;");
  (*env)->SetObjectField(env, newsocket, fid, sptr_inetaddr);

  return 0;

}

/*
 * Class:     ninja2_core_io_0005fcore_nbio_NonblockingSocketImpl
 * Method:    nbSocketAvailable
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_ninja2_core_io_1core_nbio_NonblockingSocketImpl_nbSocketAvailable (JNIEnv *env, jobject this) {
  int fd;
  int bytes;


  jclass cls = (*env)->GetObjectClass(env, this);
  jfieldID fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  jobject fdobj = (*env)->GetObjectField(env, this, fid);
  if (fdobj == NULL) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }
  cls = (*env)->GetObjectClass(env, fdobj);
  fid = (*env)->GetFieldID(env, cls, "fd", "I");
  fd = (*env)->GetIntField(env, fdobj, fid);
  if (fd == -1) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }

#ifdef linux
  if (ioctl(fd, FIONREAD, &bytes) < 0) {
#endif /* linux */
#ifdef SOLARIS
  if (ioctl(fd, I_NREAD, &bytes) < 0) {
#endif /* SOLARIS */
    THROW_EXCEPTION(env, "java/net/SocketException", strerror(errno));
    return;
  }

  DEBUG(fprintf(stderr,"NBIO: nbSocketAvailable called, %d bytes available\n", bytes));

  return bytes;

}

/*
 * Class:     ninja2_core_io_0005fcore_nbio_NonblockingSocketImpl
 * Method:    nbSocketClose
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ninja2_core_io_1core_nbio_NonblockingSocketImpl_nbSocketClose (JNIEnv * env, jobject this) {
  int fd; 
  jclass cls = (*env)->GetObjectClass(env, this);
  jfieldID fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  jobject fdobj = (*env)->GetObjectField(env, this, fid);
  if (fdobj == NULL) {
    //THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }
  cls = (*env)->GetObjectClass(env, fdobj);
  fid = (*env)->GetFieldID(env, cls, "fd", "I");
  fd = (*env)->GetIntField(env, fdobj, fid);
  if (fd == -1) {
    //THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }

  close(fd);

  (*env)->SetIntField(env, fdobj, fid, 0);
}

/* NonblockingSocketInputStream *******************************************/

/*
 * Class:     ninja2_core_io_0005fcore_nbio_NonblockingSocketInputStream
 * Method:    nbSocketRead
 * Signature: ([BII)I
 */
JNIEXPORT jint JNICALL Java_ninja2_core_io_1core_nbio_NonblockingSocketInputStream_nbSocketRead (JNIEnv *env, jobject this, jbyteArray b, jint off, jint len) {
  int fd;
  jclass cls;
  jfieldID fid;
  jobject fdobj;
  int datalen;
  char *data;
  int n;

  DEBUG(fprintf(stderr,"NBIO: nbSocketRead called, off=%d len=%d\n", off, len));

  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  fdobj = (*env)->GetObjectField(env, this, fid);
  if (fdobj == NULL) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }
  cls = (*env)->GetObjectClass(env, fdobj);
  fid = (*env)->GetFieldID(env, cls, "fd", "I");
  fd = (*env)->GetIntField(env, fdobj, fid);
  if (fd == -1) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }

  if (b == NULL) {
    THROW_EXCEPTION(env, "java/lang/NullPointerException", "null byte array passed to nbSocketRead");
    return;
  }
  datalen = (*env)->GetArrayLength(env, b);

  if (len < 0 || len + off > datalen) {
    THROW_EXCEPTION(env, "java/lang/ArrayIndexOutOfBoundsException", "len must be >= 0 and len + off <= array length");
  }

  data = (*env)->GetByteArrayElements(env, b, NULL);

  n = nbio_real_read(fd, data+off, len);
  
  DEBUG(fprintf(stderr,"NBIO: nbSocketRead: off is %d, len is %d, got %d, errno is %d\n", off, len, n, errno));

  if (n == 0) {
    // Socket was closed 
    (*env)->ReleaseByteArrayElements(env, b, data, JNI_ABORT);
    return -1; // EOF
  } else if (n < 0) {
    if (errno == EAGAIN) {
      (*env)->ReleaseByteArrayElements(env, b, data, JNI_ABORT);
      return 0; // No data returned
    } else {
      THROW_EXCEPTION(env, "java/net/SocketException", strerror(errno));
      (*env)->ReleaseByteArrayElements(env, b, data, JNI_ABORT);
      return -1; // error
    }
  }

  (*env)->ReleaseByteArrayElements(env, b, data, 0);
  return n;
}

/*
 * Class:     ninja2_core_io_0005fcore_nbio_NonblockingSocketOutputStream
 * Method:    nbSocketWrite
 * Signature: ([BII)I
 */
JNIEXPORT jint JNICALL Java_ninja2_core_io_1core_nbio_NonblockingSocketOutputStream_nbSocketWrite (JNIEnv *env, jobject this, jbyteArray b, jint off, jint len) {
  int fd;
  jclass cls;
  jfieldID fid;
  jobject fdobj;
  int datalen;
  char *data;
  int n;

  DEBUG(fprintf(stderr,"NBIO: nbSocketWrite called, off=%d len=%d\n", off, len));

  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  fdobj = (*env)->GetObjectField(env, this, fid);
  if (fdobj == NULL) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }
  cls = (*env)->GetObjectClass(env, fdobj);
  fid = (*env)->GetFieldID(env, cls, "fd", "I");
  fd = (*env)->GetIntField(env, fdobj, fid);
  if (fd == -1) {
    THROW_EXCEPTION(env, "java/net/SocketException", "socket closed");
    return;
  }

  if (b == NULL) {
    THROW_EXCEPTION(env, "java/lang/NullPointerException", "null byte array passed to nbSocketWrite");
    return;
  }
  datalen = (*env)->GetArrayLength(env, b);

  if (len < 0 || len + off > datalen) {
    THROW_EXCEPTION(env, "java/lang/ArrayIndexOutOfBoundsException", "len must be >= 0 and len + off <= array length");
  }

  data = (*env)->GetByteArrayElements(env, b, NULL);

  n = nbio_real_write(fd, data+off, len);
  
  DEBUG(fprintf(stderr,"NBIO: nbSocketWrite: off is %d, len is %d, got %d, errno is %d\n", off, len, n, errno));

  if (n < 0) {
    if (errno == EAGAIN) {
      (*env)->ReleaseByteArrayElements(env, b, data, JNI_ABORT);
      return 0; // No data returned
    } else {
      THROW_EXCEPTION(env, "java/net/SocketException", strerror(errno));
      (*env)->ReleaseByteArrayElements(env, b, data, JNI_ABORT);
      return -1; // error
    }
  }

  (*env)->ReleaseByteArrayElements(env, b, data, JNI_ABORT);
  return n;
}

/* SelectSetDevPollImpl ******************************************************/

#ifndef HAS_DEVPOLL

JNIEXPORT jboolean JNICALL Java_ninja2_core_io_1core_nbio_SelectSetDevPollImpl_supported(JNIEnv *env, jclass cls) {

  /* Safe setting when compiling on systems where /dev/poll not available */
  return JNI_FALSE;
}

#else  /* HAS_DEVPOLL */

/* Define to use B-Tree to map fd to selitemobj
#undef USE_BTREE    
/* Max number of file descriptors if flat table used */
#define MAX_FDS 4096

typedef struct devpoll_impl_state {
  int devpoll_fd;
  int max_retevents;
  struct pollfd *retevents;
#ifdef USE_BTREE
  btree_node *tree;
#else
  jobject selitems[MAX_FDS];
#endif
} devpoll_impl_state;

JNIEXPORT jboolean JNICALL Java_ninja2_core_io_1core_nbio_SelectSetDevPollImpl_supported(JNIEnv *env, jclass cls) {
  struct stat statbuf;

  /* If we were compiled on a system with /dev/poll, but running where
   * it's not available, return false
   */
  if (stat("/dev/poll", &statbuf) == 0) {
    return JNI_TRUE;
  } else {
    return JNI_FALSE;
  }
}

JNIEXPORT void JNICALL Java_ninja2_core_io_1core_nbio_SelectSetDevPollImpl_init (JNIEnv * env, jobject this, jint max_retevents) {
  jclass cls;
  jfieldID fid;
  devpoll_impl_state *state;
  int i;

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.init(%d) called\n", max_retevents));
    
  // Allocate state
  state = (devpoll_impl_state *)malloc(sizeof(devpoll_impl_state));
  if (state == NULL) {
    THROW_EXCEPTION(env, "java/lang/OutOfMemoryError", "Cannot allocate devpoll_impl_state");
    return;
  }

  // Set state field
  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "native_state", "J");
  (*env)->SetLongField(env, this, fid, (jlong)state);

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.init set state field\n"));

  state->max_retevents = max_retevents;
  state->devpoll_fd = open("/dev/poll", O_RDWR);
  if (state->devpoll_fd < 0) {
    THROW_EXCEPTION(env, "java/io/IOException", strerror(errno));
    return;
  }

#ifdef USE_BTREE
  state->tree = btree_newnode();
#else
  for (i = 0; i < MAX_FDS; i++) {
    state->selitems[i] = (jobject)NULL;
  }
#endif

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.init opened /dev/poll, fd %d\n", state->devpoll_fd));

  state->retevents = (struct pollfd *)malloc(max_retevents * sizeof(struct pollfd));
  if (state->retevents == NULL) {
    THROW_EXCEPTION(env, "java/lang/OutOfMemoryError", "Cannot allocate state->retevents");
    return;
  }

  return;
}

JNIEXPORT void JNICALL Java_ninja2_core_io_1core_nbio_SelectSetDevPollImpl_register (JNIEnv * env, jobject this, jobject selitemobj) {
  devpoll_impl_state *state;
  jclass cls, cls2;
  jfieldID fid, fid2, fid_events;
  jobject fdobj;
  short events, realevents;
  struct pollfd pfd;
  void *data;
  jobject selitem;

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.register called\n"));

  // Get state
  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "native_state", "J");
  state = (devpoll_impl_state *)((*env)->GetLongField(env, this, fid));

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.register got state, fd %d\n", state->devpoll_fd));

  // Get class and field IDs
  cls = (*env)->FindClass(env, "ninja2/core/io_core/nbio/SelectItem");
  fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  fid_events = (*env)->GetFieldID(env, cls, "events", "S");
  cls2 = (*env)->FindClass(env, "ninja2/core/io_core/nbio/NBIOFileDescriptor");
  fid2 = (*env)->GetFieldID(env, cls2, "fd", "I");

  // Get fd
  fdobj = (*env)->GetObjectField(env, selitemobj, fid);
  pfd.fd = (*env)->GetIntField(env, fdobj, fid2);
  // Get events
  events = (*env)->GetShortField(env, selitemobj, fid_events);
  realevents = 0;
  if (events != 0) {
    if (events & SELECTABLE_READ_READY) {
      realevents |= (POLLIN | POLLPRI);
    }
    if (events & SELECTABLE_WRITE_READY) {
      realevents |= POLLOUT;
    }
    pfd.events = realevents;
  }

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.register adding (fd=%d,events=0x%x)\n", pfd.fd, pfd.events));

  // Register
  if (write(state->devpoll_fd, &pfd, sizeof(struct pollfd)) != sizeof(struct pollfd)) {
    THROW_EXCEPTION(env, "java/io/IOException", strerror(errno));
    return;
  }

#ifdef USE_BTREE
  data = btree_search(state->tree, pfd.fd);
  if (data == NULL) {
    // Insert into B-tree
    state->tree = btree_insert(state->tree, pfd.fd, (*env)->NewGlobalRef(env, selitemobj));
  }
#else
  if ((pfd.fd < 0) || (pfd.fd >= MAX_FDS)) {
    fprintf(stderr,"Warning: pfd.fd is %d, out of range 0...%d.\n",MAX_FDS);
    fprintf(stderr,"  You need to recompile nbio.c with a larger MAX_FDS value.\n");
    return;
  }
  selitem = state->selitems[pfd.fd];
  if (selitem == (jobject)NULL) {
    state->selitems[pfd.fd] = (*env)->NewGlobalRef(env, selitemobj);
  }
#endif

  return;
}

JNIEXPORT void JNICALL Java_ninja2_core_io_1core_nbio_SelectSetDevPollImpl_deregister (JNIEnv * env, jobject this, jobject selitemobj) {
  devpoll_impl_state *state;
  jclass cls, cls2;
  jfieldID fid, fid2;
  jobject fdobj, selitem;
  struct pollfd pfd;

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.deregister called\n"));

  // Get state
  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "native_state", "J");
  state = (devpoll_impl_state *)((*env)->GetLongField(env, this, fid));

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.deregister got state, fd %d\n", state->devpoll_fd));

  // Get class and field IDs
  cls = (*env)->FindClass(env, "ninja2/core/io_core/nbio/SelectItem");
  fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  cls2 = (*env)->FindClass(env, "ninja2/core/io_core/nbio/NBIOFileDescriptor");
  fid2 = (*env)->GetFieldID(env, cls2, "fd", "I");

  // Get fd
  fdobj = (*env)->GetObjectField(env, selitemobj, fid);
  pfd.fd = (*env)->GetIntField(env, fdobj, fid2);
  pfd.events = POLLREMOVE;

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.deregister removing (fd=%d,events=0x%x)\n", pfd.fd, pfd.events));

  // Deeegister
  if (write(state->devpoll_fd, &pfd, sizeof(struct pollfd)) != sizeof(struct pollfd)) {
    THROW_EXCEPTION(env, "java/io/IOException", strerror(errno));
    return;
  }

#ifdef USE_BTREE
  // XXX NEED TO DELETE NODE FROM BTREE
#else
  if ((pfd.fd < 0) || (pfd.fd >= MAX_FDS)) {
    fprintf(stderr,"Warning: pfd.fd is %d, out of range 0...%d.\n",MAX_FDS);
    fprintf(stderr,"  You need to recompile nbio.c with a larger MAX_FDS value.\n");
    return;
  }
  selitem = state->selitems[pfd.fd];
  if (selitem != (jobject)NULL) {
    // selitem can be NULL if deregister is not synchronized 
    // (although it should be)
    (*env)->DeleteGlobalRef(env, selitem);
    state->selitems[pfd.fd] = (jobject)NULL;
  }
#endif

  return;
}

JNIEXPORT jint JNICALL Java_ninja2_core_io_1core_nbio_SelectSetDevPollImpl_doSelect (JNIEnv * env, jobject this, jint timeout) {
  devpoll_impl_state *state;
  jclass cls, cls2;
  jfieldID fid, fid2, fid_fd, fid_revents;
  jobject selitemobj, fdobj;
  jobjectArray itemarr, retitemarr;
  struct dvpoll dopoll;
  int itemarrlen, ret, i, j, fd, retfd, count;
  void *data;
  struct pollfd *pfd;
  short realevents;

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.doSelect called\n"));

  // Get state
  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "native_state", "J");
  state = (devpoll_impl_state *)((*env)->GetLongField(env, this, fid));

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.doSelect got state, fd=%d\n",state->devpoll_fd));

  // Get itemarray
  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "itemarr", "[Lninja2/core/io_core/nbio/SelectItem;");
  itemarr = (jobjectArray)((*env)->GetObjectField(env, this, fid));
  if (itemarr == NULL) {
    // This can happen if we have an empty SelectSet 
    return 0;
  }
  itemarrlen = (*env)->GetArrayLength(env, itemarr);
  if (itemarrlen <= 0) {
    THROW_EXCEPTION(env, "java/lang/ArrayIndexOutOfBoundsException", "SelectItem[] array has size <= 0");
    return 0;
  }

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.doSelect got itemarr, len %d\n",itemarrlen));

  // Get retitemarr
  fid = (*env)->GetFieldID(env, cls, "retevents", "[Lninja2/core/io_core/nbio/SelectItem;");
  retitemarr = (jobjectArray)((*env)->GetObjectField(env, this, fid));

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.doSelect got retitemarr, length %d\n", ((*env)->GetArrayLength(env, retitemarr))));

  // Get fid_revents
  cls = (*env)->FindClass(env, "ninja2/core/io_core/nbio/SelectItem");
  fid_revents = (*env)->GetFieldID(env, cls, "revents", "S");
  fid_fd = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  // Get fid2
  cls2 = (*env)->FindClass(env, "ninja2/core/io_core/nbio/NBIOFileDescriptor");
  fid2 = (*env)->GetFieldID(env, cls2, "fd", "I");

  // Fill in dopoll
  dopoll.dp_timeout = timeout;
  dopoll.dp_nfds = state->max_retevents;
  dopoll.dp_fds = state->retevents;

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.doSelect doing DP_POLL\n"));

  ret = ioctl(state->devpoll_fd, DP_POLL, &dopoll);

  DEBUG(fprintf(stderr,"SelectSetDevPollImpl.doSelect DP_POLL returned %d\n", ret));

  if (ret == 0) {
    return 0;
  }
  if (ret < 0) {
    int myerrno = errno;
    // Don't throw an exception if we were interrupted
    if (myerrno != EINTR) {
      THROW_EXCEPTION(env, "java/io/IOException", strerror(myerrno));
    } 
    return 0;
  }

  count = 0;
  for (i = 0; i < ret; i++) {
    pfd = &(state->retevents[i]);

    DEBUG(fprintf(stderr,"SelectSetDevPollImpl.doSelect ret[%d] fd %d revents 0x%x\n", i, pfd->fd, pfd->revents));
    retfd = pfd->fd;

#ifdef USE_BTREE
    data = btree_search(state->tree, retfd);
    if (data == NULL) {
      THROW_EXCEPTION(env, "java/lang/ArrayIndexOutOfBoundsException", "retfd not found in registered set");
      return 0;
    }
    selitemobj = (jobject)data;
#else 
    if ((retfd < 0) || (retfd >= MAX_FDS)) {
      fprintf(stderr,"Warning: retfd is %d, out of range 0...%d.\n",MAX_FDS);
      fprintf(stderr,"  You need to recompile nbio.c with a larger MAX_FDS value.\n");
      THROW_EXCEPTION(env, "java/lang/ArrayIndexOutOfBoundsException", "retfd out of range");
      return 0;
    }
    selitemobj = state->selitems[retfd];
    if (selitemobj == (jobject)NULL) {
      THROW_EXCEPTION(env, "java/lang/ArrayIndexOutOfBoundsException", "retfd not found in registered set");
      return 0;
    }
#endif
    DEBUG(fprintf(stderr,"Got selitemobj 0x%lx\n", (unsigned long)selitemobj));

    realevents = 0;
    if (pfd->revents & (POLLIN | POLLPRI)) {
      realevents |= SELECTABLE_READ_READY;
    }
    if (pfd->revents & POLLOUT) {
      realevents |= SELECTABLE_WRITE_READY;
    }
    if (pfd->revents & (POLLERR | POLLHUP | POLLNVAL)) {
      realevents |= SELECTABLE_SELECT_ERROR;
    }

    (*env)->SetShortField(env, selitemobj, fid_revents, realevents);
    DEBUG(fprintf(stderr,"Set revents\n"));
    (*env)->SetObjectArrayElement(env, retitemarr, count, selitemobj);
    DEBUG(fprintf(stderr,"Set retitemarr[%d]\n", count));
    count++;
  }

  return ret;
}

#endif /* HAS_DEVPOLL */

/* SelectSetPollImpl *******************************************************/

JNIEXPORT jint JNICALL Java_ninja2_core_io_1core_nbio_SelectSetPollImpl_doSelect(JNIEnv *env, jobject this, jint timeout) {
  jclass cls, cls2;
  jfieldID fid, fid2, fid_events, fid_revents;
  jobjectArray itemarr;
  jobject selitemobj, fdobj;
  struct pollfd *ufds;
  int *ufds_map;
  int itemarrlen;
  int i, n;
  int ret;
  int num_ufds = 0;
  short events, realevents;

  DEBUG(fprintf(stderr,"NBIO: doSelect called\n"));

  cls = (*env)->GetObjectClass(env, this);
  fid = (*env)->GetFieldID(env, cls, "itemarr", "[Lninja2/core/io_core/nbio/SelectItem;");
  itemarr = (jobjectArray)(*env)->GetObjectField(env, this, fid);
  if (itemarr == NULL) {
    // This can happen if we have an empty SelectSet 
    return 0;
  }

  DEBUG(fprintf(stderr,"NBIO: doSelect: got itemarr\n"));

  itemarrlen = (*env)->GetArrayLength(env, itemarr);
  if (itemarrlen <= 0) {
    THROW_EXCEPTION(env, "java/lang/ArrayIndexOutOfBoundsException", "SelectItem[] array has size <= 0");
    return 0;
  }

  DEBUG(fprintf(stderr,"NBIO: doSelect: itemarrlen is %d\n", itemarrlen));

  cls = (*env)->FindClass(env, "ninja2/core/io_core/nbio/SelectItem");

  DEBUG(fprintf(stderr,"NBIO: doSelect: got SelectItem class\n"));
  
  fid = (*env)->GetFieldID(env, cls, "fd", "Lninja2/core/io_core/nbio/NBIOFileDescriptor;");
  fid_events = (*env)->GetFieldID(env, cls, "events", "S");
  fid_revents = (*env)->GetFieldID(env, cls, "revents", "S");
  cls2 = (*env)->FindClass(env, "ninja2/core/io_core/nbio/NBIOFileDescriptor");
  fid2 = (*env)->GetFieldID(env, cls2, "fd", "I");

  // Only allocate a ufd if events != 0
  for (i = 0; i < itemarrlen; i++) {
    selitemobj = (*env)->GetObjectArrayElement(env, itemarr, i);
    if (selitemobj == NULL) {
      fprintf(stderr,"NBIO: WARNING: itemarr[%d] is NULL! (itemarrlen=%d)\n", i, itemarrlen);
      THROW_EXCEPTION(env, "java/lang/NullPointerException", "SelectItem element is null");
      return 0;
    }
    events = (*env)->GetShortField(env, selitemobj, fid_events);
    if (events != 0) num_ufds++;
  }

  if (num_ufds == 0) return 0;

  ufds = (struct pollfd *)malloc(sizeof(struct pollfd) * num_ufds);
  if (ufds == NULL) {
    THROW_EXCEPTION(env, "java/lang/OutOfMemoryError", "cannot allocate pollfd array");
    return 0;
  }
  DEBUG(fprintf(stderr,"NBIO: doSelect: allocated %d ufds\n", num_ufds));
  ufds_map = (int *)malloc(sizeof(int) * num_ufds);
  if (ufds_map == NULL) {
    THROW_EXCEPTION(env, "java/lang/OutOfMemoryError", "cannot allocate ufds_map");
    free(ufds);
    return 0;
  }
    
  n = 0;
  for (i = 0; i < itemarrlen; i++) {
    selitemobj = (*env)->GetObjectArrayElement(env, itemarr, i);
    if (selitemobj == NULL) {
      THROW_EXCEPTION(env, "java/lang/NullPointerException", "SelectItem element is null");
      free(ufds);
      free(ufds_map);
      return 0;
    }

    realevents = 0;
    events = (*env)->GetShortField(env, selitemobj, fid_events);
    if (events != 0) {
      if (events & SELECTABLE_READ_READY) {
        realevents |= (POLLIN | POLLPRI);
      }
      if (events & SELECTABLE_WRITE_READY) {
        realevents |= POLLOUT;
      }
      ufds[n].events = realevents;
      DEBUG(fprintf(stderr,"NBIO: doSelect: ufds[%d].events is 0x%x\n", n, ufds[n].events));
      ufds[n].revents = 0;
      fdobj = (*env)->GetObjectField(env, selitemobj, fid);
      ufds[n].fd = (*env)->GetIntField(env, fdobj, fid2);
      DEBUG(fprintf(stderr,"NBIO: doSelect: ufds[%d].fd is %d\n", n, ufds[n].fd));
      ufds_map[n] = i;
      n++;
    }
  }

  /* XXX MDW: poll() is interruptible. Under Linux, a signal (say, from 
   * the GC) might interrupt poll. For now I don't deal with this
   * properly - I just go ahead and return early from doSelect() if the 
   * call was interrupted.
   */
  DEBUG(fprintf(stderr,"NBIO: Doing poll, %d fds, timeout %d\n", n, timeout));

  ret = nbio_real_poll(ufds, num_ufds, timeout);

  DEBUG(fprintf(stderr,"NBIO: doSelect: did poll, timeout %d, ret is %d, errno is %d\n", timeout, ret, errno));

  if (ret == 0) {
    free(ufds);
    free(ufds_map);
    return 0;
  }
  if (ret < 0) {
    int myerrno = errno;
    // Don't throw an exception if we were interrupted
    if (myerrno != EINTR) {
      THROW_EXCEPTION(env, "java/io/IOException", strerror(myerrno));
    } 
    free(ufds);
    free(ufds_map);
    return 0;
  }

  for (n = 0; n < num_ufds; n++) {
    DEBUG(fprintf(stderr,"NBIO: doSelect: ufds[%d].revents is 0x%x\n", n, ufds[n].revents));

    if (ufds[n].revents != 0) {

      i = ufds_map[n];
      selitemobj = (*env)->GetObjectArrayElement(env, itemarr, i);
      if (selitemobj == NULL) {
        THROW_EXCEPTION(env, "java/lang/NullPointerException", "SelectItem element is null");
        free(ufds);
        free(ufds_map);
        return 0;
      }

      realevents = 0;
      if (ufds[n].revents & (POLLIN | POLLPRI)) {
        realevents |= SELECTABLE_READ_READY;
      }
      if (ufds[n].revents & POLLOUT) {
        realevents |= SELECTABLE_WRITE_READY;
      }
      if (ufds[n].revents & (POLLERR | POLLHUP | POLLNVAL)) {
        realevents |= SELECTABLE_SELECT_ERROR;
      }

      DEBUG(fprintf(stderr,"NBIO: doSelect: setting itemarr[%d].revents to 0x%x\n", i, realevents));
      (*env)->SetShortField(env, selitemobj, fid_revents, realevents);
    }
  }

  free(ufds);
  free(ufds_map);

  DEBUG(fprintf(stderr,"NBIO: doSelect: returning %d\n", ret));
  return ret;

}

