//////////////////////license & copyright header///////////////////////
//                                                                   //
//                Copyright (c) 1998 by Kevin Kelley                 //
//                                                                   //
// This program is free software; you can redistribute it and/or     //
// modify it under the terms of the GNU General Public License as    //
// published by the Free Software Foundation; either version 2 of    //
// the License, or (at your option) any later version.               //
//                                                                   //
// This program is distributed in the hope that it will be useful,   //
// but WITHOUT ANY WARRANTY; without even the implied warranty of    //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     //
// GNU General Public License for more details.                      //
//                                                                   //
// You should have received a copy of the GNU General Public License //
// along with this program in the file 'gpl.html'; if not, write to  //
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  //
// Boston, MA 02111-1307, USA, or contact the author:                //
//                                                                   //
//                       Kevin Kelley  <kelley@iguana.ruralnet.net>  //
//                                                                   //
////////////////////end license & copyright header/////////////////////
import java.io.*;
import java.util.zip.*;

class Zipper {

    private static String progName = getClass().getName();
    private static boolean verbose = false;
    private static int compressionLevel = Deflater.DEFAULT_COMPRESSION;

    public static void main( String[] args )
    {
        int argc = args.length;
        int argn;

        // Parse args.
        for (argn=0; (argn<args.length) && args[argn].charAt(0)=='-'; ++argn)
        {
            if ( args[argn].equals( "-v" ) )
                verbose = true;
            else if ( args[argn].equals( "-l" ) ) {
                ++argn;
                compressionLevel = Integer.parseInt(args[argn]);
            } else {
                return usage();
            }
        }
        if ( argc - argn < 1 )
        {
            return usage();
        }
        else try
        {
            // first arg is name of zipfile
            String zipName = args[argn++];

            // create and initialize a stream to write it
            ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(zipName));
            zip.setComment("created by Starlight - http://www.ruralnet.net/~kelley/index.html");
            zip.setMethod(ZipOutputStream.DEFLATED);
            zip.setLevel(compressionLevel);

            // the remaining args are files to put in the zip
            for ( ; argn < args.length; ++argn )
            {
                // read a file into memory
                File file = new File(args[argn]);
                FileInputStream in = new FileInputStream(file);
                byte[] bytes = new byte[in.available()];
                in.read(bytes);
                in.close();

                // create and initialize a zipentry for it
                ZipEntry entry = new ZipEntry(file.getName());
                entry.setTime(file.lastModified());

                // write the entry header, and the data, to the zip
                zip.putNextEntry(entry);
                zip.write(bytes);

                // write the end-of-entry marker to the zip
                zip.closeEntry();
            }
            // no more files, close the zip.  This writes the zip
            // directory, so don't forget it.
            zip.close();
        }
        catch (Exception e) { e.printStackTrace(); }
    }

    private static int usage() {
        System.err.println( "usage:  " + progName + " [-v] [-f] [-l level] zipfile files" );
        return 0;  // exit_success
    }
}

