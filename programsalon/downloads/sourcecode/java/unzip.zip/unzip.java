//////////////////////license & copyright header///////////////////////
//                                                                   //
//                Copyright (c) 1998 by Kevin Kelley                 //
//                                                                   //
// This program is free software; you can redistribute it and/or     //
// modify it under the terms of the GNU General Public License as    //
// published by the Free Software Foundation; either version 2 of    //
// the License, or (at your option) any later version.               //
//                                                                   //
// This program is distributed in the hope that it will be useful,   //
// but WITHOUT ANY WARRANTY; without even the implied warranty of    //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     //
// GNU General Public License for more details.                      //
//                                                                   //
// You should have received a copy of the GNU General Public License //
// along with this program in the file 'gpl.html'; if not, write to  //
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  //
// Boston, MA 02111-1307, USA, or contact the author:                //
//                                                                   //
//                       Kevin Kelley  <kelley@iguana.ruralnet.net>  //
//                                                                   //
////////////////////end license & copyright header/////////////////////
import java.io.*;
import java.util.Enumeration;
import java.util.zip.*;

public class Unzip {

  public static void main( String[] args )
  {
    if (args.length != 1)
    {
      System.out.println("usage:  Unzip file.zip");
      return;
    }

    if (!(new File(args[0])).exists())
    {
      System.out.println("can't open " + args[0]);
      return;
    }
    try
    {
      ZipFile archive = new ZipFile(args[0]);

      // do our own buffering; reuse the same buffer.
      byte[] buffer = new byte[16384];

      for ( Enumeration e=archive.entries(); e.hasMoreElements(); )
      {
        // get the next entry in the archive
        ZipEntry entry = (ZipEntry) e.nextElement();

        String filename = entry.getName();
        filename = filename.replace('/', File.separatorChar);
        File destFile = new File(filename);

        if (destFile.exists())
        {
          System.out.println("..skipping "+filename+" (overwrite not implemented).");
        }
        else
        {
          System.out.println("..writing "+filename);

          // create the destination path, if needed
          String parent = destFile.getParent();
          if (parent!=null)
          {
            File parentFile = new File(parent);
            if (!parentFile.exists())
            {
              // create the chain of subdirs to the file
              parentFile.mkdirs();
            }
          }

          // get a stream of the archive entry's bytes
          InputStream in = archive.getInputStream(entry);

          // open a stream to the destination file
          OutputStream out = new FileOutputStream(filename);

          // repeat reading into buffer and writing buffer to file,
          // until done.  count will always be # bytes read, until
          // EOF when it is -1.
          int count;
          while((count=in.read(buffer)) != -1)
            out.write(buffer, 0, count);

          in.close();
          out.close();
        }
      }
    }
    catch(Exception e) {e.printStackTrace();}
  }
}

