/* ---------------------------------------------------------------------------

   This code can be used as you wish but without warranties as to performance 
   of merchantability or any other warranties whether expressed or implied.
   
	 Written by Mike Funduc, Funduc Software Inc. 8/1/96

	 To download the code and more useful utilities (including Search and
	 Replace for Windows 95/NT, 3.1x) go to:
	 http://www.funduc.com

----------------------------------------------------------------------------*/

// hexviewView.h : interface of the CHexviewView class
//
/////////////////////////////////////////////////////////////////////////////

class CHexviewView : public CScrollView
{
protected: // create from serialization only
	CHexviewView();
	DECLARE_DYNCREATE(CHexviewView)

// Attributes
public:
	void UpdateScrollSizes();
	CHexviewDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHexviewView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHexviewView();
	void DispData(CDC* pDC, int iFirstLine, int iTotalLines, CFont *cfFixedFont,
							CFont *cfBoldFont, 
							int iWndLines, int iFontHeight, int iCurrentOffset,
							int iFontWidth, int iLine = 0);
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

private:
    CFont *m_cfFixedFont;
    CFont *m_cfBoldFont;
    CFont *m_cfPrintFont;
    CFont *m_cfPrintBoldFont;
    int m_iFontWidth;
    int m_iFontHeight;
    int m_iFirstLine;
    int m_iLastLine;
    int m_iWndLines;
	int m_iViewHeight;
	int m_iCurrentOffset;
	CString m_strTimePrint;
protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CHexviewView)
	afx_msg void OnDestroy();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnViewNextblock();
	afx_msg void OnViewPreviousblock();
	afx_msg void OnUpdateViewNextblock(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewPreviousblock(CCmdUI* pCmdUI);
	afx_msg void OnViewGoto();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in hexviewView.cpp
inline CHexviewDoc* CHexviewView::GetDocument()
   { return (CHexviewDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
