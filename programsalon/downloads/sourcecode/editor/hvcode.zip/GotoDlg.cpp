/* ---------------------------------------------------------------------------

   This code can be used as you wish but without warranties as to performance 
   of merchantability or any other warranties whether expressed or implied.
   
	 Written by Mike Funduc, Funduc Software Inc. 8/1/96

	 To download the code and more useful utilities (including Search and
	 Replace for Windows 95/NT, 3.1x) go to: http://www.funduc.com

----------------------------------------------------------------------------*/

// GotoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "hexview.h"
#include "GotoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGotoDlg dialog


CGotoDlg::CGotoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGotoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGotoDlg)
	m_lNewOffset = 0;
	//}}AFX_DATA_INIT
}


void CGotoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	CString strText;
	//{{AFX_DATA_MAP(CGotoDlg)
	//}}AFX_DATA_MAP
	if (pDX->m_bSaveAndValidate)  // Validating
	{
		DDX_Text(pDX, IDC_OFFSET_ED, strText);
		const char *startptr = (LPCSTR)strText;
		char *endptr;
		m_lNewOffset = strtol(startptr, &endptr, 0);
		if (*endptr != 0) // Not really a number
			m_lNewOffset = -1;
		DDV_MinMaxLong(pDX, m_lNewOffset, 0, 2000000000);
	}
	else						  // Initial display
		DDX_Text(pDX, IDC_OFFSET_ED, m_lNewOffset);
}


BEGIN_MESSAGE_MAP(CGotoDlg, CDialog)
	//{{AFX_MSG_MAP(CGotoDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGotoDlg message handlers
