/* ---------------------------------------------------------------------------

   This code can be used as you wish but without warranties as to performance 
   of merchantability or any other warranties whether expressed or implied.
   
	 Written by Mike Funduc, Funduc Software Inc. 8/1/96

	 To download the code and more useful utilities (including Search and
	 Replace for Windows 95/NT, 3.1x) go to: http://www.funduc.com

----------------------------------------------------------------------------*/

// hexview.h : main header file for the HEXVIEW application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CHexviewApp:
// See hexview.cpp for the implementation of this class
//
class CHexCommandLine : public CCommandLineInfo
{
protected:
	virtual void ParseParam( LPCTSTR lpszParam, BOOL bFlag, BOOL bLast);
public:
	CHexCommandLine() : CCommandLineInfo(), m_lStartOffset(-1), m_lEndOffset(-1) {};
	long m_lStartOffset, m_lEndOffset;
};

class CHexviewApp : public CWinApp
{
public:
	CHexviewApp();
	void GetOffsets(long &lStartOffset, long &lEndOffset);

private:
	long m_lStartOffset, m_lEndOffset;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHexviewApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CHexviewApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

// Returns application pointer (already cast)
CHexviewApp *HexGetApp();

/////////////////////////////////////////////////////////////////////////////
