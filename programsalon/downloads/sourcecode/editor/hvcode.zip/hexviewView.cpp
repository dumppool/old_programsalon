/* ---------------------------------------------------------------------------

   This code can be used as you wish but without warranties as to performance 
   of merchantability or any other warranties whether expressed or implied.
   
	 Written by Mike Funduc, Funduc Software Inc. 8/1/96

	 To download the code and more useful utilities (including Search and
	 Replace for Windows 95/NT, 3.1x) go to:
	 http://www.funduc.com

----------------------------------------------------------------------------*/

// hexviewView.cpp : implementation of the CHexviewView class
//

#include "stdafx.h"
#include "hexview.h"

#include "hexviewDoc.h"
#include "hexviewView.h"
#include "gotodlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern BOOL bDBCS;

/////////////////////////////////////////////////////////////////////////////
// CHexviewView

IMPLEMENT_DYNCREATE(CHexviewView, CScrollView)

BEGIN_MESSAGE_MAP(CHexviewView, CScrollView)
	//{{AFX_MSG_MAP(CHexviewView)
	ON_WM_DESTROY()
	ON_WM_VSCROLL()
	ON_WM_KEYDOWN()
	ON_WM_SIZE()
	ON_COMMAND(ID_VIEW_NEXTBLOCK, OnViewNextblock)
	ON_COMMAND(ID_VIEW_PREVIOUSBLOCK, OnViewPreviousblock)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NEXTBLOCK, OnUpdateViewNextblock)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PREVIOUSBLOCK, OnUpdateViewPreviousblock)
	ON_COMMAND(ID_VIEW_GOTO, OnViewGoto)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHexviewView construction/destruction

CHexviewView::CHexviewView()
{
    m_cfFixedFont = new(CFont);
	if (bDBCS)
		m_cfFixedFont->CreateStockObject(SYSTEM_FIXED_FONT);
	else
		m_cfFixedFont->CreateStockObject(ANSI_FIXED_FONT);
	m_cfBoldFont = new CFont;
	    // try and create the new font for the list box
    // it should be the same as the old but without the BOLD weight
    LOGFONT oldFont;
    m_cfFixedFont->GetObject(sizeof(LOGFONT), &oldFont);
    
	oldFont.lfUnderline = TRUE;

    m_cfBoldFont->CreateFontIndirect(&oldFont);
    m_cfPrintFont = NULL;
    m_cfPrintBoldFont = NULL;

	m_iCurrentOffset = 0;

}

CHexviewView::~CHexviewView()
{
	delete m_cfBoldFont;
	delete m_cfPrintFont;
	delete m_cfPrintBoldFont;
}

/////////////////////////////////////////////////////////////////////////////
// CHexviewView drawing

void CHexviewView::OnDraw(CDC* pDC)
{
	CHexviewDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	DispData(pDC, m_iFirstLine, pDoc->TotalFileLength(), m_cfFixedFont,
							m_cfBoldFont, m_iWndLines, m_iFontHeight, m_iCurrentOffset, m_iFontWidth);
}

void CHexviewView::DispData(CDC* pDC, int iFirstLine, int iTotalLines, 
							CFont *cfFixedFont, CFont *cfBoldFont,
							int iWndLines, int iFontHeight, int iCurrentOffset, 
							int iFontWidth, int iLine)
{
    CFont *pOldFont = pDC->SelectObject(cfFixedFont);

    CRect rcWnd;
    GetClientRect(&rcWnd);

    // compute the start point
    int iOffset = iFirstLine * 16 + iCurrentOffset;
    int iRemaining = iTotalLines - iOffset;
    CHexviewDoc* pDoc = GetDocument();
    BYTE *pData = pDoc->AdjustPointerAbsolute(0);
	bool bIgnoreThisChar = false;

	int x=0;
    if (!pData) 
	{
        pDC->TextOut(0, 0, "No data", 7);
    } 
	else 
	{
        char buf[100], buf2[100];
        while ((iRemaining > 0) && (iLine < iWndLines)) 
		{
            sprintf(buf, "%8.8lX  ", iOffset);
            BYTE *p = pData + iOffset;
            int iCount = iRemaining;
            for (int i = 0; i < 16; i++) 
			{
                if (iCount > 0) 
				{
                    sprintf(&buf[strlen(buf)],
                            "%2.2X ",
                            *p);
                } 
				else 
				{
                    strcat(buf, "   ");
                }
                iCount--;
                p++;
            }
            strcat(buf, "  ");
            p = pData + iOffset;
            iCount = iRemaining;
            for (i = 0; i < 16; i++) 
			{
				// If bIgnoreThisChar is true, this is that case that last line endded
				// with lead byte of double byte char and the value of this tail byte 
				// is in the range  of lead byte. Yuk!

				// If this is double byte char, need to deal with it now!
				// IsDBCSLeadByte() may return TRUE for tail byte if its value is
				// in the range of lead bytes'
                if ((bDBCS) && (IsDBCSLeadByte(*p)) && !bIgnoreThisChar)
                {
					sprintf(&buf[strlen(buf)], "%c%c", *p, *(p + 1));
					iCount-=2;
					p+=2;
					i++;
					if (i >= 16)
						bIgnoreThisChar = true;
	                continue;
                }
                if ((iCount > 0) && isprint(*p) && !bIgnoreThisChar) 
				{
                    sprintf(&buf[strlen(buf)], "%c", *p);
                } 
				else if (iCount > 0) 
				{
                    strcat(buf, ".");
                } 
				else 
				{
                    strcat(buf, " ");
                }
				bIgnoreThisChar = false;
                iCount--;
                p++;
            }

			// Need to blank out rest of this line
			// This is to make all lines same length, otherwise, list control will have junk displayed.
#define	LINE_LENGTH		78
			if ((i = strlen(buf)) < LINE_LENGTH)
			{
				memset(&buf[i], ' ', LINE_LENGTH-i);
				buf[LINE_LENGTH]=0;
			}

			if ((iOffset + 16 >= pDoc->m_lStartOffset) && (iOffset < pDoc->m_lEndOffset))
			{
				strcpy(buf2, buf);
				CSize szExtent;
				int nStartOnLine = max(0, pDoc->m_lStartOffset - iOffset);
				int nItemsOnLine = min(pDoc->m_lEndOffset, iOffset + 16) - max(pDoc->m_lStartOffset, iOffset);
				// Characters before highlight
				pDC->TextOut(0, iLine * iFontHeight, buf, nStartOnLine * 3 + 10);
				szExtent = pDC->GetTextExtent(buf, nStartOnLine * 3 + 10);
				memcpy(buf, buf2 + nStartOnLine * 3 + 10, (16 - nStartOnLine) * 3 + 2);
				buf[(16 - nStartOnLine) * 3 + 2] = 0;
				pDC->SelectObject(cfBoldFont);
				// Highlight characters
				pDC->TextOut(szExtent.cx, iLine * iFontHeight, buf, nItemsOnLine * 3);
				szExtent += pDC->GetTextExtent(buf, nItemsOnLine * 3);
				pDC->SelectObject(cfFixedFont);
				strcpy(buf, buf2 + (nStartOnLine + nItemsOnLine) * 3 + 10);
				// Characters after highlight
				pDC->TextOut(szExtent.cx, iLine * iFontHeight, buf, strlen(buf));
				pDC->MoveTo(0, (iLine + 1) * iFontHeight);
			}
			else  // Just a regular line
				pDC->TextOut(0, iLine * iFontHeight, buf, strlen(buf));
            iOffset += 16;
            iRemaining -= 16;
            iLine++;
        }
        if (iLine < iWndLines) 
		{
            CRect rc = rcWnd;
            rc.top = iLine * iFontHeight;
            pDC->ExtTextOut(0, iLine * iFontHeight, ETO_OPAQUE,
                            &rc, "", 0, NULL);
        }
    }
    pDC->SelectObject(pOldFont);
}

void CHexviewView::OnInitialUpdate()
{
    CDC *pDC = GetDC();
    CFont *pOldFont = pDC->SelectObject(m_cfFixedFont);
    pDC->SelectObject(pOldFont);
    CHexviewDoc* pDoc = GetDocument();
    m_iLastLine = 0;
    m_iWndLines = 0;
	m_iFirstLine = 0;

	CScrollView::OnInitialUpdate();

	UpdateScrollSizes();
	if (pDoc->m_lStartOffset > -1)
	{
		if (pDoc->m_lStartOffset > pDoc->TotalFileLength())
		{
			m_iFirstLine = 0;
			pDoc->m_lStartOffset = pDoc->m_lEndOffset = -1;
		}
		else
		{
			while (pDoc->m_lStartOffset > m_iCurrentOffset + pDoc->BlockLength(m_iCurrentOffset))
			{
				pDoc->GetNextBlock(m_iCurrentOffset);
			}
			m_iFirstLine = (pDoc->m_lStartOffset - m_iCurrentOffset) / 16;
			m_iLastLine = (pDoc->BlockLength(m_iCurrentOffset) + 15) / 16;
			UpdateScrollSizes();
		}
	}
}

void CHexviewView::UpdateScrollSizes()
{
	// UpdateScrollSizes() is called when it is necessary to adjust the
	// scrolling range or page/line sizes.  There are two occassions
	// where this is necessary:  (1) when a new row is added-- see
	// UpdateRow()-- and (2) when the window size changes-- see OnSize().
	CRect rectClient;
	GetClientRect(&rectClient);

	CClientDC dc(this);
    TEXTMETRIC tm;
    dc.GetTextMetrics(&tm);
    m_iFontHeight = tm.tmHeight + tm.tmExternalLeading;
    m_iFontWidth = tm.tmMaxCharWidth;

    CSize sz;
    sz.cx = m_iFontWidth * 80;
    CHexviewDoc* pDoc = GetDocument();
    sz.cy = m_iViewHeight = (pDoc->BlockLength(m_iCurrentOffset) + 15) / 16;

	m_iLastLine = m_iViewHeight;

	// The vert scrolling range is the total display height of all
	// of the rows.
	CSize sizeTotal(sz.cx,
		m_iFontHeight * (min(m_iViewHeight, INT_MAX / m_iFontHeight - 1)));

    m_iWndLines = max(1, (rectClient.bottom/m_iFontHeight));
	// The vertical per-page scrolling distance is equal to the
	// how many rows can be displayed in the current window, less
	// one row for paging overlap.
	CSize sizePage(sz.cx, m_iWndLines * m_iFontHeight);

	// The vertical per-line scrolling distance is equal to the
		// height of the row.
	CSize sizeLine(sz.cx, m_iFontHeight);

	SetScrollSizes(MM_TEXT, sizeTotal, sizePage, sizeLine);

	if (sizePage.cy >= sizeTotal.cy)
	{
		m_iFirstLine = 0;
	    SetScrollPos(SB_VERT, 0, TRUE);
	}
	else
	{
        int iPos = 0;
		if ((m_iLastLine - m_iWndLines) * m_iFontHeight)  // No divide by 0
			iPos = (m_iViewHeight * m_iFirstLine) / (m_iLastLine - m_iWndLines) * m_iFontHeight;
		SetScrollPos(SB_VERT, iPos, TRUE);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CHexviewView printing

BOOL CHexviewView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

HFONT hOldFont = NULL;

void CHexviewView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// get current screen font object metrics
	CFont* pFont = GetFont();
	LOGFONT lf;
	LOGFONT lfSys;
	VERIFY(::GetObject(::GetStockObject(ANSI_FIXED_FONT), sizeof(LOGFONT),
			&lfSys));
	if (pFont)
	{
		VERIFY(pFont->GetObject(sizeof(LOGFONT), &lf));
		if (lstrcmpi((LPCTSTR)lf.lfFaceName, (LPCTSTR)lfSys.lfFaceName) == 0)
			return;
		lstrcpy(lf.lfFaceName, (LPCTSTR)lfSys.lfFaceName);
	}
	else
	{
		lf = lfSys;
	}
	// map to printer font metrics
	HDC hDCFrom = ::GetDC(NULL);
	lf.lfHeight = ::MulDiv(lf.lfHeight, pDC->GetDeviceCaps(LOGPIXELSY),
		::GetDeviceCaps(hDCFrom, LOGPIXELSY));
	lf.lfWidth = ::MulDiv(lf.lfWidth, pDC->GetDeviceCaps(LOGPIXELSX),
		::GetDeviceCaps(hDCFrom, LOGPIXELSX));
	::ReleaseDC(NULL, hDCFrom);

	// create it, if it fails we just use the printer's default.
	if (m_cfPrintFont)
		delete m_cfPrintFont;
	if (m_cfPrintBoldFont)
		delete m_cfPrintBoldFont;
	m_cfPrintFont = new CFont;
	m_cfPrintBoldFont = new CFont;
	m_cfPrintFont->CreateFontIndirect(&lf);
	lf.lfUnderline = TRUE;

    m_cfPrintBoldFont->CreateFontIndirect(&lf);

    CFont *pOldFont = pDC->SelectObject(m_cfPrintFont);
    TEXTMETRIC tm;
    pDC->GetTextMetrics(&tm);
	int nPageHeight = pDC->GetDeviceCaps(VERTRES);
    m_iFontHeight = tm.tmHeight + tm.tmExternalLeading;
	m_iWndLines = nPageHeight / m_iFontHeight - 5;

	CHexviewDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	m_iFirstLine = 0;
	int nTotalLines = (pDoc->TotalFileLength() + 15) / 16;
	pInfo->SetMaxPage((nTotalLines + m_iWndLines - 1) / m_iWndLines);
	pDC->SelectObject(pOldFont);

	SYSTEMTIME sysTime;
	GetSystemTime(&sysTime);
	CString strDate;
	GetDateFormat(NULL, LOCALE_NOUSEROVERRIDE, &sysTime, NULL,
		          strDate.GetBuffer(255), 255);
	strDate.ReleaseBuffer();
	GetTimeFormat(NULL, LOCALE_NOUSEROVERRIDE, &sysTime, NULL,
		          m_strTimePrint.GetBuffer(255), 255);
	m_strTimePrint.ReleaseBuffer();
	m_strTimePrint = strDate + "  " + m_strTimePrint;
}

void CHexviewView::OnEndPrinting(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	UpdateScrollSizes();
}

/////////////////////////////////////////////////////////////////////////////
// CHexviewView diagnostics

#ifdef _DEBUG
void CHexviewView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CHexviewView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CHexviewDoc* CHexviewView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CHexviewDoc)));
	return (CHexviewDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHexviewView message handlers

void CHexviewView::OnDestroy() 
{
	delete m_cfFixedFont;
	CScrollView::OnDestroy();
}

void CHexviewView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CScrollView::OnPrepareDC(pDC, pInfo);
    CPoint pt = pDC->GetViewportOrg();
    pt.y = 0;
    pDC->SetViewportOrg(pt);

}

void CHexviewView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
    switch (nSBCode) 
	{
    case SB_TOP:
        m_iFirstLine = 0;
        break;
    
    case SB_BOTTOM:
        m_iFirstLine = m_iLastLine;
        break;
    
    case SB_LINEUP:
        m_iFirstLine--;
        break;
        
    case SB_PAGEUP:    
        m_iFirstLine -= m_iWndLines;
        break;

    case SB_LINEDOWN:
        m_iFirstLine++;
        break;

    case SB_PAGEDOWN:
        m_iFirstLine += m_iWndLines;
        break;
    
    case SB_THUMBPOSITION:
    case SB_THUMBTRACK:
        m_iFirstLine = (nPos * m_iLastLine) / (m_iFontHeight * m_iViewHeight);
        if (m_iFirstLine == m_iLastLine - m_iWndLines - 1)
            m_iFirstLine = m_iLastLine - m_iWndLines;
        break;

    default:
        return;
    }

	if (m_iFirstLine >= m_iLastLine - m_iWndLines) 
	{
        m_iFirstLine = m_iLastLine - m_iWndLines;
    }
    if (m_iFirstLine < 0) m_iFirstLine = 0;
    if (m_iWndLines >= m_iLastLine) 
	{
        m_iFirstLine = 0;
    } 

    int iPos = 0;
    if (m_iWndLines < m_iLastLine) 
        iPos = ((m_iViewHeight * m_iFirstLine) / (m_iLastLine - m_iWndLines)) * m_iFontHeight;
	TRACE("First Line: %d, Last Line: %d, Window lines: %d, Position: %d\n", 
		m_iFirstLine, m_iLastLine, m_iWndLines, iPos);
    SetScrollPos(SB_VERT, iPos, TRUE);
    Invalidate(TRUE);
}

void CHexviewView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default

   switch (nChar) 
   {
    case VK_HOME:
        OnVScroll(SB_TOP, 0, NULL);
        break;

    case VK_END:
        OnVScroll(SB_BOTTOM, 0, NULL);
        break;

    case VK_UP:
        OnVScroll(SB_LINEUP, 0, NULL);
        break;

    case VK_DOWN:
        OnVScroll(SB_LINEDOWN, 0, NULL);
        break;

    case VK_PRIOR:
        OnVScroll(SB_PAGEUP, 0, NULL);
        break;

    case VK_NEXT:
        OnVScroll(SB_PAGEDOWN, 0, NULL);
        break;
    
    default:    
        CScrollView::OnKeyDown(nChar, nRepCnt, nFlags);
        break;
    }
}


void CHexviewView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{
    CFont *pOldFont = pDC->SelectObject(m_cfPrintFont);
	// get string to show as "filename" in header/footer
	LPCTSTR pszFileName = GetDocument()->GetPathName();
	if (pszFileName[0] == 0)
		pszFileName = GetDocument()->GetTitle();

	// go thru global CPageSetupDlg to format the header and footer
	CString strHeader;
	strHeader = pszFileName;
	CString strFooter;
	CHexviewDoc* pDoc = GetDocument();
	int nTotalLines = (pDoc->TotalFileLength() + 15) / 16;
	wsprintf(strFooter.GetBuffer(81), "Page %d of %d", pInfo->m_nCurPage,
		(nTotalLines + m_iWndLines - 1) / m_iWndLines);
	strFooter.ReleaseBuffer();

	TEXTMETRIC tm;
	pDC->GetTextMetrics(&tm);
	int cyChar = tm.tmHeight;
	CRect rectPage = pInfo->m_rectDraw;

	// draw and exclude space for header
	if (!strHeader.IsEmpty())
	{
		pDC->TextOut(rectPage.left, rectPage.top, strHeader);
		int nAlign = pDC->SetTextAlign(TA_NOUPDATECP | TA_RIGHT | TA_TOP);
		strHeader = _T("Printed by HexView: http://www.funduc.com");
		pDC->TextOut(rectPage.right, rectPage.top, strHeader);
		pDC->SetTextAlign(nAlign);
		rectPage.top += cyChar + cyChar / 4;
		pDC->MoveTo(rectPage.left, rectPage.top);
		pDC->LineTo(rectPage.right, rectPage.top);
		rectPage.top += cyChar / 4;
		pInfo->m_rectDraw.top = rectPage.top;
	}

	// allow space for footer
	if (!strFooter.IsEmpty())
		pInfo->m_rectDraw.bottom -= cyChar + cyChar/4 + cyChar/4;

	int nPageHeight = pDC->GetDeviceCaps(VERTRES);
    int iFontHeight = tm.tmHeight + tm.tmExternalLeading;
    int iFontWidth = tm.tmMaxCharWidth;
	int iWndLines = nPageHeight / iFontHeight - 5;
	int iFirstLine = (pInfo->m_nCurPage -1) * iWndLines;
	iFirstLine += (2 * (pInfo->m_nCurPage -1));
	// Print the rows for the current page.

	int yTopOfPage = (pInfo->m_nCurPage -1) * iWndLines
		* iFontHeight;

	ASSERT_VALID(pDoc);

	DispData(pDC, iFirstLine, pDoc->TotalFileLength(), m_cfPrintFont,
			m_cfPrintBoldFont, iWndLines + 4, iFontHeight, 0, iFontWidth, 2);

	// draw footer
	if (!strFooter.IsEmpty())
	{
		rectPage.bottom -= cyChar;
		pDC->TextOut(rectPage.left, rectPage.bottom, strFooter);
		int nAlign = pDC->SetTextAlign(TA_NOUPDATECP | TA_RIGHT | TA_TOP);
		pDC->TextOut(rectPage.right, rectPage.bottom, m_strTimePrint);
		pDC->SetTextAlign(nAlign);
		rectPage.bottom -= cyChar / 4;
		pDC->MoveTo(rectPage.left, rectPage.bottom);
		pDC->LineTo(rectPage.right, rectPage.bottom);
		rectPage.bottom -= cyChar / 4;
	}
    pDC->SelectObject(pOldFont);
}

void CHexviewView::OnSize(UINT nType, int cx, int cy) 
{
	UpdateScrollSizes();
	CScrollView::OnSize(nType, cx, cy);
}


void CHexviewView::OnViewNextblock() 
{
	CHexviewDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (pDoc->GetNextBlock(m_iCurrentOffset))
	{
		m_iFirstLine = 0;
		m_iLastLine = (pDoc->BlockLength(m_iCurrentOffset) + 15) / 16;
	    SetScrollPos(SB_VERT, 0, TRUE);
		UpdateScrollSizes();
		Invalidate();
	}
}

void CHexviewView::OnViewPreviousblock() 
{
	CHexviewDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (pDoc->GetPrevBlock(m_iCurrentOffset))
	{
		m_iFirstLine = 0;
		m_iLastLine = (pDoc->BlockLength(m_iCurrentOffset) + 15) / 16;
	    SetScrollPos(SB_VERT, 0, TRUE);
		UpdateScrollSizes();
		Invalidate();
	}
}

void CHexviewView::OnUpdateViewNextblock(CCmdUI* pCmdUI) 
{
	CHexviewDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	int iCurrentOffset = m_iCurrentOffset;
	pCmdUI->Enable(pDoc->GetNextBlock(iCurrentOffset));
}

void CHexviewView::OnUpdateViewPreviousblock(CCmdUI* pCmdUI) 
{
	CHexviewDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	int iCurrentOffset = m_iCurrentOffset;
	pCmdUI->Enable(pDoc->GetPrevBlock(iCurrentOffset));
}


void CHexviewView::OnViewGoto() 
{
	CGotoDlg dlgGoto;
	CHexviewDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if (pDoc->m_lStartOffset != -1)  // Show the initial offset
		dlgGoto.m_lNewOffset = pDoc->m_lStartOffset;
	else							 // Show the top of current block
		dlgGoto.m_lNewOffset = m_iCurrentOffset;
	if (dlgGoto.DoModal() == IDOK)
	{
		// Bogus offset
		if (dlgGoto.m_lNewOffset > pDoc->TotalFileLength())
		{
			m_iFirstLine = 0;
		}
		else
		{
			// Find the right block
			while (dlgGoto.m_lNewOffset > m_iCurrentOffset + pDoc->BlockLength(m_iCurrentOffset))
			{
				pDoc->GetNextBlock(m_iCurrentOffset);
			}
			m_iFirstLine = (dlgGoto.m_lNewOffset - m_iCurrentOffset) / 16;
			m_iLastLine = (pDoc->BlockLength(m_iCurrentOffset) + 15) / 16;
			UpdateScrollSizes();
		}
		Invalidate();
	}
}
