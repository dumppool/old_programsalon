//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by hexview.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_HEXVWTYPE                   129
#define IDD_GOTO                        130
#define IDC_OFFSET_ED                   1000
#define IDS_ERR_OPEN                    3000
#define IDS_ERR_MAPPING                 3001
#define IDS_ERR_MAPVIEW                 3002
#define ID_VIEW_PREVIOUSBLOCK           32773
#define ID_VIEW_NEXTBLOCK               32774
#define ID_VIEW_GOTO                    32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
