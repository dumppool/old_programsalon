/* ---------------------------------------------------------------------------

   This code can be used as you wish but without warranties as to performance 
   of merchantability or any other warranties whether expressed or implied.
   
	 Written by Mike Funduc, Funduc Software Inc. 8/1/96

	 To download the code and more useful utilities (including Search and
	 Replace for Windows 95/NT, 3.1x) go to: http://www.funduc.com

----------------------------------------------------------------------------*/

// hexviewDoc.cpp : implementation of the CHexviewDoc class
//

#include "stdafx.h"
#include "hexview.h"

#include "hexviewDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const int HEXVIEW_BLOCK_SIZE = 16384;
/////////////////////////////////////////////////////////////////////////////
// CHexviewDoc

IMPLEMENT_DYNCREATE(CHexviewDoc, CDocument)

BEGIN_MESSAGE_MAP(CHexviewDoc, CDocument)
	//{{AFX_MSG_MAP(CHexviewDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHexviewDoc construction/destruction

CHexviewDoc::CHexviewDoc()
{
  m_iBlockSize = HEXVIEW_BLOCK_SIZE;
  m_lStartOffset = -1;
  m_lEndOffset = -1;
  HexGetApp()->GetOffsets(m_lStartOffset, m_lEndOffset);
}

BYTE *CHexviewDoc::AdjustPointerAbsolute(int iPosition)
{ 
  m_iCurrentPointer=iPosition;
  return &m_lpImage[m_iCurrentPointer];
}

CHexviewDoc::~CHexviewDoc()
{
}

BOOL CHexviewDoc::OnNewDocument()
{
//	if (!CDocument::OnNewDocument())
//		return FALSE;
	// Just in case this is called
	return TRUE;
}

BOOL CHexviewDoc::OnOpenDocument(LPCTSTR lpszFileName)
{
  m_csFileName = (CString *)0;
  if (INVALID_HANDLE_VALUE==(m_hFile=CreateFile(lpszFileName,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
					   	OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL)))
  {
	  AfxMessageBox(IDS_ERR_OPEN);
      return(FALSE);
  }
  m_hFileMapping = CreateFileMapping(m_hFile,NULL,PAGE_READONLY,0,0,NULL);
  if (!m_hFileMapping) 
  {
      AfxMessageBox(IDS_ERR_MAPPING);
      CloseHandle(m_hFile);
      return(FALSE);
  }
  m_lpImage = (BYTE *)MapViewOfFile(m_hFileMapping,FILE_MAP_READ,0,0,0);
  if (!m_lpImage) 
  {
      CloseHandle(m_hFileMapping);
      CloseHandle(m_hFile);
      AfxMessageBox(IDS_ERR_MAPVIEW);
      return(FALSE);
  }

  AfxGetApp()->AddToRecentFileList(lpszFileName);
  m_csFileName = new CString(lpszFileName);
  SetPathName(lpszFileName);
  m_iCurrentPointer = 0;
  DWORD dwFileSizeHigh;
  m_iFileSize = GetFileSize(m_hFile,&dwFileSizeHigh);
  m_iBlockSize = min(HEXVIEW_BLOCK_SIZE, m_iFileSize);

   return TRUE;
}

void CHexviewDoc::OnCloseDocument()
{
 UnmapViewOfFile(m_lpImage);
 CloseHandle(m_hFileMapping);
 CloseHandle(m_hFile);
 strcpy(szStatusMessage,"");
 CDocument::OnCloseDocument();
}

/////////////////////////////////////////////////////////////////////////////
// CHexviewDoc serialization

void CHexviewDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CHexviewDoc diagnostics

#ifdef _DEBUG
void CHexviewDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CHexviewDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHexviewDoc commands


BOOL CHexviewDoc::GetNextBlock(int &iCurrentOffset)
{
	int iTempOffset = iCurrentOffset;
	iTempOffset += HEXVIEW_BLOCK_SIZE;
	if (iTempOffset + 1 > TotalFileLength())
	{
		return FALSE;
	}
	iCurrentOffset = iTempOffset;
	return TRUE;
}

BOOL CHexviewDoc::GetPrevBlock(int &iCurrentOffset)
{
	int iTempOffset = iCurrentOffset;
	iTempOffset -= HEXVIEW_BLOCK_SIZE;
	if (iTempOffset < 0)
	{
		return FALSE;
	}
	iCurrentOffset = iTempOffset;
	return TRUE;
}

int CHexviewDoc::BlockLength(int iCurrentOffset)
{
	int nNewLength = min(m_iBlockSize, m_iFileSize - iCurrentOffset);
	if (nNewLength < 0)
		nNewLength = 0;
	return nNewLength;
}
