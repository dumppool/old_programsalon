/* ---------------------------------------------------------------------------

   This code can be used as you wish but without warranties as to performance 
   of merchantability or any other warranties whether expressed or implied.
   
	 Written by Mike Funduc, Funduc Software Inc. 8/1/96

	 To download the code and more useful utilities (including Search and
	 Replace for Windows 95/NT, 3.1x) go to: http://www.funduc.com

----------------------------------------------------------------------------*/

// hexviewDoc.h : interface of the CHexviewDoc class
//
/////////////////////////////////////////////////////////////////////////////

class CHexviewDoc : public CDocument
{
protected: // create from serialization only
	CHexviewDoc();
	DECLARE_DYNCREATE(CHexviewDoc)

// Attributes
private:
 CString *m_csFileName;
 HANDLE m_hFile;
 HANDLE m_hFileMapping;
 BYTE *m_lpImage;
 int m_iCurrentPointer, m_iFileSize,
	 m_iBlockSize;
// CView *m_AssociatedView;
// CFrameWnd *m_PriorityFrame;
public:
	BOOL GetPrevBlock(int &iCurrentOffset);
	BOOL GetNextBlock(int &iCurrentOffset);
 char szStatusMessage[300];
 long m_lStartOffset, m_lEndOffset;

// Operations
public:

// helper functions

//BYTE *AdjustPointerRelative(int iOffset);
BYTE *AdjustPointerAbsolute(int iPosition);
//BOOL RetrieveBytesAtCurrentPosition(BYTE *lpTarget, int iLength);
//BOOL RetrieveBytesAtAbsolutePosition(BYTE *lpPosition, BYTE *lpTarget, int iLength);
//inline int GetCurrentPosition() { return m_iCurrentPointer; };
//void ActivateTheRightFrame();
int TotalFileLength() {return m_iFileSize;};
int BlockLength(int iCurrentOffset); 

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHexviewDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszFileName);
	virtual void OnCloseDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHexviewDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CHexviewDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
