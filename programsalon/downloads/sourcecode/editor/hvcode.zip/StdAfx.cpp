/* ---------------------------------------------------------------------------

   This code can be used as you wish but without warranties as to performance 
   of merchantability or any other warranties whether expressed or implied.
   
	 Written by Mike Funduc, Funduc Software Inc. 8/1/96

	 To download the code and more useful utilities (including Search and
	 Replace for Windows 95/NT, 3.1x) go to: http://www.funduc.com

----------------------------------------------------------------------------*/

// stdafx.cpp : source file that includes just the standard includes
//	hexview.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

