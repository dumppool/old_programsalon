/* ---------------------------------------------------------------------------

   This code can be used as you wish but without warranties as to performance 
   of merchantability or any other warranties whether expressed or implied.
   
	 Written by Mike Funduc, Funduc Software Inc. 8/1/96

	 To download the code and more useful utilities (including Search and
	 Replace for Windows 95/NT, 3.1x) go to: http://www.funduc.com

----------------------------------------------------------------------------*/

// GotoDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGotoDlg dialog

class CGotoDlg : public CDialog
{
// Construction
public:
	CGotoDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGotoDlg)
	enum { IDD = IDD_GOTO };
	long	m_lNewOffset;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGotoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGotoDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
