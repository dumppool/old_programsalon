README_dossrc.txt for version 5.3 of Vim: Vi IMproved.

This is the DOS source archive for Vim.  It is packed for DOS systems, with
CR-LF.  It also includes the VisVim sources.

For more information, see the README.txt file that comes with the runtime
archive (vim52rt.zip).  To be able to run Vim you MUST get the runtime archive
too!
