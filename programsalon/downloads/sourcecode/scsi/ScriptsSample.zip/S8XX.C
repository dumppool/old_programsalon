/*--------------------------------------------------*/
/*                                                  */
/* Module S8XX.C                                    */
/*                                                  */
/* Symbios 53C8XX family specific functions for     */
/* sample code.                                     */
/*                                                  */
/* Adapted from Symbios Logic                       */
/*    Software Development Kit                      */
/*                                                  */
/* Project: A Programmer's Guide to SCSI            */
/* Copyright (C) 1997, Brian Sawert.                */
/* All rights reserved.                             */
/*                                                  */
/*--------------------------------------------------*/


#include <stdio.h>
#include <stdlib.h>
#include <dos.h>

#include "gen_tool.h"         // generic tools
#include "spci.h"             // PCI definitions
#include "s8xx.h"             // Symbios 8XX definitions


/*---------- defines and macros ----------*/

/*---------- global variables ----------*/

/*---------- external variables ----------*/

/*---------- local functions ----------*/

/*---------- external functions ----------*/

/*---------- function definitions ----------*/


/*--------------------------------------------------*/
/*                                                  */
/* Routine to initialize 53C8XX chip.               */
/*                                                  */
/* Usage:   WORD init_8xx(pci_device *ppcidevice,   */
/*    c8xx_device *pc8xxdev)                        */
/*                                                  */
/* Parameters:                                      */
/*    ppcidev:       pointer to pci_device struct   */
/*    pc8xxdev:      pointer to c8xx_device struct  */
/*                                                  */
/* Return value:                                    */
/*    Returns 1 on success, 0 otherwise.            */
/*                                                  */
/*--------------------------------------------------*/

WORD init_8xx(pci_device *ppcidev,
   c8xx_device *pc8xxdev)
{
   BYTE burst_len;


   if (!(ppcidev->dev_id == pc8xxdev->dev_id &&
      (ppcidev->rev_id & 0xF0) == pc8xxdev->rev_id)) {
   // device is not 53C8XX chip
      return 0;
   }

   // reset the chip
   IOWrite8(ppcidev->io_base + ISTAT, 0x40);
   delay(3);

   // clear the chip reset
   IOWrite8(ppcidev->io_base + ISTAT, 0x00);

   // reset the SCSI bus
   IOWrite8(ppcidev->io_base + SCNTL1, 0x08);
   delay(3);

   // clear the SCSI reset
   IOWrite8(ppcidev->io_base + SCNTL1, 0x0);

   // clear the interrupt from the SCSI reset
   IORead32(ppcidev->io_base + SIEN0);

   // set up burst mode length for 53C825
   burst_len = pc8xxdev->max_burst_a << 6;

   // clear current burst length
   RMWoff(ppcidev->io_base + CTEST5, 0x04);
   RMWoff(ppcidev->io_base + DMODE, 0xC0);

   // set new burst length (just use lower 2 bits)
   RMWon(ppcidev->io_base + DMODE, burst_len);

   // set clock conversion factor for 53C825
   RMWon(ppcidev->io_base + SCNTL3, DEF_CLOCK);

   // set chip SCSI ID and reselect response
   RMWon(ppcidev->io_base + SCID,
      (0x40 | pc8xxdev->scsi_id));

	// set response ID
   RMWon(ppcidev->io_base + RESPID0, 0x80);

   // turn on parity checking and ATN on parity error
   RMWon(ppcidev->io_base + SCNTL0, 0x0A);

   // set selection timeout to 250 ms
   RMWon(ppcidev->io_base + STIME0, DEF_SELECT_TO);

   return 1;
}
