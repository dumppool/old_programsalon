/*
 * $Id: version.c,v 1.10 1997/10/14 06:31:32 jim Exp $
 *
 * version.c - Version number for PROGRAM_NAME
 * Created by Jim Mintha on Wed Jan 10 01:06:50 PST 1996
 *
 * $Log: version.c,v $
 * Revision 1.10  1997/10/14 06:31:32  jim
 * added man page and -D dev options
 *
 * Revision 1.9  1997/10/10 09:12:25  jim
 * fix bug in ioctl to reset block size.  Make readtoc return number of
 * tracks, return status 0
 *
 * Revision 1.8  1997/10/02 16:57:37  jim
 * small bug in stdout
 *
 * Revision 1.7  1997/09/10 00:17:48  jim
 * few small bugs
 *
 * Revision 1.6  1997/09/01 22:34:14  jim
 * Added jitter control, output status, and other stuff.
 *
 * Revision 1.5  1997/08/31 19:50:43  jim
 * added patches from Andi Karrer for output to stdout, etc.
 *
 * Revision 1.4  1996/06/04 23:03:36  jim
 * Added patches from Hans Werner Strube (strube@physik3.gwdg.de)
 * for output to stdout, open volmgt device, and remove unnecessary
 * call to cdda_init when checking drive type.
 *
 * Revision 1.3  1996/01/18 13:59:49  jim
 * Added ability to query drive type
 *
 * Revision 1.2  1996/01/10 09:39:25  jim
 * Updated docs
 *
 * Revision 1.1  1996/01/10 09:12:27  jim
 * Initial revision
 *
 */

#include "version.h"
const char *version_string = "Read_CDDA 2.05";
