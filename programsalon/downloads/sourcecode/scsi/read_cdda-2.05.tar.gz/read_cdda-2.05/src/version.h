/*
 * $Id: version.h,v 1.1 1996/01/10 09:09:11 jim Exp $
 *
 * version.h - Version number for read_cdda
 * Created by Jim Mintha on 
 *
 * $Log: version.h,v $
 * Revision 1.1  1996/01/10 09:09:11  jim
 * Initial revision
 *
 */

extern const char *version_string;
