// SectnumDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSectnumDlg dialog

class CSectnumDlg : public CDialog
{
// Construction
public:
	CSectnumDlg(DWORD *psect, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSectnumDlg)
	enum { IDD = IDD_SECTNUM };
	DWORD	m_Sectnum;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSectnumDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

   DWORD *pSectnum;

	// Generated message map functions
	//{{AFX_MSG(CSectnumDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
