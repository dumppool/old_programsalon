// ActionDlg.h : header file
//

#include "scsibus.hpp"
#include "basedev.hpp"
#include "diskdev.hpp"
#include "cdromdev.hpp"


// action definition
typedef struct action_struct {
   char *pDesc;         // description string
   WORD cmdmsg;         // command message
} action_struct_t;


/////////////////////////////////////////////////////////////////////////////
// CActionDlg dialog

class CActionDlg : public CDialog
{
// Construction
public:
	CActionDlg(ScsiDevice *psd = NULL, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CActionDlg)
	enum { IDD = IDD_ACTIONS_DLG };
	CListBox	m_Actions;
	CEdit	m_Output;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CActionDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	ScsiDevice *GetDevice();
	ScsiDevice *SetDevice(ScsiDevice *);
	ScsiDevice *Device;
   ScsiBaseDevice *BaseDevice;
   CFont EditFont;
   action_struct_t *Actions;
   int nActions;

	// Generated message map functions
	//{{AFX_MSG(CActionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnRun();
	afx_msg void OnDblclkActions();
	//}}AFX_MSG

   // action handlers
   afx_msg void OnTestUnitReady(void);
   afx_msg void OnDeviceInquiry(void);
   afx_msg void OnRequestSense(void);
   afx_msg void OnReadCapacity(void);
   afx_msg void OnReadSector(void);
   afx_msg void OnReadToc(void);
   afx_msg void OnLockUnlock(void);
   afx_msg void OnEject(void);


	DECLARE_MESSAGE_MAP()
};


   
