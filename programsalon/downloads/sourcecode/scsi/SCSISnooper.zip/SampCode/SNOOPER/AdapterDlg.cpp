// AdapterDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Snooper.h"
#include "AdapterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdapterDlg dialog


CAdapterDlg::CAdapterDlg(AdapterInfo *pai, CWnd* pParent /*=NULL*/)
   : CDialog(CAdapterDlg::IDD, pParent), Adapter(pai)
{
   //{{AFX_DATA_INIT(CAdapterDlg)
      // NOTE: the ClassWizard will add member initialization here
   //}}AFX_DATA_INIT
}

void CAdapterDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   //{{AFX_DATA_MAP(CAdapterDlg)
      // NOTE: the ClassWizard will add DDX and DDV calls here
   //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdapterDlg, CDialog)
   //{{AFX_MSG_MAP(CAdapterDlg)
   //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdapterDlg message handlers

BOOL CAdapterDlg::OnInitDialog()
{
   char buff[32];


   CDialog::OnInitDialog();

   // TODO: Add extra initialization here

   if (Adapter)
   {
      wsprintf(buff, "%d", Adapter->AdapterNum);
      SetDlgItemText(IDC_HA_NUMBER, buff);
      wsprintf(buff, "%d", Adapter->ScsiId);
      SetDlgItemText(IDC_SCSI_ID, buff);
      lstrcpy(buff, Adapter->ManagerId);
      SetDlgItemText(IDC_ASPI_MGR, buff);
      lstrcpy(buff, Adapter->Identifier);
      SetDlgItemText(IDC_IDENT, buff);
      wsprintf(buff, "%d", Adapter->MaxUnits);
      SetDlgItemText(IDC_DEVICES, buff);
   }

   return TRUE;  // return TRUE unless you set the focus to a control
                 // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// Set AdapterInfo pointer

AdapterInfo *CAdapterDlg::SetAdapter(AdapterInfo *pai)
{
   AdapterInfo *oldptr = Adapter;
   Adapter = pai;

   // return old adapter info
   return(oldptr);
}

/////////////////////////////////////////////////////////////////////////////
// Get AdapterInfo pointer

AdapterInfo *CAdapterDlg::GetAdapter()
{
   return(Adapter);
}
