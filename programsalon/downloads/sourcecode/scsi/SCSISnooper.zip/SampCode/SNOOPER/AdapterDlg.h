// AdapterDlg.h : header file
//

#include "scsibus.hpp"

/////////////////////////////////////////////////////////////////////////////
// CAdapterDlg dialog

class CAdapterDlg : public CDialog
{
// Construction
public:
// standard constructor
   CAdapterDlg(AdapterInfo *pai = NULL, CWnd* pParent = NULL);

// Dialog Data
   //{{AFX_DATA(CAdapterDlg)
   enum { IDD = IDD_ADAPTER_DIALOG };
      // NOTE: the ClassWizard will add data members here
   //}}AFX_DATA


// Overrides
   // ClassWizard generated virtual function overrides
   //{{AFX_VIRTUAL(CAdapterDlg)
   protected:
   virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
   //}}AFX_VIRTUAL

// Implementation
protected:
   AdapterInfo *GetAdapter();
   AdapterInfo *SetAdapter(AdapterInfo *);
   AdapterInfo *Adapter;
   // Generated message map functions
   //{{AFX_MSG(CAdapterDlg)
   virtual BOOL OnInitDialog();
   //}}AFX_MSG
   DECLARE_MESSAGE_MAP()
};