// SnooperDlg.h : header file
//

#include "scsibus.hpp"
#include "AdapterDlg.h"
#include "DeviceDlg.h"

// limit number of adapters and devices
#define MAX_ADAPTERS    4
#define MAX_DEVICES     12
#define MAX_TYPE        10


/////////////////////////////////////////////////////////////////////////////
// CSnooperDlg dialog

class CSnooperDlg : public CDialog
{
// Construction
public:
   int nAdapters;
   int nDevices;
   ScsiDevice *DevList[MAX_DEVICES];
   CSnooperDlg(CWnd* pParent = NULL);  // standard constructor
   CButton HAButton[MAX_ADAPTERS];
   CButton DevButton[MAX_DEVICES];

// Dialog Data
   //{{AFX_DATA(CSnooperDlg)
   enum { IDD = IDD_SNOOPER_DIALOG };
   //}}AFX_DATA

   // ClassWizard generated virtual function overrides
   //{{AFX_VIRTUAL(CSnooperDlg)
   protected:
   virtual void DoDataExchange(CDataExchange* pDX);   // DDX/DDV support
   //}}AFX_VIRTUAL

// Implementation
protected:
   HICON m_hIcon;

   // Generated message map functions
   //{{AFX_MSG(CSnooperDlg)
   virtual BOOL OnInitDialog();
   afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
   afx_msg void OnPaint();
   afx_msg HCURSOR OnQueryDragIcon();
   //}}AFX_MSG

   afx_msg void OnHaButtonClicked( UINT nID );
   afx_msg void OnDevButtonClicked( UINT nID );

   DECLARE_MESSAGE_MAP()
};