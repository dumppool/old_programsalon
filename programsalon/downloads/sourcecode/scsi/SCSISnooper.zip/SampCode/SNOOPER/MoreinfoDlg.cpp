// MoreinfoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Snooper.h"
#include "MoreinfoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMoreinfoDlg dialog


CMoreinfoDlg::CMoreinfoDlg(ScsiDevice *psd, CWnd* pParent /*=NULL*/)
   : CDialog(CMoreinfoDlg::IDD, pParent), Device(psd)
{
   //{{AFX_DATA_INIT(CMoreinfoDlg)
      // NOTE: the ClassWizard will add member initialization here
   //}}AFX_DATA_INIT
}


void CMoreinfoDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   //{{AFX_DATA_MAP(CMoreinfoDlg)
      // NOTE: the ClassWizard will add DDX and DDV calls here
   //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMoreinfoDlg, CDialog)
   //{{AFX_MSG_MAP(CMoreinfoDlg)
   //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMoreinfoDlg message handlers

BOOL CMoreinfoDlg::OnInitDialog()
{
   char buff[32];


   CDialog::OnInitDialog();

   // TODO: Add extra initialization here

   if (Device)
   {
      lstrcpy(buff, MapVersionString(Device->GetAnsiVersion()));
      SetDlgItemText(IDC_ANSI_VERSION, buff);
      CheckDlgButton(IDC_REMOVABLE, Device->IsRemovable());
      CheckDlgButton(IDC_WIDE32, Device->IsWide32());
      CheckDlgButton(IDC_WIDE16, Device->IsWide16());
      CheckDlgButton(IDC_SYNC, Device->IsSync());
      CheckDlgButton(IDC_LINKED, Device->IsLinked());
      CheckDlgButton(IDC_QUEUE, Device->IsQueue());
      CheckDlgButton(IDC_SOFTRESET, Device->IsSoftReset());
   }

   return TRUE;  // return TRUE unless you set the focus to a control
                 // EXCEPTION: OCX Property Pages should return FALSE
}


/////////////////////////////////////////////////////////////////////////////
// Set ScsiDevice pointer

ScsiDevice *CMoreinfoDlg::SetDevice(ScsiDevice *psd)
{
   ScsiDevice *oldptr = Device;
   Device = psd;

   // return old device info
   return(oldptr);
}


/////////////////////////////////////////////////////////////////////////////
// Get ScsiDevice pointer

ScsiDevice *CMoreinfoDlg::GetDevice()
{
   return(Device);
}


/////////////////////////////////////////////////////////////////////////////
// Map ANSI version to description

char *CMoreinfoDlg::MapVersionString(int ansiver)
{
   char *verstr;


   verstr = (ansiver == 1) ? "SCSI-1" :
      (ansiver == 2) ? "SCSI-2" : "Unknown";

   return(verstr);
}
