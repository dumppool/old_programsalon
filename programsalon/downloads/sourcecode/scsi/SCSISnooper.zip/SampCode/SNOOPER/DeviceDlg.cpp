// DeviceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Snooper.h"
#include "DeviceDlg.h"
#include "MoreinfoDlg.h"
#include "ActionDlg.h"

#include "Basedev.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

char *devstr[] =
{
   "Direct Access",
   "Sequential Access",
   "Printer",
   "Processor",
   "Write-once",
   "CD-ROM",
   "Scanner",
   "Optical Memory",
   "Medium Changer",
   "Communications",
   "Unknown"
};


/////////////////////////////////////////////////////////////////////////////
// CDeviceDlg dialog


CDeviceDlg::CDeviceDlg(ScsiDevice *psd, CWnd* pParent /*=NULL*/)
   : CDialog(CDeviceDlg::IDD, pParent), Device(psd)
{
   //{{AFX_DATA_INIT(CDeviceDlg)
      // NOTE: the ClassWizard will add member initialization here
   //}}AFX_DATA_INIT
}


void CDeviceDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   //{{AFX_DATA_MAP(CDeviceDlg)
      // NOTE: the ClassWizard will add DDX and DDV calls here
   //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDeviceDlg, CDialog)
   //{{AFX_MSG_MAP(CDeviceDlg)
   ON_BN_CLICKED(IDC_MOREINFO, OnMoreinfo)
   ON_BN_CLICKED(IDC_ACTIONS, OnActions)
   //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDeviceDlg message handlers

BOOL CDeviceDlg::OnInitDialog()
{
   char buff[32];


   CDialog::OnInitDialog();

   // TODO: Add extra initialization here

   if (Device)
   {
      wsprintf(buff, "%d", Device->GetAdapter());
      SetDlgItemText(IDC_HA_NUMBER, buff);
      wsprintf(buff, "%d", Device->GetUnit());
      SetDlgItemText(IDC_SCSI_ID, buff);
      wsprintf(buff, "%d", Device->GetLun());
      SetDlgItemText(IDC_SCSI_LUN, buff);
      lstrcpy(buff, MapDeviceString(Device->GetType()));
      SetDlgItemText(IDC_DEVTYPE, buff);
      lstrcpy(buff, Device->GetName());
      SetDlgItemText(IDC_DEVNAME, buff);
      lstrcpy(buff, Device->GetRevision());
      SetDlgItemText(IDC_REVISION, buff);
   }

   return TRUE;  // return TRUE unless you set the focus to a control
                 // EXCEPTION: OCX Property Pages should return FALSE
}


/////////////////////////////////////////////////////////////////////////////
// Set ScsiDevice pointer

ScsiDevice *CDeviceDlg::SetDevice(ScsiDevice *psd)
{
   ScsiDevice *oldptr = Device;
   Device = psd;

   // return old device info
   return(oldptr);
}


/////////////////////////////////////////////////////////////////////////////
// Get ScsiDevice pointer

ScsiDevice *CDeviceDlg::GetDevice()
{
   return(Device);
}


/////////////////////////////////////////////////////////////////////////////
// Map device type to description

char *CDeviceDlg::MapDeviceString(int devtype)
{
   int index;


   index = (devtype < MAX_TYPE) ? devtype : MAX_TYPE;
   index = (devtype >= 0) ? devtype : MAX_TYPE;

   return(devstr[index]);
}
void CDeviceDlg::OnMoreinfo()
{
   // TODO: Add your control notification handler code here

   CMoreinfoDlg dlg(Device);

   if (dlg.DoModal() == -1)
   {
      // error creating dialog box
      MessageBox("Could not create advanced info dialog box.",
         "Dialog Error");
   }
}

void CDeviceDlg::OnActions()
{
   // TODO: Add your control notification handler code here

   CActionDlg dlg(Device);

   if (dlg.DoModal() == -1)
   {
      // error creating dialog box
      MessageBox("Could not create actions dialog box.",
         "Dialog Error");
   }
}