// SectnumDlg.cpp : implementation file
//

#include "stdafx.h"
#include "snooper.h"
#include "SectnumDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSectnumDlg dialog


CSectnumDlg::CSectnumDlg(DWORD *psect, CWnd* pParent /*=NULL*/)
	: CDialog(CSectnumDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSectnumDlg)
	m_Sectnum = 0;
	//}}AFX_DATA_INIT

   // set sector number
   m_Sectnum = *psect;
   pSectnum = psect;
}


void CSectnumDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSectnumDlg)
	DDX_Text(pDX, IDC_SECTNUM, m_Sectnum);
	DDV_MinMaxDWord(pDX, m_Sectnum, 0, 2097150);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSectnumDlg, CDialog)
	//{{AFX_MSG_MAP(CSectnumDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSectnumDlg message handlers

void CSectnumDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();

   *pSectnum = m_Sectnum;
}
