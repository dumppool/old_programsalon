// ActionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Snooper.h"
#include "ActionDlg.h"
#include "SectnumDlg.h"
#include "LockDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// macro for array element count
#define asize(x)  (sizeof(x) / sizeof(*x))

// helper functions
WORD FormatSectorData(char *pin, WORD insize, char *pout, WORD outsize);
WORD FormatTocData(char *pin, WORD insize, char *pout, WORD outsize);

// define actions for different device types
action_struct_t BaseActions[] =
{
   {"Test Unit Ready", IDC_TESTUNIT},
   {"Device Inquiry", IDC_INQUIRY},
   {"Request Sense", IDC_READSENSE}
};

#define NUM_BASE_ACTIONS asize(BaseActions)

action_struct_t DiskActions[] =
{
   {"Test Unit Ready", IDC_TESTUNIT},
   {"Device Inquiry", IDC_INQUIRY},
   {"Request Sense", IDC_READSENSE},
   {"Read Disk Capacity", IDC_CAPACITY},
   {"Read Disk Sector", IDC_READSECTOR},
// removable disk actions
   {"Lock/Unlock Disk", IDC_LOCKUNLOCK},
   {"Unload Disk", IDC_EJECT}
};

#define NUM_DISK_ACTIONS asize(DiskActions) - 2

action_struct_t CdRomActions[] =
{
   {"Test Unit Ready", IDC_TESTUNIT},
   {"Device Inquiry", IDC_INQUIRY},
   {"Request Sense", IDC_READSENSE},
   {"Read CD-ROM Capacity", IDC_CAPACITY},
   {"Read CD-ROM Table of Contents", IDC_READTOC},
   {"Lock/Unlock CD-ROM", IDC_LOCKUNLOCK},
   {"Unload CD-ROM", IDC_EJECT}
};

#define NUM_CDROM_ACTIONS asize(CdRomActions)


/////////////////////////////////////////////////////////////////////////////
// CActionDlg dialog


CActionDlg::CActionDlg(ScsiDevice *psd, CWnd* pParent /*=NULL*/)
   : CDialog(CActionDlg::IDD, pParent), Device(psd)
{
   //{{AFX_DATA_INIT(CActionDlg)
   //}}AFX_DATA_INIT

   switch (Device->GetType())
   // create appropriate device type
   {
   case 0:              // direct access device
      Actions = DiskActions;
      nActions = NUM_DISK_ACTIONS;

      if (Device->IsRemovable())
      // removable disk drive
      {
         nActions += 2;    // add removable disk actions
      }

      BaseDevice = new ScsiDiskDevice;
      BaseDevice->Open(psd);
      break;
   case 5:              // CD-ROM device
      Actions = CdRomActions;
      nActions = NUM_CDROM_ACTIONS;
      BaseDevice = new ScsiCdRomDevice;
      BaseDevice->Open(psd);
      break;
   default:             // all other devices
      Actions = BaseActions;
      nActions = NUM_BASE_ACTIONS;
      BaseDevice = new ScsiBaseDevice;
      BaseDevice->Open(psd);
      break;
   }
}


void CActionDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   //{{AFX_DATA_MAP(CActionDlg)
   DDX_Control(pDX, IDC_ACTIONS, m_Actions);
   DDX_Control(pDX, IDC_OUTPUT, m_Output);
   //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CActionDlg, CDialog)
   //{{AFX_MSG_MAP(CActionDlg)
   ON_BN_CLICKED(IDC_RUN, OnRun)
   ON_LBN_DBLCLK(IDC_ACTIONS, OnDblclkActions)
   //}}AFX_MSG_MAP

   // handlers for SCSI commands
   ON_COMMAND(IDC_TESTUNIT, OnTestUnitReady)
   ON_COMMAND(IDC_INQUIRY, OnDeviceInquiry)
   ON_COMMAND(IDC_READSENSE, OnRequestSense)
   ON_COMMAND(IDC_CAPACITY, OnReadCapacity)
   ON_COMMAND(IDC_READSECTOR, OnReadSector)
   ON_COMMAND(IDC_READTOC, OnReadToc)
   ON_COMMAND(IDC_LOCKUNLOCK, OnLockUnlock)
   ON_COMMAND(IDC_EJECT, OnEject)

END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CActionDlg message handlers

BOOL CActionDlg::OnInitDialog()
{
   int count;

   CDialog::OnInitDialog();

   // TODO: Add extra initialization here

   // fill Actions list box
   for (count = 0; count < nActions; count++)
   {
      m_Actions.AddString(Actions[count].pDesc);
   }

   // fill Output edit box
   EditFont.CreatePointFont(90, "Courier New");
   m_Output.SetFont(&EditFont);
   m_Output.SetWindowText(NULL);

   return TRUE;  // return TRUE unless you set the focus to a control
                 // EXCEPTION: OCX Property Pages should return FALSE
}


/////////////////////////////////////////////////////////////////////////////
// Set ScsiDevice pointer

ScsiDevice *CActionDlg::SetDevice(ScsiDevice *psd)
{
   ScsiDevice *oldptr = Device;
   Device = psd;

   // return old device info
   return(oldptr);
}


/////////////////////////////////////////////////////////////////////////////
// Get ScsiDevice pointer

ScsiDevice *CActionDlg::GetDevice()
{
   return(Device);
}



void CActionDlg::OnRun()
{
   int index;


   // TODO: Add your control notification handler code here
   index = m_Actions.GetCurSel();

   if (index == LB_ERR)
   // nothing selected
   {
      m_Output.SetWindowText("No action selected");
   }
   else
   // perform selection
   {
      PostMessage(WM_COMMAND, Actions[index].cmdmsg, 0L);
   }
}

void CActionDlg::OnDblclkActions()
{
   // TODO: Add your control notification handler code here

   // same action as Run button
   OnRun();
}


BOOL CActionDlg::DestroyWindow()
{
   // TODO: Add your specialized code here and/or call the base class
   BaseDevice->Close();
   delete BaseDevice;

   return CDialog::DestroyWindow();
}


/////////////////////////////////////////////////////////////////////////////
// SCSI command handlers

void CActionDlg::OnTestUnitReady(void)
{
   ScsiError_t errcode;
   char buff[256];


   errcode = BaseDevice->TestUnitReady();

   // create output message
   if (errcode == DEV_ERR_NO_SENSE)
   // no errors - device is ready
   {
      lstrcpy(buff, "Device is ready");
   }
   else
   // print error codes
   {
      BaseDevice->QueryErrorString(errcode, buff, sizeof(buff));
   }

   m_Output.SetWindowText(buff);
}


void CActionDlg::OnDeviceInquiry(void)
{
   ScsiError_t errcode;
   char buff[1024];
   SCSI_InquiryData_t *pid;
   AlignedBuffer id(sizeof(SCSI_InquiryData_t));


   pid = (SCSI_InquiryData_t *) id.Ptr();

   // check for null pointer
   if (!pid)
   {
      m_Output.SetWindowText("Cannot allocate memory");
      return;
   }

   errcode = BaseDevice->Inquiry(pid, sizeof(SCSI_InquiryData_t));

   // create output message
   if (errcode == DEV_ERR_NO_SENSE)
   {
      wsprintf(buff,
         "Device Type:      %d\r\n"
         "Removable Medium: %s\r\n"
         "ANSI Version:     %d\r\n"
         "Soft Reset:       %s\r\n"
         "Command Queuing:  %s\r\n"
         "Linked Commands:  %s\r\n"
         "Synch Transfer:   %s\r\n"
         "Wide 16:          %s\r\n"
         "Wide 32:          %s\r\n"
         "Vendor ID:        %.8s\r\n"
         "Product ID:       %.16s\r\n"
         "Revision:         %.4s",

         pid->DeviceType,
         (pid->RemovableMedia) ? "Yes" : "No",
         pid->AnsiVersion,
         (pid->SoftResetSupport) ? "Yes" : "No",
         (pid->CommandQueueSupport) ? "Yes" : "No",
         (pid->LinkedCommandSupport) ? "Yes" : "No",
         (pid->SynchronousTransferSupport) ? "Yes" : "No",
         (pid->WideBus16Support) ? "Yes" : "No",
         (pid->WideBus32Support) ? "Yes" : "No",
         pid->VendorId,
         pid->ProductId,
         pid->ProductRevisionLevel);
   }
   else
   {
      BaseDevice->QueryErrorString(errcode, buff, sizeof(buff));
   }

   m_Output.SetWindowText(buff);
}


void CActionDlg::OnRequestSense(void)
{
   ScsiError_t errcode;
   char buff[1024];
   SCSI_SenseData_t *psd;
   AlignedBuffer sd(sizeof(SCSI_SenseData_t));


   psd = (SCSI_SenseData_t *) sd.Ptr();

   // check for null pointer
   if (!psd)
   {
      m_Output.SetWindowText("Cannot allocate memory");
      return;
   }

   errcode = BaseDevice->RequestSense(psd, sizeof(SCSI_SenseData_t));

   // create output message
   if (errcode == DEV_ERR_NO_SENSE)
   {
      wsprintf(buff,
         "Valid Data Format:     %s\r\n"
         "Sense Key:             %02Xh\r\n"
         "Additional Sense Code: %02Xh\r\n"
         "Sense Code Qualifier:  %02Xh\r\n"
         "Illegal Length:        %s\r\n"
         "End of Medium:         %s\r\n"
         "File Mark:             %s",

         (psd->Valid) ? "Yes" : "No",
         psd->SenseKey,
         psd->Asc,
         psd->Asq,
         (psd->IllegalLength) ? "Yes" : "No",
         (psd->EndOfMedia) ? "Yes" : "No",
         (psd->FileMark) ? "Yes" : "No");
   }
   else
   {
      BaseDevice->QueryErrorString(errcode, buff, sizeof(buff));
   }

   m_Output.SetWindowText(buff);
}


void CActionDlg::OnReadCapacity(void)
{
   ScsiError_t errcode;
   char buff[1024];
   DWORD dLast, dSize;


   switch (Device->GetType())
   {
   case 0:     // direct access device
      errcode = ((ScsiDiskDevice*) BaseDevice)->
         ReadCapacity(&dLast, &dSize);
      break;
   case 5:     // CD-ROM device
      errcode = ((ScsiCdRomDevice*) BaseDevice)->
         ReadCapacity(&dLast, &dSize);
      break;
   default:
      m_Output.SetWindowText("Invalid device type");
      return;
   }

   // create output message
   if (errcode == DEV_ERR_NO_SENSE)
   {
      wsprintf(buff,
         "Last Sector:     %lu\r\n"
         "Sector Size:     %lu bytes\r\n"
         "Total Capacity:  %lu kbytes",
         dLast, dSize, (dLast * dSize) / 1024);
   }
   else
   {
      BaseDevice->QueryErrorString(errcode, buff, sizeof(buff));
   }

   m_Output.SetWindowText(buff);
}


void CActionDlg::OnReadSector(void)
{
   ScsiError_t errcode;
   DWORD dLast, dSize, dRead;
   char buff[1024];
   DWORD sectnum = 0L;
   WORD bsize = 0x4000;    // output buffer size
   char *pbuff, *psect;
   int dlgresult;


   CSectnumDlg dlg(&sectnum);
   dlgresult = dlg.DoModal();

   if (dlgresult == -1)
   {
      // error creating dialog box
      MessageBox("Could not create sector number dialog box.",
         "Dialog Error");
      return;
   }
   else if (dlgresult == IDCANCEL)
   // user cancelled
   {
      return;
   }

   // get sector size data
   errcode = ((ScsiDiskDevice*) BaseDevice)->ReadCapacity(&dLast, &dSize);

   if (errcode == DEV_ERR_NO_SENSE)
   // sector size read succeeded
   {
      if (dSize == 0)
      // no sector size
      {
         m_Output.SetWindowText("Medium not present");
         return;
      }

      // allocate buffer
      AlignedBuffer sectdata((WORD) dSize);
      psect = (char *) sectdata.Ptr();

      // check for null pointer
      if (!psect)
      {
         m_Output.SetWindowText("Cannot allocate memory");
         return;
      }

      errcode = ((ScsiDiskDevice*) BaseDevice)->
         ReadSector(sectnum, psect, dSize, &dRead);

      if (dSize > 0 && dRead != dSize)
      {
         m_Output.SetWindowText("Sector size mismatch");
         return;
      }

      if (errcode == DEV_ERR_NO_SENSE)
      // sector read succeeded
      {
         // make sure we read something
         if (dRead == 0)
         // nothing read
         {
            m_Output.SetWindowText("No data read");
            return;
         }

         // allocate an output buffer
         pbuff = (char *) malloc(bsize);

         // check for null pointer
         if (!pbuff)
         {
            m_Output.SetWindowText("Cannot allocate memory");
            return;
         }

         if (FormatSectorData(psect, (WORD) dRead, pbuff, bsize) != 0)
         // display formatted sector data
         {
            m_Output.SetWindowText(pbuff);
         }
         else
         // output buffer overrun
         {
            m_Output.SetWindowText("Unable to display data");
         }
      }
      else
      {
         BaseDevice->QueryErrorString(errcode, buff, sizeof(buff));
         m_Output.SetWindowText(buff);
      }
   }
   else
   {
      BaseDevice->QueryErrorString(errcode, buff, sizeof(buff));
      m_Output.SetWindowText(buff);
   }
}


void CActionDlg::OnReadToc(void)
{
   ScsiError_t errcode;
   DWORD dRead;
   char buff[1024];
   WORD tsize = 0x2000;    // TOC data buffer size
   WORD bsize = 0x4000;    // output buffer size
   char *pbuff, *ptoc;


   // allocate buffer
   AlignedBuffer tocdata(tsize);
   ptoc = (char *) tocdata.Ptr();

   // check for null pointer
   if (!ptoc)
   {
      m_Output.SetWindowText("Cannot allocate memory");
      return;
   }

   // read table of contents
   errcode = ((ScsiCdRomDevice*) BaseDevice)->
      ReadToc(ptoc, bsize, &dRead);

   if (errcode == DEV_ERR_NO_SENSE)
   // TOC read succeeded
   {
      // make sure we read something
      if (dRead == 0)
      // nothing read
      {
         m_Output.SetWindowText("No data read");
         return;
      }

      // allocate an output buffer
      pbuff = (char *) malloc(bsize);

      // check for null pointer
      if (!pbuff)
      {
         m_Output.SetWindowText("Cannot allocate memory");
         return;
      }

      if (FormatTocData(ptoc, (WORD) dRead, pbuff, bsize) != 0)
      // display formatted table of contents
      {
         m_Output.SetWindowText(pbuff);
      }
      else
      // output buffer overrun
      {
         m_Output.SetWindowText("Unable to display data");
      }
   }
   else
   {
      BaseDevice->QueryErrorString(errcode, buff, sizeof(buff));
      m_Output.SetWindowText(buff);
   }
}


void CActionDlg::OnLockUnlock(void)
{
   ScsiError_t errcode;
   char buff[256];
   int fLock = 1;
   int dlgresult;


   CLockDlg dlg(&fLock);
   dlgresult = dlg.DoModal();

   if (dlgresult == -1)
   {
      // error creating dialog box
      MessageBox("Could not create lock info dialog box.",
         "Dialog Error");
      return;
   }
   else if (dlgresult == IDCANCEL)
   // user cancelled
   {
      return;
   }

   switch (Device->GetType())
   {
   case 0:     // direct access device
      errcode = ((ScsiDiskDevice*) BaseDevice)->
         LockUnlock(fLock);
      break;
   case 5:     // CD-ROM device
      errcode = ((ScsiCdRomDevice*) BaseDevice)->
         LockUnlock(fLock);
      break;
   default:
      m_Output.SetWindowText("Invalid device type");
      return;
   }

   // create output message
   if (errcode == DEV_ERR_NO_SENSE)
   // no errors - device is ready
   {
      wsprintf(buff, "Medium is %s",
         (fLock) ? "locked" : "unlocked");
   }
   else
   // print error codes
   {
      BaseDevice->QueryErrorString(errcode, buff, sizeof(buff));
   }

   m_Output.SetWindowText(buff);
}


void CActionDlg::OnEject(void)
{
   ScsiError_t errcode;
   char buff[256];


   switch (Device->GetType())
   {
   case 0:     // direct access device
      errcode = ((ScsiDiskDevice*) BaseDevice)->Eject();
      break;
   case 5:     // CD-ROM device
      errcode = ((ScsiCdRomDevice*) BaseDevice)->Eject();
      break;
   default:
      m_Output.SetWindowText("Invalid device type");
      return;
   }

   // create output message
   if (errcode == DEV_ERR_NO_SENSE)
   // no errors - device is ready
   {
      lstrcpy(buff, "Medium unloaded");
   }
   else
   // print error codes
   {
      BaseDevice->QueryErrorString(errcode, buff, sizeof(buff));
   }

   m_Output.SetWindowText(buff);
}


// helper functions

WORD FormatSectorData(char *pin, WORD insize, char *pout, WORD outsize)
{
   WORD tbytes = 0;
   int pad, line, nlines, row = 8;
   char hbuf[80], cbuf[80];
   char buff[256];
   char *hptr, *cptr, *optr;
   WORD count;

   line = (4 * row) + 8;   // line length
   nlines = (insize / row) + 1;

   // calculate required output size

   if (outsize < (line * nlines))
   // output buffer too small
   {
      return 0;
   }

   optr = pout;         // set output pointer
   hptr = hbuf;
   cptr = cbuf;

   for (count = 0; count < insize; count++) {
   // loop through block buffer
      wsprintf(hptr, "%02X ", (BYTE) pin[count]);
      wsprintf(cptr, "%c",
         (isprint(pin[count]) ? pin[count] : '.'));

      hptr += 3;
      cptr++;

      if (count % row == (row - 1)) {
      // end this row
         wsprintf(buff, "%04X  %s %s\r\n",
            ((count / row) * row), hbuf, cbuf);
         lstrcpy(optr, buff);
         tbytes += lstrlen(buff);
         optr += lstrlen(buff);
         hptr = hbuf;
         cptr = cbuf;
      }
   }

   if ((count - 1) % row != (row - 1)) {
   // print remainder
      pad = (row - (count % row)) * 3;
      memset(hptr, ' ', pad);
      hptr[pad] = '\0';

      wsprintf(buff, "   %04X  %s %s\r\n",
         ((count / row) * row), hbuf, cbuf);
      lstrcpy(optr, buff);
      tbytes += lstrlen(buff);
      optr += lstrlen(buff);
   }

   return(tbytes);
}


WORD FormatTocData(char *pin, WORD insize, char *pout, WORD outsize)
{
   WORD tbytes = 0;
   SCSI_ReadTocData_t *phead;
   SCSI_TocDescriptor_t *pdesc;
   WORD count;
   WORD ndesc;
   char buff[256];
   char *optr;


   // point to TOC header
   phead = (SCSI_ReadTocData_t *) pin;

   // point to descriptors
   pdesc = (SCSI_TocDescriptor_t *) (phead + 1);

   // get descriptor count
#if 0
   ndesc = ((WORD) phead->Length1) << 8 |
      ((WORD) phead->Length0) - 2;
   ndesc /= sizeof(SCSI_TocDescriptor_t);
#else
   ndesc = (phead->LastTrack - phead->FirstTrack) + 1;
#endif

   optr = pout;

   wsprintf(buff,
      "First track: %d\r\n"
      "Last track:  %d\r\n",
      phead->FirstTrack, phead->LastTrack);

   lstrcpy(optr, buff);
   optr += lstrlen(buff);
   tbytes += lstrlen(buff);

   for (count = 0; count < ndesc; count++)
   // format descriptors
   {
      wsprintf(buff, "\r\n"
      "Track number: %d\r\n"
      "ADR code:     %02Xh\r\n"
      "Track type:   %s\r\n",
      pdesc[count].TrackNumber,
      pdesc[count].ADR,
      (pdesc[count].Control & 4) ? "data" : "audio");

      lstrcpy(optr, buff);
      optr += lstrlen(buff);
      tbytes += lstrlen(buff);
   }

   return(tbytes);
}
