// DeviceDlg.h : header file
//

#include "scsibus.hpp"

// define max device type
#define MAX_TYPE        10

///////////////////////////////////////////////////////////////////////////////
// CDeviceDlg dialog

class CDeviceDlg : public CDialog
{
// Construction
public:
	CDeviceDlg(ScsiDevice *psd = NULL, CWnd* pParent = NULL);   // standard constructor
                                      
// Dialog Data
	//{{AFX_DATA(CDeviceDlg)
	enum { IDD = IDD_DEVICE_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDeviceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	char *MapDeviceString(int devtype);
	ScsiDevice *GetDevice();
	ScsiDevice *SetDevice(ScsiDevice *);
	ScsiDevice *Device;

	// Generated message map functions
	//{{AFX_MSG(CDeviceDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnMoreinfo();
	afx_msg void OnActions();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
