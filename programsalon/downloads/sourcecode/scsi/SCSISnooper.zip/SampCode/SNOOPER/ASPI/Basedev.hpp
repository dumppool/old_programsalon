////////////////////////////////////////////////////////////
//
// Module BASEDEV.HPP
//
// ASPI class library
//
// Project: A Programmer's Guide to SCSI
//
// Copyright (C) 1997, Brian Sawert
// Portions copyright (C) 1995, Larry Martin
// All rights reserved
//
////////////////////////////////////////////////////////////


#ifndef BASEDEV_HPP_INCLUDED
#define BASEDEV_HPP_INCLUDED

#ifndef SEM_HPP_INCLUDED
#include "sem.hpp"
#endif

#ifndef SCSIDEFS_H_INCLUDED
#include "scsidefs.h"
#endif

#ifndef SCSIDEV_HPP_INCLUDED
#include "scsidev.hpp"
#endif


typedef long ScsiError_t;

// Major error codes

#define NUM_MAJOR_ERRORS         22

// These correspond to SCSI sense keys
#define DEV_ERR_NO_SENSE         0x000000
#define DEV_ERR_RECOVERED        0x010000
#define DEV_ERR_NOT_READY        0x020000
#define DEV_ERR_MEDIUM           0x030000
#define DEV_ERR_HARDWARE         0x040000
#define DEV_ERR_ILLEGAL_REQUEST  0x050000
#define DEV_ERR_UNIT_ATTENTION   0x060000
#define DEV_ERR_DATA_PROTECT     0x070000
#define DEV_ERR_BLANK_CHECK      0x080000
#define DEV_ERR_VENDOR           0x090000
#define DEV_ERR_COPY_ABORTED     0x0A0000
#define DEV_ERR_CMD_ABORTED      0x0B0000
#define DEV_ERR_EQUAL            0x0C0000
#define DEV_ERR_VOL_OVERFLOW     0x0D0000
#define DEV_ERR_MISCOMPARE       0x0E0000
#define DEV_ERR_RESERVED         0x0F0000

// additional major error codes
// made up to reflect other errors
#define DEV_ERR_FILEMARK         0x100000
#define DEV_ERR_END_OF_MEDIUM    0x110000
#define DEV_ERR_INCORRECT_LENGTH 0x120000
#define DEV_ERR_SYSTEM           0x130000
#define DEV_ERR_DRIVER           0x140000
#define DEV_ERR_UNKNOWN          0x150000


// macros to extract error codes
#define MakeError(major,minor)   ((major) | (minor))
#define MajorError(err)          ((err) & 0xFFFF0000)
#define MinorError(err)          ((err) & 0x0000FFFF)
#define AscError(err)            (((err) & 0x0000FF00) >> 8)
#define AsqError(err)            ((err) & 0x000000FF)


// For compatibility
#define Scsi_Dir_None   SRB_DIR_SCSI
#define Scsi_Dir_In     SRB_DIR_IN
#define Scsi_Dir_Out    SRB_DIR_OUT


// structure for common device attributes
typedef struct ScsiDeviceAttributes_s
   {
   long ShortTimeout;
   long MediumTimeout;
   long LongTimeout;
   } ScsiDeviceAttributes_t;


// Base class for derived SCSI device classes
class ScsiBaseDevice
   {
   public:

   ScsiDevice *Device;

   int IsOpen;
   int LastError;
   int SystemError;
   int LastScsiError;

   unsigned Adapter;
   unsigned Unit;
   unsigned Lun;

   ScsiCmdBlock Scb;       // all commands use this ScsiCmdBlock
   MutexSemaphore ScbMutex;

   union
      {
      SCSI_SenseData_t Sense;
      unsigned char SenseBuffer[SENSE_LEN];
      };

   ScsiDeviceAttributes_t  Attributes;
   SCSI_InquiryData_t      InquiryData;

   ScsiBaseDevice();
   ~ScsiBaseDevice();

   ScsiDevice *GetScsiDevice();

   ScsiError_t Open(ScsiDevice *dev, ScsiDeviceAttributes_t *attr=0);
   ScsiError_t Close(void);

   ScsiError_t DoCommand( void *cdb, unsigned cdblen,
                        void *dbuf, unsigned long dbuflen, int dir,
                        long timeout );

   int ValidResidualCount();
   long GetResidualCount();
   unsigned MapAscAsq();
   ScsiError_t MapScsiError();

   ScsiError_t WaitTilReady(long timeout = -1);

   ScsiError_t TestUnitReady();
   ScsiError_t RequestSense(void *bufp, unsigned maxbytes);
   ScsiError_t Inquiry( void *bufp, unsigned maxbytes, int evpd=0, int page_code=0 );
   ScsiError_t ModeSelect( void *bufp, unsigned nbytes, int pf=0, int sp=0 );
   ScsiError_t ModeSense( void *bufp, unsigned maxbytes, int page_code=0, int pc=0, int dbd=0 );

   void QueryErrorString(ScsiError_t errcode, char *bufp, unsigned maxbytes);
   char *QueryMajorErrorString(ScsiError_t errcode);
   };


// Class for DWORD aligned buffers
class AlignedBuffer
   {
   public:
      AlignedBuffer(WORD size);
      ~AlignedBuffer();
      void *Ptr() {return AlignedPtr;};

   protected:

   private:

      char *TruePtr;
      void *AlignedPtr;
   };


#endif

