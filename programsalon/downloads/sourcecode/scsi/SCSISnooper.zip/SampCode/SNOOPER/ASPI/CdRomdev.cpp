////////////////////////////////////////////////////////////
//
// Module CDROMDEV.CPP
//
// ASPI class library
// SCSI CD-ROM device class
//
// Project: A Programmer's Guide to SCSI
//
// Copyright (C) 1997, Brian Sawert
// Portions copyright (C) 1995, Larry Martin
// All rights reserved
//
////////////////////////////////////////////////////////////


#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <time.h>

#include "cdromdev.hpp"


// SCSI CD-ROM device functions

ScsiCdRomDevice::ScsiCdRomDevice()
   : ScsiBaseDevice()
{
   // add initialization here
}


ScsiCdRomDevice::~ScsiCdRomDevice()
{
   // call parent destructor
   ScsiBaseDevice::~ScsiBaseDevice();
}


ScsiError_t ScsiCdRomDevice::ReadCapacity(DWORD *blklast, DWORD *blksize)
{
   SCSI_Cdb_ReadCapacity_t cdb;
   SCSI_ReadCapacityData_t cd;


   memset(&cd, 0, sizeof(cd));
   memset(&cdb,0,sizeof(cdb));
   cdb.CommandCode = SCSI_Cmd_ReadCapacity;
   cdb.Lun = Lun;

   LastError = DoCommand(&cdb,10,&cd,sizeof(cd),Scsi_Dir_In,Attributes.ShortTimeout);

   *blklast = ((DWORD)cd.BlockAddress3 << 24) |
              ((DWORD)cd.BlockAddress2 << 16) |
              ((DWORD)cd.BlockAddress1 << 8) |
              ((DWORD)cd.BlockAddress0);

   *blksize = ((DWORD)cd.BlockSize3 << 24) |
              ((DWORD)cd.BlockSize2 << 16) |
              ((DWORD)cd.BlockSize1 << 8) |
              ((DWORD)cd.BlockSize0);

   return LastError;
}


ScsiError_t ScsiCdRomDevice::ReadToc(void *bufp, DWORD maxbytes, DWORD *bytesread)
{
   SCSI_Cdb_ReadToc_t cdb;
   SCSI_ReadTocData_t *ptd;
   DWORD nbytes;


   // max TOC length is 804 bytes
   nbytes = (maxbytes > 804) ? 804 : maxbytes;

   // clear output buffer
   memset(bufp, 0, (WORD) nbytes);

   // read the table of contents
   memset(&cdb,0,sizeof(cdb));
   cdb.CommandCode = SCSI_Cmd_ReadToc;
   cdb.Lun = Lun;
   cdb.StartTrack = 0;
   cdb.Length1 = (nbytes >> 8) & 0xFF;
   cdb.Length0 = nbytes & 0xFF;

   LastError = DoCommand(&cdb,10,bufp,nbytes,Scsi_Dir_In,Attributes.ShortTimeout);

   if(LastScsiError == Err_None)
   // no errors - format output
   {
      if (bytesread)
      // return read count
      {
         ptd = (SCSI_ReadTocData_t *) bufp;

         *bytesread = ((DWORD) ptd->Length1) << 8 |
            (DWORD) (ptd->Length0);
      }
   }

   return LastError;
}



ScsiError_t ScsiCdRomDevice::LockUnlock(int fLock)
{
   SCSI_Cdb_PreventAllow_t cdb;

   memset(&cdb,0,sizeof(cdb));
   cdb.CommandCode = SCSI_Cmd_PreventAllow;
   cdb.Lun = Lun;
   cdb.Prevent = (fLock) ? 1 : 0;

   LastError = DoCommand(&cdb,6,NULL,0,Scsi_Dir_None,Attributes.ShortTimeout);

   return LastError;
}


ScsiError_t ScsiCdRomDevice::Eject()
{
   SCSI_Cdb_LoadUnload_t cdb;

   memset(&cdb,0,sizeof(cdb));
   cdb.CommandCode = SCSI_Cmd_LoadUnload;
   cdb.Lun = Lun;
   cdb.LoadEject = 1;

   LastError = DoCommand(&cdb,6,NULL,0,Scsi_Dir_None,Attributes.MediumTimeout);

   return LastError;
}


