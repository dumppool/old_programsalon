////////////////////////////////////////////////////////////
//
// Module DISKDEV.CPP
//
// ASPI class library
// SCSI direct access device class
//
// Project: A Programmer's Guide to SCSI
//
// Copyright (C) 1997, Brian Sawert
// Portions copyright (C) 1995, Larry Martin
// All rights reserved
//
////////////////////////////////////////////////////////////


#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <time.h>

#include "diskdev.hpp"


// SCSI disk device functions

ScsiDiskDevice::ScsiDiskDevice()
   : ScsiBaseDevice()
{
   // add initialization here
}


ScsiDiskDevice::~ScsiDiskDevice()
{
   // call parent destructor
   ScsiBaseDevice::~ScsiBaseDevice();
}


ScsiError_t ScsiDiskDevice::ReadCapacity(DWORD *blklast, DWORD *blksize)
{
   SCSI_Cdb_ReadCapacity_t cdb;
   SCSI_ReadCapacityData_t cd;


   memset(&cd, 0, sizeof(cd));
   memset(&cdb,0,sizeof(cdb));
   cdb.CommandCode = SCSI_Cmd_ReadCapacity;
   cdb.Lun = Lun;

   LastError = DoCommand(&cdb,10,&cd,sizeof(cd),Scsi_Dir_In,Attributes.ShortTimeout);

   *blklast = ((DWORD)cd.BlockAddress3 << 24) |
              ((DWORD)cd.BlockAddress2 << 16) |
              ((DWORD)cd.BlockAddress1 << 8) |
              ((DWORD)cd.BlockAddress0);

   *blksize = ((DWORD)cd.BlockSize3 << 24) |
              ((DWORD)cd.BlockSize2 << 16) |
              ((DWORD)cd.BlockSize1 << 8) |
              ((DWORD)cd.BlockSize0);

   return LastError;
}


ScsiError_t ScsiDiskDevice::ReadSector(DWORD sectnum, void *bufp, DWORD maxbytes, DWORD *bytesread)
{
   SCSI_Cdb_Read_t cdb;
   DWORD dLast, dSize, dTotal;


   // get disk sector size
   LastError = ReadCapacity(&dLast, &dSize);

   if (LastError == Err_None && dSize > 0)
   // got sector size - check bounds
   {
      dTotal = dLast * dSize;

      if (maxbytes < dSize || sectnum > dLast)
      // parameter out of range
      {
         LastError = MakeError(DEV_ERR_DRIVER, 0);
         return LastError;
      }

      // read the sector
      memset(&cdb,0,sizeof(cdb));
      cdb.CommandCode = SCSI_Cmd_Read;
      cdb.Lun = Lun;
      cdb.LBA2 = (sectnum >> 16) & 0x1F;
      cdb.LBA1 = (sectnum >> 8) & 0xFF;
      cdb.LBA0 = sectnum & 0xFF;
      cdb.Length = 1;

      LastError = DoCommand(&cdb,6,bufp,dSize,Scsi_Dir_In,Attributes.MediumTimeout);
   }

   if (LastScsiError == Err_None)
   // no errors - return byte count
   {
      if (bytesread)
      // return read count
      {
         *bytesread = dSize;
      }
   }

   return LastError;
}



ScsiError_t ScsiDiskDevice::LockUnlock(int fLock)
{
   SCSI_Cdb_PreventAllow_t cdb;

   memset(&cdb,0,sizeof(cdb));
   cdb.CommandCode = SCSI_Cmd_PreventAllow;
   cdb.Lun = Lun;
   cdb.Prevent = (fLock) ? 1 : 0;

   LastError = DoCommand(&cdb,6,NULL,0,Scsi_Dir_None,Attributes.ShortTimeout);

   return LastError;
}


ScsiError_t ScsiDiskDevice::Eject()
{
   SCSI_Cdb_LoadUnload_t cdb;

   memset(&cdb,0,sizeof(cdb));
   cdb.CommandCode = SCSI_Cmd_LoadUnload;
   cdb.Lun = Lun;
   cdb.LoadEject = 1;

   LastError = DoCommand(&cdb,6,NULL,0,Scsi_Dir_None,Attributes.MediumTimeout);

   return LastError;
}


