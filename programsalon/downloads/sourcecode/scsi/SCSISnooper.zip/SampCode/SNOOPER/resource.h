//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Snooper.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SNOOPER_DIALOG              102
#define CG_IDS_PHYSICAL_MEM             103
#define CG_IDS_DISK_SPACE               104
#define CG_IDS_DISK_SPACE_UNAVAIL       105
#define IDR_APPICON                     110
#define IDR_MAINFRAME                   111
#define IDI_ADAPTER                     117
#define IDI_DEV_DISK                    130
#define IDI_DEV_BASE                    130
#define IDI_DEV_TAPE                    131
#define IDI_DEV_PRINTER                 132
#define IDI_DEV_PROCESSOR               133
#define IDI_DEV_WORM                    134
#define IDI_DEV_CDROM                   135
#define IDI_DEV_SCANNER                 136
#define IDI_DEV_OPTICAL                 137
#define IDI_DEV_CHANGER                 138
#define IDI_DEV_COMM                    139
#define IDI_DEV_UNKNOWN                 140
#define IDC_PHYSICAL_MEM                1000
#define IDC_DISK_SPACE                  1001
#define IDC_HA_NUMBER                   1003
#define IDC_ASPI_MGR                    1004
#define IDC_IDENT                       1005
#define IDC_DEVICES                     1006
#define IDC_SCSI_ID                     1007
#define IDC_SCSI_LUN                    1008
#define IDC_HA_0                        1010
#define IDC_DEVTYPE                     1010
#define IDC_HA_1                        1011
#define IDC_DEVNAME                     1011
#define IDC_HA_2                        1012
#define IDC_REVISION                    1012
#define IDC_HA_3                        1013
#define IDC_ANSI_VERSION                1013
#define IDC_REMOVABLE                   1014
#define IDC_WIDE32                      1015
#define IDC_MOREINFO                    1015
#define IDC_WIDE16                      1016
#define IDC_ACTIONS                     1016
#define IDC_SYNC                        1017
#define IDC_LINKED                      1018
#define IDC_QUEUE                       1019
#define IDC_DEV_0                       1020
#define IDC_SOFTRESET                   1020
#define IDC_DEV_1                       1021
#define IDC_RUN                         1021
#define IDC_DEV_2                       1022
#define IDC_OUTPUT                      1022
#define IDC_DEV_3                       1023
#define IDC_DEV_4                       1024
#define IDC_SECTNUM                     1024
#define IDC_DEV_5                       1025
#define IDC_LOCK                        1025
#define IDC_DEV_6                       1026
#define IDC_UNLOCK                      1026
#define IDC_DEV_7                       1027
#define IDC_DEV_8                       1028
#define IDC_DEV_9                       1029
#define IDC_DEV_10                      1030
#define IDC_DEV_11                      1031
#define IDC_HA_0_T                      1040
#define IDD_ADAPTER_DIALOG              1040
#define IDC_HA_1_T                      1041
#define IDD_DEVICE_DLG                  1041
#define IDC_HA_2_T                      1042
#define IDD_MOREINFO_DLG                1042
#define IDC_HA_3_T                      1043
#define IDD_ACTIONS_DLG                 1043
#define IDD_SECTNUM                     1044
#define IDD_LOCKUNLOCK                  1045
#define IDC_DEV_0_T                     1050
#define IDC_DEV_1_T                     1051
#define IDC_DEV_2_T                     1052
#define IDC_DEV_3_T                     1053
#define IDC_DEV_4_T                     1054
#define IDC_DEV_5_T                     1055
#define IDC_DEV_6_T                     1056
#define IDC_DEV_7_T                     1057
#define IDC_DEV_8_T                     1058
#define IDC_DEV_9_T                     1059
#define IDC_DEV_10_T                    1060
#define IDC_DEV_11_T                    1061
#define IDC_TESTUNIT                    1100
#define IDC_INQUIRY                     1101
#define IDC_READSENSE                   1102
#define IDC_CAPACITY                    1103
#define IDC_READSECTOR                  1104
#define IDC_READTOC                     1105
#define IDC_LOCKUNLOCK                  1106
#define IDC_EJECT                       1107

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1046
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           125
#endif
#endif
