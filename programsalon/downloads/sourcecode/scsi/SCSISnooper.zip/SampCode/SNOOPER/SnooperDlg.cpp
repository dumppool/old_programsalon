// SnooperDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Snooper.h"
#include "SnooperDlg.h"
#include <string.h>
#include <dos.h>
#include <direct.h>
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// linkage to application class
extern CSnooperApp theApp;


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
   CAboutDlg();

// Dialog Data
   //{{AFX_DATA(CAboutDlg)
   enum { IDD = IDD_ABOUTBOX };
   //}}AFX_DATA

   // ClassWizard generated virtual function overrides
   //{{AFX_VIRTUAL(CAboutDlg)
   protected:
   virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
   //}}AFX_VIRTUAL

// Implementation
protected:
   virtual BOOL OnInitDialog();
   //{{AFX_MSG(CAboutDlg)
   //}}AFX_MSG
   DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
   //{{AFX_DATA_INIT(CAboutDlg)
   //}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   //{{AFX_DATA_MAP(CAboutDlg)
   //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
   //{{AFX_MSG_MAP(CAboutDlg)
   // No message handlers
   //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSnooperDlg dialog

CSnooperDlg::CSnooperDlg(CWnd* pParent /*=NULL*/)
   : CDialog(CSnooperDlg::IDD, pParent)
{
   ScsiDevice *curdev;


   //{{AFX_DATA_INIT(CSnooperDlg)
   //}}AFX_DATA_INIT
   // Note that LoadIcon does not require a subsequent DestroyIcon in Win32
   m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

   // initialize adapter and device count
   nAdapters = theApp.ScsiBus->GetNumAdapters();
   nAdapters = (nAdapters < MAX_ADAPTERS) ? nAdapters : MAX_ADAPTERS;
   nDevices = 0;

   // create iterator for device linked list
   ItemListIterator iter(&theApp.ScsiBus->ScsiDevList);
   curdev = (ScsiDevice *) iter.GetFirst();

   // map device list to pointer array
   while (curdev != NULL && nDevices < MAX_DEVICES)
   {
      DevList[nDevices] = curdev;
      nDevices++;
      curdev = (ScsiDevice *) iter.IterateToNext();
   }
}

void CSnooperDlg::DoDataExchange(CDataExchange* pDX)
{
   int count;


   CDialog::DoDataExchange(pDX);
   //{{AFX_DATA_MAP(CSnooperDlg)
   //}}AFX_DATA_MAP

   for ( count = 0; count < nAdapters; count++)
   {
      DDX_Control(pDX, IDC_HA_0 + count, HAButton[count]);
   }

   for ( count = 0; count < nDevices; count++)
   {
      DDX_Control(pDX, IDC_DEV_0 + count, DevButton[count]);
   }
}

BEGIN_MESSAGE_MAP(CSnooperDlg, CDialog)
   //{{AFX_MSG_MAP(CSnooperDlg)
   ON_WM_SYSCOMMAND()
   ON_WM_PAINT()
   ON_WM_QUERYDRAGICON()
   //}}AFX_MSG_MAP

   // handler for host adapter buttons
   ON_CONTROL_RANGE(BN_CLICKED, IDC_HA_0, IDC_HA_3, OnHaButtonClicked)
   // handler for device buttons
   ON_CONTROL_RANGE(BN_CLICKED, IDC_DEV_0, IDC_DEV_11, OnDevButtonClicked)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSnooperDlg message handlers

BOOL CSnooperDlg::OnInitDialog()
{
   HICON hIcon;
   int count;
   int devtype;
   char *ptr, buff[64];


   CDialog::OnInitDialog();

   // Add "About..." menu item to system menu.

   // IDM_ABOUTBOX must be in the system command range.
   ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
   ASSERT(IDM_ABOUTBOX < 0xF000);

   CMenu* pSysMenu = GetSystemMenu(FALSE);
   CString strAboutMenu;
   strAboutMenu.LoadString(IDS_ABOUTBOX);
   if (!strAboutMenu.IsEmpty())
   {
      pSysMenu->AppendMenu(MF_SEPARATOR);
      pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
   }

   // Set the icon for this dialog.  The framework does this automatically
   //  when the application's main window is not a dialog
   SetIcon(m_hIcon, TRUE);       // Set big icon
   SetIcon(m_hIcon, FALSE);      // Set small icon

   // TODO: Add extra initialization here
   hIcon = AfxGetApp()->LoadIcon(IDI_ADAPTER);

   for (count = 0; count < nAdapters; count++)
   // build adapter buttons
   {
      HAButton[count].ShowWindow(SW_SHOW);
      HAButton[count].SetIcon(hIcon);

      lstrcpy(buff, theApp.ScsiBus->AdapterList[count].Identifier);

      if ((ptr = strchr(buff, ' '))) {
      // break at first space
         *ptr = '\0';
      }

      GetDlgItem(IDC_HA_0_T + count)->ShowWindow(SW_SHOW);
      SetDlgItemText(IDC_HA_0_T + count, buff);
   }

   for (count = 0; count < nDevices; count++)
   // build device buttons
   {
      devtype = DevList[count]->Type;
      devtype = (devtype < MAX_TYPE) ? devtype : MAX_TYPE;
      hIcon = AfxGetApp()->LoadIcon(IDI_DEV_DISK + devtype);
      DevButton[count].ShowWindow(SW_SHOW);
      DevButton[count].SetIcon(hIcon);

      lstrcpy(buff, DevList[count]->GetName());

      if ((ptr = strchr(buff, ' '))) {
      // break at first space
         *ptr = '\0';
      }

      GetDlgItem(IDC_DEV_0_T + count)->ShowWindow(SW_SHOW);
      SetDlgItemText(IDC_DEV_0_T + count, buff);
   }

   return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSnooperDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
   if ((nID & 0xFFF0) == IDM_ABOUTBOX)
   {
      CAboutDlg dlgAbout;
      dlgAbout.DoModal();
   }
   else
   {
      CDialog::OnSysCommand(nID, lParam);
   }
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSnooperDlg::OnPaint()
{
   if (IsIconic())
   {
      CPaintDC dc(this); // device context for painting

      SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

      // Center icon in client rectangle
      int cxIcon = GetSystemMetrics(SM_CXICON);
      int cyIcon = GetSystemMetrics(SM_CYICON);
      CRect rect;
      GetClientRect(&rect);
      int x = (rect.Width() - cxIcon + 1) / 2;
      int y = (rect.Height() - cyIcon + 1) / 2;

      // Draw the icon
      dc.DrawIcon(x, y, m_hIcon);
   }
   else
   {
      CDialog::OnPaint();
   }
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSnooperDlg::OnQueryDragIcon()
{
   return (HCURSOR) m_hIcon;
}

BOOL CAboutDlg::OnInitDialog()
{
   // CG: Folowing code is added by System Info Component
   {
   CDialog::OnInitDialog();
#ifndef _MAC
   CString strFreeDiskSpace;
   CString strFreeMemory;
   CString strFmt;

   // Fill available memory
   MEMORYSTATUS MemStat;
   MemStat.dwLength = sizeof(MEMORYSTATUS);
   GlobalMemoryStatus(&MemStat);
   strFmt.LoadString(CG_IDS_PHYSICAL_MEM);
   strFreeMemory.Format(strFmt, MemStat.dwTotalPhys / 1024L);

   //TODO: Add a static control to your About Box to receive the memory
   //      information.  Initialize the control with code like this:
   SetDlgItemText(IDC_PHYSICAL_MEM, strFreeMemory);

   // Fill disk free information
   struct _diskfree_t diskfree;
   int nDrive = _getdrive(); // use current default drive
   if (_getdiskfree(nDrive, &diskfree) == 0)
   {
      strFmt.LoadString(CG_IDS_DISK_SPACE);
      strFreeDiskSpace.Format(strFmt,
         (DWORD)diskfree.avail_clusters *
         (DWORD)diskfree.sectors_per_cluster *
         (DWORD)diskfree.bytes_per_sector / (DWORD)1024L,
         nDrive-1 + _T('A'));
   }
   else
      strFreeDiskSpace.LoadString(CG_IDS_DISK_SPACE_UNAVAIL);

   //TODO: Add a static control to your About Box to receive the memory
   //      information.  Initialize the control with code like this:
   SetDlgItemText(IDC_DISK_SPACE, strFreeDiskSpace);

#endif //_MAC
   }

   return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// Message handler for Host Adapter buttons

void CSnooperDlg::OnHaButtonClicked( UINT nID )
{
   int index = nID - IDC_HA_0;

   // check range
   ASSERT( index >= 0 && index < MAX_ADAPTERS );

   CAdapterDlg dlg(&theApp.ScsiBus->AdapterList[index]);

   if (dlg.DoModal() == -1)
   {
      // error creating dialog box
      MessageBox("Could not create adapter dialog box.",
         "Dialog Error");
   }
}

/////////////////////////////////////////////////////////////////////////////
// Message handler for Device buttons

void CSnooperDlg::OnDevButtonClicked( UINT nID )
{
   int index = nID - IDC_DEV_0;

   // check range
   ASSERT( index >= 0 && index < MAX_DEVICES );

   CDeviceDlg dlg(DevList[index]);

   if (dlg.DoModal() == -1)
   {
      // error creating dialog box
      MessageBox("Could not create device dialog box.",
         "Dialog Error");
   }
}