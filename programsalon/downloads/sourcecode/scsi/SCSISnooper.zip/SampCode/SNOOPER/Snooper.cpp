// Snooper.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Snooper.h"
#include "SnooperDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSnooperApp

BEGIN_MESSAGE_MAP(CSnooperApp, CWinApp)
   //{{AFX_MSG_MAP(CSnooperApp)
      // NOTE - the ClassWizard will add and remove mapping macros here.
      //    DO NOT EDIT what you see in these blocks of generated code!
   //}}AFX_MSG
   ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSnooperApp construction

CSnooperApp::CSnooperApp()
{
   // TODO: add construction code here,
   // Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSnooperApp object

CSnooperApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CSnooperApp initialization

BOOL CSnooperApp::InitInstance()
{
   // Standard initialization
   // If you are not using these features and wish to reduce the size
   //  of your final executable, you should remove from the following
   //  the specific initialization routines you do not need.

   int nResponse;


#ifdef _AFXDLL
   Enable3dControls();        // Call this when using MFC in a shared DLL
#else
   Enable3dControlsStatic();  // Call this when linking to MFC statically
#endif

   ScsiBus = new ScsiInterface(1);

   // make sure we have a SCSI adapter
   if (ScsiBus->GetNumAdapters() <= 0)
   // no adapters found
   {
      MessageBox(NULL, "No SCSI adapters found.",
         "ASPI Error", MB_ICONEXCLAMATION | MB_OK);

      nResponse = IDCANCEL;
   }
   else
   // ASPI returned adapter count
   {
      CSnooperDlg dlg;
      m_pMainWnd = &dlg;
      nResponse = dlg.DoModal();
   }

   if (nResponse == IDOK)
   {
      // TODO: Place code here to handle when the dialog is
      //  dismissed with OK
   }
   else if (nResponse == IDCANCEL)
   {
      // TODO: Place code here to handle when the dialog is
      //  dismissed with Cancel
   }

   // Since the dialog has been closed, return FALSE so that we exit the
   //  application, rather than start the application's message pump.
   return FALSE;
}

int CSnooperApp::ExitInstance() 
{
	// TODO: Add your specialized code here and/or call the base class
	
   delete ScsiBus;


	return CWinApp::ExitInstance();
}
