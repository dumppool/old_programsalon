// MoreinfoDlg.h : header file
//

#include "scsibus.hpp"

/////////////////////////////////////////////////////////////////////////////
// CMoreinfoDlg dialog

class CMoreinfoDlg : public CDialog
{
// Construction
public:
	CMoreinfoDlg(ScsiDevice *psd = NULL, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMoreinfoDlg)
	enum { IDD = IDD_MOREINFO_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMoreinfoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	char *MapVersionString(int ansiver);
	ScsiDevice *GetDevice();
	ScsiDevice *SetDevice(ScsiDevice *);
	ScsiDevice *Device;

	// Generated message map functions
	//{{AFX_MSG(CMoreinfoDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
