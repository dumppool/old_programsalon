// FPDUMPWDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FPDUMPW.h"
#include "FPDUMPWDlg.h"
#include "aspiw32.h"
#include "DialogSettings.h"
#include <io.h>
#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
CString strFileName;
BYTE	HostAdapterID = 0;
BYTE	TargetID = 3;
BYTE	LUN = 0;
// ��̨�߳�
UINT DumpWatcher( LPVOID pParam )
{
	IsWatcherRunning = TRUE;
	bCancelWatcher = FALSE;
	CWnd *pDialog;
	CButton *pbtnSetting;
	CButton *pbtnClose;
	pDialog = AfxGetMainWnd();
	pbtnSetting = (CButton*)(pDialog->GetDlgItem(IDC_DUMP_SETTINGS));
	pbtnSetting->EnableWindow(FALSE);
	pbtnClose = (CButton*)(pDialog->GetDlgItem(IDC_DUMP_CLOSE));
	pbtnClose->EnableWindow(FALSE);

	//	::MessageBox(NULL,strFileName,"MESSAGE",MB_OK);
	// 1. Wait until tape is ready...
	pDialog->SetDlgItemText(IDC_DUMPSTATUS,"�ȴ��Ŵ�������...");
	for (;;)
	{
		if (bCancelWatcher) goto ExitLoop;
		if (IO_ALL_TEST_UNIT_READY(HostAdapterID,TargetID,LUN)==SS_COMP) break;
	}
	pDialog->SetDlgItemText(IDC_DUMPSTATUS,"�Ŵ����Ѿ�����");

	// 2. Load the tape
	if (bCancelWatcher) goto ExitLoop;
	pDialog->SetDlgItemText(IDC_DUMPSTATUS,"����װ�شŴ�...");
	if (IO_TAPE_LOAD(HostAdapterID,TargetID,LUN,0,1,1)!=SS_COMP)
	{
		pDialog->SetDlgItemText(IDC_DUMPSTATUS,"װ�شŴ�����");
		goto ExitLoop;
	}
	pDialog->SetDlgItemText(IDC_DUMPSTATUS,"װ�شŴ����");

	// 3. read files
	if (bCancelWatcher) goto ExitLoop;
	{
		CString strFileNameEx;
		char szTag[12];
		int nStatus = 1; // 1 ͷ��2 ���壬3 β
		int n = 1;
		int block = 0;
		FILE *fp = NULL;

		for (;;)
		{
			BYTE	buf[2048];
			int		nBlockLen;
			BOOLEAN	bFileMark;
			BOOLEAN bILI;
			BOOLEAN bEOM;
			BOOLEAN bValid;
			BYTE	bSenseKey;
			for (;;)
			{
				if (bCancelWatcher) goto ExitLoop;
				if (IO_ALL_TEST_UNIT_READY(HostAdapterID,TargetID,LUN)==SS_COMP) break;
			}
			if (bCancelWatcher) goto ExitLoop;
			IO_TAPE_READ(HostAdapterID,TargetID,LUN,2048,&(buf[0]),&nBlockLen,&bFileMark,&bEOM,&bILI,&bValid,&bSenseKey);
			if (bValid==0)
			{
				pDialog->SetDlgItemText(IDC_DUMPSTATUS,"���Ŵ��Ĺ����з������޷�Ԥ�ϵĴ���");
				fclose(fp);
				fp = NULL;
				goto ExitLoop;
			}
			if (nBlockLen>0)
			{
				if (nBlockLen<=2048)
				{
					if (fp==NULL)
					{
						switch(nStatus)
						{
						case 1:
							sprintf(szTag,".H%2.2d",n);
							break;
						case 2:
							sprintf(szTag,".D%2.2d",n);
							break;
						case 3:
							sprintf(szTag,".E%2.2d",n);
							break;
						}
						strFileNameEx = strFileName+ CString(szTag);

						pDialog->SetDlgItemText(IDC_DUMPSTATUS,CString("���ڴ����ļ�")+strFileNameEx);

						fp = fopen(strFileNameEx,"wb");
						if (fp==NULL)
						{
							pDialog->SetDlgItemText(IDC_DUMPSTATUS,CString("�޷������ļ�")+strFileNameEx);
							goto ExitLoop2;
						}
					}
					fwrite(&(buf[0]),1,nBlockLen,fp);
				} else
				{
					pDialog->SetDlgItemText(IDC_DUMPSTATUS,"�Ŵ����ݻ�����̫С");
					fclose(fp);
					fp = NULL;
					goto ExitLoop;
				}
			}
			if (bSenseKey==8)
			{
				if (fp!=NULL)
				{
					fclose(fp);
					fp = NULL;
				}
				pDialog->SetDlgItemText(IDC_DUMPSTATUS,"���Ŵ�˳������");
				goto ExitLoop2;
			}
			if ((bFileMark)&&(fp!=NULL))
			{
				nStatus = (nStatus % 3) + 1;
				fclose(fp);
				fp = NULL;
			}
		}
	}
ExitLoop:
	pDialog->SetDlgItemText(IDC_DUMPSTATUS,"�û��ж��˶��Ŵ�");
ExitLoop2:
	pbtnSetting = (CButton*)(pDialog->GetDlgItem(IDC_DUMP_SETTINGS));
	pbtnSetting->EnableWindow(TRUE);
	pbtnClose = (CButton*)(pDialog->GetDlgItem(IDC_DUMP_CLOSE));
	pbtnClose->EnableWindow(TRUE);
	IsWatcherRunning = FALSE;
	return 0;
}

// �źŵ�
BOOLEAN		 bCancelWatcher;
CWinThread		*pDumpWatcher;
BOOLEAN		 IsWatcherRunning = FALSE;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFPDUMPWDlg dialog

CFPDUMPWDlg::CFPDUMPWDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFPDUMPWDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFPDUMPWDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFPDUMPWDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFPDUMPWDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFPDUMPWDlg, CDialog)
	//{{AFX_MSG_MAP(CFPDUMPWDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_DUMP_START, OnDumpStart)
	ON_BN_CLICKED(IDC_DUMP_CANCEL, OnDumpCancel)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_DUMP_SETTINGS, OnDumpSettings)
	ON_BN_CLICKED(IDC_DUMP_CLOSE, OnDumpClose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFPDUMPWDlg message handlers

BOOL CFPDUMPWDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	pDumpWatcher	= NULL;
	if (!LoadASPIManager())
	{
		MessageBox("�޷�����ASPI����ģ�飬�����޷�����","���ش���",MB_ICONERROR);
		EndDialog(FALSE);
	}
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFPDUMPWDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFPDUMPWDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFPDUMPWDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CFPDUMPWDlg::OnDumpStart() 
{
	// TODO: Add your control notification handler code here
	CString strDir;
	CString strName;
	GetDlgItemText(IDC_EDIT1,strDir);
	GetDlgItemText(IDC_EDIT2,strName);
	strDir.TrimLeft();
	strDir.TrimRight();
	strName.TrimLeft();
	strName.TrimRight();
	if ((strDir.GetLength()!=0)&&(strDir.Right(1)!=CString("\\")))
	{
		strDir += CString("\\");
	}

	strFileName = strDir + strName;
	if (strFileName.GetLength()==0)
	{
		MessageBox("��Ŀ¼���ʹ���������ȫ��Ϊ��","��������",MB_ICONERROR);
		return ;
	}
	if (strDir.GetLength()>0)
	{
		CString strSearch = strDir + "*.*";
		struct _finddata_t fileinfo;
		CString strPath = strDir.Left(strDir.GetLength()-1);
		long handle;
	// �ж���Ŀ¼�Ƿ����
		handle = _findfirst(strSearch,&fileinfo);
		if (handle==-1)
		{
			int nRes = MessageBox("��Ŀ¼������,�Ƿ�Ҫ����?","��������",MB_ICONERROR|MB_YESNO);
			if (nRes==IDYES)
			{
				if (-1==_mkdir(strPath))
				{
					MessageBox("�޷�������Ŀ¼?","��������",MB_ICONERROR|MB_OK);
				}
			}
		} else
		{
			_findclose(handle);
		}
	}

	// �ж��ļ��Ƿ����
	FILE *fp;
	CString strFirstFileName;
	strFirstFileName = strFileName + ".D01";
	fp = fopen((LPCSTR)strFirstFileName,"rb");
	if (fp!=NULL) 
	{
		fclose(fp);
		if (IDNO==MessageBox("�ļ��Ѵ���,Ҫ������?","�ļ����ظ�",MB_YESNO))
			return ;
	}

	pDumpWatcher = AfxBeginThread(DumpWatcher,NULL);
}

void CFPDUMPWDlg::OnDumpCancel() 
{
	// TODO: Add your control notification handler code here
	if (!IsWatcherRunning)
		return;
	bCancelWatcher	= TRUE;
//	WaitForSingleObject(pDumpWatcher->m_hThread,INFINITE);
//	pDumpWatcher=NULL;
}

void CFPDUMPWDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	CDialog::OnClose();
}

void CFPDUMPWDlg::OnDumpSettings() 
{
	// TODO: Add your control notification handler code here

	CDialogSettings myDialogSettings;
	myDialogSettings.m_HostAdapterID = HostAdapterID;
	myDialogSettings.m_TargetID		 = TargetID;
	myDialogSettings.m_LUN			 = LUN;

	if (IDOK==myDialogSettings.DoModal())
	{
		HostAdapterID = myDialogSettings.m_HostAdapterID;
		TargetID      = myDialogSettings.m_TargetID;
		LUN			  = myDialogSettings.m_LUN;
	}
}

void CFPDUMPWDlg::OnDumpClose() 
{
	// TODO: Add your control notification handler code here
	EndDialog(0);
}

void CFPDUMPWDlg::OnOK() 
{
	// TODO: Add extra validation here
	return;
//	CDialog::OnOK();
}

void CFPDUMPWDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	if (IsWatcherRunning)
		return;
	CDialog::OnCancel();
}
