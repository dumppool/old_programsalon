// ScsiDataDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ScsiInfoTst.h"
#include "ScsiDataDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScsiDataDlg dialog


CScsiDataDlg::CScsiDataDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CScsiDataDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CScsiDataDlg)
	m_szLun = _T("");
	m_szPathId = _T("");
	m_szPortNumber = _T("");
	m_szTargetId = _T("");
	//}}AFX_DATA_INIT
}


void CScsiDataDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CScsiDataDlg)
	DDX_Text(pDX, IDC_EDIT_LUN, m_szLun);
	DDX_Text(pDX, IDC_EDIT_PATHID, m_szPathId);
	DDX_Text(pDX, IDC_EDIT_PORTNUMBER, m_szPortNumber);
	DDX_Text(pDX, IDC_EDIT_TARGETID, m_szTargetId);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CScsiDataDlg, CDialog)
	//{{AFX_MSG_MAP(CScsiDataDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScsiDataDlg message handlers
