#if !defined(AFX_SCSIDATADLG_H__EF951A73_6E97_11D4_9039_00104B071DA1__INCLUDED_)
#define AFX_SCSIDATADLG_H__EF951A73_6E97_11D4_9039_00104B071DA1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ScsiDataDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CScsiDataDlg dialog

class CScsiDataDlg : public CDialog
{
// Construction
public:
	CScsiDataDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CScsiDataDlg)
	enum { IDD = IDD_DIALOG_SCSIDATA };
	CString	m_szLun;
	CString	m_szPathId;
	CString	m_szPortNumber;
	CString	m_szTargetId;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScsiDataDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CScsiDataDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCSIDATADLG_H__EF951A73_6E97_11D4_9039_00104B071DA1__INCLUDED_)
