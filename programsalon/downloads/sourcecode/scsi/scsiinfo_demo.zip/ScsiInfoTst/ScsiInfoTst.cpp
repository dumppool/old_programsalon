// ScsiInfoTst.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ScsiInfoTst.h"
#include "ScsiInfoTstDlg.h"
#include "..\scsiinfo.h"
#include "ScsiDataDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScsiInfoTstApp

BEGIN_MESSAGE_MAP(CScsiInfoTstApp, CWinApp)
	//{{AFX_MSG_MAP(CScsiInfoTstApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScsiInfoTstApp construction

CScsiInfoTstApp::CScsiInfoTstApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CScsiInfoTstApp object

CScsiInfoTstApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CScsiInfoTstApp initialization

BOOL CScsiInfoTstApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CScsiInfoTstDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

void CScsiInfoTstApp::AppScanDrives()
{
	int PortNumber,PortId,TargetId,Lun;
	CString str;

	ScanDrives();
	for(char c = 'A'; c <= 'Z'; c++)
	{
		if(ERROR_SUCCESS == GetDriveInfo(c,&PortNumber,&PortId,&TargetId,&Lun))
		{
			str.Format("%c: port number %d path id %d target id %d lun %d",
				c,PortNumber,PortId,TargetId,Lun);
		}
		else
		{
			str.Format("%c: failed",c);
		}
		((CScsiInfoTstDlg*)AfxGetMainWnd())->Log(str);
	}
}

void CScsiInfoTstApp::AppGetDriveLetter()
{
	CScsiDataDlg dlg;

	if( IDOK == dlg.DoModal())
	{
		CString str;

		char cDriveLetter = ' ';
		DWORD PathId = atoi(dlg.m_szPathId);
		DWORD PortNumber = atoi(dlg.m_szPortNumber);
		DWORD TargetId = atoi(dlg.m_szTargetId);
		DWORD Lun = atoi(dlg.m_szLun);

		if(ERROR_SUCCESS == GetDriveLetter(&cDriveLetter,PortNumber,PathId,TargetId,Lun))
		{
			str.Format("drive %c port number %d path id %d target id %d lun %d",
				cDriveLetter,PortNumber,PathId,TargetId,Lun);
		}
		else
		{
			str.Format("no drive found for port number %d path id %d target id %d lun %d",
				PortNumber,PathId,TargetId,Lun);
		}
		((CScsiInfoTstDlg*)AfxGetMainWnd())->Log(str);

	}
}
