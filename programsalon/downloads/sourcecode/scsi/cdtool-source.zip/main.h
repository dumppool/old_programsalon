//---------------------------------------------------------------------------
#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include "wnaspi32.h"
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TMainWindow : public TForm
{
__published:	// IDE-managed Components
  TComboBox *CdromsCombo;
  TGroupBox *ReadSpeedGroupBox;
  TLabel *Label22;
  TLabel *Label21;
  TGroupBox *GroupBox2;
  TLabel *Label23;
  TComboBox *PossibleSpeedsCombo;
  TComboBox *SpindownTimesCombo;
  TProgressBar *ProgressBar;
  TLabel *BuildDateLabel;
  TLabel *DebugLabel;
  TEdit *ToleranceEdit;
  TLabel *Label2;
  TButton *AboutButton;
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall FormDestroy(TObject *Sender);
  void __fastcall PossibleSpeedsComboChange(TObject *Sender);
  void __fastcall SpindownTimesComboChange(TObject *Sender);
  void __fastcall CdromsComboChange(TObject *Sender);
  

  
  

  
  
  void __fastcall AboutButtonClick(TObject *Sender);
  void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
  AnsiString __fastcall LookupASPIStatus( BYTE errorcode );
  BYTE __fastcall setCDSpeed( DWORD speed );
  int __fastcall getCDSpeed();
  BYTE __fastcall setCDSpindown( BYTE code );
  BYTE __fastcall getCDSpindown();
  BYTE __fastcall getDriveName( BYTE hostadapter, BYTE target, char* stringbuffer );
  void __fastcall RefreshItems();
  BYTE __fastcall ExecSCSICommand( SRB_ExecSCSICmd* s );
  int __fastcall getMAXCDSpeed();
  int __fastcall LookupKB( int X );
  int __fastcall LookupX( int KB );
  int __fastcall round( float num );
  void __fastcall ModeSenseDump();

  BYTE gbyCurrentTarget;
  BYTE gbyCurrentHostAdapter;
  BYTE gbyHostAdapterCount;

  TList* gDriveInfoList;

public:		// User declarations
  __fastcall TMainWindow(TComponent* Owner);
};
//---------------------------------------------------------------------------
struct DriveInfo {
  BYTE HostAdapter;
  BYTE Target;
  };
//---------------------------------------------------------------------------
extern PACKAGE TMainWindow *MainWindow;
//---------------------------------------------------------------------------
#endif
