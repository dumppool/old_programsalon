//---------------------------------------------------------------------------
#ifndef aboutcodeH
#define aboutcodeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TAboutWindow : public TForm
{
__published:	// IDE-managed Components
  TImage *AboutBitmap;
  TLabel *WWWLabel;
  TLabel *EmailLabel;
  TLabel *DescriptionLabel;
  TButton *LicsenseButton;
  TLabel *WWW2Label;
  void __fastcall WWWLabelClick(TObject *Sender);
  void __fastcall EmailLabelClick(TObject *Sender);
  void __fastcall CloseButtonClick(TObject *Sender);
  void __fastcall LicsenseButtonClick(TObject *Sender);
  void __fastcall WWW2LabelClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall TAboutWindow(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAboutWindow *AboutWindow;
//---------------------------------------------------------------------------
#endif
