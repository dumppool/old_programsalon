/*
CD-ROM Tool - Allows you to set the read speed and spindown time
 time of a CD-ROM drive.
Copyright (C) 1999-2000 Jesse Carroll

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "main.h"
#include "splashcode.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSplashWindow *SplashWindow;
//---------------------------------------------------------------------------
__fastcall TSplashWindow::TSplashWindow(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSplashWindow::FormCreate(TObject *Sender)
{
Width = SplashBitmap->Width;
Height = SplashBitmap->Height;
Left = GetSystemMetrics( SM_CXSCREEN )/2 - Width/2;
Top = GetSystemMetrics( SM_CYSCREEN )/2 - Height/2;
}
//---------------------------------------------------------------------------

void __fastcall TSplashWindow::SplashTimerTimer(TObject *Sender)
{
if( MainWindow->Visible )
  {
  SplashTimer->Enabled = false;
  delete SplashWindow;
  SplashWindow = NULL;
  }
}
//---------------------------------------------------------------------------

