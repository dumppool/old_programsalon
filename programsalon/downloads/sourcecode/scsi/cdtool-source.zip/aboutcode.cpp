/*
CD-ROM Tool - Allows you to set the read speed and spindown time
 time of a CD-ROM drive.
Copyright (C) 1999-2000 Jesse Carroll

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

//---------------------------------------------------------------------------
#include <vcl.h>
#include "registry.hpp"
#include "splashcode.h"
#include "aboutcode.h"
#include "shellapi.h"
#pragma hdrstop
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAboutWindow *AboutWindow;
//---------------------------------------------------------------------------
__fastcall TAboutWindow::TAboutWindow(TComponent* Owner)
  : TForm(Owner)
{
AboutBitmap->Picture = SplashWindow->SplashBitmap->Picture;
AboutBitmap->Width = SplashWindow->SplashBitmap->Width;
AboutBitmap->Height = SplashWindow->SplashBitmap->Height;
AboutBitmap->Left = (WWWLabel->Width + GetSystemMetrics( SM_CXFRAME )*2)/2 - AboutBitmap->Width/2 - GetSystemMetrics( SM_CXFRAME );
Width = WWWLabel->Width + GetSystemMetrics( SM_CXFRAME )*2;
DescriptionLabel->Width = WWWLabel->Width;
DescriptionLabel->Caption =
  "    CD-ROM Tool allows you to set the read speed and spindown time of your CD-ROM drive.  It is free software, and is distributed under the GNU General Public License, which basically says that the program and any modified version of it are free.  On the webpage, you can view usage instructions and download the source code (distrubuted as a C++ Builder project). \r\r\n   Your feedback is vital for the improvement of this program, so please send your comments, suggestions, and debug files to the email address above. \r\r\n   Thank you for using CD-ROM Tool.";
Height = DescriptionLabel->Top + DescriptionLabel->Height + GetSystemMetrics( SM_CYCAPTION ) + GetSystemMetrics( SM_CYFRAME )*2;
//Left = GetSystemMetrics( SM_CXSCREEN )/2 - Width/2;
//Top = GetSystemMetrics( SM_CYSCREEN )/2 - Height/2;
}
//---------------------------------------------------------------------------
void __fastcall TAboutWindow::WWWLabelClick(TObject *Sender)
{
ShellExecute( AboutWindow->Handle, NULL, "http://members.dencity.com/Naiobrin/cdromtool/home.html", NULL, NULL, 0 );
}
//---------------------------------------------------------------------------
void __fastcall TAboutWindow::EmailLabelClick(TObject *Sender)
{
ShellExecute( AboutWindow->Handle, NULL, "mailto:naiobrin@hotmail.com", NULL, NULL, 0 );
}
//---------------------------------------------------------------------------
void __fastcall TAboutWindow::CloseButtonClick(TObject *Sender)
{
ModalResult = mrNone;
}
//---------------------------------------------------------------------------
void __fastcall TAboutWindow::LicsenseButtonClick(TObject *Sender)
{
Application->MessageBox( "CD-ROM Tool\r\nCopyright (C) 1999-2000 Jesse Carroll\r\r\nThis program is free software; you can redistribute it and/or\r\nmodify it under the terms of the GNU General Public License\r\nas published by the Free Software Foundation; either version 2\r\nof the License, or (at your option) any later version.\r\n\r\nThis program is distributed in the hope that it will be useful,\r\nbut WITHOUT ANY WARRANTY; without even the implied warranty of\r\nMERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\r\nGNU General Public License for more details.\r\n\r\nYou should have received a copy of the GNU General Public License\r\nalong with this program; if not, write to the Free Software\r\nFoundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.\r\n", "License Agreement", MB_OK );
}
//---------------------------------------------------------------------------

void __fastcall TAboutWindow::WWW2LabelClick(TObject *Sender)
{
ShellExecute( AboutWindow->Handle, NULL, "http://www.crosswinds.net/~naiobrin/cdromtool/home.html", NULL, NULL, 0 );
}
//---------------------------------------------------------------------------

