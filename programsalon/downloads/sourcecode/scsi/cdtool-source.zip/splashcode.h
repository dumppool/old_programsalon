//---------------------------------------------------------------------------
#ifndef splashcodeH
#define splashcodeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TSplashWindow : public TForm
{
__published:	// IDE-managed Components
  TBevel *Bevel1;
  TImage *SplashBitmap;
  TTimer *SplashTimer;
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall SplashTimerTimer(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall TSplashWindow(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSplashWindow *SplashWindow;
//---------------------------------------------------------------------------
#endif
