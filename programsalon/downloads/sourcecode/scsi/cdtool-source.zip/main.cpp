/*
CD-ROM Tool - Allows you to set the read speed and spindown time
 time of a CD-ROM drive.
Copyright (C) 1999-2000 Jesse Carroll

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


//---------------------------------------------------------------------------
#include <vcl.h>
#include "registry.hpp"
#include "main.h"
#include "aboutcode.h"
#include "splashcode.h"
#include <stdio.h>
#pragma hdrstop

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//-----defines for SCSI commands------------------
#define SCSI_SETSPEED   0xBB
#define SCSI_INQUIRY    0x12
#define SCSI_MODESENSE  0x5A
#define SCSI_MODESELECT 0x55

//-----SCSI device type define------------------
#define DTYPE_CDROM     0x05

#define STATUS_CHKCOND 0x02

//according to the ASPI docs, a host adapter can support up to 16 targets
#define MAX_SCSI_TARGETS 16

//transfer rate in kilobytes of the 1x CD-ROM read speed
#define X1   176

//Causes debug info to be written to c:\\cdromtool.txt if set to true
//In the Main Window's OnCreate event, this is set to true if the
// command line was "-debug" or shift is held when the program is run.
// It is otherwise set to false.
bool LOG;

//the handle for the ASPI32 DLL
HMODULE ASPIDLL;

//used to store the proc addresses of the ASPI DLL functions
DWORD           (*gpfnGetASPI32SupportInfo)( VOID );
DWORD           (*gpfnSendASPI32Command)( LPSRB );

//variable to make the command line globally available
extern AnsiString CommandLineGlobal;

TMainWindow *MainWindow;
//---------------------------------------------------------------------------
__fastcall TMainWindow::TMainWindow(TComponent* Owner)
  : TForm(Owner)
{
}

//-------------------------------------------------------
//simple function that checks to see if a key is pressed
//-------------------------------------------------------
inline bool isKeyDown( int keycode )
  {
  if( (GetAsyncKeyState(keycode) & 0x8000) == 0x8000 )
    return TRUE;
  else
    return FALSE;
  }

//----------------------------------------------------
//simple function that appends text to a log file
//----------------------------------------------------
inline void log(char *string)
  {
  if( LOG )
    {
    FILE *fp=fopen("c:\\cdromtool.txt", "a+");
    fprintf( fp, "%s\n", string);
    fclose( fp );
    }
  }

//----------------------------------------------------------------------------
//Used for debugging, this dumps the entire mode pages 2A & 0D to the log file
//----------------------------------------------------------------------------
void __fastcall TMainWindow::ModeSenseDump()
{
if( LOG )
  {
  SRB_ExecSCSICmd s;
  unsigned char b[256];

  memset( &s, 0, sizeof( s ) );
  memset( b, 0xFF, 256 );

  s.SRB_Cmd      = SC_EXEC_SCSI_CMD;
  s.SRB_HaId     = gbyCurrentHostAdapter;
  s.SRB_Target   = gbyCurrentTarget;
  s.SRB_Lun      = 0;
  s.SRB_Flags    = SRB_DIR_IN | SRB_EVENT_NOTIFY;
  s.SRB_BufLen   = 256;
  s.SRB_BufPointer = b;
  s.SRB_CDBLen   = 12;
  s.CDBByte[0]   = SCSI_MODESENSE;
  s.CDBByte[2]   = 0x2A;
  s.CDBByte[7]   = 0x01;
  s.CDBByte[8]   = 0x00;

  ExecSCSICommand(&s);

  log( "Mode Page 2A Dump" );
  FILE *fp=fopen("c:\\cdromtool.txt", "a+");
  for( int i = 0; i < 256; i++ )
    fprintf( fp, "%c", b[i]);
  fclose( fp );

  memset( &s, 0, sizeof( s ) );
  memset( b, 0xFF, 256 );

  s.SRB_Cmd      = SC_EXEC_SCSI_CMD;
  s.SRB_HaId     = gbyCurrentHostAdapter;
  s.SRB_Target   = gbyCurrentTarget;
  s.SRB_Lun      = 0;
  s.SRB_Flags    = SRB_DIR_IN | SRB_EVENT_NOTIFY;
  s.SRB_BufLen   = 256;
  s.SRB_BufPointer = b;
  s.SRB_CDBLen   = 12;
  s.CDBByte[0]   = SCSI_MODESENSE;
  s.CDBByte[2]   = 0x0D;
  s.CDBByte[7]   = 0x01;
  s.CDBByte[8]   = 0x00;

  ExecSCSICommand(&s);

  log( "Mode Page 0D Dump" );
  fp=fopen("c:\\cdromtool.txt", "a+");
  for( int i = 0; i < 256; i++ )
    fprintf( fp, "%c", b[i]);
  fclose( fp );
  }
}

//---------------------------------------------------------------------------
//Executes SCSI Command specified in the structure "s"
//Returns the final SRB (SCSI request block) status
//---------------------------------------------------------------------------
BYTE __fastcall TMainWindow::ExecSCSICommand( SRB_ExecSCSICmd* s )
{
//use the event method for determining completion
HANDLE heventSRB = CreateEvent( NULL, TRUE, FALSE, NULL );
ResetEvent( heventSRB );
s->SRB_PostProc = (LPVOID)heventSRB;

//issue the command
DWORD dwStatus = gpfnSendASPI32Command( s );

//sendASPI32Command is asynchronous, so if the operation
// is still pending, wait for it to return
if ( dwStatus == SS_PENDING )
  WaitForSingleObject( heventSRB, INFINITE );

CloseHandle( heventSRB );

//return the final SRB status
return s->SRB_Status;
}

//---------------------------------------------------------
//Gets the name of the drive
//Returns the final SRB (SCSI request block) status
//---------------------------------------------------------
BYTE __fastcall TMainWindow::getDriveName( BYTE hostadapter, BYTE target, char* stringbuffer )
{
SRB_ExecSCSICmd s;
BYTE buf[100];

memset( &s, 0, sizeof( s ) );
memset( buf, 0, 100 );

s.SRB_Cmd        = SC_EXEC_SCSI_CMD;
s.SRB_HaId       = hostadapter;
s.SRB_Target     = target;
s.SRB_Lun        = 0;
s.SRB_Flags      = SRB_DIR_IN | SRB_EVENT_NOTIFY;
s.SRB_BufLen     = 100;
s.SRB_BufPointer = buf;
s.SRB_SenseLen   = SENSE_LEN;
s.SRB_CDBLen     = 6;
s.CDBByte[0]     = SCSI_INQUIRY;
s.CDBByte[4]     = 100;

BYTE byStatus = ExecSCSICommand(&s);

if( byStatus != SS_COMP )
  log( ((AnsiString)"getDriveName returned status " +
        LookupASPIStatus(byStatus) +
        (AnsiString)" with HaStat " +
        (AnsiString)s.SRB_HaStat +
        (AnsiString)" TargStat " +
        (AnsiString)s.SRB_TargStat).c_str() );

if( byStatus == SS_ERR && s.SRB_TargStat == STATUS_CHKCOND )
  {
  BYTE SenseKey = s.SenseArea[2] & (BYTE)15;
  BYTE ASC = s.SenseArea[12];
  BYTE ASCQ = s.SenseArea[13];
  log( ((AnsiString)"   Check Condition: Sense Key " +
        (AnsiString)SenseKey +
        (AnsiString)" ASC " +
        (AnsiString)ASC +
        (AnsiString)" ASCQ " +
        (AnsiString)ASCQ).c_str() );
  }

//if the command was successful
if( byStatus == SS_COMP )
  {
  //extract the whole string identifying the drive
  for( int i = 8; i < 36; i++ )
    stringbuffer[i-8] = buf[i];

  //the part I wish to extract is 28 characters long
  stringbuffer[28] = NULL;
  }

return byStatus;
}

//---------------------------------------------------------------------------
//CD Speed Commands
//---------------------------------------------------------------------------
BYTE __fastcall TMainWindow::setCDSpeed( DWORD speed )
{
//if the requested speed is less than 1x speed (176 kb/s),
// this command *will* return an error (it's part of the
// ATAPI specs).  Therefore, stop this function here if
// speed < 1x (176)
if( speed < X1 ) return 0;

SRB_ExecSCSICmd s;
memset( &s, 0, sizeof( s ) );

s.SRB_Cmd      = SC_EXEC_SCSI_CMD;
s.SRB_HaId     = gbyCurrentHostAdapter;
s.SRB_Target   = gbyCurrentTarget;
s.SRB_Lun      = 0;
s.SRB_Flags    = SRB_DIR_OUT | SRB_EVENT_NOTIFY;
s.SRB_SenseLen = SENSE_LEN;
s.SRB_CDBLen   = 12;
s.CDBByte[0]   = SCSI_SETSPEED;

//bytes 2 & 3 represent the desired read speed
s.CDBByte[2]   = (BYTE)(speed >> 8);
s.CDBByte[3]   = (BYTE)speed;

//bytes 4 & 5 represent the desired write speed
//THIS CAUSED ME A LOT OF GRIEF - it seems that with
// some drives, YOU MUST set the write speed to a
// non-zero value, or this call will return with
// an error. This applies even if you don't want to
// change the write speed! For instance, I could get
// away with not setting these bytes when sending
// this command to my old 4x drive, but I *had* to
// put *something* in here when sending the command
// to my Creative CDRW
s.CDBByte[4]   = (BYTE)(706 >> 8);
s.CDBByte[5]   = (BYTE)706;

BYTE byStatus = ExecSCSICommand(&s);

if( byStatus != SS_COMP )
  log( ((AnsiString)"setCDSpeed returned status " +
        LookupASPIStatus(byStatus) +
        (AnsiString)" with HaStat " +
        (AnsiString)s.SRB_HaStat +
        (AnsiString)" TargStat " +
        (AnsiString)s.SRB_TargStat +
        (AnsiString)" attempting " +
        (AnsiString)(unsigned int)speed +
        (AnsiString)" kb/s").c_str() );

if( byStatus == SS_ERR && s.SRB_TargStat == STATUS_CHKCOND )
  {
  BYTE SenseKey = s.SenseArea[2] & (BYTE)15;
  BYTE ASC = s.SenseArea[12];
  BYTE ASCQ = s.SenseArea[13];
  log( ((AnsiString)"   Check Condition: Sense Key " +
        (AnsiString)SenseKey +
        (AnsiString)" ASC " +
        (AnsiString)ASC +
        (AnsiString)" ASCQ " +
        (AnsiString)ASCQ).c_str() );
  }

return byStatus;
}

int __fastcall TMainWindow::getCDSpeed()
{
SRB_ExecSCSICmd s;
unsigned char b[256];

memset( &s, 0, sizeof( s ) );
memset( b, 0xFF, 256 );

s.SRB_Cmd      = SC_EXEC_SCSI_CMD;
s.SRB_HaId     = gbyCurrentHostAdapter;
s.SRB_Target   = gbyCurrentTarget;
s.SRB_Lun      = 0;
s.SRB_Flags    = SRB_DIR_IN | SRB_EVENT_NOTIFY;
s.SRB_BufLen   = 256;
s.SRB_BufPointer = b;
s.SRB_CDBLen   = 12;
s.CDBByte[0]   = SCSI_MODESENSE;
s.CDBByte[2]   = 0x2A;    //mode page 0x2A contains the speed
s.CDBByte[7]   = 0x01;
s.CDBByte[8]   = 0x00;

BYTE byStatus = ExecSCSICommand(&s);

if( byStatus != SS_COMP )
  log( ((AnsiString)"getCDSpeed returned status " +
        LookupASPIStatus(byStatus) +
        (AnsiString)" with HaStat " +
        (AnsiString)s.SRB_HaStat +
        (AnsiString)" TargStat " +
        (AnsiString)s.SRB_TargStat).c_str() );

if( byStatus == SS_ERR && s.SRB_TargStat == STATUS_CHKCOND )
  {
  BYTE SenseKey = s.SenseArea[2] & (BYTE)15;
  BYTE ASC = s.SenseArea[12];
  BYTE ASCQ = s.SenseArea[13];
  log( ((AnsiString)"   Check Condition: Sense Key " +
        (AnsiString)SenseKey +
        (AnsiString)" ASC " +
        (AnsiString)ASC +
        (AnsiString)" ASCQ " +
        (AnsiString)ASCQ).c_str() );
  }

//speed is stored in bytes 22 & 23 of mode page 0x2A
return (int)((b[22] << 8) + b[23]);
}

int __fastcall TMainWindow::getMAXCDSpeed()
{
SRB_ExecSCSICmd s;
unsigned char b[256];

memset( &s, 0, sizeof( s ) );
memset( b, 0xFF, 256 );
s.SRB_Cmd      = SC_EXEC_SCSI_CMD;
s.SRB_HaId     = gbyCurrentHostAdapter;
s.SRB_Target   = gbyCurrentTarget;
s.SRB_Lun      = 0;
s.SRB_Flags    = SRB_DIR_IN | SRB_EVENT_NOTIFY;
s.SRB_BufLen   = 256;
s.SRB_BufPointer = b;
s.SRB_CDBLen   = 12;
s.CDBByte[0]   = SCSI_MODESENSE;
s.CDBByte[2]   = 0x2A;    //mode page 0x2A contains the max speed
s.CDBByte[7]   = 0x01;
s.CDBByte[8]   = 0x00;

BYTE byStatus = ExecSCSICommand(&s);

if( byStatus != SS_COMP )
  log( ((AnsiString)"getMAXCDSpeed returned status " +
        LookupASPIStatus(byStatus) +
        (AnsiString)" with HaStat " +
        (AnsiString)s.SRB_HaStat +
        (AnsiString)" TargStat " +
        (AnsiString)s.SRB_TargStat).c_str() );

if( byStatus == SS_ERR && s.SRB_TargStat == STATUS_CHKCOND )
  {
  BYTE SenseKey = s.SenseArea[2] & (BYTE)15;
  BYTE ASC = s.SenseArea[12];
  BYTE ASCQ = s.SenseArea[13];
  log( ((AnsiString)"   Check Condition: Sense Key " +
        (AnsiString)SenseKey +
        (AnsiString)" ASC " +
        (AnsiString)ASC +
        (AnsiString)" ASCQ " +
        (AnsiString)ASCQ).c_str() );
  }

//bytes 16 & 17 in mode page 0x2A represent the max speed
return (int)((b[16] << 8) + b[17]);
}

//----------------------------------
//Rounds a float to the closest int
//----------------------------------
int __fastcall TMainWindow::round( float num )
{
int roundnum = (int)num;
if( (num - roundnum) >= .5 )
  return roundnum+1;
else
  return roundnum;
}

//----------------------------------------------------
//Given a read speed in kilobytes, this function
// returns an integer saying how fast this is in
// the common CD-ROM convention of [Speed]x
//----------------------------------------------------
int __fastcall TMainWindow::LookupX( int KB )
{
return round((float)KB/(float)176);
}

//----------------------------------------------------
//Given an integer representing "Speed" in the [Speed]x
// CD-ROM transfer rate notation, this function finds
// and returns the read speed of the currently selected
// CD-ROM drive corresponding to that X value
//----------------------------------------------------
int __fastcall TMainWindow::LookupKB( int X )
{
//Here's the thing -- different drives report different
// speeds for the same X rating.  My ASUS34x reports
// 4x speeds to be exactly 176*4 = 704 kb/s, but my Creative
// 4224 reports 4x to be 706 kb/s.  Instead of simply looking
// up the kb/s using multiple of 176, I must scan the "area"
// around the multiple a few kb/s in either direction until
// I hit on one that the drive accepts.  That is the speed
// corresponding to that x for this particular drive.
// Pretty screwy, huh?

//TOLERANCE is the number of kb/s this function scans on either
// side of the multiple of 176
const int TOLERANCE = ToleranceEdit->Text.ToInt();

//since I'll be issuing read speed set commands in order
// to determine which transfer rate the drive accepts, I
// save the speed at which the drive is currently set
int rememberspeed = getCDSpeed();

//test all speeds +/- [TOLERANCE] kb/s from [X rating]*176:
//1) attempt the set the drive's speed
//2) get the drive's speed
//3) if the gotten speed equals the set speed, that's
//     the tranfer rate corresponding to the X rating
//     for this drive
for( int j = 0; j < TOLERANCE*2; j++ )
   {
   setCDSpeed( X1*X - TOLERANCE + j );
   if( getCDSpeed() == X1*X - TOLERANCE+j )
      {
      log( ((AnsiString)"Found speed " +
            (AnsiString)(X1*X - TOLERANCE + j)).c_str() );
      //restore the drive's original speed
      setCDSpeed( rememberspeed );
      return X1*X - TOLERANCE + j;
      }
   }
//restore the drive's original speed
setCDSpeed( rememberspeed );

//if it gets this far, then no corresponding kb/s value was found
// for this drive, and the function returns 0
return 0;
}

//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//CD Spindown Commands
//---------------------------------------------------------------------------
#define SPINDOWN_VENDOR_SPECIFIC 0x00
#define SPINDOWN_125MS 0x01
#define SPINDOWN_250MS 0x02
#define SPINDOWN_500MS 0x03
#define SPINDOWN_1S    0x04
#define SPINDOWN_2S    0x05
#define SPINDOWN_4S    0x06
#define SPINDOWN_8S    0x07
#define SPINDOWN_16S   0x08
#define SPINDOWN_32S   0x09
#define SPINDOWN_1MIN  0x0A
#define SPINDOWN_2MIN  0x0B
#define SPINDOWN_4MIN  0x0C
#define SPINDOWN_8MIN  0x0D
#define SPINDOWN_16MIN 0x0E
#define SPINDOWN_32MIN 0x0F
//----------------------------------------------------
//Given one of the above codes, this function returns
// a string indicating what the corresponding spindown
// time is
//----------------------------------------------------
AnsiString LookupSpindownText( BYTE code )
{
AnsiString returnstring;
switch( code )
  {
  case SPINDOWN_VENDOR_SPECIFIC: returnstring = "VS"; break;
  case SPINDOWN_125MS  : returnstring = "125 ms"; break;
  case SPINDOWN_250MS  : returnstring = "250 ms"; break;
  case SPINDOWN_500MS  : returnstring = "500 ms"; break;
  case SPINDOWN_1S     : returnstring = "1 s";    break;
  case SPINDOWN_2S     : returnstring = "2 s";    break;
  case SPINDOWN_4S     : returnstring = "4 s";    break;
  case SPINDOWN_8S     : returnstring = "8 s";    break;
  case SPINDOWN_16S    : returnstring = "16 s";   break;
  case SPINDOWN_32S    : returnstring = "32 s";   break;
  case SPINDOWN_1MIN   : returnstring = "1 min";  break;
  case SPINDOWN_2MIN   : returnstring = "2 min";  break;
  case SPINDOWN_4MIN   : returnstring = "4 min";  break;
  case SPINDOWN_8MIN   : returnstring = "8 min";  break;
  case SPINDOWN_16MIN  : returnstring = "16 min"; break;
  case SPINDOWN_32MIN  : returnstring = "32 min"; break;
  }
return returnstring;
}

//----------------------------------------------------
//Give one of the strings that the above function
// returns, this returns the above code that
// corresponds to this string
//----------------------------------------------------
BYTE LookupSpindownCode( AnsiString Text )
{
if( Text == "125 ms" ) return SPINDOWN_125MS;
if( Text == "250 ms" ) return SPINDOWN_250MS;
if( Text == "500 ms" ) return SPINDOWN_500MS;
if( Text == "1 s" )    return SPINDOWN_1S;
if( Text == "2 s" )    return SPINDOWN_2S;
if( Text == "4 s" )    return SPINDOWN_4S;
if( Text == "8 s" )    return SPINDOWN_8S;
if( Text == "16 s" )   return SPINDOWN_16S;
if( Text == "32 s" )   return SPINDOWN_32S;
if( Text == "1 min" )  return SPINDOWN_1MIN;
if( Text == "2 min" )  return SPINDOWN_2MIN;
if( Text == "4 min" )  return SPINDOWN_4MIN;
if( Text == "8 min" )  return SPINDOWN_8MIN;
if( Text == "16 min" ) return SPINDOWN_16MIN;
if( Text == "32 min" ) return SPINDOWN_32MIN;
else return 0;
}

//----------------------------------------------------
//Issues a mode sense command to obtain the current
// spindown time of the current drive
//----------------------------------------------------
BYTE __fastcall TMainWindow::getCDSpindown()
{
SRB_ExecSCSICmd s;
unsigned char b[256];

memset( &s, 0, sizeof( s ) );
memset( b, 0xFF, 256 );
s.SRB_Cmd      = SC_EXEC_SCSI_CMD;
s.SRB_HaId     = gbyCurrentHostAdapter;
s.SRB_Target   = gbyCurrentTarget;
s.SRB_Lun      = 0;
s.SRB_Flags    = SRB_DIR_IN | SRB_EVENT_NOTIFY;
s.SRB_BufLen   = 256;
s.SRB_BufPointer = b;
s.SRB_CDBLen   = 12;
s.CDBByte[0]   = SCSI_MODESENSE;
s.CDBByte[2]   = 0x0D;    //spindown timer is on the 0x0D mode page
s.CDBByte[7]   = 0x01;
s.CDBByte[8]   = 0x00;

BYTE byStatus = ExecSCSICommand(&s);

if( byStatus != SS_COMP )
  log( ((AnsiString)"getCDSpindown returned status " +
        LookupASPIStatus(byStatus) +
        (AnsiString)" with HaStat " +
        (AnsiString)s.SRB_HaStat +
        (AnsiString)" TargStat " +
        (AnsiString)s.SRB_TargStat).c_str() );

if( byStatus == SS_ERR && s.SRB_TargStat == STATUS_CHKCOND )
  {
  BYTE SenseKey = s.SenseArea[2] & (BYTE)15;
  BYTE ASC = s.SenseArea[12];
  BYTE ASCQ = s.SenseArea[13];
  log( ((AnsiString)"   Check Condition: Sense Key " +
        (AnsiString)SenseKey +
        (AnsiString)" ASC " +
        (AnsiString)ASC +
        (AnsiString)" ASCQ " +
        (AnsiString)ASCQ).c_str() );
  }

//the byte corresponding to spindown time is 11
return b[11];
}

//----------------------------------------------------
//Issues a mode select command to set the current
// spindown time of the current drive
//----------------------------------------------------
BYTE __fastcall TMainWindow::setCDSpindown( BYTE code )
{
SRB_ExecSCSICmd s;

memset( &s, 0, sizeof( s ) );

unsigned char b[16];
memset( &b, 0, 16 );

b[8] = 0x0D;  //I'm doing a mode select on page 0x0D
b[9] = 0x06;  //The length of this page is 0x06
b[11]= code;  //The code representing spindown time goes here
b[13]= 0x3C;  //other defaults that have nothing
b[15]= 0x4B;  // to do with the spindown time

s.SRB_Cmd      = SC_EXEC_SCSI_CMD;
s.SRB_HaId     = gbyCurrentHostAdapter;
s.SRB_Target   = gbyCurrentTarget;
s.SRB_Lun      = 0;
s.SRB_Flags    = SRB_DIR_OUT | SRB_EVENT_NOTIFY;
s.SRB_SenseLen = SENSE_LEN;
s.SRB_BufPointer = b;
s.SRB_BufLen   = 16;
s.SRB_CDBLen   = 12;
s.CDBByte[0]   = SCSI_MODESELECT;
s.CDBByte[1]   = 0x10;              //a default from the ATAPI specs
s.CDBByte[8]   = (BYTE)16;

BYTE byStatus = ExecSCSICommand(&s);

if( byStatus != SS_COMP )
  log( ((AnsiString)"setCDSpindown returned status " +
        LookupASPIStatus(byStatus) +
        (AnsiString)" with HaStat " +
        (AnsiString)s.SRB_HaStat +
        (AnsiString)" TargStat " +
        (AnsiString)s.SRB_TargStat).c_str() );

if( byStatus == SS_ERR && s.SRB_TargStat == STATUS_CHKCOND )
  {
  BYTE SenseKey = s.SenseArea[2] & (BYTE)15;
  BYTE ASC = s.SenseArea[12];
  BYTE ASCQ = s.SenseArea[13];
  log( ((AnsiString)"   Check Condition: Sense Key " +
        (AnsiString)SenseKey +
        (AnsiString)" ASC " +
        (AnsiString)ASC +
        (AnsiString)" ASCQ " +
        (AnsiString)ASCQ).c_str() );
  }

return byStatus;
}

//---------------------------------------------------------------------------
//Translates ASPI status codes into meaningful text
//---------------------------------------------------------------------------
AnsiString __fastcall TMainWindow::LookupASPIStatus( BYTE code )
{
switch( code )
  {
  case SS_ILLEGAL_MODE:
     return (AnsiString)"SS_ILLEGAL_MODE";
  case SS_NO_ASPI:
     return (AnsiString)"SS_NO_ASPI";
  case SS_MISMATCHED_COMPONENTS:
     return (AnsiString)"SS_MISMATCHED_COMPONENTS";
  case SS_INSUFFICIENT_RESOURCES:
     return (AnsiString)"SS_INSUFFICIENT_RESOURCES";
  case SS_FAILED_INIT:
     return (AnsiString)"SS_FAILED_INIT";
  case SS_NO_ADAPTERS:
     return (AnsiString)"SS_NO_ADAPTERS";
  case SS_COMP:
     return (AnsiString)"SS_COMP";
  case SS_INVALID_HA:
     return (AnsiString)"SS_INVALID_HA";
  case SS_NO_DEVICE:
     return (AnsiString)"SS_NO_DEVICE";
  case SS_ERR:
     return (AnsiString)"SS_ERR";

  default:
     char buffer[50];
     sprintf( buffer, "Unknown Status Code: 0x%X", code );
     return (AnsiString)buffer;
  }
}
//---------------------------------------------------------------------------


void __fastcall TMainWindow::FormCreate(TObject *Sender)
{
//if "-debug" was specified in the command line, or shift was
// held down as the program was run, turn on logging and indicate
// debug mode by changing the label at the bottom of the form
if( !strcmp(CommandLineGlobal.c_str(), "-debug") || isKeyDown( VK_SHIFT ) )
  {
  LOG = true;
  DebugLabel->Caption = "DEBUG";
  }
else
  LOG = false;

log( "-----------" );

char buffer[50];
DWORD dwStatus;

//Load the Win32 ASPI DLL
ASPIDLL = LoadLibrary("wnaspi32.dll");

//if there was an error loading the DLL, bail out
if( ASPIDLL == NULL )
  {
  Application->MessageBox( "Couldn't load wnaspi32.dll; make sure ASPI is properly installed", "Error - Must Quit", MB_OK );
  log( "ERROR - wnaspi32.dll failed to load" );
  Application->Terminate();
  }
else log( "Loaded wnaspi32.dll OK" );

//Get the addresses of the two DLL functions I'll be using
(FARPROC)gpfnGetASPI32SupportInfo = GetProcAddress( ASPIDLL, "GetASPI32SupportInfo" );
if( gpfnGetASPI32SupportInfo == NULL )
  {
  Application->MessageBox( "Couldn't get proc address of GetASPI32SupportInfo", "Error - Must Quit", MB_OK );
  log( "ERROR - Couldn't get proc address of GetASPI32SupportInfo" );
  Application->Terminate();
  }
else log( "Got GetASPI32SupportInfo proc address OK" );

(FARPROC)gpfnSendASPI32Command = GetProcAddress( ASPIDLL, "SendASPI32Command" );
if( gpfnSendASPI32Command == NULL )
  {
  Application->MessageBox( "Couldn't get proc address of SendASPI32Command", "Error - Must Quit", MB_OK );
  log( "ERROR - Couldn't get proc address of SendASPI32Command" );
  Application->Terminate();
  }
else log( "Got SendASPI32Command proc address OK" );

//Figure out how many host adapters are in the machine:
//Call gpfnGetASPI32SupportInfo(), which returns a DWORD.
// -The high byte of the low word shall be filled with
//  an ASPI status code.
// -If this code is SS_COMP, at least one host adapter was
//  found, and the number of host adapters is stored in
//  the low byte of the low word.
// -If this code is SS_NO_ADAPTERS, no host adapters were found
// -If this code is anything else, the function has failed and
//  this is an error code
DWORD dwSupportInfo;
dwSupportInfo = gpfnGetASPI32SupportInfo();
BYTE byASPIStatus = HIBYTE(LOWORD(dwSupportInfo));
if( SS_COMP == byASPIStatus )
  {
  gbyHostAdapterCount = LOBYTE(LOWORD(dwSupportInfo));

  sprintf( buffer, "Found %d Host Adapter(s)", gbyHostAdapterCount );
  log( buffer );
  }
else if( SS_NO_ADAPTERS == byASPIStatus )
  {
  Application->MessageBox( "ASPI reported 0 host adapters", "Error - Must Quit", MB_OK );
  log( "ERROR - ASPI reported 0 host adapters" );
  Application->Terminate();
  }
else
  {
  Application->MessageBox( ((AnsiString)"Error calling GetASPI32SupportInfo: " + LookupASPIStatus(byASPIStatus)).c_str(), "Error - Must Quit", MB_OK );
  log( ((AnsiString)"Error calling GetASPI32SupportInfo: " + LookupASPIStatus(byASPIStatus)).c_str() );
  Application->Terminate();
  }

//Figure out how many CD drives are in the system:
//-Add the name of each drive found to the CdromsCombo control
//-Add the host adapter and target number of each drive
// to the gDriveInfoList
gDriveInfoList = new TList;
SRB_GDEVBlock srbGDEVBlock;
for( BYTE j = 0; j < gbyHostAdapterCount; j++ )
  {
  for( BYTE i = 0; i < MAX_SCSI_TARGETS; i++ )
    {
    memset( &srbGDEVBlock, 0, sizeof(SRB_GDEVBlock) );
    srbGDEVBlock.SRB_Cmd = SC_GET_DEV_TYPE;
    srbGDEVBlock.SRB_Target = i;
    srbGDEVBlock.SRB_HaId = j;
    gpfnSendASPI32Command( (LPSRB)&srbGDEVBlock );

    //if the i'th target on the j'th host adapter is a CD-Rom . . .
    if( srbGDEVBlock.SRB_DeviceType == DTYPE_CDROM )
       {
       //if this is the first CD-Rom found . . .
       if( CdromsCombo->Items->Count == 0 )
           {
           //make this HA and CD drive the current settings
           gbyCurrentHostAdapter = j;
           gbyCurrentTarget = i;
           }
       //add its descriptive string to the combo
       char buffer[50];
       dwStatus = getDriveName( j, i, buffer );

       //display a warning if there was a problem getting the drive name
       if( dwStatus != SS_COMP)
         {
         if( IDCANCEL == Application->MessageBox( ((AnsiString)("getDriveName returned " + LookupASPIStatus( (BYTE)dwStatus )) + (AnsiString)"\r\n\nYou may try to continue by pressing OK, or\r\nTerminate the program with CANCEL").c_str(), "Error", MB_OKCANCEL ) )
           Application->Terminate();
         }

       log( ((AnsiString)"Found CD-ROM " +
             (AnsiString)buffer +
             (AnsiString)": HA " +
             (AnsiString)j +
             (AnsiString)" Target " +
             (AnsiString)i ).c_str() );

       CdromsCombo->Items->Add( buffer );

       //add its HA and target number to the gDriveInfoList
       DriveInfo* DI = new DriveInfo;
       DI->HostAdapter = j;
       DI->Target = i;
       gDriveInfoList->Add( DI );
       }
    }
  }

//if no CD-ROM drives were found, bail out
if( CdromsCombo->Items->Count == 0 )
  {
  Application->MessageBox( "No CD-ROM drives found by ASPI", "Error - Must Quit", MB_OK );
  log( "ERROR - No CD-ROM drives found by ASPI" );
  Application->Terminate();
  }

//make the first drive in the combo be the one initially displayed
CdromsCombo->ItemIndex = 0;

//fill up the spindown times combo with all
// standard spindown times
SpindownTimesCombo->Items->Add("125 ms");
SpindownTimesCombo->Items->Add("250 ms");
SpindownTimesCombo->Items->Add("500 ms");
SpindownTimesCombo->Items->Add("1 s");
SpindownTimesCombo->Items->Add("2 s");
SpindownTimesCombo->Items->Add("4 s");
SpindownTimesCombo->Items->Add("8 s");
SpindownTimesCombo->Items->Add("16 s");
SpindownTimesCombo->Items->Add("32 s");
SpindownTimesCombo->Items->Add("1 min");
SpindownTimesCombo->Items->Add("2 min");
SpindownTimesCombo->Items->Add("4 min");
SpindownTimesCombo->Items->Add("8 min");
SpindownTimesCombo->Items->Add("16 min");
SpindownTimesCombo->Items->Add("32 min");

//make it so that all spindown times are visible at once
// when the combo box is dropped down
SpindownTimesCombo->DropDownCount = SpindownTimesCombo->Items->Count;

TRegistry* reg = new TRegistry;
//if the CD-ROM Tool registry key exists
if( reg->KeyExists( "\\Software\\Naiobrin Software\\CD-ROM Tool" ) )
  {
  //open the CD-ROM Tool registry key
  reg->OpenKey( "\\Software\\Naiobrin Software\\CD-ROM Tool", false );
  //read the tolerance
  ToleranceEdit->Text = (AnsiString)reg->ReadInteger( "Tolerance" );
  }
delete reg;

//update the speed & timeout reading as well as the speed
// choices to reflect the selected drive's current settings and
// capabilities
RefreshItems();
}
//---------------------------------------------------------------------------

void __fastcall TMainWindow::FormDestroy(TObject *Sender)
{
TRegistry* reg = new TRegistry;
//create or open the CD-ROM Tool registry key
reg->OpenKey( "\\Software\\Naiobrin Software\\CD-ROM Tool", true );
//write the tolerance
reg->WriteInteger( "Tolerance", ToleranceEdit->Text.ToInt() );
delete reg;

//Free memory allocated by gDriveInfoList and its elements
for( int i = 0; i < gDriveInfoList->Count; i++ )
  delete gDriveInfoList->Items[i];
delete gDriveInfoList;

//Clean up after DLL
if( FreeLibrary( ASPIDLL ) != 0 )
  log( "Freed wnaspi32.dll OK" );
else log( "Error freeing wnaspi32.dll" );
}
//---------------------------------------------------------------------------


void __fastcall TMainWindow::RefreshItems()
{
ModeSenseDump();

log( ((AnsiString)"RefreshItems feedback for HA " +
     (AnsiString)gbyCurrentHostAdapter +
     (AnsiString)" Target " +
     (AnsiString)gbyCurrentTarget).c_str() );

//find maximum and current speed, set the labels accordingly
Label22->Caption = "Maximum Speed: " + (AnsiString)LookupX( getMAXCDSpeed() ) + (AnsiString)"x";
log( ((AnsiString)"Maximum Speed: " +
      (AnsiString)getMAXCDSpeed()).c_str() );
Label21->Caption = "Current Speed: " + (AnsiString)LookupX( getCDSpeed() ) + (AnsiString)"x";
log( ((AnsiString)"Current Speed: " +
      (AnsiString)getCDSpeed()).c_str() );

//find the current spindown time, set the label accordingly
Label23->Caption = "Current Time: " + LookupSpindownText( getCDSpindown() );
log( Label23->Caption.c_str() );

//if current time was set to VS, indicate in the popup hint that this means Vendor Specific
Label23->ShowHint = false;
if( Label23->Caption == "Current Time: VS" )
  Label23->ShowHint = true;

//clear the possible speed settings pulldown box
PossibleSpeedsCombo->Clear();

//set up the progress bar (this'll show progress made in determining
// the possible read speeds of the drive)
ProgressBar->Min = 0;
ProgressBar->Max = LookupX(getMAXCDSpeed());

//If LookupKB([some X rating]) returns a positive integer, then
// it was able to find a transfer rate in Kilobytes corresponding
// to that X rating for this particular drive.  Thus, I can
// determine which X speeds are supported by this drive by testing
// LookupKB with each X value between 1x and [MAX]x.
int MAX_X = LookupX(getMAXCDSpeed());
for( int i = 1; i <= MAX_X; i++ )
  {
  log( ((AnsiString)"Trying " +
        (AnsiString)i +
        (AnsiString)"x").c_str() );

  if( LookupKB(i) > 0 )
     PossibleSpeedsCombo->Items->Add( (AnsiString)i + "x" );
  ProgressBar->Position++;
  }

//if none of the tests was successful, I can assume that either the
// tolerance value is set too low (see LookupKB) or, more likely, the drive's speed
// is locked.  In any case, put a dash item in the combo box to
// indicate this.
if( PossibleSpeedsCombo->Items->Count == 0 )
  PossibleSpeedsCombo->Items->Add( "-" );

log( (PossibleSpeedsCombo->Items->CommaText +
      (AnsiString)" were found to be possible speeds").c_str() );

//reset the progress bar to zero
ProgressBar->Position = 0;

//set the combo box containing the possible speeds to show
// the drive's current speed
for( int i = 0; i < PossibleSpeedsCombo->Items->Count; i++ )
  if( PossibleSpeedsCombo->Items->Strings[i] == (AnsiString)LookupX(getCDSpeed())+(AnsiString)"x" )
     PossibleSpeedsCombo->ItemIndex = i;

//set the combo box containing spindown times to show
// the drive's current spindown time
for( int i = 0; i < SpindownTimesCombo->Items->Count; i++ )
  if( SpindownTimesCombo->Items->Strings[i] == LookupSpindownText(getCDSpindown()) )
     SpindownTimesCombo->ItemIndex = i;
}

void __fastcall TMainWindow::PossibleSpeedsComboChange(TObject *Sender)
{
//extract the integer value from the combo box item
// selected(which has the form "[integer]x"):
//1)put the selected combo box item in an AnsiString variable
//2)trim off the last character
//
//This leaves me with an AnsiString containing an integer value
AnsiString SelectedItem = PossibleSpeedsCombo->Items->Strings[ PossibleSpeedsCombo->ItemIndex ];
SelectedItem = SelectedItem.SubString( 1, SelectedItem.Length()-1 );

//set new speed for the current drive
setCDSpeed( LookupKB(SelectedItem.ToInt()) );

//update the current speed text
Label21->Caption = "Current Speed: " + (AnsiString)LookupX( getCDSpeed() ) + (AnsiString)"x";
}
//---------------------------------------------------------------------------

void __fastcall TMainWindow::SpindownTimesComboChange(TObject *Sender)
{
//set new spindown time for the current drive
setCDSpindown( LookupSpindownCode(SpindownTimesCombo->Items->Strings[ SpindownTimesCombo->ItemIndex ]) );

//update the current time text
Label23->Caption = "Current Time: " + LookupSpindownText( getCDSpindown() );
}
//---------------------------------------------------------------------------

void __fastcall TMainWindow::CdromsComboChange(TObject *Sender)
{
//set current host adapter & target to reflect the
// drive that was selected in the CdromsCombo
gbyCurrentHostAdapter = ((DriveInfo*)(gDriveInfoList->Items[CdromsCombo->ItemIndex]))->HostAdapter;
gbyCurrentTarget = ((DriveInfo*)(gDriveInfoList->Items[CdromsCombo->ItemIndex]))->Target;

//update the speed & timeout reading as well as the speed
// choices to reflect the selected drive's current settings and
// capabilities
RefreshItems();
}
//---------------------------------------------------------------------------








void __fastcall TMainWindow::AboutButtonClick(TObject *Sender)
{
AboutWindow->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainWindow::Button1Click(TObject *Sender)
{
setCDSpeed( 0 );
}
//---------------------------------------------------------------------------

