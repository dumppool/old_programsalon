/* @(#)saveargs.h	1.2 99/12/19 Copyright 1998,1999 Heiko Eissfeldt */
void save_args __PR(( int ac, char *av[] ));
