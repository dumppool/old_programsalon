// ReaderDoc.h : interface of the CReaderDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_READERDOC_H__6CC1C044_F317_11D2_8D5B_FFC4C908DB0E__INCLUDED_)
#define AFX_READERDOC_H__6CC1C044_F317_11D2_8D5B_FFC4C908DB0E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "StringEx.h"
#include "ChildFrm.h"
class CReaderDoc : public CDocument
{
protected: // create from serialization only
	CReaderDoc();
	DECLARE_DYNCREATE(CReaderDoc)

// Attributes
private:
	long m_lineNumber;
	BOOL bBigToGB;
public:
	CStringEx m_text;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReaderDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual void DeleteContents();
	virtual void SetModifiedFlag(BOOL);
	//}}AFX_VIRTUAL

// Implementation
public:
	CStringArray strLine;
	long GetLineNumber();
	long CalLineNumber();
	int GetTextLength();
	CString GetText();
	CString Range(long start,long end);
	virtual ~CReaderDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CReaderDoc)
	afx_msg void OnBigtoGB();
	afx_msg void OnGbtobig();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CReaderDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_READERDOC_H__6CC1C044_F317_11D2_8D5B_FFC4C908DB0E__INCLUDED_)
