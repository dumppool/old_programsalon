// EditString.cpp: implementation of the CEditString class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Reader.h"
#include "EditString.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEditString::CEditString()
{

}

CEditString::~CEditString()
{

}
