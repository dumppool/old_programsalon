//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Reader.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_READERTYPE                  129
#define IDR_TXTTYPE                     130
#define IDR_WRITYPE                     131
#define IDR_WPSTYPE                     132
#define IDB_BACK                        138
#define ID_SHOWTEXT                     32771
#define ID_BIGTOGB                      32773
#define ID_DEBUG                        32779
#define ID_GBTOBIG                      32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
