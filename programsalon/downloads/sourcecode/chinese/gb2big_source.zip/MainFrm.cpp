// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Reader.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
const UINT WM_PAINTMYCAPTION = WM_USER+5;

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_WM_NCHITTEST()
	//}}AFX_MSG_MAP
	// Global help commands
	ON_MESSAGE(WM_PAINTMYCAPTION,OnPaintMyCaption)
	ON_COMMAND(ID_HELP_FINDER, CMDIFrameWnd::OnHelpFinder)
	ON_COMMAND(ID_HELP, CMDIFrameWnd::OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, CMDIFrameWnd::OnContextHelp)
	ON_COMMAND(ID_DEFAULT_HELP, CMDIFrameWnd::OnHelpFinder)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	m_capp.Install(this,WM_PAINTMYCAPTION,TRUE);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	CWinApp* app = AfxGetApp();
    int s, t, b, r, l;

    // only restore if there is a previously saved position
    if ( -1 != (s = app->GetProfileInt("WinPos", "Status",   -1)) &&
         -1 != (t = app->GetProfileInt("WinPos", "Top",      -1)) &&
         -1 != (l = app->GetProfileInt("WinPos", "Left",     -1)) &&
         -1 != (b = app->GetProfileInt("WinPos", "Bottom",   -1)) &&
         -1 != (r = app->GetProfileInt("WinPos", "Right",    -1))
       ) {

        // restore the window's status
        app->m_nCmdShow = s;

        // restore the window's width and height
        cs.cx = r - l;
        cs.cy = b - t;

        // the following correction is needed when the taskbar is
        // at the left or top and it is not "auto-hidden"
        RECT workArea;
        SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0);
        l += workArea.left;
        t += workArea.top;

        // make sure the window is not completely out of sight
        int max_x = GetSystemMetrics(SM_CXSCREEN) -
                        GetSystemMetrics(SM_CXICON);
        int max_y = GetSystemMetrics(SM_CYSCREEN) -
                        GetSystemMetrics(SM_CYICON);
        cs.x = min(l, max_x);
        cs.y = min(t, max_y);
    }
	return CMDIFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers



void CMainFrame::OnClose() 
{
    // Save main window position
    CWinApp* app = AfxGetApp();
    WINDOWPLACEMENT wp;
    GetWindowPlacement(&wp);
    app->WriteProfileInt("WinPos", "Status", wp.showCmd);
    app->WriteProfileInt("WinPos", "Top",    wp.rcNormalPosition.top);
    app->WriteProfileInt("WinPos", "Left",   wp.rcNormalPosition.left);
    app->WriteProfileInt("WinPos", "Bottom", wp.rcNormalPosition.bottom);
    app->WriteProfileInt("WinPos", "Right",  wp.rcNormalPosition.right);
	CMDIFrameWnd::OnClose();
}
void CMainFrame::OnUpdateFrameTitle(BOOL bAddToTitle)
{
	m_capp.UpdateFrameTitle(m_hWnd,m_strTitle);
}

LRESULT CMainFrame::OnPaintMyCaption(WPARAM bActive, LPARAM lParam)
{
m_capp.PaintMyCaption(bActive,lParam,m_strTitle);
	return 0;
}

void CMainFrame::RedrawCaption()
{
  m_capp.Invalidate();
  m_capp.PaintCaption();
}

UINT CMainFrame::OnNcHitTest(CPoint point) 
{
	RedrawCaption();
	return CMDIFrameWnd::OnNcHitTest(point);
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	if (CMDIFrameWnd::OnCreateClient(lpcs, pContext))
	{
		m_wndMdiClient.SubclassWindow(m_hWndMDIClient);
		m_wndMdiClient.SetBitmap(IDB_BACK);
		return TRUE;
	}
	else
		return FALSE;
}
