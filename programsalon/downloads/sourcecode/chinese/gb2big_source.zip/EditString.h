// EditString.h: interface for the CEditString class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDITSTRING_H__6CC1C06A_F317_11D2_8D5B_FFC4C908DB0E__INCLUDED_)
#define AFX_EDITSTRING_H__6CC1C06A_F317_11D2_8D5B_FFC4C908DB0E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <afxtempl.h>
#include <ctype.h>
#include "StringEx.h"

class CEditString : public CStringEx 
{
public:
	CEditString();
	virtual ~CEditString();

};

#endif // !defined(AFX_EDITSTRING_H__6CC1C06A_F317_11D2_8D5B_FFC4C908DB0E__INCLUDED_)
