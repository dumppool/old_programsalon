// ReaderDoc.cpp : implementation of the CReaderDoc class
//

#include "stdafx.h"
#include "Reader.h"
#include "MainFrm.h"
#include "ReaderDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReaderDoc

IMPLEMENT_DYNCREATE(CReaderDoc, CDocument)

BEGIN_MESSAGE_MAP(CReaderDoc, CDocument)
	//{{AFX_MSG_MAP(CReaderDoc)
	ON_COMMAND(ID_BIGTOGB, OnBigtoGB)
	ON_COMMAND(ID_GBTOBIG, OnGbtobig)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CReaderDoc, CDocument)
	//{{AFX_DISPATCH_MAP(CReaderDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//      DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IReader to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {6CC1C038-F317-11D2-8D5B-FFC4C908DB0E}
static const IID IID_IReader =
{ 0x6cc1c038, 0xf317, 0x11d2, { 0x8d, 0x5b, 0xff, 0xc4, 0xc9, 0x8, 0xdb, 0xe } };

BEGIN_INTERFACE_MAP(CReaderDoc, CDocument)
	INTERFACE_PART(CReaderDoc, IID_IReader, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReaderDoc construction/destruction

CReaderDoc::CReaderDoc()
{
	EnableAutomation();
	AfxOleLockApp();
	bBigToGB=TRUE;
	strLine.SetSize(0);
	m_lineNumber=CalLineNumber();
}

CReaderDoc::~CReaderDoc()
{
	AfxOleUnlockApp();
}

BOOL CReaderDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	m_text="\n";
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CReaderDoc serialization

void CReaderDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_text;
	}
	else
	{
		ar >> m_text;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CReaderDoc diagnostics

#ifdef _DEBUG
void CReaderDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CReaderDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CReaderDoc commands

BOOL CReaderDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	TCHAR	buffer[0xff]="\0";
	CStdioFile	file(lpszPathName, CFile::modeRead|CFile::typeBinary);
	DWORD	count = 0;
	DWORD	Length = file.GetLength();
	do 
	{	memset(buffer,'\0',sizeof(buffer));
		count=file.Read(buffer, sizeof(buffer)-1);
		m_text += buffer;
	}
	while (count == sizeof(buffer)-1);

	m_text+="\n";
	DWORD tmp=m_text.GetLength();
	m_lineNumber=CalLineNumber();

	return TRUE;
}

BOOL CReaderDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	try {
			CStdioFile	file(lpszPathName, CFile::modeCreate | CFile::modeWrite | CFile::typeBinary);
			m_text="";
			for(long i=0;i<m_lineNumber;i++)
			{
				m_text+=strLine[i];
				m_text+='\n';
			}
			file.WriteHuge(m_text, m_text.GetLength());
		} 
	catch (...)
		{
			return FALSE;
		}

	return TRUE;
}

void CReaderDoc::DeleteContents() 
{
	m_text=_T("");
}

CString CReaderDoc::Range(long start, long end)
{
	return m_text.Mid(start,end-start);
}



CString CReaderDoc::GetText()
{
	return m_text;
}

int CReaderDoc::GetTextLength()
{
	return m_text.GetLength();
}

long CReaderDoc::CalLineNumber()
{
	strLine.SetSize(0);
	CString strTemp;
	BOOL bReturn=FALSE;
	if(!GetTextLength())
		return 0;
	long line_num=0;
	int index=0;
	do
	{
		TCHAR c=m_text.GetAt(index++);
		if(c=='\t')
			strTemp+="        ";
		else if(c!='\n')
			strTemp+=c;
		else
		{	
			bReturn=TRUE;
			line_num++;;
			strLine.Add(strTemp.Left(strTemp.GetLength()-1));
			strTemp="\0";
		}
	}
	while(index<GetTextLength());
	if(!bReturn)
		strLine.Add(strTemp);

	return strLine.GetSize();
}

long CReaderDoc::GetLineNumber()
{
	return m_lineNumber;
}

void CReaderDoc::OnBigtoGB() 
{
	CalLineNumber();
	LPWORD pBIGTable=((CReaderApp*)AfxGetApp())->GetBigTable();
	if(m_text=="\n")
		return;
	for(int Line=0;Line<GetLineNumber();Line++)
	{
		BYTE* SourceSTR;
		SourceSTR=(BYTE* )((LPCTSTR)strLine[Line]);
		int size=strLine[Line].GetLength();
		if(size)
		{	
			BYTE* DestSTR=new BYTE[size+1];
			unsigned i=0;
			do
			{
				// is English ��Ӣ���ַ�
				if(SourceSTR[i]<0xA1||(SourceSTR[i+1]<0x40)) 
				{
					DestSTR[i]=SourceSTR[i];
					i++;
				}
				else //��BIG5�ĺ�����
				{
					DestSTR[i+1]=HIBYTE(pBIGTable[(SourceSTR[i]-0xA1)*0xBF+SourceSTR[i+1]-0x40]);
					DestSTR[i]=LOBYTE(pBIGTable[(SourceSTR[i]-0xA1)*0xBF+SourceSTR[i+1]-0x40]);
					i+=2;
				}
			}
			while(i<strlen((char*)(SourceSTR)));
			DestSTR[i]='\0';

			strLine[Line]=DestSTR;
			delete DestSTR;
		}
	}
	UpdateAllViews(NULL);
}





void CReaderDoc::OnGbtobig() 
{
	CalLineNumber();
	LPWORD pGBTable=((CReaderApp*)AfxGetApp())->GetGBTable();
	if(m_text=="\n")
		return;
	for(int Line=0;Line<GetLineNumber();Line++)
	{
		BYTE* SourceSTR;
		SourceSTR=(BYTE* )((LPCTSTR)strLine[Line]);
		int size=strLine[Line].GetLength();
		if(size)
		{	
			BYTE* DestSTR=new BYTE[size+1];
			unsigned i=0;
			do
			{
				// is English ��Ӣ���ַ�
				if(SourceSTR[i]<0xA1||(SourceSTR[i+1]<0xA1)) 
				{
					DestSTR[i]=SourceSTR[i];
					i++;
				}
				else if(SourceSTR[i]>0xA1&&SourceSTR[i]<0xB0) //��GB2312�ĺ�����
				{
					DestSTR[i+1]=HIBYTE(pGBTable[(SourceSTR[i]-0xA1)*0x5E+SourceSTR[i+1]-0xA1]);
					DestSTR[i]=LOBYTE(pGBTable[(SourceSTR[i]-0xA1)*0x5E+SourceSTR[i+1]-0xA1]);
					i+=2;
				}
				else
				{
					DestSTR[i+1]=HIBYTE(pGBTable[(SourceSTR[i]-0xA7)*0x5E+SourceSTR[i+1]-0xA1]);
					DestSTR[i]=LOBYTE(pGBTable[(SourceSTR[i]-0xA7)*0x5E+SourceSTR[i+1]-0xA1]);
					i+=2;
				}
			}
			while(i<strlen((char*)(SourceSTR)));
			DestSTR[i]='\0';

			strLine[Line]=DestSTR;
			delete DestSTR;
		}
	}
	UpdateAllViews(NULL);
}

void CReaderDoc::SetModifiedFlag(BOOL flag)
{
	CDocument::SetModifiedFlag(flag);
	((CMainFrame *)AfxGetMainWnd())->RedrawCaption();
	  POSITION pos = GetFirstViewPosition();
	  CView *pView;
	  CChildFrame *pChild;
	  while(pos!=NULL)
	  {
		pView = GetNextView(pos);
		if(pView)
		{
		  pChild = (CChildFrame *)pView->GetParent();
		  if(pChild)pChild->OnUpdateFrameTitle(TRUE);
		}
	  }  
}
