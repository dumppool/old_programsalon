-----------------------------------
  Luffar schack 0.99 Beta
  A Make-5 game for DOS
  Inc. Source code (C++)

  Copyright (c) 1998
  Ministars Software
  By Yuheng Zhao
-----------------------------------

I wrote this simple game as a school
project when I studied in the 2ed grade
in high school. Not very good "AI", but 
it works. The game is developed in Turbo
C++ 1.0, and contains some assembler 
code to handle the mouse functions.

Please don't blame me if you can't 
understand the code. Since I couldn't 
the theory for the artificial 
intelligence, I did it in the hard 
way. The algorithm is based on lots of
if () else () statements. That makes it
extremely hard to understand, and for me
to debug. Not very much comments have 
been written, and a combined language
based on English, Swedish and Chinese
is used. I believe that not many people
will understand my comments. :-)


Enjoy the game (or the code)!


-----------------------------------
Yuheng Zhao

Game Created: 1997-5-17
Document Updated: 1998-9-14
E-mail: yuheng@ministars.com
Web: http://www.ministars.com
