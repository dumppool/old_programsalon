//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BoxMan.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_BOXMANTYPE                  129
#define IDB_MAP                         130
#define IDD_DIALOG1                     131
#define IDC_EDIT1                       1004
#define IDC_BUTTON_MORE                 1008
#define IDC_STATIC_MAIL                 1009
#define ID_SELECTMAP                    32772
#define ID_SHOW_MOVE_WAY                32773
#define ID_PROMPT                       32775
#define ID_PRIOR_MAP                    32778
#define ID_NEXT_MAP                     32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
