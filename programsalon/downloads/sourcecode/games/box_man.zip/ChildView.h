// ChildView.h : interface of the CChildView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDVIEW_H__A8DB606B_6EBD_11D3_9C7F_9D98C5BF25E9__INCLUDED_)
#define AFX_CHILDVIEW_H__A8DB606B_6EBD_11D3_9C7F_9D98C5BF25E9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CChildView window

class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildView)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	void ReSetFrame();
	void BeginThinkThread();
	void SetStatusBar();
	void SelectMap( bool next );
	void Created();
	virtual ~CChildView();

	// Generated message map functions
protected:
	//{{AFX_MSG(CChildView)
	afx_msg void OnPaint();
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSelectmap();
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateEditUndo(CCmdUI* pCmdUI);
	afx_msg void OnShowMoveWay();
	afx_msg void OnUpdateShowMoveWay(CCmdUI* pCmdUI);
	afx_msg void OnUpdatePrompt(CCmdUI* pCmdUI);
	afx_msg void OnPrompt();
	afx_msg void OnPriorMap();
	afx_msg void OnNextMap();
	afx_msg void OnUpdatePriorMap(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNextMap(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDVIEW_H__A8DB606B_6EBD_11D3_9C7F_9D98C5BF25E9__INCLUDED_)
