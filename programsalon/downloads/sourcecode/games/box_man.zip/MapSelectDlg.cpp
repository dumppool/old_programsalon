// MapSelectDlg.cpp : implementation file
//

#include "stdafx.h"
#include "BoxMan.h"
#include "MapSelectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// MapSelectDlg dialog


MapSelectDlg::MapSelectDlg(CWnd* pParent /*=NULL*/)
	: CDialog(MapSelectDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(MapSelectDlg)
	m_SelectMap = 0;
	//}}AFX_DATA_INIT
}


void MapSelectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(MapSelectDlg)
	DDX_Text(pDX, IDC_EDIT1, m_SelectMap);
	DDV_MinMaxInt(pDX, m_SelectMap, 0, 9999);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(MapSelectDlg, CDialog)
	//{{AFX_MSG_MAP(MapSelectDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// MapSelectDlg message handlers
