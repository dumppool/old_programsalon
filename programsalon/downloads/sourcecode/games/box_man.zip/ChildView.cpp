// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "BoxMan.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
//my
#include "MapSelectDlg.h"
#include "MainFrm.h"
//end
/////////////////////////////////////////////////////////////////////////////
// CChildView

//my
BoxManClass bm;

UINT ThinkThread(LPVOID pParam)
{
	bm.ThinkTheWay();
	return 0;
}
//end

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_LBUTTONUP()
	ON_WM_KEYDOWN()
	ON_COMMAND(ID_SELECTMAP, OnSelectmap)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_COMMAND(ID_SHOW_MOVE_WAY, OnShowMoveWay)
	ON_UPDATE_COMMAND_UI(ID_SHOW_MOVE_WAY, OnUpdateShowMoveWay)
	ON_UPDATE_COMMAND_UI(ID_PROMPT, OnUpdatePrompt)
	ON_COMMAND(ID_PROMPT, OnPrompt)
	ON_COMMAND(ID_PRIOR_MAP, OnPriorMap)
	ON_COMMAND(ID_NEXT_MAP, OnNextMap)
	ON_UPDATE_COMMAND_UI(ID_PRIOR_MAP, OnUpdatePriorMap)
	ON_UPDATE_COMMAND_UI(ID_NEXT_MAP, OnUpdateNextMap)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	//���������Ȼû����,��һ������˩��,I don't know why.
	// TODO: Add your message handler code here
	//my
	bm.Paint();
	//end
	// Do not call CWnd::OnPaint() for painting messages
}

void CChildView::Created()
{
	//my
	bm.SetDrawWnd( this );
	bm.ReadMap( bm.m_nowmap );
	ReSetFrame();
	BeginThinkThread();
	SetStatusBar();
	//end
}

void CChildView::OnSelectmap()
{
	// TODO: Add your command handler code here
	//my
	SelectMap( false );
	//end
}

void CChildView::SelectMap(bool next)
{
	//my
	MapSelectDlg dlg;
	dlg.m_SelectMap = bm.m_nowmap;
	if ( next ) dlg.m_SelectMap++;
	int result = dlg.DoModal();
	if( result == IDOK )
	{
		int number = dlg.m_SelectMap;
		while ( !bm.ReadMap(number) && number<10000 ) number++;
		if ( number<10000 ) {
//			dlg.m_SelectMap = number;
			//bm.m_nowmap = number;
			ReSetFrame();
			BeginThinkThread();
			SetStatusBar();
		}else MessageBox( "û����ѡ����⸱��ͼ.", "ERROR", MB_ICONEXCLAMATION | MB_ICONWARNING);
	}
	//end
}

void CChildView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	//my
	unsigned char result=bm.PointAt(point);
	switch(result){
	case BM_ERROR_PIONT_OUT:
		MessageBox( "���Ц��?\r\n\r\n������ǽ��!", "ERROR", MB_ICONEXCLAMATION | MB_ICONWARNING );
		break;
	case BM_ERROR_POINT_MAN:
		break;
	case BM_ERROR_POINT_WALL:
		MessageBox( "�Բ���,������ǽ.\r\n\r\n�Ҳ���ײǽ�Ծ�!", "ERROR", MB_ICONEXCLAMATION | MB_ICONWARNING );
		break;
	case BM_MAN_MOVED:
		break;
	case BM_BOX_MOVED:
		bm.m_TheShowStep = 0;
		break;
	case BM_MOVED_OK:
		SelectMap( true );
		break;
	case BM_ERROR_CANNOT_MOVE_THERE:
		MessageBox( "�ж�������,\r\n\r\n�����ƶ�������ȥ!", "ERROR", MB_ICONEXCLAMATION | MB_ICONWARNING );
		break;
	case BM_MOVED_TO_BAD_POINT:
		MessageBox( "����ط������ƽ�ȥ,\n��ȥ�ͳ�������!", "ERROR", MB_ICONASTERISK | MB_ICONINFORMATION );
		break;
	}
	//end
	CWnd::OnLButtonUp(nFlags, point);
}

void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	//my
	bool keydown = false;
	unsigned char result;
	switch( nChar ){
	case VK_RIGHT:
		result=bm.MoveTowards( 1, 0 );
		keydown = true;
		break;
	case VK_UP:
		result=bm.MoveTowards( 0, -1 );
		keydown = true;
		break;
	case VK_LEFT:
		result=bm.MoveTowards( -1, 0 );
		keydown = true;
		break;
	case VK_DOWN:
		result=bm.MoveTowards( 0, 1 );
		keydown = true;
		break;
/*	case VK_CONTROL:
		if ( bm.m_CanUndo && !(bool)((nFlags>>14)&0x01) ) bm.Undo();
		break;
	case VK_SPACE:
		bm.ThinkTheWay();
		MessageBox( "Ok" );
*/
	}
	if ( keydown ){
		
		switch (result){
		case BM_MOVED_OK:
			SelectMap(true);
			break;
		case BM_BOX_MOVED:
			bm.m_TheShowStep=0;
			break;
		case BM_MOVED_TO_BAD_POINT:
			MessageBox( "����ط������ƽ�ȥ,\n��ȥ�ͳ�������!", "PROMPT", MB_ICONASTERISK | MB_ICONINFORMATION );
			break;
		}
	}
	//end
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CChildView::OnEditUndo() 
{
	// TODO: Add your command handler code here
	//my
	bm.Undo();
	bm.m_TheShowStep=0;
	//end
}

void CChildView::OnUpdateEditUndo(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	//my
	pCmdUI->Enable(bm.m_CanUndo);
	//end
}

void CChildView::OnShowMoveWay() 
{
	// TODO: Add your command handler code here
	//my
	bm.ShowMoveWay();
	//end
}

void CChildView::OnUpdateShowMoveWay(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	//my
	pCmdUI->Enable( !bm.m_noanswerrecoded );
	//end
}

void CChildView::OnUpdatePrompt(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	//my
	pCmdUI->SetCheck( !bm.m_CanMoveToBadPoint );
	SetStatusBar();
	//end
}

void CChildView::OnPrompt() 
{
	// TODO: Add your command handler code here
	//my
	bm.m_CanMoveToBadPoint = !bm.m_CanMoveToBadPoint;
	//end
}

void CChildView::SetStatusBar()
{
	//my
	char s[80];
	if ( bm.m_RemainShewStep == 0 ) {
		switch(bm._ThreadMessage){
		case BM_MESSAGE_THINKING:
			::wsprintf( s, "����������ⷨ" );
			break;
		case BM_MESSAGE_NO_ANSWER:
			::wsprintf( s, "û�нⷨ" );
			break;
		case BM_MESSAGE_BUFFER_FULL:
			::wsprintf( s, "̫����" );
			break;
		case BM_MESSAGE_THINK_OUT:
			::wsprintf( s, "��֪���ⷨ" );
			break;
		case BM_MESSAGE_THINK_STOPED:
			::wsprintf( s, "Copyright Hunter" );
			break;
		default:
			::wsprintf( s, "I am Hunter!" );
			break;
		}
	}else{
		::wsprintf( s, "����:%d��", bm.m_RemainShewStep );
	}
	CMainFrame* myparent = (CMainFrame*)GetParent();
	myparent->m_wndStatusBar.SetPaneText(1,s);
	//end
}

void CChildView::BeginThinkThread()
{
	//my
	AfxBeginThread( ThinkThread, 0, THREAD_PRIORITY_BELOW_NORMAL/*THREAD_PRIORITY_TIME_CRITICAL*/ );
	//end
}

void CChildView::OnPriorMap() 
{
	// TODO: Add your command handler code here
	int i=bm.m_nowmap;
	while ( !bm.ReadMap( --i ) && i>0 );
	if ( i>0 ) {
		//bm.m_nowmap = i;
		ReSetFrame();
		BeginThinkThread();
		SetStatusBar();
	}else MessageBox( "û����ѡ����⸱��ͼ.", "ERROR", MB_ICONEXCLAMATION | MB_ICONWARNING);
}

void CChildView::OnNextMap() 
{
	// TODO: Add your command handler code here
	int i=bm.m_nowmap;
	while ( !bm.ReadMap( ++i ) && i<10000 );
	if ( i<10000 ) {
		//bm.m_nowmap = i;
		ReSetFrame();
		BeginThinkThread();
		SetStatusBar();
	}else MessageBox( "û����ѡ����⸱��ͼ.", "ERROR", MB_ICONEXCLAMATION | MB_ICONWARNING);
}

void CChildView::OnUpdatePriorMap(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bm.m_nowmap<=1 ? false : true );
}

void CChildView::OnUpdateNextMap(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bm.m_nowmap>=9999 ? false : true );
}

void CChildView::ReSetFrame()
{
	CRect reWindow ;
	CWnd* parent = GetParent();
	parent->GetWindowRect( &reWindow );
	parent->SetWindowPos( NULL, reWindow.top, reWindow.left,
		bm.m_mapsizex * bm.m_size + 11, bm.m_mapsizey * bm.m_size + 94,
		SWP_NOMOVE | SWP_NOZORDER );
	//parent->MoveWindow( reWindow.top, reWindow.left,
	//	bm.m_mapsizex * bm.m_size + 11, bm.m_mapsizey * bm.m_size + 94 );
	char s[80];
	::wsprintf( s, "BoxMan ��Map %d", bm.m_nowmap );
	parent->SetWindowText( s );
	bm.DrawAllMap();
}
