// fiveView.cpp : implementation of the CFiveView class
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define ID_TIME_TEMP 13
//////////////////////////////////////////////////////////////////////////////
int CFiveView::m_Yingcount = 0;
int CFiveView::m_Pingcount = 0;
int CFiveView::m_Shucount  = 0;

/////////////////////////////////////////////////////////////////////////////
// CFiveView

IMPLEMENT_DYNCREATE(CFiveView, CView)

BEGIN_MESSAGE_MAP(CFiveView, CView)
	//{{AFX_MSG_MAP(CFiveView)
	ON_WM_LBUTTONUP()
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_CREATE()
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFiveView construction/destruction

CFiveView::CFiveView()
{
	// TODO: add construction code here
	m_pFive=NULL;
	m_Flags = TRUE;
}

CFiveView::~CFiveView()
{
}

//BOOL CFiveView::PreCreateWindow(CREATESTRUCT& cs)
//{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

//	return CView::PreCreateWindow(cs);
//}

void CFiveView::DrawTable( CDC&dc )
{
	int i;
	int W,D;
	CRect rect;
	GetClientRect( &rect );
	W = min(rect.right - rect.left,rect.bottom-rect.top );
	D = W/(FIVE_MAX_LINE+1);
	rect.left--;
	rect.right++;
	rect.top--;
	rect.bottom++;
//	dc.Rectangle( rect );
	dc.SelectObject(CBrush::FromHandle((HBRUSH)GetStockObject(NULL_BRUSH)));
	dc.Rectangle( D-1,D-1,D*FIVE_MAX_LINE+2,D*FIVE_MAX_LINE+2 );
    for( i = 0;i < FIVE_MAX_LINE;i++ )
	{
		dc.MoveTo( D,D*(i+1) );
		dc.LineTo( D*FIVE_MAX_LINE,D*(i+1) );
		dc.MoveTo( D*(i+1),D );
		dc.LineTo( D*(i+1),D*FIVE_MAX_LINE );
	}
}

void CFiveView::DrawSub( CDC& dc,int m,int n,BOOL f )
{
	CBrush brush;
	int W,D;
	CRect rect;
	GetClientRect( &rect );
	W = min(rect.right - rect.left,rect.bottom-rect.top );
	D = W/(FIVE_MAX_LINE+1);
	m_m = m+1;
	m_n = n+1;
	if( m_m == m&&m_n == n )
	{
		brush.CreateSolidBrush( RGB(255,0,0) );
	}else
	if( f == TRUE )
		brush.CreateSolidBrush( RGB(0,0,0) );
	else
		brush.CreateSolidBrush( RGB(255,255,255));
	dc.SelectObject( &brush );
	dc.Ellipse( D*(m+1) - D/2,D*(n+1) -D/2,D*(m+1) +D/2,D*(n+1) +D/2);
}

BOOL CFiveView::GetPosition( int x,int y ,int& m,int& n)
{
	CBrush brush;
	int W,D;
	CRect rect;
	GetClientRect( &rect );
	W = min(rect.right - rect.left,rect.bottom-rect.top );
	D = W/(FIVE_MAX_LINE+1);
	m = x/D+0.5;
	n = y/D+0.5;
	if( m < 15&&m>= 0 &&n<15&&n>=0 )
		return TRUE;
	else
		return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// CFiveView drawing

void CFiveView::OnDraw(CDC* pDC)
{
	/*
	int i,j;
	CFive five;
	char Nf;
//////////////////////////////////////////////////////////////////////
	CDC dc;
	CBitmap map;
	CBitmap*oldmap;
	int W;
	CRect rect;

	GetClientRect( &rect );
	W = min(rect.right - rect.left,rect.bottom-rect.top );

	CFiveDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	dc.CreateCompatibleDC(pDC);
	map.CreateCompatibleBitmap( pDC, W,W );
	oldmap=(CBitmap*)dc.SelectObject( &map );

	DrawTable( dc );
	for( i = 0;i< FIVE_MAX_LINE;i++ )
		for( j = 0;j< FIVE_MAX_LINE;j++ )
		  {
		      Nf = five.GetSubPosition( i,j );
			  if( Nf == 'W' )
				  DrawSub( dc,i,j,FALSE );
			  else if( Nf == 'B' )
				  DrawSub( dc,i,j,TRUE );
	      }
	pDC->BitBlt( 0,0,W,W,&dc,0,0,SRCCOPY );
	dc.SelectObject( oldmap );
	// TODO: add draw code for native data here
	*/
/////////////////////////////////////////////////////////////////////////
}

/////////////////////////////////////////////////////////////////////////////
// CFiveView diagnostics

#ifdef _DEBUG
void CFiveView::AssertValid() const
{
	CView::AssertValid();
}

void CFiveView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CFiveDoc* CFiveView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFiveDoc)));
	return (CFiveDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFiveView message handlers


void CFiveView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	int m,n,rev,r;

	if( m_pFive == NULL )
	{
		if( GetPosition( point.x,point.y,m,n ) )
		{
			m_pFive = new CFive();
			rev = m_pFive -> WzqTest( m,n );
			if( AssertTest( rev ) == FALSE )
			{
				MessageBeep( 0 );
				m_m = m;
				m_n = n;
				Invalidate();
				UpdateWindow();
				r = m_pFive -> WzqRun( m,n );
				if(r == WZQ_NOTHREAD )
				{
					delete m_pFive;
					m_pFive = NULL;
					m_m = m;
					m_n = n;
					Invalidate();
					UpdateWindow();
					MessageBeep( 0 );
					rev = m_pFive -> WzqEndTest();
					AssertTest( rev );
				}else if( r == WZQ_ERROR )
				{
				    delete m_pFive;
				    m_pFive = NULL;
					AfxMessageBox( "WzqRun WZQ_ERROR" );
				}else
				{
					SetTimer(ID_TIME_TEMP,200,NULL );
				}
			}
			else
			{
				delete m_pFive;
				ResetPane();
				m_pFive = NULL;
			    m_m = m;
			    m_n = n;
			    Invalidate();
			    UpdateWindow();
			    MessageBeep( 0 );
				KillTimer(ID_TIME_TEMP);
			}
		}
	}
//	else
//	{
//		if( WaitForSingleObject( m_pFive->m_hThread,0 ) == WAIT_OBJECT_0 )
//		{
//			m_pFive->GetCurStep(m,n);
//			rev = m_pFive -> WzqEndTest();
//			AssertTest( rev );
//			delete m_pFive;
//			m_pFive = NULL;
//			MessageBeep( 0 );
//		}
//	}
	CView::OnLButtonUp(nFlags, point);
}

BOOL CFiveView::AssertTest( int rev )
{
	CCountDlg dlg( this );
	switch( rev )
	{
		case WZQ_I:
//			::MessageBox( NULL,"WZQ_I","",MB_OK );
			if( m_Flags ==TRUE )
			{
				m_Shucount++;
				m_Flags = FALSE;
			}
			dlg.m_Bai = m_Shucount;
			dlg.m_Yin = m_Yingcount;
			dlg.m_Ping= m_Pingcount;
			dlg.m_Text= WZQ_I;
			dlg.DoModal();
			return TRUE;
		case WZQ_YOU:
//			::MessageBox(NULL, "WZQ_YOU","",MB_OK );
			if( m_Flags == TRUE )
			{
				m_Yingcount++;
				m_Flags = FALSE;
			}
			dlg.m_Bai = m_Shucount;
			dlg.m_Yin = m_Yingcount;
			dlg.m_Ping= m_Pingcount;
			dlg.m_Text= WZQ_YOU;
			dlg.DoModal();
			return TRUE;
		case WZQ_PING:
//			::MessageBox( NULL,"WZQ_PING","",MB_OK );
			if( m_Flags == TRUE )
			{
				m_Pingcount++;
				m_Flags = FALSE;
			}
			dlg.m_Bai = m_Shucount;
			dlg.m_Yin = m_Yingcount;
			dlg.m_Ping= m_Pingcount;
			dlg.m_Text= WZQ_PING;
			dlg.DoModal();
			return TRUE;
		case WZQ_ERROR:
            AfxMessageBox( "WZQ_ERROR" );
			return TRUE;
		case WZQ_HAVE:
			return TRUE;
	}
	return FALSE;
}

BOOL CFiveView::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if( m_pFive != NULL )
	{
		if( WaitForSingleObject( m_pFive->m_hThread,0 ) == WAIT_OBJECT_0 )
		{
			int m,n,rev;
			m_pFive->GetCurStep(m,n);
			rev = m_pFive -> WzqEndTest();
			ResetPane();
			delete m_pFive;
			m_pFive = NULL;
			m_m = m;
			m_n = n;
			Invalidate();
			UpdateWindow();
			MessageBeep( 0 );
			AssertTest( rev );
			KillTimer(ID_TIME_TEMP);
		}
	}
	return CView::PreTranslateMessage(pMsg);
}

void CFiveView::ResetPane()
{
	CMainFrame* pwnd;
	pwnd = (CMainFrame*)AfxGetMainWnd();
	if( pwnd != NULL )
	{
		if( pwnd->IsKindOf( RUNTIME_CLASS( CMainFrame )))
		{
				pwnd->m_wndStatusBar.SetPaneText( 1,"        " );
				pwnd->m_wndStatusBar.SetPaneText( 2,"        " );
				pwnd->m_wndStatusBar.SetPaneText( 3,"        " );
		}
	}
}

long GetForCount()
{
	CFive five;
	long rev,temp;
	int breadth,deep,thread,delta,i,c;
    five.GetParam( breadth,deep,thread,delta );
	rev = breadth;
	i = breadth;
	temp = breadth;
	c = 1;
	while( i>0&&c<deep)
	{
		temp = i*temp;
		rev = temp + rev;
		i = i - delta;
		c++;
	}
	return rev/breadth;
}

void CFiveView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	CMainFrame* pwnd;
	pwnd = (CMainFrame*)AfxGetMainWnd();
	if( pwnd != NULL )
	{
		if( pwnd->IsKindOf( RUNTIME_CLASS( CMainFrame )))
		{
			TCHAR Buf[20];
			if( m_pFive != NULL )
			{
				int i;
				i = (m_pFive.JingDuCount*100)/GetForCount();
				if( i > 100 )
					i = 100;
				wsprintf( Buf,"%d%c",i,'%' );
				pwnd->m_wndStatusBar.SetPaneText( 1,Buf );
				wsprintf( Buf,"%d",m_pFive->ThreadCount );
				pwnd->m_wndStatusBar.SetPaneText( 2,Buf );
				wsprintf( Buf,"%luKb",m_pFive->MemoryCount*400/1024);
				pwnd->m_wndStatusBar.SetPaneText( 3,Buf );
			}
		}
	}
	CView::OnTimer(nIDEvent);
}


void CFiveView::OnPaint() 
{
	CPaintDC pDC(this); // device context for painting
	
	// TODO: Add your message handler code here
	int i,j;
	CFive five;
	char Nf;
//////////////////////////////////////////////////////////////////////
	CDC dc;
	CBitmap map;
	CBitmap*oldmap;
	int W,H;
	CRect rect;

	GetClientRect( &rect );
	W = rect.right - rect.left;
	H = rect.bottom-rect.top;

	CFiveDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	dc.CreateCompatibleDC(&pDC);
	map.CreateCompatibleBitmap( &pDC, W,H );
	oldmap=(CBitmap*)dc.SelectObject( &map );

	dc.Rectangle(-1,-1,W+1,H+1 ); 
	DrawTable( dc );
	for( i = 0;i< FIVE_MAX_LINE;i++ )
		for( j = 0;j< FIVE_MAX_LINE;j++ )
		  {
		      Nf = five.GetSubPosition( i,j );
			  if( Nf == 'W' )
				  DrawSub( dc,i,j,FALSE );
			  else if( Nf == 'B' )
				  DrawSub( dc,i,j,TRUE );
	      }
	pDC.BitBlt( 0,0,W,H,&dc,0,0,SRCCOPY );
	dc.SelectObject( oldmap );	
	// Do not call CView::OnPaint() for painting messages
}

BOOL CFiveView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	
//	return CView::OnEraseBkgnd(pDC);
	return 1;
}


int CFiveView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_MAIN));
	ShowCursor( TRUE );
	return 0;
}

BOOL CFiveView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_MAIN));
//	ShowCursor( TRUE );	
	return TRUE;//CView::OnSetCursor(pWnd, nHitTest, message);
}
