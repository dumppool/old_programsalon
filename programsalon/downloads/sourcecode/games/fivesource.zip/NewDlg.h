// NewDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNewDlg dialog

class CNewDlg : public CDialog
{
// Construction
public:
	CNewDlg(CWnd* pParent = NULL);   // standard constructor
	static BOOL m_Xian;
	static BOOL m_Wb;
	static int  m_Check;

// Dialog Data
	//{{AFX_DATA(CNewDlg)
	enum { IDD = IDD_DIALOG_NEW };
	CButton	m_Checkbar;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnRadioBlack();
	afx_msg void OnRadioWhite();
	afx_msg void OnRadioXian();
	afx_msg void OnRadioHuo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
