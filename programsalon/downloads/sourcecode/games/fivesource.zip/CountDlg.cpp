// CountDlg.cpp : implementation file
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
int CCountDlg::m_Bai;
int CCountDlg::m_Ping;
int CCountDlg::m_Yin;
int CCountDlg::m_Text;
/////////////////////////////////////////////////////////////////////////////
// CCountDlg dialog


CCountDlg::CCountDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCountDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCountDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CCountDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCountDlg)
	DDX_Control(pDX, IDC_STATIC_IMAGE, m_Image);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCountDlg, CDialog)
	//{{AFX_MSG_MAP(CCountDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCountDlg message handlers

BOOL CCountDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	SetDlgItemInt( ID_COUNT_BAI,m_Bai );
	SetDlgItemInt( ID_COUNT_PING,m_Ping );
	SetDlgItemInt( ID_COUNT_YIN,m_Yin );
	switch( m_Text )
	{
	case WZQ_I:
		SetDlgItemText(ID_COUNT_TITLE,"�����ˣ���ѡ���¿�ʼ��");
		m_Image.SetBitmap( LoadBitmap( AfxGetInstanceHandle(),MAKEINTRESOURCE( IDB_BITMAP_SHU)));
		break;
	case WZQ_YOU:
		SetDlgItemText(ID_COUNT_TITLE,"��Ӯ�ˣ���ѡ���¿�ʼ��");
		m_Image.SetBitmap( LoadBitmap( AfxGetInstanceHandle(),MAKEINTRESOURCE( IDB_BITMAP_YING)));
		break;
	case WZQ_PING:
		SetDlgItemText(ID_COUNT_TITLE,"ƽ�壡��ѡ���¿�ʼ��");
		m_Image.SetBitmap( LoadBitmap( AfxGetInstanceHandle(),MAKEINTRESOURCE( IDB_BITMAP_PING)));
		break;
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
