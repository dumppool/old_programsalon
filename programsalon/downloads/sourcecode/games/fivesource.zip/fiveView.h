// fiveView.h : interface of the CFiveView class
//
/////////////////////////////////////////////////////////////////////////////
class CFiveView;
class CFiveDoc;

class CFiveView : public CView
{
protected: // create from serialization only
	CFiveView();
	DECLARE_DYNCREATE(CFiveView)
    BOOL AssertTest( int rev );
	int m_m;
	int m_n;
public:
	BOOL   m_Flags;
	static int m_Yingcount;
	static int m_Pingcount;
	static int m_Shucount;

	// Attributes
public:
	CFive *m_pFive;
	CFiveDoc* GetDocument();
	void DrawTable( CDC& dc );
	void DrawSub( CDC& dc,int m,int n,BOOL f );
    BOOL GetPosition( int x,int y ,int& m,int& n);
    void ResetPane();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFiveView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFiveView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFiveView)
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in fiveView.cpp
inline CFiveDoc* CFiveView::GetDocument()
   { return (CFiveDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
