//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by five.rc
//
#define IDD_ABOUTBOX                    100
#define IDC_STEPBOX                     101
#define IDR_MAINFRAME                   128
#define IDR_FIVETYPE                    129
#define IDD_DIALOG_SET                  130
#define IDB_BITMAP_EXIT                 133
#define IDB_BITMAP_ERROR                136
#define IDB_BITMAP_PING                 137
#define IDB_BITMAP_SHU                  138
#define IDB_BITMAP_WELCOM               139
#define IDB_BITMAP_ABOUT                140
#define IDB_BITMAP_HELP                 144
#define IDB_BITMAP_YING                 145
#define IDD_DIALOG_ABOUT                147
#define IDR_TOOLBAR_PLAY                150
#define IDR_TOOLBAR_MAIN                152
#define IDD_DIALOG_ERROR                156
#define IDB_BITMAP_MAIN                 156
#define IDD_DIALOG_COUNT                157
#define IDD_DIALOG_EXIT                 158
#define IDB_BITMAP_PLAY                 158
#define IDD_DIALOG_WELCOM               159
#define IDD_DIALOG_NEW                  159
#define IDD_DIALOG_HELP                 160
#define IDC_CURSOR_MAIN                 160
#define IDC_CHECK_ONE                   1000
#define IDC_EDIT_WF0_1                  1001
#define IDC_EDIT_WF0_2                  1002
#define IDC_EDIT_WF0_3                  1003
#define IDC_EDIT_WF0_4                  1004
#define IDC_EDIT_WF1_1                  1005
#define IDC_EDIT_WF1_2                  1006
#define IDC_EDIT_WF1_3                  1007
#define IDC_EDIT_WF1_4                  1008
#define IDC_EDIT_WF2_3                  1009
#define IDC_EDIT_WF2_4                  1010
#define IDC_EDIT_WF5                    1011
#define IDC_SET_RESET                   1013
#define IDC_EDIT_BREADTH                1014
#define IDC_EDIT_DEEP                   1015
#define IDC_EDIT_THREAD                 1016
#define IDC_EDIT_DELTA                  1017
#define IDC_RADIO_ALPHA                 1018
#define ID_SET_HELP                     1019
#define IDC_EDIT_NUM                    1020
#define IDC_SRCOLL_NUM                  1021
#define IDC_CHECK_JING                  1022
#define IDC_CHECK_FENG                  1023
#define IDC_CHECK_PING                  1024
#define IDC_RADIO_DELTA                 1025
#define IDC_BUTTON_GUSUAN               1026
#define IDC_STATIC_SETINFO              1027
#define ID_ERROR_NAME                   1028
#define IDC_RADIO_WHITE                 1030
#define IDC_RADIO_BLACK                 1031
#define IDC_RADIO_HUO                   1035
#define IDC_RADIO_XIAN                  1036
#define ID_ERROR_INFO                   1037
#define ID_COUNT_TITLE                  1038
#define ID_COUNT_YIN                    1039
#define IDC_STATIC_SIDE                 1039
#define ID_COUNT_PING                   1040
#define IDC_STATIC_XIAN                 1040
#define ID_COUNT_BAI                    1041
#define ID_HELP_INFO                    1042
#define IDC_WELCOM_CPU                  1045
#define IDC_WELCOM_MEMORY               1046
#define IDC_EDITBAR_SEARCHBOX           1047
#define IDC_CHECK1                      1047
#define IDC_STATIC_IMAGE                1048
#define ID_PARAM_SET                    32771
#define ID_APP_HELP                     32772
#define ID_APP_WELCOM                   32773
#define ID_VIEW_TOOLBAR1                32774
#define ID_BUTTON_HUI                   32775
#define ID_BUTTON_DIN                   32777
#define ID_BUTTON_XIA                   32778
#define ID_BUTTON_QIAN                  32779
#define ID_BUTTON_JIN                   32787
#define ID_BUTTON_KILL                  32788
#define ID_SET_SHOWNEW                  32789
#define ID_THREAD_COUNT                 59143
#define ID_JINGDU                       59144
#define ID_MEMORY_COUNT                 59145

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        161
#define _APS_NEXT_COMMAND_VALUE         32790
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
