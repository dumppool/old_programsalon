// IsRuning.cpp : implementation file
//

#include "stdafx.h"
#include "five.h"
#include "fiveview.h"
#include "IsRuning.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIsRuning

IMPLEMENT_DYNCREATE(CIsRuning, CWinThread)

int CIsRuning::CurM;
int CIsRuning::CurN;

CIsRuning::CIsRuning()
{
	boolIsRun = FALSE;
}

CIsRuning::~CIsRuning()
{
}

BOOL CIsRuning::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	boolIsRun = TRUE;
	int Curet;
//	Curet = m_Five.WzqRun( CurM,CurN );
	CClientDC dc(pView);
	switch( Curet )
	{
	case WZQ_I:
		::MessageBox( NULL,"You lost","",MB_OK );
		break;
	case WZQ_PING:
		::MessageBox( NULL,"Ping","",MB_OK );
		break;
	case WZQ_YOU:
		::MessageBox( NULL,"You wne","",MB_OK );
		break;
	case WZQ_RUN:
		pView -> DrawSub( dc,CurM,CurN,FALSE );
		break;
	case WZQ_ERROR:
		break;
	}
	return FALSE;
}

void CIsRuning::SetpView( CFiveView* p )
{
	pView = p;
}

int CIsRuning::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	int rev;
	rev = CWinThread::ExitInstance();
	boolIsRun = FALSE;
	return rev;
}

BEGIN_MESSAGE_MAP(CIsRuning, CWinThread)
	//{{AFX_MSG_MAP(CIsRuning)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIsRuning message handlers
