// SetDlg.cpp : implementation file
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetDlg dialog


CSetDlg::CSetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSetDlg, CDialog)
	//{{AFX_MSG_MAP(CSetDlg)
	ON_BN_CLICKED(IDC_SET_RESET, OnSetReset)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetDlg message handlers

BOOL CSetDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	SetDlgItemInt( IDC_EDIT_WF0_1,WF0_1 );
	SetDlgItemInt( IDC_EDIT_WF0_2,WF0_2 );
	SetDlgItemInt( IDC_EDIT_WF0_3,WF0_3 );
	SetDlgItemInt( IDC_EDIT_WF0_4,WF0_4 );
	SetDlgItemInt( IDC_EDIT_WF1_1,WF0_1 );
	SetDlgItemInt( IDC_EDIT_WF1_2,WF1_2 );
	SetDlgItemInt( IDC_EDIT_WF1_3,WF1_3 );
	SetDlgItemInt( IDC_EDIT_WF1_4,WF1_4 );
	SetDlgItemInt( IDC_EDIT_WF2_3,WF2_3 );
	SetDlgItemInt( IDC_EDIT_WF2_4,WF2_4 );
	SetDlgItemInt( IDC_EDIT_WF5,WF5 );
	SetDlgItemInt( IDC_EDIT_BREADTH,Breadth );
	SetDlgItemInt( IDC_EDIT_DEEP,Deep );
	SetDlgItemInt( IDC_EDIT_THREAD,Thread );
	SetDlgItemInt( IDC_EDIT_DELTA,Delta );
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSetDlg::OnOK() 
{
	// TODO: Add extra validation here
	WF0_1 = GetDlgItemInt( IDC_EDIT_WF0_1 );
	WF0_2 = GetDlgItemInt( IDC_EDIT_WF0_2 );
	WF0_3 = GetDlgItemInt( IDC_EDIT_WF0_3 );
	WF0_4 = GetDlgItemInt( IDC_EDIT_WF0_4 );
	WF1_1 = GetDlgItemInt( IDC_EDIT_WF1_1 );
	WF1_2 = GetDlgItemInt( IDC_EDIT_WF1_2 );
	WF1_3 = GetDlgItemInt( IDC_EDIT_WF1_3 );
	WF1_4 = GetDlgItemInt( IDC_EDIT_WF1_4 );
	WF2_3 = GetDlgItemInt( IDC_EDIT_WF2_3 );
	WF2_4 = GetDlgItemInt( IDC_EDIT_WF2_4 );
	WF5   = GetDlgItemInt( IDC_EDIT_WF5 );
	Breadth = GetDlgItemInt( IDC_EDIT_BREADTH );
	Deep = GetDlgItemInt( IDC_EDIT_DEEP );
	Thread = GetDlgItemInt( IDC_EDIT_THREAD );
	Delta = GetDlgItemInt( IDC_EDIT_DELTA );

	CDialog::OnOK();
}

void CSetDlg::OnSetReset() 
{
	// TODO: Add your control notification handler code here
	SetDlgItemInt( IDC_EDIT_WF1_1,1 );
	SetDlgItemInt( IDC_EDIT_WF1_2,20 );
	SetDlgItemInt( IDC_EDIT_WF1_3,150 );
	SetDlgItemInt( IDC_EDIT_WF1_4,600 );
	SetDlgItemInt( IDC_EDIT_WF0_1,2 );
	SetDlgItemInt( IDC_EDIT_WF0_2,50 );
	SetDlgItemInt( IDC_EDIT_WF0_3,500 );
	SetDlgItemInt( IDC_EDIT_WF0_4,5000 );
	SetDlgItemInt( IDC_EDIT_WF2_3,400 );
	SetDlgItemInt( IDC_EDIT_WF2_4,450 );
	SetDlgItemInt( IDC_EDIT_WF5,30000 );
	SetDlgItemInt( IDC_EDIT_BREADTH,1 );
	SetDlgItemInt( IDC_EDIT_DEEP,1 );
	SetDlgItemInt( IDC_EDIT_THREAD,0 );
	SetDlgItemInt( IDC_EDIT_DELTA,0 );	
}
