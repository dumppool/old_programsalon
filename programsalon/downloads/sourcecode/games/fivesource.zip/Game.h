////////////////////////////////////////////////////////////////////////////////////////////
// Hander file: game.h
//         Copyright( C ) 1997.5-1997.11
////////////////////////////////////////////////////////////////////////////////////////////
#ifndef GAME_H
#define GAME_H
#include <afxwin.h>
#include <afxtempl.h>
#include <afxmt.h>
#include <afxext.h>

#define FIVE_MAX_LINE 15

#define WZQ_I     2435
#define WZQ_PING  WZQ_I + 1
#define WZQ_ERROR WZQ_I + 2
#define WZQ_YOU   WZQ_I + 3
#define WZQ_RUN   WZQ_I + 4
#define WZQ_HAVE  WZQ_I + 5
#define WZQ_NOTHREAD  WZQ_I + 6

#define WZQ_B     'B'
#define WZQ_W     'W'
#define WZQ_N     'N'
///////////////////////////////////////////////////////////////////////////////////////////
// CFive 
	struct Step
	{
		int  m;
		int  n;
		char side;
	};

	struct Count
	{
		Step step;
		double count;
	};

class CFive:public CWinThread
{
protected:
///////////////////////////////////////////////////////////////////////////////////////////
// ƽ�ֲ���
	static int WF1_1;
	static int WF1_2;
	static int WF1_3;
	static int WF1_4;
	static int WF0_1;
	static int WF0_2;
	static int WF0_3;
	static int WF0_4;
	static int WF2_3;
	static int WF2_4;
	static int WF5;
///////////////////////////////////////////////////////////////////////////////////////////
// ��������
	static int  DeepMax;
	static int  ThreadDeepMax;
	static int  BreadthMax;
	static int  Delta;
	static char Side;

	static BOOL PlayStateFlags;
	static int  PlayIndex;

	static char FiveArea[FIVE_MAX_LINE][FIVE_MAX_LINE]; 
	static CList<Step,Step>   StepList;            //ÿһ�����б�
	static CArray<int,int>    ImpList;
	static CList<Count,Count> OneCountList;

	static CEvent KillWzqRun;
	static CStatusBar *pInfo;
//////////////////////////////////////////////////////////////////////////////////////////
// ��ʱ����
    int    CurDeep;
	int    CurThreadDeep;
	int    CurBreadth;
	double CurCount;
	char   CurSide;
	CList<Count,Count> CountList;
	CList<Step,Step>   DeepList;
	static Count       PiShen;

public:
	enum LEVE
	   {  COUNT_INC,  //ʹ�����������������
		  COUNT_SUB,  //ʹ�ǲ����������������
		  COUNT_MID,  //ƽ��
		  COUNT_DELTA,
		  COUNT_ALPHA,
		};
	static long        MemoryCount;
	static int         ThreadCount;
	static long        JingDuCount;
	
protected:
////////////////////////////////////////////////////////////////////////////////////////////
// ƽ�ֻ���
	int  Dump( int Num,int Wflag );
	long SreachLine( char *Line,int Num,char Side );
	long SreachArea( char  Area[][FIVE_MAX_LINE],char NF );
    void CalRun( char Nf,LEVE leve );
    BOOL BiTest( int& mm,int& nn );
	void ResumePlayState();
    void UpdatePlay();

///////////////////////////////////////////////////////////////////////////////////////////
//
	void ThreadRun();

	void    AddDeepList( Step step );
	Step    GetLastDeepList();
	double  GetStepCount();
public:
	CEvent  EndEvent;
///////////////////////////////////////////////////////////////////////////////////////////
// ��ʼ��
	CFive();
protected:
	CFive( char side,int deep,int breadth,int threaddeep );
public:
	~CFive();
	void WzqInit( char side,BOOL flags = TRUE  );
///////////////////////////////////////////////////////////////////////////////////////////
// ��������
	void SetDump( int Num,int Wflag,int count );
	int  GetDump( int Num,int Wflag );
	void SetParam( int breadth,int deep,int thread,int delta );
	void GetParam( int& breadth,int& deep,int& thread,int& delta );
	int  WzqTest( int m,int n );
    int  WzqEndTest();
	int  WzqRun( int &m,int &n );
	char GetSubPosition( int m,int n );
	char GetSide();

	BOOL HuiOneStep();
	BOOL BackEndStep();
	BOOL BackOneStep();
	BOOL FowardOneStep();
	BOOL OneStep();

	void InListBox( CComboBox& box );
    int  GetCurStep(int&m,int&n);
	void KillWzqThread();
	void NoKillThread();
	void SetInfo( CStatusBar*p);
//////////////////////////////////////////////////////////////////////////////////////////
// �̲߳���

	BOOL InitInstance();
	int  ExitInstance();
	void Serialize( CArchive& ar );
	DECLARE_SERIAL( CFive )
};

#endif
