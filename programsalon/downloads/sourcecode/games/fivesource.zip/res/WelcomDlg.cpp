// WelcomDlg.cpp : implementation file
//

#include "stdafx.h"
#include "five.h"
#include "WelcomDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWelcomDlg dialog


CWelcomDlg::CWelcomDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWelcomDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWelcomDlg)
	//}}AFX_DATA_INIT
}


void CWelcomDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWelcomDlg)
	DDX_Control(pDX, IDC_CHECK_ONE, m_OneCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWelcomDlg, CDialog)
	//{{AFX_MSG_MAP(CWelcomDlg)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWelcomDlg message handlers

BOOL CWelcomDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	TCHAR temp[100];

	SYSTEM_INFO   system_info;
    MEMORYSTATUS  memory_info;

	if( AfxGetApp()->GetProfileInt("Init State","Welcom",1 ) != 1 )
		m_OneCtrl.SetCheck( 0 );
	else
		m_OneCtrl.SetCheck( 1 );
	GetSystemInfo( &system_info );
	switch( system_info.dwProcessorType )
	{
	case PROCESSOR_INTEL_386:
		wsprintf( temp,"%s","Intel 386" );
		break;
	case PROCESSOR_INTEL_486:
		wsprintf( temp,"%s","Intel 486" );
		break;
	case PROCESSOR_INTEL_PENTIUM:
		wsprintf( temp,"%s","Intel Pentium" );
		break;
	default:
		wsprintf( temp,"%s","Intel ?" );
	}
	SetDlgItemText( IDC_WELCOM_CPU,temp );
	GlobalMemoryStatus(&memory_info);
	wsprintf( temp,"%d Mb",memory_info.dwTotalPhys/1024/1024 );
	SetDlgItemText( IDC_WELCOM_MEMORY,temp );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CWelcomDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CDialog::OnMouseMove(nFlags, point);
}

void CWelcomDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	AfxGetApp()->WriteProfileInt("Init State","Welcom",m_OneCtrl.GetCheck() );
	EndDialog( 1 );
	CDialog::OnLButtonUp(nFlags, point);
}
