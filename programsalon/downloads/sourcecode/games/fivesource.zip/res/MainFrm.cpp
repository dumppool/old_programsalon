// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"

#include "game.h"
#include "Five.h"

#include "MainFrm.h"
#include "SetDlg.h"
#include "exitdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
static UINT BASED_CODE indicators[] =
{
	ID_SEPARATOR,           // status line indicator
//	ID_INDICATOR_CAPS,
//	ID_INDICATOR_NUM,
//	ID_INDICATOR_SCRL,
};

static UINT BASED_CODE playId[] =
{       
	    ID_BUTTON_HUI,
		ID_BUTTON_DIN,
		ID_BUTTON_QIAN,
		ID_BUTTON_XIA,
	    ID_SEPARATOR,           // status line indicator
		IDC_STEPBOX,
};

static UINT BASED_CODE mainId[] =
{
	ID_FILE_NEW,
    ID_FILE_OPEN,
	ID_FILE_SAVE,
	ID_SEPARATOR,           // status line indicator
	ID_APP_ABOUT,
};

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_COMMAND(ID_PARAM_SET, OnParamSet)
	ON_COMMAND(ID_VIEW_TOOLBAR1, OnViewToolbar1)
	ON_UPDATE_COMMAND_UI(ID_VIEW_TOOLBAR1, OnUpdateViewToolbar1)
	ON_COMMAND(ID_BUTTON_HUI, OnButtonHui)
	ON_COMMAND(ID_VIEW_TOOLBAR, OnViewToolbar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_TOOLBAR, OnUpdateViewToolbar)
	ON_COMMAND(ID_BUTTON_DIN, OnButtonDin)
	ON_COMMAND(ID_BUTTON_QIAN, OnButtonQian)
	ON_COMMAND(ID_BUTTON_XIA, OnButtonXia)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static TCHAR BASED_CODE szSection[] = _T("Settings");
static TCHAR BASED_CODE szWindowPos[] = _T("WindowPos");
static TCHAR BASED_CODE szDump[] = _T("Dump");
static TCHAR BASED_CODE szSreach[] = _T("Sreach");

static TCHAR szFormat[] = _T("%u,%u,%d,%d,%d,%d,%d,%d,%d,%d");
static TCHAR szDumpFormat[] = _T("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d");
static TCHAR szSreachFormat[] = _T("%d,%d,%d,%d");

static void ReadGameParam( CFive& f )
{
	int WF0_1,WF0_2,WF0_3,WF0_4;
	int WF1_1,WF1_2,WF1_3,WF1_4;
	int WF2_3,WF2_4,WF5;
	int Deep,Breadth,Thread,Delta;
	CString strBuffer;
	TCHAR Def[250];
	wsprintf( Def,szDumpFormat,2,50,500,5000,1,20,150,600,400,450,30000 );
	strBuffer = AfxGetApp()->GetProfileString(szSection, szDump,Def );
	_stscanf( strBuffer,szDumpFormat,&WF0_1,&WF0_2,&WF0_3,&WF0_4,
		&WF1_1,&WF1_2,&WF1_3,&WF1_4,&WF2_3,&WF2_4,&WF5 );
	f.SetDump(1,0,WF0_1);
	f.SetDump(2,0,WF0_2);
	f.SetDump(3,0,WF0_3);
	f.SetDump(4,0,WF0_4);
	f.SetDump(1,1,WF1_1);
	f.SetDump(2,1,WF1_2);
	f.SetDump(3,1,WF1_3);
	f.SetDump(4,1,WF1_4);
	f.SetDump(3,2,WF2_3);
	f.SetDump(4,2,WF2_4);
	f.SetDump(5,5,WF5);
	wsprintf( Def,szSreachFormat,10,4,0,2 );
	strBuffer = AfxGetApp()->GetProfileString(szSection,szSreach,Def );
	_stscanf( strBuffer,szSreachFormat,&Breadth,&Deep,&Thread,&Delta );
	f.SetParam( Breadth,Deep,Thread,Delta );
}

static void WriteGameParam( CFive& f )
{
	int WF0_1,WF0_2,WF0_3,WF0_4;
	int WF1_1,WF1_2,WF1_3,WF1_4;
	int WF2_3,WF2_4,WF5;
	int Deep,Breadth,Thread,Delta;
	TCHAR Buf[250];
	WF0_1 = f.GetDump(1,0);
	WF0_2 = f.GetDump(2,0);
	WF0_3 = f.GetDump(3,0);
	WF0_4 = f.GetDump(4,0);
	WF1_1 = f.GetDump(1,1);
	WF1_2 = f.GetDump(2,1);
	WF1_3 = f.GetDump(3,1);
	WF1_4 = f.GetDump(4,1);
	WF2_3 = f.GetDump(3,2);
	WF2_4 = f.GetDump(4,2);
	WF5   = f.GetDump(5,5);

	wsprintf( Buf,szDumpFormat,WF0_1,WF0_2,WF0_3,WF0_4,
		WF1_1,WF1_2,WF1_3,WF1_4,WF2_3,WF2_4,WF5 );
	AfxGetApp()->WriteProfileString( szSection,szDump,Buf );
	f.GetParam( Breadth,Deep,Thread,Delta );
	wsprintf( Buf,szSreachFormat,Breadth,Deep,Thread,Delta );
	AfxGetApp()->WriteProfileString( szSection,szSreach,Buf );
}

static BOOL PASCAL NEAR ReadWindowPlacement(LPWINDOWPLACEMENT pwp)
{
	CString strBuffer = AfxGetApp()->GetProfileString(szSection, szWindowPos);
	if (strBuffer.IsEmpty())
		return FALSE;

	WINDOWPLACEMENT wp;
	int nRead = _stscanf(strBuffer, szFormat,
		&wp.flags, &wp.showCmd,
		&wp.ptMinPosition.x, &wp.ptMinPosition.y,
		&wp.ptMaxPosition.x, &wp.ptMaxPosition.y,
		&wp.rcNormalPosition.left, &wp.rcNormalPosition.top,
		&wp.rcNormalPosition.right, &wp.rcNormalPosition.bottom);

	if (nRead != 10)
		return FALSE;

	wp.length = sizeof wp;
	*pwp = wp;
	return TRUE;
}

static void PASCAL NEAR WriteWindowPlacement(LPWINDOWPLACEMENT pwp)
	// write a window placement to settings section of app's ini file
{
	TCHAR szBuffer[sizeof("-32767")*8 + sizeof("65535")*2];

	wsprintf(szBuffer, szFormat,
		pwp->flags, pwp->showCmd,
		pwp->ptMinPosition.x, pwp->ptMinPosition.y,
		pwp->ptMaxPosition.x, pwp->ptMaxPosition.y,
		pwp->rcNormalPosition.left, pwp->rcNormalPosition.top,
		pwp->rcNormalPosition.right, pwp->rcNormalPosition.bottom);
	AfxGetApp()->WriteProfileString(szSection, szWindowPos, szBuffer);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.style &= ~FWS_ADDTOTITLE;

	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


 int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	ReadGameParam( m_Five );

	WINDOWPLACEMENT wp;
	if (ReadWindowPlacement(&wp))
		SetWindowPlacement(&wp);

	if (!m_wndToolBar.Create(this, WS_CHILD | WS_VISIBLE | CBRS_SIZE_DYNAMIC |
			CBRS_TOP |CBRS_TOOLTIPS | CBRS_FLYBY, IDR_TOOLBAR_MAIN ) ||
		!m_wndToolBar.LoadBitmap( IDB_BITMAP_MAIN ) ||
		!m_wndToolBar.SetButtons( mainId, sizeof(mainId)/sizeof(UINT)))
	{
		TRACE0("Failed to create resourcebar\n");
		return -1;      // fail to create
	}

	if (!m_wndPlayBar.Create(this, WS_CHILD | WS_VISIBLE | CBRS_SIZE_FIXED |
		CBRS_TOP |CBRS_TOOLTIPS | CBRS_FLYBY, IDR_TOOLBAR_PLAY ) ||
		!m_wndPlayBar.LoadBitmap( IDB_BITMAP_PLAY ) ||
		!m_wndPlayBar.SetButtons( playId, sizeof(playId)/sizeof(UINT)))
	{
		TRACE0("Failed to create resourcebar\n");
		return -1;      // fail to create
	}

	CRect rect(-100, -100, 0, 0);
	if (!m_wndStepBox.Create(WS_CHILD |CBS_DROPDOWNLIST|
		CBS_AUTOHSCROLL | WS_VSCROLL | CBS_HASSTRINGS, rect, &m_wndPlayBar,
		IDC_STEPBOX))
	{
		return -1;
	}
	m_wndPlayBar.SetButtonInfo(5, IDC_STEPBOX, TBBS_SEPARATOR, 100);
	if (m_wndStepBox.m_hWnd != NULL)
	{
		CRect rect;
		m_wndPlayBar.GetItemRect(5, rect);
		
		m_wndStepBox.SetWindowPos(NULL, rect.left, rect.top, 0, 0, SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSIZE|SWP_NOCOPYBITS);
		m_wndStepBox.ShowWindow(SW_SHOW);
	}
	else
		return -1;

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.SetWindowText(_T("ͨ�ù���"));
	m_wndToolBar.EnableDocking( CBRS_ALIGN_ANY );
	m_wndPlayBar.SetWindowText(_T("���⹤��"));
	m_wndPlayBar.EnableDocking( CBRS_ALIGN_TOP|CBRS_ALIGN_BOTTOM );
	
	EnableDocking( CBRS_ALIGN_ANY );

	DockControlBar( &m_wndToolBar,AFX_IDW_DOCKBAR_TOP);
	DockControlBarLeftOf(&m_wndPlayBar,&m_wndToolBar);

	LoadBarState(_T("General"));

	// TODO: Add your specialized creation code here
	return 0;
}

 void CMainFrame::DockControlBarLeftOf(CToolBar* Bar,CToolBar* LeftOf)
{
	CRect rect;
	DWORD dw;
	UINT n;

	// get MFC to adjust the dimensions of all docked ToolBars
	// so that GetWindowRect will be accurate
	RecalcLayout();
	LeftOf->GetWindowRect(&rect);
	rect.OffsetRect(1,0);
	dw=LeftOf->GetBarStyle();
	n = 0;
	n = (dw&CBRS_ALIGN_TOP) ? AFX_IDW_DOCKBAR_TOP : n;
	n = (dw&CBRS_ALIGN_BOTTOM && n==0) ? AFX_IDW_DOCKBAR_BOTTOM : n;
	n = (dw&CBRS_ALIGN_LEFT && n==0) ? AFX_IDW_DOCKBAR_LEFT : n;
	n = (dw&CBRS_ALIGN_RIGHT && n==0) ? AFX_IDW_DOCKBAR_RIGHT : n;

	// When we take the default parameters on rect, DockControlBar will dock
	// each Toolbar on a seperate line.  By calculating a rectangle, we in effect
	// are simulating a Toolbar being dragged to that location and docked.
	DockControlBar(Bar,n,&rect);
}

LRESULT CMainFrame::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	if( message == WM_CLOSE )
	{
		CExitDlg dlg;
		if( dlg.DoModal() != IDOK )
			return FALSE;
	}
	return CFrameWnd::WindowProc(message, wParam, lParam);
}

void CMainFrame::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	SaveBarState(_T("General"));	

	WINDOWPLACEMENT wp;
	wp.length = sizeof wp;
//	WriteGameParam( m_Five );
	if (GetWindowPlacement(&wp))
	{
		wp.flags = 0;
		if (IsZoomed())
			wp.flags |= WPF_RESTORETOMAXIMIZED;
		// and write it to the .INI file
		WriteWindowPlacement(&wp);
	}

	CFrameWnd::OnClose();
}

void CMainFrame::OnParamSet() 
{
	// TODO: Add your command handler code here
	CSetDlg d;
	d.WF0_1 = m_Five.GetDump(1,0);
	d.WF0_2 = m_Five.GetDump(2,0);
	d.WF0_3 = m_Five.GetDump(3,0);
	d.WF0_4 = m_Five.GetDump(4,0);
	d.WF1_1 = m_Five.GetDump(1,1);
	d.WF1_2 = m_Five.GetDump(2,1);
	d.WF1_3 = m_Five.GetDump(3,1);
	d.WF1_4 = m_Five.GetDump(4,1);
	d.WF2_3 = m_Five.GetDump(3,2);
	d.WF2_4 = m_Five.GetDump(4,2);
	d.WF5   = m_Five.GetDump(5,5);
	m_Five.GetParam( d.Breadth,d.Deep,d.Thread,d.Delta );

	if( d.DoModal() == IDOK )
	{
	    m_Five.SetDump(1,0,d.WF0_1);
	    m_Five.SetDump(2,0,d.WF0_2);
	    m_Five.SetDump(3,0,d.WF0_3);
	    m_Five.SetDump(4,0,d.WF0_4);
	    m_Five.SetDump(1,1,d.WF1_1);
	    m_Five.SetDump(2,1,d.WF1_2);
	    m_Five.SetDump(3,1,d.WF1_3);
	    m_Five.SetDump(4,1,d.WF1_4);
	    m_Five.SetDump(3,2,d.WF2_3);
	    m_Five.SetDump(4,2,d.WF2_4);
	    m_Five.SetDump(5,5,d.WF5);
	    m_Five.SetParam( d.Breadth,d.Deep,d.Thread,d.Delta );
		WriteGameParam( m_Five );
	}
}

void CMainFrame::OnViewToolbar1() 
{
	// TODO: Add your command handler code here
	if( m_wndPlayBar.GetStyle()&WS_VISIBLE )
	{
		ShowControlBar( &m_wndPlayBar,FALSE,FALSE );
	}
	else
	{
		ShowControlBar( &m_wndPlayBar,TRUE,FALSE );
	}
}

void CMainFrame::OnUpdateViewToolbar1(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if( m_wndPlayBar.GetStyle()&WS_VISIBLE )
	{
		pCmdUI->SetCheck( 1 );
	}
	else
	{
		pCmdUI->SetCheck( 0 );
	}	
}


void CMainFrame::OnButtonHui() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnViewToolbar() 
{
	// TODO: Add your command handler code here
	if( m_wndToolBar.GetStyle()&WS_VISIBLE )
	{
		ShowControlBar( &m_wndToolBar,FALSE,FALSE );
	}
	else
	{
		ShowControlBar( &m_wndToolBar,TRUE,FALSE );
	}
}

void CMainFrame::OnUpdateViewToolbar(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if( m_wndToolBar.GetStyle()&WS_VISIBLE )
	{
		pCmdUI->SetCheck( 1 );
	}
	else
	{
		pCmdUI->SetCheck( 0 );
	}		
}

void CMainFrame::OnButtonDin() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnButtonQian() 
{
	// TODO: Add your command handler code here
	
}

void CMainFrame::OnButtonXia() 
{
	// TODO: Add your command handler code here
	
}
