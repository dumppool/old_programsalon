#ifndef GAME_H
#define GAME_H
#include <afxwin.h>
#include <afxtempl.h>
#include <afxmt.h>
#define FIVE_MAX_LINE 15
#define WZQ_I     2435
#define WZQ_PING  WZQ_I + 1
#define WZQ_ERROR WZQ_I + 2
#define WZQ_YOU   WZQ_I + 3
#define WZQ_RUN   WZQ_I + 4

/////////////////////////////////////////////////////////////////////////////
// CFive used for app
struct Step
{
		int  m;
		int  n;
		char side;
};
struct Count
{
		Step step;
		double count;
};

class CFive:public CWinThread
{
protected:
	static int WF1_1;
	static int WF1_2;
	static int WF1_3;
	static int WF1_4;
	static int WF0_1;
	static int WF0_2;
	static int WF0_3;
	static int WF0_4;
	static int WF2_3;
	static int WF2_4;
	static int WF5;
	static int DeepMax;
	static int ThreadDeepMax;
	static int BreadthMax;
	static int Delta;

	static char FiveArea[FIVE_MAX_LINE][FIVE_MAX_LINE];
	static CList<Step,Step> StepList;
	static CList<Count,Count> TempDeepList;

    int CurDeep;
	int CurThreadDeep;
	int CurBreadth;
	double CurCount;
	char CurSide;
	CList<Count,Count> CountList;
	CList<Step,Step>   DeepList;

public:
	enum LEVE
	   {  COUNT_INC,  //ʹ�����������������
		  COUNT_SUB,  //ʹ�ǲ����������������
		  COUNT_MID,  //ƽ��
		};

protected:
	virtual int Dump( int Num,int Wflag );
	virtual long SreachLine( char *Line,int Num,char Side );
	virtual long SreachArea( char  Area[][FIVE_MAX_LINE],char NF );
    virtual void CalRun( char Nf,LEVE leve );
	virtual void ThreadRun();
	void    AddDeepList( Step step );
	Step    GetLastDeepList();
	double  GetStepCount();
public:
	CEvent  EndEvent;
	CFive( char side = 'B' );
	CFive( char side,int deep,int breadth,int threaddeep );
	~CFive();
	void WzqInit( char side,BOOL flags = TRUE  );
	void SetDump( int Num,int Wflag,int count );
	int  GetDump( int Num,int Wflag );
	void SetParam( int breadth,int deep,int thread,int delta );
	void GetParam( int& breadth,int& deep,int& thread,int& delta );
	int  WzqRun( int &m,int &n );
	void Serialize( CArchive& ar );
	BOOL InitInstance();
	DECLARE_SERIAL( CFive )
};

#endif
