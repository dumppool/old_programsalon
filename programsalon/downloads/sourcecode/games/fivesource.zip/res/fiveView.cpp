// fiveView.cpp : implementation of the CFiveView class
//

#include "stdafx.h"
#include "five.h"

#include "fiveDoc.h"
#include "fiveView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFiveView

IMPLEMENT_DYNCREATE(CFiveView, CView)

BEGIN_MESSAGE_MAP(CFiveView, CView)
	//{{AFX_MSG_MAP(CFiveView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFiveView construction/destruction

CFiveView::CFiveView()
{
	// TODO: add construction code here

}

CFiveView::~CFiveView()
{
}

BOOL CFiveView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CFiveView drawing

void CFiveView::OnDraw(CDC* pDC)
{
	CFiveDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CFiveView diagnostics

#ifdef _DEBUG
void CFiveView::AssertValid() const
{
	CView::AssertValid();
}

void CFiveView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CFiveDoc* CFiveView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFiveDoc)));
	return (CFiveDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFiveView message handlers


