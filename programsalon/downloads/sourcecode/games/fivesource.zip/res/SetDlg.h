// SetDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetDlg dialog

class CSetDlg : public CDialog
{
// Construction
public:
	CSetDlg(CWnd* pParent = NULL);   // standard constructor
	int WF0_1,WF0_2,WF0_3,WF0_4;
	int WF1_1,WF1_2,WF1_3,WF1_4;
	int WF2_3,WF2_4,WF5;
	int Deep,Breadth,Thread,Delta;

// Dialog Data
	//{{AFX_DATA(CSetDlg)
	enum { IDD = IDD_DIALOG_SET };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSetDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnSetReset();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
