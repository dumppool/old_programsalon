// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//
#ifndef _FIVE_HPP
#define _FIVE_HPP
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
class CFive;
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
//#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows 95 Common Controls
//#endif // _AFX_NO_AFXCMN_SUPPORT
#include <afxmt.h>
#include "game.h"
#include "five.h"
#include "NewDlg.h"
#include "MainFrm.h"
#include "FiveDoc.h"
#include "FiveView.h"
#include "CountDlg.h"
#include "ErrorDlg.h"
#include "HelpDlg.h"
#include "SetDlg.h"
#include "ExitDlg.h"

#endif



