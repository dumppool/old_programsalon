// fiveDoc.h : interface of the CFiveDoc class
//
/////////////////////////////////////////////////////////////////////////////

class CFiveDoc : public CDocument
{
protected: // create from serialization only
	CFiveDoc();
	DECLARE_DYNCREATE(CFiveDoc)
	static BOOL m_DocWb;
	static BOOL m_DocXuan;
	static BOOL m_OnOff;

// Attributes
public:
	CFive *m_pFive;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFiveDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void ReportSaveLoadException(LPCTSTR lpszPathName, CException* e, BOOL bSaving, UINT nIDPDefault);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFiveDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFiveDoc)
	afx_msg void OnUpdateSetShownew(CCmdUI* pCmdUI);
	afx_msg void OnSetShownew();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
