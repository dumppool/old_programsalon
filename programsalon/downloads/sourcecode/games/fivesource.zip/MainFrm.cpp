// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
CFiveApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
static UINT BASED_CODE indicators[] =
{
	ID_SEPARATOR,           // status line indicator
//	ID_INDICATOR_CAPS,
//	ID_INDICATOR_NUM,
//	ID_INDICATOR_SCRL,
	ID_JINGDU,
	ID_THREAD_COUNT,
    ID_MEMORY_COUNT,
	ID_SEPARATOR,           // status line indicator
};

static UINT BASED_CODE playId[] =
{       
	    ID_BUTTON_HUI,
		ID_BUTTON_DIN,
		ID_BUTTON_QIAN,
		ID_BUTTON_XIA,
		ID_BUTTON_JIN,
		ID_BUTTON_KILL,
	    ID_SEPARATOR,           // status line indicator
		ID_SEPARATOR,
		IDC_STEPBOX,
};

static UINT BASED_CODE mainId[] =
{
	ID_FILE_NEW,
    ID_FILE_OPEN,
	ID_FILE_SAVE,
	ID_SEPARATOR,           // status line indicator
	ID_APP_ABOUT,
};

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
    ON_CBN_SETFOCUS( IDC_STEPBOX,OnStepBox )
    ON_CBN_DROPDOWN( IDC_STEPBOX,OnStepBox )
	ON_COMMAND(ID_PARAM_SET, OnParamSet)
	ON_COMMAND(ID_VIEW_TOOLBAR1, OnViewToolbar1)
	ON_UPDATE_COMMAND_UI(ID_VIEW_TOOLBAR1, OnUpdateViewToolbar1)
	ON_COMMAND(ID_BUTTON_HUI, OnButtonHui)
	ON_COMMAND(ID_VIEW_TOOLBAR, OnViewToolbar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_TOOLBAR, OnUpdateViewToolbar)
	ON_COMMAND(ID_BUTTON_DIN, OnButtonDin)
	ON_COMMAND(ID_BUTTON_QIAN, OnButtonQian)
	ON_COMMAND(ID_BUTTON_XIA, OnButtonXia)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_DIN, OnUpdateButtonDin)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_HUI, OnUpdateButtonHui)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_QIAN, OnUpdateButtonQian)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_XIA, OnUpdateButtonXia)
	ON_UPDATE_COMMAND_UI(ID_PARAM_SET, OnUpdateParamSet)
	ON_COMMAND(ID_BUTTON_JIN, OnButtonJin)
	ON_COMMAND(ID_BUTTON_KILL, OnButtonKill)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_KILL, OnUpdateButtonKill)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_JIN, OnUpdateButtonJin)
	ON_UPDATE_COMMAND_UI(ID_FILE_NEW-1, OnUpdateFile)
	ON_UPDATE_COMMAND_UI(ID_FILE_NEW, OnUpdateFileNew)
	ON_UPDATE_COMMAND_UI(ID_FILE_OPEN, OnUpdateFileOpen)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	//}}AFX_MSG_MAP
//	ON_WM_SIZING()
END_MESSAGE_MAP()

static TCHAR BASED_CODE szSection[] = _T("Settings");
static TCHAR BASED_CODE szWindowPos[] = _T("WindowPos");
static TCHAR BASED_CODE szDump[] = _T("Dump");
static TCHAR BASED_CODE szSreach[] = _T("Sreach");

static TCHAR szFormat[] = _T("%u,%u,%d,%d,%d,%d,%d,%d,%d,%d");
static TCHAR szDumpFormat[] = _T("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d");
static TCHAR szSreachFormat[] = _T("%d,%d,%d,%d");

static void ReadGameParam( CFive& f )
{
	int WF0_1,WF0_2,WF0_3,WF0_4;
	int WF1_1,WF1_2,WF1_3,WF1_4;
	int WF2_3,WF2_4,WF5;
	int Deep,Breadth,Thread,Delta;
	CString strBuffer;
	TCHAR Def[250];
	wsprintf( Def,szDumpFormat,2,50,500,5000,1,20,150,600,400,450,30000 );
	strBuffer = AfxGetApp()->GetProfileString(szSection, szDump,Def );
	_stscanf( strBuffer,szDumpFormat,&WF0_1,&WF0_2,&WF0_3,&WF0_4,
		&WF1_1,&WF1_2,&WF1_3,&WF1_4,&WF2_3,&WF2_4,&WF5 );
	f.SetDump(1,1,WF0_1);
	f.SetDump(2,1,WF0_2);
	f.SetDump(3,1,WF0_3);
	f.SetDump(4,1,WF0_4);
	f.SetDump(1,0,WF1_1);
	f.SetDump(2,0,WF1_2);
	f.SetDump(3,0,WF1_3);
	f.SetDump(4,0,WF1_4);
	f.SetDump(3,2,WF2_3);
	f.SetDump(4,2,WF2_4);
	f.SetDump(5,5,WF5);
	wsprintf( Def,szSreachFormat,10,4,0,2 );
	strBuffer = AfxGetApp()->GetProfileString(szSection,szSreach,Def );
	_stscanf( strBuffer,szSreachFormat,&Breadth,&Deep,&Thread,&Delta );
	f.SetParam( Breadth,Deep,Thread,Delta );
}

static void WriteGameParam( CFive& f )
{
	int WF0_1,WF0_2,WF0_3,WF0_4;
	int WF1_1,WF1_2,WF1_3,WF1_4;
	int WF2_3,WF2_4,WF5;
	int Deep,Breadth,Thread,Delta;
	TCHAR Buf[250];
	WF0_1 = f.GetDump(1,1);
	WF0_2 = f.GetDump(2,1);
	WF0_3 = f.GetDump(3,1);
	WF0_4 = f.GetDump(4,1);
	WF1_1 = f.GetDump(1,0);
	WF1_2 = f.GetDump(2,0);
	WF1_3 = f.GetDump(3,0);
	WF1_4 = f.GetDump(4,0);
	WF2_3 = f.GetDump(3,2);
	WF2_4 = f.GetDump(4,2);
	WF5   = f.GetDump(5,5);

	wsprintf( Buf,szDumpFormat,WF0_1,WF0_2,WF0_3,WF0_4,
		WF1_1,WF1_2,WF1_3,WF1_4,WF2_3,WF2_4,WF5 );
	AfxGetApp()->WriteProfileString( szSection,szDump,Buf );
	f.GetParam( Breadth,Deep,Thread,Delta );
	wsprintf( Buf,szSreachFormat,Breadth,Deep,Thread,Delta );
	AfxGetApp()->WriteProfileString( szSection,szSreach,Buf );
}

static BOOL PASCAL NEAR ReadWindowPlacement(LPWINDOWPLACEMENT pwp)
{
	CString strBuffer = AfxGetApp()->GetProfileString(szSection, szWindowPos);
	if (strBuffer.IsEmpty())
		return FALSE;

	WINDOWPLACEMENT wp;
	int nRead = _stscanf(strBuffer, szFormat,
		&wp.flags, &wp.showCmd,
		&wp.ptMinPosition.x, &wp.ptMinPosition.y,
		&wp.ptMaxPosition.x, &wp.ptMaxPosition.y,
		&wp.rcNormalPosition.left, &wp.rcNormalPosition.top,
		&wp.rcNormalPosition.right, &wp.rcNormalPosition.bottom);

	if (nRead != 10)
		return FALSE;

	wp.length = sizeof wp;
	*pwp = wp;
	return TRUE;
}

static void PASCAL NEAR WriteWindowPlacement(LPWINDOWPLACEMENT pwp)
	// write a window placement to settings section of app's ini file
{
	TCHAR szBuffer[sizeof("-32767")*8 + sizeof("65535")*2];

	wsprintf(szBuffer, szFormat,
		pwp->flags, pwp->showCmd,
		pwp->ptMinPosition.x, pwp->ptMinPosition.y,
		pwp->ptMaxPosition.x, pwp->ptMaxPosition.y,
		pwp->rcNormalPosition.left, pwp->rcNormalPosition.top,
		pwp->rcNormalPosition.right, pwp->rcNormalPosition.bottom);
	AfxGetApp()->WriteProfileString(szSection, szWindowPos, szBuffer);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.style &= ~FWS_ADDTOTITLE;

	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


 int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	ReadGameParam( m_Five );

	WINDOWPLACEMENT wp;
	if (ReadWindowPlacement(&wp))
		SetWindowPlacement(&wp);

	if (!m_wndToolBar.Create(this, WS_CHILD | WS_VISIBLE | CBRS_SIZE_DYNAMIC |
			CBRS_TOP |CBRS_TOOLTIPS | CBRS_FLYBY, IDR_TOOLBAR_MAIN ) ||
		!m_wndToolBar.LoadBitmap( IDB_BITMAP_MAIN ) ||
		!m_wndToolBar.SetButtons( mainId, sizeof(mainId)/sizeof(UINT)))
	{
		TRACE0("Failed to create resourcebar\n");
		return -1;      // fail to create
	}

	if (!m_wndPlayBar.Create(this, WS_CHILD | WS_VISIBLE | CBRS_SIZE_FIXED |
		CBRS_TOP |CBRS_TOOLTIPS | CBRS_FLYBY, IDR_TOOLBAR_PLAY ) ||
		!m_wndPlayBar.LoadBitmap( IDB_BITMAP_PLAY ) ||
		!m_wndPlayBar.SetButtons( playId, sizeof(playId)/sizeof(UINT)))
	{
		TRACE0("Failed to create resourcebar\n");
		return -1;      // fail to create
	}

	CRect rect(-100, -100, 0, 0);
	if (!m_wndStepBox.Create(WS_CHILD |CBS_DROPDOWNLIST|
		CBS_AUTOHSCROLL | WS_VSCROLL | CBS_HASSTRINGS, rect, &m_wndPlayBar,
		IDC_STEPBOX))
	{
		return -1;
	}
	m_wndPlayBar.SetButtonInfo(8, IDC_STEPBOX, TBBS_SEPARATOR, 100);
	if (m_wndStepBox.m_hWnd != NULL)
	{
		CRect rect;
		m_wndPlayBar.GetItemRect(8, rect);
		
		m_wndStepBox.SetWindowPos(NULL, rect.left, rect.top, 0, 0, SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSIZE|SWP_NOCOPYBITS);
		m_wndStepBox.ShowWindow(SW_SHOW);
	}
	else
		return -1;

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	SIZE size = {18,18};
	SIZE siz  = { 25,25 };
	m_wndToolBar.SetSizes( siz,size );
	m_wndPlayBar.SetSizes( siz,size );

	m_wndToolBar.SetWindowText(_T("ͨ�ù���"));
	m_wndToolBar.EnableDocking( CBRS_ALIGN_ANY );
	m_wndPlayBar.SetWindowText(_T("���⹤��"));
	m_wndPlayBar.EnableDocking( CBRS_ALIGN_TOP|CBRS_ALIGN_BOTTOM );
	
	EnableDocking( CBRS_ALIGN_ANY );

	DockControlBar( &m_wndToolBar,AFX_IDW_DOCKBAR_TOP);
	DockControlBarLeftOf(&m_wndPlayBar,&m_wndToolBar);

	LoadBarState(_T("General"));

	CFiveView *pView;
	CRect re;
	int W,H,W1,H1,dw,dh;
	pView = (CFiveView*)GetActiveView();
	if( pView )
	{
		pView -> GetWindowRect(&rect);
		GetWindowRect(&re);
		W = rect.right-rect.left;
		H = rect.bottom-rect.top;
		W1 = re.right-re.left;
		H1 = re.bottom-re.top;
		dw = W1 - W1;
		dh = H1 - H1;
		re.bottom = re.top + dh + re.right - re.left - dw;
		MoveWindow(&re,TRUE);
	}
	// TODO: Add your specialized creation code here
	//m_wndStatusBar.SetPaneText(1,"35%" );
	//m_wndStatusBar.SetPaneText(2,"1.25Mb" );
	//SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_MAIN));
	//ShowCursor( TRUE );
	//m_wndStatusBar.SetPaneText(3,"450");
	CFive five;
	five.SetInfo( &m_wndStatusBar );
	return 0;
}

 CComboBox* CMainFrame::GetListBox()
 {
	 return &m_wndStepBox;
 }

 void CMainFrame::DockControlBarLeftOf(CToolBar* Bar,CToolBar* LeftOf)
{
	CRect rect;
	DWORD dw;
	UINT n;

	// get MFC to adjust the dimensions of all docked ToolBars
	// so that GetWindowRect will be accurate
	RecalcLayout();
	LeftOf->GetWindowRect(&rect);
	rect.OffsetRect(1,0);
	dw=LeftOf->GetBarStyle();
	n = 0;
	n = (dw&CBRS_ALIGN_TOP) ? AFX_IDW_DOCKBAR_TOP : n;
	n = (dw&CBRS_ALIGN_BOTTOM && n==0) ? AFX_IDW_DOCKBAR_BOTTOM : n;
	n = (dw&CBRS_ALIGN_LEFT && n==0) ? AFX_IDW_DOCKBAR_LEFT : n;
	n = (dw&CBRS_ALIGN_RIGHT && n==0) ? AFX_IDW_DOCKBAR_RIGHT : n;

	// When we take the default parameters on rect, DockControlBar will dock
	// each Toolbar on a seperate line.  By calculating a rectangle, we in effect
	// are simulating a Toolbar being dragged to that location and docked.
	DockControlBar(Bar,n,&rect);
}

LRESULT CMainFrame::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	if( message == WM_CLOSE )
	{
		CExitDlg dlg;
		if( dlg.DoModal() != IDOK )
			return FALSE;
	}
	return CFrameWnd::WindowProc(message, wParam, lParam);
}

void CMainFrame::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	SaveBarState(_T("General"));	

	WINDOWPLACEMENT wp;
	wp.length = sizeof wp;
//	WriteGameParam( m_Five );
	if (GetWindowPlacement(&wp))
	{
		wp.flags = 0;
		if (IsZoomed())
			wp.flags |= WPF_RESTORETOMAXIMIZED;
		// and write it to the .INI file
		WriteWindowPlacement(&wp);
	}

	CFrameWnd::OnClose();
}

void CMainFrame::OnStepBox()
{
	m_Five.InListBox( m_wndStepBox );
}

void CMainFrame::OnParamSet() 
{
	// TODO: Add your command handler code here
	CSetDlg d;
	d.WF0_1 = m_Five.GetDump(1,1);
	d.WF0_2 = m_Five.GetDump(2,1);
	d.WF0_3 = m_Five.GetDump(3,1);
	d.WF0_4 = m_Five.GetDump(4,1);
	d.WF1_1 = m_Five.GetDump(1,0);
	d.WF1_2 = m_Five.GetDump(2,0);
	d.WF1_3 = m_Five.GetDump(3,0);
	d.WF1_4 = m_Five.GetDump(4,0);
	d.WF2_3 = m_Five.GetDump(3,2);
	d.WF2_4 = m_Five.GetDump(4,2);
	d.WF5   = m_Five.GetDump(5,5);
	m_Five.GetParam( d.Breadth,d.Deep,d.Thread,d.Delta );

	if( d.DoModal() == IDOK )
	{
	    m_Five.SetDump(1,0,d.WF1_1);
	    m_Five.SetDump(2,0,d.WF1_2);
	    m_Five.SetDump(3,0,d.WF1_3);
	    m_Five.SetDump(4,0,d.WF1_4);
	    m_Five.SetDump(1,1,d.WF0_1);
	    m_Five.SetDump(2,1,d.WF0_2);
	    m_Five.SetDump(3,1,d.WF0_3);
	    m_Five.SetDump(4,1,d.WF0_4);
	    m_Five.SetDump(3,2,d.WF2_3);
	    m_Five.SetDump(4,2,d.WF2_4);
	    m_Five.SetDump(5,5,d.WF5);
	    m_Five.SetParam( d.Breadth,d.Deep,d.Thread,d.Delta );
		WriteGameParam( m_Five );
	}
}

void CMainFrame::OnViewToolbar1() 
{
	// TODO: Add your command handler code here
	if( m_wndPlayBar.GetStyle()&WS_VISIBLE )
	{
		ShowControlBar( &m_wndPlayBar,FALSE,FALSE );
	}
	else
	{
		ShowControlBar( &m_wndPlayBar,TRUE,FALSE );
	}
}

void CMainFrame::OnUpdateViewToolbar1(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if( m_wndPlayBar.GetStyle()&WS_VISIBLE )
	{
		pCmdUI->SetCheck( 1 );
	}
	else
	{
		pCmdUI->SetCheck( 0 );
	}	
}


void CMainFrame::OnButtonHui() 
{
	// TODO: Add your command handler code here
	CFive five;
	CFiveView *mpView;
	if(five.HuiOneStep()==FALSE)
	{
		MessageBeep(0);
		return;
	}
	five.InListBox( m_wndStepBox );
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	mpView->Invalidate(FALSE);
	mpView->UpdateWindow();
}

void CMainFrame::OnViewToolbar() 
{
	// TODO: Add your command handler code here
	if( m_wndToolBar.GetStyle()&WS_VISIBLE )
	{
		ShowControlBar( &m_wndToolBar,FALSE,FALSE );
	}
	else
	{
		ShowControlBar( &m_wndToolBar,TRUE,FALSE );
	}
}

void CMainFrame::OnUpdateViewToolbar(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if( m_wndToolBar.GetStyle()&WS_VISIBLE )
	{
		pCmdUI->SetCheck( 1 );
	}
	else
	{
		pCmdUI->SetCheck( 0 );
	}		
}

void CMainFrame::OnButtonDin() 
{
	// TODO: Add your command handler code here
	CFive five;
	CFiveView *mpView;
	if(five.BackEndStep()==FALSE)
	{
		MessageBeep(0);
		return;
	}
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	mpView->Invalidate(FALSE);
	mpView->UpdateWindow();	
}

void CMainFrame::OnButtonQian() 
{
	// TODO: Add your command handler code here
	CFive five;
	CFiveView *mpView;
	if(five.BackOneStep()==FALSE)
	{
		MessageBeep(0);
		return;
	}
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	mpView->Invalidate(FALSE);
	mpView->UpdateWindow();	
}

void CMainFrame::OnButtonXia() 
{
	// TODO: Add your command handler code here	
	CFive five;
	CFiveView *mpView;
	if(five.FowardOneStep()==FALSE)
	{
		MessageBeep(0);
		return;
	}
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	mpView->Invalidate(FALSE);
	mpView->UpdateWindow();
}


void CMainFrame::OnUpdateButtonDin(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnUpdateButtonHui(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnUpdateButtonQian(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnUpdateButtonXia(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnUpdateParamSet(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnButtonJin() 
{
	// TODO: Add your command handler code here
	CFive five;
	CFiveView *mpView;
	if(five.OneStep()==FALSE)
	{
		MessageBeep(0);
		return;
	}
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	mpView->Invalidate(FALSE);
	mpView->UpdateWindow();	
}

void CMainFrame::OnButtonKill() 
{
	// TODO: Add your command handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	mpView->m_pFive->KillWzqThread();
	mpView->Invalidate(FALSE);
	mpView->UpdateWindow();	

	delete mpView -> m_pFive;
	mpView -> m_pFive = NULL;
}

void CMainFrame::OnUpdateButtonKill(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( FALSE );
	else
		pCmdUI->Enable( TRUE );		
}

void CMainFrame::OnUpdateButtonJin(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );		
}

void CMainFrame::OnUpdateFileNew(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );				
}

void CMainFrame::OnUpdateFileOpen(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );			
}

void CMainFrame::OnUpdateFileSave(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );			
}

void CMainFrame::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnUpdateFile( CCmdUI* pCmdUI )
{
	CFiveView *mpView;
	mpView = (CFiveView*)GetActiveView();
	if( mpView == NULL )
		return;
	if( !mpView -> IsKindOf( RUNTIME_CLASS( CFiveView)))
		return;
	if( mpView -> m_pFive == NULL )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );			
}