// IsRuning.h : header file
//

#ifndef _CISRUNG_H
#define _CISRUNG_H

/////////////////////////////////////////////////////////////////////////////
// CIsRuning thread

class CIsRuning : public CWinThread
{
	DECLARE_DYNCREATE(CIsRuning)
public:
	CIsRuning();           // protected constructor used by dynamic creation
// Attributes
public:
	CFiveView *pView;
	static int CurM;
	static int CurN;
	void SetpView( CFiveView* p );
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIsRuning)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CIsRuning();

	// Generated message map functions
	//{{AFX_MSG(CIsRuning)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};
#endif
/////////////////////////////////////////////////////////////////////////////
