// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////
class CMainFrame : public CFrameWnd
{
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)
    void DockControlBarLeftOf(CToolBar* Bar,CToolBar* LeftOf);

// Attributes
public:
	CFive m_Five;
	CComboBox* GetListBox();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CToolBar    m_wndPlayBar;

	CComboBox   m_wndStepBox;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnStepBox();
	afx_msg void OnParamSet();
	afx_msg void OnViewToolbar1();
	afx_msg void OnUpdateViewToolbar1(CCmdUI* pCmdUI);
	afx_msg void OnButtonHui();
	afx_msg void OnViewToolbar();
	afx_msg void OnUpdateViewToolbar(CCmdUI* pCmdUI);
	afx_msg void OnButtonDin();
	afx_msg void OnButtonQian();
	afx_msg void OnButtonXia();
	afx_msg void OnUpdateButtonDin(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonHui(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonQian(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonXia(CCmdUI* pCmdUI);
	afx_msg void OnUpdateParamSet(CCmdUI* pCmdUI);
	afx_msg void OnButtonJin();
	afx_msg void OnButtonKill();
	afx_msg void OnUpdateButtonKill(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonJin(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileNew(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileSave(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
    afx_msg void CMainFrame::OnUpdateFile(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
