// fiveDoc.cpp : implementation of the CFiveDoc class
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
/////////////////////////////////////////////////////////////////////////////
BOOL CFiveDoc::m_DocWb  = 1;
BOOL CFiveDoc::m_DocXuan= 1;
BOOL CFiveDoc::m_OnOff  = 1;

/////////////////////////////////////////////////////////////////////////////
// CFiveDoc

IMPLEMENT_DYNCREATE(CFiveDoc, CDocument)

BEGIN_MESSAGE_MAP(CFiveDoc, CDocument)
	//{{AFX_MSG_MAP(CFiveDoc)
	ON_UPDATE_COMMAND_UI(ID_SET_SHOWNEW, OnUpdateSetShownew)
	ON_COMMAND(ID_SET_SHOWNEW, OnSetShownew)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFiveDoc construction/destruction

CFiveDoc::CFiveDoc()
{
	// TODO: add one-time construction code here

}

CFiveDoc::~CFiveDoc()
{
}

BOOL CFiveDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	CFive five;
	if( m_OnOff == 0 )
	{
		CNewDlg dlg(AfxGetMainWnd());
		if( dlg.DoModal() == IDCANCEL )
			return FALSE;
	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
		if( dlg.m_Wb )
			five.WzqInit( 'W',dlg.m_Xian );
		else
			five.WzqInit( 'B',dlg.m_Xian );
		m_OnOff   = dlg.m_Check;
		m_DocWb   = dlg.m_Wb;
		m_DocXuan = dlg.m_Xian;
	}
	else
	{
		if( m_DocWb )
			five.WzqInit( 'W',m_DocXuan );
		else
			five.WzqInit( 'B',m_DocXuan );
	}
	POSITION pos;
	CFiveView* p;
	pos = GetFirstViewPosition();
	p = (CFiveView*)GetNextView( pos );
	p -> m_Flags = TRUE;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CFiveDoc serialization

void CFiveDoc::Serialize(CArchive& ar)
{
	CFive five;
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
	five.Serialize( ar );
}

/////////////////////////////////////////////////////////////////////////////
// CFiveDoc diagnostics

#ifdef _DEBUG
void CFiveDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CFiveDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFiveDoc commands

void CFiveDoc::ReportSaveLoadException(LPCTSTR lpszPathName, CException* e, BOOL bSaving, UINT nIDPDefault) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(e->IsKindOf( RUNTIME_CLASS( CFileException )))
	{
		if(((CFileException*)e)->m_cause==CFileException::accessDenied)
		{
		    POSITION pos;
		    pos = GetFirstViewPosition();
			CErrorDlg Dlg(GetNextView(pos));
			Dlg.Name = lpszPathName;
			Dlg.Info = "����һ�������� 3.0�ļ�";
			Dlg.DoModal();
			return;
		}
	}
	CDocument::ReportSaveLoadException(lpszPathName, e, bSaving, nIDPDefault);
}

void CFiveDoc::OnUpdateSetShownew(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if( m_OnOff == 0 )
	{
		pCmdUI->SetCheck(1);
	}
	else
	{
		pCmdUI->SetCheck(0);
	}
}

void CFiveDoc::OnSetShownew() 
{
	// TODO: Add your command handler code here
	if( m_OnOff == 0 )
		m_OnOff = 1;
	else
		m_OnOff = 0;
}
