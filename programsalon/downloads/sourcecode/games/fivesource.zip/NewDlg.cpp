// NewDlg.cpp : implementation file
//
#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewDlg dialog
BOOL CNewDlg::m_Xian = TRUE;
BOOL CNewDlg::m_Wb = TRUE;
int  CNewDlg::m_Check = 1;

CNewDlg::CNewDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNewDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewDlg)
	//}}AFX_DATA_INIT
}


void CNewDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewDlg)
	DDX_Control(pDX, IDC_CHECK1, m_Checkbar);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewDlg, CDialog)
	//{{AFX_MSG_MAP(CNewDlg)
	ON_BN_CLICKED(IDC_RADIO_BLACK, OnRadioBlack)
	ON_BN_CLICKED(IDC_RADIO_WHITE, OnRadioWhite)
	ON_BN_CLICKED(IDC_RADIO_XIAN, OnRadioXian)
	ON_BN_CLICKED(IDC_RADIO_HUO, OnRadioHuo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewDlg message handlers

BOOL CNewDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	if( m_Xian == TRUE )
	{
		CheckDlgButton(IDC_RADIO_XIAN,1);
		CheckDlgButton(IDC_RADIO_HUO,0);
	}
	else
	{
		CheckDlgButton(IDC_RADIO_XIAN,0);
		CheckDlgButton(IDC_RADIO_HUO,1);
	}

	if( m_Wb == TRUE )
	{
		CheckDlgButton(IDC_RADIO_WHITE,0);
		CheckDlgButton(IDC_RADIO_BLACK,1);
	}
	else
	{
		CheckDlgButton(IDC_RADIO_WHITE,1);
		CheckDlgButton(IDC_RADIO_BLACK,0);
	}
//	SetDlgItemInt(IDC_EDIT_LEVEL,m_Level ); 
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CNewDlg::OnOK() 
{
	// TODO: Add extra validation here
	m_Check = m_Checkbar.GetCheck();
	CDialog::OnOK();
}

void CNewDlg::OnRadioBlack() 
{
	// TODO: Add your control notification handler code here
	m_Wb = TRUE;
	if( m_Wb == TRUE )
	{
		CheckDlgButton(IDC_RADIO_WHITE,0);
		CheckDlgButton(IDC_RADIO_BLACK,1);
	}
	else
	{
		CheckDlgButton(IDC_RADIO_WHITE,1);
		CheckDlgButton(IDC_RADIO_BLACK,0);
	}
}

void CNewDlg::OnRadioWhite() 
{
	// TODO: Add your control notification handler code here
	m_Wb = FALSE;
	if( m_Wb == TRUE )
	{
		CheckDlgButton(IDC_RADIO_WHITE,0);
		CheckDlgButton(IDC_RADIO_BLACK,1);
	}
	else
	{
		CheckDlgButton(IDC_RADIO_WHITE,1);
		CheckDlgButton(IDC_RADIO_BLACK,0);
	}	
}

void CNewDlg::OnRadioXian() 
{
	// TODO: Add your control notification handler code here
	m_Xian = TRUE;
	if( m_Xian == TRUE )
	{
		CheckDlgButton(IDC_RADIO_XIAN,1);
		CheckDlgButton(IDC_RADIO_HUO,0);
	}
	else
	{
		CheckDlgButton(IDC_RADIO_XIAN,0);
		CheckDlgButton(IDC_RADIO_HUO,1);
	}
}

void CNewDlg::OnRadioHuo() 
{
	// TODO: Add your control notification handler code here
	m_Xian = FALSE;
	if( m_Xian == TRUE )
	{
		CheckDlgButton(IDC_RADIO_XIAN,1);
		CheckDlgButton(IDC_RADIO_HUO,0);
	}
	else
	{
		CheckDlgButton(IDC_RADIO_XIAN,0);
		CheckDlgButton(IDC_RADIO_HUO,1);
	}
}
