#include <windows.h>

// My music handling functions
void GetCDInfo(HWND);
void PlayCDMusic(void);
void PlayMidiMusic(void);
void PauseResumeMusic(void);
void PlayNextSong(void);
void StopMusic(void);

