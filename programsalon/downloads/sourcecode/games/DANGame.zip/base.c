#include<dos.h>
#include<stdio.h>
#include<stdlib.h>
unsigned char far *hzkbuffer0,*hzkbuffer1,*hzkbuffer2,*hzkbuffer3,*hzkbuffer4;
int outchinese(int x,int y,int dx,int color,char *str)
{
	  FILE *fp;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec,xx=x;
	long offset;
	char bit[32];
	char chinesedata[256];
	
	while(*str)
	{
		i=*str++;
		if(i==32)x+=16;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{
                                memset(chinesedata,0,256);
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
					case 4:memcpy(bit,&hzkbuffer4[offset],32);break;
				}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					chinesedata[(i1<<4)+(i2<<3)+i3]=color;
					for(i1=0;i1<16;i1++)
					drawlinedatamask(x,y+i1,16,&chinesedata[i1<<4],0);

					/*drawpixel(x+(i2<<3)+i3,y+i1,color);*/
			x+=16+dx;if(x>=768){x=xx;y+=20;}
		}
	}
}
return x;
}

int outchineseying(int x,int y,int dx,int color,int yingcolor,char *str,int ddx,int ddy)
{
	  FILE *fp;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec,xx=x;
	long offset;
	char bit[32];
	char chinesedata[256];
	while(*str)
	{
		i=*str++;
		if(i==32)x+=16;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{
				memset(chinesedata,0,256);
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
					case 4:memcpy(bit,&hzkbuffer4[offset],32);break;
				}
                                	for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					chinesedata[(i1<<4)+(i2<<3)+i3]=yingcolor;
					for(i1=0;i1<16;i1++)
					drawlinedatamask(x+ddx,y+i1+ddy,16,&chinesedata[i1<<4],0);
					for(i1=0;i1<256;i1++)
					if(chinesedata[i1]==yingcolor)chinesedata[i1]=color;

					for(i1=0;i1<16;i1++)
					drawlinedatamask(x,y+i1,16,&chinesedata[i1<<4],0);

					/*drawpixel(x+(i2<<3)+i3+ddx,y+i1+ddy,yingcolor);
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)*/

			x+=16+dx;if(x>=768){x=xx;y+=20;}
		}
	}
}
return x;
}
int outchinesekong(int x,int y,int dx,int color,char *str)
{
	  FILE *fp;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec,xx=x,tx,ty;
	long offset;
	char bit[32];
	while(*str)
	{
		i=*str++;
		if(i==32)x+=16;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
					case 4:memcpy(bit,&hzkbuffer4[offset],32);break;
				}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					{
						tx=x+(i2<<3)+i3;
						ty=y+i1;
						if(i1!=0&&((bit[((i1-1)<<1)+i2]>>(7-i3))&1));
						else drawpixel(tx,ty-1,color);/*up*/
						if(i1!=15&&((bit[((i1+1)<<1)+i2]>>(7-i3))&1));
						else drawpixel(tx,ty+1,color);/*down*/
						/*if(((i2<<3)+i3)!=0&&((bit[(i1<<1)+i2]>>(7-i3+1))&1));
						else*/ drawpixel(tx-1,ty,color);/*left*/
						if(((i2<<3)+i3)!=15&&((bit[(i1<<1)+i2]>>(7-i3-1))&1));
						else drawpixel(tx+1,ty,color);/*right*/
						if(((i2<<3)+i3)!=0&&i1!=0&&((bit[((i1-1)<<1)+i2]>>(7-i3+1))&1));
						else drawpixel(tx-1,ty-1,color);/*leftup*/
						if(((i2<<3)+i3)!=15&&i1!=15&&((bit[((i1+1)<<1)+i2]>>(7-i3-1))&1));
						else drawpixel(tx+1,ty+1,color);/*rightdown*/
						/*if(((i2<<3)+i3)!=0&&i1!=15&&((bit[((i1+1)<<1)+i2]>>(7-i3+1))&1));
						else*/ drawpixel(tx-1,ty+1,color);/*leftdown*/
						if(((i2<<3)+i3)!=15&&i1!=0&&((bit[((i1-1)<<1)+i2]>>(7-i3-1))&1));
						else drawpixel(tx+1,ty-1,color);/*rightup*/
					}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					drawpixel(x+(i2<<3)+i3,y+i1,0);
			x+=16+dx;if(x>=768){x=xx;y+=20;}
		}
	}
}
return x;
}
/*int outchinesekong (int x,int y,int dx,int color,char *str)
{
	  FILE *fp;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec,xx=x,tx,ty;
	long offset;
	char bit[32];
	char chinesedata[324];
	int kongaddr[18]={0,18,36,54,72,90,108,126,144,162,180,198,216,234,252,270,298,324};
	while(*str)
	{
		i=*str++;
		if(i==32)x+=16;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{

				memset(chinesedata,0,324);
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
					case 4:memcpy(bit,&hzkbuffer4[offset],32);break;
				}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					{
						tx=(i2<<3)+i3+1;
						ty=i1+1;
						chinesedata[tx+18*(ty-1)]=color;
						chinesedata[tx+18*(ty+1)]=color;
						chinesedata[tx+18*(ty)-1]=color;
						chinesedata[tx+18*(ty)+1]=color;
						chinesedata[tx+18*(ty-1)-1]=color;
						chinesedata[tx+18*(ty+1)+1]=color;
						chinesedata[tx+18*(ty+1)-1]=color;
						chinesedata[tx+18*(ty-1)+1]=color;
					}  */
					/*for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					chinesedata[((i1+1)<<4)+(i2<<3)+i3+1]=0;*/
					/*for(i1=0;i1<18;i1++)
					drawlinedatamask(x-1,y+i1-1,18,&chinesedata[i1*18],0);

			x+=16+dx;if(x>=768){x=xx;y+=20;}
		}
	}
}
return x;
}       */
/*int outchinesekong(int x,int y,int dx,int color,char *str)
{
	  FILE *fp;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec,xx=x,tx,ty;
	long offset;
	char bit[32];
	char chinesedata[324];
	int kongaddr[18]={0,18,36,54,72,90,108,126,144,162,180,198,216,234,252,270,298,324};
	while(*str)
	{
		i=*str++;
		if(i==32)x+=16;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{

				memset(chinesedata,0,324);
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
					case 4:memcpy(bit,&hzkbuffer4[offset],32);break;
				}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					{
						tx=(i2<<3)+i3;
						ty=i1;
						chinesedata[tx+kongaddr[ty-1]]=color;
						chinesedata[tx+kongaddr[ty+1]]=color;
						chinesedata[tx+kongaddr[ty]-1]=color;
						chinesedata[tx+kongaddr[ty]+1]=color;
						chinesedata[tx+kongaddr[ty-1]-1]=color;
						chinesedata[tx+kongaddr[ty+1]+1]=color;
						chinesedata[tx+kongaddr[ty+1]-1]=color;
						chinesedata[tx+kongaddr[ty-1]+1]=color;
					}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					chinesedata[((i1)<<4)+(i2<<3)+i3]=0;
					for(i1=0;i1<18;i1++)
					drawlinedatamask(x,y+i1,18,&chinesedata[kongaddr[i1]],0);

			x+=16+dx;if(x>=768){x=xx;y+=20;}
		}
	}
}
return x;
}       */

int outchineseback(int x,int y,int dx,int color,int backcolor,char *str)
{
	  FILE *fp;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec,xx=x;
	long offset;
	char bit[32];
	while(*str)
	{
		i=*str++;
		if(i==32)x+=16;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
					case 4:memcpy(bit,&hzkbuffer4[offset],32);break;
				}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					drawpixel(x+(i2<<3)+i3,y+i1,color);
					else
					drawpixel(x+(i2<<3)+i3,y+i1,backcolor);
			x+=16+dx;if(x>=768){x=xx;y+=20;}
		}
	}
}
return x;
}

int getoneworddata(char *str,char *bit)
{
	  FILE *fp;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec;
	long offset;
	while(*str)
	{
		i=*str++;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
					case 4:memcpy(bit,&hzkbuffer4[offset],32);break;
				}
		}
	}
}
}


int outchinesey(int x,int y,int dx,int color,char *str)
{
	  FILE *fp;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec,yy=y;
	long offset;
	char bit[32];
	char chinesedata[256];
	while(*str)
	{
		i=*str++;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{
				memset(chinesedata,0,256);
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
				}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
                                        chinesedata[(i1<<4)+(i2<<3)+i3]=color;
					for(i1=0;i1<16;i1++)
					drawlinedatamask(x,y+i1,16,&chinesedata[i1<<4],0);
					/*drawpixel(x+(i2<<3)+i3,y+i1,color);*/
			y+=16+dx;if(y>=479){y=yy;x+=20;}
		}
	}
}
return x;
}
int outchinesen(int x,int y,int dx,int color,char *str,int xn,int yn)
{
	  FILE *fp;
	  int mm,nn;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec,xx=x;
	long offset;
	char bit[32];
	while(*str)
	{
		i=*str++;
		if(i==32)x+=16;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
				}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					{
					drawbar(x+((i2<<3)+i3)*xn,y+i1*yn,x+((i2<<3)+i3)*xn+xn,y+i1*yn+yn,color);
					/*for(nn=0;nn<=yn;nn++)
					for(mm=0;mm<=xn;mm++)
					drawpixel(x+((i2<<3)+i3)*xn+nn,y+i1*yn+mm,color);*/
					}
			x+=16*xn+dx;if(x>=768){x=xx;y+=20;}
		}
	}
}

return x;
}

int outchineseyingn(int x,int y,int dx,int color,int yingcolor,char *str,int ddx,int ddy,int xn,int yn)
{
	  FILE *fp;
	  int mm,nn;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec,xx=x;
	long offset;
	char bit[32];
	while(*str)
	{
		i=*str++;
		if(i==32)x+=16;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
				}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					{
					drawbar(x+((i2<<3)+i3)*xn+ddx,y+i1*yn+ddy,x+((i2<<3)+i3)*xn+xn+ddx,y+i1*yn+yn+ddy,yingcolor);
					/*for(nn=0;nn<=yn;nn++)
					for(mm=0;mm<=xn;mm++)
					drawpixel(x+((i2<<3)+i3)*xn+nn,y+i1*yn+mm,color);*/
					}
                                        for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					{
					drawbar(x+((i2<<3)+i3)*xn,y+i1*yn,x+((i2<<3)+i3)*xn+xn,y+i1*yn+yn,color);
					/*for(nn=0;nn<=yn;nn++)
					for(mm=0;mm<=xn;mm++)
					drawpixel(x+((i2<<3)+i3)*xn+nn,y+i1*yn+mm,color);*/
					}
			x+=16*xn+dx;if(x>=768){x=xx;y+=20;}
		}
	}
}

return x;
}

int outchinesekongn(int x,int y,int dx,int color,char *str,int xn,int yn)
{
	  FILE *fp;
	  int mm,nn;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec,xx=x;
	long offset;
	char bit[32];
	while(*str)
	{
		i=*str++;
		if(i==32)x+=16;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
				}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					{
					drawbar(x+((i2<<3)+i3)*xn-1,y+i1*yn-1,x+((i2<<3)+i3)*xn+xn+1,y+i1*yn-1,color);
					drawbar(x+((i2<<3)+i3)*xn-1,y+i1*yn+yn+1,x+((i2<<3)+i3)*xn+xn+1,y+i1*yn+yn+1,color);
					drawbar(x+((i2<<3)+i3)*xn-1,y+i1*yn-1,x+((i2<<3)+i3)*xn-1,y+i1*yn+yn+1,color);
					drawbar(x+((i2<<3)+i3)*xn+xn+1,y+i1*yn-1,x+((i2<<3)+i3)*xn+xn+1,y+i1*yn+yn+1,color);
					/*for(nn=0;nn<=yn;nn++)
					for(mm=0;mm<=xn;mm++)
					drawpixel(x+((i2<<3)+i3)*xn+nn,y+i1*yn+mm,color);*/
					}
                                        for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					{
					drawbar(x+((i2<<3)+i3)*xn,y+i1*yn,x+((i2<<3)+i3)*xn+xn,y+i1*yn+yn+1,0);
					/*for(nn=0;nn<=yn;nn++)
					for(mm=0;mm<=xn;mm++)
					drawpixel(x+((i2<<3)+i3)*xn+nn,y+i1*yn+mm,color);*/
					}
			x+=16*xn+dx;if(x>=768){x=xx;y+=20;}
		}
	}
}

return x;
}
int outchineseny(int x,int y,int dx,int color,char *str,int xn,int yn)
{
	  FILE *fp;
	  int mm,nn;
	unsigned char i,c1,c2,flag=0,page;
	int i1,i2,i3,rec,yy=y;
	long offset;
	char bit[32];
	while(*str)
	{
		i=*str++;
		if(i>0xa0)
		{
			if(!flag)
			{
				c1=(i-0xa1)&0x7f;flag=1;
			}
			else
			{
				flag--;c2=(i-0xa1)&0x7f;rec=c1*94L+c2;
				offset=(long)rec<<5l;
				page=offset/65504L;
				offset=offset-(long)page*65504L;
				switch(page)
				{
					case 0:memcpy(bit,&hzkbuffer0[offset],32);break;
					case 1:memcpy(bit,&hzkbuffer1[offset],32);break;
					case 2:memcpy(bit,&hzkbuffer2[offset],32);break;
					case 3:memcpy(bit,&hzkbuffer3[offset],32);break;
				}
					for(i1=0;i1<16;i1++)
					for(i2=0;i2<2;i2++)
					for(i3=0;i3<8;i3++)
					if((bit[(i1<<1)+i2]>>(7-i3))&1)
					{
                                        for(nn=0;nn<=yn;nn++)
					for(mm=0;mm<=xn;mm++)
					drawpixel(x+((i2<<3)+i3)*xn+nn,y+i1*yn+mm,color);
					}
			y+=16*yn+dx;if(y>=479){y=yy;x+=20;}
		}
	}
}

return x;
}


int outchinesenum(int x,int y,int dx,int color,long num)
{
	unsigned char i,c1,c2,bit[32];
	int i1,i2,i3,rec,len;
	long offset;
	unsigned char str[25],str1[13];
	memset(str,0,25);
	memset(str1,0,13);

	if(num>999999999L)
	{
		outchinese(x,y,dx,color,"������������������");
		return;
	}
	if(num<0)
	{
		outchinese(x,y,dx,color,"��");
		x+=(16+dx);num=-num;
	}
	sprintf(str1,"%ld",num);
	len=strlen(str1);
	for(i=0;i<len;i++)
	{
		str[i*2]=0xa1+2;
		str[i*2+1]=0xa1+15+((int)str1[i]-48);
	}
	outchinese(x,y,dx,color,str);

}
int outchinesenumback(int x,int y,int dx,int color,int backcolor,long num)
{
	unsigned char i,c1,c2,bit[32];
	int i1,i2,i3,rec,len;
	long offset;
	unsigned char str[25],str1[13];
	memset(str,0,25);
	memset(str1,0,13);

	if(num>999999999L)
	{
		outchinese(x,y,dx,color,"������������������");
		return;
	}
	if(num<0)
	{
		outchineseback(x,y,dx,color,backcolor,"��");
		x+=(16+dx);num=-num;
	}
	sprintf(str1,"%ld",num);
	len=strlen(str1);
	for(i=0;i<len;i++)
	{
		str[i*2]=0xa1+2;
		str[i*2+1]=0xa1+15+((int)str1[i]-48);
	}
	outchineseback(x,y,dx,color,backcolor,str);

}

int outchinesenumn(int x,int y,int dx,int color,long num,int m,int n)
{
	unsigned char i,c1,c2,bit[32];
	int i1,i2,i3,rec,len;
	long offset;
	unsigned char str[25],str1[13];
	memset(str,0,25);
	memset(str1,0,13);

	if(num>999999999L)
	{
		outchinesen(x,y,dx,color,"������������������",m,n);
		return;
	}
	if(num<0)
	{
		outchinesen(x,y,dx,color,"��",m,n);
		x+=(16+dx);num=-num;
	}
	sprintf(str1,"%ld",num);
	len=strlen(str1);
	for(i=0;i<len;i++)
	{
		str[i*2]=0xa1+2;
		str[i*2+1]=0xa1+15+((int)str1[i]-48);
	}
	outchinesen(x,y,dx,color,str,m,n);

}

int outchineseascii(int x,int y,int dx,int color,char *str)
{
	int len,i;
	char str2[1024];
	memset(str2,0,255);

	len=strlen(str);
	for(i=0;i<len;i++)
	{
		str2[i*2]=0xa1+2;
		str2[i*2+1]=0xa1+15+((int)str[i]-48);
	}
	outchinese(x,y,dx,color,str2);

}

int outchineseasciin(int x,int y,int dx,int color,char *str,int m,int n)
{
	int len,i;
	char str2[1024];
	memset(str2,0,255);

	len=strlen(str);
	for(i=0;i<len;i++)
	{
		str2[i*2]=0xa1+2;
		str2[i*2+1]=0xa1+15+((int)str[i]-48);
	}
	outchinesen(x,y,dx,color,str2,m,n);

}
int outchineseasciiyingn(int x,int y,int dx,int color,int yingcolor,char *str,int ddx,int ddy,int m,int n)
{
	int len,i;
	char str2[1024];
	memset(str2,0,255);

	len=strlen(str);
	for(i=0;i<len;i++)
	{
		str2[i*2]=0xa1+2;
		str2[i*2+1]=0xa1+15+((int)str[i]-48);
	}
	outchineseyingn(x,y,dx,color,yingcolor,str2,ddx,ddy,m,n);

}
int outchineseasciiying(int x,int y,int dx,int color,int yingcolor,char *str,int ddx,int ddy)
{
	int len,i;
	char str2[1024];
	memset(str2,0,255);

	len=strlen(str);
	for(i=0;i<len;i++)
	{
		str2[i*2]=0xa1+2;
		str2[i*2+1]=0xa1+15+((int)str[i]-48);
	}
	outchineseying(x,y,dx,color,yingcolor,str2,ddx,ddy);

}
int outchineseasciikong(int x,int y,int dx,int color,char *str)
{
	int len,i;
	char str2[1024];
	memset(str2,0,255);

	len=strlen(str);
	for(i=0;i<len;i++)
	{
		str2[i*2]=0xa1+2;
		str2[i*2+1]=0xa1+15+((int)str[i]-48);
	}
	outchinesekong(x,y,dx,color,str2);

}

int outchineseasciikongn(int x,int y,int dx,int color,char *str,int m,int n)
{
	int len,i;
	char str2[1024];
	memset(str2,0,255);

	len=strlen(str);
	for(i=0;i<len;i++)
	{
		str2[i*2]=0xa1+2;
		str2[i*2+1]=0xa1+15+((int)str[i]-48);
	}
	outchinesekongn(x,y,dx,color,str2,m,n);

}
int outchineseasciiback(int x,int y,int dx,int color,int backcolor,char *str)
{
	int len,i;
	char str2[1024];
	memset(str2,0,255);

	len=strlen(str);
	for(i=0;i<len;i++)
	{
		str2[i*2]=0xa1+2;
		str2[i*2+1]=0xa1+15+((int)str[i]-48);
	}
	outchineseback(x,y,dx,color,backcolor,str2);

}
int outchineseasciiy(int x,int y,int dx,int color,char *str)
{
	int len,i;
	char str2[1024];
	memset(str2,0,255);

	len=strlen(str);
	for(i=0;i<len;i++)
	{
		str2[i*2]=0xa1+2;
		str2[i*2+1]=0xa1+15+((int)str[i]-48);
	}
	outchinesey(x,y,dx,color,str2);

}

int initchinese()
{
	FILE *fp;
	long n;
	unsigned char hzk;
	if((hzkbuffer0=malloc(65504/*157615L*/))==NULL)
	{
		printf("\nNot enough memory!\n");
		free(hzkbuffer0);
		return(0);
	}
	if((hzkbuffer1=malloc(65504/*157615L*/))==NULL)
	{
		printf("\nNot enough memory!\n");
		free(hzkbuffer1);
	      free(hzkbuffer0);
		return(0);
	}
	if((hzkbuffer2=malloc(65504/*157615L*/))==NULL)
	{
		printf("\nNot enough memory!\n");
		free(hzkbuffer2);
	      free(hzkbuffer1);
	      free(hzkbuffer0);
		return(0);
	}
	if((hzkbuffer3=malloc(65504))==NULL)
	{
		printf("\nNot enough memory!\n");
		free(hzkbuffer3);
		free(hzkbuffer2);
		free(hzkbuffer1);
		free(hzkbuffer0);
		return(0);
	}
	if((hzkbuffer4=malloc(5600))==NULL)
	{
		printf("\nNot enough memory!\n");
		free(hzkbuffer4);
		free(hzkbuffer3);
		free(hzkbuffer2);
		free(hzkbuffer1);
		free(hzkbuffer0);
		return(0);
	}
	if((fp=fopen("hzk16","rb"))==NULL)
	{
		printf("\nCan't find hzk16!\n");
		return(0);
	}
	fread(hzkbuffer0,65504,1,fp);
	fread(hzkbuffer1,65504,1,fp);
	fread(hzkbuffer2,65504,1,fp);
	fread(hzkbuffer3,65504,1,fp);
	fread(hzkbuffer4,5600,1,fp);
       fclose(fp);
       return(1);
}

void closechinese()
{
free(hzkbuffer4);
free(hzkbuffer3);
		free(hzkbuffer2);
		free(hzkbuffer1);
		free(hzkbuffer0);
}
