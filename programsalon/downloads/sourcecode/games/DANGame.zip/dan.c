/*����ģʽ��Compact*/
#define SCREENWIDTH 640
#define SCREENHEIGHT 480
#define SCREENWIDTHBYTES 1920L
#include"keyboard.c"
#include"dan.h"
#include"danmouse.c"
int dosshellflag=0;
int foodflag=0,foodn=0;
int foodfirstflag=0;
int danmap6flag=0,danmap6flagflag=0;
unsigned char foodmap[32*12];
unsigned char foodsavemap[33*13];
unsigned char foodmapall[6][32*12];
extern int zhuan[40][40];
int int1chflag=0;
int soundword[10][2];
int soundn=0;
int soundflag=0;
int sound1n=0;
char soundonoroff=ON;

char stepflag=0;
unsigned char timehigh,timelow;
unsigned int shudu=217,shudun=0;
int ballflag=0;
int fuballflag=0;

int fuballx=0,fubally=0;
int fudx=1.0,fudy=1.0,fudistancex=0,fudistancey=0;
char fuincdx=1,fuincdy=1;
int ballx=INITBALLX,bally=INITBALLY,dead=0;
int busy=0,lifebusy=0;
int dx=1.0,dy=1.0,distancex=0,distancey=0;
int distancefoodx=0,distancefoody=0;
char incdx=1,incdy=1;
int jiao=45;
int step=1;
long fen=0;
long fentemp=0;
int mx;

int ganx=0,gany=440;
int  balln=15;
int balldelay=0;
int life=3;

#define inline(a,a1,a2) (a>=a1&&a<=a2)
int twobox(int x1,int y1,int x2,int y2,int xx1,int yy1,int xx2,int yy2,int *x11,int *y11,int *x22,int *y22)
{
	int t;
	if(x1>x2){t=x1;x1=x2;x2=t;}
	if(y1>y2){t=y1;y1=y2;y2=t;}
	if(xx1>xx2){t=xx1;xx1=xx2;xx2=t;}
	if(yy1>yy2){t=yy1;yy1=yy2;yy2=t;}
	if(inline(y1,yy1,yy2))yy1=y1;
	else y1=yy1;

	if(inline(y2,yy1,yy2))yy2=y2;
	else y2=yy2;

	if(inline(x1,xx1,xx2))xx1=x1;
	else x1=xx1;

	if(inline(x2,xx1,xx2))xx2=x2;
	else x2=xx2;

	if(((x2-x1)<0)||((y2-y1)<0))
	{return(0);}
	else{*y11=y1;*x11=x1;*y22=y2;*x22=x2;}
	return(1);
}
int setpalette15()
{
	int n;
	rgbcolor(16,0,0,63);
	rgbcolor(31,0,0,31);

	rgbcolor(17,0,63,0);
	rgbcolor(32,0,21,0);

	rgbcolor(18,0,63,63);
	rgbcolor(33,0,21,21);

	rgbcolor(19,63,0,0);
	rgbcolor(34,21,0,0);

	rgbcolor(20,63,0,63);
	rgbcolor(35,21,0,21);

	rgbcolor(21,63,42,0);
	rgbcolor(36,21,0,0);

	rgbcolor(22,63,63,63);
	rgbcolor(37,21,21,21);

	rgbcolor(23,42,42,42);
	rgbcolor(38,10,10,10);

	rgbcolor(24,42,42,63);
	rgbcolor(39,0,0,21);

	rgbcolor(25,42,63,42);
	rgbcolor(40,0,21,0);

	rgbcolor(26,42,63,63);
	rgbcolor(41,0,21,21);

	rgbcolor(27,63,42,42);
	rgbcolor(42,21,0,0);

	rgbcolor(28,63,42,63);
	rgbcolor(43,21,0,21);

	rgbcolor(29,63,63,42);
	rgbcolor(44,21,21,0);

	rgbcolor(30,50,50,50);
	rgbcolor(45,15,15,15);
	rgbcolor(15,63,63,63);

	for(n=224;n<=254;n++)
	rgbcolor(n,0,(n-224)*2,(n-224)*2);
	rgbcolor(224,0,63,63);
}
int inbox(int x,int y,int x1,int y1,int x2,int y2)
{
	if(x>=x1&&x<=x2&&y>=y1&&y<=y2)
	return(1);
	else return(0);
}

loadfoodmap(int index)
{
int i;
for(i=0;i<32*12;i++)
foodmap[i]=foodmapall[index-1][i];
}

initloadfoodmap()
{
FILE *fp;
fp=fopen("danmap1","rb");
fseek(fp,0L,SEEK_SET);
fread(&foodmapall[0][0],32*12,1,fp);
fclose(fp);

fp=fopen("danmap2","rb");
fseek(fp,0L,SEEK_SET);
fread(&foodmapall[1][0],32*12,1,fp);
fclose(fp);

fp=fopen("danmap3","rb");
fseek(fp,0L,SEEK_SET);
fread(&foodmapall[2][0],32*12,1,fp);
fclose(fp);

fp=fopen("danmap4","rb");
fseek(fp,0L,SEEK_SET);
fread(&foodmapall[3][0],32*12,1,fp);
fclose(fp);

fp=fopen("danmap5","rb");
fseek(fp,0L,SEEK_SET);
fread(&foodmapall[4][0],32*12,1,fp);
fclose(fp);

fp=fopen("danmap6","rb");
fseek(fp,0L,SEEK_SET);
fread(&foodmapall[5][0],32*12,1,fp);
fclose(fp);

busy=0;
}

void drawfoodmap(int x1,int y1)
{
	int y,x;
	int n=0;int xx=x1,yy=y1;
	if((x1+32)>ganx&&x1<(ganx+96)&&y1>(gany-25))drawgan(ganx,gany,14);
	for(y=0;y<12;y++)
	for(x=0;x<32;x++)
	{
	  if(foodmap[n]==255){n++;xx++;  if(xx>=(x1+32)){yy++;xx=x1;}continue;}
	  drawpixel(xx++,yy,foodmap[n++]);
	  if(xx>=(x1+32)){yy++;xx=x1;}
	}
}

void drawbian()
{
	int n;
	for(n=31;n>0;n--)
	drawbar(n,0,n,479,224+32-n);
	for(n=1;n<32;n++)
	drawbar(607+n,0,n+607,479,224+n);
}

void changetime(unsigned int count)
{
shudu=count;
count=1192737/count;
outp(0x43,0x3c);
outp(0x40,(count&0xff));
outp(0x40,(count>>8)&0xff);
}

void restoretime()
{
outp(0x43,0x3c);
outp(0x40,0xff);
outp(0x40,0xff);
}


void initfoodmap(int x1,int y1,int index,int dx,int dy,int inx,int iny)
{
	if(x1>(639-64))x1=639-65;
	if(x1<34)x1=34;
	if(index<1)index=1;
	if(index>6)index=6;
	loadfoodmap(index);
	foodflag=1;food.x=x1;
	food.y=y1;food.index=index;food.dx=dx;food.dy=dy;
	food.incdx=inx;food.incdy=iny;
	foodfirstflag=1;
}
void interrupt(*oldint1ch)();

int close1ch(int fg)
{
if(fg==1){int1chflag=0;return;}
if(fg==0)
setvect(0x1c,oldint1ch);
}



void outlife()
{
	int i,l;
	busy=1;
	outchineseback(300,460,0,13,0,"������");
	outchinesenumback(300+48,460,0,12,0,(long)(life+1));
	busy=0;
}
int rgbcolorset(int n,int r,int g,int b)
{
	outportb(0x3c6,0xff);
	outportb(0x3c8,n);
	outportb(0x3c9,r);
	outportb(0x3c9,g);
	outportb(0x3c9,b);
}
int drawesccai(int n)
{
	hidemouse();
	if(n==1)outchinesen((640-7*32)/2,100,32,15,"�˳���Ϸ",2,2);
	else outchinesen((640-7*32)/2,100,32,1,"�˳���Ϸ",2,2);
	if(n==2)outchinesen((640-7*32)/2,150,32,15,"���¿�ʼ",2,2);
	else outchinesen((640-7*32)/2,150,32,1,"���¿�ʼ",2,2);
	if(soundonoroff==ON)
	{
		if(n==3)outchinesen((640-7*32)/2,200,32,15,"��������",2,2);
		else outchinesen((640-7*32)/2,200,32,1,"��������",2,2);
	}
	else if(soundonoroff==OFF)
	{
		if(n==3)outchinesen((640-7*32)/2,200,32,15,"��������",2,2);
		else outchinesen((640-7*32)/2,200,32,1,"��������",2,2);
	}
	else {soundonoroff=ON;
		if(n==3)outchinesen(0,0,0,15,"��������",2,2);
		else outchinesen(0,0,0,1,"��������",2,2);
	     }
	if(n==4)outchinesen((640-7*32)/2,250,32,15,"������Ϸ",2,2);
	else outchinesen((640-7*32)/2,250,32,1,"������Ϸ",2,2);
	showmouse();
}
int esccai()
{
	int c=1,x,y,k,ox=0,oy=0,key;
        setmousebar(0,0,SCREENWIDTH-mousebufxlong-1,SCREENHEIGHT-mousebufylong-1);
	hidemouse();
        setmousefilebar();
	drawesccai(1);
	showmouse();

while(1)
{
	while(!lastascii)
	{
		mousecontrol();
		_AX=0x03;
		geninterrupt(0x33);
		x=_CX;y=_DX;k=_BX;
		if(x!=ox||y!=oy)
		{
			if(inbox(x,y,208,100,208+7*32,132)&&c!=1)
			{drawesccai(1);c=1;}
			if(inbox(x,y,208,150,208+7*32,182)&&c!=2)
			{drawesccai(2);c=2;}
			if(inbox(x,y,208,200,208+7*32,232)&&c!=3)
			{drawesccai(3);c=3;}
			if(inbox(x,y,208,250,208+7*32,282)&&c!=4)
			{drawesccai(4);c=4;}
		}
		if(k&2){waitupmouse();lastascii=27;}
		if((k&1)==1)
		{
			if(inbox(x,y,208,100,208+7*32,132)&&c==1)
			{key=13;c=1;waitupmouse();goto AA;}
			if(inbox(x,y,208,150,208+7*32,182)&&c==2)
			{key=13;c=2;waitupmouse();goto AA;}
			if(inbox(x,y,208,200,208+7*32,232)&&c==3)
			{key=13;c=3;waitupmouse();goto AA;}
			if(inbox(x,y,208,250,208+7*32,282)&&c==4)
			{key=13;c=4;waitupmouse();goto AA;}
		}
	}
	key=lastascii;
	lastascii=0;
AA:
	switch(key)
	{
                case KEY_CTRLBREAK:
					getbmp();break;
		case KEY_UP:if(c>1)drawesccai(--c);else {c=4;drawesccai(c);break;
		case KEY_DOWN:if(c<4)c++;else c=1;drawesccai(c);break;
		case 27:return(GAMECONTINUEBACK);
		case 32:
		case 13:switch(c)
			{
			case 1:
				restoretime();rgbcolor(255,0,0,0);
				rgbcolor(0,0,0,0);
				save();
				closechinese();closegraphics();closekeyboard();exit(0);
			case 2:return(RESTART);
			case 3:if(soundonoroff==ON)
				{
                                        outchinesen(208+6*32,200,0,0,"��",2,2);
					drawmousemap(mousex,mousey);
					outchinesen((640-7*32)/2,200,32,15,"��������",2,2);
					soundonoroff=OFF;
					nosound();
				}
				else if(soundonoroff==OFF)
				{
                                        outchinesen(208+6*32,200,0,0,"��",2,2);
					drawmousemap(mousex,mousey);
					outchinesen((640-7*32)/2,200,32,15,"��������",2,2);
					soundonoroff=ON;
				}break;
			case 4:setdanmousebar();return(GAMECONTINUEBACK);
			}/*end switch*/
		}
	}

}setdanmousebar();
}

int drawstartcai(int n)
{
	hidemouse();
	if(n==1)outchinesen((640-7*32)/2,100,32,15,"��ʼ��Ϸ",2,2);
	else outchinesen((640-7*32)/2,100,32,1,"��ʼ��Ϸ",2,2);
	if(n==2)outchinesen((640-7*32)/2,150,32,15,"�˳���Ϸ",2,2);
	else outchinesen((640-7*32)/2,150,32,1,"�˳���Ϸ",2,2);
	if(soundonoroff==ON)
	{
		if(n==3)outchinesen((640-7*32)/2,200,32,15,"��������",2,2);
		else outchinesen((640-7*32)/2,200,32,1,"��������",2,2);
	}
	else if(soundonoroff==OFF)
	{
		if(n==3)outchinesen((640-7*32)/2,200,32,15,"��������",2,2);
		else outchinesen((640-7*32)/2,200,32,1,"��������",2,2);
	}
	else {soundonoroff=ON;
		if(n==3)outchinesen(0,0,0,15,"��������",2,2);
		else outchinesen(0,0,0,1,"��������",2,2);
	     }
	if(n==4)outchinesen((640-7*32)/2,250,32,15,"��Ϸ����",2,2);
	else outchinesen((640-7*32)/2,250,32,1,"��Ϸ����",2,2);
	showmouse();
}
int startcai()
{
	int c=1,x,y,k,ox=0,oy=0,key;
	hidemouse();
	drawstartcai(1);

	setmousefilebar();
	showmouse();
while(1)
{	while(!lastascii)
	{
		mousecontrol();
		_AX=0x03;
		geninterrupt(0x33);
		x=_CX;y=_DX;k=_BX;
		if(x!=ox||y!=oy)
		{
			if(inbox(x,y,208,100,208+7*32,132)&&c!=1)
			{drawstartcai(1);c=1;}
			if(inbox(x,y,208,150,208+7*32,182)&&c!=2)
			{drawstartcai(2);c=2;}
			if(inbox(x,y,208,200,208+7*32,232)&&c!=3)
			{drawstartcai(3);c=3;}
			if(inbox(x,y,208,250,208+7*32,282)&&c!=4)
			{drawstartcai(4);c=4;}
		}
		if((k&1)==1)
		{
			if(inbox(x,y,208,100,208+7*32,132)&&c==1)
			{key=13;c=1;waitupmouse();goto AA;}
			if(inbox(x,y,208,150,208+7*32,182)&&c==2)
			{key=13;c=2;waitupmouse();goto AA;}
			if(inbox(x,y,208,200,208+7*32,232)&&c==3)
			{key=13;c=3;waitupmouse();goto AA;}
			if(inbox(x,y,208,250,208+7*32,282)&&c==4)
			{key=13;c=4;waitupmouse();goto AA;}
		}
	}
	key=lastascii;
	lastascii=0;
AA:
	switch(key)
	{
                case KEY_CTRLBREAK:
					getbmp();break;
		case KEY_UP:if(c>1)drawstartcai(--c);else {c=4;drawstartcai(c);break;
		case KEY_DOWN:if(c<4)c++;else c=1;drawstartcai(c);break;
		case 32:
		case 13:switch(c)
			{
			case 2:
					restoretime();rgbcolor(255,0,0,0);
					rgbcolor(0,0,0,0);
					closechinese();closegraphics();closekeyboard();exit(0);
			case 1:return(START);
			case 3:
				if(soundonoroff==ON)
				{
					outchinesen(208+6*32,200,0,0,"��",2,2);
					drawmousemap(mousex,mousey);
					outchinesen((640-7*32)/2,200,32,15,"��������",2,2);
					soundonoroff=OFF;
					nosound();
				}
				else if(soundonoroff==OFF)
				{
					outchinesen(208+6*32,200,0,0,"��",2,2);
					drawmousemap(mousex,mousey);
					outchinesen((640-7*32)/2,200,32,15,"��������",2,2);
					soundonoroff=ON;
				}break;
			case 4:return(HELP);
			}/*end switch*/
		}
	}

}
setdanmousebar();
}




int end()
{
	switch(dead)
	{

		case GAMEOVER:close1ch(0);

				restoretime();rgbcolor(255,0,0,0);
				rgbcolor(0,0,0,0);
				save();
				return(RESTART);
		case ESC:nosound();close1ch(0);
				restoretime();rgbcolor(255,0,0,0);
				rgbcolor(0,0,0,0);
				switch(esccai())
				{
				case RESTART:save();return(RESTART);
				case BACK:return(BACK);
				case EXIT:
					restoretime();rgbcolor(255,0,0,0);
					rgbcolor(0,0,0,0);
					save();
					closechinese();closegraphics();closekeyboard();exit(0);
				}
	}
}
int  zhuancontrol()
{
	int x,y;
	for(y=1;y<=29;y++)
	for(x=2;x<=17;x++)
	{
		if(zhuan[y][x]!=0&&(zhuan[y][x]!=14)&&(zhuan[y][x]!=16))return(0);
	}
	if(step!=15)return(1);else {return(1);}

}
void initzhuandata(int size)
{
	int m,n,temp;
	randomize();

	switch(size)
	{
		case 9:readdata9();break;
		case 7:readdata8();break;
		case 6:readdata6();break;
		case 5:readdata5();break;
		case 4:readdata4();break;
		case 3:readdata3();break;
		case 2:readdata2();break;
		case 1:readdata1();break;
		case 8:readdata7();break;

	}
}

static int drawball(int x,int y,unsigned char color)
{
	char ballcolor[8][8]=
	{
	{00,00, 7, 7,15,15,00,00},
	{00, 7, 7,15,15,15,15,00},
	{ 8, 7, 7,15,15,15,15,15},
	{ 8, 7, 7, 7,15,15,15,15},
	{ 8, 7, 7, 7,15,15,15,15},
	{ 8, 8, 7, 7, 7, 7,15,15},
	{00, 8, 7, 7, 7, 7, 7,00},
	{00, 0, 8, 8, 7, 7,00,00}
	};
	int m,n;
	if(x>ganx&&x<(ganx+96)&&y>gany)drawgan(ganx,gany,14);
	busy=1;
	if(color==0)
	{
		drawbar(ballx-4,bally-4,ballx+4,bally+4,0);
	}
	/*for(m=0;m<8;m++)
	for(n=0;n<8;n++)
	drawpixel(x+n-4,y+m-4,0);*/
	else
	for(m=0;m<8;m++)
	for(n=0;n<8;n++)
	drawpixel(x+n-4,y+m-4,ballcolor[m][n]);
	busy=0;
}




int drawzhuan(int x,int y,int size)
{
	int xx;
	busy=1;
	drawbar(x,y,x+32,y+12,0);
	if(stepflag==7)
	{
           if(size==0||size==16)
	{
				drawbar(x-1,y-1,x+ZHUANDX+1,y+ZHUANDY+1,0);
	}else
	if(size==7||size==8||size==15)

	{
		drawbar(x+1,y+1,x+ZHUANDX-2,y+ZHUANDY-1,size+15);
			drawbar(x+1,y+1,x+ZHUANDX-2,y+1,size+30);
			drawbar(x+1,y+1,x+1,y+ZHUANDY-1,size+30);
			drawbar(x+1,y+ZHUANDY-1,x+1,y+ZHUANDY-1,size+30+15);
			drawbar(x+ZHUANDX+1,y+ZHUANDY-1,x+ZHUANDX+1,y+ZHUANDY-1,size+30+15);
		/*if(stepflag==0)
		for(xx=0;xx<51+(size<<3);xx++)
		drawpixel(random(ZHUANDX-1)+x,random(ZHUANDY-1)+y,random(size));*/
			drawrectangle(x,y,x+ZHUANDX-1,y+ZHUANDY,0);
		}
		else

	{
		drawbar(x+1,y+1,x+ZHUANDX-2,y+ZHUANDY-1,size+15);
			drawbar(x+1,y+1,x+ZHUANDX-2,y+1,size+30);
			drawbar(x+1,y+1,x+1,y+ZHUANDY-1,size+30);
			drawbar(x+1,y+ZHUANDY-1,x+1,y+ZHUANDY-1,size+30+15);
			drawbar(x+ZHUANDX+1,y+ZHUANDY-1,x+ZHUANDX+1,y+ZHUANDY-1,size+30+15);
		if(stepflag==0)
		/*for(xx=0;xx<51;xx++)
		drawpixel(random(ZHUANDX-1)+x,random(ZHUANDY-1)+y,size+1+15);*/
		drawrectangle(x,y,x+ZHUANDX-1,y+ZHUANDY,0);
		} busy=0;return;
	}

	if(size==0||size==16)
	{
				drawbar(x-1,y-1,x+ZHUANDX+1,y+ZHUANDY+1,0);
	}else
	if(size==7||size==8||size==15)

	{
		drawbar(x+1,y+1,x+ZHUANDX-2,y+ZHUANDY-1,size);
			drawbar(x+1,y+1,x+ZHUANDX-2,y+1,size+15);
			drawbar(x+1,y+1,x+1,y+ZHUANDY-1,size+15);
			drawbar(x+1,y+ZHUANDY-1,x+1,y+ZHUANDY-1,size+30);
			drawbar(x+ZHUANDX+1,y+ZHUANDY-1,x+ZHUANDX+1,y+ZHUANDY-1,size+30);
		/*if(stepflag==0)
		for(xx=0;xx<51+(size<<3);xx++)
		drawpixel(random(ZHUANDX-1)+x,random(ZHUANDY-1)+y,random(size));*/
			drawrectangle(x,y,x+ZHUANDX-1,y+ZHUANDY,0);
		}
		else

	{
		drawbar(x+1,y+1,x+ZHUANDX-2,y+ZHUANDY-1,size);
			drawbar(x+1,y+1,x+ZHUANDX-2,y+1,size+15);
			drawbar(x+1,y+1,x+1,y+ZHUANDY-1,size+15);
			drawbar(x+1,y+ZHUANDY-1,x+1,y+ZHUANDY-1,size+30);
			drawbar(x+ZHUANDX+1,y+ZHUANDY-1,x+ZHUANDX+1,y+ZHUANDY-1,size+30);
		/*if(stepflag==0)
		for(xx=0;xx<51;xx++)
		drawpixel(random(ZHUANDX-1)+x,random(ZHUANDY-1)+y,size+1);*/
			drawrectangle(x,y,x+ZHUANDX-1,y+ZHUANDY,0);
		}


		busy=0;
}

int initdrawzhuan()
{
	int m,n;
	drawbar(0,0,639,479,0);
	for(m=0;m<=ZHUANYN;m++)
	for(n=0;n<ZHUANXN;n++)
	{if(zhuan[m][n]!=0)drawzhuan(n*ZHUANDX,m*ZHUANDY,zhuan[m][n]);}
	drawbian();
	outlife();
	outtime(1);
}

int drawgan(int x,int y,int color)
{
	busy=1;
	x=x;
	y=y+5;
	if(color==0){drawbar(x,y,x+96,y+13,0);return;}
	drawbar(x,y+3,x+96,y+12,7);
	drawrectangle(x,y+3,x+96,y+12,15);
	drawbar(x,y+10,x+96,y+12,8);
	drawbar(x+94,y,x+96,y+12,8);
	busy=0;
}
int outfen()
{
/*drawbar(64,460,220,476,0);*/
	outchinesenumback(64,460,0,14,0,fen);
}
void deletezhuan(int xn,int yn)
{
	if(xn==0||xn==19)return;
	if(zhuan[yn][xn]==0)return;
	busy=1;
	switch(zhuan[yn][xn])
	{
		case 16:zhuan[yn][xn]=1;drawzhuan(xn*ZHUANDX,yn*ZHUANDY,1);fen=fen+0L;fentemp=fentemp+0L;
			break;
		case 13:zhuan[yn][xn]=0;drawzhuan(xn*ZHUANDX,yn*ZHUANDY,0);fen=fen+1L;fentemp=fentemp+1L;fuballflag=1;fuballx=ballx;fuballx=bally;fudy=dy+20;break;
		case 12:zhuan[yn][xn]=0;drawzhuan(xn*ZHUANDX,yn*ZHUANDY,0);fen=fen+12L;fentemp=fentemp+12L;break;
		case 14:if(!ballflag)drawzhuan(xn*ZHUANDX,yn*ZHUANDY,14);
				else {zhuan[yn][xn]=0;drawzhuan(xn*ZHUANDX,yn*ZHUANDY,0);}break;
		case 15:zhuan[yn][xn]=8;drawzhuan(xn*ZHUANDX,yn*ZHUANDY,8);fen=fen+0L;fentemp=fentemp+0L;break;
		case 8:zhuan[yn][xn]=7;drawzhuan(xn*ZHUANDX,yn*ZHUANDY,7);fen=fen+0L;fentemp=fentemp=0L;break;
		default:zhuan[yn][xn]=0;drawzhuan(xn*ZHUANDX,yn*ZHUANDY,0);fen=fen+1L;fentemp=fentemp+1L;break;
	}
	if(random(100)>50)if(foodflag==0)initfoodmap(xn*32,yn*12,random(6)+1,dx,dy,-incdx,1);
	if(fentemp>1000L&&(step<8||((step%10)==0)))
	{
		if(life<127)
		{
			life++;
			outlife();
		}
		fentemp=fentemp-1000L;
	}


	soundword[ 0][ 0]=400;soundword[ 0][ 1]=10;
	soundword[ 1][ 0]=500;soundword[ 1][ 1]=0;
	soundword[ 2][ 0]=600;soundword[ 2][ 1]=0;
	soundword[ 3][ 0]=350;soundword[ 3][ 1]=0;
	soundword[ 4][ 0]=800;soundword[ 3][ 1]=0;
	soundword[ 5][ 0]=480;soundword[ 5][ 1]=0;
	soundword[ 6][ 0]=0;soundword[ 6][ 1]=0;
	soundword[ 7][ 0]=0;soundword[ 7][ 1]=0;
	soundword[ 8][ 0]=0;soundword[ 8][ 1]=0;
	soundword[ 9][ 0]=0;soundword[ 9][ 1]=0;
	nosound();
        if(soundflag!=1)
	{soundn=0;
	sound1n=0;
	soundflag=1;
	}
	outfen();
	outlife();
	busy=0;
}



void ballcontrol()
{
	int tx,ty,temp1,temp2,ddlong;
	drawball(ballx,bally,0);
	if(dy<15)dy=15;
	if(dx>46)dx=46;
	if(dy>46)dy=46;
	if(dx<15)dx=15;
	if(dx>=dy)
	{
		distancex+=dy;
		distancey+=dy;
		if(distancex>=dx){distancex=distancex-dx;ballx+=incdx;}
		distancey=0;
		bally+=incdy;
	}
	else
	{
		distancex+=dx;
		distancey+=dx;
		if(distancey>=dy){distancey=distancey-dy;bally+=incdy;}
		distancex=0;
		ballx+=incdx;
	}
        if(life<0){dead=GAMEOVER;return;}
	if(bally>=DEADY)
	{
	changetime(217);shudu=217;
	soundword[ 0][ 0]=400;soundword[ 0][ 1]=3;
	soundword[ 1][ 0]=500;soundword[ 1][ 1]=14;
	soundword[ 2][ 0]=600;soundword[ 2][ 1]=3;
	soundword[ 3][ 0]=700;soundword[ 3][ 1]=5;
	soundword[ 4][ 0]=800;soundword[ 3][ 1]=2;
	soundword[ 5][ 0]=900;soundword[ 5][ 1]=18;
	soundword[ 6][ 0]=800;soundword[ 6][ 1]=7;
	soundword[ 7][ 0]=700;soundword[ 7][ 1]=28;
        soundn=0;
	sound1n=0;
	soundflag=1;
	nosound();
	life--;danmap6flag=0;outlife();fuballflag=0;drawball(fuballx,fubally,0);
	ballflag=0;
		if(life<0){dead=GAMEOVER;return;}
		else {
			ganx=320-48;
			setmousexy(ganx,gany);
			balln=15;
			ballx=320,bally=gany,dead=0;
			dx=1.0,dy=1.0,distancex=0,distancey=0;
			incdx=-1,incdy=-1;
			jiao=45;
			initdrawzhuan();
			outlife();
                        outfen();
			drawgan(ganx,gany,14);
			drawball(ballx,bally,14);
			lifebusy=1;
		     return;

		}
	}
	if((bally>=gany)&&(bally<=(gany+1))&&(ballx>ganx)&&(ballx<(ganx+96)))
	{


		if(danmap6flag)danmap6flagflag=1;
		incdy=-incdy;incdx=incdx;
		ddlong=ballx-ganx;
		if(incdx<=0)
		{

			if(ddlong<=48){incdx=-1;incdy=-1;}
			if(ddlong>48){incdx=1;incdy=-1;}

			dy=96-ddlong;
			if(dx<25)dx=25;
			if(dx>48&&ddlong<48)dx=48;

			dx=ddlong;
			if(dy<25)dy=25;
			if(dy>48&&ddlong>48)dy=48;
			if(ddlong>48){tx=dx;dx=dy;dy=tx;}


		}
		if(incdx>0)
		{
			if(ddlong>=48){incdx=1;incdy=-1;}
			if(ddlong<48){incdx=-1;incdy=-1;}
			dy=96-ddlong;
			if(dx<26)dx=26;
			if(dx>46&&ddlong>48)dx=46;

			dx=ddlong;
			if(dy<25)dy=25;
			if(dy>46&&ddlong<48)dy=46;
                        if(ddlong>48){tx=dx;dx=dy;dy=tx;}



		}
		if(dy<0)ty=-dy;
		else ty=dy;
		if(dx<0)tx=-dx;
		else tx=dx;
		if(dx>dy)
		{

                        if(dy<1)dy=1;
			if((dx/dy)>3)
			dy=dx/3;
		}
		soundword[ 0][ 0]=300;soundword[ 0][ 1]=6;
		soundword[ 1][ 0]=700;soundword[ 1][ 1]=17;
		soundword[ 2][ 0]=600;soundword[ 2][ 1]=4;
		soundword[ 3][ 0]=400;soundword[ 3][ 1]=53;
		soundword[ 4][ 0]=250;soundword[ 3][ 1]=23;
		soundword[ 5][ 0]=0;soundword[ 5][ 1]=0;
		soundword[ 6][ 0]=0;soundword[ 6][ 1]=0;
		soundword[ 7][ 0]=0;soundword[ 7][ 1]=0;
		soundword[ 8][ 0]=0;soundword[ 8][ 1]=0;
		soundword[ 9][ 0]=0;soundword[ 9][ 1]=0;
		nosound();
                if(soundflag!=10)
		{soundn=0;
		sound1n=0;
		soundflag=1;
		}

	}
	tx=ballx+BALLR+1;
	ty=bally+BALLR+1;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(ballflag==0)
		{       if(LEFTDOWN)incdy=-incdy;
			else if(RIGHTDOWN)incdy=-incdy;
			else if(RIGHTUP)incdx=-incdx;
		ballx+=incdx;bally+=incdy;
			ballx+=incdx;bally+=incdy;
		}
	}

	tx=ballx+BALLR+1;
	ty=bally;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(ballflag==0)
		{
		if(RIGHTDOWN)incdx=-incdx;
		else if(RIGHTUP)incdx=-incdx;
		ballx+=incdx;bally+=incdy;
		ballx+=incdx;bally+=incdy;
		}
	}

	tx=ballx+BALLR+1;
	ty=bally-BALLR-1;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
	  if(ballflag==0)
		{if(RIGHTDOWN)incdx=-incdx;
		else if(RIGHTUP)incdx=-incdx;
		else if(LEFTUP)incdy=-incdy;
		ballx+=incdx;bally+=incdy;
		ballx+=incdx;bally+=incdy;
		}
	}

	tx=ballx;
	ty=bally-BALLR-1;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
	  if(ballflag==0)
		{if(LEFTUP)incdy=-incdy;
		else if(RIGHTUP)incdy=-incdy;
		else if(incdy<0)incdy=-incdy;
		ballx+=incdx;bally+=incdy;
		ballx+=incdx;bally+=incdy;
		}
	}

	tx=ballx-1-BALLR;
	ty=bally-BALLR-1;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
	  if(ballflag==0)
		{if(LEFTUP)incdx=-incdx;
		else if(LEFTDOWN)incdx=-incdx;
		else if(RIGHTUP)incdy=-incdy;
		ballx+=incdx;bally+=incdy;
		ballx+=incdx;bally+=incdy;
		}
	}

	tx=ballx-1-BALLR;
	ty=bally;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(ballflag==0)
		{
		if(LEFTDOWN)incdx=-incdx;
		else if(LEFTUP)incdx=-incdx;
		ballx+=incdx;bally+=incdy;
		ballx+=incdx;bally+=incdy;
		}
	}

	tx=ballx-1-BALLR;
	ty=bally+1+BALLR;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
	  if(ballflag==0)
		{if(LEFTDOWN)incdy=-incdy;
		else if(RIGHTDOWN)incdy=-incdy;
		else if(LEFTUP)incdx=-incdx;
		ballx+=incdx;bally+=incdy;
		ballx+=incdx;bally+=incdy;
		}
	}

	tx=ballx;
	ty=bally+1+BALLR;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(ballflag==0)
		{
		if(RIGHTDOWN)incdy=-incdy;
		else if(LEFTDOWN)incdy=-incdy;
		ballx+=incdx;bally+=incdy;
		ballx+=incdx;bally+=incdy;
		}
	}

	if(ballx<32+BALLR){incdx=-incdx;ballx=BALLR+32;}
	if(ballx>(SCREENWIDTH-BALLR-33)){incdx=-incdx;ballx=SCREENWIDTH-BALLR-33;}
	if(bally<BALLR){incdy=-incdy;bally=BALLR;}
	if(bally>465){incdy=-incdy;bally=465;}
	drawball(ballx,bally,14);
}


void fuballcontrol()
{
	int tx,ty,temp1,temp2,ddlong;
	if(!fuballflag)return;
	drawball(fuballx,fubally,0);
	if(fudx>=fudy)
	{
		fudistancex+=fudy;
		fudistancey+=fudy;
		if(fudistancex>=fudx){fudistancex=fudistancex-fudx;fuballx+=fuincdx;}
		fudistancey=0;
		fubally+=fuincdy;
	}
	else
	{
		fudistancex+=fudx;
		fudistancey+=fudx;
		if(fudistancey>=fudy){fudistancey=fudistancey-fudy;fubally+=fuincdy;}
		fudistancex=0;
		fuballx+=fuincdx;
	}
	if(bally>=DEADY)
	{
		fuballflag=0;return;
	}
	if((fubally>=gany)&&(fubally<=(gany+1))&&(fuballx>ganx)&&(fuballx<(ganx+96)))
	{
		fuincdy=-fuincdy;fuincdx=fuincdx;
		ddlong=fuballx-ganx;
		if(fuincdx<0)
		{

			if(ddlong>=48){fuincdx=-1;fuincdy=-1;}
			if(ddlong<48){fuincdx=1;fuincdy=-1;}
			if(ddlong>48)ddlong-=48;

			fudx=48-ddlong;
			if(fudx<2)fudx=2;
			if(fudx>48)fudx=48;

			fudy=ddlong;
			if(fudy<2)fudy=2;
			if(fudy>48)fudy=48;


		}
		if(fuincdx>0)
		{
			if(ddlong>=48){fuincdx=1;fuincdy=-1;}
			if(ddlong<48){fuincdx=-1;fuincdy=-1;}
			if(ddlong>49)ddlong-=48;
			fudx=48-ddlong;
			if(fudx<2)fudx=2;
			if(fudx>46)fudx=46;

			fudy=ddlong;
			if(fudy<2)fudy=2;
			if(fudy>46)fudy=46;



		}
	}
	tx=fuballx+BALLR+1;
	ty=fubally+BALLR+1;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(LEFTDOWN)fuincdy=-fuincdy;
		else if(RIGHTDOWN)fuincdy=-fuincdy;
		else if(RIGHTUP)fuincdx=-fuincdx;
			 fuballx+=fuincdx;fubally+=fuincdy;
		fuballx+=fuincdx;fubally+=fuincdy;
	}

	tx=fuballx+BALLR+1;
	ty=fubally;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(RIGHTDOWN)fuincdx=-fuincdx;
		else if(RIGHTUP)fuincdx=-fuincdx;
		fuballx+=fuincdx;fubally+=fuincdy;
		fuballx+=fuincdx;fubally+=fuincdy;
	}

	tx=fuballx+BALLR+1;
	ty=fubally-BALLR-1;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(RIGHTDOWN)fuincdx=-fuincdx;
		else if(RIGHTUP)fuincdx=-fuincdx;
		else if(LEFTUP)fuincdy=-fuincdy;
		fuballx+=fuincdx;fubally+=fuincdy;
		fuballx+=fuincdx;fubally+=fuincdy;
	}

	tx=fuballx;
	ty=fubally-BALLR-1;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(LEFTUP)fuincdy=-fuincdy;
		else if(RIGHTUP)fuincdy=-fuincdy;
		else if(incdy<0)fuincdy=-fuincdy;
		fuballx+=fuincdx;fubally+=fuincdy;
		fuballx+=fuincdx;fubally+=fuincdy;
	}

	tx=fuballx-1-BALLR;
	ty=fubally-BALLR-1;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(LEFTUP)fuincdx=-fuincdx;
		else if(LEFTDOWN)fuincdx=-fuincdx;
		else if(RIGHTUP)fuincdy=-fuincdy;
		fuballx+=fuincdx;fubally+=fuincdy;
		fuballx+=fuincdx;fubally+=fuincdy;
	}

	tx=fuballx-1-BALLR;
	ty=fubally;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(LEFTDOWN)fuincdx=-fuincdx;
		else if(LEFTUP)fuincdx=-fuincdx;
		fuballx+=fuincdx;bally+=fuincdy;
		fuballx+=fuincdx;bally+=fuincdy;
	}

	tx=fuballx-1-BALLR;
	ty=fubally+1+BALLR;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(LEFTDOWN)fuincdy=-fuincdy;
		else if(RIGHTDOWN)fuincdy=-fuincdy;
		else if(LEFTUP)fuincdx=-fuincdx;
		fuballx+=fuincdx;fubally+=fuincdy;
		fuballx+=fuincdx;fubally+=fuincdy;
	}

	tx=fuballx;
	ty=fubally+1+BALLR;
	temp1=tx/ZHUANDX;
	temp2=ty/ZHUANDY;
	if(zhuan[temp2][temp1]!=ZHUANNONE)
	{
		deletezhuan(temp1,temp2);
		if(RIGHTDOWN)fuincdy=-fuincdy;
		else if(LEFTDOWN)fuincdy=-fuincdy;
		fuballx+=fuincdx;fubally+=fuincdy;
		fuballx+=fuincdx;fubally+=fuincdy;
	}

	if(fuballx<BALLR){fuincdx=-fuincdx;fuballx=BALLR;}
	if(fuballx>(SCREENWIDTH-BALLR-1)){fuincdx=-fuincdx;fuballx=SCREENWIDTH-BALLR-1;}
	if(fubally<BALLR){fuincdy=-fuincdy;fubally=BALLR;}
	drawball(fuballx,fubally,14);
}
int delaytime(long n)
{
	int hour,min,s,bais,baisbak;
	long oldtime,newtime,temp,timedelta;
	int oldday,nowday;

	_AH=0x2c;
	geninterrupt(0x21);
	hour=_CH;
	min=_CL;
	s=_DH;
	bais=_DL;
	/*baisbak=bais;*/
	oldtime=(long)hour*360000L+min*6000L+s*100L+(long)bais;
	if((24L*360000L-1L-oldtime)>=n)
	{
		do
		{       busy=1;/*����BUSY��������Ϊ����ʱ��INT 1CH��ͻ*/
                	_AH=0x2c;
			geninterrupt(0x21);
			busy=0;
			hour=_CH;
			min=_CL;
			s=_DH;
			bais=_DL;
			/*if(baisbak!=bais){ballcontrol();ballcontrol();ballcontrol();ballcontrol();baisbak=bais;}*/
			newtime=(long)hour*60L*60L*100L+min*60L*100L+s*100L+bais;
			timedelta=newtime-oldtime;
			if(timedelta<0)return;
			delay(1);
		}while(timedelta<n);
	}
	else{
		busy=1;
		_AH=0x2a;
		geninterrupt(0x21);
		busy=0;
		oldday=_DL;
		temp=24*360000L-1-oldtime;
		temp=n-temp;
		do{
                        busy=1;
			_AH=0x2a;
			geninterrupt(0x21);
			busy=0;
			nowday=_DL;
			busy=1;
			_AH=0x2c;
			geninterrupt(0x21);
			busy=0;
			hour=_CH;
			min=_CL;
			s=_DH;
			bais=_DL;
			newtime=(long)hour*360000L+min*6000+s*100+bais;
		    }while(newtime>temp&&(((nowday==oldday)&&newtime>oldtime)||((nowday!=oldday)&&newtime<oldtime)));

	    }
}

int outdostime()
{
	struct time t;
	static char temps=1;
	unsigned char far *buf=(char far *)0xb8000000+144;
	int oldx,oldy,x,y,n,m;
	int hour,min,s;
	char chr[9];
	/*_AH=0x2c;
	geninterrupt(0x21);
	hour=_CH;
	min=_CL;
	s=_DH;*/
	gettime(&t);
	hour=t.ti_hour;
	min=t.ti_min;
	s=t.ti_sec;

	if(s!=temps)
	{
		temps=s;

		sprintf(chr,"%d:%d:%d",hour,min,s);
		n=strlen(chr);
		for(m=n;m<8;m++)chr[m]=32;
		chr[7]=0;

		for(m=1;m<(n<<1);m+=2)
		*(buf+m)=14;
		for(m=0;m<8;m++)
		*(buf+m*2)=chr[m];


		/*oldx=wherex();
		oldy=wherey();
		textcolor(9);
		textbackground(14);
		gotoxy(71,1);
		cprintf("%s",chr);
		gotoxy(oldx,oldy);
		textcolor(8);
		textbackground(0);*/

	}
}



int outtime(int flag)
{
	static char temps=1;
	int hour,min,s;
	char chr[9];
	_AH=0x2c;
	geninterrupt(0x21);
	hour=_CH;
	min=_CL;
	s=_DH;
	if(s!=temps||flag)
	{
		temps=s;

		sprintf(chr,"%d:%d:%d",hour,min,s);
		drawbar(639-32-((8-strlen(chr))<<4),463,639-32,479,0);
		outchineseasciiback(639-32-128,463,0,15,0,chr);
		/*if(hour<10)
		{
			outchinesenum(40,0,0,15,0);
			outchinesenum(56,0,0,15,hour);
			outchineseascii(72,0,0,15,":");
		}
		else
		{
			outchinesenum(40,0,0,15,hour);
			outchineseascii(72,0,0,15,":");
		}
		if(min<10)
		{
			outchinesenum(88,0,0,15,0);
			outchinesenum(88+16,0,0,15,min);
			outchineseascii(88+32,0,0,15,":");
		}
		else
		{
			outchinesenum(88,0,0,15,min);
			outchineseascii(88+32,0,0,15,":");
		}
		if(s<10)
		{
			outchinesenum(120,0,0,15,0);
			outchinesenum(120+16,0,0,15,s);
			outchineseascii(120+32,0,0,15,":");
		}
		else
		{
			outchinesenum(120,0,0,15,s);
			outchineseascii(120+32,0,0,15,":");
		}       */
	}
}

void interrupt newint1ch()
{
int n,i;
(*oldint1ch)();
if(busy){enable();return;}
if(dosshellflag)
{
	/*outdostime();*/
	enable();return;
}

if(foodflag==1&&foodn>=0){foodcontrol();foodn=0;}
else if(foodflag==1)foodn++;
outtime(0);
if(lifebusy){enable();return;}
if(int1chflag){enable();return;}
if(soundflag==1)
{
	if(soundn>7){soundflag=0;nosound();goto ENND;}
	if(sound1n<soundword[soundn][1]){gamesound(soundword[soundn][0]);sound1n++;}
	else{soundn++;sound1n=0;}
}
ENND:
ballcontrol();
}

int foodcontrol()
{
	int zx,zy,ty;
	int xx,xy;
	zx=food.x/ZHUANDX;
	zy=food.y/ZHUANDY;
	xx=zx*ZHUANDX;
	xy=zy*ZHUANDY;

	drawzhuan(xx,xy,zhuan[zy][zx]);
	drawzhuan(xx+32,xy,zhuan[zy][zx+1]);
	drawzhuan(xx,xy+12,zhuan[zy+1][zx]);
	drawzhuan(xx+32,xy+12,zhuan[zy+1][zx+1]);
	/*drawzhuan(xx,xy+24,zhuan[zy+2][zx]);
	drawzhuan(xx+32,xy+24,zhuan[zy+2][zx+1]);
	drawzhuan(xx,xy+36,zhuan[zy+3][zx]);
	drawzhuan(xx+32,xy+36,zhuan[zy+3][zx+1]);*/

	if(food.dx>=food.dy)
	{
		distancefoodx+=food.dy;
		distancefoody+=food.dy;
		if(distancefoodx>=food.dx){distancefoodx=distancefoodx-food.dx;food.x+=food.incdx;}
		distancefoody=0;
		food.y+=food.incdy;
	}
	else
	{
		distancefoodx+=food.dx;
		distancefoody+=food.dx;
		if(distancefoody>=food.dy){distancefoody=distancefoody-food.dy;food.y+=food.incdy;}
		distancefoodx=0;
		food.x+=food.incdx;
	}
	if(food.x<33)
	{	food.incdx=-food.incdx;
		food.x=34;
	}
	if(food.x>(639-64))
	{
		food.incdx=-food.incdx;
		food.x=639-65;
	}
	if((food.y>=(gany-12))&&(food.y<=(gany-12+1))&&(food.x>ganx)&&(food.x<(ganx+96)))
	{
		switch(food.index)
		{
			case 1:life++;
				soundword[ 0][ 0]=400;soundword[ 0][ 1]=120;
				soundword[ 1][ 0]=500;soundword[ 1][ 1]=150;
				soundword[ 2][ 0]=600;soundword[ 2][ 1]=1110;
				soundword[ 3][ 0]=350;soundword[ 3][ 1]=190;
				soundword[ 4][ 0]=800;soundword[ 3][ 1]=1250;
				soundword[ 5][ 0]=480;soundword[ 5][ 1]=130;
				soundword[ 6][ 0]=220;soundword[ 6][ 1]=140;
				soundword[ 7][ 0]=330;soundword[ 7][ 1]=1350;
				soundword[ 8][ 0]=0;soundword[ 8][ 1]=0;
				soundword[ 9][ 0]=0;soundword[ 9][ 1]=0;

				soundn=0;
				sound1n=0;
				soundflag=1;
				nosound();
				outlife();
				break;
			case 2:if(shudu<800){shudu=shudu+100;
				changetime(shudu);}
				break;
			case 3:if(shudu>200){shudu=shudu-100;
				changetime(shudu);}
				break;
			case 4:
                                life--;danmap6flag=0;outlife();fuballflag=0;drawball(fuballx,fubally,0);
				ballflag=0;
				changetime(217);shudu=217;
				soundword[ 0][ 0]=400;soundword[ 0][ 1]=3;
				soundword[ 1][ 0]=800;soundword[ 1][ 1]=14;
				soundword[ 2][ 0]=400;soundword[ 2][ 1]=3;
				soundword[ 3][ 0]=800;soundword[ 3][ 1]=5;
				soundword[ 4][ 0]=400;soundword[ 3][ 1]=2;
				soundword[ 5][ 0]=800;soundword[ 5][ 1]=18;
				soundword[ 6][ 0]=400;soundword[ 6][ 1]=7;
				soundword[ 7][ 0]=800;soundword[ 7][ 1]=28;
				soundword[ 8][ 0]=400;soundword[ 8][ 1]=29;
				soundword[ 9][ 0]=800;soundword[ 9][ 1]=51;
				soundn=0;
				sound1n=0;
				soundflag=1;
				nosound();
				if(life<0){dead=GAMEOVER;nosound();return;}
				else {
					ganx=320-48;
					setmousexy(ganx,gany);
					balln=15;
					ballx=320,bally=gany,dead=0;
					dx=1.0,dy=1.0,distancex=0,distancey=0;
					incdx=-1,incdy=-1;
					jiao=45;
					initdrawzhuan();
					outlife();
					outfen();
					drawgan(ganx,gany,14);
					drawball(ballx,bally,14);
					lifebusy=1;
				}
				break;
			case 5:ballflag=12;break;
			case 6:danmap6flag=1;break;
		}
		fen=fen+100;

		outfen();
		foodflag=0;
		drawbar(food.x,food.y,food.x+12,food.y+12,0);
		if((food.x+32)>ganx&&food.x<(ganx+96)&&food.y>(gany-25))drawgan(ganx,gany,14);
		drawgan(ganx,gany,1);
	}
	else if(food.y>gany-5)
	{
		foodflag=0;
		drawbar(food.x,food.y,food.x+12,food.y+12,0);
                if((food.x+32)>ganx&&food.x<(ganx+96)&&food.y>(gany-25))drawgan(ganx,gany,14);

	}
	if(foodflag==1)drawfoodmap(food.x,food.y);
	busy=0;
}



int init1ch(int fg)
{
if(fg==1)int1chflag=1;
else
{
oldint1ch=getvect(0x1c);
changetime(shudu);
setvect(0x1c,newint1ch);
}
}


unsigned int systemcontrol()
{
	int mousex,mk,m,n,tx,temp,x,y;
	lastascii='\0';
	init1ch(0);
	while(1)
	{
		CONTINUE:
		if(zhuancontrol()==1){close1ch(0);return(OKOK);}
		while(!lastascii)
		{
                        if(danmap6flagflag)
			{
				lifebusy=1;
				busy=0;
				drawball(ballx,bally,14);
				tx=ballx-ganx;
				while(!lastascii)
				{
					lifebusy=1;
					_AX=3;geninterrupt(0x33);
					if(_BX)break;
					mx=_CX;
					if(mx!=ganx)
					{
						drawgan(ganx,gany,0);
						drawball(ballx,bally,0);
						ganx=mx;
						ballx=ganx+tx;
						drawball(ballx,bally,14);
						drawgan(ganx,gany,15);
					}
				}
				lifebusy=0;danmap6flagflag=0;
			}
			if((dead==GAMEOVER)/*||(dead==ESC)*/)
			{
				close1ch(0);save();
                                restoretime();
				rgbcolor(255,0,0,0);
				rgbcolor(0,0,0,0);
				return(RESTART);
				/*closegraphics();
				printf("\n\n\n\t\t\tGame Over!!!");
				closekeyboard();closechinese();exit(0);*/
			}
			if(lifebusy)
			{
				drawgan(ganx,gany,0);
				ganx=320-48;
				setmousexy(ganx,gany);
				drawgan(ganx,gany,7);
				outlife();
				while(!lastascii)
				{
					_AX=3;geninterrupt(0x33);
					if(_BX)break;
					mx=_CX;
					if(mx!=ganx)
					{
						drawgan(ganx,gany,0);
						drawball(ballx,bally,0);
						ganx=mx;
						ballx=ganx+48;
						drawball(ballx,bally,14);
						drawgan(ganx,gany,15);
					}
				}
				lifebusy=0;
			}
			if(zhuancontrol()==1)
			{
				close1ch(0);return(OKOK);
			}
			_AX=3;
			geninterrupt(0x33);
			mousex=_CX;
			temp=_BX;
			if(temp&2){waitupmouse();lastascii=27;}
			if(mousex!=ganx)
			{
				if(shudun>30)
				{
					if(shudu<800)
					{	shudu+=1;
						changetime(shudu);
					}
					shudun=0;
				}
				else shudun++;
				drawgan(ganx,gany,0);
				ganx=mousex;
				drawgan(ganx,gany,15);
			}
		}
		switch(lastascii)
		{
			case 'n':
			case 'N':nosound();break;
			case KEY_CTRLBREAK:
					close1ch(0);getbmp();init1ch(0);break;
			case KEY_INSERT:
					close1ch(0);
					for(m=1;m<35;m++)
					for(n=1;n<=18;n++)
					deletezhuan(n,m);
					init1ch(0);
					break;
			case KEY_F11:if(life<127){life++;outlife();}
				     break;
			case KEY_F12:if(1)ballflag=12;break;
			case 'd':
			case 'D':
				/*close1ch(0);*/
				restoretime();
				busy=1;
				closekeyboard();closegraphics();
				dosshellflag=1;
				busy=0;
				nosound();
				system("command /k prompt Please Enter EXIT return game -- By Explorer$_$p$g");
				dosshellflag=0;
				initkeyboard();initgraphics();initdrawzhuan();
				outlife();
				outfen();
				drawgan(ganx,gany,15);drawball(ballx,bally,14);
				setpalette15();
				setdanmousebar();
				/*init1ch(0);*/
				changetime(shudu);
				break;
			case 'p':
			case 'P':
				nosound();/*init1ch(1);*/close1ch(0);lastascii=0;setmousefilebar();hidemouse();showmouse();waitmouseandkey();/*close1ch(1);*/init1ch(0);
				setdanmousebar();showmouse();hidemouse();
				setmousexy(ganx,gany);
				break;
			case 's':
			case 'S':if(shudu<800){shudu+=20;changetime(shudu);}break;
			case KEY_LEFT:if(ganx>=48+31)
			{
				drawgan(ganx,gany,0);
				ganx-=48;
				setmousexy(ganx,gany);
				drawgan(ganx,gany,15);
			}
			else
                        {
				drawgan(ganx,gany,0);
				ganx=32;
				setmousexy(ganx,gany);
				drawgan(ganx,gany,15);
			}
			break;
			case KEY_RIGHT:if(ganx<(639-96-31))
			{
				drawgan(ganx,gany,0);
				ganx+=48;
				setmousexy(ganx,gany);
				drawgan(ganx,gany,15);
			}
			else
                        {
				drawgan(ganx,gany,0);
				ganx=639-96-31;
				setmousexy(ganx,gany);
				drawgan(ganx,gany,15);
			}
			break;
			case 32:close1ch(0);initdrawzhuan();
			outlife();
                        outfen();
			drawgan(ganx,gany,15);init1ch(0);break;
			case 27:dead=ESC;lastascii=0;
				switch(end())
				{
					case BACK:
							initdrawzhuan();
							outlife();
							outfen();
							drawgan(ganx,gany,15);return(BACK);
					case RESTART:return(RESTART);
					case GAMECONTINUEBACK:
						showmouse();
						hidemouse();
						for(y=100;y<=282+32;y+=12)
						for(x=208;x<=208+32*8;x+=32)
						{
							m=y/12;
							n=x/32;
							drawzhuan(n*32,m*12,zhuan[m][n]);
						}
						/*initdrawzhuan();*/
						showmouse();
						hidemouse();
						outlife();
						outfen();
						drawgan(ganx,gany,15);
						setdanmousebar();
						init1ch(0);
						changetime(shudu);
						showmouse();hidemouse();
						setdanmousebar();
						setmousexy(ganx,gany);
						goto CONTINUE;
				}
		}
		lastascii='\0';
	}
}


void outstep()
{
	int x;
	nosound();
	hidemouse();
	drawbar(0,0,639,479,0);
	/*outchineseascii(200,700,0,14,"Waiting...");
	/*showbmp("t256-1.bmp",0,0);*/
	/*showbmp("zhuo16.bmp",(640-344)/2,100);*/
	outchinesekongn((640-32*9-8*16)/2,100,14,1,"���浯����Ǯ����",2,2);
	outchinesen(150,200,0,15,"��",3,3);
	if(step<=9)x=320-3*8;
	else if(step<=99)x=320-45;
	else if(step<=999)x=320-65;
	else if(step<=9999)x=320-94;
	outchinesenumn(x,200,0,7,(long)step,4,4);
	outchinesen(490,200,0,15,"��",3,3);
	outchinese(639-9*16,460,0,14,"����Ϸ����������");
	setmousefilebar();
	showmouse();
	waitmouseandkey();
	setdanmousebar();
}



int initstep()
{	cls(0);
	ballflag=0;
	outlife();
	ganx=320-48;
	danmap6flag=0;
	setmousexy(ganx,gany);
	balln=15;
	ballx=320,bally=gany,dead=0;
	dx=1.0,dy=1.0,distancex=0,distancey=0;
	incdx=-1,incdy=-1;
	jiao=45;
	initdrawzhuan();outlife();
	drawgan(ganx,gany,14);
	drawball(ballx,bally,14);
	outfen();
	changetime(217);
	init1ch(0);
	init1ch(1);
	while(!lastascii)
	{

		_AX=3;geninterrupt(0x33);

		if(_BX)break;;
		mx=_CX;
		if(mx!=ganx)
			{
				drawgan(ganx,gany,0);
				drawball(ballx,bally,0);
				ganx=mx;
				ballx=ganx+48;
				drawball(ballx,bally,14);
				drawgan(ganx,gany,15);
			}
	}
	close1ch(0);
	close1ch(1);
	return(systemcontrol());

}

int step1()
{

	step=1;

	outstep();
	initzhuandata(1);
	return(initstep());

}

int step2()
{
	step=2;
	outstep();
	initzhuandata(2);
	return(initstep());
}

int step3()
{
	step=3;
	outstep();
	initzhuandata(3);
	return(initstep());
}
int step4()
{
	step=4;
	outstep();
	initzhuandata(4);
	return(initstep());
}

int step5()
{
	step=5;
	outstep();
	initzhuandata(5);
	return(initstep());
}
int step6()
{
	step=6;
	outstep();
	initzhuandata(6);
	return(initstep());
}

int step7()
{
	step++;
	stepflag=0;
	outstep();
	initzhuandata(8);
	return(initstep());
}
int step8()
{
	int temp;
	step++;
	stepflag=7;

	outstep();
	initzhuandata(7);
	temp=initstep();
	setpalette15();
	return(temp);
}

int step9()
{
	int temp;
	step++;
	if(step<50)
	stepflag=12;
	else stepflag=0;
	outstep();
	initzhuandata(9);
	temp=initstep();
	setpalette15();
	return(temp);
}


int save()
{
	long i,mixi,j,maxi;
	long mix,max,templ;
	int tempchr[39],co;
	int tempname[39];
	FILE *fp,*fp1;
	struct SAVE save[10],save1[10];
	long temp[10];

	fp=fopen("dan.ov1","r");
	fread(&save,sizeof(struct SAVE),10,fp);
	fclose(fp);
	for(i=0;i<10;i++)
	{
	 if(save[i].fen>9999999L)save[i].fen=0;
	 }
	mix=save[0].fen;mixi=0;
	for(i=1;i<10;i++)
	{       if(mix>save[i].fen)
		{
			mix=save[i].fen;mixi=i;
		}
	}


	if(save[mixi].fen<fen)
	{
		tscanfimage640(10,20,"Name:",tempname,18,9);
		tempname[39]=0;
		save[mixi].fen=fen;
		if(life>=5)save[mixi].flag=1;
		if(life>=10)save[mixi].flag=2;
		if(life==15)save[mixi].flag=3;
		for(i=0;i<40;i++)
		save[mixi].name[i]=tempname[i];
		WRITE:

		fp=fopen("dan.ov2","w");
		fwrite(&save,sizeof(struct SAVE),10,fp);fclose(fp);
		fclose(fp);
		fp=fopen("dan.ov1","w");
		fwrite(&save,sizeof(struct SAVE),10,fp);fclose(fp);
	}

/*drawbar(0,0,639,479,0);

fp=fopen("dan.ov2","r");
fread(&save1,sizeof(struct SAVE),10,fp);
fclose(fp);


for(i=0;i<10;i++)
{
	max=save1[i].fen;maxi=i;
	for(j=i+1;j<10;j++)
	{
		if(max<=save1[j].fen)
		{
		max=save1[j].fen;maxi=j;
		}
	}
	temp[i]=maxi;
	strcpy(tempchr,save1[maxi].name);
	strcpy(save1[maxi].name,save1[i].name);
	strcpy(save1[i].name,tempchr);
	templ=save1[maxi].fen;
	save1[maxi].fen=save1[i].fen;
	save1[i].fen=templ;
}

j=0;
outchinesekongn((640-3*16*2-20)/2,20,10,14,"���а�",2,2);
drawbar(0,68,639,70,2);
drawbar(0,72,639,72,10);
for(i=82;i<82+10*26;i+=26)
{
	if(j>9)break;
	if(j%2)co=GREEN;
	else co=13;
	outchinesenumy(20,i,0,co,7,j+1,1,1);
	outchineseasciiying(100,i,0,co,7,(unsigned char *)save1[j].name,1,1);
	outchinesenum(450,i,0,co,7,save1[j].fen,1,1);
	j++;
}
drawbar(0,92+260,639,92+260,10);
drawbar(0,94+260,639,96+260,2);
getkey();*/
}

void soun()
{
gamesound(500);delaytime(3);gamesound(900);delaytime(1);gamesound(400);delaytime(5);nosound();
}

int nofileexit(char *str,FILE *fp)
{
	 printf("%s file not exist\n",str);
	 fclose(fp);
	 exit(0);
}
void testfileexist()
{
	FILE *fp;
	if((fp=fopen("dan.exe","rb"))==NULL)
	nofileexit("Dan.exe",fp);
	if((fp=fopen("dan.ov1","rb"))==NULL)
	nofileexit("Dan.ov1",fp);
	if((fp=fopen("Dan.ov2","rb"))==NULL)
	nofileexit("Dan.ov2",fp);
	if((fp=fopen("Danmap1","rb"))==NULL)
	nofileexit("Danmap1",fp);
	if((fp=fopen("Danmap2","rb"))==NULL)
	nofileexit("Danmap2",fp);
	if((fp=fopen("Danmap3","rb"))==NULL)
	nofileexit("Danmap3",fp);
	if((fp=fopen("Danmap4","rb"))==NULL)
	nofileexit("Danmap4",fp);
	if((fp=fopen("Danmap5","rb"))==NULL)
	nofileexit("Danmap5",fp);
	if((fp=fopen("Danmap6","rb"))==NULL)
	nofileexit("Danmap6",fp);
	if((fp=fopen("Hzk16","rb"))==NULL)
	nofileexit("Hzk16",fp);
}

void help()
{
hidemouse();
drawbar(0,0,639,479,0);
	outchineseyingn(100,100,30,1,7,"�ȼ�",-3,-3,5,5);
	outchineseying(100,200,0,LIGHTGREEN,GREEN,"�У���ͣ",-1,-1);
	outchineseying(100,230,0,LIGHTGREEN,GREEN,"�ģ��ݻأ���",-1,-1);
	outchineseying(100,260,0,LIGHTGREEN,GREEN,"�ӣ�����",-1,-1);
	outchineseying(100,290,0,LIGHTGREEN,GREEN,"�ţӣã��˳�",-1,-1);
	outchineseying(100,320,0,LIGHTGREEN,GREEN,"�ã���죭�£���룭����Ϸ��Ļ����Ϊ�ԣţͣС��£ͣ�",-1,-1);
	outchineseying(100,350,0,LIGHTGREEN,GREEN,"����Ҽ�������Ϸ�е����˵��������Ϸ",-1,-1);
	setstartxy(0,0);
	showmouse();
	waitmouseandkey();
	hidemouse();
	drawbar(0,0,639,479,0);
	loadfoodmap(1);
	drawfoodmap(50,20);
	outchinesekong(150,18,0,13,"��һ����");

	loadfoodmap(2);
	drawfoodmap(50,50);
	outchinesekong(150,48,0,13,"���������");
	loadfoodmap(3);
	drawfoodmap(50,80);
	outchinesekong(150,78,0,13,"���������");

	loadfoodmap(4);
	drawfoodmap(50,110);
	outchinesekong(150,108,0,13,"��ǰ����������");

	loadfoodmap(5);
	drawfoodmap(50,140);
	outchinesekong(150,138,0,13,"�����ۻ��κ�ש��ĳ���");

	loadfoodmap(6);
	drawfoodmap(50,170);
	outchinesekong(150,168,0,13,"ʹ�˾���������ĳ���");
	lastascii=0;
	showmouse();
	waitmouseandkey();
	showmouse();

}

int list()
{
	int i,j;
	long mixi,maxi;
	long mix,max,templ;
	int tempchr[39],co;
	int tempname[39];
	FILE *fp,*fp1;
	struct SAVE save[10],save1[10];
	long temp[10];

drawbar(0,0,639,479,0);

fp=fopen("dan.ov2","r");
fread(&save1,sizeof(struct SAVE),10,fp);
fclose(fp);


for(i=0;i<10;i++)
{
	max=save1[i].fen;maxi=i;
	for(j=i+1;j<10;j++)
	{
		if(max<=save1[j].fen)
		{
		max=save1[j].fen;maxi=j;
		}
	}
	temp[i]=maxi;
	strcpy(tempchr,save1[maxi].name);
	strcpy(save1[maxi].name,save1[i].name);
	strcpy(save1[i].name,tempchr);
	templ=save1[maxi].fen;
	save1[maxi].fen=save1[i].fen;
	save1[i].fen=templ;
}

j=0;
outchinesekongn((640-3*16*2-20)/2,20,10,14,"���а�",2,2);
drawbar(0,68,639,70,2);
drawbar(0,72,639,72,10);
for(i=82;i<82+10*36;i+=36)
{
	if(j%2)co=GREEN;
	else co=13;
	outchinesenum(20,i,0,co,(long)(j+1));
	if(save1[j].fen!=0)
	outchineseasciiying(100,i,0,co,7,(unsigned char *)save1[j].name,1,1);
	else outchineseasciiying(100,i,0,co,7,"None\n",1,1);
	outchinesenum(450,i,0,co,save1[j].fen);
	j++;
}
drawbar(0,92+350,639,92+350,10);
drawbar(0,94+350,639,96+350,2);
waitmouseandkey();
}

initall()
{
testfileexist();
randomize();
initkeyboard();
if(!checkmouse()){printf("\nPlease run mouse.com first!\n");rgbcolor(255,0,0,0);
				rgbcolor(0,0,0,0);closekeyboard();exit(0);}
	if(!initchinese()){closekeyboard();exit(0);}
	printf("\nLoading hzk16...");

	printf("\nLoading maps...");
	initloadfoodmap();
	if(!initgraphics())
	{
		printf("\Not VESA VGA Card! Can't run in 640x480x256 graphics mode!\n");
		closechinese();
		closegraphics();
		closekeyboard();
		exit(0);
	}
	initmouse();
	list();
	drawbar(0,0,639,479,0);
	hidemouse();

	rgbcolor(255,0,0,0);
	setpalette15();

	outchineseyingn(50,200,35,9,7,"�����ש��",2,2,4,4);
	outchineseying(350,450,0,1,8,"Ǯ����һ�žž�������ʮһ���ں�����ר",2,2);
	showmouse();
	waitmouseandkey();
	hidemouse();

	setdanmousebar();
}
void initallvalue()
{
	fuballx=0;fubally=0;
	 fudx=1.0;fudy=1.0;fudistancex=0;fudistancey=0;
	 fuincdx=1;fuincdy=1;
	 ballx=INITBALLX;bally=INITBALLY;dead=0;
	 busy=0;lifebusy=0;
	 dx=1.0;dy=1.0;distancex=0;distancey=0;
	 distancefoodx=0;distancefoody=0;
	 incdx=1;incdy=1;
	 jiao=45;
	 step=1;
	 fen=0;
	 fentemp=0;ganx=0;gany=440;
	 balln=15;balldelay=0;life=3;
}
void main()
{
int i,n;
initall();
AA:
GAMESTART:

	initallvalue();
	hidemouse();
	drawbar(0,0,639,479,0);
	showmouse();
	setmousefilebar();
	switch(startcai())
	{
		case START:break;
		case HELP:help();delaytime(50);hidemouse();
			drawbar(0,0,639,479,0);drawstartcai(4);
			showmouse();goto AA;
	}
if(step1()==RESTART)goto GAMESTART;
soun();if(step2()==RESTART)goto GAMESTART;soun();
if(step3()==RESTART)goto GAMESTART;
soun();if(step4()==RESTART)goto GAMESTART;
soun();if(step5()==RESTART)goto GAMESTART;
if(step6()==RESTART)goto GAMESTART;
if(step7()==RESTART)goto GAMESTART;

for(i=0;i<=92;i++)
{
	n=random(100);
	if(n>90){step8();stepflag=0;}
	else if(n>20){if(step9()==RESTART)goto GAMESTART;}
	else
	if(step7()==RESTART)goto GAMESTART;
}
save();closegraphics();closekeyboard();printf("Your Win\n");closekeyboard();restoretime();while(bioskey(1))getch();
closechinese();
nosound();
rgbcolor(255,0,0,0);
rgbcolor(0,0,0,0);
}