/******************* ( Animation Construction Kit 3D ) ***********************/
/*		       Display ViewWindow to Screen			     */
/* CopyRight (c) 1993	   Author: Lary Myers				     */
/*****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <dos.h>
#include <mem.h>
#include <alloc.h>
#include <io.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>
#include <sys\stat.h>
#include "ack3d.h"
#include "ackeng.h"


void AckDrawPage(int,int,UCHAR far *,int,int,int);


/****************************************************************************
** This routine simply pulls out the needed information from the ACKENG	   **
** structure before calling the assembly routine to do the actual display. **
**									   **
****************************************************************************/
int AckDisplayScreen(ACKENG *ae)
{

/* Let the assembly routine do the hard work */

AckDrawPage(ae->WinStartOffset,
	    ae->WinLength,
	    ae->ScreenBuffer,
	    ae->WinWidth,
	    ae->WinHeight,
	    ae->WinStartX);

return(0);
}

