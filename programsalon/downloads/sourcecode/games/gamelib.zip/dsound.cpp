#include "graphics.h"

LPDIRECTSOUND       lpDS;         // DirectSound����
LPDIRECTSOUNDBUFFER lpDSBPrimary; // ������������
WAVEFORMATEX         wf;

BOOL sound_init = FALSE;
BOOL sound_on = TRUE, music_on = TRUE; // ��Ч�����ֿ���
long sample_pan, sample_volume; // ��Ч�ľ��������
long music_pan, music_volume; // ���ֵľ��������
STATICSOUND static_buffer[MAXSAMPLE]; // ��Ч������
STREAMSOUND stream_buffer; // ���ֻ�����
HANDLE sound_event[MAXSAMPLE * 2 + 2]; // �����������¼�����
HANDLE DS_Thread = NULL; // DirectSound�߳�
DWORD DirectSoundThreadID; // DirectSound�߳�ID

// ��ʼ��DirectSound
BOOL init_directsound()
{
	// ����DirectSound����
	if (DirectSoundCreate(NULL, &lpDS, NULL) != DS_OK)
	{
		// ����DirectSound����ʧ��
		sound_on = music_on = FALSE;
		return FALSE;
	}
	// ����DirectSoundЭ����
	if (lpDS->SetCooperativeLevel(hWnd, DSSCL_PRIORITY) != DD_OK)
	{
		// ����DirectSoundЭ����ʧ��
		free_directsound();
		return FALSE;
	}
	DSBUFFERDESC dsbdesc;
	ZeroMemory(&dsbdesc, sizeof(dsbdesc));
	dsbdesc.dwSize = sizeof(dsbdesc);
	dsbdesc.dwFlags = DSBCAPS_PRIMARYBUFFER;
	// ����������������
	if(lpDS->CreateSoundBuffer(&dsbdesc, &lpDSBPrimary,NULL) != DS_OK)
	{
		free_directsound();
		return FALSE;
	}
	// ������������������ʽ
	wf.wFormatTag = WAVE_FORMAT_PCM;
	wf.nChannels = 2;
	wf.wBitsPerSample = SOUNDBPS;
	wf.nSamplesPerSec = SOUNDSPS;
	wf.nBlockAlign = (SOUNDBPS * 2) >> 3;
	wf.nAvgBytesPerSec = SOUNDSPS * wf.nBlockAlign;
	wf.cbSize = 0;
	if (lpDSBPrimary->SetFormat(&wf) != DS_OK)
	{
		// ������������������ʽʧ��
		free_directsound();
		return FALSE;
	}
	lpDSBPrimary->Play(0, 0, DSBPLAY_LOOPING);
	// ����������������
	dsbdesc.dwSize = sizeof(dsbdesc);
	dsbdesc.dwFlags = DSBCAPS_GETCURRENTPOSITION2 |
		DSBCAPS_CTRLPOSITIONNOTIFY | DSBCAPS_CTRLPAN |
		DSBCAPS_CTRLVOLUME;
	dsbdesc.dwBufferBytes = MUSIC_BUFFER_SIZE;
	dsbdesc.lpwfxFormat = &wf;
	dsbdesc.dwReserved = 0;
	if (lpDS->CreateSoundBuffer(&dsbdesc, &stream_buffer.lpDSB, NULL) != DS_OK)
	{
		// ����������������ʧ��
		free_directsound();
		return FALSE;
	}
	if (stream_buffer.lpDSB->QueryInterface(IID_IDirectSoundNotify, (void **)&stream_buffer.lpDSN) != DS_OK)
	{
		// �����������������¼�����ʧ��
		free_directsound();
		return FALSE;
	}
	HANDLE event;
	event = CreateEvent(NULL, FALSE, FALSE, NULL);
	sound_event[MAXSAMPLE*2] = event;
	stream_buffer.dsbpn[0].hEventNotify = event;
	stream_buffer.dsbpn[0].dwOffset = 0;
	event = CreateEvent(NULL, FALSE, FALSE, NULL);
	sound_event[MAXSAMPLE * 2 + 1] = event;
	stream_buffer.dsbpn[1].hEventNotify = event;
	stream_buffer.dsbpn[1].dwOffset = MUSIC_BUFFER_SIZE >> 1;
	stream_buffer.pan = music_pan;
	stream_buffer.volume = music_volume;
	if (stream_buffer.lpDSN->SetNotificationPositions(2, stream_buffer.dsbpn) != DS_OK)
	{
		// �����������������¼�����ʧ��
		free_directsound();
		return FALSE;
	}
	stream_buffer.music = NULL;

	// ���û�����
	STATICSOUND *ss;
	dsbdesc.dwSize = sizeof(dsbdesc);
	dsbdesc.dwFlags = DSBCAPS_GETCURRENTPOSITION2 |
		DSBCAPS_CTRLPOSITIONNOTIFY | DSBCAPS_CTRLPAN |
		DSBCAPS_CTRLVOLUME;
	dsbdesc.dwBufferBytes = SAMPLE_BUFFER_SIZE;
	dsbdesc.lpwfxFormat = &wf;
	dsbdesc.dwReserved = 0;

	ss = &static_buffer[0];
	for (int i = 0; i < MAXSAMPLE; i++, ss++)
	{
		// ����������
		if (lpDS->CreateSoundBuffer(&dsbdesc, &(ss->lpDSB), NULL) != DS_OK)
		{
			// ������̬����������ʧ��
			free_directsound();
			return FALSE;
		}
		if (ss->lpDSB->QueryInterface(IID_IDirectSoundNotify, (void **)&ss->lpDSN) != DS_OK)
		{
			// ��������������ʧ��
			free_directsound();
			return FALSE;
		}
		ss->status = -1;
		event = CreateEvent(NULL, FALSE, FALSE, NULL);
		sound_event[i << 1] = event;
		ss->dsbpn[0].hEventNotify = event;
		ss->dsbpn[0].dwOffset = 0;
		event = CreateEvent(NULL, FALSE, FALSE, NULL);
		sound_event[(i << 1) + 1] = event;
		ss->dsbpn[1].hEventNotify = event;
		ss->dsbpn[1].dwOffset = SAMPLE_BUFFER_SIZE >> 1;
		ss->pan = sample_pan;
		ss->volume = sample_volume;
		if (ss->lpDSN->SetNotificationPositions(2, ss->dsbpn) != DS_OK)
		{
			// ��������������ʧ��
			free_directsound();
			return FALSE;
		}
	}
	// �������߳�
	if(!(DS_Thread = CreateThread(NULL, 0, DirectSoundThread, NULL, 0, &DirectSoundThreadID)))
	{
		free_directsound();
		put_message(TRUE, "���󣬴������������߳�ʧ�ܡ�");
	}

	return TRUE;
}

// ��ȡ��Ч�ļ�
SAMPLE *load_sample(char *filename)
{
	FILE *fp;
	SAMPLE *sample;
	sample = new SAMPLE;
	put_message(sample == NULL, "����û���㹻���ڴ档");
	sample->number = -1;
	fp = fopen(filename, "rb");
	put_message(fp == NULL, "���󣬶�ȡ�ļ�%sʧ�ܡ�", filename);
	DWORD riff = 0, size = 0, type = 0, entry = 0, filesize = 0, data_size = 0;
	fseek(fp, 0, SEEK_END);
	filesize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	fread(&riff, sizeof(DWORD), 1, fp);
	fread(&size, sizeof(DWORD), 1, fp);
	fread(&type, sizeof(DWORD), 1, fp);
	BOOL format_read = FALSE, data_read = FALSE;
	if (riff != mmioFOURCC('R', 'I', 'F', 'F') ||
		type != mmioFOURCC('W', 'A', 'V', 'E'))
	{
		fclose(fp);
		return NULL;
	}
	entry += 12;
	while(entry < filesize)
	{
		fread(&type, sizeof(DWORD), 1, fp);
		fread(&size, sizeof(DWORD), 1, fp);
		entry += 8;
		switch(type)
		{
		case mmioFOURCC('f', 'm', 't', ' '):
			if (size < sizeof(WAVEFORMAT))
			{
				fclose(fp);
				return FALSE;
			}
			fseek(fp, sizeof(WAVEFORMAT), SEEK_CUR);
			entry += sizeof(WAVEFORMAT);
			if (format_read && data_read)
				return sample;
			format_read = TRUE;
			break;
		case mmioFOURCC('d', 'a', 't', 'a'):
			sample->bit = new char [size];
			put_message(sample->bit == NULL, "����û���㹻���ڴ档");
			fread(sample->bit, size, 1, fp);
			entry += size;
			sample->size = size;
			data_read = TRUE;
			if (format_read)
				return sample;
			break;
		}
	}
	fclose(fp);
	return sample;
}

// ��ȡ�����ļ�
MUSIC *load_music(char *filename)
{
	MUSIC *music;
	music = new MUSIC;
	put_message(music == NULL, "����û���㹻���ڴ档");
	music->source = MUSIC_IN_FILE;
	music->fp = fopen(filename, "rb");
	put_message(music->fp == NULL, "���󣬶�ȡ�ļ�%sʧ�ܡ�", filename);
	DWORD riff = 0, size = 0, type = 0, entry = 0, filesize = 0, data_size = 0;
	fseek(music->fp, 0, SEEK_END);
	filesize = ftell(music->fp);
	fseek(music->fp, 0, SEEK_SET);
	fread(&riff, sizeof(DWORD), 1, music->fp);
	fread(&size, sizeof(DWORD), 1, music->fp);
	fread(&type, sizeof(DWORD), 1, music->fp);
	BOOL format_read = FALSE, data_read = FALSE;
	if (riff != mmioFOURCC('R', 'I', 'F', 'F') ||
		type != mmioFOURCC('W', 'A', 'V', 'E'))
	{
		fclose(music->fp);
		return NULL;
	}
	entry += 12;
	while(entry < filesize)
	{
		fread(&type, sizeof(DWORD), 1, music->fp);
		fread(&size, sizeof(DWORD), 1, music->fp);
		entry += 8;
		switch(type)
		{
		case mmioFOURCC('f', 'm', 't', ' '):
			if (size < sizeof(WAVEFORMAT))
			{
				fclose(music->fp);
				return FALSE;
			}
			fseek(music->fp, sizeof(WAVEFORMAT), SEEK_CUR);
			entry += sizeof(WAVEFORMAT);
			if (format_read && data_read)
				return music;
			format_read = TRUE;
			break;
		case mmioFOURCC('d', 'a', 't', 'a'):
			music->size = size;
			music->pos = ftell(music->fp);
			data_read = TRUE;
			if (format_read)
				return music;
			break;
		}
	}
	fclose(music->fp);
	return music;
}

// �ͷ���Ч�ļ���ռ���ڴ�
void free_sample(SAMPLE **sample)
{
	SAMPLE *s = *sample;
	if (s == NULL)
		return;
	if (s->bit != NULL)
		free(s->bit);
	free(s);
	*sample = NULL;
}

// �ͷ���Ч�ļ���ռ���ڴ�
void free_music(MUSIC **music)
{
	MUSIC *m = *music;
	free(m);
	*music = NULL;
}

// �ͷ�DirectSound����
void free_directsound()
{
	// �ر����������߳�
	if (DS_Thread)
	{
		TerminateThread(DS_Thread, 0);
		Sleep(200);
	}
	// �ͷž�̬������
	for (int i = 0; i < MAXSAMPLE; i++)
	{
		if (static_buffer[i].lpDSB != NULL)
		{
			static_buffer[i].lpDSB->Release();
			static_buffer[i].lpDSB = NULL;
			static_buffer[i].lpDSN->Release();
			static_buffer[i].lpDSN = NULL;
			CloseHandle(sound_event[i << 1]);
			CloseHandle(sound_event[i << 1 + 1]);
		}
	}
	// �ͷ���������
	if (stream_buffer.lpDSN != NULL)
	{
		stream_buffer.lpDSN->Release();
		stream_buffer.lpDSN = NULL;
	}
	if (stream_buffer.lpDSB != NULL)
	{
		stream_buffer.lpDSB->Release();
		stream_buffer.lpDSB = NULL;
	}
	CloseHandle(sound_event[MAXSAMPLE * 2]);
	CloseHandle(sound_event[MAXSAMPLE * 2 + 1]);
	// �ͷ�������������
	if (lpDSBPrimary != NULL)
	{
		lpDSBPrimary->Release();
		lpDSBPrimary = NULL;
	}
	// �ͷ�DirectSound����
	if (lpDS != NULL)
	{
		lpDS->Release();
		lpDS = NULL;
	}
	// �ر���Ч������
	sound_on = music_on = FALSE;
}

int play_sample(SAMPLE *sample, int loop, long pan, long volume)
{
	if (!sound_on)
		return -1;
	int i;
	STATICSOUND *ss;
	for (i = 0; i < MAXSAMPLE; i++)
	{
		ss = &static_buffer[i];
		if (ss->status < 0)
			break;
	}
	if (i >= MAXSAMPLE)
		return -1;
	ss->pos = 0;
	ss->sample = sample;
	ss->pan = pan;
	ss->volume = volume;
	ss->status = loop;
	sample->number = i;
	zero_static_buffer(i);
	if (!static_next_data(ss, 0, SAMPLE_BUFFER_SIZE >> 1))
		return -1;
	ss->lpDSB->SetCurrentPosition(0);
	ss->lpDSB->SetPan(ss->pan);
	ss->lpDSB->SetVolume(ss->volume);
	if (ss->lpDSB->Play(0, 0, DSBPLAY_LOOPING) != DS_OK)
		return -1;
	return i;
}

void play_music(MUSIC *music, int loop, long pan, long volume)
{
	if (!music_on)
		return;
	stream_buffer.lpDSB->Stop();
	stream_buffer.status = -1;
	music->pack_offset = music->pos;
	stream_buffer.music = music;
	stream_buffer.pan = pan;
	stream_buffer.volume = volume;
	stream_buffer.status = loop;
	fseek(data_file->fp, music->pos, SEEK_SET);
	if (!stream_next_data(0, MUSIC_BUFFER_SIZE >> 1))
		return;
	stream_buffer.lpDSB->SetCurrentPosition(0);
	stream_buffer.lpDSB->SetPan(stream_buffer.pan);
	stream_buffer.lpDSB->SetVolume(stream_buffer.volume);
	stream_buffer.lpDSB->Play(0, 0, DSBPLAY_LOOPING);
}

BOOL static_next_data(STATICSOUND *ss, DWORD pos, DWORD size)
{
	char *buffer;
	DWORD buffersize, s;
	if (ss->status < 0)
	{   
		// ֹͣ����
		ss->lpDSB->Stop();
		ss->lpDSB->SetCurrentPosition(0);
		ss->sample = NULL;
		return TRUE;
	}
	if (pos + size > SAMPLE_BUFFER_SIZE)
		return FALSE;
	put_message(ss->lpDSB->Lock(pos, size, (void **)&buffer, &buffersize, NULL, NULL, 0) != DS_OK, 
		"������������������ʧ�ܡ�");
	if (ss->pos + buffersize > ss->sample->size)
	{
		s = ss->sample->size - ss->pos;
		if (ss->status & PLAYLOOP)
		{
			memcpy(buffer, ss->sample->bit + ss->pos, s);
			memcpy(buffer + s, ss->sample->bit, buffersize - s);
			ss->pos = buffersize - s;
		}
		else
		{
			memcpy(buffer, ss->sample->bit + ss->pos, s);
			if (wf.wBitsPerSample == 16)
				FillMemory(buffer + s, buffersize - s, 0);
			else
				FillMemory(buffer + s, buffersize - s, 0x80);
			ss->pos = ss->sample->size;
			if (ss->status == PLAYLOOP)
			{
				ss->lpDSB->Unlock(buffer, buffersize, NULL, 0);
				zero_static_buffer(ss->sample->number);
				ss->pos = 0;
				return TRUE;
			}
			else
				ss->status = -1;   // ���Ž���
		}
	}
	else
	{
		memcpy(buffer, ss->sample->bit + ss->pos, buffersize);
		ss->pos += buffersize;
	}
	ss->lpDSB->Unlock(buffer, buffersize, NULL, 0);

	return TRUE;
}

BOOL stream_next_data(int pos, int size)
{
	char *buffer;
	int buffersize, s;

	if (stream_buffer.status < 0)
	{   
		// ֹͣ��������
		stream_buffer.lpDSB->Stop();
		stream_buffer.lpDSB->SetCurrentPosition(0);
		stream_buffer.music = NULL;
		return TRUE;
	}
	put_message(stream_buffer.lpDSB->Lock(pos, size, (void **)&buffer, (DWORD *)&buffersize, NULL, NULL, 0) != DS_OK, 
		"������������������ʧ��.");
	if (stream_buffer.music->source == MUSIC_IN_FILE)
	{
		if (!fread(buffer, buffersize, 1, stream_buffer.music->fp))
		{
			s = ftell(stream_buffer.music->fp);
			s = size - s;
			if (stream_buffer.status == PLAYLOOP && s < 1)
			{
				stream_buffer.lpDSB->Unlock(buffer, buffersize, NULL, 0);
				zero_stream_buffer();
				fseek(stream_buffer.music->fp, stream_buffer.music->pos, SEEK_SET);
				return TRUE;
			}
			else
			{
				if (s < 1)
				{
					stream_buffer.status = -1;
				}
				else
				{
					fread(buffer, s, 1, stream_buffer.music->fp);
					FillMemory(buffer + s, buffersize - s, 0);
				}
			}
		}
	}
	else if (stream_buffer.music->source == MUSIC_IN_PACKFILE)
	{
		fseek(data_file->fp, stream_buffer.music->pack_offset, SEEK_SET);
		s = stream_buffer.music->size - (stream_buffer.music->pack_offset - stream_buffer.music->pos) + 1;
		if (s < buffersize)
		{
			if (stream_buffer.status == PLAYLOOP && s < 1)
			{
				stream_buffer.lpDSB->Unlock(buffer, buffersize, NULL, 0);
				stream_buffer.music->pack_offset = stream_buffer.music->pos;
				zero_stream_buffer();
				fseek(data_file->fp, stream_buffer.music->pos, SEEK_SET);
				return TRUE;
			}
			else
			{
				if (s < 1)
				{
					stream_buffer.status = -1;
					stream_buffer.music->pack_offset = stream_buffer.music->pos;
				}
				else
				{
					fread(buffer, s, 1, data_file->fp);
					stream_buffer.music->pack_offset += s;
					FillMemory(buffer + s, buffersize - s, 0);
				}
			}
		}
		else
		{
			fread(buffer, buffersize, 1, data_file->fp);
			stream_buffer.music->pack_offset += buffersize;
		}
	}
	stream_buffer.lpDSB->Unlock(buffer, buffersize, NULL, 0);

	return TRUE;
}

DWORD WINAPI DirectSoundThread(LPVOID p)
{
	DWORD i;
	while(TRUE)
	{
		i = MsgWaitForMultipleObjects(MAXSAMPLE * 2 + 2, sound_event, FALSE, INFINITE, 0);
		if (i == MAXSAMPLE * 2)
		{
			if (!stream_next_data(MUSIC_BUFFER_SIZE >> 1, MUSIC_BUFFER_SIZE >> 1))
			{
				stream_buffer.lpDSB->Stop();
				stream_buffer.lpDSB->SetCurrentPosition(0);
				stream_buffer.music = NULL;
				stream_buffer.status = -1;
			}
		}
		else if (i == MAXSAMPLE * 2 + 1)
		{
			if (!stream_next_data(0, MUSIC_BUFFER_SIZE >> 1)) 
			{
				stream_buffer.lpDSB->Stop();
				stream_buffer.lpDSB->SetCurrentPosition(0);
				stream_buffer.music = NULL;
				stream_buffer.status = -1;
			}
		}
		else if (!static_next_data(&static_buffer[i / 2], (i & 1) ? 0 : (SAMPLE_BUFFER_SIZE >> 1), SAMPLE_BUFFER_SIZE >> 1))
		{
			static_buffer[i / 2].lpDSB->Stop();
			static_buffer[i / 2].lpDSB->SetCurrentPosition(0);
			static_buffer[i / 2].sample = NULL;
			static_buffer[i / 2].status = -1;
		}
		Sleep(30);
	}
	return 0;
}

void zero_static_buffer(int i)
{
	char *buffer;
	int buffersize;
	put_message(static_buffer[i].lpDSB->Lock(0, SAMPLE_BUFFER_SIZE, (void **)&buffer, (DWORD *)&buffersize, NULL, NULL, 0) != DS_OK, 
		"���󣬾�̬��������������ʧ��.");
	ZeroMemory(buffer, SAMPLE_BUFFER_SIZE >> 1);
	static_buffer[i].lpDSB->Unlock(buffer, buffersize, NULL, NULL);
}

void zero_stream_buffer()
{
	char *buffer;
	int buffersize;
	put_message(stream_buffer.lpDSB->Lock(0, MUSIC_BUFFER_SIZE, (void **)&buffer, (DWORD *)&buffersize, NULL, NULL, 0) != DS_OK, 
		"������������������ʧ��.");
	ZeroMemory(buffer, MUSIC_BUFFER_SIZE);
	stream_buffer.lpDSB->Unlock(buffer, buffersize, NULL, NULL);
}

long set_sample_pan(long pan)
{
	long old = sample_pan;
	if (pan < -10000 || pan > 10000)
		return 0;
	sample_pan = pan;
	return old;
}

long set_sample_volume(long volume)
{
	long old = sample_volume;
	if (volume < -10000 || volume > 10000)
		return 0;
	sample_volume = volume;
	return old;
}

long set_music_pan(long pan)
{
	long old = music_pan;
	if (pan < -10000 || pan > 10000)
		return 0;
	stream_buffer.pan = pan;
	stream_buffer.lpDSB->SetVolume(stream_buffer.volume);
	music_pan = pan;
	return old;
}

long set_music_volume(long volume)
{
	long old = music_volume;
	if (volume < -10000 || volume > 10000)
		return 0;
	stream_buffer.volume = volume;
	stream_buffer.lpDSB->SetVolume(stream_buffer.volume);
	music_volume = volume;
	return old;
}

void set_sample_on()
{
	sound_on = TRUE;
}

void set_sample_off()
{
	sound_on = FALSE;
}

void set_music_on()
{
	music_on = TRUE;
}

void set_music_off()
{
	music_on = FALSE;
}

