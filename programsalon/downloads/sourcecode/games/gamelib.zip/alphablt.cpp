// 9��Alphaλͼ���ƺ���

#include "graphics.h"

void alpha_bitblt_1(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2;
	DWORD dcolor1, dcolor2;
	_asm
	{
#include "alphablt.inc"
_is_odd:
_odd_next_line:
		MOV h, ecx;
		MOV ecx, w;
		ALIGN 4

_odd_line_loop:
		LODSW;
		MOV color1, ax;
		MOV ax, [edi];
		MOV color2, ax;

		MOV ax, color1;
		SHR ax, 3;
		AND ax, alpha125mask;

		SUB color1, ax;

		MOV ax, color2;
		SHR ax, 3;
		AND ax, alpha125mask;

		ADD color1, ax;
		MOV ax, color1;

		STOSW;
		ALIGN 4
		LOOP _odd_line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _odd_next_line;
		JMP _bitblt_end;

_no_odd:
_next_line:
		MOV h, ecx;
		MOV ecx, w;
		SAR ecx, 1;
		ALIGN 4

_line_loop:
		LODSD;
		MOV dcolor1, eax;
		MOV eax, [edi];
		MOV dcolor2, eax;

		MOV eax, dcolor1;
		SHR eax, 3;
		AND eax, dalpha125mask;

		SUB dcolor1, eax;

		MOV eax, dcolor2;
		SHR eax, 3;
		AND eax, dalpha125mask;

		ADD dcolor1, eax;
		MOV eax, dcolor1;

		STOSD;
		ALIGN 4
		LOOP _line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _next_line;
		POP esi;
		POP edi;

_alpha_bitblt_end:
	}
}

void alpha_bitblt_2(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2;
	DWORD dcolor1, dcolor2;
	_asm
	{
#include "alphablt.inc"
_is_odd:
_odd_next_line:
		MOV h, ecx;
		MOV ecx, w;
		ALIGN 4

_odd_line_loop:
		LODSW;
		MOV color1, ax;
		MOV ax, [edi];
		MOV color2, ax;

		MOV ax, color1;
		SHR ax, 3;
		AND ax, alpha125mask;

		SUB color1, ax;

		MOV ax, color1;
		SHR ax, 2;
		AND ax, alpha25mask;

		SUB color1, ax;

		MOV ax, color2;
		SHR ax, 2;
		AND ax, alpha25mask;

		ADD color1, ax;
		MOV ax, color1;

		STOSW;
		ALIGN 4
		LOOP _odd_line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _odd_next_line;
		JMP _bitblt_end;

_no_odd:
_next_line:
		MOV h, ecx;
		MOV ecx, w;
		SAR ecx, 1;
		ALIGN 4

_line_loop:
		LODSD;
		MOV dcolor1, eax;
		MOV eax, [edi];
		MOV dcolor2, eax;

		MOV eax, dcolor1;
		SHR eax, 2;
		AND eax, dalpha25mask;

		SUB dcolor1, eax;

		MOV eax, dcolor2;
		SHR eax, 2;
		AND eax, dalpha25mask;

		ADD dcolor1, eax;
		MOV eax, dcolor1;

		STOSD;
		ALIGN 4
		LOOP _line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _next_line;
		POP esi;
		POP edi;

_alpha_bitblt_end:
	}
}

void alpha_bitblt_3(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2;
	DWORD dcolor1, dcolor2;
	_asm
	{
#include "alphablt.inc"
_is_odd:
_odd_next_line:
		MOV h, ecx;
		MOV ecx, w;
		ALIGN 4

_odd_line_loop:
		LODSW;
		MOV color1, ax;
		MOV ax, [edi];
		MOV color2, ax;
		
		PUSH dx;
		PUSH bx;
		MOV ax, color1;
		MOV bx, color2;
		SHR bx, 2;
		SHR ax, 2;
		AND bx, alpha25mask;
		AND ax, alpha25mask;
		ADD bx, ax;
		MOV dx, bx;
		SHR bx, 1;
		ADD ax, dx;
		AND bx, alpha50mask_2;
		ADD ax, bx;
		POP bx;
		POP dx;

		STOSW;
		ALIGN 4
		LOOP _odd_line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _odd_next_line;
		JMP _bitblt_end;

_no_odd:
_next_line:
		MOV h, ecx;
		MOV ecx, w;
		SAR ecx, 1;
		ALIGN 4

_line_loop:
		LODSD;
		MOV dcolor1, eax;
		MOV eax, [edi];
		MOV dcolor2, eax;
		
		PUSH edx;
		PUSH ebx;
		MOV eax, dcolor1;
		MOV ebx, dcolor2;
		SHR ebx, 2;
		SHR eax, 2;
		AND ebx, dalpha25mask;
		AND eax, dalpha25mask;
		ADD ebx, eax;
		MOV edx, ebx;
		SHR ebx, 1;
		ADD eax, edx;
		AND ebx, dalpha50mask_2;
		ADD eax, ebx;
		POP ebx;
		POP edx;

		STOSD;
		ALIGN 4
		LOOP _line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _next_line;
		POP esi;
		POP edi;

_alpha_bitblt_end:
	}
}

void alpha_bitblt_4(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2;
	DWORD dcolor1, dcolor2;
	_asm
	{
#include "alphablt.inc"
_is_odd:
_odd_next_line:
		MOV h, ecx;
		MOV ecx, w;
		ALIGN 4

_odd_line_loop:
		LODSW;
		MOV color1, ax;
		MOV ax, [edi];
		MOV color2, ax;
		
		PUSH bx;
		MOV ax, color1;
		MOV bx, color2;
		AND ax, alpha50mask;
		AND bx, alpha50mask;
		ADD ax, bx;
		RCR ax, 1;
		  
		POP bx;
		STOSW;
		ALIGN 4
		LOOP _odd_line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _odd_next_line;
		JMP _bitblt_end;

_no_odd:
_next_line:
		MOV h, ecx;
		MOV ecx, w;
		SAR ecx, 1;
		ALIGN 4

_line_loop:
		LODSD;
		MOV dcolor1, eax;
		MOV eax, [edi];
		MOV dcolor2, eax;
		
		PUSH ebx;
		MOV eax, dcolor1;
		MOV ebx, dcolor2;
		AND eax, dalpha50mask;
		AND ebx, dalpha50mask;
		ADD eax, ebx;
		RCR eax, 1;
		  
		POP ebx;
		STOSD;
		ALIGN 4
		LOOP _line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _next_line;
		POP esi;
		POP edi;

_alpha_bitblt_end:
	}
}

void alpha_bitblt_5(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2;
	DWORD dcolor1, dcolor2;
	_asm
	{
#include "alphablt.inc"
_is_odd:
_odd_next_line:
		MOV h, ecx;
		MOV ecx, w;
		ALIGN 4

_odd_line_loop:
		LODSW;
		MOV color1, ax;
		MOV ax, [edi];
		MOV color2, ax;

		PUSH bx;
		PUSH dx;
		MOV ax, color1;
		MOV bx, color2;
		SHR ax, 2;
		SHR bx, 2;
		AND ax, alpha25mask;
		AND bx, alpha25mask;
		ADD ax, bx;
		MOV dx, ax;
		SHR ax, 1;
		ADD dx, bx;
		AND ax, alpha50mask_2;
		ADD ax, dx;

		POP dx;
		POP bx;

		STOSW;
		ALIGN 4
		LOOP _odd_line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _odd_next_line;
		JMP _bitblt_end;

_no_odd:
_next_line:
		MOV h, ecx;
		MOV ecx, w;
		SAR ecx, 1;
		ALIGN 4

_line_loop:
		LODSD;
		MOV dcolor1, eax;
		MOV eax, [edi];
		MOV dcolor2, eax;

		PUSH ebx;
		PUSH edx;
		MOV eax, dcolor1;
		MOV ebx, dcolor2;
		SHR eax, 2;
		SHR ebx, 2;
		AND eax, dalpha25mask;
		AND ebx, dalpha25mask;
		ADD eax, ebx;
		MOV edx, eax;
		SHR eax, 1;
		ADD edx, ebx;
		AND eax, dalpha50mask_2;
		ADD eax, edx;

		POP edx;
		POP ebx;

		STOSD;
		ALIGN 4
		LOOP _line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _next_line;
		POP esi;
		POP edi;

_alpha_bitblt_end:
	}
}

void alpha_bitblt_6(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2;
	DWORD dcolor1, dcolor2;
	_asm
	{
#include "alphablt.inc"
_is_odd:
_odd_next_line:
		MOV h, ecx;
		MOV ecx, w;
		ALIGN 4

_odd_line_loop:
		LODSW;
		MOV color1, ax;
		MOV ax, [edi];
		MOV color2, ax;

		PUSH bx;
		MOV ax, color1;
		MOV bx, color2;
		AND ax, alpha25mask;
		ADD ax, bx;
		SHR bx, 2;
		AND bx, alpha25mask;
		SUB ax, bx;

		POP bx;

		STOSW;
		ALIGN 4
		LOOP _odd_line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _odd_next_line;
		JMP _bitblt_end;

_no_odd:
_next_line:
		MOV h, ecx;
		MOV ecx, w;
		SAR ecx, 1;
		ALIGN 4

_line_loop:
		LODSD;
		MOV dcolor1, eax;
		MOV eax, [edi];
		MOV dcolor2, eax;

		PUSH ebx;
		MOV eax, dcolor1;
		MOV ebx, dcolor2;
		SHR eax, 2;
		AND eax, dalpha25mask;
		ADD eax, ebx;
		SHR ebx, 2;
		AND ebx, dalpha25mask;
		SUB eax, ebx;

		POP ebx;

		STOSD;
		ALIGN 4
		LOOP _line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _next_line;
		POP esi;
		POP edi;

_alpha_bitblt_end:
	}
}

void alpha_bitblt_7(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2;
	DWORD dcolor1, dcolor2;
	_asm
	{
#include "alphablt.inc"
_is_odd:
_odd_next_line:
		MOV h, ecx;
		MOV ecx, w;
		ALIGN 4

_odd_line_loop:
		LODSW;
		MOV color1, ax;
		MOV ax, [edi];
		MOV color2, ax;

		PUSH bx;
		MOV ax, color1;
		MOV bx, color2;
		SHR ax, 3;
		AND ax, alpha125mask;
		ADD ax, bx;
		SHR bx, 3;
		AND bx, alpha125mask;
		SUB ax, bx;

		POP bx;

		STOSW;
		ALIGN 4
		LOOP _odd_line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _odd_next_line;
		JMP _bitblt_end;

_no_odd:
_next_line:
		MOV h, ecx;
		MOV ecx, w;
		SAR ecx, 1;
		ALIGN 4

_line_loop:
		LODSD;
		MOV dcolor1, eax;
		MOV eax, [edi];
		MOV dcolor2, eax;

		PUSH ebx;
		MOV eax, dcolor1;
		MOV ebx, dcolor2;
		SHR eax, 3;
		AND eax, dalpha125mask;
		ADD eax, ebx;
		SHR ebx, 3;
		AND ebx, dalpha125mask;
		SUB eax, ebx;

		POP ebx;

		STOSD;
		ALIGN 4
		LOOP _line_loop;

		ADD esi, edx;
		ADD edi, ebx;
		MOV ecx, h;
		ALIGN 4
		LOOP _next_line;
		POP esi;
		POP edi;

_alpha_bitblt_end:
	}
}

void alpha_bitblt_8(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	return;
}

void mask_alpha_bitblt_1(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2, transcolor;
	_asm
	{
#include "maskalphablit.inc"
_odd_alpha_start:
		MOV ax, color1;
		SHR ax, 3;
		AND ax, alpha125mask;

		SUB color1, ax;

		MOV ax, color2;
		SHR ax, 3;
		AND ax, alpha125mask;

		ADD color1, ax;
		MOV ax, color1;
		JMP _alpha_end;
_alpha_bitblt_end:
	}
}

void mask_alpha_bitblt_2(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2, transcolor;
	_asm
	{
#include "maskalphablit.inc"
_odd_alpha_start:
		MOV ax, color1;
		SHR ax, 2;
		AND ax, alpha25mask;

		SUB color1, ax;

		MOV ax, color2;
		SHR ax, 2;
		AND ax, alpha25mask;

		ADD color1, ax;
		MOV ax, color1;
		JMP _alpha_end;
_alpha_bitblt_end:
	}
}

void mask_alpha_bitblt_3(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2, transcolor;
	_asm
	{
#include "maskalphablit.inc"
_odd_alpha_start:
		PUSH dx;
		PUSH bx;
		MOV ax, color1;
		MOV bx, color2;
		SHR bx, 2;
		SHR ax, 2;
		AND bx, alpha25mask;
		AND ax, alpha25mask;
		ADD bx, ax;
		MOV dx, bx;
		SHR bx, 1;
		ADD ax, dx;
		AND bx, alpha50mask_2;
		ADD ax, bx;
		POP bx;
		POP dx;

		JMP _alpha_end;
_alpha_bitblt_end:
	}
}

void mask_alpha_bitblt_4(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2, transcolor;
	_asm
	{
#include "maskalphablit.inc"
_odd_alpha_start:
		PUSH bx;
		MOV ax, color1;
		MOV bx, color2;
		AND ax, alpha50mask;
		AND bx, alpha50mask;
		ADD ax, bx;
		RCR ax, 1;
		  
		POP bx;
		JMP _alpha_end;
_alpha_bitblt_end:
	}
}

void mask_alpha_bitblt_5(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2, transcolor;
	_asm
	{
#include "maskalphablit.inc"
_odd_alpha_start:
		PUSH bx;
		PUSH dx;
		MOV bx, color2;
		SHR ax, 2;
		SHR bx, 2;
		AND ax, alpha25mask;
		AND bx, alpha25mask;
		ADD ax, bx;
		MOV dx, ax;
		SHR ax, 1;
		ADD dx, bx;
		AND ax, alpha50mask_2;
		ADD ax, dx;

		POP dx;
		POP bx;
		JMP _alpha_end;
_alpha_bitblt_end:
	}
}

void mask_alpha_bitblt_6(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2, transcolor;
	_asm
	{
#include "maskalphablit.inc"
_odd_alpha_start:
		PUSH bx;
		MOV ax, color1;
		MOV bx, color2;
		AND ax, alpha25mask;
		ADD ax, bx;
		SHR bx, 2;
		AND bx, alpha25mask;
		SUB ax, bx;

		POP bx;
		JMP _alpha_end;
_alpha_bitblt_end:
	}
}

void mask_alpha_bitblt_7(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	WORD color1, color2, transcolor;
	_asm
	{
#include "maskalphablit.inc"
_odd_alpha_start:
		PUSH bx;
		MOV ax, color1;
		MOV bx, color2;
		SHR ax, 3;
		AND ax, alpha125mask;
		ADD ax, bx;
		SHR bx, 3;
		AND bx, alpha125mask;
		SUB ax, bx;

		POP bx;
		JMP _alpha_end;
_alpha_bitblt_end:
	}
}

void mask_alpha_bitblt_8(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	return;
}