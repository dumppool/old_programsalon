#include "graphics.h"

#define MAX_ICE   100
#define ICE_SPEED 50

typedef struct
{
	int y;     // ѩ��y��λ��
	int x;     // ѩ��x��λ��
	int oldx;  // ѩ����X������λ��
	int fd;    // ѩ��ҡ�ڵķ���
	BOOL f;    // ��ǰ��ҡ�ڷ���
	int speed; // ѩ���½����ٶ�
	int type;  // ѩ��������
}ICE;

LIST *ice_list; // ѩ���б�
BMP  *ice_type[2]; // ѩ����ʽ

// ��ʼ��ѩ��
BOOL init_ice()
{
	ice_list = create_list();
	ice_type[0] = create_bitmap(3, 3, 0);
	if (ice_type[0] == NULL)
		return FALSE;
	ice_type[1] = create_bitmap(5, 5, 0);
	if (ice_type[1] == NULL)
		return FALSE;
	if (Is555)
		circle_fill(ice_type[0], 1, 1, 1, create_color(31, 31, 31));
	else
		circle_fill(ice_type[0], 1, 1, 1, create_color(31, 63, 31));
	if (Is555)
		circle_fill(ice_type[1], 2, 2, 2, create_color(31, 31, 31));
	else
		circle_fill(ice_type[1], 2, 2, 2, create_color(31, 63, 31));
	return TRUE;
}

// ��ʾѩ��
void show_ice(BMP *dest)
{
	static int ice_nt, ice_ot = 0;
	BOOL update_ice;
	ice_nt = GetTickCount();
	if (ice_nt > ice_ot + ICE_SPEED)
	{
		ice_ot = ice_nt;
		update_ice = TRUE;
	}
	else
		update_ice = FALSE;
	LIST_POINT *p;
	if (ice_list->count < MAX_ICE)
	{
		// ������ѩ��
		ICE *nice = new ICE;
		if (nice == NULL)
			return;
		nice->oldx = rand() % dest->width;
		nice->y = -3, nice->x = nice->oldx;
		nice->fd = rand() % 10;
		nice->f = rand() % 1;
		nice->speed = rand() % 3 + 3;
		nice->type = rand() % 2;
		add_point(ice_list, nice);
	}
	seek_to_first(ice_list);
	p = ice_list->entry;
	while(p != NULL)
	{
		ICE *ice = (ICE *)(p->data);
		if (ice->y < dest->height)
		{
			// ��ʾ�Ѿ��е�ѩ��
			mask_draw_bitmap(dest, ice->x, ice->y, ice_type[ice->type]);
			if (update_ice)
			{
				ice->y += ice->speed;
				if (ice->f)
				{
					if (ice->x - ice->oldx < ice->fd)
						ice->x++;
					else
						ice->f = FALSE;
				}
				else
				{
					if (ice->oldx -ice->x < ice->fd)
						ice->x--;
					else
						ice->f = TRUE;
				}
			}
			p = p->next;
		}
		else
		{
			// ɾ��ѩ��
			delete_point(ice_list, p);
			p = ice_list->entry;
		}
	}
}

void free_ice()
{
	free_bitmap(&ice_type[0]);
	free_bitmap(&ice_type[1]);
	free_list(&ice_list);
}
