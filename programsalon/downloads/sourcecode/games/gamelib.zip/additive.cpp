#include "graphics.h"

// Additive���(565��)
void additive_bitblt_bitmap_565(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	DWORD src_pitch, dest_pitch;
	WORD transcolor;
	_asm
	{
	 	PUSH edi;
		PUSH esi;
#include "clipblit.inc"
		MOV ebx, dest_bmp; // ��dest_bmp.bit�ĵ�ַ������edi
		MOV edi, [ebx]BMP.bit;
		MOV edx, src_bmp; // ��src_bmp.bit�ĵ�ַ������edi
		MOV esi, [edx]BMP.bit;
		MOV ax, [edx]BMP.colorkey;
		MOV transcolor, ax;

		SAL x, 1;
		ADD edi, x;
		SAL srcx, 1;
		ADD esi, srcx;

		MOV eax, srcy;
		IMUL [edx]BMP.pitch_byte;
		ADD esi, eax;
		MOV eax, y;
		IMUL [ebx]BMP.pitch_byte;
		ADD edi, eax;

		MOV edx, src_bmp; // ��src_bmp.bit�ĵ�ַ������edi
		MOV ebx, [ebx]BMP.width;
		SUB ebx, w;
		SAL ebx, 1;
		MOV dest_pitch, ebx;
		MOV edx, [edx]BMP.width;
		SUB edx, w;
		SAL edx, 1;
		MOV src_pitch, edx;

		CLD;
		MOV ecx, h;
		ALIGN 4

		MOV dx, 0xf7df;   // 1111 0111 1101 1111
		CLD;
		ALIGN 4
_loop1:
		MOV h, ecx;
		MOV ecx, w;
_loop:
		LODSW;
		CMP ax, transcolor;
		JZ _skippixel;
		MOV bx, [edi];
		AND ax, dx;    // 0111 0111 1101 1111
		AND bx, dx;
		ADC ax, bx;
		JNC _rnc;
		OR ax, 0xf000;
_rnc:
		TEST ax, 0x20; // 10 0000
		JZ _bnc;
		OR ax, 0x1f;
_bnc:
		TEST ax, 0x800; // 1000 0000 0000
		JZ _gnc;
		OR ax, 0x7e0;   // 111 1110 0000
_gnc:
		STOSW;
		LOOP _loop;
		ADD esi, src_pitch;           // ׼����һ��
		ADD edi, dest_pitch;
		MOV ecx, h;
		LOOP _loop1;
		JMP _bitblt_end;
_skippixel:
		ADD edi, 2;
		LOOP _loop;
		ADD esi, src_pitch;           // ׼����һ��
		ADD edi, dest_pitch;
		MOV ecx, h;                   // ȡ����ֵ 
		LOOP _loop1;
_bitblt_end:
		POP esi;
		POP edi;
	}
}

// Additive���(555��)
void additive_bitblt_bitmap_555(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h)
{
	put_message(dest_bmp == NULL || src_bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	DWORD src_pitch, dest_pitch;
	WORD transcolor;
	_asm
	{
	 	PUSH edi;
		PUSH esi;
#include "clipblit.inc"
		MOV ebx, dest_bmp; // ��dest_bmp.bit�ĵ�ַ������edi
		MOV edi, [ebx]BMP.bit;
		MOV edx, src_bmp; // ��src_bmp.bit�ĵ�ַ������edi
		MOV esi, [edx]BMP.bit;
		MOV ax, [edx]BMP.colorkey;
		MOV transcolor, ax;

		SAL x, 1;
		ADD edi, x;
		SAL srcx, 1;
		ADD esi, srcx;

		MOV eax, srcy;
		IMUL [edx]BMP.pitch_byte;
		ADD esi, eax;
		MOV eax, y;
		IMUL [ebx]BMP.pitch_byte;
		ADD edi, eax;

		MOV edx, src_bmp; // ��src_bmp.bit�ĵ�ַ������edi
		MOV ebx, [ebx]BMP.width;
		SUB ebx, w;
		SAL ebx, 1;
		MOV dest_pitch, ebx;
		MOV edx, [edx]BMP.width;
		SUB edx, w;
		SAL edx, 1;
		MOV src_pitch, edx;

		CLD;
		MOV ecx, h;
		ALIGN 4

		MOV dx, 0x7bdf;   // 0111 1011 1101 1111
		CLD;
		ALIGN 4
_loop1:
		MOV h, ecx;
		MOV ecx, w;
_loop:
		LODSW;
		CMP ax, transcolor;
		JZ _skippixel;
		MOV bx, [edi];
		AND ax, dx;    // 0111 0111 1101 1111
		AND bx, dx;
		ADD ax, bx;
		TEST ax, 0x20; // 10 0000
		JZ _bnc;
		OR ax, 0x1f;
_bnc:
		TEST ax, 0x400; // 100 0000 0000
		JZ _gnc;
		OR ax, 0x3e0;
_gnc:
		BTR ax, 15;
		JNC _rnc;
		OR ax, 0x7c00;
_rnc:
		STOSW;
		LOOP _loop;
		ADD esi, src_pitch;           // ׼����һ��
		ADD edi, dest_pitch;
		MOV ecx, h;
		LOOP _loop1;
		JMP _bitblt_end;
_skippixel:
		ADD edi,2;
		LOOP _loop;
		ADD esi, src_pitch;           // ׼����һ��
		ADD edi, dest_pitch;
		MOV ecx, h;                   // ȡ����ֵ 
		LOOP _loop1;
_bitblt_end:
		POP esi;
		POP edi;
	}
}