#include "graphics.h"

int  screen_left = 0, screen_top = 0, 
	screen_right = SCREEN_WIDTH - 1, screen_bottom = SCREEN_HEIGHT - 1;

// ������Ļ���þ���
void set_update_box(int left, int top, int right, int bottom)
{
	if (left < 0 || top < 0)
		return;
	if (right > SCREEN_WIDTH - 1 || bottom > SCREEN_HEIGHT - 1)
		return;
	int temp;
	if (left > right)
	{
		temp = left;
		left = right;
		right = temp;
	}
	if (top > bottom)
	{
		temp = top;
		top = bottom;
		bottom = temp;
	}
	screen_left   = left;
	screen_top    = top;
	screen_right  = right;
	screen_bottom = bottom;
	temp_screen->clipleft = left;
	temp_screen->cliptop = top;
	temp_screen->clipright = right;
	temp_screen->clipbottom = bottom;
}

// ��ͨ������Ļģʽ
void update_screen_normal()
{
	// �������
	if (cursor != NULL || show_cursor)
		paint_mouse(cursor);
	calc_fps();
	show_message(); 
	lpDDPrimary->Lock(NULL, &PrimarySurfaceDesc, DDLOCK_WAIT, NULL);
	void *bitmap = PrimarySurfaceDesc.lpSurface;
	int h;
	_asm
	{
		PUSH edi;
		PUSH esi;

		MOV ebx, screen;         // �ѵ�ַ����SI��DI
		MOV edi, bitmap;
		MOV esi, [ebx]BMP.bit;

		MOV eax, screen_left;    // ����ƫ����
		SAL eax, 1;
		ADD edi, eax;
		ADD esi, eax;
		MOV eax, SCREEN_PITCH;
		IMUL screen_top;
		ADD edi, eax;
		ADD esi, eax;

		MOV edx, screen_bottom;  // ��������Ƶĸ߶�
		SUB edx, screen_top;
		INC edx;
		MOV h, edx;

		MOV edx, screen_right;   // ����ƫ�ƵĿ���
		SUB edx, screen_left;
		INC edx;
		MOV eax, SCREEN_WIDTH;
		SUB eax, edx;
		SAL eax, 1;

		CLD;
		MOV ecx, h;
		TEST edx, 1;
		JNZ _odd_next_line;
		SAR edx, 1;
		JMP _no_odd_next_line;

_odd_next_line:
		MOV h, ecx;
		MOV ecx, edx;
		REP MOVSW;
		ADD esi, eax;
		ADD edi, eax;
		MOV ecx, h;
		LOOP _odd_next_line;
		JMP _update_end;

_no_odd_next_line:
		MOV h, ecx;
		MOV ecx, edx;
		REP MOVSD;
		ADD esi, eax;
		ADD edi, eax;
		MOV ecx, h;
		LOOP _no_odd_next_line;

_update_end:
		POP esi;
		POP edi;
	}
	lpDDPrimary->Unlock(&PrimarySurfaceDesc);
}

// ��Ӱ������Ļģʽ
void update_screen_shadow()
{
	// �������
	if (cursor != NULL || show_cursor)
		paint_mouse(cursor);
	calc_fps();
	show_message();
	alpha_bitblt_4(temp_screen, 0, 0, screen, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
	lpDDPrimary->Lock(NULL, &PrimarySurfaceDesc, DDLOCK_WAIT, NULL);
	void *bitmap = PrimarySurfaceDesc.lpSurface;
	int h;
	_asm
	{
		PUSH edi;
		PUSH esi;

		MOV ebx, temp_screen;         // �ѵ�ַ����SI��DI
		MOV edi, bitmap;
		MOV esi, [ebx]BMP.bit;

		MOV eax, screen_left;    // ����ƫ����
		SAL eax, 1;
		ADD edi, eax;
		ADD esi, eax;
		MOV eax, SCREEN_PITCH;
		IMUL screen_top;
		ADD edi, eax;
		ADD esi, eax;

		MOV edx, screen_bottom;  // ��������Ƶĸ߶�
		SUB edx, screen_top;
		INC edx;
		MOV h, edx;

		MOV edx, screen_right;   // ����ƫ�ƵĿ���
		SUB edx, screen_left;
		INC edx;
		MOV eax, SCREEN_WIDTH;
		SUB eax, edx;
		SAL eax, 1;

		CLD;
		MOV ecx, h;
		TEST edx, 1;
		JNZ _odd_next_line;
		SAR edx, 1;
		JMP _no_odd_next_line;

_odd_next_line:
		MOV h, ecx;
		MOV ecx, edx;
		REP MOVSW;
		ADD esi, eax;
		ADD edi, eax;
		MOV ecx, h;
		LOOP _odd_next_line;
		JMP _update_end;

_no_odd_next_line:
		MOV h, ecx;
		MOV ecx, edx;
		REP MOVSD;
		ADD esi, eax;
		ADD edi, eax;
		MOV ecx, h;
		LOOP _no_odd_next_line;

_update_end:
		POP esi;
		POP edi;
	}
	lpDDPrimary->Unlock(&PrimarySurfaceDesc);
}

// ���и�����Ļģʽ
void update_screen_interval()
{
	// �������
	if (cursor != NULL || show_cursor)
		paint_mouse(cursor);
	calc_fps();
	show_message();
	lpDDPrimary->Lock(NULL, &PrimarySurfaceDesc, DDLOCK_WAIT, NULL);
	void *bitmap = PrimarySurfaceDesc.lpSurface;
	int h;
	_asm
	{
		PUSH edi;
		PUSH esi;

		MOV ebx, screen;         // �ѵ�ַ����SI��DI
		MOV edi, bitmap;
		MOV esi, [ebx]BMP.bit;

		MOV eax, screen_left;    // ����ƫ����
		SAL eax, 1;
		ADD edi, eax;
		ADD esi, eax;
		MOV eax, SCREEN_PITCH;
		IMUL screen_top;
		ADD edi, eax;
		ADD esi, eax;

		MOV edx, screen_bottom;  // ��������Ƶĸ߶�
		SUB edx, screen_top;
		INC edx;
		SAR edx, 1;
		MOV h, edx;

		MOV edx, screen_right;   // ����ƫ�ƵĿ���
		SUB edx, screen_left;
		INC edx;
		MOV eax, SCREEN_WIDTH;
		SUB eax, edx;
		SAL eax, 1;

		CLD;
		MOV ecx, h;
		TEST edx, 1;
		JNZ _odd_next_line;
		SAR edx, 1;
		JMP _no_odd_next_line;

_odd_next_line:
		MOV h, ecx;
		MOV ecx, edx;
		REP MOVSW;
		ADD esi, eax;
		ADD edi, eax;
		ADD edi, [ebx]BMP.pitch_byte;
		ADD esi, [ebx]BMP.pitch_byte;
		MOV ecx, h;
		LOOP _odd_next_line;
		JMP _update_end;

_no_odd_next_line:
		MOV h, ecx;
		MOV ecx, edx;
		REP MOVSD;
		ADD esi, eax;
		ADD edi, eax;
		ADD edi, [ebx]BMP.pitch_byte;
		ADD esi, [ebx]BMP.pitch_byte;
		MOV ecx, h;
		LOOP _no_odd_next_line;

_update_end:
		POP esi;
		POP edi;
	}
	lpDDPrimary->Unlock(&PrimarySurfaceDesc);
}
