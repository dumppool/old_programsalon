#include "FindPath.h"

int offset_x[] = {-1, 1, -1, 1, 0, -1, 1, 0};
int offset_y[] = {-1, -1, 1, 1, -1, 0, 0, 1};

CFindPath::CFindPath(int *m, int w, int h, int range1, int range2)
{
	// Ϊ����������ֵ
	Width = w;
	Height = h;
	Root = NULL;
	Stack1 = Stack2 = NULL;
	TileCount = w * h;
	FindOk = FALSE;
	DestNode = NULL;
	Step = 0;
	Path = NULL;
	Nodes = NULL;

	// ���õ�ͼ
	SetMap(m, range1, range2);
}

CFindPath::~CFindPath()
{
	if (Map)
		delete Map;
	if (MapBak)
		delete MapBak;
	FreeAll();
}

BOOL CFindPath::FindPath(int sx, int sy, int dx, int dy)
{
	memcpy(Map, MapBak, sizeof(int) * TileCount);
	FreeAll();
	if (GetTileType(sx, sy) != 0 && GetTileType(dx, dy) != 0)
		return FALSE;
	SrcPoint = GetTileNum(sx, sy);
	DestPoint = GetTileNum(dx, dy);
	Step = 2;
	// �������ڵ�
	Root = new NODE;
	if (Root == NULL)
		return FALSE;
	Root->x = sx;
	Root->y = sy;
	Root->number = GetTileNum(sx, sy);
	for (int i = 0; i < 8; i++)
		Root->child[i] = NULL;
	LPSTACK s = new STACK;
	if (s == NULL)
	{
		delete Root;
		Root = NULL;
		return FALSE;
	}
	s->node = Root;
	s->next = NULL;
	Stack1 = s;
	while(Stack1)
	{
		if (CreateNode())
			return TRUE;
		// ������ջ
		LPSTACK s = Stack1;
		Stack1 = Stack2;
		Stack2 = s;
		Step++;
	}
	FindOk = FALSE;
	DestNode = NULL;
	return FALSE;
}

BOOL CFindPath::CreateNode()
{
	// ������һ�ֵ���չ
	while(Stack1)
	{
		LPNODE n = Pop();
		if (CreateNode8(n))
		{
			GetPath();
			return TRUE;
		}
	}
	return FALSE;
}

void CFindPath::Push(LPNODE n)
{
	// ѹ��һ���ڵ㵽Stack2
	LPSTACK s = new STACK;
	if (s == NULL)
		return;
	s->next = Stack2;
	s->node = n;
	Stack2 = s;
}

LPNODE CFindPath::Pop()
{
	// ��Stack1����һ���ڵ�
	LPSTACK s = Stack1;
	Stack1 = Stack1->next;
	LPNODE n = s->node;
	delete s;
	return n;
}

BOOL CFindPath::CreateNode8(LPNODE n)
{
	int x, y;
	int ii = 0;
	BOOL ok = FALSE;
	for (int i = 0; i < 8; i++)
	{
		x = n->x + offset_x[i];
		y = n->y + offset_y[i];
		if (x >= 0 && y >= 0 && x < Width && y < Height && GetTileType(x, y) == 0)
		{
			// ���û��Խ�粢��û����չ�������ڵ�
			LPNODE temp = new NODE;
			if (temp == NULL)
				return FALSE;
			temp->x = x;
			temp->y = y;
			temp->number = GetTileNum(x, y);
			temp->child[ii++] = temp;
			temp->parent = n;
			// ���ýڵ�ѹ���ջ
			Push(temp);
			// ���ýڵ�ѹ��ڵ��б�
			LPSTACK tempstack = new STACK;
			tempstack->node = temp;
			tempstack->next = Nodes;
			Nodes = tempstack;
			if (GetTileNum(x, y) == DestPoint)
			{
				FindOk = TRUE;
				DestNode = temp;
				return TRUE;
			}
			else
				// ��־��չ���Ľڵ�
				*GetTilePtr(x, y) = 1;
			ok = TRUE;
		}
	}
	/*
	if (!ok)
	{
	// �����·������,���ߵ������λ��
	}
	*/
	return FALSE;
}

BOOL CFindPath::GetPath()
{
	if (FindOk)
	{
		// �����һ�������ɹ�,���ȡ·��
		LPNODE e = DestNode;
		for (int i = 0; i < Step; i++)
		{
			LPSTACK s = new STACK;
			s->node = e;
			s->next = Path;
			Path = s;
			e = e->parent;
		}
		return TRUE;
	}
	return FALSE;
}

void CFindPath::FreeAll()
{
	// �ͷŶ�ջStack1, Stack2, Path
	LPSTACK t;
	while(Stack1)
	{
		t = Stack1;
		Stack1 = Stack1->next;
		delete t;
	}
	Stack1 = NULL;
	while(Stack2)
	{
		t = Stack2;
		Stack2 = Stack2->next;
		delete t;
	}
	Stack2 = NULL;
	while(Path)
	{
		t = Path;
		Path = Path->next;
		delete t;
	}
	Path = NULL;
	FindOk = FALSE;
	// �ͷſ���������
	while(Nodes)
	{
		LPSTACK s = Nodes;
		delete s->node;
		Nodes = Nodes->next;
		delete s;
	}
	Nodes = NULL;
}

BOOL CFindPath::PopPath(int & x, int & y)
{
	if (FindOk && Path != NULL)
	{
		// �����������,���·����ջ�е�����һ��
		x = Path->node->x;
		y = Path->node->y;
		LPSTACK temp = Path;
		Path = Path->next;
		delete temp;
		return TRUE;
	}
	return FALSE;
}

BOOL CFindPath::SetMap(int *m, int range1, int range2)
{
	// ���õ�ͼ
	Map = new int [TileCount];
	if (Map == NULL)
		return FALSE;
	MapBak = new int [TileCount];
	if (MapBak == NULL)
		return FALSE;
	int *p = Map, *p1 = m;
	for (int i = 0; i < TileCount; i++)
	{
		if (*p1 >= range1 && *p1 <= range2)
			*p++ = -3;
		else
			*p++ = 0;
		p1++;
	}
	memcpy(MapBak, Map, sizeof(int) * TileCount);
	return TRUE;
}
