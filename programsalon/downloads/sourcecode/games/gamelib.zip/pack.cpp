#include "graphics.h"

DATA_FILE *data_file = NULL;

// ����һ�������ļ�
void create_data_file(char *filename)
{
	close_data_file();
	data_file = new DATA_FILE;
	data_file->fp = fopen(filename, "wb+");
	put_message(data_file->fp == NULL, "���󣬽����������ļ�ʧ�ܡ�");
	data_file->file_count = 0;
	fwrite(&data_file->file_count, sizeof(DWORD), 1, data_file->fp);
	data_file->pack_file_list = create_list();
}

// ��һ�������ļ�
void open_data_file(char *filename)
{
	close_data_file();
	data_file = new DATA_FILE;
	data_file->fp = fopen(filename, "rb");
	put_message(data_file->fp == NULL, "���󣬴������ļ�ʧ�ܡ�");
	fread(&data_file->file_count, sizeof(DWORD), 1, data_file->fp);
	data_file->pack_file_list = create_list();
	PACK_FILE *temp;
	// װ�������ļ��б�
	for (DWORD i = 0; i < data_file->file_count; i++)
	{
		temp = new PACK_FILE;
		fread(&temp->ID, sizeof(DWORD), 1, data_file->fp);
		fread(&temp->pos, sizeof(DWORD), 1, data_file->fp);
		fread(temp->filename, 64, 1, data_file->fp);
		fread(&temp->oldsize, sizeof(DWORD), 1, data_file->fp);
		fread(&temp->filesize, sizeof(DWORD), 1, data_file->fp);
		fread(&temp->compress, sizeof(BOOL), 1, data_file->fp);
		add_point(data_file->pack_file_list, temp);
		fseek(data_file->fp, temp->filesize, SEEK_CUR);
	}
}

/* * * * * * * * * * * *
 * �����ļ��������ļ�  *
 * �����ļ���Ҫѹ��    *
 * * * * * * * * * * * */
void add_file(char *filename, DWORD ID, BOOL comp)
{
	put_message(data_file == NULL, "���󣬵�ǰû�д������ļ���");
	FILE *fp;
	PACK_FILE *pf = new PACK_FILE;
	put_message(pf == NULL, "����û���㹻���ڴ档");
	fp = fopen(filename, "rb");
	put_message(fp == NULL, "���󣬴��ļ�%sʧ��", filename);
	fseek(data_file->fp, 0, SEEK_END);
	fseek(fp, 0, SEEK_END);
	DWORD pos = ftell(data_file->fp);
	DWORD size = ftell(fp);
	fseek(data_file->fp, 0, SEEK_SET);
	fseek(fp, 0, SEEK_SET);
	data_file->file_count++;
	fwrite(&data_file->file_count, sizeof(DWORD), 1, data_file->fp);
	fseek(data_file->fp, 0, SEEK_END);
	pos += sizeof(PACK_FILE);
	pf->ID = ID;
	pf->pos = pos;
	strcpy(pf->filename, filename);
	char *buffer = new char [size];
	put_message(buffer == NULL, "����û���㹻���ڴ档");
	fread(buffer, size, 1, fp);
	pf->oldsize = size;
	pf->filesize = size;
	if (!comp)
	{
		pf->compress = FALSE;
		fwrite(&pf->ID, sizeof(DWORD), 1, data_file->fp);
		fwrite(&pf->pos, sizeof(DWORD), 1, data_file->fp);
		fwrite(&pf->filename, 64, 1, data_file->fp);
		fwrite(&pf->oldsize, sizeof(DWORD), 1, data_file->fp);
		fwrite(&pf->filesize, sizeof(DWORD), 1, data_file->fp);
		fwrite(&pf->compress, sizeof(BOOL), 1, data_file->fp);
		fwrite(buffer, pf->filesize, 1, data_file->fp);
		delete buffer;
	}
	else
	{
		char *cbuffer = new char [pf->filesize];
		pf->filesize = compress(buffer, pf->filesize, cbuffer);
		pf->compress = TRUE;
		fwrite(&pf->ID, sizeof(DWORD), 1, data_file->fp);
		fwrite(&pf->pos, sizeof(DWORD), 1, data_file->fp);
		fwrite(&pf->filename, 64, 1, data_file->fp);
		fwrite(&pf->oldsize, sizeof(DWORD), 1, data_file->fp);
		fwrite(&pf->filesize, sizeof(DWORD), 1, data_file->fp);
		fwrite(&pf->compress, sizeof(BOOL), 1, data_file->fp);
		fwrite(cbuffer, pf->filesize, 1, data_file->fp);
		delete buffer;
		delete cbuffer;
	}
	add_point(data_file->pack_file_list, pf);
	fclose(fp);
}

// �ر������ļ�
void close_data_file()
{
	if (data_file != NULL)
	{
		free_list(&data_file->pack_file_list);
		fclose(data_file->fp);
	}
}

// ֻ�����ݰ��ڵ����ļ��ſ�����ѹ��״̬��
// ����һ����׼WindowsBMP(8λɫ �� 24λɫ)
BMP *load_pack_win_bitmap(char *filename)
{
	BOOL find_ok = FALSE;
	seek_to_first(data_file->pack_file_list);
	PACK_FILE *pf;
	for (DWORD c = 0; c < data_file->file_count; c++)
	{
		pf = (PACK_FILE *)get_data(data_file->pack_file_list);
		if (strcmp(pf->filename, filename) == 0)
		{
			find_ok = TRUE;
			break;
		}
		seek_to_next(data_file->pack_file_list);
	}
	if (!find_ok)
		return NULL;

	fseek(data_file->fp, pf->pos, SEEK_SET);
	BMP *bmp;

	if (!pf->compress)
	{
		// ����û��ѹ����
		BITMAPFILEHEADER bmpheader; // ȡBMP�ļ�ͷ��Ϣ
		if (fread(&bmpheader, sizeof(bmpheader), 1, data_file->fp) == NULL)
		{
			fclose(data_file->fp);
			put_message(TRUE, 
				"���󣬶�ȡ�ļ�ͷʧ�ܡ�");
		}
		if (bmpheader.bfType != 19778)
		{
			fclose(data_file->fp);
			put_message(TRUE, 
				"���󣬲��Ǳ�׼Windows BMP�ļ���");
		}
		BITMAPINFOHEADER bmpinfo;// ȡBMP�ļ���Ϣ
		if (fread(&bmpinfo, sizeof(bmpinfo), 1, data_file->fp) == NULL)
		{
			fclose(data_file->fp);
			put_message(TRUE, 
				"���󣬶�ȡͼ����Ϣʧ�ܡ�");
		}
		if ((bmpinfo.biCompression != BI_RGB) || ((bmpinfo.biBitCount!=8)&&(bmpinfo.biBitCount != 24)))
		{
			fclose(data_file->fp);      // �Ƿ�δѹ����Ϊ8 or 24λɫ
			put_message(TRUE, 
				"�������Windows BMP����ѹ���ġ�");
		}
		bmp = new BMP;
		put_message(bmp == NULL, "����û���㹻���ڴ档");
		bmp->height        = bmpinfo.biHeight ;
		bmp->width         = bmpinfo.biWidth  ;
		bmp->cliptop       = bmp->clipleft = 0;
		bmp->clipright     = bmp->width - 1;
		bmp->clipbottom    = bmp->height - 1;
		bmp->pitch_byte    = WORD(bmp->width << 1);
		bmp->pitch_word    = bmp->width;
		bmp->pitch_dword   = bmp->width / 2;
		bmp->surface_byte  = bmp->pitch_byte  * bmp->height;
		bmp->surface_word  = bmp->pitch_word  * bmp->height;
		bmp->surface_dword = bmp->pitch_dword * bmp->height;
		bmp->colorkey      = 0x0;
		bmp->bit = new WORD [bmp->surface_word];
		if (Is555)
			bmp->pixelbitcount = 15;
		else
			bmp->pixelbitcount = 16;
		put_message(bmp->bit == NULL, "����û���㹻���ڴ档");
		if (bmpinfo.biBitCount == 8) // 8λɫ�Ĵ���
		{
			RGBQUAD *quad;
			quad = new RGBQUAD[256];
			if (quad == NULL)
			{
				fclose(data_file->fp);
				put_message(TRUE, 
					"����û���㹻���ڴ档");
				return NULL;
			}
			WORD *pal;
			pal = new WORD[256];
			if (pal == NULL)
			{
				delete quad;
				fclose(data_file->fp);
				put_message(TRUE, 
					"����û���㹻���ڴ档");
				return NULL;
			}
			fread(quad, sizeof(RGBQUAD) * 256, 1, data_file->fp);
			DWORD c;
			for (int i = 0; i < 256; i++) // ��ɫ��
			{
				c = ((((DWORD)quad[i].rgbRed) << 16) | (((DWORD)quad[i].rgbGreen) << 8) | ((DWORD)quad[i].rgbBlue));
				pal[i] = true_to_hi(c);
			}
			for (int ii = 0; ii < 256; ii++)
				pal[ii] = true_to_hi(*((DWORD *)(quad + ii)));
			WORD* Offset = bmp->bit;
			DWORD linesize;
			BYTE* buffer;
			linesize = (bmpinfo.biWidth + 3) & 0xfffffffc;
			buffer = (BYTE *)malloc(linesize);
			
			for (i = bmpinfo.biHeight - 1; i >= 0; i--)
			{
				Offset = bmp->bit + i * bmpinfo.biWidth ;
				fread(buffer, linesize, 1, data_file->fp);
				for (int j = 0; j < bmpinfo.biWidth; j++)
					Offset[j] = pal[buffer[j]];
			}
			delete buffer;
			Offset = NULL;
			delete pal;
			delete quad;
			return bmp;
		}
		// 24λɫ����
		int linesize = (bmpinfo.biWidth * 3 + 3) & 0xfffffffc;
		BYTE *Buffer;
		Buffer = new BYTE[linesize];
		if (Buffer == NULL)
		{
			fclose(data_file->fp);
			put_message(TRUE, 
				"����û���㹻���ڴ档");
			return NULL;
		}
		WORD *Offset;
		for (int i = bmpinfo.biHeight - 1; i >= 0; i--)
		{
			fread(Buffer, linesize, 1, data_file->fp);
			Offset = bmp->bit + i * bmpinfo.biWidth; 
			for (int j = 0; j < bmpinfo.biWidth; j++)
				Offset[j] = true_to_hi((*(DWORD *)(Buffer + j * 3)));
		}
		delete Buffer;
		Offset = NULL;
		return bmp;
	}
	else
	{
		// ����ѹ������
		BITMAPFILEHEADER bmpheader; // ȡBMP�ļ�ͷ��Ϣ
		char *filebuffer, *cbuffer, *pbuffer;
		cbuffer = new char [pf->filesize];
		put_message(cbuffer == NULL, "����û���㹻���ڴ�ռ䡣");
		fread(cbuffer, pf->filesize, 1, data_file->fp);
		filebuffer = new char [pf->oldsize];
		put_message(filebuffer == NULL, "����û���㹻���ڴ�ռ䡣");
		decompress(cbuffer, pf->filesize, filebuffer);
		delete cbuffer;
		pbuffer = filebuffer;

		memcpy(&bmpheader, pbuffer, sizeof(bmpheader));
		pbuffer += sizeof(bmpheader);
		if (bmpheader.bfType != 19778)
		{
			delete filebuffer;
			fclose(data_file->fp);
			put_message(TRUE, 
				"���󣬲��Ǳ�׼Windows BMP�ļ���");
		}
		BITMAPINFOHEADER bmpinfo;// ȡBMP�ļ���Ϣ
		memcpy(&bmpinfo, pbuffer, sizeof(bmpinfo));
		pbuffer += sizeof(bmpinfo);
		if ((bmpinfo.biCompression != BI_RGB) || ((bmpinfo.biBitCount!=8)&&(bmpinfo.biBitCount != 24)))
		{
			delete filebuffer;
			fclose(data_file->fp);      // �Ƿ�δѹ����Ϊ8 or 24λɫ
			put_message(TRUE, 
				"�������Windows BMP����ѹ���ġ�");
		}
		bmp = new BMP;
		put_message(bmp == NULL, "����û���㹻���ڴ档");
		bmp->height        = bmpinfo.biHeight ;
		bmp->width         = bmpinfo.biWidth  ;
		bmp->cliptop       = bmp->clipleft = 0;
		bmp->clipright     = bmp->width - 1;
		bmp->clipbottom    = bmp->height - 1;
		bmp->pitch_byte    = WORD(bmp->width << 1);
		bmp->pitch_word    = bmp->width;
		bmp->pitch_dword   = bmp->width / 2;
		bmp->surface_byte  = bmp->pitch_byte  * bmp->height;
		bmp->surface_word  = bmp->pitch_word  * bmp->height;
		bmp->surface_dword = bmp->pitch_dword * bmp->height;
		bmp->colorkey      = 0x0;
		bmp->bit = new WORD [bmp->surface_word];
		if (Is555)
			bmp->pixelbitcount = 15;
		else
			bmp->pixelbitcount = 16;
		put_message(bmp->bit == NULL, "����û���㹻���ڴ档");
		if (bmpinfo.biBitCount == 8) // 8λɫ�Ĵ���
		{
			RGBQUAD *quad;
			quad = new RGBQUAD[256];
			if (quad == NULL)
			{
				delete bmp;
				delete filebuffer;
				fclose(data_file->fp);
				put_message(TRUE, 
					"����û���㹻���ڴ档");
				return NULL;
			}
			WORD *pal;
			pal = new WORD[256];
			if (pal == NULL)
			{
				delete bmp;
				delete filebuffer;
				delete quad;
				fclose(data_file->fp);
				put_message(TRUE, 
					"����û���㹻���ڴ档");
				return NULL;
			}
			memcpy(quad, pbuffer, sizeof(RGBQUAD) * 256);
			pbuffer += sizeof(RGBQUAD) * 256;
			DWORD c;
			for (int i = 0; i < 256; i++) // ��ɫ��
			{
				c = ((((DWORD)quad[i].rgbRed) << 16) | (((DWORD)quad[i].rgbGreen) << 8) | ((DWORD)quad[i].rgbBlue));
				pal[i] = true_to_hi(c);
			}
			for (int ii = 0; ii < 256; ii++)
				pal[ii] = true_to_hi(*((DWORD *)(quad + ii)));
			WORD* Offset = bmp->bit;
			DWORD linesize;
			BYTE* buffer;
			linesize = (bmpinfo.biWidth + 3) & 0xfffffffc;
			buffer = (BYTE *)malloc(linesize);
			
			for (i = bmpinfo.biHeight - 1; i >= 0; i--)
			{
				Offset = bmp->bit + i * bmpinfo.biWidth ;
				memcpy(buffer, pbuffer, linesize);
				pbuffer += linesize;
				for (int j = 0; j < bmpinfo.biWidth; j++)
					Offset[j] = pal[buffer[j]];
			}
			delete filebuffer;
			delete buffer;
			Offset = NULL;
			delete pal;
			delete quad;
			return bmp;
		}
		// 24λɫ����
		int linesize = (bmpinfo.biWidth * 3 + 3) & 0xfffffffc;
		BYTE *Buffer;
		Buffer = new BYTE[linesize];
		if (Buffer == NULL)
		{
			delete filebuffer;
			delete bmp;
			fclose(data_file->fp);
			put_message(TRUE, 
				"����û���㹻���ڴ档");
			return NULL;
		}
		WORD *Offset;
		for (int i = bmpinfo.biHeight - 1; i >= 0; i--)
		{
			memcpy(Buffer, pbuffer, linesize);
			pbuffer += linesize;
			Offset = bmp->bit + i * bmpinfo.biWidth; 
			for (int j = 0; j < bmpinfo.biWidth; j++)
				Offset[j] = true_to_hi((*(DWORD *)(Buffer + j * 3)));
		}
		delete filebuffer;
		delete Buffer;
		Offset = NULL;
		return bmp;
	}
}	

// װ��λͼ�ļ�
BMP *load_pack_bmp_file(char *filename)
{
	BOOL find_ok = FALSE;
	seek_to_first(data_file->pack_file_list);
	PACK_FILE *pf;
	for (DWORD c = 0; c < data_file->file_count; c++)
	{
		pf = (PACK_FILE *)get_data(data_file->pack_file_list);
		if (strcmp(pf->filename, filename) == 0)
		{
			find_ok = TRUE;
			break;
		}
		seek_to_next(data_file->pack_file_list);
	}
	if (!find_ok)
		return NULL;

	BMP *bmp;
	fseek(data_file->fp, pf->pos, SEEK_SET);
	bmp = new BMP;
	put_message(bmp == NULL, "����û���㹻���ڴ�ռ䡣");

	if (!pf->compress)
	{
		// ����û��ѹ����
		fread(bmp, sizeof(BMP), 1, data_file->fp);
		char *buffer = new char [bmp->surface_byte];
		fread(buffer, bmp->surface_byte, 1, data_file->fp);
		bmp->bit = (WORD *)buffer;
		return bmp;
	}
	else
	{
		// ����ѹ������
		char *cbuffer = new char [pf->filesize];
		put_message(cbuffer == NULL, "����û���㹻���ڴ�ռ䡣");
		fread(cbuffer, pf->filesize, 1, data_file->fp);
		char *filebuffer = new char [pf->oldsize], *pbuffer;
		put_message(filebuffer == NULL, "����û���㹻���ڴ�ռ䡣");
		decompress(cbuffer, pf->filesize, filebuffer);
		delete cbuffer;
		pbuffer = filebuffer;
		memcpy(bmp, pbuffer, sizeof(BMP));
		pbuffer += sizeof(BMP);
		char *buffer = new char [bmp->surface_byte];
		memcpy(buffer, pbuffer, bmp->surface_byte);
		bmp->bit = (WORD *)buffer;
		delete filebuffer;
		return bmp;
	}
}

// װ�������ļ�
void *load_pack_file(char *filename)
{
	BOOL find_ok = FALSE;
	seek_to_first(data_file->pack_file_list);
	PACK_FILE *pf;
	for (DWORD c = 0; c < data_file->file_count; c++)
	{
		pf = (PACK_FILE *)get_data(data_file->pack_file_list);
		if (strcmp(pf->filename, filename) == 0)
		{
			find_ok = TRUE;
			break;
		}
		seek_to_next(data_file->pack_file_list);
	}
	if (!find_ok)
		return NULL;

	fseek(data_file->fp, pf->pos, SEEK_SET);

	if (!pf->compress)
	{
		// ����û��ѹ����
		char *buffer = new char [pf->filesize];
		fread(buffer, pf->filesize, 1, data_file->fp);
		return buffer;
	}
	else
	{
		// ����ѹ������
		char *cbuffer = new char [pf->filesize];
		fread(cbuffer, pf->filesize, 1, data_file->fp);
		char *buffer = new char [pf->oldsize];
		decompress(cbuffer, pf->filesize, buffer);
		delete cbuffer;
		return buffer;
	}
}

// ��ȡ��Ч�ļ�
SAMPLE *load_pack_sample(char *filename)
{
	BOOL find_ok = FALSE;
	seek_to_first(data_file->pack_file_list);
	PACK_FILE *pf;
	for (DWORD c = 0; c < data_file->file_count; c++)
	{
		pf = (PACK_FILE *)get_data(data_file->pack_file_list);
		if (strcmp(pf->filename, filename) == 0)
		{
			find_ok = TRUE;
			break;
		}
		seek_to_next(data_file->pack_file_list);
	}
	if (!find_ok)
		return NULL;

	fseek(data_file->fp, pf->pos, SEEK_SET);

	SAMPLE *sample;
	sample = new SAMPLE;
	put_message(sample == NULL, "����û���㹻���ڴ档");
	if (!pf->compress)
	{
		// ����û��ѹ����
		sample->number = -1;
		DWORD riff = 0, size = 0, type = 0, entry = 0, filesize = 0, data_size = 0;
		filesize = pf->filesize;
		fread(&riff, sizeof(DWORD), 1, data_file->fp);
		fread(&size, sizeof(DWORD), 1, data_file->fp);
		fread(&type, sizeof(DWORD), 1, data_file->fp);
		BOOL format_read = FALSE, data_read = FALSE;
		if (riff != mmioFOURCC('R', 'I', 'F', 'F') ||
			type != mmioFOURCC('W', 'A', 'V', 'E'))
			return NULL;
		entry += 12;
		while(entry < filesize)
		{
			fread(&type, sizeof(DWORD), 1, data_file->fp);
			fread(&size, sizeof(DWORD), 1, data_file->fp);
			entry += 8;
			switch(type)
			{
			case mmioFOURCC('f', 'm', 't', ' '):
				if (size < sizeof(WAVEFORMAT))
					return NULL;
				fseek(data_file->fp, sizeof(WAVEFORMAT), SEEK_CUR);
				entry += sizeof(WAVEFORMAT);
				if (format_read && data_read)
					return sample;
				format_read = TRUE;
				break;
			case mmioFOURCC('d', 'a', 't', 'a'):
				sample->bit = new char [size];
				put_message(sample->bit == NULL, "����û���㹻���ڴ档");
				fread(sample->bit, size, 1, data_file->fp);
				entry += size;
				sample->size = size;
				if (format_read)
					return sample;
				break;
			}
		}
		return sample;
	}
	else
	{
		// ����ѹ������
		char *cbuffer, *filebuffer, *pbuffer;
		cbuffer = new char [pf->filesize];
		put_message(cbuffer == NULL, "����û���㹻���ڴ�ռ䡣");
		fread(cbuffer, pf->filesize, 1, data_file->fp);
		filebuffer = new char [pf->oldsize];
		put_message(filebuffer == NULL, "����û���㹻���ڴ�ռ䡣");
		decompress(cbuffer, pf->filesize, filebuffer);
		delete cbuffer;
		pbuffer = filebuffer;

		sample->number = -1;
		DWORD riff = 0, size = 0, type = 0, entry = 0, filesize = 0, data_size = 0;
		filesize = pf->oldsize;
		memcpy(&riff, pbuffer, sizeof(DWORD));
		pbuffer += sizeof(DWORD);
		memcpy(&size, pbuffer, sizeof(DWORD));
		pbuffer += sizeof(DWORD);
		memcpy(&type, pbuffer, sizeof(DWORD));
		pbuffer += sizeof(DWORD);
		BOOL format_read = FALSE, data_read = FALSE;
		if (riff != mmioFOURCC('R', 'I', 'F', 'F') ||
			type != mmioFOURCC('W', 'A', 'V', 'E'))
		{
			delete filebuffer;
			return NULL;
		}
		entry += 12;
		while(entry < filesize)
		{
			memcpy(&type, pbuffer, sizeof(DWORD));
			pbuffer += sizeof(DWORD);
			memcpy(&size, pbuffer, sizeof(DWORD));
			pbuffer += sizeof(DWORD);
			entry += 8;
			switch(type)
			{
			case mmioFOURCC('f', 'm', 't', ' '):
				if (size < sizeof(WAVEFORMAT))
				{
					delete filebuffer;
					return NULL;
				}
				pbuffer += sizeof(WAVEFORMAT);
				entry += sizeof(WAVEFORMAT);
				if (format_read && data_read)
				{
					delete filebuffer;
					return sample;
				}
				format_read = TRUE;
				break;
			case mmioFOURCC('d', 'a', 't', 'a'):
				sample->bit = new char [size];
				put_message(sample->bit == NULL, "����û���㹻���ڴ档");
				memcpy(sample->bit, pbuffer, size);
				pbuffer += size;
				entry += size;
				sample->size = size;
				if (format_read)
				{
					delete filebuffer;
					return sample;
				}
				break;
			}
		}
		return sample;
	}
}

// ��ȡ�����ļ�
MUSIC *load_pack_music(char *filename)
{
	BOOL find_ok = FALSE;
	seek_to_first(data_file->pack_file_list);
	PACK_FILE *pf;
	for (DWORD c = 0; c < data_file->file_count; c++)
	{
		pf = (PACK_FILE *)get_data(data_file->pack_file_list);
		if (strcmp(pf->filename, filename) == 0)
		{
			find_ok = TRUE;
			break;
		}
		seek_to_next(data_file->pack_file_list);
	}
	if (!find_ok)
		return NULL;

	fseek(data_file->fp, pf->pos, SEEK_SET);

	MUSIC *music;
	music = new MUSIC;
	put_message(music == NULL, "����û���㹻���ڴ档");
	music->source = MUSIC_IN_PACKFILE;
	put_message(music->fp == NULL, "���󣬶�ȡ�ļ�%sʧ�ܡ�", filename);
	DWORD riff = 0, size = 0, type = 0, entry = 0, filesize = 0, data_size = 0;
	filesize = pf->filesize;
	fread(&riff, sizeof(DWORD), 1, data_file->fp);
	fread(&size, sizeof(DWORD), 1, data_file->fp);
	fread(&type, sizeof(DWORD), 1, data_file->fp);
	BOOL format_read = FALSE, data_read = FALSE;
	if (riff != mmioFOURCC('R', 'I', 'F', 'F') ||
		type != mmioFOURCC('W', 'A', 'V', 'E'))
		return NULL;
	entry += 12;
	while(entry < filesize)
	{
		fread(&type, sizeof(DWORD), 1, data_file->fp);
		fread(&size, sizeof(DWORD), 1, data_file->fp);
		entry += 8;
		switch(type)
		{
		case mmioFOURCC('f', 'm', 't', ' '):
			if (size < sizeof(WAVEFORMAT))
				return NULL;
			fseek(data_file->fp, sizeof(WAVEFORMAT), SEEK_CUR);
			entry += sizeof(WAVEFORMAT);
			if (format_read && data_read)
				return music;
			format_read = TRUE;
			break;
		case mmioFOURCC('d', 'a', 't', 'a'):
			music->size = size;
			music->pack_offset = music->pos = ftell(data_file->fp);
			data_read = TRUE;
			if (format_read)
				return music;
			break;
		}
	}
	return music;
}

// д���ݰ������ļ��������ļ�
BOOL write_pack_file(char *filename, char *destfile)
{
	BOOL find_ok = FALSE;
	seek_to_first(data_file->pack_file_list);
	PACK_FILE *pf;
	for (DWORD c = 0; c < data_file->file_count; c++)
	{
		pf = (PACK_FILE *)get_data(data_file->pack_file_list);
		if (strcmp(pf->filename, filename) == 0)
		{
			find_ok = TRUE;
			break;
		}
		seek_to_next(data_file->pack_file_list);
	}
	if (!find_ok)
		return NULL;

	fseek(data_file->fp, pf->pos, SEEK_SET);

	char *buffer = new char [pf->filesize];
	if (buffer == NULL)
		return FALSE;
	fread(buffer, pf->filesize, 1, data_file->fp);
	FILE *fp;
	fp = fopen(destfile, "wb+");
	if (fp == NULL)
	{
		delete buffer;
		return FALSE;
	}
	fwrite(buffer, pf->filesize, 1, fp);
	fclose(fp);
	delete buffer;
	return TRUE;
}

// дȫ�����ݰ��ļ��������ļ�
BOOL write_all_pack_file()
{
	PACK_FILE *pf;
	seek_to_first(data_file->pack_file_list);
	for (DWORD c = 0; c < data_file->file_count; c++)
	{
		pf = (PACK_FILE *)get_data(data_file->pack_file_list);

		fseek(data_file->fp, pf->pos, SEEK_SET);
		char *buffer = new char [pf->filesize];
		if (buffer == NULL)
			return FALSE;
		fread(buffer, pf->filesize, 1, data_file->fp);
		FILE *fp;
		fp = fopen(pf->filename, "wb+");
		if (fp == NULL)
		{
			delete buffer;
			return FALSE;
		}
		fwrite(buffer, pf->filesize, 1, fp);
		fclose(fp);
		delete buffer;

		seek_to_next(data_file->pack_file_list);
	}
	return TRUE;
}
