#define STRUCT
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <Windowsx.h>
#include <ddraw.h>
#include <stdio.h>
#include "graphics.h"
#include "AstarFind.h"

HINSTANCE             app_hInst;
MSG                   Msg;                 // ��Ϣ��
HWND                  hWnd;                // ���ھ��
WNDCLASS              Wndclass;            // ������
LPDIRECTDRAW          lpDD = NULL;                // DirectDraw����
LPDIRECTDRAWSURFACE   lpDDPrimary;         // ����ʾҳ��
DDSURFACEDESC         PrimarySurfaceDesc;  // ����ʾҳ�������
LPDIRECTDRAWCLIPPER   lpClipper;           // ���ö���

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch(Message)
	{
    case WM_ACTIVATEAPP:
		IsActive = wParam;
		active_directinput(IsActive);
		if (!IsActive)
			restore_surface();
		return TRUE;
    case WM_SETCURSOR:
		SetCursor(NULL);
		return TRUE;
	default:
		return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return DefWindowProc(hWnd, Message, wParam, lParam);	
}

// ��ʼ�����ڼ�DirectDraw����
BOOL initialize(HINSTANCE hInst, int nCmdShow)
{
	app_hInst = hInst;
	Wndclass.style         = CS_HREDRAW | CS_VREDRAW;
	Wndclass.lpfnWndProc   = WndProc;
	Wndclass.cbClsExtra    = 0;
	Wndclass.cbWndExtra    = 0;
	Wndclass.hInstance     = hInst;
	Wndclass.hIcon         = LoadIcon(hInst, IDI_APPLICATION);
	Wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
	Wndclass.hbrBackground = NULL;
	Wndclass.lpszMenuName  = NULL;
	Wndclass.lpszClassName = "Game";
	// ע�ᴰ����
	RegisterClass(&Wndclass);

	hWnd = CreateWindowEx(
		0,
		"Game",
		"Game",
		WS_SYSMENU,
		0,
		0,
		GetSystemMetrics(SM_CXSCREEN),
		GetSystemMetrics(SM_CXSCREEN),
		NULL,
		NULL,
		hInst,
		NULL);
	// ��ʾ�͵ǼǴ���
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	// ����DirectDraw����
	if (DirectDrawCreate(NULL, &lpDD, NULL) != DD_OK)
		return FALSE;
	// ����Э����
#ifndef WINDOW_MODE
	if (lpDD->SetCooperativeLevel(hWnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN) != DD_OK)
		return FALSE;
	// ������ʾģʽ
	if (lpDD->SetDisplayMode(640, 480, 16) != DD_OK)
		return FALSE;
#else
	if (lpDD->SetCooperativeLevel(hWnd, DDSCL_NORMAL) != DD_OK)
		return FALSE;
#endif
	// ��������ʾҳ��
	DDSURFACEDESC ddsd;
	ZeroMemory(&ddsd, sizeof(DDSURFACEDESC));
	ddsd.dwSize = sizeof(ddsd); 
    ddsd.dwFlags = DDSD_CAPS;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
	if (lpDD->CreateSurface(&ddsd, &lpDDPrimary, NULL) != DD_OK)
		return FALSE;
#ifdef WINDOW_MODE
	if (lpDD->CreateClipper(0, &lpClipper, NULL) != DD_OK)
		return FALSE;
	if (lpClipper->SetHWnd(0, hWnd) != DD_OK)
		return FALSE;
	if (lpDDPrimary->SetClipper(lpClipper) != DD_OK)
		return FALSE;
#endif
	// �������ظ�ʽ��555����565
	DDPIXELFORMAT DDPixelFormat;
	ZeroMemory(&DDPixelFormat, sizeof(DDPIXELFORMAT));
	DDPixelFormat.dwSize = sizeof(DDPIXELFORMAT);
	if (lpDDPrimary->GetPixelFormat(&DDPixelFormat) != DD_OK)
		return FALSE;
#ifndef _SET_555
	if (DDPixelFormat.dwGBitMask == 2016) // 0000 0111 1110 0000
		Is555 = FALSE;
#endif
	ZeroMemory(&PrimarySurfaceDesc, sizeof(DDSURFACEDESC));
	PrimarySurfaceDesc.dwSize = sizeof(ddsd);
	PrimarySurfaceDesc.dwFlags = DDSD_WIDTH | DDSD_HEIGHT;
	if (lpDDPrimary->GetSurfaceDesc(&PrimarySurfaceDesc) != DD_OK)
		return FALSE;

	init_set();

	// ����Ļ��Ϊ��ɫ
	lock_screen();
	clrscr_bitmap(directscreen, 0x0);
	unlock_screen();

	// ��ʼ��DirectSound
	if (!init_directsound())
		return FALSE;
	return TRUE;
}

void free_resource()
{
	// ������Ļ
	if (ScreenIsLock)
		unlock_screen();
	free_ime(); // �ͷ����뷨ģ��
	free_bitmap(&screen); // �ͷ���Ļλͼ
	free_bitmap(&temp_screen); // �ͷ���ʱλͼ
	free(directscreen); // �ͷ�ָ������������ָ��λͼ
	// �ͷź��ֿ�
	if (hzk_16 != NULL)
		free(hzk_16);
	if (hzk_16 != NULL)
		free(hzk_24);
	if (asc_16 != NULL)
		free(asc_16);
	free_directsound(); // �ͷ���������
	free_directinput(); // �ͷ��������
	// �ͷ�DirectDraw����
	if (lpDDPrimary != NULL)
	{
		lpDDPrimary->Release();
		lpDDPrimary = NULL;
	}
	if (lpDD != NULL)
	{
		lpDD->Release();
		lpDD = NULL;
	}
	// �ͷŵ�����Ϣ������
	free_debug_msg();
}

// Ӧ�ó���������
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpszCmdParam, int nCmdShow)
{
	initialize(hInst, nCmdShow);

	put_message(!game_init(), "�����û���ʼ��ʧ�ܡ�");
	// ��ʼ��DirectInput
	if (!init_directinput())
		return FALSE;

	while(TRUE)
	{
		if (PeekMessage(&Msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage(&Msg, NULL, 0, 0 )) return Msg.wParam;
			TranslateMessage(&Msg);
			DispatchMessage(&Msg);
		}
		else
		{
			if (IsActive)
			{
				if (!game_loop())
				{
					game_exit();
					free_resource();
					PostQuitMessage(0);
				}
			}
		}
	}

	return Msg.wParam;
}

BOOL lock_screen()
{
	if (ScreenIsLock)
		return FALSE;
	if (lpDDPrimary->Lock(NULL, &PrimarySurfaceDesc, DDLOCK_WAIT, NULL) != DD_OK)
		put_message(TRUE, "���󣬲�������Ϊֱ��д����ʽ��");
	void *bitmap = PrimarySurfaceDesc.lpSurface;
	if (directscreen != NULL)
		free(directscreen);
	directscreen = create_ptr_bitmap(SCREEN_WIDTH, SCREEN_HEIGHT, (WORD *)bitmap);
	ScreenIsLock = TRUE;
	return TRUE;
}

void unlock_screen()
{
	if (!ScreenIsLock)
		return;
	lpDDPrimary->Unlock(&PrimarySurfaceDesc);
	free(directscreen);
	directscreen = NULL;
	ScreenIsLock = FALSE;
}

void restore_surface()
{
	lpDDPrimary->Restore();
}

void calc_fps()
{
	static int frame = 0, nt, ot = 0;
	frame++;
	nt = GetTickCount();
	if (nt > ot + 1000)
	{
		ot = nt;
		fps = frame;
		frame = 0;
	}
}

void *load_file(char *filename)
{
	FILE *fp;
	fp = fopen(filename, "rb");
	put_message(fp == NULL, "���󣬴��ļ�%sʧ��", filename);
	fseek(fp, 0, SEEK_END);
	DWORD size = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	char *buffer = new char [size];
	fread(buffer, size, 1, fp);
	return buffer;
}