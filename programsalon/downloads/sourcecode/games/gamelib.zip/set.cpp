#include "graphics.h"

BOOL Is555 = TRUE;           // ���ظ�ʽ��555  ���ֵ�ǼٵĻ�Ϊ565
BOOL IsActive = TRUE;        // Ӧ�ó̼���
BOOL TransBitblt = FALSE;    // ֵΪ��Ϊ͸������
int  Alpha;                  // Alpha��ϵĵȼ�
int  FstAlpha;               // Fstλͼʹ�õ�Alpha�ȼ�
int  DrawMode = DRAW_NORMAL; // ��ͼģʽ
BMP  *screen, *directscreen; // ������λͼ��ָ��DirectDrawSurface�������λͼ
BOOL ScreenIsLock = FALSE;   // ֵΪ��Ϊ��Ļ����
int  UpdateMode;             // ������Ļ��ģʽ
BMP *temp_screen;            // ��ʱ��Ļ������
int fps = 0;                 // ÿ������ʾ��֡��
int data_source = DATA_NORMALFILE;
int PaintMouseMode = PAINT_MOUSE_NORMAL; // ��������ģʽ

char *hzk_16, *hzk_24, *asc_16; // ָ���ֿ��ָ��
int  font_style;             // �������ʽ
int  font_shadow_x, font_shadow_y; // ������Ӱ��ƫ������
WORD font_shadow_color;      // ������Ӱ����ɫ
WORD font_hollow_color;      // ����߿����ɫ

WORD alpha25mask;
WORD alpha50mask;
WORD alpha125mask;
WORD alpha50mask_2;
DWORD dalpha25mask;
DWORD dalpha50mask;
DWORD dalpha125mask;
DWORD dalpha50mask_2;

void (* bitblt_bitmap)(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h);
void (* draw_bitmap)(BMP *dest_bmp, int x, int y, BMP *src_bmp);
void (* alpha_bitblt_bitmap)(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h);
WORD (* true_to_hi)(DWORD color);
DWORD (* hi_to_true)(WORD color);
void (* additive_bitblt_bitmap)(BMP *dest_bmp, int x, int y, BMP *src_bmp, int srcx, int srcy, int w, int h);
void ( *additive_fst)(BMP *dest_bmp, int x, int y, FST_BMP *src_fst, int srcx, int srcy, int w, int h);
void (* update_screen)();
void (* paint_C16)(BMP *bmp, int x, int y, WORD color,char *text);
void (* paint_C24)(BMP *bmp, int x, int y, WORD color,char *text);
void (* paint_ASC)(BMP *bmp, int x, int y, WORD color,char c);
void (* pixel)(BMP *bmp, int x, int y, WORD color);
BMP *(* get_win_bitmap)(char *filename);
BMP *(* get_bmp_file)(char *filename);
void *(* get_file)(char *filename);
SAMPLE *(* get_sample)(char *filename);
MUSIC *(* get_music)(char *filename);
void (* paint_mouse)(MOUSE_CURSOR *cur);
void (* alpha_pixel);

// ��ʼ������
void init_set()
{
	screen = create_bitmap(640, 480);
	temp_screen = NULL;
	directscreen = NULL;

	hzk_16 = NULL;
	hzk_24 = NULL;
	asc_16 = NULL;
	set_font_style(FONT_NORMAL);
	font_shadow_x = 2;
	font_shadow_y = 2;
	font_shadow_color = 0x0;
	font_hollow_color = 0xffff;

	set_paint_mouse_mode(PAINT_MOUSE_NORMAL);
	set_update_mode(UPDATE_NORMAL);
	set_trans_mode(FALSE);
	set_alpha(0);
	set_draw_mode(DRAW_NORMAL);
	if (Is555)
		set_555();
	else
		set_565();
	init_debug_msg();
	set_data_source(DATA_NORMALFILE);
}

// ����Ϊ555ģʽ
void set_555()
{
	clrscr_bitmap(screen, 0x0);
	if (UpdateMode == UPDATE_SHADOW)
		clrscr_bitmap(temp_screen, 0x0);
	Is555          = TRUE;
	alpha25mask    = 0x1ce7;
	alpha50mask    = 0x7bdf;
	alpha125mask   = 0xc63;
	alpha50mask_2  = 0x3def;
	dalpha25mask   = 0x1ce71ce7;
	dalpha50mask   = 0x7bde7bdf;
	dalpha125mask  = 0xc630c63;
	dalpha50mask_2 = 0x3def3def;
	true_to_hi     = true_to_hi_555;
	hi_to_true     = hi_to_true_555;
	additive_bitblt_bitmap = additive_bitblt_bitmap_555;
	additive_fst = additive_fst_555;
}

// ����Ϊ565ģʽ
void set_565()
{
	clrscr_bitmap(screen, 0x0);
	if (UpdateMode == UPDATE_SHADOW)
		clrscr_bitmap(temp_screen, 0x0);
	Is555         = FALSE;
	alpha25mask   = 0x39e7;
	alpha50mask   = 0xf7df;
	alpha125mask  = 0x18e3;
	alpha50mask_2 = 0x7bef;
	dalpha25mask   = 0x39e739e7;
	dalpha50mask   = 0xf7def7df;
	dalpha125mask  = 0x18e318e3;
	dalpha50mask_2 = 0x7bef7bef;
	true_to_hi     = true_to_hi_565;
	hi_to_true     = hi_to_true_565;
	additive_bitblt_bitmap = additive_bitblt_bitmap_565;
	additive_fst = additive_fst_565;
}

// ����͸��λͼ����ģʽ
BOOL set_trans_mode(BOOL trans)
{
	BOOL old = TransBitblt;
	TransBitblt = trans;
	if (trans)
	{
		bitblt_bitmap = mask_bitblt_bitmap;
		draw_bitmap   = mask_draw_bitmap;
	}
	else
	{
		bitblt_bitmap = nomask_bitblt_bitmap;
		draw_bitmap   = nomask_draw_bitmap;
	}
	set_alpha(Alpha);
	return old;
}

// ����Alpha��ϵĵȼ�
int set_alpha(int alpha)
{
	int old = Alpha;
	if (TransBitblt)
	{
		switch(alpha)
		{
		case 0:
			alpha_bitblt_bitmap = mask_bitblt_bitmap;
			break;
		case 1:
			alpha_bitblt_bitmap = mask_alpha_bitblt_1;
			break;
		case 2:
			alpha_bitblt_bitmap = mask_alpha_bitblt_2;
			break;
		case 3:
			alpha_bitblt_bitmap = mask_alpha_bitblt_3;
			break;
		case 4:
			alpha_bitblt_bitmap = mask_alpha_bitblt_4;
			break;
		case 5:
			alpha_bitblt_bitmap = mask_alpha_bitblt_5;
			break;
		case 6:
			alpha_bitblt_bitmap = mask_alpha_bitblt_6;
			break;
		case 7:
			alpha_bitblt_bitmap = mask_alpha_bitblt_7;
			break;
		case 8:
			alpha_bitblt_bitmap = mask_alpha_bitblt_8;
			break;
		}
	}
	else
	{
		switch(alpha)
		{
		case 0:
			alpha_bitblt_bitmap = nomask_bitblt_bitmap;
			break;
		case 1:
			alpha_bitblt_bitmap = alpha_bitblt_1;
			break;
		case 2:
			alpha_bitblt_bitmap = alpha_bitblt_2;
			break;
		case 3:
			alpha_bitblt_bitmap = alpha_bitblt_3;
			break;
		case 4:
			alpha_bitblt_bitmap = alpha_bitblt_4;
			break;
		case 5:
			alpha_bitblt_bitmap = alpha_bitblt_5;
			break;
		case 6:
			alpha_bitblt_bitmap = alpha_bitblt_6;
			break;
		case 7:
			alpha_bitblt_bitmap = alpha_bitblt_7;
			break;
		case 8:
			alpha_bitblt_bitmap = alpha_bitblt_8;
			break;
		}
	}
	switch(alpha)
	{
	case 0:
		pixel = pixel_normal;
		break;
	case 1:
		pixel = pixel_alpha_1;
		break;
	case 2:
		pixel = pixel_alpha_2;
		break;
	case 3:
		pixel = pixel_alpha_3;
		break;
	case 4:
		pixel = pixel_alpha_4;
		break;
	case 5:
		pixel = pixel_alpha_5;
		break;
	case 6:
		pixel = pixel_alpha_6;
		break;
	case 7:
		pixel = pixel_alpha_7;
		break;
	}
	Alpha = alpha;
	return old;
}

// ����λͼˢ��ģʽ
int set_update_mode(int mode)
{
	int old = UpdateMode;
	if (mode == UpdateMode)
		return mode;
	lock_screen();
	clrscr_bitmap(directscreen, 0x0);
	unlock_screen();
	clrscr_bitmap(screen, 0x0);
	free_bitmap(&temp_screen);
	if (mode == UPDATE_NORMAL)
	{
		update_screen = update_screen_normal;
	}
	else if (mode == UPDATE_SHADOW)
	{
		update_screen = update_screen_shadow;
		temp_screen = create_bitmap(SCREEN_WIDTH, SCREEN_HEIGHT, 0x0);
		temp_screen->clipleft = temp_screen->cliptop = 0;
		temp_screen->clipright = SCREEN_WIDTH - 1;
		temp_screen->clipbottom = SCREEN_HEIGHT - 1;
	}
	else if (mode == UPDATE_INTERVAL)
	{
		update_screen = update_screen_interval;
	}
	UpdateMode = mode;
	return old;
}

// ����������ʽ
int set_font_style(int style)
{
	int old = font_style;
	font_style = style;
	switch(style)
	{
	case FONT_NORMAL:
		paint_C16 = paint_C16_normal;
		paint_C24 = paint_C24_normal;
		paint_ASC = paint_ASC_normal;
		break;
	case FONT_SHADOW:
		paint_C16 = paint_C16_shadow;
		paint_C24 = paint_C24_shadow;
		paint_ASC = paint_ASC_shadow;
		break;
	case FONT_HOLLOW:
		paint_C16 = paint_C16_hollow;
		paint_C24 = paint_C24_hollow;
		paint_ASC = paint_ASC_hollow;
	}
	return old;
}

// ����������Ӱ����
void set_shadow(int x, int y, WORD sc)
{
	font_shadow_x = x;
	font_shadow_y = y;
	font_shadow_color = sc;
}

// ���ñ߿��ֵı߿�ɫ
void set_hollow(WORD hc)
{
	font_hollow_color = hc;
}

// ���û�ͼģʽ
int set_draw_mode(int mode)
{
	int old = DrawMode;
	switch(mode)
	{
	case DRAW_NORMAL:
		pixel = pixel_normal;
		break;
	case DRAW_OR:
		pixel = pixel_or;
		break;
	case DRAW_AND:
		pixel = pixel_and;
		break;
	case DRAW_XOR:
		pixel = pixel_xor;
		break;
	case DRAW_NOT:
		pixel = pixel_not;
		break;
	case DRAW_ALPHA:
		set_alpha(Alpha);
		break;
	case DRAW_ADDITIVE:
		if (Is555)
			pixel = pixel_additive_555;
		else
			pixel = pixel_additive_565;
	}
	DrawMode = mode;
	return old;
}

// ���������ļ���Դ
void set_data_source(int source)
{
	if (source == DATA_NORMALFILE)
	{
		get_win_bitmap = load_win_bitmap;
		get_bmp_file   = load_to_file;
		get_file       = load_file;
		get_sample     = load_sample;
		get_music      = load_music;
	}
	else if (DATA_PACKFILE)
	{
		get_win_bitmap = load_pack_win_bitmap;
		get_bmp_file   = load_pack_bmp_file;
		get_file       = load_pack_file;
		get_sample     = load_pack_sample;
		get_music      = load_pack_music;
	}
}

// ����������ģʽ
int set_paint_mouse_mode(int mode)
{
	int old = PaintMouseMode;
	switch(mode)
	{
	case PAINT_MOUSE_NORMAL:
		paint_mouse = paint_mouse_normal;
		break;
	case PAINT_MOUSE_ADDITIVE:
		paint_mouse = paint_mouse_additive;
		break;
	}
	PaintMouseMode = mode;
	return old;
}

int set_fst_alpha(int alpha)
{
	int old = FstAlpha;
	switch(alpha)
	{
	case 0:
		alpha_pixel = alpha_0_1;
		break;
	case 1:
		alpha_pixel = alpha_1_1;
		break;
	case 2:
		alpha_pixel = alpha_2_1;
		break;
	case 3:
		alpha_pixel = alpha_3_1;
		break;
	case 4:
		alpha_pixel = alpha_4_1;
		break;
	case 5:
		alpha_pixel = alpha_5_1;
		break;
	case 6:
		alpha_pixel = alpha_6_1;
		break;
	case 7:
		alpha_pixel = alpha_7_1;
		break;
	}
	FstAlpha = alpha;
	return old;
}