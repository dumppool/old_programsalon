#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <io.h>
#include "graphics.h"

// ���õ�ǰ��ͼ������
void set_draw_xy(BMP *bmp, int x, int y)
{
	put_message(bmp == NULL,
		"������ͼ�Բ����ڵ�λͼ���в�����");
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;

		MOV eax, x;                 // ����
		CMP eax, [ebx]BMP.clipleft;
		JL _NULL;
		CMP eax, [ebx]BMP.clipright;
		JG _NULL;
		MOV eax, y;
		CMP eax, [ebx]BMP.cliptop;
		JL _NULL;
		CMP eax, [ebx]BMP.clipbottom;
		JG _NULL;

		MOV edi, [ebx]BMP.bit;
		CMP [ebx]BMP.draw_ptr, 0;
		JE _normal;
		JMP _offset;

// ��ͨ������ָ��
_normal:
		MOV eax, y;
		IMUL [ebx]BMP.pitch_byte;
		ADD eax, x;
		ADD eax, x;
		ADD edi, eax;
		MOV [ebx]BMP.draw_ptr, edi;
		JMP _pixel_end;

_offset:
		// x > draw_x
		MOV eax, x;
		CMP eax, [ebx]BMP.draw_x;
		JG _x_draw_x;
		MOV ecx, [ebx]BMP.draw_x;
		SUB ecx, eax;
		SAL ecx, 1;
		SUB edi, ecx;
		MOV [ebx]BMP.draw_ptr, edi;
		JMP _offset_y;

_x_draw_x:
		SUB eax, [ebx]BMP.draw_x;
		SAL eax, 1;
		ADD edi, eax;
		MOV [ebx]BMP.draw_ptr, edi;
		
_offset_y:
		// y > draw_y
		MOV eax, y;
		CMP eax, [ebx]BMP.draw_y;
		JG _y_draw_y;
		JL _y_draw_y_;
		JMP _pixel_end;
_y_draw_y_:
		MOV ecx, [ebx]BMP.draw_y;
		SUB ecx, eax;
		MOV eax, ecx;
		IMUL [ebx]BMP.pitch_byte;
		SUB edi, eax;
		MOV [ebx]BMP.draw_ptr, edi;
		JMP _offset_y;

_y_draw_y:
		SUB eax, [ebx]BMP.draw_y;
		IMUL [ebx]BMP.pitch_byte;
		ADD edi, eax;
		MOV [ebx]BMP.draw_ptr, edi;

		JMP _pixel_end;

_NULL:
		MOV [ebx]BMP.draw_ptr, 0;
_pixel_end:
		POP edi;
	}
}

// ��λͼ�ϻ���(��ͨ)
void pixel_normal(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;
		MOV dx, color;
		MOV [edi], dx;
		POP edi;
	}
}

// ��λͼ�ϻ���(OR)
void pixel_or(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;
		MOV dx, [edi];
		OR dx, color;
		MOV [edi], dx;
		POP edi;
	}
}

// ��λͼ�ϻ���(XOR)
void pixel_xor(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;
		MOV dx, [edi];
		XOR dx, color;
		MOV [edi], edx;
		POP edi;
	}
}

// ��λͼ�ϻ���(AND)
void pixel_and(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;
		MOV dx, [edi];
		AND dx, color;
		MOV [edi], dx;
		POP edi;
	}
}

// ��λͼ�ϻ���(NOT)
void pixel_not(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;
		NOT color;
		MOV dx, color;
		MOV [edi], dx;
		POP edi;
	}
}

// ��λͼ�ϻ���(Alphaһ��)
void pixel_alpha_1(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;

		// ��ʼ���
		MOV ax, color;
		MOV bx, ax;
		SHR bx, 3;
		AND bx, alpha125mask;
		SUB ax, bx;
		MOV bx, [edi];
		SHR bx, 3;
		AND bx, alpha125mask;
		ADD ax, bx;
		MOV [edi], ax;
		// ��Ͻ���
		POP edi;
	}
}

// ��λͼ�ϻ���(Alpha����)
void pixel_alpha_2(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;

		// ��ʼ���
		MOV ax, color;
		MOV bx, ax;
		SHR bx, 2;
		AND bx, alpha25mask;
		SUB ax, bx;
		MOV bx, [edi];
		SHR bx, 2
	    AND bx, alpha25mask;
		ADD ax, bx;
		MOV [edi], ax;
		// ��Ͻ���
		POP edi;
	}
}

// ��λͼ�ϻ���(Alpha����)
void pixel_alpha_3(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;

		// ��ʼ���
		MOV ax, color;
		MOV bx, [edi];
		SHR bx, 2;
		SHR ax, 2;
		AND bx, alpha25mask;
		AND ax, alpha25mask;
		ADD bx, ax;         // (1/4)(ax+bx)
		MOV dx, bx;
		SHR bx, 1;           // (1/8)(ax+bx)
		ADD ax, dx;
		AND bx, alpha50mask_2;     
		ADD ax, bx;
		MOV [edi], ax;
		// ��Ͻ���
		POP edi;
	}
}

// ��λͼ�ϻ���(Alpha�ļ�)
void pixel_alpha_4(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;

		// ��ʼ���
		MOV ax, [edi];
		MOV bx, color;
		AND ax, alpha50mask;
		AND bx, alpha50mask;
		ADD ax, bx;
		RCR ax, 1;
		MOV [edi], ax;
		// ��Ͻ���
		POP edi;
	}
}

// ��λͼ�ϻ���(Alpha�弶)
void pixel_alpha_5(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;

		// ��ʼ���
		MOV ax, color;
		MOV bx, [edi];
		SHR ax, 2;
		SHR bx, 2;
	    AND ax, alpha25mask;
		AND bx, alpha25mask;
		ADD ax, bx;         // (1/4)(eax+ebx)
		MOV dx, ax;
		SHR ax, 1;          // (1/8)(eax+ebx)
		ADD dx, bx;
		AND ax, alpha50mask_2;
		ADD ax, dx;
		MOV [edi], ax;
		// ��Ͻ���
		POP edi;
	}
}

// ��λͼ�ϻ���(Alpha����)
void pixel_alpha_6(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;

		// ��ʼ���
		MOV ax, color;
		SHR ax, 2;
		MOV bx, [edi];
		AND ax, alpha25mask;
		ADD ax, bx;
		SHR bx, 2;
		AND bx, alpha25mask;
		SUB ax, bx; 
		MOV [edi], ax;
		// ��Ͻ���
		POP edi;
	}
}

// ��λͼ�ϻ���(Alpha�߼�)
void pixel_alpha_7(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;

		// ��ʼ���
		MOV ax, color;
		SHR ax, 3;
		MOV bx, [edi];
		AND ax, alpha125mask;
		ADD ax, bx;
		SHR bx, 3;
		AND bx, alpha125mask;
		SUB ax, bx; 
		MOV [edi], ax;
		// ��Ͻ���
		POP edi;
	}
}

// ��λͼ�ϻ���(Additive_565)
void pixel_additive_565(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;

		MOV dx, 0xf7df;   // 1111 0111 1101 1111
		// ��ʼ���
		MOV ax, [edi];
		MOV bx, color;
		AND ax, dx;    // 0111 0111 1101 1111
		AND bx, dx;
		ADC ax, bx;
		JNC _rnc;
		OR ax, 0xf000;
_rnc:
		TEST ax, 0x20; // 10 0000
		JZ _bnc;
		OR ax, 0x1f;
_bnc:
		TEST ax, 0x800; // 1000 0000 0000
		JZ _gnc;
		OR ax, 0x7e0;   // 111 1110 0000
_gnc:
		MOV [edi], ax;
		// ��Ͻ���
		POP edi;
	}
}

// ��λͼ�ϻ���(Additive_555)
void pixel_additive_555(BMP *bmp, int x, int y, WORD color)
{
	set_draw_xy(bmp, x, y);
	if (bmp->draw_ptr == NULL)
		return;
	_asm
	{
		PUSH edi;
		MOV ebx, bmp;
		MOV edi, [ebx]BMP.draw_ptr;

		MOV dx, 0x7bdf;   // 1111 0111 1101 1111
		// ��ʼ���
		MOV ax, [edi];
		MOV bx, color;
		AND ax, dx;    // 0111 0111 1101 1111
		AND bx, dx;
		ADD ax, bx;
		TEST ax, 0x20; // 10 0000
		JZ _bnc;
		OR ax, 0x1f;
_bnc:
		TEST ax, 0x400; // 100 0000 0000
		JZ _gnc;
		OR ax, 0x3e0;
_gnc:
		BTR ax, 15;
		JNC _rnc;
		OR ax, 0x7c00;
_rnc:
		MOV [edi], ax;
		// ��Ͻ���
		POP edi;
	}
}

// ��λͼ�ϻ���(Alpha�˼�)
void pixel_alpha_8(BMP *bmp, int x, int y, WORD color)
{
	return;
}

// ���ߺ����������˵�
void line(BMP *bmp, int x1, int y1, int x2, int y2, WORD color)
{
	put_message(bmp == NULL,
		"������ͼ�Բ����ڵ�λͼ���в�����");
	int i, sum;
	int dx, dy, wcx = 0, wcy = 0, incrementx, incrementy;
	
	dx = x2 - x1;
	dy = y2 - y1;

	if (dx > 0) incrementx = 1;
	else if (dx == 0) incrementx = 0;
	else incrementx =- 1, dx =- dx;
	if (dy > 0) incrementy = 1;
	else if(dy == 0) incrementy = 0;
	else incrementy =- 1, dy =- dy;
	if(dx > dy) sum = dx;
	else sum = dy;
	for(i = 0; i <= sum + 1; i++)
	{
		pixel(bmp, x1, y1, color);
		wcx += dx, wcy += dy;
		if (wcx > sum) wcx -= sum, x1 += incrementx;
		if (wcy > sum) wcy -= sum, y1 += incrementy;
	}
}

// ��Բ����
void circle(BMP *bmp, int x0, int y0, int r, WORD color)
{
	put_message(bmp == NULL,
		"������ͼ�Բ����ڵ�λͼ���в�����");
	int x, y;
	int increment;
	int startx, endx, starty, endy, i;
	y = r;
	increment = 3 - 2 * r;
	for (x = 0; x < y;)
	{
		startx = x, endx = x + 1;
		starty = y, endy = y + 1;
		for(i = startx; i < endx; i++)
		{
			pixel(bmp, x0 + i, y0 + y, color);
			pixel(bmp, x0 + i, y0 - y, color);
			pixel(bmp, x0 - i, y0 - y, color);
			pixel(bmp, x0 - i, y0 + y, color);
		}
		for(i = starty; i < endy; i++)
		{
			pixel(bmp, x0 + i, y0 + x, color);
			pixel(bmp, x0 + i, y0 - x, color);
			pixel(bmp, x0 - i, y0 - x, color);
			pixel(bmp, x0 - i, y0 + x, color);
		}
		if (increment < 0) increment += 4 * x + 6;
		else increment += 4 * (x - y) + 10, y--;
		x++;
	}
}

// ʵ��Բ
void circle_fill(BMP *bmp, int x0, int y0, int r, WORD color)
{
	put_message(bmp == NULL,
		"������ͼ�Բ����ڵ�λͼ���в�����");
	int x, y;
	int increment;
	int startx, endx, starty, endy, i;
	y = r;
	increment = 3 - 2 * r;
	for(x = 0; x < y;)
	{
		startx = x, endx = x + 1;
		starty = y, endy = y + 1;
		for(i = startx; i < endx; i++)
		{
			line(bmp, x0 + i, y0 + y, x0 + i, y0 - y, color);
			line(bmp, x0 - i, y0 - y, x0 - i, y0 + y, color);
		}
		for(i = starty; i < endy; i++)
		{
			line(bmp, x0 + i, y0 + x, x0 + i, y0 - x, color);
			line(bmp, x0 - i, y0 - x, x0 - i, y0 + x, color);
		}
		if (increment < 0) increment += 4 * x + 6;
		else increment += 4 * (x - y) + 10, y--;
		x++;
	}
}

// ����
void rect(BMP *bmp, int x1, int y1, int x2, int y2, WORD color)
{
	put_message(bmp == NULL,
		"������ͼ�Բ����ڵ�λͼ���в�����");
	line(bmp, x1, y1, x1, y2, color);
	line(bmp, x1, y1, x2, y1, color);
	line(bmp, x2, y2, x1, y2, color);
	line(bmp, x2, y2, x2, y1, color);
}

// ʵ�ľ���
void rect_fill(BMP *bmp, int x1, int y1, int x2, int y2, WORD color)
{
	put_message(bmp == NULL,
		"������ͼ�Բ����ڵ�λͼ���в�����");
	int i;
	for(i = y1; i <= y2; i++)
		line(bmp, x1, i, x2, i, color);
}

// ��16�����ֶ����ڴ�
BOOL load_hzk16(char *filename)
{
	if (hzk_16 != NULL) free(hzk_16);
	int fp;
	int Length = 0;
	// ���ļ�
	fp = _open(filename, _O_RDONLY); 
	if (fp == -1)
	{
		_close(fp);
		hzk_16 = NULL;
		return FALSE;
	}
	// �����ļ�����
	Length = _filelength(fp);
	hzk_16 = (char *)malloc(Length);
	if (hzk_16 == NULL)
	{
		_close(fp);
		hzk_16 = NULL;
		return FALSE;
	}
	// ��ȡ
	if (_read(fp, hzk_16, Length) <= 0)
	{
		_close(fp);
		hzk_16 = NULL;
		return FALSE;
	}
	return TRUE;
}

// ��24�����ֶ����ڴ�
BOOL load_hzk24(char *filename)
{
	if (hzk_24 != NULL)	free(hzk_24);
	int fp;
	int Length = 0;
	// ���ļ�
	fp = _open(filename, _O_RDONLY); 
	if (fp == -1)
	{
		_close(fp);
		hzk_24 = NULL;
		return FALSE;
	}
	// �����ļ�����
	Length = _filelength(fp);
	hzk_24 = (char *)malloc(Length);
	if (hzk_24 == NULL)
	{
		_close(fp);
		hzk_24 = NULL;
		return FALSE;
	}
	// ��ȡ
	if (_read(fp, hzk_24, Length) <= 0)
	{
		_close(fp);
		hzk_24 = NULL;
		return FALSE;
	}
	return TRUE;
}

// ��8*16ASC�����ֿ�����ڴ�
BOOL load_asc16(char *filename)
{
	if (asc_16 != NULL)	free(asc_16);
	int fp;
	int Length = 0;
	// ���ļ�
	fp = _open(filename, _O_RDONLY); 
	if (fp == -1)
	{
		_close(fp);
		asc_16 = NULL;
		return FALSE;
	}
	// �����ļ�����
	Length = _filelength(fp);
	asc_16 = (char *)malloc(Length);
	if (asc_16 == NULL)
	{
		_close(fp);
		asc_16 = NULL;
		return FALSE;
	}
	// ��ȡ
	if (_read(fp, asc_16, Length) <= 0)
	{
		_close(fp);
		asc_16 = NULL;
		return FALSE;
	}
	return TRUE;
}

// ��ʾ16������
void _paint_C16(BMP *bmp, int x, int y, WORD color,char *text)
{
	put_message(bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	unsigned int i, c1, c2, f = 0;
	int rec;
	long lseek;
	char by[32];
	int len = strlen(text);
 
	while((i = *text++) != 0)
	{
		if (i > 0xa1)
			if (f == 0)
			{
				c1 = (i - 0xa1) & 0x07f;
				f = 1;
			}
		else
		{
			c2 = (i - 0xa1) & 0x07f;
			f = 0;
			rec = c1 * 94 + c2;
			lseek = rec * 32L;
      
			for (int n = 0; n < 32; n++)
				by[n] = hzk_16[lseek + n];
		
			int i1, i2, i3;
			for(i1 = 0; i1 < 16; i1++)
				for(i2 = 0; i2 < 2; i2++)
					for(i3 = 0; i3 < 8; i3++)
						if ((by[i1 * 2 + i2] >> (7 - i3)) & 1)
							pixel(bmp, x + i2 * 8 + i3, y + i1, color);
			x = x + 16;
       }
	}
}

// ��ʾ16������ͨ����
void paint_C16_normal(BMP *bmp, int x, int y, WORD color, char *text)
{
	_paint_C16(bmp, x, y, color, text);
}

// ��ʾ16������Ӱ����
void paint_C16_shadow(BMP *bmp, int x, int y, WORD color, char *text)
{
	put_message(bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	_paint_C16(bmp, x + font_shadow_x, y + font_shadow_y, font_shadow_color, text);
	_paint_C16(bmp, x, y, color, text);
}

// ��ʾ16����߿���
void paint_C16_hollow(BMP *bmp, int x, int y, WORD color, char *text)
{
	put_message(bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	for (int i = -1; i < 2; i++)
		for (int j = -1; j < 2; j++)
			_paint_C16(bmp, x+j, y+i, font_hollow_color, text);
		_paint_C16(bmp, x, y, color, text);
}

// 24��������ʾ
void _paint_C24(BMP *bmp, int x, int y, WORD color, char *text)
{
	put_message(bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	unsigned int i, c1, c2, f = 0;
	int i1, i2, i3, rec;
	long lseek;
	char by[72];
	while((i = *text++) != 0)
	{
		if (i > 0xal)
			if (f == 0)
			{
				c1 = (i - 0xa1) & 0x07f;
				f = 1;
			}
			else
			{
				c2 = (i - 0xa1) & 0x07f;
				f = 0;
				rec = (c1 - 15) * 94 + c2;
				lseek = rec * 72L;
				for(int n = 0; n < 72; n++)
					by[n] = hzk_24[lseek + n];

				for(i1 = 0; i1 < 24; i1++)
					for(i2 = 0; i2 < 3; i2++)
						for(i3 = 0; i3 < 8; i3++)
							if ((by[i1 * 3 + i2] >> (7 - i3)) & 1)
								pixel(bmp, x + i1, y + i2 * 8 + i3, color);
				x = x + 24;
			}
	}
}

// ��ʾ24������ͨ����
void paint_C24_normal(BMP *bmp, int x, int y, WORD color, char *text)
{
	_paint_C24(bmp, x, y, color, text);
}

// ��ʾ24������Ӱ����
void paint_C24_shadow(BMP *bmp, int x, int y, WORD color, char *text)
{
	put_message(bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	_paint_C24(bmp, x + font_shadow_x, y + font_shadow_y, font_shadow_color, text);
	_paint_C24(bmp, x, y, color, text);
}

// ��ʾ24����߿���
void paint_C24_hollow(BMP *bmp, int x, int y, WORD color, char *text)
{
	put_message(bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	for (int i = -1; i < 2; i++)
		for (int j = -1; j < 2; j++)
			_paint_C24(bmp, x+j, y+i, font_hollow_color, text);
		_paint_C24(bmp, x, y, color, text);
}

// ��ʾ8*16ASC�ַ�
void _paint_ASC(BMP *bmp, int x, int y, WORD color,char c)
{
	put_message(bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	char *p = asc_16 + c * 16;
	unsigned char mask;
	int ex = x, ey = y;
	for (int i = 0; i < 16; i++)
	{
		ex = x;
		mask = 0x80; // 1000 0000
		for (int ii = 0; ii < 8; ii++)
		{
			if (mask & *p)
				pixel(bmp, ex, ey, color);
			mask >>= 1;
			ex++;
		}
		p++;
		ey++;
	}
}

// ��ʾ8*16ASC��ͨ�ַ�
void paint_ASC_normal(BMP *bmp, int x, int y, WORD color, char text)
{
	_paint_ASC(bmp, x, y, color, text);
}

// ��ʾ8*16ASC��Ӱ�ַ�
void paint_ASC_shadow(BMP *bmp, int x, int y, WORD color, char text)
{
	put_message(bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	_paint_ASC(bmp, x + font_shadow_x, y + font_shadow_y, font_shadow_color, text);
	_paint_ASC(bmp, x, y, color, text);
}

// ��ʾ8*16ASC�߿��ַ�
void paint_ASC_hollow(BMP *bmp, int x, int y, WORD color, char text)
{
	put_message(bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	for (int i = -1; i < 2; i++)
		for (int j = -1; j < 2; j++)
			_paint_ASC(bmp, x+j, y+i, font_hollow_color, text);
		_paint_ASC(bmp, x, y, color, text);
}

// ��ʾһ��16������ַ���
void text_out(BMP *bmp, int x, int y, WORD color, char *text)
{
	put_message(bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	char hz[3];
	hz[2] = '\0';
	int ex = x, ey = y;
	for (int i = 0; text[i]; i++)
	{
		if (text[i] == '\n')
		{
			ex = x;
			ey += 16;
		}
		else if ((unsigned char)text[i] >= 0xa1)// && text[i + 1] >= 0xal)
		{
			hz[0] = text[i];
			hz[1] = text[i + 1];
			paint_C16(bmp, ex, ey, color, hz);
			ex += 16, i++;
		}
		else
		{
			paint_ASC(bmp, ex, ey, color, text[i]);
			ex += 8;
		}
	}
}

// ��printf�ķ�ʽ��ʾ�ַ���
void text_printf(BMP *bmp, int x, int y, WORD color, char *format, ...)
{
	put_message(bmp == NULL, 
		"������ͼ�Բ����ڵ�λͼ���в�����");
	char temp[256];

	va_list list;
	va_start(list, format);
	vsprintf(temp, format, list);
	va_end(list);
	text_out(bmp, x, y, color, temp);
}