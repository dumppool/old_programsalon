#include "graphics.h"

__declspec(naked) void alpha_0_1(void)
{
	_asm
	{
		STOSW;
		RET;
	}
}

__declspec(naked) void alpha_0_2(void)
{
	_asm
	{
		STOSW;
		RET;
	}
}

__declspec(naked) void alpha_1_1(void)
{
	_asm
	{
		MOV bx, ax;
		SHR bx, 3;
		AND bx, alpha125mask;
		SUB ax, bx;
		MOV bx, [edi];
		SHR bx, 3;
	    AND bx, alpha125mask;
		ADD ax, bx;
		STOSW;
		RET;
	}
}

__declspec(naked) void alpha_1_2(void)
{
	_asm 
	{
		MOV ebx, eax;
		SHR ebx, 3;
		AND ebx, dalpha125mask;
		SUB eax, ebx;
		MOV ebx, [edi];
		SHR ebx, 3;
	    AND ebx, dalpha125mask;
		ADD eax, ebx;
		STOSD;
		RET;
	}
}

__declspec(naked) void alpha_2_1(void)
{
	_asm
	{
		MOV bx, ax;
		SHR bx, 2;
		AND bx, alpha25mask;
		SUB ax, bx;
		MOV bx, [edi];
		SHR bx, 2;
	    AND bx, alpha25mask;
		ADD ax, bx;
		STOSW;
		RET;
	}
}

__declspec(naked) void alpha_2_2(void)
{
	_asm
	{
		MOV ebx, eax;
		SHR ebx, 2;
		AND ebx, dalpha25mask;
		SUB eax, ebx;
		MOV ebx, [edi];
		SHR ebx, 2
	    AND ebx, dalpha25mask;
		ADD eax, ebx;
		STOSD;
		RET;
	}
}

__declspec(naked) void alpha_3_1(void)
{
	_asm
	{
		MOV bx, [edi];
		PUSH dx;
		SHR bx, 2;
		SHR ax, 2;
		AND bx, alpha25mask;
		AND ax, alpha25mask;
		ADD bx, ax;
		MOV dx, bx;
		SHR bx, 1;
		ADD ax, dx;
		AND bx, alpha50mask_2;
		ADD ax, bx;
		pop dx;
		STOSW;
		RET;
	}
}

__declspec(naked) void alpha_3_2(void)
{
	_asm
	{
		MOV ebx, [edi];
		PUSH edx;
		SHR ebx, 2;
		SHR eax, 2;
		AND ebx, dalpha25mask;
		AND eax, dalpha25mask;
		ADD ebx, eax;
		MOV edx, ebx;
		SHR ebx, 1;
		ADD eax, edx;
		AND ebx, dalpha50mask_2;     
		ADD eax, ebx;
		POP edx;
		STOSD;
		RET;
	}
}

__declspec(naked) void alpha_4_1(void)
{
	_asm
	{
		MOV bx, [edi];
		AND ax, alpha50mask;
		AND bx, alpha50mask;
		ADD ax, bx;
		RCR ax, 1;
		STOSW;
		RET;
	}
}

__declspec(naked) void alpha_4_2(void)
{
	_asm
	{
		MOV ebx, [edi];
		AND eax, dalpha50mask;
		AND ebx, dalpha50mask;
		ADD eax, ebx;
		RCR eax, 1;
		STOSD;
		RET;
	}
}

__declspec(naked) void alpha_5_1(void)
{
	_asm
	{
		MOV bx, [edi];
		SHR ax, 2;
		SHR bx, 2;
	    AND ax, alpha25mask;
		AND bx, alpha25mask;
		PUSH dx;
		ADD ax, bx;
		MOV dx, ax;
		SHR ax, 1;
		ADD dx, bx;
		AND ax, alpha50mask_2;
		ADD ax, dx;
		POP dx;
		STOSW;
		RET;
	}
}

__declspec(naked) void alpha_5_2(void)
{
	_asm
	{	
		MOV ebx, [edi];
		SHR eax, 2;
		SHR ebx, 2;
	    AND eax, dalpha25mask;
		AND ebx, dalpha25mask;
		PUSH edx;
		ADD eax, ebx;
		MOV edx, eax;
		SHR eax, 1;
		ADD edx, ebx;
		AND eax, dalpha50mask_2;
		ADD eax, edx;
		STOSD;
		POP edx;
		RET;
	}
}

__declspec(naked) void alpha_6_1(void)
{
	_asm
	{
		SHR ax, 2;
		MOV bx, [edi];
		AND ax, alpha25mask;
		ADD ax, bx;
		SHR bx, 2;
		AND bx, alpha25mask;
		SUB ax, bx; 
		STOSW;
		RET;
	}
}

__declspec(naked) void alpha_6_2(void)
{
	_asm
	{
		SHR eax, 2;
		MOV ebx, [edi];
		AND eax, dalpha25mask;
		ADD eax, ebx;
		SHR ebx, 2;
		AND ebx, dalpha25mask;
		SUB eax, ebx; 
		STOSD;
		RET;
	}
}

__declspec(naked) void alpha_7_1(void)
{
	_asm
	{
		SHR ax, 3;
		MOV bx, [edi];
		AND ax, alpha125mask;
		ADD ax, bx;
		SHR bx, 3;
		AND bx, alpha125mask;
		SUB ax, bx; 
		STOSW;
		RET;
	}
}

__declspec(naked) void alpha_7_2(void)
{
	_asm
	{
		SHR eax, 3;
		MOV ebx, [edi];
		AND eax, dalpha125mask;
		ADD eax, ebx;
		SHR ebx, 3;
		AND ebx, dalpha125mask;
		SUB eax, ebx; 
		STOSD;
		RET;
	}
}
