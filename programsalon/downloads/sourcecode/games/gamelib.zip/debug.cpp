#include "graphics.h"

DEBUG_MESSAGE *msg_buffer[MAX_DEBUG_MSG]; // ָ����Ϣ��ָ������
int           msg_count = 0;              // ��ǰ��Ч����Ϣ��

// �����ѡ�����ΪDEBUGģʽ
#define _DEBUG_MODE_

// ��ʼ����Ϣ������
BOOL init_debug_msg()
{
#ifdef _DEBUG_MODE_
	for (int i = 0; i < MAX_DEBUG_MSG; i++)
	{
		msg_buffer[i] = new DEBUG_MESSAGE;
		if (msg_buffer[i] == NULL)
		{
			put_message(TRUE, 
				"����û���㹻���ڴ档");
			return FALSE;
		}
		msg_buffer[i]->msg = new char [MAX_DEBUG_CHAR];
		msg_buffer[i]->delay = 0;
	}
	return TRUE;
#endif
	return TRUE;
}

// ����Ϣװ�뻺����
void add_message(char *format, ...)
{
#ifdef _DEBUG_MODE_
	char str[MAX_DEBUG_CHAR];
	DEBUG_MESSAGE *temp;
	temp = msg_buffer[MAX_DEBUG_MSG - 1];
	for (int i = MAX_DEBUG_MSG - 1; i > 0; i--)
		msg_buffer[i] = msg_buffer[i - 1];
	msg_buffer[0] = temp;

	va_list list;
	va_start(list, format);
	vsprintf(str, format, list);
	va_end(list);
	strcpy(msg_buffer[0]->msg, str);
	msg_buffer[0]->delay = DEBUG_DELAY;

	msg_count = msg_count < MAX_DEBUG_MSG ? msg_count + 1 : msg_count;
#endif
}

// ����Ϣ��ʾ����Ļ������
void show_message()
{
#ifdef _DEBUG_MODE_
	int y = DEBUG_MSG_TOP, old_style, old_alpha;
	if (DRAW_ALPHA)
		old_alpha = Alpha;
	set_alpha(0);
	old_style = set_font_style(FONT_NORMAL);
	for (int i = 0; i < msg_count; i++)
	{
		text_out(screen, DEBUG_MSG_LEFT, y, DEBUG_MSG_COLOR, msg_buffer[i]->msg);
		msg_buffer[i]->delay--;
		y += 16 + DEBUG_MSG_SPACING;
	}
	if (msg_count > 0)
	{
		if (msg_buffer[msg_count - 1]->delay < 0)
			msg_count--;
	}
	set_alpha(old_alpha);
	set_font_style(old_style);
#endif
}

// ����Ϣ��ʾ����Ļ�ϣ����ұ��밴�հ׼�����
void put_message(BOOL t, char *format, ...)
{
#ifdef _DEBUG_MODE_
	if (t)
	{
		BMP *temp;
		temp = create_bitmap(SCREEN_WIDTH, SCREEN_HEIGHT, 0x0);
		if (temp == NULL)
			return;
		draw_bitmap(temp, 0, 0, screen);
		WORD color;
		if (Is555)
			color = create_color(31, 31, 31);
		else
			color = create_color(31, 63, 31);
		set_hollow(color);
		set_font_style(FONT_HOLLOW);
		set_draw_mode(DRAW_ALPHA);
		set_alpha(4);
		rect_fill(screen, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, 0x0);
		int title_w;
		title_w = strlen("������Ϣ����") * 8;
		set_draw_mode(DRAW_NORMAL);
		text_out(screen, (SCREEN_WIDTH - title_w) / 2, 50, 0x0, "������Ϣ����");
		rect(screen, (SCREEN_WIDTH - title_w) / 2 - 20, 40, (SCREEN_WIDTH - title_w) / 2 + title_w + 20, 76, color);
		rect(screen, (SCREEN_WIDTH - title_w) / 2 - 22, 38, (SCREEN_WIDTH - title_w) / 2 + title_w + 22, 78, color);
		line(screen, 20, 90, SCREEN_WIDTH - 1 - 20, 90, color);
		line(screen, 20, 92, SCREEN_WIDTH - 1 - 20, 92, color);
		char str[65535];
		va_list list;
		va_start(list, format);
		vsprintf(str, format, list);
		va_end(list);
		set_font_style(FONT_NORMAL);
		text_out(screen, 32, 100, color, str);
		text_out(screen, 224, 460, color, "���������հ׼�����������");
		update_screen();
		wait_key(DIK_SPACE);
		game_exit();
		free_resource();
		PostQuitMessage(1);
	}
#endif
}

// �ͷŵ�����Ϣ��ռ���ڴ�
void free_debug_msg()
{
#ifdef _DEBUG_MODE_
	for (int i = 0; i < MAX_DEBUG_MSG; i++)
	{
		if (msg_buffer[i] != NULL)
		{
			if (msg_buffer[i]->msg != NULL)
				delete msg_buffer[i]->msg;
			delete msg_buffer[i];
		}
	}
#endif
}