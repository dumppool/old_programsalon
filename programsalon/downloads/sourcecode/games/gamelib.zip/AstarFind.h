#ifndef _ASTARFIND_H_
#define _ASTARFIND_H_

#include "windows.h"
#include "windowsx.h"

struct NODE
{
	int f, g, h;
	int number;
	NODE *parent;
	NODE *child[8];
	NODE *next;
	int x, y;
};

struct STACK
{
	NODE *node;
	STACK *next;
};

struct PATH
{
	int count; // ·���ĳ���
	POINT *path; // ·��
};

class CAstarFind  
{
public:
	NODE *open, *close;
	int  *map;
	int  width, height;
	PATH path;
	int  tilecount;
	STACK *stack;
public:
	BOOL NewPath(int sx, int sy, int dx, int dy);
	void FreeStack();
	void FreeNodes();
	BOOL findok;
	void Insert(NODE *succ);
	void PropagateDown(NODE*old);
	NODE* Pop();
	void Push(NODE *node);
	NODE* CheckCLOSE(int num);
	NODE* CheckOPEN(int num);
	void _CreateChild(NODE *b, int x, int y, int dx, int dy);
	void CreateChild(NODE *b, int dx, int dy);
	NODE* ReturnBestNode();
	int GetTileType(int x, int y);
	int GetTileNum(int x, int y);
	void FindPath(int sx, int sy, int dx, int dy);
	CAstarFind(int *m, int w, int h);
	virtual ~CAstarFind();

};

#endif // !defined(_ASTARFIND_H_)
