/*****************************************************************************
*                                                                             
*   BitmapTables.h
*                                                                             
*   Electrical Engineering Faculty - Software Lab                             
*   Spring semester 1998                                                      
*                                                                             
*   Tanks game                                                                
*                                                                             
*   Module description: Static bitmaps tables for the image manager module.
*                       
*                                                                             
*   Authors: Eran Yariv - 28484475                                           
*            Moshe Zur  - 24070856                                           
*                                                                            
*                                                                            
*   Date: 23/09/98                                                           
*                                                                            
******************************************************************************/
#ifndef _BITMAP_TABLES_H
#define _BITMAP_TABLES_H

#include <resource.h>

CImageManager::BitmapType CImageManager::m_Bitmaps[] = {
    {IDB_TANK1_000, NULL, (CBitMask*)1, 000, 000},                  //   0
    {IDB_TANK1_015, NULL, (CBitMask*)1, 000, 000},                  //   1
    {IDB_TANK1_030, NULL, (CBitMask*)1, 000, 000},                  //   2
    {IDB_TANK1_045, NULL, (CBitMask*)1, 000, 000},                  //   3
    {IDB_TANK1_060, NULL, (CBitMask*)1, 000, 000},                  //   4
    {IDB_TANK1_075, NULL, (CBitMask*)1, 000, 000},                  //   5
    {IDB_TANK1_090, NULL, (CBitMask*)1, 000, 000},                  //   6
    {IDB_TANK1_105, NULL, (CBitMask*)1, 000, 000},                  //   7
    {IDB_TANK1_120, NULL, (CBitMask*)1, 000, 000},                  //   8
    {IDB_TANK1_135, NULL, (CBitMask*)1, 000, 000},                  //   9
    {IDB_TANK1_150, NULL, (CBitMask*)1, 000, 000},                  //  10
    {IDB_TANK1_165, NULL, (CBitMask*)1, 000, 000},                  //  11
    {IDB_TANK1_180, NULL, (CBitMask*)1, 000, 000},                  //  12
    {IDB_TANK1_195, NULL, (CBitMask*)1, 000, 000},                  //  13
    {IDB_TANK1_210, NULL, (CBitMask*)1, 000, 000},                  //  14
    {IDB_TANK1_225, NULL, (CBitMask*)1, 000, 000},                  //  15
    {IDB_TANK1_240, NULL, (CBitMask*)1, 000, 000},                  //  16
    {IDB_TANK1_255, NULL, (CBitMask*)1, 000, 000},                  //  17
    {IDB_TANK1_270, NULL, (CBitMask*)1, 000, 000},                  //  18
    {IDB_TANK1_285, NULL, (CBitMask*)1, 000, 000},                  //  19
    {IDB_TANK1_300, NULL, (CBitMask*)1, 000, 000},                  //  20
    {IDB_TANK1_315, NULL, (CBitMask*)1, 000, 000},                  //  21
    {IDB_TANK1_330, NULL, (CBitMask*)1, 000, 000},                  //  22
    {IDB_TANK1_345, NULL, (CBitMask*)1, 000, 000},                  //  23

    {IDB_TANK2_000, NULL, (CBitMask*)1, 000, 000},                  //  24
    {IDB_TANK2_015, NULL, (CBitMask*)1, 000, 000},                  //  25
    {IDB_TANK2_030, NULL, (CBitMask*)1, 000, 000},                  //  26
    {IDB_TANK2_045, NULL, (CBitMask*)1, 000, 000},                  //  27
    {IDB_TANK2_060, NULL, (CBitMask*)1, 000, 000},                  //  28
    {IDB_TANK2_075, NULL, (CBitMask*)1, 000, 000},                  //  29
    {IDB_TANK2_090, NULL, (CBitMask*)1, 000, 000},                  //  30
    {IDB_TANK2_105, NULL, (CBitMask*)1, 000, 000},                  //  31
    {IDB_TANK2_120, NULL, (CBitMask*)1, 000, 000},                  //  32
    {IDB_TANK2_135, NULL, (CBitMask*)1, 000, 000},                  //  33
    {IDB_TANK2_150, NULL, (CBitMask*)1, 000, 000},                  //  34
    {IDB_TANK2_165, NULL, (CBitMask*)1, 000, 000},                  //  35
    {IDB_TANK2_180, NULL, (CBitMask*)1, 000, 000},                  //  36
    {IDB_TANK2_195, NULL, (CBitMask*)1, 000, 000},                  //  37
    {IDB_TANK2_210, NULL, (CBitMask*)1, 000, 000},                  //  38
    {IDB_TANK2_225, NULL, (CBitMask*)1, 000, 000},                  //  39
    {IDB_TANK2_240, NULL, (CBitMask*)1, 000, 000},                  //  40
    {IDB_TANK2_255, NULL, (CBitMask*)1, 000, 000},                  //  41
    {IDB_TANK2_270, NULL, (CBitMask*)1, 000, 000},                  //  42
    {IDB_TANK2_285, NULL, (CBitMask*)1, 000, 000},                  //  43
    {IDB_TANK2_300, NULL, (CBitMask*)1, 000, 000},                  //  44
    {IDB_TANK2_315, NULL, (CBitMask*)1, 000, 000},                  //  45
    {IDB_TANK2_330, NULL, (CBitMask*)1, 000, 000},                  //  46
    {IDB_TANK2_345, NULL, (CBitMask*)1, 000, 000},                  //  47

    {IDB_TANK3_000, NULL, (CBitMask*)1, 000, 000},                  //  48
    {IDB_TANK3_015, NULL, (CBitMask*)1, 000, 000},                  //  49
    {IDB_TANK3_030, NULL, (CBitMask*)1, 000, 000},                  //  50
    {IDB_TANK3_045, NULL, (CBitMask*)1, 000, 000},                  //  51
    {IDB_TANK3_060, NULL, (CBitMask*)1, 000, 000},                  //  52
    {IDB_TANK3_075, NULL, (CBitMask*)1, 000, 000},                  //  53
    {IDB_TANK3_090, NULL, (CBitMask*)1, 000, 000},                  //  54
    {IDB_TANK3_105, NULL, (CBitMask*)1, 000, 000},                  //  55
    {IDB_TANK3_120, NULL, (CBitMask*)1, 000, 000},                  //  56
    {IDB_TANK3_135, NULL, (CBitMask*)1, 000, 000},                  //  57
    {IDB_TANK3_150, NULL, (CBitMask*)1, 000, 000},                  //  58
    {IDB_TANK3_165, NULL, (CBitMask*)1, 000, 000},                  //  59
    {IDB_TANK3_180, NULL, (CBitMask*)1, 000, 000},                  //  60
    {IDB_TANK3_195, NULL, (CBitMask*)1, 000, 000},                  //  61
    {IDB_TANK3_210, NULL, (CBitMask*)1, 000, 000},                  //  62
    {IDB_TANK3_225, NULL, (CBitMask*)1, 000, 000},                  //  63
    {IDB_TANK3_240, NULL, (CBitMask*)1, 000, 000},                  //  64
    {IDB_TANK3_255, NULL, (CBitMask*)1, 000, 000},                  //  65
    {IDB_TANK3_270, NULL, (CBitMask*)1, 000, 000},                  //  66
    {IDB_TANK3_285, NULL, (CBitMask*)1, 000, 000},                  //  67
    {IDB_TANK3_300, NULL, (CBitMask*)1, 000, 000},                  //  68
    {IDB_TANK3_315, NULL, (CBitMask*)1, 000, 000},                  //  69
    {IDB_TANK3_330, NULL, (CBitMask*)1, 000, 000},                  //  70
    {IDB_TANK3_345, NULL, (CBitMask*)1, 000, 000},                  //  71

    {IDB_TANK4_000, NULL, (CBitMask*)1, 000, 000},                  //  72
    {IDB_TANK4_015, NULL, (CBitMask*)1, 000, 000},                  //  73
    {IDB_TANK4_030, NULL, (CBitMask*)1, 000, 000},                  //  74
    {IDB_TANK4_045, NULL, (CBitMask*)1, 000, 000},                  //  75
    {IDB_TANK4_060, NULL, (CBitMask*)1, 000, 000},                  //  76
    {IDB_TANK4_075, NULL, (CBitMask*)1, 000, 000},                  //  77
    {IDB_TANK4_090, NULL, (CBitMask*)1, 000, 000},                  //  78
    {IDB_TANK4_105, NULL, (CBitMask*)1, 000, 000},                  //  79
    {IDB_TANK4_120, NULL, (CBitMask*)1, 000, 000},                  //  80
    {IDB_TANK4_135, NULL, (CBitMask*)1, 000, 000},                  //  81
    {IDB_TANK4_150, NULL, (CBitMask*)1, 000, 000},                  //  82
    {IDB_TANK4_165, NULL, (CBitMask*)1, 000, 000},                  //  83
    {IDB_TANK4_180, NULL, (CBitMask*)1, 000, 000},                  //  84
    {IDB_TANK4_195, NULL, (CBitMask*)1, 000, 000},                  //  85
    {IDB_TANK4_210, NULL, (CBitMask*)1, 000, 000},                  //  86
    {IDB_TANK4_225, NULL, (CBitMask*)1, 000, 000},                  //  87
    {IDB_TANK4_240, NULL, (CBitMask*)1, 000, 000},                  //  88
    {IDB_TANK4_255, NULL, (CBitMask*)1, 000, 000},                  //  89
    {IDB_TANK4_270, NULL, (CBitMask*)1, 000, 000},                  //  90
    {IDB_TANK4_285, NULL, (CBitMask*)1, 000, 000},                  //  91
    {IDB_TANK4_300, NULL, (CBitMask*)1, 000, 000},                  //  92
    {IDB_TANK4_315, NULL, (CBitMask*)1, 000, 000},                  //  93
    {IDB_TANK4_330, NULL, (CBitMask*)1, 000, 000},                  //  94
    {IDB_TANK4_345, NULL, (CBitMask*)1, 000, 000},                  //  95

    {IDB_SHELL_000, NULL, (CBitMask*)1, 000, 000},                  //  96
    {IDB_SHELL_015, NULL, (CBitMask*)1, 000, 000},                  //  97
    {IDB_SHELL_030, NULL, (CBitMask*)1, 000, 000},                  //  98
    {IDB_SHELL_045, NULL, (CBitMask*)1, 000, 000},                  //  99
    {IDB_SHELL_060, NULL, (CBitMask*)1, 000, 000},                  // 100
    {IDB_SHELL_075, NULL, (CBitMask*)1, 000, 000},                  // 101
    {IDB_SHELL_090, NULL, (CBitMask*)1, 000, 000},                  // 102
    {IDB_SHELL_105, NULL, (CBitMask*)1, 000, 000},                  // 103
    {IDB_SHELL_120, NULL, (CBitMask*)1, 000, 000},                  // 104
    {IDB_SHELL_135, NULL, (CBitMask*)1, 000, 000},                  // 105
    {IDB_SHELL_150, NULL, (CBitMask*)1, 000, 000},                  // 106
    {IDB_SHELL_165, NULL, (CBitMask*)1, 000, 000},                  // 107
    {IDB_SHELL_180, NULL, (CBitMask*)1, 000, 000},                  // 108
    {IDB_SHELL_195, NULL, (CBitMask*)1, 000, 000},                  // 109
    {IDB_SHELL_210, NULL, (CBitMask*)1, 000, 000},                  // 110
    {IDB_SHELL_225, NULL, (CBitMask*)1, 000, 000},                  // 111
    {IDB_SHELL_240, NULL, (CBitMask*)1, 000, 000},                  // 112
    {IDB_SHELL_255, NULL, (CBitMask*)1, 000, 000},                  // 113
    {IDB_SHELL_270, NULL, (CBitMask*)1, 000, 000},                  // 114
    {IDB_SHELL_285, NULL, (CBitMask*)1, 000, 000},                  // 115
    {IDB_SHELL_300, NULL, (CBitMask*)1, 000, 000},                  // 116
    {IDB_SHELL_315, NULL, (CBitMask*)1, 000, 000},                  // 117
    {IDB_SHELL_330, NULL, (CBitMask*)1, 000, 000},                  // 118
    {IDB_SHELL_345, NULL, (CBitMask*)1, 000, 000},                  // 119

    {IDB_TANK_EXPLODE_01, NULL, NULL,   2,  -4},                    // 120
    {IDB_TANK_EXPLODE_02, NULL, NULL,   2,  -4},                    // 121
    {IDB_TANK_EXPLODE_03, NULL, NULL,   2,  -4},                    // 122
    {IDB_TANK_EXPLODE_04, NULL, NULL,   2,  -4},                    // 123
    {IDB_TANK_EXPLODE_05, NULL, NULL,   2,  -4},                    // 124
    {IDB_TANK_EXPLODE_06, NULL, NULL,   2,  -4},                    // 125
    {IDB_TANK_EXPLODE_07, NULL, NULL,   2,  -4},                    // 126
    {IDB_TANK_EXPLODE_08, NULL, NULL,   2,  -4},                    // 127
    {IDB_TANK_EXPLODE_09, NULL, NULL,   2,  -4},                    // 128
    {IDB_TANK_EXPLODE_10, NULL, NULL,   2,  -4},                    // 129
    {IDB_TANK_EXPLODE_11, NULL, NULL,   2,  -4},                    // 130
    {IDB_TANK_EXPLODE_12, NULL, NULL,   2,  -4},                    // 131
    {IDB_TANK_EXPLODE_13, NULL, NULL,   2,  -4},                    // 132
    {IDB_TANK_EXPLODE_14, NULL, NULL,   2,  -4},                    // 133
    {IDB_TANK_EXPLODE_15, NULL, NULL,   2,  -4},                    // 134
    {IDB_TANK_EXPLODE_16, NULL, NULL,   2,  -4},                    // 135

    {IDB_SHELL_EXPLODE_00, NULL, NULL, -13, -13},                   // 136
    {IDB_SHELL_EXPLODE_01, NULL, NULL, -13, -13},                   // 137
    {IDB_SHELL_EXPLODE_02, NULL, NULL, -13, -13},                   // 138
    {IDB_SHELL_EXPLODE_03, NULL, NULL, -13, -13},                   // 139
    {IDB_SHELL_EXPLODE_04, NULL, NULL, -13, -13},                   // 140
    {IDB_SHELL_EXPLODE_05, NULL, NULL, -13, -13},                   // 141
    {IDB_SHELL_EXPLODE_06, NULL, NULL, -13, -13},                   // 142
    {IDB_SHELL_EXPLODE_07, NULL, NULL, -13, -13},                   // 143
    {IDB_SHELL_EXPLODE_08, NULL, NULL, -13, -13},                   // 144
    {IDB_SHELL_EXPLODE_09, NULL, NULL, -13, -13},                   // 145
    {IDB_SHELL_EXPLODE_10, NULL, NULL, -13, -13},                   // 146
    {IDB_SHELL_EXPLODE_11, NULL, NULL, -13, -13},                   // 147
    {IDB_SHELL_EXPLODE_12, NULL, NULL, -13, -13},                   // 148
    {IDB_SHELL_EXPLODE_13, NULL, NULL, -13, -13},                   // 149

    {IDB_BULLET,           NULL, NULL, 000, 000},                   // 150

    {IDB_BOARD,            NULL, NULL, 000, 000},                   // 151

    {IDB_MINE_ON,          NULL, NULL, 000, 000},                   // 152
    {IDB_MINE_OFF,         NULL, NULL, 000, 000},                   // 153

    {IDB_BONUS_AERIAL_00,  NULL, NULL, 000, 000},                   // 154
    {IDB_BONUS_AERIAL_01,  NULL, NULL, 000, 000},                   // 155
    {IDB_BONUS_AERIAL_02,  NULL, NULL, 000, 000},                   // 156
    {IDB_BONUS_AERIAL_03,  NULL, NULL, 000, 000},                   // 157
    {IDB_BONUS_AERIAL_04,  NULL, NULL, 000, 000},                   // 158
    {IDB_BONUS_AERIAL_05,  NULL, NULL, 000, 000},                   // 159
    {IDB_BONUS_AERIAL_06,  NULL, NULL, 000, 000},                   // 160
    {IDB_BONUS_AERIAL_07,  NULL, NULL, 000, 000},                   // 161
    {IDB_BONUS_AERIAL_08,  NULL, NULL, 000, 000},                   // 162
    {IDB_BONUS_AERIAL_09,  NULL, NULL, 000, 000},                   // 163
    {IDB_BONUS_AERIAL_10,  NULL, NULL, 000, 000},                   // 164
    {IDB_BONUS_AERIAL_11,  NULL, NULL, 000, 000},                   // 165
    {IDB_BONUS_AERIAL_12,  NULL, NULL, 000, 000},                   // 166
    {IDB_BONUS_AERIAL_13,  NULL, NULL, 000, 000},                   // 167
    {IDB_BONUS_AERIAL_14,  NULL, NULL, 000, 000},                   // 168
    {IDB_BONUS_AERIAL_15,  NULL, NULL, 000, 000},                   // 169
    {IDB_BONUS_AERIAL_16,  NULL, NULL, 000, 000},                   // 170
    {IDB_BONUS_AERIAL_17,  NULL, NULL, 000, 000},                   // 171
    {IDB_BONUS_AERIAL_18,  NULL, NULL, 000, 000},                   // 172
    {IDB_BONUS_AERIAL_19,  NULL, NULL, 000, 000},                   // 173

    {IDB_BONUS_BULLETS_00, NULL, NULL, 000, 000},                   // 174
    {IDB_BONUS_BULLETS_01, NULL, NULL, 000, 000},                   // 175
    {IDB_BONUS_BULLETS_02, NULL, NULL, 000, 000},                   // 176
    {IDB_BONUS_BULLETS_03, NULL, NULL, 000, 000},                   // 177
    {IDB_BONUS_BULLETS_04, NULL, NULL, 000, 000},                   // 178
    {IDB_BONUS_BULLETS_05, NULL, NULL, 000, 000},                   // 179
    {IDB_BONUS_BULLETS_06, NULL, NULL, 000, 000},                   // 180
    {IDB_BONUS_BULLETS_07, NULL, NULL, 000, 000},                   // 181
    {IDB_BONUS_BULLETS_08, NULL, NULL, 000, 000},                   // 182
    {IDB_BONUS_BULLETS_09, NULL, NULL, 000, 000},                   // 183
    {IDB_BONUS_BULLETS_10, NULL, NULL, 000, 000},                   // 184
    {IDB_BONUS_BULLETS_11, NULL, NULL, 000, 000},                   // 185
    {IDB_BONUS_BULLETS_12, NULL, NULL, 000, 000},                   // 186
    {IDB_BONUS_BULLETS_13, NULL, NULL, 000, 000},                   // 187
    {IDB_BONUS_BULLETS_14, NULL, NULL, 000, 000},                   // 188
    {IDB_BONUS_BULLETS_15, NULL, NULL, 000, 000},                   // 189
    {IDB_BONUS_BULLETS_16, NULL, NULL, 000, 000},                   // 190
    {IDB_BONUS_BULLETS_17, NULL, NULL, 000, 000},                   // 191
    {IDB_BONUS_BULLETS_18, NULL, NULL, 000, 000},                   // 192
    {IDB_BONUS_BULLETS_19, NULL, NULL, 000, 000},                   // 193

    {IDB_BONUS_FIRERATE_00, NULL, NULL, 000, 000},                  // 194
    {IDB_BONUS_FIRERATE_01, NULL, NULL, 000, 000},                  // 195
    {IDB_BONUS_FIRERATE_02, NULL, NULL, 000, 000},                  // 196
    {IDB_BONUS_FIRERATE_03, NULL, NULL, 000, 000},                  // 197
    {IDB_BONUS_FIRERATE_04, NULL, NULL, 000, 000},                  // 198
    {IDB_BONUS_FIRERATE_05, NULL, NULL, 000, 000},                  // 199
    {IDB_BONUS_FIRERATE_06, NULL, NULL, 000, 000},                  // 200
    {IDB_BONUS_FIRERATE_07, NULL, NULL, 000, 000},                  // 201
    {IDB_BONUS_FIRERATE_08, NULL, NULL, 000, 000},                  // 202
    {IDB_BONUS_FIRERATE_09, NULL, NULL, 000, 000},                  // 203
    {IDB_BONUS_FIRERATE_10, NULL, NULL, 000, 000},                  // 204
    {IDB_BONUS_FIRERATE_11, NULL, NULL, 000, 000},                  // 205
    {IDB_BONUS_FIRERATE_12, NULL, NULL, 000, 000},                  // 206
    {IDB_BONUS_FIRERATE_13, NULL, NULL, 000, 000},                  // 207
    {IDB_BONUS_FIRERATE_14, NULL, NULL, 000, 000},                  // 208
    {IDB_BONUS_FIRERATE_15, NULL, NULL, 000, 000},                  // 209
    {IDB_BONUS_FIRERATE_16, NULL, NULL, 000, 000},                  // 210
    {IDB_BONUS_FIRERATE_17, NULL, NULL, 000, 000},                  // 211
    {IDB_BONUS_FIRERATE_18, NULL, NULL, 000, 000},                  // 212
    {IDB_BONUS_FIRERATE_19, NULL, NULL, 000, 000},                  // 213

    {IDB_BONUS_SHELLS_00,   NULL, NULL, 000, 000},                  // 214
    {IDB_BONUS_SHELLS_01,   NULL, NULL, 000, 000},                  // 215
    {IDB_BONUS_SHELLS_02,   NULL, NULL, 000, 000},                  // 216
    {IDB_BONUS_SHELLS_03,   NULL, NULL, 000, 000},                  // 217
    {IDB_BONUS_SHELLS_04,   NULL, NULL, 000, 000},                  // 218
    {IDB_BONUS_SHELLS_05,   NULL, NULL, 000, 000},                  // 219
    {IDB_BONUS_SHELLS_06,   NULL, NULL, 000, 000},                  // 220
    {IDB_BONUS_SHELLS_07,   NULL, NULL, 000, 000},                  // 221
    {IDB_BONUS_SHELLS_08,   NULL, NULL, 000, 000},                  // 222
    {IDB_BONUS_SHELLS_09,   NULL, NULL, 000, 000},                  // 223
    {IDB_BONUS_SHELLS_10,   NULL, NULL, 000, 000},                  // 224
    {IDB_BONUS_SHELLS_11,   NULL, NULL, 000, 000},                  // 225
    {IDB_BONUS_SHELLS_12,   NULL, NULL, 000, 000},                  // 226
    {IDB_BONUS_SHELLS_13,   NULL, NULL, 000, 000},                  // 227
    {IDB_BONUS_SHELLS_14,   NULL, NULL, 000, 000},                  // 228
    {IDB_BONUS_SHELLS_15,   NULL, NULL, 000, 000},                  // 229
    {IDB_BONUS_SHELLS_16,   NULL, NULL, 000, 000},                  // 230
    {IDB_BONUS_SHELLS_17,   NULL, NULL, 000, 000},                  // 231
    {IDB_BONUS_SHELLS_18,   NULL, NULL, 000, 000},                  // 232
    {IDB_BONUS_SHELLS_19,   NULL, NULL, 000, 000},                  // 233

    {IDB_BONUS_SHIELD_00,   NULL, NULL, 000, 000},                  // 234
    {IDB_BONUS_SHIELD_01,   NULL, NULL, 000, 000},                  // 235
    {IDB_BONUS_SHIELD_02,   NULL, NULL, 000, 000},                  // 236
    {IDB_BONUS_SHIELD_03,   NULL, NULL, 000, 000},                  // 237
    {IDB_BONUS_SHIELD_04,   NULL, NULL, 000, 000},                  // 238
    {IDB_BONUS_SHIELD_05,   NULL, NULL, 000, 000},                  // 239
    {IDB_BONUS_SHIELD_06,   NULL, NULL, 000, 000},                  // 240
    {IDB_BONUS_SHIELD_07,   NULL, NULL, 000, 000},                  // 241
    {IDB_BONUS_SHIELD_08,   NULL, NULL, 000, 000},                  // 242

    {IDB_BONUS_MINES_00,    NULL, NULL, 000, 000},                  // 243
    {IDB_BONUS_MINES_01,    NULL, NULL, 000, 000},                  // 244
    {IDB_BONUS_MINES_02,    NULL, NULL, 000, 000},                  // 245
    {IDB_BONUS_MINES_03,    NULL, NULL, 000, 000},                  // 246
    {IDB_BONUS_MINES_04,    NULL, NULL, 000, 000},                  // 247
    {IDB_BONUS_MINES_05,    NULL, NULL, 000, 000},                  // 248
    {IDB_BONUS_MINES_06,    NULL, NULL, 000, 000},                  // 249
    {IDB_BONUS_MINES_07,    NULL, NULL, 000, 000},                  // 250
    {IDB_BONUS_MINES_08,    NULL, NULL, 000, 000},                  // 251

    {IDB_GAMEOVER_00,       NULL, NULL, 000, 000},                  // 252
    {IDB_GAMEOVER_01,       NULL, NULL, 000, 000},                  // 253
    {IDB_GAMEOVER_02,       NULL, NULL, 000, 000},                  // 254
    {IDB_GAMEOVER_03,       NULL, NULL, 000, 000},                  // 255
    {IDB_GAMEOVER_04,       NULL, NULL, 000, 000},                  // 256
    {IDB_GAMEOVER_05,       NULL, NULL, 000, 000},                  // 257
    {IDB_GAMEOVER_06,       NULL, NULL, 000, 000},                  // 258
    {IDB_GAMEOVER_07,       NULL, NULL, 000, 000},                  // 259
    {IDB_GAMEOVER_08,       NULL, NULL, 000, 000},                  // 260
    {IDB_GAMEOVER_09,       NULL, NULL, 000, 000},                  // 261
    {IDB_GAMEOVER_10,       NULL, NULL, 000, 000},                  // 262
    {IDB_GAMEOVER_11,       NULL, NULL, 000, 000},                  // 263
    {IDB_GAMEOVER_12,       NULL, NULL, 000, 000},                  // 264
    {IDB_GAMEOVER_13,       NULL, NULL, 000, 000},                  // 265
    {IDB_GAMEOVER_14,       NULL, NULL, 000, 000},                  // 266
    {IDB_GAMEOVER_15,       NULL, NULL, 000, 000},                  // 267
    {IDB_GAMEOVER_16,       NULL, NULL, 000, 000},                  // 268
    {IDB_GAMEOVER_17,       NULL, NULL, 000, 000},                  // 269
    {IDB_GAMEOVER_18,       NULL, NULL, 000, 000},                  // 270
    {IDB_GAMEOVER_19,       NULL, NULL, 000, 000},                  // 271
    {IDB_GAMEOVER_20,       NULL, NULL, 000, 000},                  // 272
    {IDB_GAMEOVER_21,       NULL, NULL, 000, 000},                  // 273
    {IDB_GAMEOVER_22,       NULL, NULL, 000, 000},                  // 274
    {IDB_GAMEOVER_23,       NULL, NULL, 000, 000},                  // 275
    {IDB_GAMEOVER_24,       NULL, NULL, 000, 000},                  // 276
    {IDB_GAMEOVER_25,       NULL, NULL, 000, 000},                  // 277
    {IDB_GAMEOVER_26,       NULL, NULL, 000, 000},                  // 278
    {IDB_GAMEOVER_27,       NULL, NULL, 000, 000},                  // 279
    {IDB_GAMEOVER_28,       NULL, NULL, 000, 000},                  // 280
    {IDB_GAMEOVER_29,       NULL, NULL, 000, 000},                  // 281
    {IDB_GAMEOVER_30,       NULL, NULL, 000, 000},                  // 282
    {IDB_GAMEOVER_31,       NULL, NULL, 000, 000},                  // 283
    {IDB_GAMEOVER_32,       NULL, NULL, 000, 000},                  // 284
    {IDB_GAMEOVER_33,       NULL, NULL, 000, 000},                  // 285
    {IDB_GAMEOVER_34,       NULL, NULL, 000, 000},                  // 286
    {IDB_GAMEOVER_35,       NULL, NULL, 000, 000},                  // 287
    {IDB_GAMEOVER_36,       NULL, NULL, 000, 000},                  // 288
    {IDB_GAMEOVER_37,       NULL, NULL, 000, 000},                  // 289
    {IDB_GAMEOVER_38,       NULL, NULL, 000, 000},                  // 290
    {IDB_GAMEOVER_39,       NULL, NULL, 000, 000},                  // 291
    {IDB_GAMEOVER_40,       NULL, NULL, 000, 000},                  // 292
    {IDB_GAMEOVER_41,       NULL, NULL, 000, 000},                  // 293
    {IDB_GAMEOVER_42,       NULL, NULL, 000, 000},                  // 294
    {IDB_GAMEOVER_43,       NULL, NULL, 000, 000},                  // 295
    {IDB_GAMEOVER_44,       NULL, NULL, 000, 000},                  // 296
    {IDB_GAMEOVER_45,       NULL, NULL, 000, 000},                  // 297
    {IDB_GAMEOVER_46,       NULL, NULL, 000, 000},                  // 298
    {IDB_GAMEOVER_47,       NULL, NULL, 000, 000},                  // 299
    {IDB_GAMEOVER_48,       NULL, NULL, 000, 000},                  // 300
    {IDB_GAMEOVER_49,       NULL, NULL, 000, 000},                  // 301
    {IDB_GAMEOVER_50,       NULL, NULL, 000, 000},                  // 302
    {IDB_GAMEOVER_51,       NULL, NULL, 000, 000},                  // 303
    {IDB_GAMEOVER_52,       NULL, NULL, 000, 000},                  // 304
    {IDB_GAMEOVER_53,       NULL, NULL, 000, 000},                  // 305
    {IDB_GAMEOVER_54,       NULL, NULL, 000, 000},                  // 306
    {IDB_GAMEOVER_55,       NULL, NULL, 000, 000},                  // 307
    {IDB_GAMEOVER_56,       NULL, NULL, 000, 000},                  // 308
    {IDB_GAMEOVER_57,       NULL, NULL, 000, 000},                  // 309
    {IDB_GAMEOVER_58,       NULL, NULL, 000, 000},                  // 310
    {IDB_GAMEOVER_59,       NULL, NULL, 000, 000},                  // 311

    {IDB_BOMBER_000,        NULL, NULL, 000, 000},                  // 312
    {IDB_BOMBER_015,        NULL, NULL, 000, 000},                  // 313
    {IDB_BOMBER_030,        NULL, NULL, 000, 000},                  // 314
    {IDB_BOMBER_045,        NULL, NULL, 000, 000},                  // 315
    {IDB_BOMBER_060,        NULL, NULL, 000, 000},                  // 316
    {IDB_BOMBER_075,        NULL, NULL, 000, 000},                  // 317
    {IDB_BOMBER_090,        NULL, NULL, 000, 000},                  // 318
    {IDB_BOMBER_105,        NULL, NULL, 000, 000},                  // 319
    {IDB_BOMBER_120,        NULL, NULL, 000, 000},                  // 320
    {IDB_BOMBER_135,        NULL, NULL, 000, 000},                  // 321
    {IDB_BOMBER_150,        NULL, NULL, 000, 000},                  // 322
    {IDB_BOMBER_165,        NULL, NULL, 000, 000},                  // 323
    {IDB_BOMBER_180,        NULL, NULL, 000, 000},                  // 324
    {IDB_BOMBER_195,        NULL, NULL, 000, 000},                  // 325
    {IDB_BOMBER_210,        NULL, NULL, 000, 000},                  // 326
    {IDB_BOMBER_225,        NULL, NULL, 000, 000},                  // 327
    {IDB_BOMBER_240,        NULL, NULL, 000, 000},                  // 328
    {IDB_BOMBER_255,        NULL, NULL, 000, 000},                  // 329
    {IDB_BOMBER_270,        NULL, NULL, 000, 000},                  // 330
    {IDB_BOMBER_285,        NULL, NULL, 000, 000},                  // 331
    {IDB_BOMBER_300,        NULL, NULL, 000, 000},                  // 332
    {IDB_BOMBER_315,        NULL, NULL, 000, 000},                  // 333
    {IDB_BOMBER_330,        NULL, NULL, 000, 000},                  // 334
    {IDB_BOMBER_345,        NULL, NULL, 000, 000},                  // 335

    {IDB_BOMB_00,           NULL, NULL, 000, 000},                  // 336
    {IDB_BOMB_01,           NULL, NULL, 000, 000},                  // 337
    {IDB_BOMB_02,           NULL, NULL, 000, 000},                  // 338
    {IDB_BOMB_03,           NULL, NULL, 000, 000},                  // 339
    {IDB_BOMB_04,           NULL, NULL, 000, 000},                  // 340
    {IDB_BOMB_05,           NULL, NULL, 000, 000},                  // 341
    {IDB_BOMB_06,           NULL, NULL, 000, 000},                  // 342
    {IDB_BOMB_07,           NULL, NULL, 000, 000},                  // 343
    {IDB_BOMB_08,           NULL, NULL, 000, 000},                  // 344
    {IDB_BOMB_09,           NULL, NULL, 000, 000},                  // 345
    {IDB_BOMB_10,           NULL, NULL, 000, 000},                  // 346

    {IDB_ZOMBIE,            NULL, NULL, 015, 012}                   // 347

};


CImageManager::SubImageType CImageManager::m_SubImages[] = {

        //Tank 1:

    {1 /* Num bitmaps */, &m_Bitmaps[  0] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //   0
    {1 /* Num bitmaps */, &m_Bitmaps[  1] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //   1
    {1 /* Num bitmaps */, &m_Bitmaps[  2] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //   2
    {1 /* Num bitmaps */, &m_Bitmaps[  3] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //   3
    {1 /* Num bitmaps */, &m_Bitmaps[  4] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //   4
    {1 /* Num bitmaps */, &m_Bitmaps[  5] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //   5
    {1 /* Num bitmaps */, &m_Bitmaps[  6] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //   6
    {1 /* Num bitmaps */, &m_Bitmaps[  7] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //   7
    {1 /* Num bitmaps */, &m_Bitmaps[  8] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //   8
    {1 /* Num bitmaps */, &m_Bitmaps[  9] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //   9
    {1 /* Num bitmaps */, &m_Bitmaps[ 10] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  10
    {1 /* Num bitmaps */, &m_Bitmaps[ 11] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  11
    {1 /* Num bitmaps */, &m_Bitmaps[ 12] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  12
    {1 /* Num bitmaps */, &m_Bitmaps[ 13] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  13
    {1 /* Num bitmaps */, &m_Bitmaps[ 14] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  14
    {1 /* Num bitmaps */, &m_Bitmaps[ 15] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  15
    {1 /* Num bitmaps */, &m_Bitmaps[ 16] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  16
    {1 /* Num bitmaps */, &m_Bitmaps[ 17] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  17
    {1 /* Num bitmaps */, &m_Bitmaps[ 18] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  18
    {1 /* Num bitmaps */, &m_Bitmaps[ 19] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  19
    {1 /* Num bitmaps */, &m_Bitmaps[ 20] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  20
    {1 /* Num bitmaps */, &m_Bitmaps[ 21] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  21
    {1 /* Num bitmaps */, &m_Bitmaps[ 22] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  22
    {1 /* Num bitmaps */, &m_Bitmaps[ 23] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  23

        // Tank 2:

    {1 /* Num bitmaps */, &m_Bitmaps[ 24] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  24
    {1 /* Num bitmaps */, &m_Bitmaps[ 25] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  25
    {1 /* Num bitmaps */, &m_Bitmaps[ 26] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  26
    {1 /* Num bitmaps */, &m_Bitmaps[ 27] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  27
    {1 /* Num bitmaps */, &m_Bitmaps[ 28] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  28
    {1 /* Num bitmaps */, &m_Bitmaps[ 29] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  29
    {1 /* Num bitmaps */, &m_Bitmaps[ 30] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  30
    {1 /* Num bitmaps */, &m_Bitmaps[ 31] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  31
    {1 /* Num bitmaps */, &m_Bitmaps[ 32] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  32
    {1 /* Num bitmaps */, &m_Bitmaps[ 33] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  33
    {1 /* Num bitmaps */, &m_Bitmaps[ 34] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  34
    {1 /* Num bitmaps */, &m_Bitmaps[ 35] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  35
    {1 /* Num bitmaps */, &m_Bitmaps[ 36] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  36
    {1 /* Num bitmaps */, &m_Bitmaps[ 37] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  37
    {1 /* Num bitmaps */, &m_Bitmaps[ 38] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  38
    {1 /* Num bitmaps */, &m_Bitmaps[ 39] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  39
    {1 /* Num bitmaps */, &m_Bitmaps[ 40] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  40
    {1 /* Num bitmaps */, &m_Bitmaps[ 41] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  41
    {1 /* Num bitmaps */, &m_Bitmaps[ 42] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  42
    {1 /* Num bitmaps */, &m_Bitmaps[ 43] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  43
    {1 /* Num bitmaps */, &m_Bitmaps[ 44] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  44
    {1 /* Num bitmaps */, &m_Bitmaps[ 45] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  45
    {1 /* Num bitmaps */, &m_Bitmaps[ 46] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  46
    {1 /* Num bitmaps */, &m_Bitmaps[ 47] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  47


        // Tank 3:

    {1 /* Num bitmaps */, &m_Bitmaps[ 48] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  48
    {1 /* Num bitmaps */, &m_Bitmaps[ 49] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  49
    {1 /* Num bitmaps */, &m_Bitmaps[ 50] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  50
    {1 /* Num bitmaps */, &m_Bitmaps[ 51] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  51
    {1 /* Num bitmaps */, &m_Bitmaps[ 52] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  52
    {1 /* Num bitmaps */, &m_Bitmaps[ 53] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  53
    {1 /* Num bitmaps */, &m_Bitmaps[ 54] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  54
    {1 /* Num bitmaps */, &m_Bitmaps[ 55] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  55
    {1 /* Num bitmaps */, &m_Bitmaps[ 56] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  56
    {1 /* Num bitmaps */, &m_Bitmaps[ 57] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  57
    {1 /* Num bitmaps */, &m_Bitmaps[ 58] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  58
    {1 /* Num bitmaps */, &m_Bitmaps[ 59] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  59
    {1 /* Num bitmaps */, &m_Bitmaps[ 60] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  60
    {1 /* Num bitmaps */, &m_Bitmaps[ 61] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  61
    {1 /* Num bitmaps */, &m_Bitmaps[ 62] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  62
    {1 /* Num bitmaps */, &m_Bitmaps[ 63] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  63
    {1 /* Num bitmaps */, &m_Bitmaps[ 64] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  64
    {1 /* Num bitmaps */, &m_Bitmaps[ 65] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  65
    {1 /* Num bitmaps */, &m_Bitmaps[ 66] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  66
    {1 /* Num bitmaps */, &m_Bitmaps[ 67] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  67
    {1 /* Num bitmaps */, &m_Bitmaps[ 68] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  68
    {1 /* Num bitmaps */, &m_Bitmaps[ 69] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  69
    {1 /* Num bitmaps */, &m_Bitmaps[ 70] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  70
    {1 /* Num bitmaps */, &m_Bitmaps[ 71] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  71


        // Tank 4:

    {1 /* Num bitmaps */, &m_Bitmaps[ 72] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  72
    {1 /* Num bitmaps */, &m_Bitmaps[ 73] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  73
    {1 /* Num bitmaps */, &m_Bitmaps[ 74] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  74
    {1 /* Num bitmaps */, &m_Bitmaps[ 75] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  75
    {1 /* Num bitmaps */, &m_Bitmaps[ 76] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  76
    {1 /* Num bitmaps */, &m_Bitmaps[ 77] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  77
    {1 /* Num bitmaps */, &m_Bitmaps[ 78] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  78
    {1 /* Num bitmaps */, &m_Bitmaps[ 79] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  79
    {1 /* Num bitmaps */, &m_Bitmaps[ 80] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  80
    {1 /* Num bitmaps */, &m_Bitmaps[ 81] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  81
    {1 /* Num bitmaps */, &m_Bitmaps[ 82] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  82
    {1 /* Num bitmaps */, &m_Bitmaps[ 83] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  83
    {1 /* Num bitmaps */, &m_Bitmaps[ 84] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  84
    {1 /* Num bitmaps */, &m_Bitmaps[ 85] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  85
    {1 /* Num bitmaps */, &m_Bitmaps[ 86] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  86
    {1 /* Num bitmaps */, &m_Bitmaps[ 87] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  87
    {1 /* Num bitmaps */, &m_Bitmaps[ 88] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  88
    {1 /* Num bitmaps */, &m_Bitmaps[ 89] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  89
    {1 /* Num bitmaps */, &m_Bitmaps[ 90] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  90
    {1 /* Num bitmaps */, &m_Bitmaps[ 91] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  91
    {1 /* Num bitmaps */, &m_Bitmaps[ 92] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  92
    {1 /* Num bitmaps */, &m_Bitmaps[ 93] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  93
    {1 /* Num bitmaps */, &m_Bitmaps[ 94] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  94
    {1 /* Num bitmaps */, &m_Bitmaps[ 95] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  95


        // Shell:

    {1 /* Num bitmaps */, &m_Bitmaps[ 96] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  96
    {1 /* Num bitmaps */, &m_Bitmaps[ 97] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  97
    {1 /* Num bitmaps */, &m_Bitmaps[ 98] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  98
    {1 /* Num bitmaps */, &m_Bitmaps[ 99] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      //  99
    {1 /* Num bitmaps */, &m_Bitmaps[100] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 100
    {1 /* Num bitmaps */, &m_Bitmaps[101] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 101
    {1 /* Num bitmaps */, &m_Bitmaps[102] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 102
    {1 /* Num bitmaps */, &m_Bitmaps[103] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 103
    {1 /* Num bitmaps */, &m_Bitmaps[104] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 104
    {1 /* Num bitmaps */, &m_Bitmaps[105] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 105
    {1 /* Num bitmaps */, &m_Bitmaps[106] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 106
    {1 /* Num bitmaps */, &m_Bitmaps[107] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 107
    {1 /* Num bitmaps */, &m_Bitmaps[108] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 108
    {1 /* Num bitmaps */, &m_Bitmaps[109] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 109
    {1 /* Num bitmaps */, &m_Bitmaps[110] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 110
    {1 /* Num bitmaps */, &m_Bitmaps[111] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 111
    {1 /* Num bitmaps */, &m_Bitmaps[112] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 112
    {1 /* Num bitmaps */, &m_Bitmaps[113] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 113
    {1 /* Num bitmaps */, &m_Bitmaps[114] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 114
    {1 /* Num bitmaps */, &m_Bitmaps[115] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 115
    {1 /* Num bitmaps */, &m_Bitmaps[116] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 116
    {1 /* Num bitmaps */, &m_Bitmaps[117] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 117
    {1 /* Num bitmaps */, &m_Bitmaps[118] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 118
    {1 /* Num bitmaps */, &m_Bitmaps[119] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 119

    
        // Tank explosion:

    {16 /* Num bitmaps */, &m_Bitmaps[120] /* Bitmap */, FALSE /* Cyclic anim */, 100 /* Frame delay */},   // 120

    
        // Shell explosion:

    {14 /* Num bitmaps */, &m_Bitmaps[136] /* Bitmap */, FALSE /* Cyclic anim */, 100 /* Frame delay */},   // 121

   
        // Bullet

    {1 /* Num bitmaps */, &m_Bitmaps[150] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 122

        // Board

    {1 /* Num bitmaps */, &m_Bitmaps[151] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 123

        // Mine

    {2 /* Num bitmaps */, &m_Bitmaps[152] /* Bitmap */, TRUE /* Cyclic anim */, 500 /* Frame delay */},     // 124

        //  Shells bonus 

    {20/* Num bitmaps */, &m_Bitmaps[214] /* Bitmap */, TRUE /* Cyclic anim */, 100 /* Frame delay */},     // 125

        //  Bullets bonus 

    {20/* Num bitmaps */, &m_Bitmaps[174] /* Bitmap */, TRUE /* Cyclic anim */, 100 /* Frame delay */},     // 126

        //  Mines bonus 

    {9 /* Num bitmaps */, &m_Bitmaps[243] /* Bitmap */, TRUE /* Cyclic anim */, 100 /* Frame delay */},     // 127

        //  Aerial support bonus 

    {20/* Num bitmaps */, &m_Bitmaps[154] /* Bitmap */, TRUE /* Cyclic anim */, 100 /* Frame delay */},     // 128

        //  Faster fire rate bonus 

    {20/* Num bitmaps */, &m_Bitmaps[194] /* Bitmap */, TRUE /* Cyclic anim */, 100 /* Frame delay */},     // 129

        //  Shield repair bonus 

    {9 /* Num bitmaps */, &m_Bitmaps[234] /* Bitmap */, TRUE /* Cyclic anim */, 100 /* Frame delay */},     // 130

        //  Game over animation 

    {60/* Num bitmaps */, &m_Bitmaps[252] /* Bitmap */, TRUE /* Cyclic anim */,  66 /* Frame delay */},     // 131

        // Bomber

    {1 /* Num bitmaps */, &m_Bitmaps[312] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 132
    {1 /* Num bitmaps */, &m_Bitmaps[313] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 133
    {1 /* Num bitmaps */, &m_Bitmaps[314] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 134
    {1 /* Num bitmaps */, &m_Bitmaps[315] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 135
    {1 /* Num bitmaps */, &m_Bitmaps[316] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 136
    {1 /* Num bitmaps */, &m_Bitmaps[317] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 137
    {1 /* Num bitmaps */, &m_Bitmaps[318] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 138
    {1 /* Num bitmaps */, &m_Bitmaps[319] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 139
    {1 /* Num bitmaps */, &m_Bitmaps[320] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 140
    {1 /* Num bitmaps */, &m_Bitmaps[321] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 141
    {1 /* Num bitmaps */, &m_Bitmaps[322] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 142
    {1 /* Num bitmaps */, &m_Bitmaps[323] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 143
    {1 /* Num bitmaps */, &m_Bitmaps[324] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 144
    {1 /* Num bitmaps */, &m_Bitmaps[325] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 145
    {1 /* Num bitmaps */, &m_Bitmaps[326] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 146
    {1 /* Num bitmaps */, &m_Bitmaps[327] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 147
    {1 /* Num bitmaps */, &m_Bitmaps[328] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 148
    {1 /* Num bitmaps */, &m_Bitmaps[329] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 149
    {1 /* Num bitmaps */, &m_Bitmaps[330] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 150
    {1 /* Num bitmaps */, &m_Bitmaps[331] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 151
    {1 /* Num bitmaps */, &m_Bitmaps[332] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 152
    {1 /* Num bitmaps */, &m_Bitmaps[333] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 153
    {1 /* Num bitmaps */, &m_Bitmaps[334] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 154
    {1 /* Num bitmaps */, &m_Bitmaps[335] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */},      // 155

    {11/* Num bitmaps */, &m_Bitmaps[336] /* Bitmap */, FALSE /* Cyclic anim */,120/* Frame delay */},      // 156

    {1 /* Num bitmaps */, &m_Bitmaps[347] /* Bitmap */, FALSE /* Cyclic anim */, 0 /* Frame delay */}       // 157
};


CImageManager::ImageInfoType CImageManager::m_ImagesInfo[] = {
    // Image 0 (TANK1): 24 SubImages
    {
        24,             // Number of sub images
        &m_SubImages[ 0]// Pointer to 1st sub-image
    },
            
    // Image 1 (TANK2): 24 SubImages
    {
        24,             // Number of sub images
        &m_SubImages[24]// Pointer to 1st sub-image
    },
            
    // Image 2 (TANK3): 24 SubImages
    {
        24,             // Number of sub images
        &m_SubImages[48]// Pointer to 1st sub-image
    },
            
    // Image 3 (TANK4): 24 SubImages
    {
        24,             // Number of sub images
        &m_SubImages[72]// Pointer to 1st sub-image
    },
            
    // Image 4 (TANK_EXPLODE): 1 SubImage - 16 frames
    {
        1,                // Number of sub images
        &m_SubImages[120] // Pointer to 1st sub-image
    },
            
    // Image 5 (SHELL): 24 SubImages
    {
        24,             // Number of sub images
        &m_SubImages[96]// Pointer to 1st sub-image
    },

    // Image 6 (SHELL_EXPLODE): 1 SubImage - 28 frames
    {
        1,                // Number of sub images
        &m_SubImages[121] // Pointer to 1st sub-image
    },
            
    // Image 7 (BULLET): 1 SubImage
    {
        1,                // Number of sub images
        &m_SubImages[122] // Pointer to 1st sub-image
    },

    // Image 8 (BOARD): 1 SubImage
    {
        1,                // Number of sub images
        &m_SubImages[123] // Pointer to 1st sub-image
    },

    // Image 9 (MINE): 1 SubImage - 2 frame
    {
        1,                // Number of sub images
        &m_SubImages[124] // Pointer to 1st sub-image
    },
    //  Image 10 (Shells bonus): 1 SubImage - 20 frames 
    {
        1,                // Number of sub images
        &m_SubImages[125] // Pointer to 1st sub-image
    },
    //  Image 11 (Bullets bonus): 1 SubImage - 20 frames 
    {
        1,                // Number of sub images
        &m_SubImages[126] // Pointer to 1st sub-image
    },
    //  Image 12 (Mines bonus): 1 SubImage - 9 frames 
    {
        1,                // Number of sub images
        &m_SubImages[127] // Pointer to 1st sub-image
    },
    //  Image 13 (Aerial support bonus): 1 SubImage - 20 frames
    {
        1,                // Number of sub images
        &m_SubImages[128] // Pointer to 1st sub-image
    },
    //  Image 14 (Faster fire rate bonus): 1 SubImage - 20 frames 
    {
        1,                // Number of sub images
        &m_SubImages[129] // Pointer to 1st sub-image
    },
    //  Image 15 (Shield repair bonus): 1 SubImage - 9 frames 
    {
        1,                // Number of sub images
        &m_SubImages[130] // Pointer to 1st sub-image
    },
    //  Image 16 (GameOver animation): 1 SubImage - 60 frames 
    {
        1,                // Number of sub images
        &m_SubImages[131] // Pointer to 1st sub-image
    },
    //  Image 17 (Bomber): 24 SubImages
    {
        24,               // Number of sub images
        &m_SubImages[132] // Pointer to 1st sub-image
    },
    //  Image 18 (Falling bomb): 1 SubImage - 11 frames
    {
        1,                // Number of sub images
        &m_SubImages[156] // Pointer to 1st sub-image
    },
    // Image 19 (zombie overaly): 1 Sub image - 1 frame
    {
        1,                // Number of sub images
        &m_SubImages[157] // Pointer to 1st sub-image
    }
};

#endif
