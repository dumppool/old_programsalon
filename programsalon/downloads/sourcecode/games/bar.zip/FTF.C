/*

����: ����˹���� Դ�� For Turbo C 2.0

������д:

�й� ���� ����ռ���������Ⱥ
Illusion Space Software Design Groups.

BBS: 1601118 Ext (Illusion Space)
Email: ILLUSION@peony.ioa.ac.cn

W.G. & Lee.k.

BP: (010) 2561155 Call 1615
          8271188 Call 89161

��ͬ������ϵ, �������ǻ����Խ�������.

����, ��ӭ��λ��̸��ּ������ռ���������Ⱥ - ����Ա�ǵ���԰

*/

/*  text mode  */
/*   Turbo C   */
#include	<stdio.h>
#include	<stdlib.h>
#include	<dos.h>
#include	<conio.h>
#include	<time.h>

#define		L	 1
#define		R	 2
#define		RX	47
#define		RY	 4
#define		LX	15
#define		LY	 4
static	struct BLOCK{
				int	x0;
				int	y0;
				int	x1;
				int	y1;
				int	x2;
				int	y2;
				int	x3;
				int	y3;
				int	color;
				int	next;
		}b[23] = {	{	0, 1, 1, 1, 2, 1, 3, 1,  4,  1	},
					{	1, 0, 1, 3, 1, 2, 1, 1,  4,  0  },
					{	1, 1, 2, 2, 1, 2, 2, 1,  1,  2  },
					{	0, 1, 1, 1, 1, 0, 2, 0,  2,  4  },
					{	1, 0, 1, 1, 2, 2, 2, 1,  2,  5  },
					{	0, 2, 1, 2, 1, 1, 2, 1,  2,  6  },
					{	0, 0, 0, 1, 1, 2, 1, 1,  2,  3  },
					{	0, 0, 1, 0, 1, 1, 2, 1,  3,  8  },
					{	0, 1, 0, 2, 1, 1, 1, 0,  3,  9  },
					{	0, 1, 1, 1, 1, 2, 2, 2,  3, 10  },
					{	1, 1, 1, 2, 2, 1, 2, 0,  3,  7  },
					{	1, 0, 1, 1, 1, 2, 2, 2,  7, 12  },
					{	0, 1, 1, 1, 2, 1, 2, 0,  7, 13  },
					{	0, 0, 1, 2, 1, 1, 1, 0,  7, 14  },
					{	0, 1, 0, 2, 1, 1, 2, 1,  7, 11  },
					{	0, 2, 1, 2, 1, 1, 1, 0,  5, 16  },
					{	0, 1, 1, 1, 2, 2, 2, 1,  5, 17  },
					{	1, 0, 1, 1, 1, 2, 2, 0,  5, 18  },
					{	0, 0, 0, 1, 1, 1, 2, 1,  5, 15  },
					{	0, 1, 1, 1, 1, 0, 2, 1,  6, 20  },
					{	0, 1, 1, 2, 1, 1, 1, 0,  6, 21  },
					{	0, 1, 1, 2, 1, 1, 2, 1,  6, 22  },
					{	1, 0, 1, 1, 1, 2, 2, 1,  6, 19  }	};

static	int		d[10]={ 1500,3000,1600,1200,900,800,600,400,300,200 };
int		Llevel, Lcurrent, Lnext, Lable, lx, ly, Lsum;
int		Rlevel, Rcurrent, Rnext, Rable, rx, ry, Rsum;
unsigned	Lpoint, Rpoint;
int		La[19][10], Ra[19][10], FLAG, bell, sum;
unsigned	ldelay, rdelay;
void	scrinit( ),datainit( ),dispb( ), eraseb( );
void	throw( ), judge( ), delayp( ), move( ), note( ), show( );
int		Ldrop( ), Rdrop( ), Ljudge( ), Rjudge( ), nextb( ), routejudge( );

main( )
{
	char	c;
	
	do{
		scrinit( );
		datainit( );
	//	note( );
		
		while( nextb(R) == 0 && nextb(L) == 0 && FLAG == 0){
			while( FLAG == 0 ){
				Lable = Ldrop( );
				
				Rable = Rdrop( );
				
				while( 1 ){
					delayp( );
					if( Lable != 0 ){
						Ljudge( );
						Lable = nextb( L );
					}
					if( Rable != 0 ){
						Rjudge( );
						Rable = nextb( R );
					}
					ldelay--;
					rdelay--;
					if( ldelay == 0 ){
						Lable = Ldrop( );
						ldelay = d[0];
					}
					if( rdelay == 0 ){
						Rable = Rdrop( );
						rdelay = d[0];
					}
					if( FLAG != 0 )
						break;
				}
				if( FLAG != 0 )
				break;
			}
			if( FLAG != 0 )
				break;
		}
		show( FLAG );
		
		c = getch( );
	}while( c!='n' && c!='N' ); 
	clrscr( );
	_setcursortype( _SOLIDCURSOR );
	
}


int		nextb( LRflag )
int		LRflag;
{
		if( LRflag == R ){
			if( Ra[(b[Rnext].y0)][(3+b[Rnext].x0)] != 0 ||
				Ra[(b[Rnext].y1)][(3+b[Rnext].x1)] != 0 ||
				Ra[(b[Rnext].y2)][(3+b[Rnext].x2)] != 0 ||
				Ra[(b[Rnext].y3)][(3+b[Rnext].x3)] != 0  ){
					FLAG = R;
					return( -1 );
			}
			eraseb( 0, 71, 5, Rnext );
			Rcurrent = Rnext;
			rx = 3;
			ry = 0;
			Rable = 0;
			rdelay = d[0];
			Rsum ++;
			Rpoint += 1;
			Rnext = random( 26 );
			if( Rnext==23 )					Rnext = 0;
			if( Rnext==24 || Rnext==25 )	Rnext = 2;
			dispb( 0, 71, 5, Rnext );
		}else{
			if( La[(b[Lnext].y0)][(3+b[Lnext].x0)] != 0 ||
				La[(b[Lnext].y1)][(3+b[Lnext].x1)] != 0 ||
				La[(b[Lnext].y2)][(3+b[Lnext].x2)] != 0 ||
				La[(b[Lnext].y3)][(3+b[Lnext].x3)] != 0  ){
					FLAG = L;
					return( -1 );
			}
			eraseb( 0, 3, 5, Lnext );
			Lcurrent = Lnext;
			lx = 3;
			ly = 0;
			Lable = 0;
			ldelay = d[0];
			Lsum ++;
			Lpoint += 1;
			Lnext = random( 26 );
			if( Lnext==23 )					Lnext = 0;
			if( Lnext==24 || Lnext==25 )	Lnext = 2;
			dispb( 0, 3, 5, Lnext );
		}
		
		textcolor( 7 );
		gotoxy( 3, 14 );	cprintf( "%#5d", Lsum );
		gotoxy( 3, 17 );	cprintf( "%#5d", Lpoint );
		gotoxy( 72, 14 );	cprintf( "%#5d", Rsum );
		gotoxy( 72, 17 );	cprintf( "%#5d", Rpoint );
		
		return( 0 );
}


void	delayp( )
{
	char	key;
	
		if( kbhit( ) != 0 ){
			key = getch( );
	 			move( key );
	 		if( key== '\\' )
	 			getch( );
	 		if( key== 'b' )
	 			bell ^= 1;
	 	}
}


void	move( funckey )
char	funckey;
{
	int		tempcode;
	switch( funckey ){
		case '4':
		case 'p': if( rx+b[Rcurrent].x0 > 0 )
					if( Ra[ry+(b[Rcurrent].y0)][rx-1+(b[Rcurrent].x0)]==0 &&
						Ra[ry+(b[Rcurrent].y1)][rx-1+(b[Rcurrent].x1)]==0 &&
						Ra[ry+(b[Rcurrent].y2)][rx-1+(b[Rcurrent].x2)]==0 &&
						Ra[ry+(b[Rcurrent].y3)][rx-1+(b[Rcurrent].x3)]==0 ){
						  eraseb( R, rx, ry, Rcurrent );
						  rx --;
						  dispb( R, rx, ry, Rcurrent );
					}
				  break;
		case '5':
		case '@': tempcode = b[Rcurrent].next;
				  if( rx+b[tempcode].x0 >= 0 && rx+b[tempcode].x3 <= 9 &&
				  	  ry+b[tempcode].y1 <=19 && ry+b[tempcode].y2 <= 19 )
				  	if( routejudge( R ) != -1 )
						if( Ra[ry+(b[tempcode].y0)][rx+(b[tempcode].x0)]==0 &&
							Ra[ry+(b[tempcode].y1)][rx+(b[tempcode].x1)]==0 &&
							Ra[ry+(b[tempcode].y2)][rx+(b[tempcode].x2)]==0 &&
							Ra[ry+(b[tempcode].y3)][rx+(b[tempcode].x3)]==0 ){
						  eraseb( R, rx, ry, Rcurrent );
						  Rcurrent = tempcode;
						  dispb( R, rx, ry, Rcurrent );
					}
				  break;
		case '6':
		case '[': if( rx+b[Rcurrent].x3 < 9 )
					if( Ra[ry+(b[Rcurrent].y0)][rx+1+(b[Rcurrent].x0)]==0 &&
						Ra[ry+(b[Rcurrent].y1)][rx+1+(b[Rcurrent].x1)]==0 &&
						Ra[ry+(b[Rcurrent].y2)][rx+1+(b[Rcurrent].x2)]==0 &&
						Ra[ry+(b[Rcurrent].y3)][rx+1+(b[Rcurrent].x3)]==0 ){
						  eraseb( R, rx, ry, Rcurrent );
						  rx ++;
						  dispb( R, rx, ry, Rcurrent );
					}
				  break;
		case '0':
		case ',': throw( R );
				  break;
		
		case '�':
		case 'a': if( lx+b[Lcurrent].x0 > 0 )
					if( La[ly+(b[Lcurrent].y0)][lx-1+(b[Lcurrent].x0)]==0 &&
						La[ly+(b[Lcurrent].y1)][lx-1+(b[Lcurrent].x1)]==0 &&
						La[ly+(b[Lcurrent].y2)][lx-1+(b[Lcurrent].x2)]==0 &&
						La[ly+(b[Lcurrent].y3)][lx-1+(b[Lcurrent].x3)]==0 ){
						  eraseb( L, lx, ly, Lcurrent );
						  lx --;
						  dispb( L, lx, ly, Lcurrent );
					}
				  break;
		case '�':
		case 's': tempcode = b[Lcurrent].next;
				  if( lx+b[tempcode].x0 >= 0 && lx+b[tempcode].x3 <= 9 &&
				  	  ly+b[tempcode].y1 <=19 && ly+b[tempcode].y2 <= 19 )
				  	  if( routejudge( L ) != -1 )
						if( La[ly+(b[tempcode].y0)][lx+(b[tempcode].x0)]==0 &&
							La[ly+(b[tempcode].y1)][lx+(b[tempcode].x1)]==0 &&
							La[ly+(b[tempcode].y2)][lx+(b[tempcode].x2)]==0 &&
							La[ly+(b[tempcode].y3)][lx+(b[tempcode].x3)]==0 ){
						  eraseb( L, lx, ly, Lcurrent );
						  Lcurrent = tempcode;
						  dispb( L, lx, ly, Lcurrent );
					}
				  break;
		case '�':
		case 'd': if( lx+b[Lcurrent].x3 < 9 )
					if( La[ly+(b[Lcurrent].y0)][lx+1+(b[Lcurrent].x0)]==0 &&
						La[ly+(b[Lcurrent].y1)][lx+1+(b[Lcurrent].x1)]==0 &&
						La[ly+(b[Lcurrent].y2)][lx+1+(b[Lcurrent].x2)]==0 &&
						La[ly+(b[Lcurrent].y3)][lx+1+(b[Lcurrent].x3)]==0 ){
						  eraseb( L, lx, ly, Lcurrent );
						  lx ++;
						  dispb( L, lx, ly, Lcurrent );
					}
				  break;
		case '�':
		case 'q': throw( L );
				  break;
		
		case 0x1b:	clrscr( );
					_setcursortype( _SOLIDCURSOR );
					exit(0);
					break;
		default:	break;
	}
	
}


void	throw( LRflag )
int		LRflag;
{
	int		tempy;
	
	if( LRflag == L ){
		tempy = ly;
		while(  ly+b[Lcurrent].y1 < 19 && ly+b[Lcurrent].y2 < 19 &&
				La[ly+(b[Lcurrent].y0)][lx+(b[Lcurrent].x0)]==0 &&
				La[ly+(b[Lcurrent].y1)][lx+(b[Lcurrent].x1)]==0 &&
				La[ly+(b[Lcurrent].y2)][lx+(b[Lcurrent].x2)]==0 &&
				La[ly+(b[Lcurrent].y3)][lx+(b[Lcurrent].x3)]==0 )
			ly++;
		ly--;
		eraseb( L, lx, tempy, Lcurrent );
		dispb( L, lx, ly, Lcurrent );
		La[ly+(b[Lcurrent].y0)][lx+(b[Lcurrent].x0)] =
		La[ly+(b[Lcurrent].y1)][lx+(b[Lcurrent].x1)] =
		La[ly+(b[Lcurrent].y2)][lx+(b[Lcurrent].x2)] =
		La[ly+(b[Lcurrent].y3)][lx+(b[Lcurrent].x3)] = b[Lcurrent].color;
		Lable = -1;
	}else{
		tempy = ry;
		while(  ry+b[Rcurrent].y1 < 19 && ry+b[Rcurrent].y2 < 19 &&
				Ra[ry+(b[Rcurrent].y0)][rx+(b[Rcurrent].x0)]==0 &&
				Ra[ry+(b[Rcurrent].y1)][rx+(b[Rcurrent].x1)]==0 &&
				Ra[ry+(b[Rcurrent].y2)][rx+(b[Rcurrent].x2)]==0 &&
				Ra[ry+(b[Rcurrent].y3)][rx+(b[Rcurrent].x3)]==0 )
			ry++;
		ry--;
		eraseb( R, rx, tempy, Rcurrent );
		dispb( R, rx, ry, Rcurrent );
		Ra[ry+(b[Rcurrent].y0)][rx+(b[Rcurrent].x0)] =
		Ra[ry+(b[Rcurrent].y1)][rx+(b[Rcurrent].x1)] =
		Ra[ry+(b[Rcurrent].y2)][rx+(b[Rcurrent].x2)] =
		Ra[ry+(b[Rcurrent].y3)][rx+(b[Rcurrent].x3)] = b[Rcurrent].color;
		Rable = -1;
	}
}


int		routejudge( LRflag )
int		LRflag;
{
		int		i, j;
		if( LRflag == L ){
			for( i=0;i<3;i++ )
				for( j=0;j<3;j++ )
					if( La[ly+i][lx+j] != 0 )
						return( -1 );
		}else{
			for( i=0;i<3;i++ )
				for( j=0;j<3;j++ )
					if( Ra[ry+i][rx+j] != 0 )
						return( -1 );
		}
		return( 1 );
}


int		Ldrop( )
{
		if( ly+b[Lcurrent].y1 >= 18 || ly+b[Lcurrent].y2 >= 18 ){
			La[ly+(b[Lcurrent].y0)][lx+(b[Lcurrent].x0)] =
			La[ly+(b[Lcurrent].y1)][lx+(b[Lcurrent].x1)] =
			La[ly+(b[Lcurrent].y2)][lx+(b[Lcurrent].x2)] =
			La[ly+(b[Lcurrent].y3)][lx+(b[Lcurrent].x3)] = b[Lcurrent].color;
			return( -1 );
		}
		if(	La[ly+1+(b[Lcurrent].y0)][lx+(b[Lcurrent].x0)]!=0 ||
			La[ly+1+(b[Lcurrent].y1)][lx+(b[Lcurrent].x1)]!=0 ||
			La[ly+1+(b[Lcurrent].y2)][lx+(b[Lcurrent].x2)]!=0 ||
			La[ly+1+(b[Lcurrent].y3)][lx+(b[Lcurrent].x3)]!=0 ){
				La[ly+(b[Lcurrent].y0)][lx+(b[Lcurrent].x0)]=
				La[ly+(b[Lcurrent].y1)][lx+(b[Lcurrent].x1)]=
				La[ly+(b[Lcurrent].y2)][lx+(b[Lcurrent].x2)]=
				La[ly+(b[Lcurrent].y3)][lx+(b[Lcurrent].x3)]=b[Lcurrent].color;
				return( -1 );
		}
		eraseb( L, lx, ly, Lcurrent );
		dispb( L, lx, ++ly, Lcurrent );
		return( 0 );
}


int		Rdrop( )
{
		if( ry+b[Rcurrent].y1 >= 18 || ry+b[Rcurrent].y2 >= 18 ){
			Ra[ry+(b[Rcurrent].y0)][rx+(b[Rcurrent].x0)] =
			Ra[ry+(b[Rcurrent].y1)][rx+(b[Rcurrent].x1)] =
			Ra[ry+(b[Rcurrent].y2)][rx+(b[Rcurrent].x2)] =
			Ra[ry+(b[Rcurrent].y3)][rx+(b[Rcurrent].x3)] = b[Rcurrent].color;
			return( -1 );
		}
		if(	Ra[ry+1+(b[Rcurrent].y0)][rx+(b[Rcurrent].x0)]!=0 ||
			Ra[ry+1+(b[Rcurrent].y1)][rx+(b[Rcurrent].x1)]!=0 ||
			Ra[ry+1+(b[Rcurrent].y2)][rx+(b[Rcurrent].x2)]!=0 ||
			Ra[ry+1+(b[Rcurrent].y3)][rx+(b[Rcurrent].x3)]!=0 ){
				Ra[ry+(b[Rcurrent].y0)][rx+(b[Rcurrent].x0)]=
				Ra[ry+(b[Rcurrent].y1)][rx+(b[Rcurrent].x1)]=
				Ra[ry+(b[Rcurrent].y2)][rx+(b[Rcurrent].x2)]=
				Ra[ry+(b[Rcurrent].y3)][rx+(b[Rcurrent].x3)]=b[Rcurrent].color;
				return( -1 );
		}
		eraseb( R, rx, ry, Rcurrent );
		dispb( R, rx, ++ry, Rcurrent );
		return( 0 );
}


int		Rjudge(  )
{
	int		i, j, k,lines, f, codebuffer[4][10];
	int		ii, jj, kk, ll;
	static int	p[5]={ 0,1,3,6,10 };
	char	buffer[4][20*4];

	lines = 0;
	for( k=0; k<=3; k++ ){
		f = 0;
		if( (ry+k)>18 )
			continue;
		for( i=0; i<10; i++ )
			if( Ra[ry+k][i]==0 ){
				f++;
				break;
			}
		if( f == 0 ){
			for( j=0; j<10; j++ )
				codebuffer[lines][j] = Ra[ry+k][j];
			if( b[Rcurrent].y0 == k ){
				gotoxy( RX+2*(rx+b[Rcurrent].x0), RY+k+ry );
				cputs( "  " );
				codebuffer[lines][rx+b[Rcurrent].x0] = 0;
			}
			if( b[Rcurrent].y1 == k ){
				gotoxy( RX+2*(rx+b[Rcurrent].x1), RY+k+ry );
				cputs( "  " );
				codebuffer[lines][rx+b[Rcurrent].x1] = 0;
			}
			if( b[Rcurrent].y2 == k ){
				gotoxy( RX+2*(rx+b[Rcurrent].x2), RY+k+ry );
				cputs( "  " );
				codebuffer[lines][rx+b[Rcurrent].x2] = 0;
			}
			if( b[Rcurrent].y3 == k ){
				gotoxy( RX+2*(rx+b[Rcurrent].x3), RY+k+ry );
				cputs( "  " );
				codebuffer[lines][rx+b[Rcurrent].x3] = 0;
			}
			gettext( RX, RY+ry+k, RX+19, RY+ry+k , &buffer[lines][0] );
			movetext( RX, RY, RX+19, RY+ry+k-1, RX, RY+1 );
			for( i=(ry+k); i>0; i-- )
				for( j=0; j<10; j++ )
					Ra[i][j] = Ra[i-1][j];
			for( j=0; j<10; j++ )
				Ra[0][j] = 0;
			lines ++;
		}
	}
	if( lines >= 2 ){
		if( bell )	putchar( 7 );
		for( ii=0; ii<10; ii++ )
			if( La[lines-1][ii] != 0 ){
				Lable = -1;
				FLAG = L;
				return( 0 );
			}
		eraseb( L, lx, ly, Lcurrent );
		for( ii=0; ii<(19-lines); ii++ )
			for( jj=0; jj<10; jj++ )
				La[ii][jj] = La[ii+lines][jj];
		movetext( LX, lines+LY, LX+19, LY+18, LX, LY );

		for( ii=(19-lines); ii<19; ii++ ){
			ll = ii+lines-19;
			for( jj=0; jj<10; jj++ )
				La[ii][jj] = codebuffer[ll][jj];
			puttext( LX, LY+ii, LX+19, LY+ii, &buffer[ll][0] );
		}
		Lable = -1;
	}
	Rpoint += p[lines]*10;
	return( 0 );

}


int		Ljudge(  )
{
	int		i, j, k,lines, f, codebuffer[4][10];
	int		ii, jj, kk, ll;
	static int	p[5]={ 0,1,3,6,10 };
	char	buffer[4][20*4];
	
	lines = 0;
	for( k=0; k<=3; k++ ){
		f = 0;
		if( (ly+k)>18 )
			continue;
		for( i=0; i<10; i++ )
			if( La[ly+k][i]==0 ){
				f++;
				break;
			}
		if( f == 0 ){
			for( j=0; j<10; j++ )
				codebuffer[lines][j] = La[ly+k][j];
			if( b[Lcurrent].y0 == k ){
				gotoxy( LX+2*(lx+b[Lcurrent].x0), LY+k+ly );
				cputs( "  " );
				codebuffer[lines][lx+b[Lcurrent].x0] = 0;
			}
			if( b[Lcurrent].y1 == k ){
				gotoxy( LX+2*(lx+b[Lcurrent].x1), LY+k+ly );
				cputs( "  " );
				codebuffer[lines][lx+b[Lcurrent].x1] = 0;
			}
			if( b[Lcurrent].y2 == k ){
				gotoxy( LX+2*(lx+b[Lcurrent].x2), LY+k+ly );
				cputs( "  " );
				codebuffer[lines][lx+b[Lcurrent].x2] = 0;
			}
			if( b[Lcurrent].y3 == k ){
				gotoxy( LX+2*(lx+b[Lcurrent].x3), LY+k+ly );
				cputs( "  " );
				codebuffer[lines][lx+b[Lcurrent].x3] = 0;
			}
			gettext( LX, LY+ly+k, LX+19, LY+ly+k , &buffer[lines][0] );
			movetext( LX, LY, LX+19, LY+ly+k-1, LX, LY+1 );
			for( i=(ly+k); i>0; i-- )
				for( j=0; j<10; j++ )
					La[i][j] = La[i-1][j];
			for( j=0; j<10; j++ )
				La[0][j] = 0;
			lines ++;
		}
	}
	if( lines >= 2 ){
		if( bell )	putchar( 7 );
		for( ii=0; ii<10; ii++ )
			if( Ra[lines-1][ii] != 0 ){
				Rable = -1;
				FLAG = R;
				return( 0 );
			}
		eraseb( R, rx, ry, Rcurrent );
		for( ii=0; ii<(19-lines); ii++ )
			for( jj=0; jj<10; jj++ )
				Ra[ii][jj] = Ra[ii+lines][jj];
		movetext( RX, lines+RY, RX+19, RY+18, RX, RY );

		for( ii=(19-lines); ii<19; ii++ ){
			ll = ii+lines-19;
			for( jj=0; jj<10; jj++ )
				Ra[ii][jj] = codebuffer[ll][jj];
			puttext( RX, RY+ii, RX+19, RY+ii, &buffer[ll][0] );
		}
		Rable = -1;
	}
	Lpoint += p[lines]*10;
	return( 0 );

}


void	note( )
{
}


void	show( LRflag )
int		LRflag;
{
	int		i, j;
	if( LRflag == R ){
		for( i=18; i>=0; i-- )
			for( j=0;j<10; j++ ){
				gotoxy( LX+j*2, LY+i );
				if( La[i][j] != 0 )
					cputs( "��" );
			}
		gotoxy( 39, 9 );
		cputs( "left" );
		gotoxy( 39, 11 );
		cputs( "win!" );
		gotoxy( 19, 12 );
		cputs( "  you  win!! " );
		gotoxy( 51, 12 );
		cputs( " end of game!" );
	}else{
		for( i=18; i>=0; i-- )
			for( j=0;j<10; j++ ){
				gotoxy( RX+j*2, RY+i );
				if( Ra[i][j] != 0 )
					cputs( "��" );
			}
		gotoxy( 39, 9 );
		cputs( "right" );
		gotoxy( 39, 11 );
		cputs( "win! " );
		gotoxy( 19, 12 );
		cputs( " end of game!" );
		gotoxy( 51, 12 );
		cputs( " you  win !  " );
	}
	while( getch( )!='\r' );
	gotoxy( 38, 16 );
	cputs( "again?" );

}


void	scrinit( )
{
	int		i;
	char	lft[20],rght[20];

	_setcursortype( _NOCURSOR );

	textbackground(1);
	clrscr( );
	gotoxy( 30,9 );
	cputs( "ENTER YOUR NAMES:" );
	gotoxy( 25,14 );
	cputs( "LEFT ONE:    ");
	scanf( "%s",lft );
	gotoxy( 25,16 );
	cputs( "RIGHT ONE:   ");
	scanf( "%s",rght );
	textbackground(0);
	clrscr( );
	textcolor( 15 );
	gotoxy( 17, 1 );
	cprintf( "%s",lft );
	gotoxy( 53,1 );
	cprintf( "%s",rght );
	gotoxy( 5, 3 );
	cputs( "NEXT" );
	gotoxy( 72,3 );
	cputs( "NEXT" );
	gotoxy( 4, 13 );
	cputs( "block" );
	gotoxy( 4, 16 );
	cputs( "point" );
	gotoxy( 73, 13 );
	cputs( "block" );
	gotoxy( 73, 16 );
	cputs( "point" );
	for( i=0; i<19; i++ ){
		gotoxy( LX-2, LY+i );
		cputs( "��                    ��" );
		gotoxy( RX-2, RY+i );
		cputs( "��                    ��" );
	}
	gotoxy( LX-2, LY+19 );
	cputs( "������������������������" );
	gotoxy( RX-2, RY+19 );
	cputs( "������������������������" );

}


void	datainit( )
{
	int		i,j;
	for( i=0; i<19; i++ )
		for( j=0; j<10; j++ ){
			La[i][j]=0;
			Ra[i][j]=0;
		}
	Lable = 0;
	Rable = 0;
	FLAG = 0;
	bell = 1;
	ldelay = rdelay = d[0];
	Lsum = Rsum = 0;
	Lpoint = Rpoint = 0;
	randomize( );
	Lnext = random( 26 );
	if( Lnext==23 )					Lnext = 0;
	if( Lnext==24 || Lnext==25 )	Lnext = 2;
	Rnext = random( 26 );
	if( Rnext==23 )					Rnext = 0;
	if( Rnext==24 || Rnext==25 )	Rnext = 2;
}


void	dispb( LRflag, x, y, blockcode )			/* display blocks */
int		LRflag, x, y, blockcode;
{
		int		realx, realy;
		
		if( LRflag == R ){
			realx = RX+x*2;
			realy = RY+y;
		}else if( LRflag == L ){
			realx = LX+x*2;
			realy = LY+y;
		}else{
			realx = x;
			realy = y;
		}
		textcolor( b[blockcode].color );
		gotoxy( realx+2*b[blockcode].x0, realy+b[blockcode].y0 ); cputs("��");
		gotoxy( realx+2*b[blockcode].x1, realy+b[blockcode].y1 ); cputs("��");
		gotoxy( realx+2*b[blockcode].x2, realy+b[blockcode].y2 ); cputs("��");
		gotoxy( realx+2*b[blockcode].x3, realy+b[blockcode].y3 ); cputs("��");
}


void	eraseb( LRflag, x, y, blockcode )			/* erase blocks */
int		LRflag, x, y, blockcode;
{
		int		realx, realy;

		if( LRflag == R ){
			realx = RX+x*2;
			realy = RY+y;
		}else if( LRflag == L ){
			realx = LX+x*2;
			realy = LY+y;
		}else{
			realx = x;
			realy = y;
		}
		textcolor( 0 );
		gotoxy( realx+2*b[blockcode].x0, realy+b[blockcode].y0 ); cputs("��");
		gotoxy( realx+2*b[blockcode].x1, realy+b[blockcode].y1 ); cputs("��");
		gotoxy( realx+2*b[blockcode].x2, realy+b[blockcode].y2 ); cputs("��");
		gotoxy( realx+2*b[blockcode].x3, realy+b[blockcode].y3 ); cputs("��");
}


