// BotonSimon.cpp: implementation of the BotonSimon class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Simon.h"
#include "BotonSimon.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

BotonSimon::BotonSimon()
{
	prendido_DC=NULL;
	apagado_DC=NULL;
	region_mascara_h=NULL;
	sonido_ptr=NULL;
	recurso_sonido=NULL;
}

BotonSimon::~BotonSimon()
{
	if( prendido_DC != NULL )
		DeleteDC( prendido_DC );
	prendido.DeleteObject();
	if( apagado_DC != NULL )
		DeleteDC( apagado_DC );
	apagado.DeleteObject();
	if( region_mascara_h != NULL )
		DeleteObject( region_mascara_h );
	if( recurso_sonido != NULL )
	{
		UnlockResource(	recurso_sonido );
		FreeResource( recurso_sonido );
	}
	::DeleteObject( region_mascara_h );
} 

simon_error BotonSimon::Inicializar(int x_or,int y_or,HWND ventana_h,UINT recurso_prend,UINT recurso_apag, UINT recurso_mascara,UINT recurso_wav)
{
	BITMAP info_bmp;

	x=x_or;
	y=y_or;
	ventana_handle=ventana_h;
	prendido_DC=::CreateCompatibleDC( NULL );
	if( prendido_DC == NULL )
		return boton_simon_init_create_dc_error;
	if( !prendido.LoadBitmap( recurso_prend ) )
		return boton_simon_init_load_bitmap_error;
	::SelectObject( prendido_DC,prendido );
	if( prendido.GetBitmap( &info_bmp ) == 0 )
		return boton_simon_init_get_bitmap_error;
	ancho=info_bmp.bmWidth;
	alto=info_bmp.bmHeight;
	apagado_DC=::CreateCompatibleDC( NULL );
	if( apagado_DC == NULL )
		return boton_simon_init_create_dc_error;
	if(	!apagado.LoadBitmap( recurso_apag ) )
		return boton_simon_init_load_bitmap_error;
	::SelectObject( apagado_DC,apagado );
	ConversorBmp2Rgn conversor;
	region_mascara_h=conversor.Convertir( recurso_mascara );
	if( region_mascara_h == NULL )
		return boton_simon_init_convertir_mask_error;
	if( ::OffsetRgn( region_mascara_h,x,y ) == ERROR )
		return boton_simon_init_offset_rgn_error;
	if( !LeerSonido( recurso_wav ) )
		return boton_simon_init_leer_sonido_error;
	return ok;
}

bool BotonSimon::DibujarApretado()
{
	HDC wind_dc=NULL;
	int resultado=0;

	wind_dc=GetWindowDC( ventana_handle );
	if( wind_dc == NULL )
		return false;
	resultado=::ExtSelectClipRgn( wind_dc,region_mascara_h,RGN_COPY );
	if( resultado == ERROR )
		return false;
	if( !::BitBlt( wind_dc,x,y,ancho,alto,prendido_DC,0,0,SRCCOPY ) )
		return false;
	::ExtSelectClipRgn( wind_dc,NULL,RGN_COPY );
	ReleaseDC( ventana_handle,wind_dc );
	return true;
}


bool BotonSimon::DibujarSoltado(  )
{
	HDC wind_dc=NULL;
	int resultado=0;

	wind_dc=GetWindowDC( ventana_handle );
	if( wind_dc == NULL )
		return false;
	resultado=::ExtSelectClipRgn( wind_dc,region_mascara_h,RGN_COPY );
	if( resultado == ERROR )
		return false;
	if( !BitBlt( wind_dc,x,y,ancho,alto,apagado_DC,0,0,SRCCOPY ) )
		return false;
	::ExtSelectClipRgn( wind_dc,NULL,RGN_COPY );
	ReleaseDC( ventana_handle,wind_dc );
	return true;
}

bool BotonSimon::Apretar()
{
	if( !DibujarApretado() )
		return false;
	TocarSonido();
	return DibujarSoltado();
}

bool BotonSimon::ApretarTocando(LPSTR sonido_data)
{
	if( !DibujarApretado() )
		return false;
	if( !sndPlaySound( sonido_data,SND_MEMORY | SND_SYNC |SND_NODEFAULT ) )
		return false;
	return DibujarSoltado();
}

simon_error BotonSimon::Redibujar()
{
	HDC wind_dc=NULL;

	wind_dc=GetWindowDC( ventana_handle );
	if( wind_dc == NULL )
		return boton_simon_redibujar_getwdc_error;
	if( !BitBlt( wind_dc,x,y,ancho,alto,apagado_DC,0,0,SRCCOPY ) )
		return boton_simon_redibujar_biblt_error;
	ReleaseDC( ventana_handle,wind_dc );
	return ok;
}

bool BotonSimon::EstaAdentro(CPoint * punto)
{
	if( !::PtInRegion( region_mascara_h,punto->x,punto->y ) )
		return false;
	return true;
}

bool BotonSimon::TocarSonido() 
{ 
    if( !sndPlaySound( sonido_ptr,SND_MEMORY | SND_SYNC |SND_NODEFAULT ) )
		return false;
	return true;
} 


bool BotonSimon::LeerSonido(UINT recurso)
{
	HANDLE hResInfo=NULL;
	LPSTR lpRes=NULL;

	hResInfo = FindResource( AfxGetResourceHandle(),MAKEINTRESOURCE(recurso),"WAVE" );
	if( hResInfo == NULL )
		return false;
	recurso_sonido = LoadResource( AfxGetResourceHandle(),(HRSRC)hResInfo );
	if( recurso_sonido == NULL )
		return false;
	sonido_ptr=(LPSTR)LockResource( recurso_sonido );
	if( sonido_ptr == NULL )
		return false;
	return true;
}




