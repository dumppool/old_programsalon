// Jego.cpp: implementation of the Jego class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Simon.h"
#include "Juego.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Juego::Juego()
{
	keys_ptr = NULL;
	srand( (unsigned)time( NULL ) );
	avance=0;
	tiempo=0L;
}

Juego::~Juego()
{
	if( keys_ptr !=  NULL )
		delete [] keys_ptr;
}

bool Juego::Inicializar(int dif)
{
	dificultad=(dif*8)+1;
	//dificultad=4;
	keys_ptr=new int[dificultad];
	if( keys_ptr == NULL )
		return false;
	for( int i=0;i<dificultad;i++ )
	{
		if( i == 0 )
			keys_ptr[i]=NumeroAlAzar(0);
		else keys_ptr[i]=NumeroAlAzar( keys_ptr[i-1] );
	}
	tiempo=GetTickCount();
	return true;
}

int Juego::NumeroAlAzar( int anterior )
{
	int numero=0;

	numero=rand();
	numero=numero%4;
	if( numero == anterior )
		return NumeroAlAzar( anterior );
	return numero;
}

roll_over Juego::ProximoMovimiento(bool avanza)
{
	if( avanza )
		avance++;
	if( avance > dificultad )
		return gano;
	return Color( keys_ptr[avance] );
}

roll_over Juego::Color(int num)
{
	if( num == 0 )
		return verde;
	else if( num == 1 )
		return rojo;
	else if( num == 2 )
		return amarillo;
	else return azul;
}

roll_over Juego::MovimientoNumero(int i)
{
	return Color( keys_ptr[i] );
}

int Juego::Dificultad()
{
	return dificultad;
}

int Juego::CuantoDuroJuego()
{
	return (int) (GetTickCount() - tiempo)/1000;
}
