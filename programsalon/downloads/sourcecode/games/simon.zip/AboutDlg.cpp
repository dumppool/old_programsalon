// AboutDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Simon.h"
#include "AboutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// AboutDlg dialog


AboutDlg::AboutDlg(CWnd* pParent /*=NULL*/)
	: CDialog(AboutDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(AboutDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void AboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(AboutDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(AboutDlg, CDialog)
	//{{AFX_MSG_MAP(AboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// AboutDlg message handlers

BOOL AboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CString texto;

	texto+="Simon 1.0 R5. by Fernando Lagos\r\n\r\nwau@satlink.com\r\nhttp://members.xoom.com/lakes\r\n\n";
	texto+="This program is FREEWARE, you can distribute it without any limit.\r\n\r\nSimon is a trade mark of TopToys.\r\n\r\n";
	texto+="Aguante Foo Fighters !!!";
	SetDlgItemText(ID_TEXTO_ABOUT,LPCTSTR(texto) );
	return TRUE;
}


