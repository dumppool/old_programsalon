#define K_ANCHO_VENTANA 390
#define K_LARGO_VENTANA 390

#define K_TIMER_ESPERA	1
#define K_TIMER_INTER_BOTON	2
#define K_TIMER_REPLAY	3

typedef enum roll_over{
	verde,
	rojo,
	amarillo,
	azul,
	last,
	play,
	scores,
	dificultad,
	on_off,
	nada,
	gano
};

typedef struct puntaje{
	char nombre[30];
	char fecha[30];
	int	tiempo;
}puntaje;

typedef struct puntajes{
	puntaje score_1;
	puntaje score_2;
	puntaje score_3;
	puntaje score_4;
	puntaje score_5;
}puntajes;

typedef enum simon_error{
	mem_error=0,
	c_dialog_create_error,
	cambiar_forma_ventana_1,
	cambiar_forma_ventana_2,
	cambiar_forma_ventana_3,
	cambiar_forma_ventana_4,
	prep_reg_drag_window_error,
	load_cursor_mano_error,
	load_cursor_comun_error,
	levantar_cur_directory_error,


	boton_simon_init_create_dc_error,
	boton_simon_init_load_bitmap_error,
	boton_simon_init_get_bitmap_error,
	boton_simon_init_convertir_mask_error,
	boton_simon_init_offset_rgn_error,
	boton_simon_init_leer_sonido_error,
	boton_simon_redibujar_getwdc_error,
	boton_simon_redibujar_biblt_error,


	boton_init_create_dc_error,
	boton_init_load_bitmap_error,
	boton_init_get_bitmap_error,
	boton_init_create_elliptic_rgn_error,
	boton_init_create_solid_brush,
	boton_redibujar_getwdc_error,
	boton_redibujar_extselectcliprgn_error,
	boton_redibujar_bitblt_error,


	slider_init_create_dc_error,
	slider_init_load_bitmap_error,
	slider_init_componer_region_error,
	slider_init_offset_rgn_error,
	slider_init_leer_sonido_error,
	slider_init_crear_region_apreto,
	slider_redibujar_origen_region_1_error,
	slider_redibujar_origen_region_2_error,
	slider_redibujar_getwdc_error,
	slider_redibujar_bitblt_1_error,
	slider_redibujar_create_rect_rgn_error,
	slider_redibujar_combine_rgn_error,
	slider_redibujar_ext_select_clip_rgn,
	slider_redibujar_bitblt_2_error,





	sonido_init_find_resource_error,
	sonido_init_load_resource_error,
	sonido_init_lock_resource_error,


	ok
};