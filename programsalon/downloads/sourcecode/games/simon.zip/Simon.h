// Simon.h : main header file for the SIMON application
//

#if !defined(AFX_SIMON_H__BD49A451_52DE_11D2_807F_006097E57760__INCLUDED_)
#define AFX_SIMON_H__BD49A451_52DE_11D2_807F_006097E57760__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSimonApp:
// See Simon.cpp for the implementation of this class
//

#include "SimonDlg.h"

class CSimonApp : public CWinApp
{
public:
	CSimonApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimonApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSimonApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void MostrarError(simon_error error);
	CSimonDlg * simon_dlg_ptr;
	HWND ventana_handle;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMON_H__BD49A451_52DE_11D2_807F_006097E57760__INCLUDED_)
