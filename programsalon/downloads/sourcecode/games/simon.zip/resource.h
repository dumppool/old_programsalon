//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Simon.rc
//
#define IDD_SIMON_DIALOG                102
#define IDR_MAINFRAME                   128
#define ID_FONDO_BMP                    129
#define ID_PREND1_BMP                   130
#define ID_PREND2_BMP                   131
#define ID_PREND3_BMP                   132
#define ID_PREND4_BMP                   133
#define ID_APAG1_BMP                    134
#define ID_APAG2_BMP                    135
#define ID_APAG3_BMP                    136
#define ID_APAG4_BMP                    137
#define ID_MASK1_INVERTED_BMP           138
#define ID_MASK2_INVERTED_BMP           139
#define ID_MASK3_INVERTED_BMP           140
#define ID_MASK4_INVERTED_BMP           141
#define ID_MASK1_BMP                    142
#define ID_MASK2_BMP                    143
#define ID_MASK3_BMP                    144
#define ID_MASK4_BMP                    145
#define ID_BOTON_VERDE_BMP              146
#define ID_BOTON_AMARILLO_BMP           147
#define ID_BOTON_ROJO_BMP               148
#define ID_SLIDE_AZUL_BMP               149
#define ID_FONDO_SLIDE_AZUL_BMP         151
#define ID_SLIDE_ROJO_BMP               152
#define ID_FONDO_SLIDE_ROJO_BMP         153
#define ID_AMARILLO_WAV                 154
#define ID_AZUL_WAV                     155
#define ID_ROJO_WAV                     156
#define ID_VERDE_WAV                    157
#define ID_DESLIZ_WAV                   159
#define ID_CURSOR_MANO                  163
#define ID_GANO_WAV                     164
#define ID_PERDIO_WAV                   165
#define ID_SCORES_DLG                   166
#define ID_NAME_DLG                     167
#define ID_ABOUT_DLG                    168
#define ID_LAST_BUTTON                  1000
#define ID_PLAY_BUTTON                  1001
#define ID_SCORES_BUTTON                1002
#define IDC_CUSTOM1                     1004
#define ID_SOCORE_1_TXT                 1005
#define ID_SOCORE_2_TXT                 1006
#define ID_SOCORE_3_TXT                 1007
#define ID_SOCORE_4_TXT                 1008
#define ID_SOCORE_5_TXT                 1009
#define ID_NAME_TXT                     1010
#define ID_TEXTO_ABOUT                  1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        172
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
