// Boton.cpp: implementation of the Boton class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Simon.h"
#include "Boton.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Boton::Boton()
{
	prendido_DC=NULL;
	apretado=false;
}

Boton::~Boton()
{
	if( prendido_DC != NULL )
		DeleteDC( prendido_DC );
	prendido.DeleteObject();
	region.DeleteObject();
	pincel.DeleteObject();
}

simon_error Boton::Inicializar(HWND vent_h, UINT recurso_prend,int x_or, int y_or)	
{	
	BITMAP info_bmp;

	x=x_or;
	y=y_or;
	ventana_handle=vent_h;
	prendido_DC = ::CreateCompatibleDC( NULL );
	if( prendido_DC == NULL )
		return boton_init_create_dc_error;
	if( !prendido.LoadBitmap( recurso_prend ) )
		return boton_init_load_bitmap_error;
	::SelectObject( prendido_DC,HBITMAP( prendido ) );
	if( !prendido.GetBitmap( &info_bmp ) )
		return boton_init_get_bitmap_error;
	ancho=info_bmp.bmWidth;
	alto=info_bmp.bmHeight;
	if( !region.CreateEllipticRgn( x,y,x+ancho,y+alto ) )
		return boton_init_create_elliptic_rgn_error;
	if( !pincel.CreateSolidBrush( RGB(0,0,0) ) )
		return boton_init_create_solid_brush;
	return ok;
}

bool Boton::Soltar()
{
	if( apretado == true )
	{
		Redibujar();
		apretado=false;
	}
	return true;
}

bool Boton::Apretar()
{
	HDC wind_dc=NULL;

	if( apretado == false )
	{
		wind_dc=::GetWindowDC( ventana_handle );
		if( wind_dc == NULL )
			return false;
		if( !::FillRgn( wind_dc,HRGN( region ),HBRUSH( pincel ) ) )
			return false;
		ReleaseDC( ventana_handle,wind_dc );
		apretado=true;
	}
	return true;
}

bool Boton::EstaAdentro(CPoint * punto)
{
	if( !::PtInRegion( HRGN( region ),punto->x,punto->y ) )
		return false;
	return true;
}

simon_error Boton::Redibujar()
{
	HDC wind_dc=NULL;
	int result;

	wind_dc=::GetWindowDC( ventana_handle );
	if( wind_dc == NULL )
		return boton_redibujar_getwdc_error;
	result=::ExtSelectClipRgn( wind_dc,HRGN( region ),RGN_COPY );
	if( result == ERROR )
		return boton_redibujar_extselectcliprgn_error;
	if( !::BitBlt( wind_dc,x,y,ancho,alto,prendido_DC,0,0,SRCCOPY ) )
		return boton_redibujar_bitblt_error;
	::ExtSelectClipRgn( wind_dc,NULL,RGN_COPY );
	ReleaseDC( ventana_handle,wind_dc );
	return ok;
}
