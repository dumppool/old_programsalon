// Simon.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Simon.h"
#include "SimonDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimonApp

BEGIN_MESSAGE_MAP(CSimonApp, CWinApp)
	//{{AFX_MSG_MAP(CSimonApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimonApp construction

CSimonApp::CSimonApp()
{
	simon_dlg_ptr=NULL;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSimonApp object

CSimonApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CSimonApp initialization

BOOL CSimonApp::InitInstance()
{
	simon_error error;

	simon_dlg_ptr=new CSimonDlg;
	if( simon_dlg_ptr == NULL )
		return FALSE;
	error=simon_dlg_ptr->Crear();
	if( error != ok )
	{
		MostrarError(error);
		return FALSE;
	}
	m_pMainWnd=(CWnd*)simon_dlg_ptr;
	ventana_handle=simon_dlg_ptr->m_hWnd;
	return TRUE;
}




void CSimonApp::MostrarError(simon_error error)
{
	char buffer[20];
	CString mensaje;

	buffer[0]=0;
	mensaje+="Error # ";
	mensaje+=itoa( (int)error,buffer,10 );
	mensaje+=".";
	AfxMessageBox(LPCTSTR(mensaje));
}
