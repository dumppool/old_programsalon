// SimonDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Simon.h"
#include "SimonDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimonDlg dialog

CSimonDlg::CSimonDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSimonDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSimonDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	mouse_down=false;
}

void CSimonDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSimonDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSimonDlg, CDialog)
	//{{AFX_MSG_MAP(CSimonDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_NCHITTEST()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	ON_WM_RBUTTONDOWN()
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimonDlg message handlers

BOOL CSimonDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSimonDlg::OnPaint() 
{
	simon_error error;
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CPaintDC dc(this);
		error=Redibujar();
		if( error != ok )
			MostrarError( error );
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSimonDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

simon_error CSimonDlg::Crear()
{
	simon_error error;

	gano=true;
	juego_ptr=NULL;
	if( !CDialog::Create(IDD_SIMON_DIALOG,NULL ) )
		return c_dialog_create_error;
	CWnd::ShowWindow(SW_HIDE);
	error=CambiarFormaVentana();
	if( error != ok )
		return error;
	error=boton_verde.Inicializar( 0,0,m_hWnd,ID_PREND1_BMP,ID_APAG1_BMP,ID_MASK1_INVERTED_BMP,ID_VERDE_WAV );
	if( error != ok )
		return error;
	error=boton_rojo.Inicializar( 195,0,m_hWnd,ID_PREND2_BMP,ID_APAG2_BMP,ID_MASK2_INVERTED_BMP,ID_ROJO_WAV );
	if( error != ok )
		return error;
	error=boton_amarillo.Inicializar( 0,195,m_hWnd,ID_PREND3_BMP,ID_APAG3_BMP,ID_MASK3_INVERTED_BMP,ID_AMARILLO_WAV );
	if( error != ok )
		return error;
	error=boton_azul.Inicializar( 195,195,m_hWnd,ID_PREND4_BMP,ID_APAG4_BMP,ID_MASK4_INVERTED_BMP,ID_AZUL_WAV);
	if( error != ok )
		return error;
	error=boton_last.Inicializar( m_hWnd,ID_BOTON_VERDE_BMP,145,220 );
	if( error != ok )
		return error;
	error=boton_play.Inicializar( m_hWnd,ID_BOTON_ROJO_BMP,185,220 );
	if( error != ok )
		return error;
	error=boton_scores.Inicializar( m_hWnd,ID_BOTON_AMARILLO_BMP,225,220 );
	if( error != ok )
		return error;
	error=slider_dificultad.Inicializar( 146,187,m_hWnd,ID_FONDO_SLIDE_ROJO_BMP,ID_SLIDE_ROJO_BMP,4 );
	if( error != ok )
		return error;
	error=slider_on_off.Inicializar( 172,246,m_hWnd,ID_FONDO_SLIDE_AZUL_BMP,ID_SLIDE_AZUL_BMP,2 );
	if( error != ok )
		return error;
	if( !PrepararRegionDragWindow() )
		return prep_reg_drag_window_error;
	cursor_mano=NULL;
	cursor_mano=::LoadCursor(AfxGetInstanceHandle(), MAKEINTRESOURCE(ID_CURSOR_MANO));
	if( cursor_mano == NULL )
		return load_cursor_mano_error;
	cursor_comun=NULL;
	cursor_comun=LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW));
	if( cursor_comun == NULL )
		return load_cursor_comun_error;
	error=sonido_gana.Inicializar( ID_GANO_WAV );
	if( error != ok )
		return error;
	error=sonido_pierde.Inicializar( ID_PERDIO_WAV );
	if( error != ok )
		return error;
	if( !LevantarCurrentDirectory() )
		return levantar_cur_directory_error;
	CWnd::ShowWindow(SW_SHOW);
	CWnd::UpdateWindow();
	return ok;
}

BOOL CSimonDlg::PreTranslateMessage(MSG* pMsg) 
{
	if( pMsg->message==WM_KEYDOWN )
	{
		if( pMsg->wParam == 27)
		{
			Salir();
			return 1;
		}
		else if( pMsg->wParam == 13 )
			return 1;
	}
	return CDialog::PreTranslateMessage(pMsg);
}

void CSimonDlg::Salir()
{
	region_drag_window.DeleteObject();
	if( juego_ptr != NULL )
		delete juego_ptr;
	DestroyCursor(cursor_mano);
	CWnd::DestroyWindow();
	region_ventana_redonda.DeleteObject();
}

simon_error CSimonDlg::CambiarFormaVentana()
{
	CRgn region;
	CRect borde;

	this->GetWindowRect( &borde );
	if( !region_ventana_redonda.CreateEllipticRgn( 0,0,K_ANCHO_VENTANA,K_LARGO_VENTANA ) )
		return cambiar_forma_ventana_3;
	if( this->SetWindowRgn( HRGN(region_ventana_redonda) ,FALSE ) == 0)
		return cambiar_forma_ventana_4;
	return ok;
}

simon_error CSimonDlg::Redibujar()
{
	simon_error error;

	error=boton_verde.Redibujar();
	if( error != ok )
		return error;
	error=boton_rojo.Redibujar();
	if( error != ok )
		return error;
	error=boton_amarillo.Redibujar();
	if( error != ok )
		return error;
	error=boton_azul.Redibujar();
	if( error != ok )
		return error;
	error=boton_last.Redibujar();
	if( error != ok )
		return error;
	error=boton_play.Redibujar();
	if( error != ok )
		return error;
	error=boton_scores.Redibujar();
	if( error != ok )
		return error;
	error=slider_dificultad.Redibujar();
	if( error != ok )
		return error;
	return slider_on_off.Redibujar();
}

UINT CSimonDlg::OnNcHitTest(CPoint point) 
{
	ScreenToClient( &point );
	if( ::PtInRegion( region_drag_window,point.x,point.y ) )
		return HTCAPTION;
	ClientToScreen( &point );
	return CDialog::OnNcHitTest(point);
}

void CSimonDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	mouse_down=true;
	SetCapture();
	if( boton_verde.EstaAdentro( &point ) )
		ApretoBotonJuego(verde);
	else if( boton_rojo.EstaAdentro( &point ) )
		ApretoBotonJuego(rojo);
	else if( boton_amarillo.EstaAdentro( &point ) )
		ApretoBotonJuego(amarillo);
	else if( boton_azul.EstaAdentro( &point ) )
		ApretoBotonJuego(azul);
	else if( boton_last.EstaAdentro( &point ) )
		boton_last.Apretar();
	else if( boton_play.EstaAdentro( &point ) )
		boton_play.Apretar();
	else if( boton_scores.EstaAdentro( &point ) )
		boton_scores.Apretar();
	else if( slider_dificultad.Apreto( &point ) )
	{
	}
	else if( slider_on_off.Apreto( &point ) )
	{
	}
}

void CSimonDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{

	if( mouse_down == true )
	{
		mouse_down=false;
		::ReleaseCapture();
		if( boton_last.EstaAdentro( &point ) )
		{
			boton_last.Soltar();
			BotonLast();
		}
		else if( boton_play.EstaAdentro( &point ) )
		{
			boton_play.Soltar();
			BotonPlay();
		}
		else if( boton_scores.EstaAdentro( &point ) )
		{
			boton_scores.Soltar();
			BotonScores();
		}
		else if( slider_dificultad.EstaAdentro( &point ) )
		{
			slider_dificultad.SoltarSin();
		}
		else if( slider_on_off.EstaAdentro( &point ) )
		{
			slider_on_off.SoltarSin();
			if( slider_on_off.Value() == 1 )
				Salir();
		}
	}
}

void CSimonDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	roll_over sobre=nada;
	
	sobre=SobreDondeEsta( &point );
	if( sobre == nada )
		SetCursor(cursor_comun);
	else SetCursor( cursor_mano );
	if( mouse_down == true )
	{
		if( !nFlags & MK_LBUTTON)
			return;
		if( slider_dificultad.Trackear(&point) )
		{
		}
		else if( slider_on_off.Trackear(&point) )
		{
		}
		if( sobre == last )
			boton_last.Apretar();
		else
			boton_last.Soltar();
		if( sobre == play )
			boton_play.Apretar();
		else
			boton_play.Soltar();
		if( sobre == scores )
			boton_scores.Apretar();
		else
			boton_scores.Soltar();
	}
}



bool CSimonDlg::PrepararRegionDragWindow()
{
	CRgn region_gde,region_chica;

	if( !region_gde.CreateRectRgn( 0,0,390,390 ) )
		return false;
	if( !region_chica.CreateEllipticRgn( 7,7,377,377 ) )
		return false;
	if( !region_drag_window.CreateRectRgn(1,1,5,5) )
		return false;
	if( ::CombineRgn( HRGN(region_drag_window),HRGN(region_gde),HRGN(region_chica),RGN_DIFF) == ERROR )
		return false;
	region_gde.DeleteObject();
	region_chica.DeleteObject();
	RECT b;
	region_drag_window.GetRgnBox( &b );
	return true;
}

roll_over CSimonDlg::SobreDondeEsta(CPoint * punto)
{
	if( boton_verde.EstaAdentro( punto ) )
		return verde;
	else if( boton_rojo.EstaAdentro( punto ) )
		return rojo;
	else if( boton_amarillo.EstaAdentro( punto ) )
		return amarillo;
	else if( boton_azul.EstaAdentro( punto ) )
		return azul;
	else if( boton_last.EstaAdentro( punto ) )
		return last;
	else if( boton_play.EstaAdentro( punto ) )
		return play;
	else if( boton_scores.EstaAdentro( punto ) )
		return scores;
	else if( slider_dificultad.EstaAdentro( punto ) )
		return dificultad;
	else if( slider_on_off.EstaAdentro( punto ) )
		return on_off;
	else return nada;
}

void CSimonDlg::BotonLast()
{
	if( juego_ptr != NULL )
	{
		avance_inter_boton=0;
		ReplayJuego();
	}
}

void CSimonDlg::BotonScores()
{
	ScoresDlg dlg;
	
	dlg.MostrarScores(directory_app,slider_dificultad.Value() );
}

void CSimonDlg::BotonPlay()
{
	gano=false;
	avance=0;
	avance_usuario=0;
	avance_inter_boton=0;
	if( juego_ptr != NULL )
	{
		delete juego_ptr;
		juego_ptr=NULL;
	}
	juego_ptr=new Juego;
	juego_ptr->Inicializar( slider_dificultad.Value() + 1 );
	avance++;
	MostrarJuego();
}

void CSimonDlg::OnTimer(UINT nIDEvent) 
{
	if( nIDEvent == K_TIMER_INTER_BOTON )
	{
		KillTimer( K_TIMER_INTER_BOTON );
		MostrarJuego();
	}
	else if( nIDEvent == K_TIMER_REPLAY )
	{
		KillTimer( K_TIMER_REPLAY );
		ReplayJuego();
	}
	else
	{
		KillTimer( K_TIMER_ESPERA );
		MostrarBotonCorrecto();
	}
}

void CSimonDlg::ApretoBotonJuego(roll_over color)
{
	if( gano == true )
	{
		BotonSegunColor( color )->Apretar();
	}
	else
	{
		MatarTimer(K_TIMER_ESPERA);
		if( color == juego_ptr->MovimientoNumero(avance_usuario) )
		{
			BotonSegunColor( color )->Apretar();
			avance_usuario++;
			if( avance_usuario == avance )
			{
				avance++;
				if( avance == juego_ptr->Dificultad() +1  )
				{
					gano=true;
					Ganar();
					return;
				}
				avance_usuario=0;
				avance_inter_boton=0;
				InstalarTimer( K_TIMER_INTER_BOTON,1);
			}
		}
		else MostrarBotonCorrecto();
	}
}

BotonSimon * CSimonDlg::BotonSegunColor(roll_over color)
{
	if( color == verde )
		return &boton_verde;
	else if( color == rojo )
		return &boton_rojo;
	else if( color == amarillo )
		return &boton_amarillo;
	return &boton_azul;
}

void CSimonDlg::MostrarJuego()
{
	if( avance_inter_boton<avance )
	{
		BotonSegunColor( juego_ptr->MovimientoNumero( avance_inter_boton ) )->Apretar();
		avance_inter_boton++;
		if( avance_inter_boton < avance )
			InstalarTimer( K_TIMER_INTER_BOTON,1);
		else
		{
			avance_inter_boton=0;
			InstalarTimer( K_TIMER_ESPERA,10 );
		}
	}
}

void CSimonDlg::MostrarBotonCorrecto()
{
	BotonSimon * boton;

	boton=BotonSegunColor( juego_ptr->MovimientoNumero( avance_usuario ) );
	boton->DibujarApretado();
	sonido_pierde.Sonar();
	boton->DibujarSoltado();
	gano=true;
}

void CSimonDlg::Ganar()
{
	int tiempo_juego=juego_ptr->CuantoDuroJuego();
	for( int i=0;i<2;i++ )
	{
		boton_verde.ApretarTocando( sonido_gana.SuData() );
		boton_rojo.ApretarTocando(sonido_gana.SuData());
		boton_azul.ApretarTocando(sonido_gana.SuData());
		boton_amarillo.ApretarTocando(sonido_gana.SuData());
	}
	ScoresDlg dlg;

	dlg.AgregarScore( directory_app,tiempo_juego,slider_dificultad.Value() );
}

bool CSimonDlg::LevantarCurrentDirectory()
{
	directory_app[0]=0;
	if( GetCurrentDirectory( 256, directory_app) == 0 )
		return false;
	return true;
}

void CSimonDlg::OnRButtonDown(UINT nFlags, CPoint point) 
{
	AboutDlg dlg;
	dlg.DoModal();
}

void CSimonDlg::MostrarError(simon_error error)
{
	char buffer[20];
	CString mensaje;

	buffer[0]=0;
	mensaje+="Error # ";
	mensaje+=itoa( (int)error,buffer,10 );
	mensaje+=".";
	AfxMessageBox(LPCTSTR(mensaje));
	OnOK();
}

void CSimonDlg::ReplayJuego()
{
	if( avance_inter_boton<(avance ) )
	{
		BotonSegunColor( juego_ptr->MovimientoNumero( avance_inter_boton ) )->Apretar();
		avance_inter_boton++;
		InstalarTimer(K_TIMER_REPLAY,1);
	}
}

void CSimonDlg::InstalarTimer(int identificador, int factor)
{
	int dificultad=0,demora=0;
	
	dificultad=slider_dificultad.Value()+1;
	if( dificultad == 1 )
		demora=300;
	else if( dificultad == 2 )
		demora=200;
	else if( dificultad == 3 )
		demora=100;
	else if( dificultad == 4 )
		demora=20;
	this->SetTimer( identificador,demora*factor,NULL );
}

void CSimonDlg::MatarTimer(int identificador)
{
	KillTimer(identificador);
}


BOOL CSimonDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	SetCursor(cursor_mano);
	return TRUE;
}


