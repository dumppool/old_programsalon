// Jego.h: interface for the Jego class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JEGO_H__0983AD53_726B_11D2_B5E6_0008C72A46AE__INCLUDED_)
#define AFX_JEGO_H__0983AD53_726B_11D2_B5E6_0008C72A46AE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class Juego  
{
public:
	int CuantoDuroJuego();
	roll_over MovimientoNumero(int i);
	roll_over ProximoMovimiento( bool avanza );
	bool Inicializar( int dif );
	Juego();
	virtual ~Juego();
	int Dificultad();
private:
	DWORD tiempo;
	roll_over Color( int num );
	int NumeroAlAzar(int anterior);
	int * keys_ptr;
	int dificultad;
	int avance;
};

#endif // !defined(AFX_JEGO_H__0983AD53_726B_11D2_B5E6_0008C72A46AE__INCLUDED_)
