// Sonido.h: interface for the Sonido class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SONIDO_H__0983AD55_726B_11D2_B5E6_0008C72A46AE__INCLUDED_)
#define AFX_SONIDO_H__0983AD55_726B_11D2_B5E6_0008C72A46AE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class Sonido  
{
public:
	LPSTR SuData();
	bool Stop();
	bool Loopear();
	bool Sonar();
	simon_error Inicializar(UINT recurso);
	Sonido();
	virtual ~Sonido();
private:
	LPSTR sonido_ptr;
	HANDLE recurso_sonido;
};

#endif // !defined(AFX_SONIDO_H__0983AD55_726B_11D2_B5E6_0008C72A46AE__INCLUDED_)
