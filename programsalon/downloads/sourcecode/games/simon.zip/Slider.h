// Slider.h: interface for the Slider class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SLIDER_H__8D81E2B3_6F61_11D2_B5E2_00805F9F769A__INCLUDED_)
#define AFX_SLIDER_H__8D81E2B3_6F61_11D2_B5E2_00805F9F769A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class Slider  
{
public:
	void SoltarSin();
	void Soltar();
	int Value();
	BOOL TocarSonido();
	bool Apreto( CPoint * punto );
	bool EstaAdentro( CPoint * punto );
	simon_error Redibujar();
	simon_error Inicializar(int or_x, int or_y, HWND ventana_h, UINT recurso_fondo, UINT recurso_slider,int pasos_or);
	Slider();
	virtual ~Slider();
	bool Deslizar( int pixles );
	bool Trackear( CPoint * punto );
private:
	CRgn region_apreto;
	bool apretado;
	bool LeerSonido();
	bool Puede( int pixels );
	int XDeRegion( CRgn * reg );
	int ultimo_toque;
	bool OrigenRegion( int * x, int * y,CRgn * rgn_ptr );
	int pasos;
	bool ComponerRegion( CBitmap * bmp_ptr, CRgn * region_ptr,int *ancho_ptr,int * alto_ptr );
	CBitmap slider;
	CBitmap fondo;
	HDC fondo_dc;
	HDC slider_dc;
	HWND ventana_handle;
	CRgn region_fondo,region_slider;
	int x,y;
	int ancho_fondo,alto_fondo;
	int ancho_slider,alto_slider;
	LPSTR sonido_ptr;
	HANDLE recurso_sonido;
};

#endif // !defined(AFX_SLIDER_H__8D81E2B3_6F61_11D2_B5E2_00805F9F769A__INCLUDED_)
