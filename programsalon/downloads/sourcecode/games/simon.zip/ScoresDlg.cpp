// ScoresDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Simon.h"
#include "ScoresDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ScoresDlg dialog


ScoresDlg::ScoresDlg(CWnd* pParent /*=NULL*/)
	: CDialog(ScoresDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(ScoresDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void ScoresDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ScoresDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ScoresDlg, CDialog)
	//{{AFX_MSG_MAP(ScoresDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ScoresDlg message handlers


bool ScoresDlg::MostrarScores(LPCTSTR path_prog,int dif)
{
	dificultad=dif;
	memset( &los_puntajes,0,sizeof(puntajes) );
	path_programa=path_prog;
	path_programa+="\\scores.dat";
	CDialog::DoModal();
	return true;
}

BOOL ScoresDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	ColocarTituloVentana();
	if( !LeerScores() )
		return FALSE;
	if( !SetearCampos() )
		return FALSE;
	return TRUE;
}

void ScoresDlg::ColocarTituloVentana()
{
	CString titulo;
	char buffer[10];

	buffer[0]=0;
	titulo+="Best scores Level ";
	titulo+=itoa( dificultad+1,buffer,10 );
	SetWindowText( LPCTSTR( titulo ) );
}

bool ScoresDlg::LeerScores()
{
	CFile * archivo_ptr=NULL;

	archivo_ptr=AbrirArchivoScores();
	if( archivo_ptr == NULL )
		return false;
	if( archivo_ptr->GetLength() < (sizeof( puntajes )*4) )
	{
		for( int x=0;x<4;x++ )
			archivo_ptr->Write( &los_puntajes,sizeof(puntajes));
	}
	archivo_ptr->Seek( dificultad*sizeof(puntajes),CFile::begin );
	if( archivo_ptr->Read( &los_puntajes,sizeof( puntajes ) ) != sizeof( puntajes ) )
		return VolverDesalocando( archivo_ptr );
	archivo_ptr->Close();
	delete archivo_ptr;
	return true;
}

CFile * ScoresDlg::AbrirArchivoScores()
{
	CFile * arch_ptr=NULL;

	try
	{
		arch_ptr=new CFile( LPCTSTR( path_programa ),CFile::modeReadWrite | CFile::typeBinary );
	}catch( CFileException * e )
	{

	}
	if( arch_ptr != NULL )
		return arch_ptr;
	try
	{
		arch_ptr=new CFile( LPCTSTR( path_programa ),CFile::modeCreate | CFile::modeReadWrite | CFile::typeBinary );
	}catch( CFileException * e )
	{

	}
	if( arch_ptr != NULL )
		return arch_ptr;
	return NULL;
}

bool ScoresDlg::VolverDesalocando(CFile * arch)
{
	arch->Close();
	delete arch;
	return false;
}

bool ScoresDlg::SetearCampos()
{
	puntaje * puntaje_ptr;

	puntaje_ptr=(puntaje*)&los_puntajes;
	if( !SetearCampo( ID_SOCORE_1_TXT, &(puntaje_ptr[0]) ) )
		return false;
	if( !SetearCampo( ID_SOCORE_2_TXT, &(puntaje_ptr[1]) ) )
		return false;
	if( !SetearCampo( ID_SOCORE_3_TXT, &(puntaje_ptr[2]) ) )
		return false;
	if( !SetearCampo( ID_SOCORE_4_TXT, &(puntaje_ptr[3]) ) )
		return false;
	if( !SetearCampo( ID_SOCORE_5_TXT, &(puntaje_ptr[4]) ) )
		return false;
	return true;
}

bool ScoresDlg::SetearCampo(UINT nombre_campo,puntaje * puntaje_ptr)
{
	char buffer[10];
	CString texto;
	
	if( puntaje_ptr->tiempo == 0 )
		return true;
	buffer[0]=0;
	texto+=puntaje_ptr->nombre;
	texto+=" ";
	texto+=puntaje_ptr->fecha;
	texto+=" ";
	texto+=itoa( puntaje_ptr->tiempo,buffer,10 );
	texto +=" seconds.";
	SetDlgItemText( nombre_campo,LPCTSTR( texto ) );
	return true;
}

bool ScoresDlg::AgregarScore(LPCTSTR path_prog, int tiempo,int dif)
{
	NombreDlg nombre_dlg;
	CString nombre;

	dificultad=dif;
	memset( &los_puntajes,0,sizeof(puntajes) );
	path_programa=path_prog;
	path_programa+="\\scores.dat";
	if( !DebeAgregarJugada(tiempo) )
		return true;
	if( nombre_dlg.DoModal() != IDOK )
		return true;
	nombre=*(nombre_dlg.Nombre());
	if( !AgregarJugada( LPCTSTR(nombre),tiempo ) )
		return false;
	CDialog::DoModal();
	return true;
}

bool ScoresDlg::DebeAgregarJugada(int tiempo)
{
	puntaje * puntaje_ptr;

	if( !LeerScores() )
		return false;
	puntaje_ptr=(puntaje*)&los_puntajes;
	for( int i=0;i<5;i++ )
	{
		if( puntaje_ptr[i].tiempo == 0 || tiempo < puntaje_ptr[i].tiempo )
			return true;
	}
	return false;
}

bool ScoresDlg::AgregarJugada(LPCTSTR  nombre, int tiempo)
{
	puntaje * puntaje_ptr;

	if( !LeerScores() )
		return false;
	puntaje_ptr=(puntaje*)&los_puntajes;
	for( int i=0;i< 5;i++ )
	{
		if( puntaje_ptr[i].tiempo == 0 || tiempo < puntaje_ptr[i].tiempo )
		{
			if( i < 4 )
			{
				HacerCascada( &(puntaje_ptr[i]),4-i );
				ArmarPuntaje( &(puntaje_ptr[i]),nombre,tiempo );
			}
			else ArmarPuntaje( &(puntaje_ptr[i]),nombre,tiempo );
			return EscribirNuevoScore();
		}
	}
	return false;
}

void ScoresDlg::ArmarPuntaje(puntaje * puntaje_ptr, LPCTSTR nombre, int tiempo)
{
	CString texto_fecha;
	CTime fecha;

	memset( &puntaje_ptr->nombre,0,30 );
	strcat( (char*)&puntaje_ptr->nombre,nombre );

	fecha=CTime::GetCurrentTime();
	texto_fecha= fecha.Format( "%d/%b/%Y" );
	puntaje_ptr->tiempo=tiempo;
	memset( &puntaje_ptr->fecha,0,10 );
	strcat( (char*)&puntaje_ptr->fecha,(char*)LPCTSTR( texto_fecha ) );
}

bool ScoresDlg::EscribirNuevoScore()
{
	CFile * arch_ptr=NULL;

	arch_ptr=AbrirArchivoScores();
	if( arch_ptr == NULL )
		return false;
	arch_ptr->Seek( dificultad*sizeof(puntajes),CFile::begin );
	arch_ptr->Write( &los_puntajes,sizeof(puntajes) );
	arch_ptr->Close();
	delete arch_ptr;
	return true;
}

void ScoresDlg::HacerCascada(puntaje * puntaje_ptr, int ctos)
{
	for( ctos;ctos>=0;ctos-- )
	{
		CopiarPuntaje( puntaje_ptr+(ctos-1),puntaje_ptr+ctos );
	}
}

void ScoresDlg::CopiarPuntaje(puntaje * punt_or, puntaje * punt_dest)
{
	memcpy( &(punt_dest->nombre),&(punt_or->nombre),30 );
	memcpy( &(punt_dest->fecha),&(punt_or->fecha),10 );
	punt_dest->tiempo=punt_or->tiempo;
}




