// Foto.h: interface for the Foto class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOTO_H__BD49A45B_52DE_11D2_807F_006097E57760__INCLUDED_)
#define AFX_FOTO_H__BD49A45B_52DE_11D2_807F_006097E57760__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "onversorBmp2Rgn.h"

class Foto  
{
public:
	bool Inicializar( HWND vent_h,UINT recurso_prend,UINT recurso_apag, UINT recurso_mascara,UINT recurso_mascara_inverted	 );
	bool DibujarEnmascarada( int x,int y );
	bool Dibujar(int x, int y);
	bool Inicializar( HWND vent_h,UINT recurso_foto );
	Foto();
	virtual ~Foto();
	bool RedibujarFondoEnmascarado( int x,int y );
private:
	HDC prendido_DC;
	HDC apagado_DC;
	CBitmap prendido,apagado;
	CBitmap mask,mask_invert;
	HDC mask_DC,mask_invert_DC;
	int ancho,alto;
	HWND ventana_handle;
	HDC dc_ventana_handle;
	CRgn * region_ptr;
	HRGN region_h;
};

#endif // !defined(AFX_FOTO_H__BD49A45B_52DE_11D2_807F_006097E57760__INCLUDED_)
