#if !defined(AFX_SCORESDLG_H__80C71644_7338_11D2_B5E7_0008C72A46AE__INCLUDED_)
#define AFX_SCORESDLG_H__80C71644_7338_11D2_B5E7_0008C72A46AE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ScoresDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// ScoresDlg dialog

#include "NombreDlg.h"

class ScoresDlg : public CDialog
{
// Construction
public:
	bool AgregarScore( LPCTSTR path_prog, int tiempo,int dif);
	bool MostrarScores(LPCTSTR path_prog,int dif);
	ScoresDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(ScoresDlg)
	enum { IDD = ID_SCORES_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ScoresDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ScoresDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void ColocarTituloVentana();
	int dificultad;
	void CopiarPuntaje( puntaje * punt_or,puntaje * punt_dest );
	void HacerCascada( puntaje * puntaje_ptr,int ctos );
	bool EscribirNuevoScore();
	void ArmarPuntaje( puntaje * puntaje_ptr,LPCTSTR nombre,int tiempo );
	bool AgregarJugada( LPCTSTR  nombre,int tiempo );
	bool DebeAgregarJugada( int tiempo );
	bool SetearCampo( UINT nombre_campo,puntaje * puntaje_ptr );
	bool SetearCampos();
	bool VolverDesalocando( CFile * arch );
	CFile * AbrirArchivoScores();
	bool LeerScores();
	CString path_programa;
	puntajes los_puntajes;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCORESDLG_H__80C71644_7338_11D2_B5E7_0008C72A46AE__INCLUDED_)
