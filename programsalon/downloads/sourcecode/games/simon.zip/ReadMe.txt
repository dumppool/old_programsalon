Hi.

Here is my submition for the "Because Knowledge was Meant to be Free" contest.
It's a board game, similar to the classical of the 70/80's.

You will need Sound Blaster Compatible Software and Hardware, and MFC42.DLL.

To play, just press the "Play" button.
To quit, drag and leave the "On/Off" slide to the "Off" position, or just press the ESC key.

The goal is to repeat the secuence of colors, by pressing the different buttons.

The project was compiled with MS Visual C++ 6.0 SP1. If you have any problem opening it
please emailme.

Any sugestion or bug, just emailme.
Thanks.



Fernando Lagos
http://members.xoom.com/lakes
wau@satlink.com