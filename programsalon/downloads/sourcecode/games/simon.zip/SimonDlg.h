// SimonDlg.h : header file
//

#if !defined(AFX_SIMONDLG_H__BD49A453_52DE_11D2_807F_006097E57760__INCLUDED_)
#define AFX_SIMONDLG_H__BD49A453_52DE_11D2_807F_006097E57760__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CSimonDlg dialog

#include "BotonSimon.h"
#include "Boton.h"
#include "Slider.h"
#include "Juego.h"
#include "Sonido.h"
#include "ScoresDlg.h"
#include "AboutDlg.h"

class CSimonDlg : public CDialog
{
// Construction
public:
	simon_error Crear();
	CSimonDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSimonDlg)
	enum { IDD = IDD_SIMON_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimonDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSimonDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg UINT OnNcHitTest(CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void MatarTimer(int identificador);
	void InstalarTimer( int demora,int factor );
	void ReplayJuego();
	int avance_inter_boton;
	void MostrarError(simon_error error);
	bool LevantarCurrentDirectory();
	void Ganar();
	void MostrarBotonCorrecto();
	Sonido sonido_pierde;
	Sonido sonido_gana;
	void MostrarJuego();
	int avance;
	int avance_usuario;
	BotonSimon * BotonSegunColor( roll_over color );
	void ApretoBotonJuego( roll_over color );
	Juego * juego_ptr;
	void BotonScores();
	void BotonPlay();
	void BotonLast();
	roll_over SobreDondeEsta( CPoint * punto );
	HCURSOR cursor_mano;
	HCURSOR cursor_comun;
	CRgn region_drag_window;
	bool PrepararRegionDragWindow();
	Boton boton_last,boton_play,boton_scores;
	BotonSimon boton_verde,boton_rojo,boton_amarillo,boton_azul;
	Slider slider_dificultad;
	Slider slider_on_off;
	simon_error Redibujar();
	simon_error CambiarFormaVentana();
	void Salir();
	bool mouse_down;
	char directory_app[256];
	CRgn region_ventana_redonda;
	bool gano;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMONDLG_H__BD49A453_52DE_11D2_807F_006097E57760__INCLUDED_)
