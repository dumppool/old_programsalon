// Sonido.cpp: implementation of the Sonido class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Simon.h"
#include "Sonido.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Sonido::Sonido()
{
	sonido_ptr=NULL;
	recurso_sonido=NULL;
}

Sonido::~Sonido()
{
	if( recurso_sonido != NULL )
	{
		UnlockResource(	recurso_sonido );
		FreeResource( recurso_sonido );
	}
}

simon_error Sonido::Inicializar(UINT recurso)
{
	HANDLE hResInfo=NULL;
	LPSTR lpRes=NULL;

	hResInfo = FindResource( AfxGetResourceHandle(),MAKEINTRESOURCE(recurso),"WAVE" );
	if( hResInfo == NULL )
		return sonido_init_find_resource_error;
	recurso_sonido = LoadResource( AfxGetResourceHandle(),(HRSRC)hResInfo );
	if( recurso_sonido == NULL )
		return sonido_init_load_resource_error;
	sonido_ptr=(LPSTR)LockResource( recurso_sonido );
	if( sonido_ptr == NULL )
		return sonido_init_lock_resource_error;
	return ok;
}

bool Sonido::Sonar()
{
	if( !sndPlaySound( sonido_ptr,SND_MEMORY | SND_SYNC |SND_NODEFAULT ) )
		return false;
	return true;
}

bool Sonido::Loopear()
{
	if( !sndPlaySound( sonido_ptr,SND_MEMORY | SND_SYNC |SND_NODEFAULT | SND_LOOP ) )
		return false;
	return true;
}
 

bool Sonido::Stop()
{
	if( !sndPlaySound( NULL,SND_MEMORY ) )
		return false;
	return true;
}



LPSTR Sonido::SuData()
{
	return sonido_ptr;
}
