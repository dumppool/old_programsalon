#if !defined(AFX_NOMBREDLG_H__80C71645_7338_11D2_B5E7_0008C72A46AE__INCLUDED_)
#define AFX_NOMBREDLG_H__80C71645_7338_11D2_B5E7_0008C72A46AE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// NombreDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// NombreDlg dialog

class NombreDlg : public CDialog
{
// Construction
public:
	CString * Nombre();
	NombreDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(NombreDlg)
	enum { IDD = ID_NAME_DLG };
	CString	nombre;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(NombreDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(NombreDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NOMBREDLG_H__80C71645_7338_11D2_B5E7_0008C72A46AE__INCLUDED_)
