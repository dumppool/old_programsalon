// Foto.cpp: implementation of the Foto class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Foto.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Foto::Foto()
{
	prendido_DC=NULL;
	apagado_DC=NULL;
	mask_DC=NULL;
	mask_invert_DC=NULL;
}

Foto::~Foto()
{
	if( prendido_DC != NULL )
		DeleteDC( prendido_DC );
	prendido.DeleteObject();
	if( apagado_DC != NULL )
		DeleteDC( apagado_DC );
	apagado.DeleteObject();
	if( mask_DC != NULL )
		DeleteDC( mask_DC );
	mask.DeleteObject();
	if( mask_invert_DC != NULL )
		DeleteDC( mask_invert_DC );
	mask_invert.DeleteObject();
}

bool Foto::Inicializar(HWND vent_h,UINT recurso_prend,UINT recurso_apag, UINT recurso_mascara,UINT recurso_mascara_inverted)
{
	BITMAP info_bmp;

	ventana_handle=vent_h;
	prendido_DC=::CreateCompatibleDC( NULL );
	if( prendido_DC == NULL )
		return false;
	if( !prendido.LoadBitmap( recurso_prend ) )
		return false;
	::SelectObject( prendido_DC,HBITMAP( prendido ) );

	if( prendido.GetBitmap( &info_bmp ) == 0 )
		return false;
	ancho=info_bmp.bmWidth;
	alto=info_bmp.bmHeight;
	
	apagado_DC=::CreateCompatibleDC( NULL );
	if( apagado_DC == NULL )
		return false;
	if( !apagado.LoadBitmap( recurso_apag ) )
		return false;
	::SelectObject( apagado_DC,HBITMAP( apagado ) );
	mask_DC=::CreateCompatibleDC( NULL );
	if( mask_DC == NULL )
		return false;
	if( !mask.LoadBitmap( recurso_mascara ) )
		return false;
	::SelectObject( mask_DC,HBITMAP( mask ) );
	mask_invert_DC=::CreateCompatibleDC( NULL );
	if( mask_invert_DC == NULL )
		return false;
	if( !mask_invert.LoadBitmap( recurso_mascara_inverted ) )
		return false;
	::SelectObject( mask_invert_DC,HBITMAP( mask_invert ) );
	ConversorBmp2Rgn conversor;
	region_h=0;
	region_h=conversor.Convertir( recurso_mascara );
	return true;
}

bool Foto::Inicializar( HWND vent_h,UINT recurso_foto )
{
	BITMAP info_bmp;

	ventana_handle=vent_h;
	prendido_DC=::CreateCompatibleDC( NULL );
	if( prendido_DC == NULL )
		return false;
	if( !prendido.LoadBitmap( recurso_foto ) )
		return false;
	if( prendido.GetBitmap( &info_bmp ) == 0 )
		return false;
	ancho=info_bmp.bmWidth;
	alto=info_bmp.bmHeight;
	::SelectObject( prendido_DC,HBITMAP( prendido ) );
	return true;
}

bool Foto::Dibujar(int x, int y)
{
	if( !::BitBlt( ::GetWindowDC( ventana_handle ),x,y,ancho,alto,prendido_DC,x,y,SRCCOPY) )
		return false;
	return true;
}

bool Foto::DibujarEnmascarada(int x, int y)
{
	/*if( !::BitBlt( prendido_DC,0,0,ancho,alto,mask_DC,x,y,SRCAND ) )
		return false;
	if( !::BitBlt( ::GetWindowDC(ventana_handle),x,y,ancho,alto,mask_invert_DC,0,0,SRCAND ) )
		return false;*/
	CRgn region;
	region.CreateEllipticRgn(0,0,10,10);
	HDC eldc=::GetWindowDC( ventana_handle );
	int a=::ExtSelectClipRgn( eldc,region_h,RGN_COPY);
	if( a==ERROR )
		AfxMessageBox("error");
	if( !::BitBlt( eldc,x,y,ancho,alto,prendido_DC,0,0,SRCCOPY ) )
		return false;
	return true;
}




bool Foto::RedibujarFondoEnmascarado(int x,int y)
{
	if( !::BitBlt( apagado_DC,0,0,ancho,alto,mask_DC,x,y,SRCAND ) )
		return false;
	if( !::BitBlt( ::GetWindowDC(ventana_handle),x,y,ancho,alto,mask_invert_DC,0,0,SRCAND ) )
		return false;
	if( !::BitBlt( ::GetWindowDC(ventana_handle),x,y,ancho,alto, apagado_DC ,0,0,SRCPAINT ) )
		return false;
	return true;
}


