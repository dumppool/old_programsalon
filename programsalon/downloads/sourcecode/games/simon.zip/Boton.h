// Boton.h: interface for the Boton class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BOTON_H__EF7877A3_680C_11D2_80B1_006097E57760__INCLUDED_)
#define AFX_BOTON_H__EF7877A3_680C_11D2_80B1_006097E57760__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class Boton  
{
public:
	simon_error Redibujar();
	bool EstaAdentro(CPoint * punto);
	bool Soltar(  );
	simon_error Inicializar( HWND vent_h, UINT recurso_prend,int x_or, int y_or );
	Boton();
	virtual ~Boton();
	bool Apretar();
private:
	bool apretado;
	CBrush pincel;
	int x,y;
	CBitmap prendido;
	HDC prendido_DC;
	HWND ventana_handle;
	int ancho,alto;
	CRgn region;
};

#endif // !defined(AFX_BOTON_H__EF7877A3_680C_11D2_80B1_006097E57760__INCLUDED_)
