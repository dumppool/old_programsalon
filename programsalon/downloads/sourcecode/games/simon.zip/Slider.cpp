// Slider.cpp: implementation of the Slider class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Simon.h"
#include "Slider.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Slider::Slider()
{
	fondo_dc=NULL;
	slider_dc=NULL;
	sonido_ptr=NULL;
	recurso_sonido=NULL;
	apretado=false;
}

Slider::~Slider()
{
	if( fondo_dc != NULL )
		DeleteDC( fondo_dc );
	fondo.DeleteObject();
	if( slider_dc != NULL )
		DeleteDC( slider_dc );
	slider.DeleteObject();
	region_fondo.DeleteObject();
	region_slider.DeleteObject();
	region_apreto.DeleteObject();
	if( recurso_sonido != NULL )
	{
		UnlockResource( recurso_sonido );
		FreeResource( recurso_sonido );
	}
}

simon_error Slider::Inicializar(int or_x, int or_y, HWND ventana_h, UINT recurso_fondo, UINT recurso_slider,int pasos_or)
{
	ventana_handle=ventana_h;
	x=or_x;
	y=or_y;
	pasos=pasos_or;
	fondo_dc=::CreateCompatibleDC( NULL );
	if( fondo_dc == NULL )
		return slider_init_create_dc_error;
	if( !fondo.LoadBitmap( recurso_fondo ) )
		return slider_init_load_bitmap_error;
	::SelectObject( fondo_dc,fondo );
	if( !ComponerRegion( &fondo,&region_fondo,&ancho_fondo,&alto_fondo ) )
		return slider_init_componer_region_error;
	if( region_fondo.OffsetRgn( x,y ) == ERROR )
		return slider_init_offset_rgn_error;
	slider_dc=::CreateCompatibleDC( NULL );
	if( slider_dc == NULL )
		return slider_init_create_dc_error;
	if( !slider.LoadBitmap( recurso_slider ) )
		return slider_init_load_bitmap_error;
	::SelectObject( slider_dc,slider );
	if( !ComponerRegion( &slider,&region_slider,&ancho_slider,&alto_slider ) )
		return slider_init_componer_region_error;
	if( region_slider.OffsetRgn( x,y ) == ERROR )
		return slider_init_offset_rgn_error;
	if( !LeerSonido() )
		return slider_init_leer_sonido_error;
	if( !region_apreto.CreateRectRgn(0,0,10,10) )
		return slider_init_crear_region_apreto;
	return ok;
}

bool Slider::ComponerRegion(CBitmap * bmp_ptr, CRgn * region_ptr,int *ancho_ptr,int * alto_ptr)
{
	BITMAP info_bmp;
	int ancho,alto;

	if( bmp_ptr->GetBitmap( &info_bmp ) == 0 )
		return false;
	ancho=info_bmp.bmWidth;
	alto=info_bmp.bmHeight;
	if( !region_ptr->CreateRectRgn( 0,0,ancho,alto ) )
		return false;
	*ancho_ptr=ancho;
	*alto_ptr=alto;
	return true;
}

simon_error Slider::Redibujar()
{
	HDC wind_dc=NULL;
	int resultado=0;
	CRgn region_update;
	int slider_x,slider_y;
	int fondo_x,fondo_y;

	if( !OrigenRegion( &slider_x,&slider_y,&region_slider ) )
		return slider_redibujar_origen_region_1_error;
	if( !OrigenRegion( &fondo_x,&fondo_y,&region_fondo ) )
		return slider_redibujar_origen_region_2_error;
	wind_dc=GetWindowDC( ventana_handle );
	if( wind_dc == NULL )
		return slider_redibujar_getwdc_error;
	if( !BitBlt( wind_dc,slider_x,slider_y,ancho_slider,alto_slider,slider_dc,0,0,SRCCOPY ) )
		return slider_redibujar_bitblt_1_error;
	if( !region_update.CreateRectRgn( 0,0,10,10 ) )
		return slider_redibujar_create_rect_rgn_error;
	resultado=region_update.CombineRgn( &region_fondo,&region_slider,RGN_DIFF );
	if( resultado==ERROR )
		return slider_redibujar_combine_rgn_error;
	resultado=::ExtSelectClipRgn( wind_dc,region_update,RGN_COPY );
	if( resultado == ERROR )
		return slider_redibujar_ext_select_clip_rgn;
	if( !BitBlt( wind_dc,fondo_x,fondo_y,ancho_fondo,alto_fondo,fondo_dc,0,0,SRCCOPY ) )
		return slider_redibujar_bitblt_2_error;
	ReleaseDC( ventana_handle,wind_dc );
	::ExtSelectClipRgn( wind_dc,NULL,RGN_COPY );
	region_update.DeleteObject();
	return ok;
}

bool Slider::Deslizar(int pixels)
{
	if( region_slider.OffsetRgn( pixels,0 ) == 0 )
		return false;
	if( Redibujar() != ok)
		return false;
	return true;
}

bool Slider::EstaAdentro(CPoint * punto)
{
	if( !::PtInRegion( HRGN(region_slider),punto->x,punto->y ) )
		return false;
	return true;
}

bool Slider::OrigenRegion(int * x, int * y,CRgn * rgn_ptr)
{
	RECT borde;

	if( rgn_ptr->GetRgnBox(&borde) == ERROR)
		return false;
	*x=borde.left;
	*y=borde.top;
	return true;
}

bool Slider::Apreto(CPoint * punto)
{
	if( !::PtInRegion( HRGN(region_slider),punto->x,punto->y ) )
		return false;
	apretado=true;
	ultimo_toque=punto->x;
	if( region_apreto.CopyRgn( &region_slider )==ERROR )
		AfxMessageBox("No pude copiar region");
	return true;
}

bool Slider::Trackear(CPoint * punto)
{
	int pixels;

	if( !EstaAdentro( punto ) )
	{
		Soltar();
		return false;
	}
	pixels=punto->x - ultimo_toque;
	if( pixels >= 8 || pixels <= -8)
	{
		if( pixels < 0 )
			pixels=-8;
		else pixels=8;
		if( Puede( pixels ) )
		{
			Deslizar( pixels );
			TocarSonido();
			ultimo_toque=punto->x;
		}
	}
	return true;
}

void Slider::Soltar()
{
	if( apretado==true )
	{
		if( region_slider.CopyRgn( &region_apreto )==ERROR )
			AfxMessageBox("No pude copiar region");
		Redibujar();
		apretado=false;
	}
}

void Slider::SoltarSin()
{
	apretado=false;
}

int Slider::XDeRegion(CRgn * reg)
{
	RECT borde;

	if( reg->GetRgnBox(&borde) == ERROR)
		return 0;
	return borde.left;
}

bool Slider::Puede(int pixels)
{
	int equis=XDeRegion( &region_slider );
	equis+=pixels;
	if( equis >= XDeRegion( &region_fondo ) && equis < (XDeRegion( &region_fondo )+(pasos*8)) )
		return true;
	return false;
}

BOOL Slider::TocarSonido()
{
	if( !sndPlaySound( sonido_ptr,SND_MEMORY | SND_ASYNC |SND_NODEFAULT ) )
		return false;
	return true;
}

bool Slider::LeerSonido()
{
	HANDLE hResInfo=NULL;
	LPSTR lpRes=NULL;

	hResInfo = FindResource( AfxGetResourceHandle(),MAKEINTRESOURCE(ID_DESLIZ_WAV),"WAVE" );
	if( hResInfo == NULL )
		return false;
	recurso_sonido = LoadResource( AfxGetResourceHandle(),(HRSRC)hResInfo );
	if( recurso_sonido == NULL )
		return false;
	sonido_ptr=(LPSTR)LockResource( recurso_sonido );
	if( sonido_ptr == NULL )
		return false;
	return true;
}

int Slider::Value()
{
	return (XDeRegion( &region_slider ) - XDeRegion( &region_fondo ) )/8;
}




