// BotonSimon.h: interface for the BotonSimon class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BOTONSIMON_H__A21BC793_53A7_11D2_8080_006097E57760__INCLUDED_)
#define AFX_BOTONSIMON_H__A21BC793_53A7_11D2_8080_006097E57760__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "onversorBmp2Rgn.h"

class BotonSimon  
{
public:
	bool ApretarTocando(LPSTR sonido_data);
	bool Apretar();
	simon_error Redibujar();
	bool EstaAdentro( CPoint * punto );
	bool DibujarSoltado(  );
	simon_error Inicializar( int x_or,int y_or,HWND ventana_h,UINT recurso_prend,UINT recurso_apag, UINT recurso_mascara,UINT recurso_wav );
	BotonSimon();
	virtual ~BotonSimon();
	bool DibujarApretado(  );
private:
	bool LeerSonido( UINT recurso );
	int x,y;
	HDC prendido_DC;
	HDC apagado_DC;
	CBitmap prendido,apagado;
	HRGN region_mascara_h;
	HWND ventana_handle;
	int ancho,alto;
	bool TocarSonido() ;
	LPSTR sonido_ptr;
	HANDLE recurso_sonido;
};

#endif // !defined(AFX_BOTONSIMON_H__A21BC793_53A7_11D2_8080_006097E57760__INCLUDED_)
