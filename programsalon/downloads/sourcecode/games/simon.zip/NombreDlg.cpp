// NombreDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Simon.h"
#include "NombreDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// NombreDlg dialog


NombreDlg::NombreDlg(CWnd* pParent /*=NULL*/)
	: CDialog(NombreDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(NombreDlg)
	nombre = _T("");
	//}}AFX_DATA_INIT
}


void NombreDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(NombreDlg)
	DDX_Text(pDX, ID_NAME_TXT, nombre);
	DDV_MaxChars(pDX, nombre, 30);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(NombreDlg, CDialog)
	//{{AFX_MSG_MAP(NombreDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// NombreDlg message handlers

CString * NombreDlg::Nombre()
{
	return & nombre;
}
