// onversorBmp2Rgn.h: interface for the ConversorBmp2Rgn class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ONVERSORBMP2RGN_H__D055F824_377C_11D2_BDA5_006097E57760__INCLUDED_)
#define AFX_ONVERSORBMP2RGN_H__D055F824_377C_11D2_BDA5_006097E57760__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class ConversorBmp2Rgn  
{
public:
	HRGN Convertir(UINT bmp_resource);
	ConversorBmp2Rgn();
	virtual ~ConversorBmp2Rgn();
private:
	HRGN BitmapToRegion (HBITMAP hBmp);
};

#endif // !defined(AFX_ONVERSORBMP2RGN_H__D055F824_377C_11D2_BDA5_006097E57760__INCLUDED_)
