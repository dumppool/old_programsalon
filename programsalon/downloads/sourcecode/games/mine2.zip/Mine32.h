// Mine32.h : main header file for the MINE32 application
//

#if !defined(AFX_MINE32_H__6EFA3907_2329_11D3_86F7_81CBA8EFA9EC__INCLUDED_)
#define AFX_MINE32_H__6EFA3907_2329_11D3_86F7_81CBA8EFA9EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMine32App:
// See Mine32.cpp for the implementation of this class
//

class CMine32App : public CWinApp
{
public:
	CMine32App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMine32App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMine32App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MINE32_H__6EFA3907_2329_11D3_86F7_81CBA8EFA9EC__INCLUDED_)
