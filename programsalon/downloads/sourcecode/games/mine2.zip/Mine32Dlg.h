// Mine32Dlg.h : header file
//

#if !defined(AFX_MINE32DLG_H__6EFA3909_2329_11D3_86F7_81CBA8EFA9EC__INCLUDED_)
#define AFX_MINE32DLG_H__6EFA3909_2329_11D3_86F7_81CBA8EFA9EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CMine32Dlg dialog

class CMine32Dlg : public CDialog
{
// Construction
public:
	CMine32Dlg(CWnd* pParent = NULL);	// standard constructor
	HBITMAP m_hbSmile, m_hbPass, m_hbClick, m_hbBomb;
	CPoint m_LastPoint;
	CRect  m_Ground, m_BeginButton, m_Time, m_Mines;
	void DrawMines();
	void IniData();
	void Sweep(int x, int y);
	void Flag(int x, int y);

// Dialog Data
	//{{AFX_DATA(CMine32Dlg)
	enum { IDD = IDD_MINE32_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMine32Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon, m_hSmallIcon;

	// Generated message map functions
	//{{AFX_MSG(CMine32Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTimeDlg();
	afx_msg void OnExit();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnUpdateBeginner(CCmdUI* pCmdUI);
	afx_msg void OnUpdateMiddle(CCmdUI* pCmdUI);
	afx_msg void OnUpdateExpert(CCmdUI* pCmdUI);
	afx_msg void OnUpdateCustom(CCmdUI* pCmdUI);
	afx_msg void OnUpdateMark(CCmdUI* pCmdUI);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnBegin();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MINE32DLG_H__6EFA3909_2329_11D3_86F7_81CBA8EFA9EC__INCLUDED_)
