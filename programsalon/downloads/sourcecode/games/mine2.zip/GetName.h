#if !defined(AFX_GETNAME_H__07C94401_2FF5_11D3_86F7_9FAA629A49EC__INCLUDED_)
#define AFX_GETNAME_H__07C94401_2FF5_11D3_86F7_9FAA629A49EC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// GetName.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGetName dialog

class CGetName : public CDialog
{
// Construction
public:
	CGetName(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGetName)
	enum { IDD = IDD_GETNAME };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGetName)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGetName)
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETNAME_H__07C94401_2FF5_11D3_86F7_9FAA629A49EC__INCLUDED_)
