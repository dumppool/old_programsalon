// GetName.cpp : implementation file
//

#include "stdafx.h"
#include "Mine32.h"
#include "GetName.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MAXLENGTH 128
extern int nDifficulty;
extern CString strName[3];
/////////////////////////////////////////////////////////////////////////////
// CGetName dialog


CGetName::CGetName(CWnd* pParent /*=NULL*/)
	: CDialog(CGetName::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGetName)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CGetName::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGetName)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGetName, CDialog)
	//{{AFX_MSG_MAP(CGetName)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGetName message handlers

void CGetName::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	CString strMsg;
	if (nDifficulty == 0)
		strMsg.LoadString(IDS_BEGINNER);
	if (nDifficulty == 1)
		strMsg.LoadString(IDS_MIDDLE);
	if (nDifficulty == 2)
		strMsg.LoadString(IDS_EXPERT);
	SetDlgItemText(IDC_MESSAGE, strMsg);
	SetDlgItemText(IDC_NAME, strName[nDifficulty]);
}

void CGetName::OnOK() 
{
	LPTSTR lpName;
	
	lpName = strName[nDifficulty].GetBuffer(MAXLENGTH);
	GetDlgItemText(IDC_NAME, lpName, MAXLENGTH);
	strName[nDifficulty].ReleaseBuffer();

	CDialog::OnOK();
}
