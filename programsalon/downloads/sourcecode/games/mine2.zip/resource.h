//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Mine32.rc
//
#define IDS_SECOND                      7
#define IDS_NONAME                      8
#define IDS_BEGINNER                    9
#define IDS_MIDDLE                      10
#define IDS_EXPERT                      11
#define IDM_ABOUTBOX                    0x0010
#define IDD_CUSTOM                      80
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MINE32_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_HEIGHT                      141
#define IDC_WIDTH                       142
#define IDC_MINES                       143
#define IDB_ICONS                       410
#define IDB_NUMBERS                     420
#define IDB_FACES                       430
#define IDC_MAINMEMU                    500
#define IDM_EXIT                        512
#define IDM_BEGINNER                    521
#define IDM_MIDDLE                      522
#define IDM_EXPERT                      523
#define IDM_CUSTOM                      524
#define IDM_MARK                        527
#define IDM_TIME                        528
#define IDM_ABOUT                       596
#define IDC_MESSAGE                     601
#define IDC_NAME                        602
#define IDD_NAME                        699
#define IDD_GETNAME                     699
#define IDD_TIME                        700
#define IDC_TIME1                       701
#define IDC_NAME1                       702
#define IDC_TIME2                       703
#define IDC_NAME2                       704
#define IDC_TIME3                       705
#define IDC_NAME3                       706
#define IDB_RESET                       777
#define IDC_BEGIN                       1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
