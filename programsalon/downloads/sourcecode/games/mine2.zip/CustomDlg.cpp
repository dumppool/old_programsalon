// CustomDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Mine32.h"
#include "CustomDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern int nWidth, nHeight, nTotalMines, nMines;
/////////////////////////////////////////////////////////////////////////////
// CCustomDlg dialog


CCustomDlg::CCustomDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCustomDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCustomDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CCustomDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCustomDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCustomDlg, CDialog)
	//{{AFX_MSG_MAP(CCustomDlg)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCustomDlg message handlers

void CCustomDlg::OnOK() 
{
	nWidth = GetDlgItemInt(IDC_WIDTH);
	nHeight = GetDlgItemInt(IDC_HEIGHT);
	nTotalMines = nMines = GetDlgItemInt(IDC_MINES);

	CDialog::OnOK();
}

void CCustomDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	SetDlgItemInt(IDC_WIDTH, nWidth);
	SetDlgItemInt(IDC_HEIGHT, nHeight);
	SetDlgItemInt(IDC_MINES, nMines);
}
