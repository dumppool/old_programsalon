// Mine32Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "Mine32.h"
#include "Mine32Dlg.h"
#include "TimeDlg.h"
#include "CustomDlg.h"
#include "GetName.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define XPos 13
#define YPos 55
#define EDGE 3

BOOL bMark, bTime, bBomb, bWin;
int nDifficulty;
int nWidth, nHeight;
int nMines, nTotalMines;
int nTime[4];
DWORD Mines[18];
DWORD LClicked[18];
DWORD RClicked[18];
CDC IconsDC, FacesDC, NumsDC;
int x0[8], y0[8];
CDC MemDC;
extern CString strName[3];
int nSeconds;
int nClicked;

#define GetBit(x, y) (Mines[y] >> x) & 1
#define SetBit(x, y) Mines[y] |= (1 << x)
#define GetLClicked(x, y) (LClicked[y] >> x) & 1
#define SetLClicked(x, y) LClicked[y] |= (1 << x)
#define GetRClicked(x, y) (RClicked[y] >> x) & 1
#define SetR1Clicked(x, y) RClicked[y] |= (1 << x)
#define SetR0Clicked(x, y) RClicked[y] &= ~(1 << x)

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMine32Dlg dialog

CMine32Dlg::CMine32Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMine32Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMine32Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_hSmallIcon = (HICON)LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
}

void CMine32Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMine32Dlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMine32Dlg, CDialog)
	//{{AFX_MSG_MAP(CMine32Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(IDM_TIME, OnTimeDlg)
	ON_COMMAND(IDM_EXIT, OnExit)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_UPDATE_COMMAND_UI(IDM_BEGINNER, OnUpdateBeginner)
	ON_UPDATE_COMMAND_UI(IDM_MIDDLE, OnUpdateMiddle)
	ON_UPDATE_COMMAND_UI(IDM_EXPERT, OnUpdateExpert)
	ON_UPDATE_COMMAND_UI(IDM_CUSTOM, OnUpdateCustom)
	ON_UPDATE_COMMAND_UI(IDM_MARK, OnUpdateMark)
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(IDC_BEGIN, OnBegin)
	ON_WM_RBUTTONUP()
	ON_WM_MBUTTONUP()
	ON_WM_MBUTTONDOWN()
	ON_COMMAND(IDM_ABOUT, OnAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMine32Dlg message handlers

BOOL CMine32Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hSmallIcon, FALSE);		// Set small icon
	
	x0[0]=1;  y0[0]=1;
	x0[1]=0;  y0[1]=1;
	x0[2]=-1; y0[2]=1;
	x0[3]=-1; y0[3]=0;
	x0[4]=-1; y0[4]=-1;
	x0[5]=0;  y0[5]=-1;
	x0[6]=1;  y0[6]=-1;
	x0[7]=1;  y0[7]=0;

	CClientDC dc(this);
	CBitmap Icon, Face, Num;
	IconsDC.CreateCompatibleDC(&dc);
	Icon.LoadBitmap(IDB_ICONS);
	IconsDC.SelectObject(&Icon);	
	FacesDC.CreateCompatibleDC(&dc);
	Face.LoadBitmap(IDB_FACES);
	FacesDC.SelectObject(&Face);	
	NumsDC.CreateCompatibleDC(&dc);
	Num.LoadBitmap(IDB_NUMBERS);
	NumsDC.SelectObject(&Num);

	MemDC.CreateCompatibleDC(&dc);
	CBitmap MemBitmap;
	MemBitmap.CreateCompatibleBitmap(&dc, 503, 322);
	MemDC.SelectObject(MemBitmap);
	
	HKEY hKey;
	DWORD dw = 0;
	DWORD dwType = 0;
	if (RegOpenKeyEx(HKEY_CURRENT_USER, "SoftWare\\Mine32", 0, KEY_QUERY_VALUE, &hKey) != ERROR_SUCCESS)
	{
		nWidth = nHeight = 8;
		nMines = 10;
		nDifficulty = 0;
		nTime[0] = nTime[1] = nTime[2] = 999;
		strName[0].LoadString(IDS_NONAME);
		strName[1] = strName[2] = strName[0];
		bMark = TRUE;
	}
	else
	{
		RegQueryValueEx(hKey, "Width", NULL, &dwType, (BYTE*)&nWidth, &dw);
		RegQueryValueEx(hKey, "Width", NULL, &dwType, (BYTE*)&nWidth, &dw);
		RegQueryValueEx(hKey, "Height", NULL, &dwType, (BYTE*)&nHeight, &dw);
		RegQueryValueEx(hKey, "Difficulty", NULL, &dwType, (BYTE*)&nDifficulty, &dw);
		RegQueryValueEx(hKey, "Mark", NULL, &dwType, (BYTE*)&bMark, &dw);
		RegQueryValueEx(hKey, "Mines", NULL, &dwType, (BYTE*)&nMines, &dw);
		RegQueryValueEx(hKey, "Time1", NULL, &dwType, (BYTE*)&nTime[0], &dw);
		RegQueryValueEx(hKey, "Time2", NULL, &dwType, (BYTE*)&nTime[1], &dw);
		RegQueryValueEx(hKey, "Time3", NULL, &dwType, (BYTE*)&nTime[2], &dw);
		TCHAR* lpsz;
		LONG lRes = RegQueryValueEx(hKey, "Name1", NULL, &dwType, NULL, &dw);
		if (lRes == ERROR_SUCCESS)
		{
			ASSERT(dwType == REG_SZ);
			lpsz = strName[0].GetBufferSetLength(dw);
			lRes = RegQueryValueEx(hKey, "Name1", NULL, &dwType, (BYTE*)lpsz, &dw);
			ASSERT(lRes == ERROR_SUCCESS);
			strName[0].ReleaseBuffer();
		}
		lRes = RegQueryValueEx(hKey, "Name2", NULL, &dwType, NULL, &dw);
		if (lRes == ERROR_SUCCESS)
		{
			ASSERT(dwType == REG_SZ);
			lpsz = strName[1].GetBufferSetLength(dw);
			lRes = RegQueryValueEx(hKey, "Name2", NULL, &dwType, (BYTE*)lpsz, &dw);
			ASSERT(lRes == ERROR_SUCCESS);
			strName[1].ReleaseBuffer();
		}
		lRes = RegQueryValueEx(hKey, "Name3", NULL, &dwType, NULL, &dw);
		if (lRes == ERROR_SUCCESS)
		{
			ASSERT(dwType == REG_SZ);
			lpsz = strName[2].GetBufferSetLength(dw);
			lRes = RegQueryValueEx(hKey, "Name3", NULL, &dwType, (BYTE*)lpsz, &dw);
			ASSERT(lRes == ERROR_SUCCESS);
			strName[2].ReleaseBuffer();
		}
	}
	nTime[0] = nTime[0] > 999 ? 999 : nTime[0];
	nTime[1] = nTime[1] > 999 ? 999 : nTime[1];
	nTime[2] = nTime[2] > 999 ? 999 : nTime[2];
	nTime[3] = 0;

	OnBegin();
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMine32Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMine32Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CClientDC dc(this);
		CRect rc;
		GetClientRect(&rc);
		dc.BitBlt(0, 0, rc.Width(), rc.Height(), &MemDC, 0, 0, SRCCOPY);
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMine32Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMine32Dlg::OnTimeDlg() 
{
	CTimeDlg TimeDlg;
	TimeDlg.DoModal();
}

void CMine32Dlg::OnExit() 
{
	PostQuitMessage(0);	
}

void CMine32Dlg::OnBegin() 
{
	int i, x, y;

	bBomb = bTime = bWin = FALSE;
	nClicked = 0;
	KillTimer(1);

	IniData();
	m_LastPoint.x = m_LastPoint.y = -1;	
	ZeroMemory(LClicked, sizeof(LClicked));
	ZeroMemory(RClicked, sizeof(RClicked));
	srand(GetTickCount());
	ZeroMemory(Mines, sizeof(Mines));
	for (i = 0; i < nMines; i ++)
	{
		x = 1 + (rand() % nWidth);
		y = 1 + (rand() % nHeight);
		if (GetBit(x, y))
			i --;
		SetBit(x, y);
	}

	CPen pen;
	CRect rc;
	GetClientRect(&rc);
	::FillRect(MemDC.m_hDC, &rc, (HBRUSH)GetStockObject(LTGRAY_BRUSH));
	MemDC.SelectStockObject(WHITE_PEN);
	MemDC.MoveTo(rc.right - 2, 0);
	MemDC.LineTo(0, 0);
	MemDC.LineTo(0, rc.bottom - 1);
	MemDC.MoveTo(rc.right - 3, 1);
	MemDC.LineTo(1, 1);
	MemDC.LineTo(1, rc.bottom - 2);
	MemDC.MoveTo(rc.right - 4, 2);
	MemDC.LineTo(2, 2);
	MemDC.LineTo(2, rc.bottom - 3);

	MemDC.MoveTo(m_Ground.left - 2, m_Ground.bottom + 2);
	MemDC.LineTo(m_Ground.right + 2, m_Ground.bottom + 2);
	MemDC.LineTo(m_Ground.right + 2, m_Ground.top - 3);
	MemDC.MoveTo(m_Ground.left - 1, m_Ground.bottom + 1);
	MemDC.LineTo(m_Ground.right + 1, m_Ground.bottom + 1);
	MemDC.LineTo(m_Ground.right + 1, m_Ground.top - 2);
	MemDC.MoveTo(m_Ground.left, m_Ground.bottom);
	MemDC.LineTo(m_Ground.right, m_Ground.bottom);
	MemDC.LineTo(m_Ground.right, m_Ground.top - 1);

	MemDC.MoveTo(m_Ground.left - 1, 44);
	MemDC.LineTo(m_Ground.right + 1, 44);
	MemDC.LineTo(m_Ground.right + 1, 10);
	MemDC.MoveTo(m_Ground.left - 2, 45);
	MemDC.LineTo(m_Ground.right + 2, 45);
	MemDC.LineTo(m_Ground.right + 2, 9);
	
	MemDC.MoveTo(m_Mines.left, m_Mines.bottom);
	MemDC.LineTo(m_Mines.right, m_Mines.bottom);
	MemDC.LineTo(m_Mines.right, m_Mines.top - 1);
	
	MemDC.MoveTo(m_Time.left, m_Time.bottom);
	MemDC.LineTo(m_Time.right, m_Time.bottom);
	MemDC.LineTo(m_Time.right, m_Time.top - 1);
	
	pen.CreatePen(PS_SOLID, 1, RGB(128, 128, 128));
	CPen *pOldPen = MemDC.SelectObject(&pen);
	MemDC.MoveTo(1, rc.bottom - 1);
	MemDC.LineTo(rc.right - 1, rc.bottom - 1);
	MemDC.LineTo(rc.right - 1, 0);
	MemDC.MoveTo(2, rc.bottom - 2);
	MemDC.LineTo(rc.right - 2, rc.bottom - 2);
	MemDC.LineTo(rc.right - 2, 1);
	MemDC.MoveTo(3, rc.bottom - 3);
	MemDC.LineTo(rc.right - 3, rc.bottom - 3);
	MemDC.LineTo(rc.right - 3, 2);
	
	MemDC.MoveTo(m_Ground.right + 1, m_Ground.top - 3);
	MemDC.LineTo(m_Ground.left - 3, m_Ground.top - 3);
	MemDC.LineTo(m_Ground.left - 3, m_Ground.bottom + 2);
	MemDC.MoveTo(m_Ground.right, m_Ground.top - 2);
	MemDC.LineTo(m_Ground.left - 2, m_Ground.top - 2);
	MemDC.LineTo(m_Ground.left - 2, m_Ground.bottom + 1);
	MemDC.MoveTo(m_Ground.right - 1, m_Ground.top - 1);
	MemDC.LineTo(m_Ground.left - 1, m_Ground.top - 1);
	MemDC.LineTo(m_Ground.left - 1, m_Ground.bottom);
	
	MemDC.MoveTo(m_Ground.right + 1, 9);
	MemDC.LineTo(m_Ground.left - 3, 9);
	MemDC.LineTo(m_Ground.left - 3, 45);
	MemDC.MoveTo(m_Ground.right, 10);
	MemDC.LineTo(m_Ground.left - 2, 10);
	MemDC.LineTo(m_Ground.left - 2, 44);

	MemDC.MoveTo(m_Mines.left - 1, m_Mines.bottom - 1);
	MemDC.LineTo(m_Mines.left - 1, m_Mines.top - 1);
	MemDC.LineTo(m_Mines.right, m_Mines.top - 1);
	
	MemDC.MoveTo(m_Time.left - 1, m_Time.bottom - 1);
	MemDC.LineTo(m_Time.left - 1, m_Time.top - 1);
	MemDC.LineTo(m_Time.right, m_Time.top - 1);
	
	MemDC.MoveTo(m_BeginButton.left - 1, m_BeginButton.bottom);
	MemDC.LineTo(m_BeginButton.left - 1, m_BeginButton.top - 1);
	MemDC.LineTo(m_BeginButton.right, m_BeginButton.top - 1);
	MemDC.MoveTo(m_BeginButton.left, m_BeginButton.bottom);
	MemDC.LineTo(m_BeginButton.right, m_BeginButton.bottom);
	MemDC.LineTo(m_BeginButton.right, m_BeginButton.top);
	
	MemDC.SelectObject(pOldPen);
	MemDC.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 96, SRCCOPY);
	nSeconds = 0;
	MemDC.BitBlt(m_Time.left, m_Time.top, 13, 23, &NumsDC, 0, 253, SRCCOPY);
	MemDC.BitBlt(m_Time.left + 13, m_Time.top, 13, 23, &NumsDC, 0, 253, SRCCOPY);
	MemDC.BitBlt(m_Time.left + 26, m_Time.top, 13, 23, &NumsDC, 0, 253, SRCCOPY);
	DrawMines();
	for (x = 0; x < nWidth; x ++)
		for (y = 0; y < nHeight; y ++)
			MemDC.BitBlt(XPos + (x << 4), YPos + (y << 4), 16, 16, &IconsDC, 0, 0, SRCCOPY);
	InvalidateRect(&m_Ground, FALSE);
}

void CMine32Dlg::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == 1)
	{
		nSeconds ++;
		int s;
		s = nSeconds % 10;
		MemDC.BitBlt(m_Time.left + 26, m_Time.top, 13, 23, &NumsDC, 0, 253 - s * 23, SRCCOPY);
		s = (nSeconds / 10) % 10;
		MemDC.BitBlt(m_Time.left + 13, m_Time.top, 13, 23, &NumsDC, 0, 253 - s * 23, SRCCOPY);
		s = (nSeconds / 100) % 10;
		MemDC.BitBlt(m_Time.left, m_Time.top, 13, 23, &NumsDC, 0, 253 - s * 23, SRCCOPY);
		InvalidateRect(&m_Time, FALSE);
	}

	CDialog::OnTimer(nIDEvent);
}

void CMine32Dlg::OnDestroy() 
{
	CDialog::OnDestroy();

	HKEY hKey;
	RegCreateKeyEx(HKEY_CURRENT_USER, "SoftWare\\Mine32", 0, "SoftWare\\Mine32", REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKey, NULL);
	RegSetValueEx(hKey, "Width", NULL, REG_DWORD, (BYTE*)&nWidth, 4);
	RegSetValueEx(hKey, "Height", NULL, REG_DWORD, (BYTE*)&nHeight, 4);
	RegSetValueEx(hKey, "Difficulty", NULL, REG_DWORD, (BYTE*)&nDifficulty, 4);
	RegSetValueEx(hKey, "Mark", NULL, REG_DWORD, (BYTE*)&bMark, 4);
	RegSetValueEx(hKey, "Mines", NULL, REG_DWORD, (BYTE*)&nMines, 4);
	RegSetValueEx(hKey, "Time1", NULL, REG_DWORD, (BYTE*)&nTime[0], 4);
	RegSetValueEx(hKey, "Time2", NULL, REG_DWORD, (BYTE*)&nTime[1], 4);
	RegSetValueEx(hKey, "Time3", NULL, REG_DWORD, (BYTE*)&nTime[2], 4);
	
	TCHAR* lpsz;
	lpsz = strName[0].GetBufferSetLength(strName[0].GetLength());
	RegSetValueEx(hKey, "Name1", NULL, REG_SZ, (BYTE*)lpsz, strName[0].GetLength()+1);
	strName[0].ReleaseBuffer();
	lpsz = strName[1].GetBufferSetLength(strName[1].GetLength());
	RegSetValueEx(hKey, "Name2", NULL, REG_SZ, (BYTE*)lpsz, strName[1].GetLength()+1);
	strName[1].ReleaseBuffer();
	lpsz = strName[2].GetBufferSetLength(strName[2].GetLength());
	RegSetValueEx(hKey, "Name3", NULL, REG_SZ, (BYTE*)lpsz, strName[2].GetLength()+1);
	strName[2].ReleaseBuffer();
}

void CMine32Dlg::OnUpdateBeginner(CCmdUI* pCmdUI) 
{
	CMenu *menu = GetMenu();
	menu->CheckMenuItem(IDM_BEGINNER, MF_CHECKED);
	menu->CheckMenuItem(IDM_MIDDLE, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_EXPERT, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_CUSTOM, MF_UNCHECKED);
	nDifficulty = 0;
	nWidth      = 8;
	nHeight     = 8;
	nMines      = 10;
	OnBegin();
	// TODO: Add your command update UI handler code here
}

void CMine32Dlg::OnUpdateMiddle(CCmdUI* pCmdUI) 
{
	CMenu *menu = GetMenu();
	menu->CheckMenuItem(IDM_BEGINNER, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_MIDDLE, MF_CHECKED);
	menu->CheckMenuItem(IDM_EXPERT, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_CUSTOM, MF_UNCHECKED);
	nDifficulty = 1;
	nWidth      = 16;
	nHeight     = 16;
	nMines      = 40;
	OnBegin();
}

void CMine32Dlg::OnUpdateExpert(CCmdUI* pCmdUI) 
{
	CMenu *menu = GetMenu();
	menu->CheckMenuItem(IDM_BEGINNER, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_MIDDLE, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_EXPERT, MF_CHECKED);
	menu->CheckMenuItem(IDM_CUSTOM, MF_UNCHECKED);
	nDifficulty = 2;
	nWidth      = 30;
	nHeight     = 16;
	nMines      = 99;
	OnBegin();
}

void CMine32Dlg::OnUpdateCustom(CCmdUI* pCmdUI) 
{
	CMenu *menu = GetMenu();
	menu->CheckMenuItem(IDM_BEGINNER, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_MIDDLE, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_EXPERT, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_CUSTOM, MF_CHECKED);

	CCustomDlg CustomDlg;
	CustomDlg.DoModal();
	nDifficulty = 3;
	OnBegin();
}

void CMine32Dlg::OnUpdateMark(CCmdUI* pCmdUI) 
{
	CMenu *menu = GetMenu();
	if (menu->GetMenuState(IDM_MARK, MF_BYCOMMAND) == MF_UNCHECKED)
		bMark = FALSE;
	else
		bMark = TRUE;
}


void CMine32Dlg::DrawMines()
{
	int s[3];

	if (nMines >= 0)
		s[2] = 253 - 23 * ((nMines / 100) % 10);
		
	else
		s[2] = 0;
	s[0] = 253 - 23 * (abs(nMines) % 10);	
	s[1] = 253 - 23 * ((abs(nMines) / 10) % 10);
	MemDC.BitBlt(m_Mines.left + 26, m_Mines.top, 13, 23, &NumsDC, 0, s[0], SRCCOPY);
	MemDC.BitBlt(m_Mines.left + 13, m_Mines.top, 13, 23, &NumsDC, 0, s[1], SRCCOPY);
	MemDC.BitBlt(m_Mines.left, m_Mines.top, 13, 23, &NumsDC, 0, s[2], SRCCOPY);	
}

void CMine32Dlg::IniData()
{
	nWidth = nWidth < 8 ? 8 : nWidth;
	nWidth = nWidth > 30 ? 30 : nWidth;
	nHeight = nHeight < 8 ? 8 : nHeight;
	nHeight = nHeight > 16 ? 16 : nHeight;
	nTotalMines = nMines = nMines < 10 ? 10 : nMines;
	nTotalMines = nMines = nMines > 99 ? 99 : nMines;
	nDifficulty = nDifficulty < 0 ? 0 : nDifficulty;
	nDifficulty = nDifficulty > 3 ? 3 : nDifficulty;
		
	CMenu *menu = GetMenu();
	menu->CheckMenuItem(IDM_BEGINNER, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_MIDDLE, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_EXPERT, MF_UNCHECKED);
	menu->CheckMenuItem(IDM_CUSTOM, MF_CHECKED);
	
	if (nDifficulty == 0)
	{
		nWidth      = 8;
		nHeight     = 8;
		nTotalMines = nMines = 10;
		menu->CheckMenuItem(IDM_BEGINNER, MF_CHECKED);
		menu->CheckMenuItem(IDM_CUSTOM, MF_UNCHECKED);
	}
	if (nDifficulty == 1)
	{
		nWidth      = 16;
		nHeight     = 16;
		nTotalMines = nMines = 40;
		menu->CheckMenuItem(IDM_MIDDLE, MF_CHECKED);
		menu->CheckMenuItem(IDM_CUSTOM, MF_UNCHECKED);
	}
	if (nDifficulty == 2)
	{
		nWidth      = 30;
		nHeight     = 16;
		nTotalMines = nMines = 99;
		menu->CheckMenuItem(IDM_EXPERT, MF_CHECKED);
		menu->CheckMenuItem(IDM_CUSTOM, MF_UNCHECKED);
	}
	if (nDifficulty == 3 && nWidth == 8 && nHeight == 8)
		nTotalMines = nMines = nMines > 49 ? 49 : nMines;
	
	m_Ground.SetRect(XPos, YPos, XPos + (nWidth << 4), YPos + (nHeight << 4));
	m_BeginButton.SetRect(XPos + (nWidth << 3) - 12, 16, XPos + (nWidth << 3) + 12, 40);
	m_Mines.SetRect(17, 16, 56, 39);
	m_Time.SetRect(m_Ground.right - 45, 16, m_Ground.right - 6, 39);
	SetWindowPos(NULL, 0, 0, m_Ground.Width() + 32, m_Ground.Height() + 111, SWP_NOZORDER | SWP_NOMOVE);
}

void CMine32Dlg::Sweep(int x, int y)
{
	int i, nCount = 0;
	for (i = 0; i < 8; i ++)
		nCount += GetBit(x + x0[i] + 1, y + y0[i] + 1);
	MemDC.BitBlt(XPos + (x << 4), YPos + (y << 4), 16, 16, &IconsDC, 0, 240-nCount*16, SRCCOPY);
	SetLClicked(x + 1, y + 1);
}

void CMine32Dlg::Flag(int x, int y)
{
	if (GetRClicked(x + 1, y + 1))
	{
		MemDC.BitBlt(XPos + (x << 4), YPos + (y<< 4), 16, 16, &IconsDC, 0, 0, SRCCOPY);
		SetR0Clicked(x + 1, y + 1);
		nMines ++;
	}
	else
	{
		MemDC.BitBlt(XPos + (x << 4), YPos + (y<< 4), 16, 16, &IconsDC, 0, 16, SRCCOPY);
		SetR1Clicked(x + 1, y + 1);
		nMines --;
	}
}

void CMine32Dlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	if (nFlags & MK_RBUTTON)
	{
		OnMButtonDown(nFlags, point);
		return;
	}
	CClientDC dc(this);
	if (m_BeginButton.PtInRect(point))
	{
		dc.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 0, SRCCOPY);
		MemDC.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 0, SRCCOPY);
	}
	if (bBomb | bWin)
		return;
	if (!m_Ground.PtInRect(point))
		return;
	dc.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 72, SRCCOPY);
	MemDC.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 72, SRCCOPY);
	int x, y;
	x = (point.x - XPos) >> 4;
	y = (point.y - YPos) >> 4;
	if (GetLClicked(x + 1, y + 1) || GetRClicked(x + 1, y + 1))
		return;
	dc.BitBlt(XPos + (x << 4), YPos + (y << 4), 16, 16, &IconsDC, 0, 240, SRCCOPY);
	m_LastPoint.x = x;
	m_LastPoint.y = y;
	InvalidateRect(&m_Ground, FALSE);

	CDialog::OnLButtonDown(nFlags, point);
}

void CMine32Dlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (nFlags & MK_RBUTTON)
	{
		OnMButtonUp(nFlags, point);
		return;
	}

	int i, nCount = 0;
	if (m_BeginButton.PtInRect(point))
	{	
		OnBegin();
		return;
	}
	if (bBomb | bWin)
		return;
	if (!bTime)
	{
		SetTimer(1, 1000, NULL);
		bTime = TRUE;
	}

	CClientDC dc(this);
	dc.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 96, SRCCOPY);
	MemDC.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 96, SRCCOPY);
	if (!m_Ground.PtInRect(point))
		return;
	int x, y;
	x = (point.x - XPos) >> 4;
	y = (point.y - YPos) >> 4;
	if (GetLClicked(x + 1, y + 1) || GetRClicked(x + 1, y + 1))
		return;
	if (GetBit(x + 1, y + 1) == 1)
	{
		bBomb = TRUE;
		dc.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 48, SRCCOPY);
		MemDC.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 48, SRCCOPY);
		MemDC.BitBlt(XPos + (x << 4), YPos + (y << 4), 16, 16, &IconsDC, 0, 48, SRCCOPY);
		KillTimer(1);
		bTime = FALSE;
	}
	else
	{
		//Sweep(x, y);
		for (i = 0; i < 8; i ++)
			nCount += GetBit(x + x0[i] + 1, y + y0[i] + 1);
		CClientDC dc(this);
		MemDC.BitBlt(XPos + (x << 4), YPos + (y << 4), 16, 16, &IconsDC, 0, 240 - (nCount << 4), SRCCOPY);
		SetLClicked(x + 1, y + 1);
		nClicked ++;
		if (nClicked == nWidth * nHeight - nTotalMines)
		{
			dc.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 24, SRCCOPY);
			MemDC.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 24, SRCCOPY);
			int j;
			CPoint pt;
			for (i = 0; i < nWidth; i ++)
				for (j = 0; j < nHeight; j ++)
					if (!(GetLClicked(i + 1, j + 1) || GetRClicked(i + 1, j + 1)))
					{
						pt.x = XPos + (i << 4);
						pt.y = YPos + (j << 4);
						nMines = 0;
						DrawMines();
						Flag(i, j);
					}
			KillTimer(1);
			bWin = TRUE;
			if (nSeconds < nTime[nDifficulty])
			{
				nTime[nDifficulty] = nSeconds;
				CGetName GNDlg;
				GNDlg.DoModal();
			}		
		}
	}
	InvalidateRect(&m_Ground, FALSE);

	if (nCount == 0)
	{
		CPoint pt;
		for (i = 0; i < 8; i ++)
		{
			pt.x = point.x + (x0[i] << 4);
			pt.y = point.y + (y0[i] << 4);
			OnLButtonUp(MK_LBUTTON, pt);
		}
	}
	
	CDialog::OnLButtonUp(nFlags, point);
}

void CMine32Dlg::OnRButtonDown(UINT nFlags, CPoint point) 
{
	if (bBomb | bWin)
		return;
	int x, y;
	x = (point.x - XPos) >> 4;
	y = (point.y - YPos) >> 4;
	if (!m_Ground.PtInRect(point))
		return;
	
	if (nFlags & MK_LBUTTON)
	{
		OnMButtonDown(nFlags, point);
		return;
	}
		
	if (GetLClicked(x + 1, y + 1))
		return;
	Flag(x, y);
	DrawMines();	
	InvalidateRect(&m_Ground, FALSE);
	
	CDialog::OnRButtonDown(nFlags, point);
}

void CMine32Dlg::OnRButtonUp(UINT nFlags, CPoint point) 
{
	if (bBomb | bWin)
		return;
	if (nFlags & MK_LBUTTON)
	{
		OnMButtonUp(nFlags, point);
		return;
	}
	
	CDialog::OnRButtonUp(nFlags, point);
}

void CMine32Dlg::OnMButtonUp(UINT nFlags, CPoint point) 
{
	if (bBomb | bWin)
		return;
	if (!m_Ground.PtInRect(point))
		return;
	
	CClientDC dc(this);
	dc.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 96, SRCCOPY);
	CPoint pt;
	int i, nCountL = 0, nCountR = 0;
	int	x = (point.x - XPos) >> 4;
	int y = (point.y - YPos) >> 4;
	
	for (i = 0; i < 8; i ++)
	{
		nCountL += GetBit(x + x0[i] + 1, y + y0[i] + 1);
		nCountR += GetRClicked(x + x0[i] + 1, y + y0[i] + 1);
	}
	if (nCountL != nCountR)
		return;

	for (i = 0; i < 8; i ++)
	{	
		pt.x = point.x + (x0[i] << 4);
		pt.y = point.y + (y0[i] << 4);
		OnLButtonUp(MK_LBUTTON, pt);
	}
	
	CDialog::OnMButtonUp(nFlags, point);
}

void CMine32Dlg::OnMButtonDown(UINT nFlags, CPoint point) 
{
	if (bBomb | bWin)
		return;
	
	CClientDC dc(this);
	dc.BitBlt(m_BeginButton.left, m_BeginButton.top, 24, 24, &FacesDC, 0, 72, SRCCOPY);
	CPoint pt;
	int i;
	int x, y;
	x = (point.x - XPos) >> 4;
	y = (point.y - YPos) >> 4;
	if (!GetLClicked(x + 1, y + 1))
		dc.BitBlt(XPos + (x << 4), YPos + (y << 4), 16, 16, &IconsDC, 0, 240, SRCCOPY);
	for (i = 0; i < 8; i ++)
	{	
		pt.x = XPos + ((x + x0[i]) << 4);
		pt.y = YPos + ((y + y0[i]) << 4);
		if (m_Ground.PtInRect(pt) && !GetLClicked(x + x0[i] + 1, y + y0[i] + 1) && !GetRClicked(x + x0[i] + 1, y + y0[i] + 1))
			dc.BitBlt(pt.x, pt.y, 16, 16, &IconsDC, 0, 240, SRCCOPY);
	}
	// TODO: Add your message handler code here and/or call default
	
	CDialog::OnMButtonDown(nFlags, point);
}

void CMine32Dlg::OnAbout() 
{
	CAboutDlg about;
	about.DoModal();
}

/*void CMine32Dlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (bBomb | bWin)
		return;

	CClientDC dc(this);
	int x, y;
	x = (point.x - XPos) >> 4;
	y = (point.y - YPos) >> 4;
	if (x == m_LastPoint.x && y == m_LastPoint.y)
		return;
	if (m_LastPoint.x == m_LastPoint.y == -1)
		return;	

	if ((nFlags & MK_LBUTTON) && (nFlags & MK_RBUTTON))
	{
		CPoint pt;
		int i;
		for (i = 0; i < 8; i ++)
		{	
			pt.x = XPos + ((m_LastPoint.x + x0[i]) << 4);
			pt.y = YPos + ((m_LastPoint.y + y0[i]) << 4);
			if (m_Ground.PtInRect(pt) && !GetLClicked(x + x0[i] + 1, y + y0[i] + 1) && !GetRClicked(x + x0[i] + 1, y + y0[i] + 1))
				dc.BitBlt(pt.x, pt.y, 16, 16, &IconsDC, 0, 240, SRCCOPY);
		}
		if (!m_Ground.PtInRect(point))
		{
			m_LastPoint.x = m_LastPoint.y = -1;
			return;
		}
		for (i = 0; i < 8; i ++)
		{	
			pt.x = XPos + ((x + x0[i]) << 4);
			pt.y = YPos + ((y + y0[i]) << 4);
			if (m_Ground.PtInRect(pt) && !GetLClicked(x + x0[i] + 1, y + y0[i] + 1) && !GetRClicked(x + x0[i] + 1, y + y0[i] + 1))
				dc.BitBlt(pt.x, pt.y, 16, 16, &IconsDC, 0, 240, SRCCOPY);
		}
	}

	if (nFlags & MK_LBUTTON)
	{
		if (GetLClicked(x + 1, y + 1))
			return;
		dc.BitBlt(XPos + (m_LastPoint.x << 4), YPos + (m_LastPoint.y << 4), 16, 16, &IconsDC, 0, 0, SRCCOPY);
		if (!m_Ground.PtInRect(point))
		{
			m_LastPoint.x = m_LastPoint.y = -1;
			return;
		}
		dc.BitBlt(XPos + (x << 4), YPos + (y << 4), 16, 16, &IconsDC, 0, 240, SRCCOPY);
	}
	m_LastPoint.x = x;
	m_LastPoint.y = y;
	
	CDialog::OnMouseMove(nFlags, point);
}
*/
