// TimeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Mine32.h"
#include "TimeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern int nTime[3];
CString strName[3];
/////////////////////////////////////////////////////////////////////////////
// CTimeDlg dialog


CTimeDlg::CTimeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTimeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTimeDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTimeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTimeDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTimeDlg, CDialog)
	//{{AFX_MSG_MAP(CTimeDlg)
	ON_WM_SHOWWINDOW()
	ON_BN_CLICKED(IDB_RESET, OnReset)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTimeDlg message handlers

void CTimeDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	char buf[24];
	char Sec[24];
	LoadString(AfxGetInstanceHandle(), IDS_SECOND, (char*)Sec, 24);
	sprintf(buf, Sec, nTime[0]);
	SetDlgItemText(IDC_TIME1, buf);
	sprintf(buf, Sec, nTime[1]);
	SetDlgItemText(IDC_TIME2, buf);
	sprintf(buf, Sec, nTime[2]);
	SetDlgItemText(IDC_TIME3, buf);
	SetDlgItemText(IDC_NAME1, strName[0]);
	SetDlgItemText(IDC_NAME2, strName[1]);
	SetDlgItemText(IDC_NAME3, strName[2]);
}

void CTimeDlg::OnReset() 
{
	nTime[0] = nTime[1] = nTime[2] = 999;
	strName[0].LoadString(IDS_NONAME);
	strName[1] = strName[2] = strName[0];
	OnShowWindow(TRUE, SW_SHOWNORMAL);
}
