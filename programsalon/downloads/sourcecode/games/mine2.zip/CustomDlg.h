#if !defined(AFX_CUSTOMDLG_H__7A767FC4_26EC_11D3_86F7_D283B67FD8ED__INCLUDED_)
#define AFX_CUSTOMDLG_H__7A767FC4_26EC_11D3_86F7_D283B67FD8ED__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// CustomDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCustomDlg dialog

class CCustomDlg : public CDialog
{
// Construction
public:
	CCustomDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCustomDlg)
	enum { IDD = IDD_CUSTOM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCustomDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCustomDlg)
	virtual void OnOK();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CUSTOMDLG_H__7A767FC4_26EC_11D3_86F7_D283B67FD8ED__INCLUDED_)
