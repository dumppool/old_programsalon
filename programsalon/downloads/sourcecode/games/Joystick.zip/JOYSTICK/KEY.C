#include <dos.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "joystick.h"

#define KEYBD   9

#ifndef __BORLANDC__
#define min(a, b)    (((a) < (b)) ? (a) : (b))
#define max(a, b)    (((a) > (b)) ? (a) : (b))
#endif

static int mode = JOY_2BUTTONS;
unsigned char       Keys[128];
void                interrupt (*oldvec)();
void                interrupt myInt();

void printstatus(unsigned char jready, unsigned int j0, unsigned int j1)
{
  /* Show status for both joysticks */

  char l[13][26];
  unsigned char j, o, ln;
  unsigned int jflags;

  strcpy(l[0],  "     �  �          �  �  ");
  strcpy(l[1],  "   �������-      �������-");
  strcpy(l[2],  "     �  �          �  �  ");
  strcpy(l[3],  "   ��������      �������-");
  strcpy(l[4],  "     �  �          �  �  ");
  strcpy(l[5],  "");
  strcpy(l[6],  "   A �  �        A �  �  ");
  strcpy(l[7],  "");
  strcpy(l[8],  "   B �  �        B �  �  ");
  strcpy(l[9],  "");
  strcpy(l[10], "   C �  �        C �  �  ");
  strcpy(l[11], "");
  strcpy(l[12], "   D �  �        D �  �  ");

  for (j = 0; j < 2; j++)
    if (jready & (j + 1))
    {
      jflags = j ? j1 : j0;
      if (jflags & JOY_UP)
      {
        ln = 0;
        if (jflags & JOY_LT || jflags & JOY_RT)
          o = (jflags & JOY_LT) ? 3 : 9;
        else
          o = 6;
      }
      else
        if (jflags & JOY_DN)
        {
          ln = 4;
          if (jflags & JOY_LT || jflags & JOY_RT)
            o = (jflags & JOY_LT) ? 3 : 9;
          else
            o = 6;
        }
        else
        {
          ln = 2;
          if (jflags & JOY_LT || jflags & JOY_RT)
            o = (jflags & JOY_LT) ? 3 : 9;
          else
            o = 6;
        }
      l[ln][o + (j ? 14 : 0)] = 0xDB;
      l[ln][o + (j ? 15 : 1)] = 0xDB;

      if (jflags & JOY_AF)
      {
        l[6][(j ? 20 : 6)] = 0xDB;
        l[6][(j ? 21 : 7)] = 0xDB;
      }

      if (jflags & JOY_BF)
      {
        l[8][(j ? 20 : 6)] = 0xDB;
        l[8][(j ? 21 : 7)] = 0xDB;
      }

      if (mode > JOY_2BUTTONS)
      {
        if (jflags & JOY_CF)
        {
          l[10][(j ? 20 : 6)] = 0xDB;
          l[10][(j ? 21 : 7)] = 0xDB;
        }

        if (jflags & JOY_DF)
        {
          l[12][(j ? 20 : 6)] = 0xDB;
          l[12][(j ? 21 : 7)] = 0xDB;
        }

        if (mode == JOY_6BUTTONS)
        {
          int i;

          for (i = 0; i < 9; i++)
            strcpy(l[i] + 17, "        ");

          l[10][17] = 'E';
          l[12][17] = 'F';

          if (jflags & JOY_EF)
          {
            l[10][20] = 0xDB;
            l[10][21] = 0xDB;
          }

          if (jflags & JOY_FF)
          {
            l[12][20] = 0xDB;
            l[12][21] = 0xDB;
          }

          goto end;
        }
      }
    }
end:
  for (j = 0; j < ((mode == JOY_2BUTTONS) ? 9 : 13); j++)
  {
    cputs(l[j]);
    cputs("\r\n");
  }
}

void interrupt myInt(void)
{
  register char x;
  char scanCode;

scanCode = inp(0x60);  /* read keyboard data port */
x = inp(0x61);
outp(0x61, (x | 0x80));
outp(0x61, x);
outp(0x20, 0x20);

Keys[scanCode & 127] = 1;
if (scanCode & 128)
    Keys[scanCode & 127] = 0;
}

void ReadKeyboard(unsigned int *first,unsigned int *second)
{
  int mask=0;
  if(Keys[0x48]) mask |= JOY_UP;         /*  up   key  */
  if(Keys[0x50]) mask |= JOY_DN;         /*  down key  */
  if(Keys[0x4b]) mask |= JOY_LT;         /*  left key  */
  if(Keys[0x4d]) mask |= JOY_RT;         /*  right key  */
  if(Keys[0x1e]) mask |= JOY_AF;         /*  "A" key  */
  if(Keys[0x2c]) mask |= JOY_BF;         /*  "Z" key  */
  if(Keys[0x1f]) mask |= JOY_CF;         /*  "S" key  */
  if(Keys[0x2d]) mask |= JOY_DF;         /*  "X" key  */
  if(Keys[0x20]) mask |= JOY_EF;         /*  "D" key  */
  if(Keys[0x2e]) mask |= JOY_FF;         /*  "C" key  */
  if (first)
    *first = mask;
  if (second)
    *second = mask;
}

int main(int argc, char *argv[])
{
  int j, i;
  unsigned int status[4], oldstat[2];
  unsigned char sr;
  char * cp;

  oldvec=getvect(KEYBD);
  setvect(KEYBD,myInt);
  clrscr();
  cprintf("JTEST - Joystick Test v1.1 / (C) 1997 Simone Zanella Productions\r\n\r\n");
  cprintf("Usage: JTEST [mode]\r\n");
  cprintf("Mode can be:   [0] = 2 buttons   1 = 4 buttons   2 = 6 buttons\r\n\r\n");

  /* Read mode (if specified) */
  if (argc > 1)
    mode = min(max(atoi(argv[1]), JOY_2BUTTONS), JOY_6BUTTONS);

  /* Build configuration file name (it will be located in JTEST.EXE directory) */
  cp = argv[0] + strlen(argv[0]) - 1;
  while (*cp != '.')
    cp--;
  strcpy(cp + 1, "JC");

  /* Initialize joystick(s) */
  sr = wherey();
  j = InstallJoystick(mode, JOY_NONE, argv[0]);
  gotoxy(1, sr);
  for (i = 0; i < 15; i++)
    delline();

  if (j)
  {
    cprintf("Joystick(s): %d. Mode: %d buttons\r\n",
           (j > 2) ? (mode == JOY_6BUTTONS ? 1 : 2) : 1, (mode + 1) * 2);
    cprintf("Keyboard: A=botton A   Z=botton B    S=botton C    X=botton D\r\n");
    cprintf("          D=botton E   C=botton F\r\n"); 
    cprintf("\r\nPress ESC to exit..\r\n\r\n");
    oldstat[0] = oldstat[1] = -1;
    sr = wherey();

    /* Wait for press ESC key*/
    while (Keys[1]!=1)
    {
      /* Read joystick(s) */
      ReadJoystick(&(status[0]), &(status[1]));
      ReadKeyboard(&(status[2]), &(status[3]));
      status[0]|=status[2];
      status[1]|=status[3];
      if (status[0] != oldstat[0] || status[1] != oldstat[1])
      {
        oldstat[0] = status[0];
        oldstat[1] = status[1];
        gotoxy(1, sr);
        /* Print status */
        printstatus(j, status[0], status[1]);
      }
    }

    /* Remove keypress from keyboard buffer */
    setvect(KEYBD,oldvec);
  }
  else
    cprintf("\r\nNo joysticks found.\r\n");
  return 0;
}
