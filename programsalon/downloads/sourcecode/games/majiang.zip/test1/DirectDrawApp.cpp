#include "Headers.h"
#include "DirectDrawApp.h"
#include "DirectDrawWin.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif


BEGIN_MESSAGE_MAP(DirectDrawApp, CWinApp)
	//{{AFX_MSG_MAP(DirectDrawApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

DirectDrawApp::DirectDrawApp()
{
	ddwin=0;
	m_pMainWnd=0;
}

BOOL DirectDrawApp::InitInstance()
{
	ASSERT(m_pMainWnd);
	m_pMainWnd->ShowWindow( SW_SHOWNORMAL );
	m_pMainWnd->UpdateWindow();
	ShowCursor( FALSE );

	return TRUE;
}

BOOL DirectDrawApp::OnIdle(LONG) 
{
	if (ddwin->PreDrawScene())
		ddwin->DrawScene();
	return TRUE;
}

int DirectDrawApp::ExitInstance() 
{
	delete ddwin;
	
	return CWinApp::ExitInstance();
}
