#include "Headers.h"
#include "resource.h"
#include "DriverDialog.h"
#include "test1Win.h"
#include <mmsystem.h>
#include <mmreg.h>

#pragma comment (lib,"ddraw.lib")
#pragma comment (lib,"dinput.lib")
#pragma comment (lib,"dxguid.lib")
#pragma comment (lib,"winmm.lib")

const DWORD desiredwidth=640;
const DWORD desiredheight=480;
const DWORD desireddepth=8;

BEGIN_MESSAGE_MAP(test1Win, DirectDrawWin)
	//{{AFX_MSG_MAP(test1Win)
	ON_WM_DESTROY()
	ON_WM_CREATE()
	ON_WM_ACTIVATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

////////////////////////////////
DWORD dwFrameTime = 0;    // Time of the last frame.
DWORD dwFrames = 0;       // The frame rate (frames/second).
DWORD dwFrameCount = 0;   // Frames displayed.

HRESULT DDCopyBitmap(LPDIRECTDRAWSURFACE pdds, HBITMAP hbm, int x, int y, int dx, int dy);
////////////////////////////////

test1Win::test1Win()
{
	x=100;
	y=400;
	hand=0;
	dinput=0;
	keyboard=0;
	ZeroMemory(key, sizeof(key));
}

BOOL test1Win::CreateCustomSurfaces()
{
	// create your surfaces here...
	LPDIRECTDRAWSURFACE tmp;
	tmp=CreateSurface("img\\a1.bmp");
	CPai::SetIndexBmp(tmp);
    hand=CreateSurface("img\\hand.bmp", TRUE);
	RECT rect;
	GetSurfaceRect(hand, rect);
	bak=CreateSurface(rect.right-rect.left, rect.bottom-rect.top);

	DDCOLORKEY ddck;
	ddck.dwColorSpaceLowValue  = 0;
	ddck.dwColorSpaceHighValue = 0;
	hand->SetColorKey(DDCKEY_SRCBLT, &ddck);

	return TRUE;
}

void test1Win::DrawScene()
{
//	blt surfaces to the back buffer (backsurf)
//�õ���ʱ״̬�İ���
	keyboard->GetDeviceState(sizeof(key), &key);
	ReadKeyboard();

	BltSurface( backsurf, mj.GetSurface(ddraw2), x, y );

	static unsigned old=0;

	if(old!=mj.GetCur())
	{
		int n=x+(old-1)*25+5;
		if(old>0)
		{
			backsurf->BltFast(n, y+20, bak, 0, DDBLTFAST_WAIT);
			primsurf->BltFast(n, y+20, bak, 0, DDBLTFAST_WAIT);
		}

		old=mj.GetCur();
		RECT rect;
		rect.left  =x+(old-1)*25+5;
		rect.top   =y+20;
		rect.right =rect.left+21;
		rect.bottom=rect.top+30;
		bak->BltFast(0, 0, backsurf, &rect, DDBLTFAST_WAIT);
	}

	backsurf->BltFast(x+(mj.GetCur()-1)*25+5, y+20, hand, 0, DDBLTFAST_SRCCOLORKEY|DDBLTFAST_WAIT);
	ShowFPS();
	
	primsurf->Flip( 0, DDFLIP_WAIT );
}

void test1Win::RestoreSurfaces()
{
//	reclain lost surfaces with the DirectDrawSurface Restore() function

//	depending on the surface's function, it may be necessary to restore
//	surface content as well

}

int test1Win::SelectDriver()
{
	int numdrivers=GetNumDrivers();
	if (numdrivers==1)
		return 0;

	CArray<CString, CString> drivers;
	for (int i=0;i<numdrivers;i++)
	{
		LPSTR desc, name;
		GetDriverInfo( i, 0, &desc, &name );
		drivers.Add(desc);
	}

	DriverDialog dialog;
	dialog.SetContents( &drivers );
	if (dialog.DoModal()!=IDOK)
		return -1;

	return dialog.GetSelection();
}

int test1Win::SelectInitialDisplayMode()
{
	DWORD curdepth=GetDisplayDepth();
	int i, nummodes=GetNumDisplayModes();
	DWORD w,h,d;

	if (curdepth!=desireddepth)
		ddraw2->SetDisplayMode( 640, 480, curdepth, 0, 0 );

	for (i=0;i<nummodes;i++)
	{
		GetDisplayModeDimensions( i, w, h, d );
		if (w==desiredwidth && h==desiredheight && d==desireddepth)
			return i;
	}

	for (i=0;i<nummodes;i++)
	{
		GetDisplayModeDimensions( i, w, h, d );
		if (d==desireddepth)
			return i;
	}

	return 0;
}

/////////////////////////////Globals
HRESULT DDCopyBitmap(LPDIRECTDRAWSURFACE pdds, HBITMAP hbm, int x, int y, int dx, int dy)
{
    HDC                     hdcImage;
    HDC                     hdc;
    BITMAP                  bm;
    DDSURFACEDESC           ddsd;
    HRESULT                 hr;

    if (hbm == NULL || pdds == NULL)
        return E_FAIL;
    //
    // Make sure this surface is restored.
    //


    pdds->Restore();
    //
    // Select bitmap into a memoryDC so we can use it.
    //
    hdcImage = CreateCompatibleDC(NULL);
    if (!hdcImage)
        OutputDebugString("createcompatible dc failed\n");
    SelectObject(hdcImage, hbm);
    //
    // Get size of the bitmap
    //
    GetObject(hbm, sizeof(bm), &bm);
    dx = dx == 0 ? bm.bmWidth : dx;     // Use the passed size, unless zero
    dy = dy == 0 ? bm.bmHeight : dy;
    //
    // Get size of surface.
    //
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_HEIGHT | DDSD_WIDTH;
    pdds->GetSurfaceDesc(&ddsd);

    if ((hr = pdds->GetDC(&hdc)) == DD_OK)
    {
        StretchBlt(hdc, 0, 0, ddsd.dwWidth, ddsd.dwHeight, hdcImage, x, y,
                   dx, dy, SRCCOPY);
        pdds->ReleaseDC(hdc);
    }
    DeleteDC(hdcImage);
    return hr;
}


void test1Win::OnDestroy() 
{
	// TODO: Add your message handler code here
	hand->Release(), hand=0;
	bak->Release(), bak=0;
	CPai::DeleteIndexBmp();
	mj.Release();

	dinput->Release(), dinput=0;
	if(keyboard)
	{
		keyboard->Unacquire();
		keyboard->Release(), keyboard=0;
	}

	DirectDrawWin::OnDestroy();
}

void test1Win::ShowFPS()
{
    dwFrameCount++;
    DWORD dwTime = timeGetTime() - dwFrameTime;
    if ( dwTime > 1000 )
    {
        dwFrames = ( dwFrameCount*1000 )/dwTime;
        dwFrameTime = timeGetTime();
        dwFrameCount = 0;
    }
	HDC hdc;
	backsurf->GetDC(&hdc);
	CString msg;
	msg.Format("fps =%3d", dwFrames);
	COLORREF c1=SetTextColor(hdc, RGB(255,255,0));
	COLORREF c2=SetBkColor(hdc, 0);
	TextOut(hdc, 0, 0, msg, msg.GetLength());
	SetTextColor(hdc, c1);
	SetBkColor(hdc, c2);
	backsurf->ReleaseDC(hdc);
}

BOOL test1Win::InitKeyboard()
{
	if( dinput==NULL )
		return FALSE;

	if( dinput->CreateDevice(GUID_SysKeyboard, &keyboard, 0)==DI_OK )
	{
		if( keyboard->SetDataFormat(&c_dfDIKeyboard)==DI_OK )
		{
			if( keyboard->SetCooperativeLevel(GetSafeHwnd(), DISCL_FOREGROUND | DISCL_NONEXCLUSIVE ) !=DI_OK )
				return FALSE;
		}
		else
			return FALSE;
	}
	else
		return FALSE;

	DIPROPDWORD diprop;
	diprop.diph.dwSize = sizeof(DIPROPDWORD);
	diprop.diph.dwHeaderSize = sizeof(DIPROPHEADER);
	diprop.diph.dwObj = 0;
	diprop.diph.dwHow = DIPH_DEVICE;
	diprop.dwData = 64;

	if(keyboard->SetProperty(DIPROP_BUFFERSIZE, &diprop.diph)!=DI_OK)
	{
		Fatal("���û������ʧ�ܡ�");
		return FALSE;
	}

	return TRUE;
}

int test1Win::BufKey()
{
	if( keyboard==NULL )
		return 0;

	DIDEVICEOBJECTDATA data;
	DWORD item=1;
	HRESULT hr = 0L;

	ZeroMemory(&data, sizeof(DIDEVICEOBJECTDATA));
	hr=keyboard->GetDeviceData(
		sizeof(DIDEVICEOBJECTDATA),
		&data,
		&item,
		0);

	if(hr==DIERR_INPUTLOST)
	{
		if(keyboard != NULL)
			keyboard->Acquire();
	    else 
		{
			if(keyboard != NULL)
				keyboard->Unacquire();
		}

		hr=keyboard->GetDeviceData(
			sizeof(DIDEVICEOBJECTDATA),
			&data,
			&item,
			0);
		if (hr!=DI_OK)
			return 0;
	}

	if (item==0)
		return 0;
	if (data.dwData&0x80) 
		return data.dwOfs;
	else
		return 0;
}

void test1Win::ReadKeyboard()
{
//////////////////
//�Ի�����̵Ĵ���
	int nBufKey = 0;
	nBufKey = BufKey();

	switch(nBufKey)
	{
	case DIK_ESCAPE:
		PostMessage( WM_CLOSE );
	    break;

	case DIK_LEFT:
		mj.Left();
		break;

	case DIK_RIGHT:
		mj.Right();
		break;

	case DIK_RETURN:
		mj.Sort();
		break;
}

////////////////////////
//�Լ�ʱ״̬�¼��̵Ĵ���
	if( (key[DIK_SPACE]&0x80) )
	{
		mj.Init();
	}
}

int test1Win::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	// TODO: Add your specialized creation code here
//��ʼ��DIRECTINPUT
	if( DirectInputCreate(AfxGetInstanceHandle(), DIRECTINPUT_VERSION, &dinput, 0)!=DI_OK )
	{
		Fatal("��ʼ��DIRECTINPUTʧ�ܡ�");
		return -1;
	}
	if( InitKeyboard()==FALSE )
	{
		Fatal("��ʼ��DIRECTINPUT����ʧ�ܡ�");
		return -1;
	}
	
	if (DirectDrawWin::OnCreate(lpCreateStruct) == -1)
		return -1;
	return 0;
}

void test1Win::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	DirectDrawWin::OnActivate(nState, pWndOther, bMinimized);
	
	// TODO: Add your message handler code here
	if (nState!=WA_INACTIVE)
	{
		if (keyboard)
		{
			TRACE("keyboard->Acquire()\n");
			keyboard->Acquire();
		}
	}
}
