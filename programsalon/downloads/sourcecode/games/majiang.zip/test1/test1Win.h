#ifndef TEST1WIN_H
#define TEST1WIN_H


#include "DirectDrawWin.h"
#include "MaJiang.h"
#include <dinput.h>

class test1Win : public DirectDrawWin
{
public:
	int BufKey();
	test1Win();
protected:
	void ReadKeyboard();
	BOOL InitKeyboard();
	void ShowFPS();
	//{{AFX_MSG(test1Win)
	afx_msg void OnDestroy();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int SelectDriver();
	int SelectInitialDisplayMode();
	BOOL CreateCustomSurfaces();
	void DrawScene();
	void RestoreSurfaces();

	LPDIRECTINPUT dinput;        //DIRECTINPUT�Ľӿڶ���
	LPDIRECTINPUTDEVICE keyboard;//DIRECTINPUT�ļ����豸
    char key[256];               //���а���������
	
	LPDIRECTDRAWSURFACE hand;
	LPDIRECTDRAWSURFACE bak;
	CMaJiang mj;
	unsigned x,y;
};


#endif
