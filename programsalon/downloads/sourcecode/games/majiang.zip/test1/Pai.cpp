#include "stdafx.h"
#include "Pai.h"

LPDIRECTDRAWSURFACE CPai::index=NULL;

CPai::CPai()
{
	style=0;
	number=0;
}

void CPai::Init(unsigned a, unsigned b)
{
	style=a;
	number=b;
}

void CPai::GetInfo(unsigned &a, unsigned &b)
{
	a=style;
	b=number;
}

void CPai::GetSurface(LPDIRECTDRAWSURFACE & surf)
{
ASSERT(index);
	RECT rect;
	rect.left  =(number-1)*25;
	rect.top   =(style-1)*35;
	rect.right =rect.left+25;
	rect.bottom=rect.top+35;
	surf->BltFast(0, 0, index, &rect, DDBLTFAST_WAIT);
}

LPDIRECTDRAWSURFACE CPai::GetIndexBmp()
{
ASSERT(index);
	return index;
}

CPai::SetIndexBmp(LPDIRECTDRAWSURFACE & surf)
{
	if(index)
		index->Release(), index=NULL;
	index=surf;
}

CPai::DeleteIndexBmp()
{
	if(index)
		index->Release(), index=NULL;
}

CPai::~CPai()
{
}
