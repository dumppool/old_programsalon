#ifndef TEST1APP_H
#define TEST1APP_H


#include "DirectDrawApp.h"

class test1App : public DirectDrawApp
{
public:
	BOOL  InitInstance();
protected:
	//{{AFX_MSG(test1App)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#endif
