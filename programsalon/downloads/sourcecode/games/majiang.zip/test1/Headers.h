#include <AfxWin.h>
#include <AfxExt.h>
#include <AfxTempl.h>
#include <fstream.h>
#include <math.h>
#include <ddraw.h>
