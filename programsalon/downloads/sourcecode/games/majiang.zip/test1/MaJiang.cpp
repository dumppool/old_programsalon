#include "stdafx.h"
#include "MaJiang.h"

CMaJiang::CMaJiang()
{
	Init();
}

void CMaJiang::Init()
{
	ZeroMemory(pai, sizeof(CPai)*13);//���ԭʼ����

	srand( GetTickCount() );
	for(int n=0; n<13;)//��������Ƶ�ֵ,��ͬ���Ʋ��ܳ���4��
	{
 		unsigned a=0, b=0;
		while((a=rand()%5)==0);
		while(((b=rand()%10)==0)||(b>7&&a==4));

		bool bInsert=true;
		if(n>0)
		{
			int nRepeat=0;
			for(int m=0; m<n; m++)
			{
				unsigned c=0,d=0;
				pai[m].GetInfo(c,d);
				if( a==c && b==d )
				{
					if(++nRepeat==4)
					{
						bInsert=false;
						break;
					}
				}
			}
		}
		if(bInsert)
			pai[n++].Init(a, b);
	}
	info=0x1fff;
	cur=13;
	parent=0;
}

void CMaJiang::Left()
{
	if(cur>1)
		cur--;
}

void CMaJiang::Right()
{
	if(cur<GetWidth())
		cur++;
}

LPDIRECTDRAWSURFACE CMaJiang::GetSurface(const LPDIRECTDRAW2 & ddraw2)
{
	unsigned w=GetWidth();//��ʣ����
	if(w==0)
		return NULL;

	DDSURFACEDESC desc;
	ZeroMemory( &desc, sizeof(desc) );
	desc.dwSize = sizeof(desc);
	desc.dwFlags = DDSD_WIDTH | DDSD_HEIGHT | DDSD_CAPS;
	desc.dwWidth = w*25;
	desc.dwHeight = 35;
	desc.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_VIDEOMEMORY;

	if(parent)
		parent->Release(), parent=0;

	HRESULT r=ddraw2->CreateSurface( &desc, &parent, 0 );
	if (r!=DD_OK)
	{
		desc.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
		r=ddraw2->CreateSurface( &desc, &parent, 0 );
		if (r!=DD_OK)
		{
			TRACE("CreateSurface \"parent\" failed\n");
			return NULL;
		}
	}

	ZeroMemory( &desc, sizeof(desc) );
	desc.dwSize = sizeof(desc);
	desc.dwFlags = DDSD_WIDTH | DDSD_HEIGHT | DDSD_CAPS;
	desc.dwWidth = 25;
	desc.dwHeight = 35;
	desc.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_VIDEOMEMORY;

	DDBLTFX bltfx;
	ZeroMemory( &bltfx, sizeof(bltfx) );
	bltfx.dwSize = sizeof(bltfx);
	bltfx.dwFillColor = 0;
	r=parent->Blt( 0, 0, 0, DDBLT_COLORFILL | DDBLT_WAIT, &bltfx );
	if (r!=DD_OK)
	{
		TRACE("ClearSurface \"parent\" failed\n");
		return NULL;
	}

	LPDIRECTDRAWSURFACE surf;
	r=ddraw2->CreateSurface( &desc, &surf, 0 );
	if (r!=DD_OK)
	{
		desc.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
		r=ddraw2->CreateSurface( &desc, &surf, 0 );
		if (r!=DD_OK)
		{
			TRACE("CreateSurface \"surf\" failed\n");
			return NULL;
		}
	}

	int m=0;
	for(int n=1; n<=0x1fff; n*=2, m++)
	{
		if(info&n)
		{
			pai[m].GetSurface(surf);
			parent->BltFast(m*25, 0, surf, 0, DDBLTFAST_WAIT);
		}
	}

	surf->Release(), surf=NULL;

	return parent;
}

unsigned CMaJiang::GetWidth()
{
	unsigned w=0;//�����13λ��Ϊ1  �����Ϊ0x1fff
	for(int n=1; n<=0x1fff; n*=2)
		if(info&n)
			w++;
	return w;
}

unsigned CMaJiang::GetCur()
{
	return cur;
}

void CMaJiang::Release()
{
	if(parent)
		parent->Release(), parent=0;
}

int comp(const void *, const void *);
//int comp1(const void *, const void *);
void CMaJiang::Sort()
{
	//��������Ͳ�����˳��ʹ�С��������
	qsort( pai, GetWidth(), sizeof(CPai), comp );
	return;
	
/*���취
	unsigned w[13], t[13], o[13], f[13];
	int w1, t1, o1, f1;
	w1=t1=o1=f1=0;
	ZeroMemory(w,13);
	ZeroMemory(t,13);
	ZeroMemory(o,13);
	ZeroMemory(f,13);
	for(int n=0; n<13; n++)
	{
		unsigned a=0,b=0;
		pai[n].GetInfo(a,b);
		switch(a)
		{
		case 1:
			w[w1++]=b;
			break;
		case 2:
			t[t1++]=b;
			break;
		case 3:
			o[o1++]=b;
			break;
		case 4:
			f[f1++]=b;
			break;
		}
	}

	qsort(w, w1, sizeof(unsigned), comp1);
	qsort(t, t1, sizeof(unsigned), comp1);
	qsort(o, o1, sizeof(unsigned), comp1);
	qsort(f, f1, sizeof(unsigned), comp1);

	n=0;
	for(int m=0; n<w1; n++, m++)
		pai[n].Init(1, w[m]);
	for(m=0; n<w1+t1; n++, m++)
		pai[n].Init(2, t[m]);
	for(m=0; n<o1+t1+w1; n++, m++)
		pai[n].Init(3, o[m]);
	for(m=0; n<13; n++, m++)
		pai[n].Init(4, f[m]);
*/
}

int comp(const void *x, const void *y)
{
	unsigned a,b,c,d;
	a=b=c=d=0;
	((CPai *)x)->GetInfo(a, b);
	((CPai *)y)->GetInfo(c, d);

	if(a!=c)
		return a-c;
	else
		return b-d;
}
/*
int comp1(const void *a, const void *b)
{
	return (*(int *)a-*(int *)b);
}
*/