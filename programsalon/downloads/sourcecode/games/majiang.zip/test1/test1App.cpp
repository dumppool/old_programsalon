#include "Headers.h"
#include "resource.h"
#include "test1App.h"
#include "test1Win.h"


BEGIN_MESSAGE_MAP(test1App, DirectDrawApp)
	//{{AFX_MSG_MAP(test1App)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

test1App theapp;

BOOL test1App::InitInstance()
{
#ifdef _DEBUG
//	afxTraceEnabled=FALSE;
#endif
	test1Win* win=new test1Win;
	if (!win->Create( "High Performance test1 Demo", IDI_ICON ))
		return FALSE;

	m_pMainWnd=win;
	return DirectDrawApp::InitInstance();
}
