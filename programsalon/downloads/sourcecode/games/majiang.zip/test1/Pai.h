#ifndef _PAI_H
#define _PAI_H

#include "ddraw.h"
class CPai
{
public:
	CPai();
	void Init(unsigned, unsigned);
	void GetInfo(unsigned &, unsigned &);
	static LPDIRECTDRAWSURFACE GetIndexBmp();
	static SetIndexBmp(LPDIRECTDRAWSURFACE &);
	void GetSurface(LPDIRECTDRAWSURFACE &);
	static DeleteIndexBmp();
	~CPai();

private:
	unsigned style;  //����
	unsigned number; //�ڼ�����
	static LPDIRECTDRAWSURFACE index; //�����齫��ͼƬ
};

#endif