// ha.h: interface for the ha class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HA_H__C894E560_E53E_11D2_B5CF_5254AB16944E__INCLUDED_)
#define AFX_HA_H__C894E560_E53E_11D2_B5CF_5254AB16944E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ha  
{
public:
	ha();
	virtual ~ha();

};

#endif // !defined(AFX_HA_H__C894E560_E53E_11D2_B5CF_5254AB16944E__INCLUDED_)
