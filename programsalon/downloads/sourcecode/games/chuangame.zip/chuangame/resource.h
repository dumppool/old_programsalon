//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by niu1.rc
//
#define IDT_KONG                        1
#define IDM_FIRST                       1
#define IDT_KONGJ                       2
#define IDM_SECOND                      2
#define IDT_KONGXC                      3
#define IDM_THIRD                       3
#define IDT_KONGYC                      4
#define IDM_FORTH                       4
#define IDT_LNIU                        5
#define IDM_FIFTH                       5
#define IDT_LXIANSHANG                  6
#define IDM_SIXTH                       6
#define IDT_LXIANXIA                    7
#define IDT_LXIANYOU                    8
#define IDT_LXIANZUO                    9
#define IDT_NIU                         10
#define IDT_XIANSHANG                   11
#define IDT_XIANSY                      12
#define IDT_XIANSZ                      13
#define IDT_XIANXC                      14
#define IDT_XIANXIA                     15
#define IDT_XIANXY                      16
#define IDT_XIANXZ                      17
#define IDT_XIANYC                      18
#define IDT_XIANYOU                     19
#define IDT_XIANZUO                     20
#define IDB_BITMAP1                     101
#define IDT_KONGd                       137
#define df                              137
#define IDM_BEGINGAME                   40002
#define IDM_PAUSEGAME                   40003
#define IDM_GAMEOVER                    40004
#define IDM_CLOSEGAME                   40005
#define IDM_PAIHANG                     40012
#define IDM_ABOUT                       40014
#define IDM_GOON                        40015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         40015
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
