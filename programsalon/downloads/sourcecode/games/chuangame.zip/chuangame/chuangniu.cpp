#include <windows.h>
#include "resource.h"
#include "chuanniu.h"
#include "time.h"
LRESULT  CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM) ;
static   HBITMAP hBitmap[20];
int Map[12][12],bakMap[12][12];
int QiziNumber=70;
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
{
     static TCHAR szAppName [] ="ChuanNiukou";
	 HWND         hwnd ;
     HBRUSH       hBrush;
	 HBITMAP      hMainBitmap;
	 MSG          msg ;
     WNDCLASS     wndclass ;
     
	 hMainBitmap=LoadBitmap(hInstance,"main");
	 hBrush=CreatePatternBrush(hMainBitmap);
	 DeleteObject(hMainBitmap);
	 wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
     wndclass.lpfnWndProc   = WndProc ;
     wndclass.cbClsExtra    = 0 ;
     wndclass.cbWndExtra    = 0 ;
     wndclass.hInstance     = hInstance ;
     wndclass.hIcon         = LoadIcon (hInstance,szAppName) ;
     wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
     wndclass.hbrBackground = hBrush ;
     wndclass.lpszMenuName  = szAppName ;
     wndclass.lpszClassName = szAppName ;
     
     if (!RegisterClass (&wndclass))
     {
          MessageBox (NULL, TEXT ("This program requires Windows NT!"),
                      szAppName, MB_ICONERROR) ;
          return 0 ;
     }
     
     hwnd = CreateWindow(szAppName, TEXT ("���Ӵ�Ŧ��Ϸ��ʾ��"), 
                          WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX, 
                          150,150,
                          453,341,
                          NULL, NULL, hInstance, NULL) ;

     ShowWindow (hwnd, iCmdShow) ;
     UpdateWindow (hwnd) ;

     while (GetMessage (&msg, NULL, 0, 0))
     {
          TranslateMessage (&msg) ;
          DispatchMessage (&msg) ;
     }
	 DeleteObject(hBrush);
     return msg.wParam ;
}

LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	 static HWND    hchildwnd1,hchildwnd2,hchildwnd3;
	 static int     Level=IDM_FIRST;
	 static HMENU   hMenu;
	 static BOOL    ifBegin=FALSE;
	 int            x,y;
	 static int     xSource=0,ySource=0,iflag=0;
	 HDC            hdc;
	 HINSTANCE      hInstance;   
     TCHAR    szJibie[30];
     TCHAR    szFenshu[30];
	 int            xposition,yposition;
	 PAINTSTRUCT ps ;
    
	 switch (message)
     {
     case WM_CREATE:
		  hMenu=GetMenu(hwnd);
		  hInstance=((LPCREATESTRUCT)lParam)->hInstance;
		  ClearQipan();
		  LoadAllBitmap(hInstance);
		  hchildwnd1=CreateWindow("static","�÷�:(��ʾ���޴˹���)",WS_CHILD|WS_VISIBLE|WS_EX_STATICEDGE|SS_CENTERIMAGE,280,50,130,30,hwnd,(HMENU)1,hInstance,NULL);
		  hchildwnd2=CreateWindow("static","ʣ��:         70",WS_CHILD|WS_VISIBLE|WS_EX_STATICEDGE|SS_CENTERIMAGE,280,120 ,130,30,hwnd,(HMENU)2,hInstance,NULL);
		  hchildwnd3=CreateWindow("static","����:          1",WS_CHILD|WS_VISIBLE|WS_EX_STATICEDGE|SS_CENTERIMAGE,280,190,130,30,hwnd,(HMENU)3,hInstance,NULL);
		  return 0;
	 case WM_PAINT:
		  hdc=BeginPaint(hwnd,&ps);
		  DrawJiemian(hchildwnd1,hchildwnd2,hchildwnd3,hdc);
	      DrawQipan(hdc,hInstance,hwnd);
		  EndPaint(hwnd,&ps);
		  return 0;
     case WM_COMMAND:
		  switch(LOWORD(wParam))
		  {	  
		  case IDM_BEGINGAME:
			   KillTimer(hwnd,Level);
			   iflag=0;
			   QiziNumber=70;
			   InitQiziLink();
			   ifBegin=TRUE;
			   ClearQipan();
			   InitLink();
               DrawQizi(15,hwnd,hchildwnd2,IDT_NIU);
			   EnableMenuItem(hMenu,IDM_PAUSEGAME,MF_ENABLED);
			   EnableMenuItem(hMenu,IDM_GAMEOVER,MF_ENABLED);
			   for(x=1;x<=6;x++)
				   EnableMenuItem(hMenu,x,MF_GRAYED);
			   SetTimer(hwnd,Level,1200/Level,NULL);
			   return 0;
		  case IDM_PAUSEGAME:
			   EnableMenuItem(hMenu,IDM_BEGINGAME,MF_GRAYED);
			   EnableMenuItem(hMenu,IDM_GAMEOVER,MF_GRAYED);
			   ModifyMenu(hMenu,IDM_PAUSEGAME,NULL,IDM_GOON,"������Ϸ������F3");
			   KillTimer(hwnd,Level);
			   ifBegin=FALSE;
			   return 0;
		  case IDM_GOON:
			   EnableMenuItem(hMenu,IDM_BEGINGAME,MF_ENABLED);
			   EnableMenuItem(hMenu,IDM_GAMEOVER,MF_ENABLED);
			   ModifyMenu(hMenu,IDM_GOON,NULL,IDM_PAUSEGAME,"��ͣ��Ϸ������F3");
			   SetTimer(hwnd,Level,1200/Level,NULL);
			   ifBegin=TRUE;
			   return 0;
		  case IDM_FIRST:
	      case IDM_SECOND:
	      case IDM_THIRD:
	      case IDM_FORTH:
	      case IDM_FIFTH:
	      case IDM_SIXTH:
		       CheckMenuItem(hMenu,Level,MF_UNCHECKED);
		       Level=LOWORD(wParam);
		       CheckMenuItem(hMenu,Level,MF_CHECKED);
		       wsprintf(szJibie,"����:��     %d",Level);
			   SetWindowText(hchildwnd3,szJibie);
			   return 0;
		  case IDM_ABOUT:
			   MessageBox(hwnd,"��������\n2001��4��6��\nvcroad.6to23.com\nwutao8@263.net","���Ӵ�Ŧ��",NULL);
			   return 0;
		  case IDM_PAIHANG:
			   MessageBox(hwnd,"��Ǹ����ʾ���޴˹��ܣ��Ǻ�","���Ӵ�Ŧ��",NULL);
			   return 0;
		  case IDM_GAMEOVER:
			   KillTimer(hwnd,Level);
               EnableMenuItem(hMenu,IDM_PAUSEGAME,MF_GRAYED);
			   EnableMenuItem(hMenu,IDM_GAMEOVER,MF_GRAYED);
		       ifBegin=FALSE;
			   for(x=1;x<=6;x++)
				   EnableMenuItem(hMenu,x,MF_ENABLED);
			   return 0;
		  case IDM_CLOSEGAME:
			   SendMessage(hwnd,WM_CLOSE,0,0);
			   return 0;
		  }
		  return 0;
	 case WM_LBUTTONDOWN:
		  xposition=(LOWORD(lParam)-16)/21;
		  yposition=(HIWORD(lParam)-16)/21;
		  if(xposition>=0&&xposition<=11&&yposition>=0&&yposition<=11)
		    if(((Map[xposition][yposition]==IDT_NIU)||(xposition==QiziLink[0].hang&&yposition==QiziLink[0].lie))&&ifBegin)
			{
              if(DrawLine(xSource,ySource,xposition,yposition,hwnd,&iflag,hchildwnd2))
			  {
		        xSource=xposition;
		        ySource=yposition;
			  }
			}
		  return 0;      
	 case WM_RBUTTONDOWN:
		  for(x=0;x<12;x++)
			  for(y=0;y<12;y++)
				  Map[x][y]=bakMap[x][y];
		  iflag=0;
		  InvalidateRect(hwnd,NULL,FALSE);
		  ShuaXinLink(hchildwnd2);
		  return 0;
	 case WM_TIMER:
		  DrawQizi(1,hwnd,hchildwnd2,IDT_NIU);
		  if(QiziNumber==0)
		  {   
			  KillTimer(hwnd,Level);
			  MessageBox(hwnd,"��Ϸ���������֧��vcroad.6to23.com","���Ӵ�Ŧ��",NULL);
		      ifBegin=FALSE;
			  EnableMenuItem(hMenu,IDM_PAUSEGAME,MF_GRAYED);
		      EnableMenuItem(hMenu,IDM_GAMEOVER,MF_GRAYED);
		      for(x=1;x<=6;x++)
				 EnableMenuItem(hMenu,x,MF_ENABLED);
		  }
		  return 0;
	 case WM_DESTROY:
		  DeleteAllBitmap();
		  KillTimer(hwnd,Level);
		  PostQuitMessage (0) ;
		  return 0 ;
     }
     return DefWindowProc (hwnd, message, wParam, lParam) ;
}
void DrawJiemian(HWND hchildwnd1,HWND hchildwnd2,HWND hchildwnd3,HDC hdc)
{
	RECT  rectmain,rectfen,rectone,recttwo,rectthree;
	rectmain.left=14;rectmain.top=14;rectmain.right=270;rectmain.bottom=270;
    rectfen.left=272;rectfen.right=425;rectfen.top=14;rectfen.bottom=270;
	rectone.left=279;rectone.right=412;rectone.top=49;rectone.bottom=82;
	recttwo.left=279;recttwo.right=412;recttwo.top=119;recttwo.bottom=152;
	rectthree.left=279;rectthree.right=412;rectthree.top=189;rectthree.bottom=222;
	DrawEdge(hdc,&rectfen,BDR_SUNKENINNER|BDR_RAISEDOUTER,BF_TOPLEFT|BF_BOTTOMRIGHT|BF_FLAT);
    DrawEdge(hdc,&rectmain,BDR_SUNKENINNER|BDR_RAISEDOUTER,BF_TOPLEFT|BF_BOTTOMRIGHT|BF_FLAT);
    DrawEdge(hdc,&rectone,BDR_SUNKENOUTER,BF_TOPLEFT|BF_BOTTOMRIGHT);
    DrawEdge(hdc,&recttwo,BDR_SUNKENOUTER,BF_TOPLEFT|BF_BOTTOMRIGHT);
    DrawEdge(hdc,&rectthree,BDR_SUNKENOUTER,BF_TOPLEFT|BF_BOTTOMRIGHT);
}
void DrawQipan(HDC hdc,HINSTANCE hInstance,HWND hwnd)
{
	int x,y;
    HDC hdcMem;
	hdcMem=CreateCompatibleDC(hdc);
	
	for(y=0;y<12*21;y=y+21)
		for(x=0;x<12*21;x=x+21)
		{
			SelectObject(hdcMem,hBitmap[Map[x/21][y/21]-1]);
			BitBlt(hdc,x+16,y+16,21,21,hdcMem,0,0,SRCCOPY); 
		}
	DeleteDC(hdcMem);
}
void LoadAllBitmap(HINSTANCE hInstance)
{
	int i;
	for(i=0;i<20;i++)
		hBitmap[i]=LoadBitmap(hInstance,MAKEINTRESOURCE(i+1));
}
void DeleteAllBitmap(void)
{
	int i;
	for(i=0;i<20;i++)
		DeleteObject(hBitmap[i+1]);
}
unsigned short RandNumber(unsigned long n)
{
	unsigned long multiplier=1194211693L;
	unsigned long adder=12345L;
	Seed=multiplier*Seed+adder;
	return (unsigned short)((Seed>>16)%n);
}
void InitSeed(void)
{
	Seed=time(0);
}
void InitLink(void)
{
	int i;
	nodehead.hang=-1;
	nodehead.lie=-1;
	nodehead.link=0;
	for(i=0;i<144;i++)
	{
		mapbiao[i].hang=i/12;
	    mapbiao[i].lie=i%12;
		mapbiao[i].link=i+1;
	}
	nodenum=144;
}
void DrawQizi(int iniunum,HWND hwnd,HWND hchildwnd2,int nID)
{
	int i,j,num,r;
	TCHAR  szShengyu[30];
	InitSeed();
	for(i=0;i<iniunum;i++)
	{
		r=RandNumber(nodenum);
		for(j=nodehead.link,num=0;num<r;j=mapbiao[j].link,num++)
			if(num+1==r)
			{
               Map[mapbiao[mapbiao[j].link].hang][mapbiao[mapbiao[j].link].lie]=nID;
		       bakMap[mapbiao[mapbiao[j].link].hang][mapbiao[mapbiao[j].link].lie]=nID;
			   mapbiao[j].link=mapbiao[mapbiao[j].link].link;
			}
		    
		if(r==0)
		{
			nodehead.link=mapbiao[j].link;
		    Map[mapbiao[j].hang][mapbiao[j].lie]=nID;
		    bakMap[mapbiao[j].hang][mapbiao[j].lie]=nID;
		}
		nodenum--;
		QiziNumber--;
    }
	wsprintf(szShengyu,"ʣ��:         %d",QiziNumber);
    SetWindowText(hchildwnd2,szShengyu);
	InvalidateRect(hwnd,NULL,FALSE);
}
void ClearQipan(void)
{
	int i,j;
	for(i=0;i<12;i++)
		for(j=0;j<12;j++)
		{
			Map[i][j]=IDT_KONG;
            bakMap[i][j]=Map[i][j];
		}
}
void DrawOneQizi(int x,int y,int nID,HWND hwnd)
{
	Map[x][y]=nID;
	InvalidateRect(hwnd,NULL,FALSE);
}
BOOL DrawLine(int xSource,int ySource,int xTarget,int yTarget,HWND hwnd,int* iflag,HWND hchildwnd2)
{
	int i,temp;
	if(*iflag==0)
	{
	  *iflag=1;
	  DrawOneQizi(xTarget,yTarget,IDT_LNIU,hwnd);
	  QiziLink[0].hang=xTarget;
	  QiziLink[0].lie=yTarget;
	  QiziLink[0].link=10;
	  ChuanQiziNum=1;
	  return TRUE;
	}
	if(xTarget==QiziLink[0].hang&&yTarget==QiziLink[0].lie&&QiziLink[0].link==10&&(xSource!=xTarget||ySource!=yTarget))
	{
      if(QiziLink[2].hang==-1)
	    return FALSE;
	  QiziLink[0].link=-1;
	  temp=Map[xTarget][yTarget];
	  Map[xTarget][yTarget]=IDT_NIU;
	  if(DrawLine(xSource,ySource,xTarget,yTarget,hwnd,iflag,hchildwnd2))
      { 
		for(i=0;i<ChuanQiziNum;i++)
		{
		  Map[QiziLink[i].hang][QiziLink[i].lie]=IDT_KONG;
		  bakMap[QiziLink[i].hang][QiziLink[i].lie]=IDT_KONG;
		  InvalidateRect(hwnd,NULL,FALSE);
		}
		InitQiziLink();
		*iflag=0;
		ShuaXinLink(hchildwnd2);
	  }
	  else
	  {
		Map[xTarget][yTarget]=temp;
	    QiziLink[0].link=10;
	  }
	  return FALSE;
	}
	if(((xSource!=xTarget)&&(ySource!=yTarget))||(Map[xTarget][yTarget]!=IDT_NIU)||((xSource==xTarget)&&(ySource==yTarget)))
	  return FALSE;
	if((xSource==xTarget)&&(ySource!=yTarget))
	{
		if(ySource<yTarget)
		{
		  for(i=ySource+1;i<yTarget;i++)
		  {
			  if((Map[xSource][i]!=IDT_KONG)&&(Map[xSource][i]!=IDT_KONGYC)&&(Map[xSource][i]!=IDT_NIU))
				  return FALSE;
		  }
		  for(i=ySource;i<yTarget;i++)
		  {
			  switch(Map[xSource][i])
			  {
			  case IDT_KONG:
                   Map[xSource][i]=IDT_KONGXC;
                   DeleteNode(xSource,i);
				   break;
			  case IDT_NIU:
				   Map[xSource][i]=IDT_XIANXC;
				   break;
			  case IDT_KONGYC:
				   Map[xSource][i]=IDT_KONGJ;
				   break;
			  case IDT_LNIU:
				   Map[xSource][i]=IDT_XIANXIA;
			       break;
			  case IDT_LXIANSHANG:
				   Map[xSource][i]=IDT_XIANXC;
				   break;
			  case IDT_LXIANYOU:
				   Map[xSource][i]=IDT_XIANXY;
				   break;
			  case IDT_LXIANZUO:
				   Map[xSource][i]=IDT_XIANXZ;
				   break; 
			  }
			  QiziLink[ChuanQiziNum].hang=xSource;
			  QiziLink[ChuanQiziNum].lie=i;
			  ChuanQiziNum++;
		  }
		  Map[xSource][i]=IDT_LXIANSHANG;
		}
		if(ySource>yTarget)
		{
		  for(i=ySource-1;i>yTarget;i--)
		  {
			  if((Map[xSource][i]!=IDT_KONG)&&(Map[xSource][i]!=IDT_KONGYC)&&(Map[xSource][i]!=IDT_NIU))
                  return FALSE;
		  }
	      for(i=ySource;i>yTarget;i--)
		  {
			  switch(Map[xSource][i])
			  {
			  case IDT_KONG:
                   Map[xSource][i]=IDT_KONGXC;
                   DeleteNode(xSource,i);
				   break;
			  case IDT_NIU:
				   Map[xSource][i]=IDT_XIANXC;
				   break;
			  case IDT_KONGYC:
				   Map[xSource][i]=IDT_KONGJ;
				   break;
              case IDT_LNIU:
				   Map[xSource][i]=IDT_XIANSHANG;
				   break;
			  case IDT_LXIANXIA:
				   Map[xSource][i]=IDT_XIANXC;
			       break;
			  case IDT_LXIANYOU:
				   Map[xSource][i]=IDT_XIANSY;
                   break;
			  case IDT_LXIANZUO:
				   Map[xSource][i]=IDT_XIANSZ;
				   break;
			  }
			  QiziLink[ChuanQiziNum].hang=xSource;
			  QiziLink[ChuanQiziNum].lie=i;
			  ChuanQiziNum++;
		  }
		  Map[xSource][i]=IDT_LXIANXIA;
		}
	}
	if((xSource!=xTarget)&&(ySource==yTarget))
	{
		if(xSource<xTarget)
		{
		  for(i=xSource+1;i<xTarget;i++)
		  {
			  if((Map[i][ySource]!=IDT_KONG)&&(Map[i][ySource]!=IDT_KONGXC)&&(Map[i][ySource]!=IDT_NIU))
				  return FALSE;
		  }
		  for(i=xSource;i<xTarget;i++)
		  {
			  switch(Map[i][ySource])
			  {
			  case IDT_KONG:
				   Map[i][ySource]=IDT_KONGYC;
				   DeleteNode(i,ySource);
				   break;
			  case IDT_NIU:
				   Map[i][ySource]=IDT_XIANYC;
				   break;
			  case IDT_KONGXC:
				   Map[i][ySource]=IDT_KONGJ;
				   break;
			  case IDT_LNIU:
				   Map[i][ySource]=IDT_XIANYOU;
				   break;
			  case IDT_LXIANSHANG:
				   Map[i][ySource]=IDT_XIANSY;
				   break;
			  case IDT_LXIANXIA:
				   Map[i][ySource]=IDT_XIANXY;
				   break;
			  case IDT_LXIANZUO:
				   Map[i][ySource]=IDT_XIANYC;
				   break;
			  }
			  QiziLink[ChuanQiziNum].hang=i;
			  QiziLink[ChuanQiziNum].lie=ySource;
			  ChuanQiziNum++;
		  }
		  Map[i][ySource]=IDT_LXIANZUO;
		}
		if(xSource>xTarget)
		{
		  for(i=xSource-1;i>xTarget;i--)
		  {
			  if((Map[i][ySource]!=IDT_KONG)&&(Map[i][ySource]!=IDT_KONGXC)&&(Map[i][ySource]!=IDT_NIU))
				  return FALSE;
		  }
	      for(i=xSource;i>xTarget;i--)
		  {
		      switch(Map[i][ySource])
			  {
			  case IDT_KONG:
				   Map[i][ySource]=IDT_KONGYC;
				   DeleteNode(i,ySource);
				   break;
			  case IDT_NIU:
				   Map[i][ySource]=IDT_XIANYC;
				   break;
			  case IDT_KONGXC:
				   Map[i][ySource]=IDT_KONGJ;
				   break;
			  case IDT_LNIU:
				   Map[i][ySource]=IDT_XIANZUO;
				   break;
			  case IDT_LXIANSHANG:
				   Map[i][ySource]=IDT_XIANSZ;
				   break;
			  case IDT_LXIANXIA:
				   Map[i][ySource]=IDT_XIANXZ;
				   break;
			  case IDT_LXIANYOU:
				   Map[i][ySource]=IDT_XIANYC;
				   break;
			  }
			  QiziLink[ChuanQiziNum].hang=i;
			  QiziLink[ChuanQiziNum].lie=ySource;
			  ChuanQiziNum++;
		  }
		  Map[i][ySource]=IDT_LXIANYOU;
		}
	}
	InvalidateRect(hwnd,NULL,FALSE);
	return TRUE;
}
int DeleteNode(int x,int y)
{
     int j=nodehead.link,num,k=nodehead.link;
	 if(mapbiao[nodehead.link].hang==x&&mapbiao[nodehead.link].lie==y)
	 {
		nodehead.link=mapbiao[j].link;
		nodenum--;
		return 1;
	 }
	 for(j=mapbiao[nodehead.link].link,num=0;num<nodenum;j=mapbiao[j].link,num++)
     {
		   if(mapbiao[j].hang==x&&mapbiao[j].lie==y)
		   {
			  mapbiao[k].link=mapbiao[j].link;
              nodenum--;
			  return 1;
		   }
		   k=j;
	 }
	 return 0;
}
void InitQiziLink(void)
{
	int i;
	for(i=0;i<144;i++)
	{
		QiziLink[i].hang=-1;
		QiziLink[i].lie=-1;
		QiziLink[i].link=-1;
	}
	ChuanQiziNum=0;
}
void ShuaXinLink(HWND hchildwnd2)
{
	int i,k;
	TCHAR szShengyu[30];
	QiziNumber=70;
	nodenum=0;
	for(i=0;i<144;i++)
		if(Map[mapbiao[i].hang][mapbiao[i].lie]==IDT_KONG)
		{
			nodehead.link=i;
            break;
		}
	k=nodehead.link;
	for(i=0;i<144;i++)
	{
		if(Map[mapbiao[i].hang][mapbiao[i].lie]>4)
			QiziNumber--;
		if(Map[mapbiao[i].hang][mapbiao[i].lie]==IDT_KONG)
		{
			mapbiao[k].link=i;
			nodenum++;
			k=i;
		}
	}
	wsprintf(szShengyu,"ʣ��:         %d",QiziNumber);
    SetWindowText(hchildwnd2,szShengyu);
}
