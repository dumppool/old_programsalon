//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StringRes.rc
//
#define IDS_GameOver                    57345
#define IDS_TxtScore                    57346
#define IDS_TxtLines                    57347
#define IDS_TxtLevel                    57348
#define IDS_TxtStart                    57349
#define IDS_TxtStop                     57350
#define IDS_TxtPause                    57351
#define IDS_TxtResume                   57352
#define IDS_HeaderScore                 57353
#define IDS_HeaderName                  57354
#define IDS_HeaderLevel                 57355
#define IDS_TxtSquareWidth              57356
#define IDS_TxtSquareHeight             57357
#define IDS_TxtGrid                     57358
#define IDS_TxtEnableSound              57359
#define IDS_TxtEnableMusic              57360
#define IDS_TxtSoundCardRequired        57361
#define IDS_TxtSplashAgain              57362
#define IDS_TxtBoard                    57363
#define IDS_TxtSound                    57364
#define IDS_TxtExFigureSet              57365
#define IDS_TxtChaikovsky               57366
#define IDS_TxtScorpions                57367
#define IDS_TxtKalinka                  57368
#define IDS_License                     57369
#define IDS_Concept                     57370
#define IDS_Warrantee                   57371
#define IDS_Disclosure                  57372
#define IDS_SplashImage                 57373
#define IDS_Credits                     57374
#define IDS_TxtEndGame                  57375
#define IDS_TitleGamePage               57376
#define IDS_TitleScorePage              57377
#define IDS_TitleOptionsPage            57378
#define IDS_TitleAboutPage              57379
#define IDS_HelpPageDlg                 57380
#define IDS_HelpPrelude                 57381
#define IDS_HelpKeys                    57382

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        800
#define _APS_NEXT_COMMAND_VALUE         33000
#define _APS_NEXT_CONTROL_VALUE         2000
#define _APS_NEXT_SYMED_VALUE           500
#endif
#endif
