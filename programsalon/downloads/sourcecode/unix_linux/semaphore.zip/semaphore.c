  void reader_function(void);
  void writer_function(void);
  
  char buffer;
  Semaphore writers_turn;
  Semaphore readers_turn;
  
  main()
  {
     pthread_t reader;
  
     semaphore_init( &readers_turn );
     semaphore_init( &writers_turn );
  
     /* writer must go first */
     semaphore_down( &readers_turn );
  
     pthread_create( &reader, pthread_attr_default, 
                    (void *)&reader_function, NULL);
     writer_function();
  }
  
  void writer_function(void)
  {
     while(1)
     {
          semaphore_down( &writers_turn );
          buffer = make_new_item();
          semaphore_up( &readers_turn );
     }
  }
  
  void reader_function(void)
  {
     while(1)
     {
          semaphore_down( &readers_turn );
          consume_item( buffer );
          semaphore_up( &writers_turn );
     }
  }

