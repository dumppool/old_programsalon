
require './sendmail-lib.pl';

# acl_security_form(&options)
# Output HTML for editing security options for the sendmail module
sub acl_security_form
{
print "<tr> <td><b>$text{'acl_opts'}</b></td> <td>\n";
printf "<input type=radio name=opts value=1 %s> $text{'yes'}\n",
	$_[0]->{'opts'} ? "checked" : "";
printf "<input type=radio name=opts value=0 %s> $text{'no'}</td>\n",
	$_[0]->{'opts'} ? "" : "checked";

print "<td><b>$text{'acl_cws'}</b></td> <td>\n";
printf "<input type=radio name=cws value=1 %s> $text{'yes'}\n",
	$_[0]->{'cws'} ? "checked" : "";
printf "<input type=radio name=cws value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'cws'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_masq'}</b></td> <td>\n";
printf "<input type=radio name=masq value=1 %s> $text{'yes'}\n",
	$_[0]->{'masq'} ? "checked" : "";
printf "<input type=radio name=masq value=0 %s> $text{'no'}</td>\n",
	$_[0]->{'masq'} ? "" : "checked";

print "<td><b>$text{'acl_trusts'}</b></td> <td>\n";
printf "<input type=radio name=trusts value=1 %s> $text{'yes'}\n",
	$_[0]->{'trusts'} ? "checked" : "";
printf "<input type=radio name=trusts value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'trusts'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_cgs'}</b></td> <td>\n";
printf "<input type=radio name=cgs value=1 %s> $text{'yes'}\n",
	$_[0]->{'cgs'} ? "checked" : "";
printf "<input type=radio name=cgs value=0 %s> $text{'no'}</td>\n",
	$_[0]->{'cgs'} ? "" : "checked";

print "<td><b>$text{'acl_relay'}</b></td> <td>\n";
printf "<input type=radio name=relay value=1 %s> $text{'yes'}\n",
	$_[0]->{'relay'} ? "checked" : "";
printf "<input type=radio name=relay value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'relay'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_mailers'}</b></td> <td>\n";
printf "<input type=radio name=mailers value=1 %s> $text{'yes'}\n",
	$_[0]->{'mailers'} ? "checked" : "";
printf "<input type=radio name=mailers value=0 %s> $text{'no'}</td>\n",
	$_[0]->{'mailers'} ? "" : "checked";

print "<td><b>$text{'acl_access'}</b></td> <td>\n";
printf "<input type=radio name=access value=1 %s> $text{'yes'}\n",
	$_[0]->{'access'} ? "checked" : "";
printf "<input type=radio name=access value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'access'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_domains'}</b></td> <td>\n";
printf "<input type=radio name=domains value=1 %s> $text{'yes'}\n",
	$_[0]->{'domains'} ? "checked" : "";
printf "<input type=radio name=domains value=0 %s> $text{'no'}</td>\n",
	$_[0]->{'domains'} ? "" : "checked";

print "<td><b>$text{'acl_stop'}</b></td> <td>\n";
printf "<input type=radio name=stop value=1 %s> $text{'yes'}\n",
	$_[0]->{'stop'} ? "checked" : "";
printf "<input type=radio name=stop value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'stop'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_mailq'}</b></td> <td colspan=3>\n";
printf "<input type=radio name=mailq value=2 %s> $text{'acl_viewdel'}\n",
	$_[0]->{'mailq'} == 2 ? "checked" : "";
printf "<input type=radio name=mailq value=1 %s> $text{'acl_view'}\n",
	$_[0]->{'mailq'} == 1 ? "checked" : "";
printf "<input type=radio name=mailq value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'mailq'} == 0 ? "checked" : "";

print "<tr> <td colspan=4><hr></td> </tr>\n";

print "<tr> <td valign=top><b>$text{'acl_virtusers'}</b></td> <td colspan=3>\n";
printf "<input type=radio name=vmode value=0 %s> $text{'acl_none'}\n",
	$_[0]->{'vmode'} == 0 ? "checked" : "";
printf "<input type=radio name=vmode value=1 %s> $text{'acl_all'}<br>\n",
	$_[0]->{'vmode'} == 1 ? "checked" : "";
printf "<input type=radio name=vmode value=2 %s> $text{'acl_matching'}\n",
	$_[0]->{'vmode'} == 2 ? "checked" : "";
printf "<input name=vaddrs size=40 value='%s'></td> </tr>\n",
	$_[0]->{'vaddrs'};

print "<tr> <td><b>$text{'acl_vtypes'}</b></td>\n";
print "<td colspan=3>\n";
for($n = 0; $n<3; $n++) {
	printf "<input type=checkbox name=vedit_%s value=1 %s> %s\n",
		$n, $_[0]->{"vedit_$n"} ? "checked" : "", $text{"acl_vtype$n"};
	}
print "</td> </tr>\n";

print "<tr> <td><b>$text{'acl_vmax'}</b></td>\n";
printf "<td colspan=3><input type=radio name=vmax_def value=1 %s> %s\n",
	$_[0]->{'vmax'} ? "" : "checked", $text{'acl_unlimited'};
printf "<input type=radio name=vmax_def value=0 %s>\n",
	$_[0]->{'vmax'} ? "checked" : "";
printf "<input name=vmax size=5 value='%s'></td> </tr>\n",
	$_[0]->{'vmax'};

print "<tr> <td colspan=4><hr></td> </tr>\n";

print "<tr> <td valign=top><b>$text{'acl_aliases'}</b></td> <td colspan=3>\n";
printf "<input type=radio name=amode value=0 %s> $text{'acl_none'}\n",
	$_[0]->{'amode'} == 0 ? "checked" : "";
printf "<input type=radio name=amode value=1 %s> $text{'acl_all'}<br>\n",
	$_[0]->{'amode'} == 1 ? "checked" : "";
printf "<input type=radio name=amode value=2 %s> $text{'acl_matching'}\n",
	$_[0]->{'amode'} == 2 ? "checked" : "";
printf "<input name=aliases size=40 value='%s'></td> </tr>\n",
	$_[0]->{'aliases'};

print "<tr> <td><b>$text{'acl_atypes'}</b></td> <td colspan=3>\n";
for($n=1; $n<5; $n++) {
	printf "<input type=checkbox name=aedit_%s value=1 %s> %s\n",
		$n, $_[0]->{"aedit_$n"} ? "checked" : "",
		$text{"acl_atype$n"};
	}
print "</td> </tr>\n";

print "<tr> <td><b>$text{'acl_amax'}</b></td>\n";
printf "<td colspan=3><input type=radio name=amax_def value=1 %s> %s\n",
	$_[0]->{'amax'} ? "" : "checked", $text{'acl_unlimited'};
printf "<input type=radio name=amax_def value=0 %s>\n",
	$_[0]->{'amax'} ? "checked" : "";
printf "<input name=amax size=5 value='%s'></td> </tr>\n",
	$_[0]->{'amax'};

print "<tr> <td colspan=4><hr></td> </tr>\n";

print "<tr> <td valign=top><b>$text{'acl_outgoing'}</b></td> <td colspan=3>\n";
printf "<input type=radio name=omode value=0 %s> $text{'acl_none'}\n",
	$_[0]->{'omode'} == 0 ? "checked" : "";
printf "<input type=radio name=omode value=1 %s> $text{'acl_all'}<br>\n",
	$_[0]->{'omode'} == 1 ? "checked" : "";
printf "<input type=radio name=omode value=2 %s> $text{'acl_matching'}\n",
	$_[0]->{'omode'} == 2 ? "checked" : "";
printf "<input name=oaddrs size=40 value='%s'></td> </tr>\n",
	$_[0]->{'oaddrs'};

print "<tr> <td colspan=4><hr></td> </tr>\n";

print "<tr> <td valign=top><b>$text{'acl_read'}</b></td> <td colspan=3>\n";
printf "<input type=radio name=mmode value=0 %s> $text{'acl_none'}\n",
	$_[0]->{'mmode'} == 0 ? "checked" : "";
printf "<input type=radio name=mmode value=1 %s> $text{'acl_all'}<br>\n",
	$_[0]->{'mmode'} == 1 ? "checked" : "";
printf "<input type=radio name=mmode value=2 %s> $text{'acl_users'}\n",
	$_[0]->{'mmode'} == 2 ? "checked" : "";
printf "<input name=musers size=40 value='%s'> %s<br>\n",
	$_[0]->{'mmode'} == 2 ? $_[0]->{'musers'} : "",
	&user_chooser_button("musers", 1);
printf "<input type=radio name=mmode value=3 %s> $text{'acl_userse'}\n",
	$_[0]->{'mmode'} == 3 ? "checked" : "";
printf "<input name=muserse size=40 value='%s'> %s</td> </tr>\n",
	$_[0]->{'mmode'} == 3 ? $_[0]->{'musers'} : "",
	&user_chooser_button("muserse", 1);

print "<tr> <td valign=top><b>$text{'acl_from'}</b></td> <td colspan=3>\n";
printf "<input type=radio name=fmode value=0 %s> $text{'acl_any'}<br>\n",
	$_[0]->{'fmode'} == 0 ? "checked" : "";
printf "<input type=radio name=fmode value=1 %s> $text{'acl_fdoms'}\n",
	$_[0]->{'fmode'} == 1 ? "checked" : "";
printf "<input name=fdoms size=40 value='%s'><br>\n",
	$_[0]->{'fmode'} == 1 ? $_[0]->{'from'} : '';
printf "<input type=radio name=fmode value=2 %s> $text{'acl_faddrs'}\n",
	$_[0]->{'fmode'} == 2 ? "checked" : "";
printf "<input name=faddrs size=40 value='%s'><br>\n",
	$_[0]->{'fmode'} == 2 ? $_[0]->{'from'} : '';
print "</td> </tr>\n";
}

# acl_security_save(&options)
# Parse the form for security options for the sendmail module
sub acl_security_save
{
$_[0]->{'opts'} = $in{'opts'};
$_[0]->{'cws'} = $in{'cws'};
$_[0]->{'masq'} = $in{'masq'};
$_[0]->{'trusts'} = $in{'trusts'};
$_[0]->{'cgs'} = $in{'cgs'};
$_[0]->{'relay'} = $in{'relay'};
$_[0]->{'mailq'} = $in{'mailq'};
$_[0]->{'mailers'} = $in{'mailers'};
$_[0]->{'access'} = $in{'access'};
$_[0]->{'domains'} = $in{'domains'};
$_[0]->{'stop'} = $in{'stop'};
$_[0]->{'vmode'} = $in{'vmode'};
$_[0]->{'vaddrs'} = $in{'vmode'} == 2 ? $in{'vaddrs'} : "";
$_[0]->{'vmax'} = $in{'vmax_def'} ? undef : $in{'vmax'};
foreach $i (0..2) {
	$_[0]->{"vedit_$i"} = $in{"vedit_$i"};
	}
$_[0]->{'amode'} = $in{'amode'};
$_[0]->{'aliases'} = $in{'amode'} == 2 ? $in{'aliases'} : "";
$_[0]->{'amax'} = $in{'amax_def'} ? undef : $in{'amax'};
foreach $i (1..4) {
	$_[0]->{"aedit_$i"} = $in{"aedit_$i"};
	}
$_[0]->{'omode'} = $in{'omode'};
$_[0]->{'oaddrs'} = $in{'omode'} == 2 ? $in{'oaddrs'} : "";
$_[0]->{'mmode'} = $in{'mmode'};
$_[0]->{'musers'} = $in{'mmode'} == 2 ? $in{'musers'} :
		    $in{'mmode'} == 3 ? $in{'muserse'} : "";
$_[0]->{'fmode'} = $in{'fmode'};
$_[0]->{'from'} = $in{'fmode'} == 0 ? undef :
		  $in{'fmode'} == 1 ? $in{'fdoms'} : $in{'faddrs'};
}

