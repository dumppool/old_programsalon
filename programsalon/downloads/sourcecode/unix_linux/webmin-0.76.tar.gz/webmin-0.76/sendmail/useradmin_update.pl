
do './sendmail-lib.pl';

# useradmin_create_user(&details)
sub useradmin_create_user
{
}

# useradmin_delete_user(&details)
# Delete this user's mail file
sub useradmin_delete_user
{
local $dir = $config{'mail_dir'};
if ($dir && -d $dir) {
	unlink("$dir/$_[0]->{'user'}");
	unlink("$dir/.$_[0]->{'user'}.pop");
	}
}

# useradmin_modify_user(&details)
sub useradmin_modify_user
{
local $dir = $config{'mail_dir'};
if ($dir) {
	local $mfile = "$dir/$_[0]->{'user'}";
	local @st = stat($mfile);
	if ($st[4] != $_[0]->{'uid'}) {
		chown($_[0]->{'uid'}, $st[5], $mfile);
		}
	}
}

1;

