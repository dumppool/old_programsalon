import java.awt.*;;

public class GrayPanel extends Panel
{
	public void paint(Graphics g)
	{
	g.setColor(Color.lightGray);
	g.fillRect(0, 0, size().width, size().height);
	}
}
