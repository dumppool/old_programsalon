# file-lib.pl
# Common functions for file manager CGIs

do '../web-lib.pl';
&init_config();
%access = &get_module_acl();

$icon_map = (	"c", 1,    "txt", 1,
		"pl", 1,   "cgi", 1,
		"html", 1, "htm", 1,
		"gif", 2,  "jpg", 2,
		"tar", 3
		);

# file_info_line(path)
# Returns a line of text containing encoded details of some file
sub file_info_line
{
local @st = $access{'follow'} ? stat($_[0]) : lstat($_[0]);
local $ext = $_[0] =~ /\S+\.([^\.\/]+)$/ ? $1 : undef;
local $user = getpwuid($st[4]); $user = $st[4] if (!$user);
local $group = getgrgid($st[5]); $group = $st[5] if (!$group);
return sprintf ("%s\t%d\t%s\t%s\t%d\t%d\t%d\t%s",
		$_[0],
		(-l $_[0] && !$access{'follow'} ? 5 :
		 -d $_[0] ? 0 :
		 -b $_[0] ? 6 :
		 -c $_[0] ? 6 :
		 -p $_[0] ? 7 :
		 -S $_[0] ? 7 :
		 defined($icon_map{$ext}) ? $icon_map{$ext} : 4),
		$user, $group,
		$st[7], $st[2], $st[9], readlink($_[0]));
}

# switch_acl_uid()
sub switch_acl_uid
{
if ($access{'uid'}) {
	local @u = getpwuid($access{'uid'});
	$( = $u[3]; $) = "$u[3] $u[3]";
	$< = $> = $u[2];
	umask(oct($access{'umask'}));
	}
}

# can_access(file)
sub can_access
{
foreach $r (split(/\s+/, $access{'root'})) {
	return 1 if ($r eq "/");
	local $lf = length($_[0]);
	local $lr = length($r);
	if ($lf > $lr) {
		return 1 if (substr($_[0], 0, $lr) eq $r);
		}
	else {
		return 1 if (substr($r, 0, $lf) eq $_[0]);
		}
	}
return 0;
}

1;

