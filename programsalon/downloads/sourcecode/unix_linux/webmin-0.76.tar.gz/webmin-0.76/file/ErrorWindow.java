import java.awt.*;

class ErrorWindow extends FixedFrame implements CbButtonCallback
{
	CbButton ok;

	ErrorWindow(String m)
	{
	setLayout(new BorderLayout());
	Panel cen = new BorderPanel(1);
	cen.setLayout(new GridLayout(1, 1));
	cen.add(new Label(m));
	add("Center", cen);
	Panel bot = new GrayPanel();
	bot.setLayout(new FlowLayout(FlowLayout.CENTER));
	bot.add(new CbButton("Ok", this));
	add("South", bot);
	pack();
	show();
	setTitle("Error");
	Util.recursiveBackground(this, Color.lightGray);
	}

	public void click(CbButton b)
	{
	dispose();
	}
}

