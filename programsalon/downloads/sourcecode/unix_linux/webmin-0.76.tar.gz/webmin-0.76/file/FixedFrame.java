import java.awt.*;
import java.io.*;

public class FixedFrame extends Frame
{
	int mw = 0, mh = 0;

	public FixedFrame()
	{
	/*
	Image im = Util.tk.getImage("icons"+File.separator+"jshock.gif");
	if (im != null && Util.waitForImage(im))
		setIconImage(im);
	*/
	}

	public FixedFrame(int w, int h)
	{
	this();
	mw = w; mh = h;
	}

	public boolean handleEvent(Event evt)
	{
	if (evt.target == this && evt.id == Event.WINDOW_DESTROY) {
		dispose();
		return true;
		}
	return super.handleEvent(evt);
	}

	public Dimension minimumSize()
	{
	if (mw != 0 && mh != 0) return new Dimension(mw, mh);
	else return super.minimumSize();
	}

	public Dimension preferredSize()
	{
	return minimumSize();
	}
}

