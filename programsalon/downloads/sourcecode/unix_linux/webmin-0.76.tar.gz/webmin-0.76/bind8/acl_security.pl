
require './bind8-lib.pl';

# acl_security_form(&options)
# Output HTML for editing security options for the bind8 module
sub acl_security_form
{
print "<tr> <td valign=top rowspan=4><b>$text{'acl_zones'}</b></td>\n";
print "<td rowspan=4 valign=top><select name=zones multiple size=5 width=15>\n";
local $conf = &get_config();
local @zones = grep { $_->{'value'} ne "." }
		    &find("zone", $conf);
local ($z, %zcan);
map { $zcan{$_}++ } split(/\s+/, $_[0]->{'zones'});
foreach $z (sort { $a->{'value'} cmp $b->{'value'} } @zones) {
	printf "<option value='%s' %s>%s\n",
		$z->{'value'},
		$zcan{$z->{'value'}} || $zcan{"*"} ? "selected" : "",
		&arpa_to_ip($z->{'value'});
	}
print "</select></td>\n";

print "<td><b>$text{'acl_master'}</b></td> <td>\n";
printf "<input type=radio name=master value=1 %s> $text{'yes'}\n",
	$_[0]->{'master'} ? "checked" : "";
printf "<input type=radio name=master value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'master'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_slave'}</b></td> <td>\n";
printf "<input type=radio name=slave value=1 %s> $text{'yes'}\n",
	$_[0]->{'slave'} ? "checked" : "";
printf "<input type=radio name=slave value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'slave'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_forward'}</b></td> <td>\n";
printf "<input type=radio name=forward value=1 %s> $text{'yes'}\n",
	$_[0]->{'forward'} ? "checked" : "";
printf "<input type=radio name=forward value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'forward'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_defaults'}</b></td> <td>\n";
printf "<input type=radio name=defaults value=1 %s> $text{'yes'}\n",
	$_[0]->{'defaults'} ? "checked" : "";
printf "<input type=radio name=defaults value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'defaults'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_reverse'}</b></td> <td>\n";
printf "<input type=radio name=reverse value=1 %s> $text{'yes'}\n",
	$_[0]->{'reverse'} ? "checked" : "";
printf "<input type=radio name=reverse value=0 %s> $text{'no'}</td>\n",
	$_[0]->{'reverse'} ? "" : "checked";

print "<td><b>$text{'acl_multiple'}</b></td> <td>\n";
printf "<input type=radio name=multiple value=1 %s> $text{'yes'}\n",
	$_[0]->{'multiple'} ? "checked" : "";
printf "<input type=radio name=multiple value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'multiple'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_ro'}</b></td> <td>\n";
printf "<input type=radio name=ro value=1 %s> $text{'yes'}\n",
	$_[0]->{'ro'} ? "checked" : "";
printf "<input type=radio name=ro value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'ro'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_dir'}</b></td>\n";
printf "<td colspan=3><input name=dir size=30 value='%s'> %s</td> </tr>\n",
	$_[0]->{'dir'}, &file_chooser_button("dir", 1);
}

# acl_security_save(&options)
# Parse the form for security options for the bind8 module
sub acl_security_save
{
local $conf = &get_config();
local @zones = grep { $_->{'value'} ne "." }
		    &find("zone", $conf);
local @sel = split(/\0/, $in{'zones'});
if (scalar(@sel) == scalar(@zones)) {
	$_[0]->{'zones'} = "*";
	}
else {
	$_[0]->{'zones'} = join(" ", @sel);
	}
$_[0]->{'master'} = $in{'master'};
$_[0]->{'slave'} = $in{'slave'};
$_[0]->{'forward'} = $in{'forward'};
$_[0]->{'defaults'} = $in{'defaults'};
$_[0]->{'reverse'} = $in{'reverse'};
$_[0]->{'multiple'} = $in{'multiple'};
$_[0]->{'ro'} = $in{'ro'};
$_[0]->{'dir'} = $in{'dir'};
}

