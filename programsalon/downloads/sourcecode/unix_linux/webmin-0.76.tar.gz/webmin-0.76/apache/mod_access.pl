# mod_access.pl
# Defines editors for host restriction directives

sub mod_access_directives
{
local($rv);
$rv = [ [ 'allow deny order', 1, 4, 'directory htaccess' ] ];
return &make_directives($rv, $_[0], "mod_access");
}

sub edit_allow_deny_order
{
local($d, @w, $i, @type, @mode, @what, $rv);
foreach $d (@{$_[0]}, @{$_[1]}) {
	@w = split(/\s+/, $d->{'value'});
	for($i=1; $i<@w; $i++) {
		push(@type, $d->{'name'} eq "allow" ? 1 : 2);
		push(@what, $w[$i]);
		if ($w[$i] =~ /^env=(\S+)$/) {
			$what[$#what] = $1;
			push(@mode, 6);
			}
		elsif ($w[$i] =~ /^[0-9\.]+\/[0-9]+$/) { push(@mode, 5); }
		elsif ($w[$i] =~ /^[0-9\.]+\/[0-9\.]+$/) { push(@mode, 4); }
		elsif ($w[$i] =~ /^\d+\.\d+\.\d+\.\d+$/) { push(@mode, 2); }
		elsif ($w[$i] =~ /^[0-9\.]+$/) { push(@mode, 3); }
		elsif ($w[$i] eq "all") { push(@mode, 0); }
		else { push(@mode, 1); }
		}
	}
push(@type, ""); push(@what, ""); push(@mode, 0);
$rv = "<i>Access checking order:</i>\n".
      &choice_input($_[2]->[0]->{'value'}, "order", "",
       "Deny then allow,deny,allow", "Allow then deny,allow,deny",
       "Mutual failure,mutual-failure", "Default,")."<br>\n";
$rv .= "<table border>\n".
       "<tr $tb> <td><b>Action</b></td> <td><b>Condition</b></td> </tr>\n";
@sels = ("All requests,0", "Request from host...,1",
	 "Request from IP..,2", "Request from partial IP..,3");
if ($_[3]->{'version'} >= 1.3) {
	push(@sels, "Request from net/netmask..,4",
		    "Request from net/CIDR..,5");
	}
if ($_[3]->{'version'} >= 1.2) {
	push(@sels, "If variable is set..,6");
	}
for($i=0; $i<@type; $i++) {
	$rv .= "<tr $cb> <td>".&select_input($type[$i], "allow_type_$i", "",
	       ",0", "Allow,1", "Deny,2")."</td>\n";
	$rv .= "<td>".&select_input($mode[$i], "allow_mode_$i", "0", @sels);
	$rv .= sprintf "<input name=allow_what_$i size=20 value=\"%s\"></td>\n",
	        $mode[$i] ? $what[$i] : "";
	$rv .= "</tr>\n";
	}
$rv .= "</table>\n";
return (2, "Restrict access", $rv);
}
sub save_allow_deny_order
{
local($i, $type, $mode, $what, @allow, @deny);
for($i=0; defined($type = $in{"allow_type_$i"}); $i++) {
	$mode = $in{"allow_mode_$i"}; $what = $in{"allow_what_$i"};
	if (!$type) { next; }
	if ($mode == 0) { $what = "all"; }
	elsif ($mode == 2 && !&check_ipaddress($what)) {
		&error("'$what' is not a valid IP address");
		}
	elsif ($mode == 3 && $what !~ /^[0-9\.]+$/) {
		&error("'$what' is not a valid partial IP address");
		}
	elsif ($mode == 4 && ($what !~ /^([0-9\.]+)\/([0-9\.]+)$/ ||
	       !&check_ipaddress($1) || !&check_ipaddress($2))) {
		&error("'$what' is not a valid network/netmask pair");
		}
	elsif ($mode == 5 && ($what !~ /^([0-9\.]+)\/([0-9]+)$/ ||
	       !&check_ipaddress($1) || $2 > 32)) {
		&error("'$what' is not a valid network/CIDR pair");
		}
	elsif ($mode == 6) {
		$what =~ /^\S+$/ ||
			&error("'$what' is not a valid variable name");
		$what = "env=$what";
		}
	if ($type == 1) { push(@allow, "from $what"); }
	else { push(@deny, "from $what"); }
	}
return ( \@allow, \@deny, &parse_choice("order", ""));
}

1;

