# mod_speling.pl
# Defines editors spelling correction directives

sub mod_speling_directives
{
$rv = [ [ 'CheckSpelling', 0, 5, 'virtual', '1.3-1.32' ],
	[ 'CheckSpelling', 0, 5, 'virtual directory htaccess', 1.32 ] ];
return &make_directives($rv, $_[0], "mod_speling");
}

sub edit_CheckSpelling
{
return (1, "Automatically correct misspelled URLs?",
        &choice_input($_[0]->{'value'}, "CheckSpelling",
        "", "No,Off", "Yes,On", "Default,"));
}
sub save_CheckSpelling
{
return &parse_choice("CheckSpelling", "");
}

1;

