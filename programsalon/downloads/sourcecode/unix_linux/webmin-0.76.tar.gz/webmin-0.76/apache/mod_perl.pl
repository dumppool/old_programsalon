# mod_perl.pl
# Placeholder for mod_perl directives

sub mod_perl_directives
{
return ();
}

1;
