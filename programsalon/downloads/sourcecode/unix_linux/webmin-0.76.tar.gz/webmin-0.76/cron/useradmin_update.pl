
do './cron-lib.pl';

# useradmin_create_user(&details)
sub useradmin_create_user
{
}

# useradmin_delete_user(&details)
# Delete this user's cron file
sub useradmin_delete_user
{
unlink("$config{'cron_dir'}/$_[0]->{'user'}");
}

# useradmin_modify_user(&details)
sub useradmin_modify_user
{
}

1;

