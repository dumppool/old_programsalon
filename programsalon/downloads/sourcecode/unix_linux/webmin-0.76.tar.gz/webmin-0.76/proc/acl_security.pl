
require './proc-lib.pl';

# acl_security_form(&options)
# Output HTML for editing security options for the proc module
sub acl_security_form
{
print "<tr> <td><b>Manage processes as user</b></td>\n";
local $u = getpwuid($_[0]->{'uid'});
print "<td><input name=uid size=8 value='$u'> ",
	&user_chooser_button("uid", 0),"</td> </tr>\n";
}

# acl_security_save(&options)
# Parse the form for security options for the proc module
sub acl_security_save
{
$_[0]->{'uid'} = getpwnam($in{'uid'});
}

