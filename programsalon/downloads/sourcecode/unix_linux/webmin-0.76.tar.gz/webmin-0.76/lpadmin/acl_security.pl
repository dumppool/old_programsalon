
require './lpadmin-lib.pl';

# acl_security_form(&options)
# Output HTML for editing security options for the lpadmin module
sub acl_security_form
{
print "<tr> <td valign=top><b>$text{'acl_printers'}</b></td>\n";
print "<td><select name=printers multiple size=3 width=15>\n";
local ($p, %pcan);
map { $pcan{$_}++ } split(/\s+/, $_[0]->{'printers'});
foreach $p (&list_printers()) {
	local $prn = &get_printer($p);
	printf "<option value=%s %s>%s (%s)\n",
		$p, $pcan{$p} || $pcan{'*'} ? 'selected' : '',
		$prn->{'desc'}, $p;
	}
print "</select></td> </tr>\n";

print "<tr> <td><b>$text{'acl_add'}</b></td>\n";
printf "<td><input type=radio name=add value=1 %s> $text{'yes'}\n",
	$_[0]->{'add'} ? "checked" : "";
printf "<input type=radio name=add value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'add'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_cancel'}</b></td>\n";
printf "<td><input type=radio name=cancel value=1 %s> $text{'yes'}\n",
	$_[0]->{'cancel'} ? "checked" : "";
printf "<input type=radio name=cancel value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'cancel'} ? "" : "checked";

print "<tr> <td><b>$text{'acl_stop'}</b></td>\n";
printf "<td><input type=radio name=stop value=1 %s> $text{'yes'}\n",
	$_[0]->{'stop'} ? "checked" : "";
printf "<input type=radio name=stop value=0 %s> $text{'no'}</td> </tr>\n",
	$_[0]->{'stop'} ? "" : "checked";
}

# acl_security_save(&options)
# Parse the form for security options for the bind8 module
sub acl_security_save
{
local @sel = split(/\0/, $in{'printers'});
local @prns = &list_printers();
if (scalar(@sel) == scalar(@prns)) {
	$_[0]->{'printers'} = '*';
	}
else {
	$_[0]->{'printers'} = join(" ", @sel);
	}
$_[0]->{'cancel'} = $in{'cancel'};
$_[0]->{'add'} = $in{'add'};
$_[0]->{'stop'} = $in{'stop'};
}

