
do './majordomo-lib.pl';
$conf = &get_config();
@lists = &list_lists($conf);

# useradmin_create_user(&details)
# Add a user to the mailing list
sub useradmin_create_user
{
foreach $l (@lists) {
	if ($config{"sync_$l"}) {
		local $dom = $config{"shost_$l"};
		$dom = &get_system_hostname() if (!$dom);
		local $pass = &find_value("admin_passwd",
			   &get_list_config(&get_list($l, $conf)->{'config'}));
		open(WRAPPER, "|$config{'program_dir'}/wrapper majordomo");
		print WRAPPER "From: root\n\n";
		print WRAPPER "approve $pass subscribe $l ",
			      "$_[0]->{'user'}\@$dom\n\n";
		close(WRAPPER);
		}
	}
}

# useradmin_delete_user(&details)
# Delete a user from the mailing list
sub useradmin_delete_user
{
foreach $l (@lists) {
	if ($config{"sync_$l"}) {
		local $dom = $config{"shost_$l"};
		$dom = &get_system_hostname() if (!$dom);
		local $pass = &find_value("admin_passwd",
			   &get_list_config(&get_list($l, $conf)->{'config'}));
		open(WRAPPER, "|$config{'program_dir'}/wrapper majordomo");
		print WRAPPER "From: root\n\n";
		print WRAPPER "approve $pass unsubscribe $l ",
			      "$_[0]->{'user'}\@$dom\n\n";
		close(WRAPPER);
		}
	}
}

# useradmin_modify_user(&details)
# Does nothing
sub useradmin_modify_user
{
}

1;

