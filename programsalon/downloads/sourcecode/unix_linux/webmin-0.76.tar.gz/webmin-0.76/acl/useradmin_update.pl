
do './acl-lib.pl';

# useradmin_create_user(&details)
# Does nothing, as webmin users must be created manually
sub useradmin_create_user
{
}

# useradmin_delete_user(&details)
# Delete this webmin user if in sync
sub useradmin_delete_user
{
local @list = &list_users();
foreach $u (@list) {
	if ($u->{'name'} eq $_[0]->{'user'} && $u->{'sync'}) {
		&delete_user($u->{'name'});
		&restart_miniserv();
		}
	}
}

# useradmin_modify_user(&details)
# Update this users password if in sync
sub useradmin_modify_user
{
return if ($_[0]->{'passmode'} == 4);
local @list = &list_users();
foreach $u (@list) {
	if ($u->{'name'} eq $_[0]->{'user'} && $u->{'sync'}) {
		$u->{'pass'} = $_[0]->{'pass'};
		&modify_user($u->{'name'}, $u);
		&restart_miniserv();
		}
	}
}

1;

