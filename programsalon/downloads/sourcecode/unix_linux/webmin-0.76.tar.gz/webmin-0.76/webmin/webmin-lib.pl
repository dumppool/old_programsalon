# webmin-lib.pl
# Common functions for configuring miniserv

do '../web-lib.pl';
&init_config("webmin");

@cs_codes = ( 'cs_page', 'cs_text', 'cs_table', 'cs_header', 'cs_link' );
@cs_names = map { $text{$_} } @cs_codes;

1;
