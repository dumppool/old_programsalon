// Sign_CertCtl.cpp : Implementation of the CSign_CertCtrl ActiveX Control class.

#include "stdafx.h"
#include "SIGN_CTRL.h"
#include "Sign_CertCtl.h"
#include "Sign_CertPpg.h"

#include "tcp.h"
#include "err.h"
#include "ca.h"
#include "util.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CSign_CertCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CSign_CertCtrl, COleControl)
	//{{AFX_MSG_MAP(CSign_CertCtrl)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CSign_CertCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CSign_CertCtrl)
	DISP_FUNCTION(CSign_CertCtrl, "Init", Init, VT_I4, VTS_NONE)
	DISP_FUNCTION(CSign_CertCtrl, "AddRequstData", AddRequstData, VT_I4, VTS_I4 VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_I4 VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_I4 VTS_I4 VTS_BSTR)
	DISP_FUNCTION(CSign_CertCtrl, "Sign", Sign, VT_I4, VTS_NONE)
	DISP_FUNCTION(CSign_CertCtrl, "GetSerialNo", GetSerialNo, VT_BSTR, VTS_I4)
	DISP_FUNCTION(CSign_CertCtrl, "GetCert", GetCert, VT_BSTR, VTS_I4)
	DISP_FUNCTION(CSign_CertCtrl, "FreeBuf", FreeBuf, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CSign_CertCtrl, "SetConfig", SetConfig, VT_I4, VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_BSTR VTS_I4)
	DISP_FUNCTION(CSign_CertCtrl, "GetErrMsg", GetErrMsg, VT_BSTR, VTS_NONE)
	DISP_FUNCTION(CSign_CertCtrl, "GetRes", GetRes, VT_I4, VTS_I4)
	DISP_FUNCTION(CSign_CertCtrl, "SetDebug", SetDebug, VT_EMPTY, VTS_I4)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CSign_CertCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CSign_CertCtrl, COleControl)
	//{{AFX_EVENT_MAP(CSign_CertCtrl)
	// NOTE - ClassWizard will add and remove event map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CSign_CertCtrl, 1)
	PROPPAGEID(CSign_CertPropPage::guid)
END_PROPPAGEIDS(CSign_CertCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CSign_CertCtrl, "SIGNCTRL.SignCertCtrl.1",
	0xf846dea8, 0x376a, 0x43dd, 0xaf, 0x67, 0x6e, 0xea, 0xf5, 0x32, 0xb7, 0xe5)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CSign_CertCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DSign_Cert =
		{ 0xa9d8c088, 0x755a, 0x4c71, { 0xa6, 0xec, 0xc6, 0xf3, 0x3e, 0xaa, 0xe, 0xe5 } };
const IID BASED_CODE IID_DSign_CertEvents =
		{ 0x50733012, 0xc3ea, 0x40b9, { 0xaa, 0xd6, 0xaa, 0x99, 0x7d, 0xd2, 0x3b, 0x31 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwSign_CertOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CSign_CertCtrl, IDS_SIGN_CERT, _dwSign_CertOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CSign_CertCtrl::CSign_CertCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CSign_CertCtrl

BOOL CSign_CertCtrl::CSign_CertCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_SIGN_CERT,
			IDB_SIGN_CERT,
			afxRegApartmentThreading,
			_dwSign_CertOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CSign_CertCtrl::CSign_CertCtrl - Constructor

CSign_CertCtrl::CSign_CertCtrl()
{
	InitializeIIDs(&IID_DSign_Cert, &IID_DSign_CertEvents);

	memset(&req_head, 0, sizeof(req_head));
	memset(&res_head, 0, sizeof(res_head));
	memset(errmsg, 0, sizeof(errmsg));
	preq_rec =NULL;
	pres_rec =NULL;
	b_sign =false;
	db_name[0] =db_user[0] =db_pass[0] =host[0] =0;
	port =TCP_PORT_SIGN_CA;
	memset(&issuer, 0, sizeof(issuer));
	db_init(&db_info);
	b_write_cert_valid =0;
	f_debug =GetProfileInt("signctrl", "debug", 0);
}

/////////////////////////////////////////////////////////////////////////////
// CSign_CertCtrl::~CSign_CertCtrl - Destructor

CSign_CertCtrl::~CSign_CertCtrl()
{
	FreeBuf();
	db_exit(&db_info);
}


/////////////////////////////////////////////////////////////////////////////
// CSign_CertCtrl::OnDraw - Drawing function

void CSign_CertCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
	pdc->SetBkMode(TRANSPARENT);
	pdc->TextOut(2, 2, "Cert");
}


/////////////////////////////////////////////////////////////////////////////
// CSign_CertCtrl::DoPropExchange - Persistence support

void CSign_CertCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.

}


/////////////////////////////////////////////////////////////////////////////
// CSign_CertCtrl::OnResetState - Reset control to default state

void CSign_CertCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CSign_CertCtrl::AboutBox - Display an "About" box to the user

void CSign_CertCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_SIGN_CERT);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CSign_CertCtrl message handlers

long CSign_CertCtrl::Init() 
{
	// TODO: Add your dispatch handler code here

	return 0;
}

#define MAX_CERT_TYPE	4

int certi_types[] ={0, 1, 2, 5};

long CSign_CertCtrl::AddRequstData(long type, LPCTSTR req_serial_no,
								   LPCTSTR ca_id, LPCTSTR ra_id,
								   LPCTSTR rs_id, LPCTSTR subject_country,
								   LPCTSTR subject_state, LPCTSTR subject_org,
								   LPCTSTR subject_org_unit, LPCTSTR subject_common_name,
								   LPCTSTR subject_career, LPCTSTR subject_city,
								   LPCTSTR subject_street, LPCTSTR subject_zip_code,
								   LPCTSTR subject_tel, LPCTSTR subject_email,
								   long subject_base64_pki_len,
								   LPCTSTR subject_base64_pki, LPCTSTR not_before, LPCTSTR not_after,
								   LPCTSTR key_usage, LPCTSTR extensions_flag,
								   LPCTSTR credit_class, long certi_class_code, long b_safe_keep_private_key,
								   LPCTSTR subject_base64_private_key)
{
	REC_REQ_SIGN_CERT *prec;
	unsigned char base64_public_key[2048], base64_private_key[2048];
	char sqlstm[600], temp[256];
	DB_QUERY_INFO db_query;
	time_t t;
	struct tm *ptm;
	
	if(type >MAX_CERT_TYPE) return -1;

	if(b_sign) req_head.rec_count =0;
	b_sign =false;
	
	if(preq_rec)
		preq_rec =(REC_REQ_SIGN_CERT *)realloc(preq_rec, sizeof(REC_REQ_SIGN_CERT)*(req_head.rec_count+1));
	else preq_rec =(REC_REQ_SIGN_CERT *)malloc(sizeof(REC_REQ_SIGN_CERT)*(req_head.rec_count+1));
	if(preq_rec ==NULL)
		return EMEMALLOC;
	//::MessageBox(NULL, "malloc mem ok", "debug", MB_OK);
	prec =&preq_rec[req_head.rec_count];
	memset(prec, 0, sizeof(REC_REQ_SIGN_CERT));

	req_head.req_type =REQ_TYPE_SIGN_CERT;
	req_head.rec_size =sizeof(REC_REQ_SIGN_CERT);
	if(key_usage[0] ==0)
		strcpy((char *)key_usage, "0");
	if(extensions_flag[0] ==0)
		strcpy((char *)extensions_flag, "01");
	
	if(f_debug) ::MessageBox(NULL, "0001", "debug", MB_OK);
	if(not_after[0] ==0 || not_before[0] ==0)
	{
		time(&t);
		ptm =localtime(&t);
		wsprintf(prec->not_before, "%04d%02d%02d%02d%02d%02d", ptm->tm_year+1900, ptm->tm_mon+1,
			ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
		wsprintf(sqlstm, "select valid_date from cert_validdate "
			" where cert_typecode='%d' and key_usage='%s' and credit_class='%s' "
			" and certi_class_code='%d'", certi_types[type], /*Crypt_Int2Char()*/key_usage, credit_class,
			certi_class_code);

		if(f_debug) ::MessageBox(NULL, sqlstm, "debug", MB_OK);
		int valid_mon =3;
		db_query_init(&db_query, &db_info);
		int ret;
		if((ret =db_query_select(&db_query, sqlstm)) >0
			&& db_query_fetch(&db_query) >0)
		{
			get_field_value2(&db_query, 0, temp);
			if(f_debug) ::MessageBox(NULL, temp, "valid_date", MB_OK);
			valid_mon =atoi(temp);
		}
		else
		{
			char tmp[256];
			
			//if(ret <=0)
			{
				wsprintf(tmp, "%s:%s", db_get_error_string(&db_info), sqlstm);
				::MessageBox(NULL, tmp, "select valid from cert_validdate failed", MB_OK);
			}
		add_mon(t, valid_mon, prec->not_after);
		}
		ptm =localtime(&t);
		wsprintf(prec->not_after, "%04d%02d%02d%02d%02d%02d", ptm->tm_year+1900, ptm->tm_mon+1,
				ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);

		db_query_close(&db_query);
	}
	else
	{
		strcpy(prec->not_after, not_after);
		strcpy(prec->not_before, not_before);
	}
	if(f_debug) ::MessageBox(NULL, prec->not_after, prec->not_before, MB_OK);

if(f_debug) ::MessageBox(NULL, "0003", "debug", MB_OK);
	db_query_init(&db_query, &db_info);
	int tt;
	if(db_query_select(&db_query, "select policy_value from ca_policy where policy_id='KTOC'") >0
		&& db_query_fetch(&db_query) >0)
	{
		get_field_value_by_name2(&db_query, "policy_value", temp);
		tt =atoi(temp);
	}
	else
		tt =-30;
	db_query_close(&db_query);
if(f_debug) ::MessageBox(NULL, "0004", "debug", MB_OK);
	strcpy(prec->private_key_not_before, prec->not_before);
	struct tm ttm;
	sscanf(prec->not_after, "%04d%02d%02d%02d%02d%02d", &ttm.tm_year, &ttm.tm_mon,
		&ttm.tm_mday, &ttm.tm_hour, &ttm.tm_min, &ttm.tm_sec);
	ttm.tm_year -=1900;
	ttm.tm_mon--;
	t =mktime(&ttm)+tt*24*3600;
	ptm =localtime(&t);
if(f_debug) ::MessageBox(NULL, "0007", "debug not_after", MB_OK);
	wsprintf(prec->private_key_not_after, "%04d%02d%02d%02d%02d%02d",ptm->tm_year+1900, ptm->tm_mon+1,
				ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
if(f_debug) ::MessageBox(NULL, "0008", "debug not_after", MB_OK);
	db_query_init(&db_query, &db_info);
	if(db_query_select(&db_query, "select parameter_value from system_parameter where parameter_name='SURL'") >0
		&& db_query_fetch(&db_query) >0)
		get_field_value_by_name2(&db_query, "parameter_value", prec->revocation_url);
	else strcpy(prec->revocation_url, "http://www.cpca.com");
	db_query_close(&db_query);

if(f_debug) ::MessageBox(NULL, "0005", "debug", MB_OK);
	if(subject_base64_pki_len <=0 || subject_base64_pki[0] ==0)
	{
		db_query_init(&db_query, &db_info);
		if(db_query_select(&db_query, "select public_key, private_key from key_pair") >0
			&& db_query_fetch(&db_query)>0)
		{
			get_field_value_by_name2(&db_query, "public_key", (char *)base64_public_key);
			get_field_value_by_name2(&db_query, "private_key", (char *)base64_private_key);
			db_query_close(&db_query);
		}
		else
		{
			wsprintf(errmsg, "select public_key, private_key from key_pair failed or no data");
			db_query_close(&db_query);
			return EDBSELECT;
		}
		prec->b_pki_created_from_ca =1;
	}
	else
	{
		strcpy((char *)base64_public_key, subject_base64_pki);
		strcpy((char *)base64_private_key, subject_base64_private_key);
	}

if(f_debug) ::MessageBox(NULL, "PEM2DER...", "debug", MB_OK);
	if(PEM2DER_data_format(base64_public_key, strlen((char *)base64_public_key), prec->pkcs10_params.subject_pki, &prec->pkcs10_params.subject_pki_len) !=0)
	{
		wsprintf(errmsg, "PEM2DER_data_format base64_public_key failed!");
		return EFORMAT_CONVERT;
	}
if(f_debug) ::MessageBox(NULL, "PEM2DER private_key", "debug", MB_OK);
	if(base64_private_key[0] && PEM2DER_data_format(base64_private_key, strlen((char *)base64_private_key), prec->private_key, &prec->private_key_len) !=0)
	{
		wsprintf(errmsg, "PEM2DER_data_format base64_private_key failed!");
		return EFORMAT_CONVERT;
	}

	prec->pkcs10_params.subject_pki_len =tcp_htonl(prec->pkcs10_params.subject_pki_len);
	prec->private_key_len =tcp_htonl(prec->private_key_len);
	strcpy(prec->usage, key_usage);
	strcpy(prec->extensions_type, extensions_flag);
	//prec->basic_constraints_ca =tcp_htonl(0);
	//prec->basic_constraints_path_len =tcp_htonl(0xFFFFFFFF);
	//prec->critical_flag =tcp_htonl(0);
	//prec->ne_cert_type =tcp_htonl(neCertType);
	prec->b_safe_keep_private_key =(char)b_safe_keep_private_key;

	prec->type =(char)type;
	strcpy(prec->req_serial_no, req_serial_no);
	strcpy(prec->ca_id, ca_id);
	strcpy(prec->ra_id, ra_id);
	strcpy(prec->rs_id, rs_id);
	strcpy(prec->subject_email, subject_email);
	
	//strcpy(prec->pki_id, subject_pki_id);
	strcpy(prec->pki_id, "RS");
	//prec->pkcs_id =3;
	
if(f_debug) ::MessageBox(NULL, "0006", "debug", MB_OK);
	prec->pkcs10_params.version =tcp_htonl(2);
	strcpy(prec->pkcs10_params.subject_country, subject_country);
	strcpy(prec->pkcs10_params.subject_org, subject_org);
	strcpy(prec->pkcs10_params.subject_org_unit, subject_org_unit);
	strcpy(prec->pkcs10_params.subject_common_name, subject_common_name);
	strcpy(prec->pkcs10_params.subject_career, subject_career);
	strcpy(prec->pkcs10_params.subject_state, subject_state);
	strcpy(prec->pkcs10_params.subject_local, subject_city);
	strcpy(prec->pkcs10_params.subject_street, subject_street);
	strcpy(prec->pkcs10_params.subject_zip_code, subject_zip_code);
	strcpy(prec->pkcs10_params.subject_tel, subject_tel);

	strcpy(prec->pkcs10_params.subject_given_name, "");
	prec->pkcs10_params.subject_initials =(char)0;
	strcpy(prec->pkcs10_params.subject_sur_name, "");
	strcpy(prec->pkcs10_params.subject_post_office_box, "");

	req_head.rec_count++;

	return 0;
}

long CSign_CertCtrl::Sign() 
{
	int sd, count, i;
	
	b_sign =true;


	if((sd =tcp_connect(host, port, NULL, 15)) <0)
		return ETCPCONNECT;
	if(f_debug) ::MessageBox(NULL, "Sign0001", "debug", MB_OK);
	count =req_head.rec_count;
	req_head.rec_count =tcp_htonl(req_head.rec_count);
	req_head.rec_size =tcp_htonl(req_head.rec_size);
	if(tcp_send(sd, (char *)&req_head, sizeof(req_head), 15) !=sizeof(req_head))
	{
		tcp_close(sd);
		strcpy(errmsg, "send req_head failed!");
		return ETCPSEND;
	}
	if(tcp_send(sd, (char *)preq_rec, count*sizeof(REC_REQ_SIGN_CERT), 30) !=count*(int)sizeof(REC_REQ_SIGN_CERT))
	{
		tcp_close(sd);
		wsprintf(errmsg, "send preq_rec failed! count=%d", count);
		return ETCPSEND;
	}
	wsprintf(errmsg, "recv data...");
	if(tcp_recv(sd, (char *)&res_head, sizeof(res_head), 120) !=sizeof(res_head))
	{
		tcp_close(sd);
		strcpy(errmsg, "recv res_head failed");
		return ETCPRECV;
	}
	if(res_head.res <0)
	{
		tcp_close(sd);
		wsprintf(errmsg, "server return failed, res=%d", res_head.res);
		return ESERVER;
	}
	res_head.rec_count =tcp_ntohl(res_head.rec_count);
	res_head.rec_size =tcp_ntohl(res_head.rec_size);
	if(pres_rec) free(pres_rec);
	if(f_debug) ::MessageBox(NULL, "Sign0002", "debug", MB_OK);
	if((pres_rec =(REC_RES_SIGN_CERT *)malloc(res_head.rec_count*res_head.rec_size)) ==NULL)
	{
		tcp_close(sd);
		wsprintf(errmsg, "malloc pres_rec failed! rec_count =%d, rec_size=%d", res_head.rec_count, res_head.rec_size);
		return EMEMALLOC;
	}
	if(tcp_recv(sd, (char *)pres_rec, res_head.rec_count*sizeof(REC_RES_SIGN_CERT), 30) !=res_head.rec_count*(int)sizeof(REC_RES_SIGN_CERT))
	{
		tcp_close(sd);
		wsprintf(errmsg, "tcp_recv pres_rec failed! rec_count:%d, rec_size:%d", res_head.rec_count, res_head.rec_size);
		return ETCPRECV;
	}
	tcp_close(sd);
  
	if(f_debug) ::MessageBox(NULL, "Sign0003", "debug", MB_OK);
	if(!b_write_cert_valid) return 0;

	if(f_debug) ::MessageBox(NULL, "write cert_valid", "debug", MB_OK);

	char stmt[800];
	unsigned char public_key[2048];
	int public_key_len =0;
	char *p[5];
	int len[5];

	for(i =0; i<res_head.rec_count; i++)
	{
	db_begin_trans(&db_info);
		if(pres_rec[i].res ==0)
		{
			::MessageBox(NULL, "Begin DER2PEM", "debug", MB_OK);
			if(DER2PEM_data_format(preq_rec[i].pkcs10_params.subject_pki, preq_rec[i].pkcs10_params.subject_pki_len, public_key, (unsigned int *)&public_key_len, "-----Begine PublicKey-----", "-----End PublicKey-----") !=0)
			{
				//write_log("err.log", "DER2PEM public_key failed!");
				db_roll_back(&db_info); 
				continue;
			}
			::MessageBox(NULL, "DER2PEM ok", "debug", MB_OK);
			sprintf(stmt, "insert into cert_valid values('%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', TO_DATE('%s', 'YYYYMMDDHH24MISS'), TO_DATE('%s', 'YYYYMMDDHH24MISS'), '', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s',:p1, '%d', '', '', 1024, '', :p2, '%d', '%d', '12345', '12345', '', '0')",
				pres_rec[i].serial_no, preq_rec[i].credit_class, preq_rec[i].ca_id, preq_rec[i].certi_class, preq_rec[i].req_serial_no, certi_types[preq_rec[i].type], preq_rec[i].pkcs10_params.version, preq_rec[i].ra_id, preq_rec[i].not_before, preq_rec[i].not_after, pres_rec[i].issuer_id, preq_rec[i].pkcs10_params.subject_country, preq_rec[i].pkcs10_params.subject_state, preq_rec[i].pkcs10_params.subject_local, preq_rec[i].pkcs10_params.subject_org, preq_rec[i].pkcs10_params.subject_common_name, preq_rec[i].pkcs10_params.subject_org_unit, preq_rec[i].pkcs10_params.subject_street, preq_rec[i].pkcs10_params.subject_zip_code, preq_rec[i].pkcs10_params.subject_tel, preq_rec[i].subject_email, preq_rec[i].pki_id, pres_rec[i].key_usage, pres_rec[i].basic_constraints_ca, pres_rec[i].basic_constraints_path_len);
			p[0] =(char *)public_key;
			len[0] =strlen(p[0]);
			p[1] =(char *)&pres_rec[i].base64_cert[0];
			len[1] =strlen(p[1]);
			::MessageBox(NULL, "db_exec_bind_long", "debug", MB_OK);
			if(db_exec_bind_long(&db_info, stmt, 2, &p[0], &len[0]) <0)
			{
		        //write_log("err.log", "insert into cert_valid failed, serail_no=%s, base64_certi=%s\n sql='%s', db_err:%s\n", pres_rec[i].serial_no, pres_rec[i].base64_cert, stmt, db_get_error_string(&db_info));
				db_roll_back(&db_info);
				continue;
			}
 			::MessageBox(NULL, "db_exec_bind_long ok", "debug", MB_OK);
     if(preq_rec[i].b_pki_created_from_ca)
      {
        sprintf(stmt, "insert into key_pair_used(serial_no, public_key, private_key) values('%s', :p1, :p2)");
        p[0] =(char *)&public_key[0];
        p[1] =(char *)&preq_rec[i].private_key[0];
        len[0] =strlen((char *)public_key);
        len[1] =strlen((char *)preq_rec[i].private_key);
        if(db_exec_bind_long(&db_info, stmt, 2, &p[0], &len[0]) <0)
        {
          //write_log("err.log", "failed insert key_pair_used, sql=%s", stmt);
          db_roll_back(&db_info);
          continue;
        }
        sprintf(stmt, "delete from key_pair where public_key=:p1");
        if(db_exec_bind_long(&db_info, stmt, 1, &p[0], &len[0]) <0)
        {
          //write_log("err.log", "failed insert key_pair_used, sql=%s", stmt);
          db_roll_back(&db_info);
          continue;
        }
      }
    }
    else
    {
      //write_log("err.log", "sign cert failed!, i=%d, res=%d\n", i, pres_rec[i].res);
    }
  }
  db_commit(&db_info);
  db_close(&db_info);
	return 0;
}

BSTR CSign_CertCtrl::GetSerialNo(long num)
{
	CString *strResult;
	if(num >=res_head.rec_count) return NULL;

	strResult =new CString(pres_rec[num].serial_no);

	return strResult->AllocSysString();
}

BSTR CSign_CertCtrl::GetCert(long num) 
{
	CString *strResult;
	if(f_debug) ::MessageBox(NULL, "GetCert0001", "debug", MB_OK);
	if(num >=res_head.rec_count) return NULL;
	if(f_debug) ::MessageBox(NULL, "GetCert0002", "debug", MB_OK);

	strResult =new CString(pres_rec[num].base64_cert);

	return strResult->AllocSysString();
}

void CSign_CertCtrl::FreeBuf() 
{
	if(preq_rec) free(preq_rec);
	req_head.rec_count =0;
	preq_rec =NULL;
	if(pres_rec) free(pres_rec);
	pres_rec =NULL;
}

long CSign_CertCtrl::SetConfig(LPCTSTR whoami, LPCTSTR db_name, LPCTSTR db_user, LPCTSTR db_pass, LPCTSTR host, long port)
{
	if(strcmpi(whoami, "SIGN_CA") ==0) b_write_cert_valid =0;
	else b_write_cert_valid =1;
	if(f_debug) ::MessageBox(NULL, whoami, "whoami", MB_OK);
	//b_write_cert_valid =0;

	strcpy(this->db_name, db_name);
	strcpy(this->db_user, db_user);
	strcpy(this->db_pass, db_pass);
	strcpy(this->host, host);
	this->port = port;
	
	if(!db_is_connected(&db_info))
	{
		if(db_connect(&db_info, (char *)db_name, (char *)db_user, (char *)db_pass) <0)
		{
			strcpy(errmsg, "db_connect failed!");
			::MessageBox(NULL, "connect db failed", db_name, MB_OK);
			return EDBCONNECT;
		}
	}
	return 0;
}

BSTR CSign_CertCtrl::GetErrMsg() 
{
	CString *strResult;
	
	strResult =new CString(errmsg);

	return strResult->AllocSysString();
}

long CSign_CertCtrl::GetRes(long num) 
{
	char temp[256];

	if(num >=res_head.rec_count)
	{
		wsprintf(temp, "GetRes:num too big:%d, rec_count=%d�����ܻ�û�з�������", num, res_head.rec_count);
		MessageBox(temp, "error", MB_OK);
		return -1;
	}

	return (long)pres_rec[num].res;
}

void CSign_CertCtrl::SetDebug(long f_debug) 
{
	this->f_debug =f_debug;
}
