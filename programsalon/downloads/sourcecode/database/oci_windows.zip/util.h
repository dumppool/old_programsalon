
#ifndef __UTIL_H_

char *GetFilePath(char *file, char *path); /* get path from full path name */
char *GetFileName(char *file);    /* get file name from full path name */
char *del_all_spaces(char *p);    /* del all spaces */
char *del_lr_spaces(char *pbuf);  /* del left and right spaces */
char *del_rn(char *pbuf);         /* del \r and \n */

int write_log(char *file, char *format, ...);

int read_config_string(char *config_file, char *item, char *str_buf);
int read_config_int(char *config_file, char *item, int *int_buf);
int write_config_string(char *config_file, char *item, char *str_buf);
int write_config_int(char *config_file, char *item, int *int_buf);

char *lower_case(char *);
char *upper_case(char *);
int add_mon(time_t, int, char *);

#endif

