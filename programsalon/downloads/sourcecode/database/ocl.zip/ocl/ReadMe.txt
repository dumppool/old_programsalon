Oracle Class Library for C++ 1.00.1.11
Copyright 1999-2001, Core Lab. All Rights Reserved
--------------------------------------------------

Oracle Class Library (OCL) provides native connectivity to the Oracle
database server. OCL uses Oracle Call Interface (OCI) directly. OCI is
low-level native application programming interface to access to Oracle.
Using OCI in Oracle Class Library allows to create lightweight and fast
applications working with Oracle. Oracle Class Library encapsulates OCI
calls in high-level classes that allows to hide the complexity of using
OCI directly and keep performance and all abilities of native routines.
With OCL you can use the power and flexibility of SQL in your application
programs without any restrictions.

OCL contains classes to control connection, execute SQL statements, store
and process result rows of queries and some common classes useful for
developing database applications. All classes have intuitive, easy to use
interface. 

OCL is written with ANSI C++ and uses Standard C++ Library only that
allows you to port your application easily to another platform. 
Oracle Class Library provides easiness in using from Pro*C/C++ and power
of Oracle Call Interface. 

OCL allows you to 

 - design and develop highly customized database applications  
 - improve performance of data processing in your applications  
 - compile the same application for different platforms  
 - automatically convert between Oracle internal datatypes and high-level
   language datatypes  
 - fetch rows quickly  
 - cache result rows in memory to process them later  
 - use arrays as input and output program variables  
 - call stored procedures easily  
 - handle errors  
 - use LONG fields in the database  

To sum it up, OCL is a full-featured tool that supports a professional
approach to develop database applications. 

OCL 1.00 includes library for Visual C++ 6.0, Borland C++ Builder 5 and
GNU compliler.

Using
-----

To support OCL in your project you need

- Add OCL header and OCI header folders
- Add OCL library and OCI library
- Insert OCL header #include "ocl.h"

OCL headers: ocl\include
OCL library: MSVC: ocl\lib\msvc\ocl.lib
             BCB: ocl\lib\bcb\ocl.lib
             gcc: libocl.a or libocl.so in ocl\lib\gnu\ 

OCI headers: ocl\oci\include or 
             MSWIN: <ORACLE_HOME>\oci\include
             Linux: $ORACLE_HOME/rdbms/demo
OCI library: MSVC: ociw32.lib or oci.lib in ocl\oci\lib\msvc\ or
                   <ORACLE_HOME>\oci\lib\msvc\
             BCB: ociw32.lib or oci.lib in ocl\oci\lib\bcb\ or
                  <ORACLE_HOME>\oci\lib\bc\
             gcc: $ORACLE_HOME/lib/libclntsh.so


