 
//////////////////////////////////////////////////
//  Oracle Class Library
//  Copyright � 1999-2001 Core Lab. All right reserved.
//  Ora trace
//  Last modified:      13.03.00
//////////////////////////////////////////////////

#ifndef __ORATRACE_H__
#define __ORATRACE_H__

#include "crdef.h"

//enum TObjectType {otSession,otSQL,otDataSet,otException};
//enum TActionType {atError,atConnect,atDisconnect,atCommit,atRollback,atPrepare,atExecute,atUnprepare};

typedef int TObjectType;

const TObjectType otSession    = 1;
const TObjectType otSQL        = 2;
const TObjectType otDataSet    = 3;
const TObjectType otException  = 4;

typedef int TActionType;

const TActionType atError      = 1;
const TActionType atConnect    = 2;
const TActionType atDisconnect = 3;
const TActionType atCommit     = 4;
const TActionType atRollback   = 5;
const TActionType atPrepare    = 6;
const TActionType atExecute    = 7;
const TActionType atUnprepare  = 8;

typedef void TOCLTraceProc(TObjectType ObjectType, void* Object, TActionType ActionType);

extern TOCLTraceProc* OCLTraceProc;

void SetOCLTraceProc(TOCLTraceProc Proc);
CCRString GetTraceInfo(TObjectType ObjectType, void* Object, TActionType ActionType);

#endif
