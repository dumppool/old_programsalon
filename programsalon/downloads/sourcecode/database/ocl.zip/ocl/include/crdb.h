
//////////////////////////////////////////////////
//  Oracle Class Library
//  Copyright � 1999-2001 Core Lab. All right reserved.
//  Dataset
//  Last modified:      29.01.01
/////////////////////////////////////////////////

#ifndef __DATASET_H__
#define __DATASET_H__

#include "crdef.h"

//////////////////  Data types  /////////////////

typedef word TCRDataType;

const TCRDataType dtUnknown = 0;
const TCRDataType dtString  = 1;
const TCRDataType dtInt8    = 2;
const TCRDataType dtInt16   = 3;
const TCRDataType dtInt32   = 4;
const TCRDataType dtInt     = dtInt32;
const TCRDataType dtInteger = dtInt;
const TCRDataType dtFloat   = 5;
const TCRDataType dtDouble  = 6;
const TCRDataType dtDate    = 7;
const TCRDataType dtBlob    = 10;
const TCRDataType dtMemo    = 11;

////////////////  CCRDBException  /////////////////

class CCRDBException : public CCRException {
public:
  CCRDBException(const char* msg) : CCRException(msg) {};
};

class CCRDataset;
class CCRBlob;

////////////////////  CCRValue  //////////////////

class CCRValue {
public:
  CCRValue();
  CCRValue(int value);
  CCRValue(float value);
  CCRValue(double value);
  CCRValue(const CCRString& value);
  CCRValue(const char* value);
  CCRValue(const CCRDate& value);
  CCRValue(const CCRValue& value);
  virtual ~CCRValue();

  enum TValueType {
    None,
    Int,
    Float,
    Double,
    String,
    Date
  };

  TValueType type() const;
  void setType(TValueType type);

  bool isNull() const;
  void setNull();

  int getInt() const;
  float getFloat() const;
  double getDouble() const;
  CCRString getString() const;
  CCRDate getDate() const;

  void setInt(int value);
  void setFloat(float value);
  void setDouble(double value);
  void setString(const CCRString& value);
  void setString(const char* value);
  void setDate(const CCRDate& value);
  void setValue(const CCRValue& value);

  void assign(int value) { setInt(value); };
  void assign(float value) { setFloat(value); };
  void assign(double value) { setDouble(value); };
  void assign(const CCRString& value) { setString(value); };
  void assign(const char* value) { setString(value); };
  void assign(const CCRDate& value) { setDate(value); };
  void assign(const CCRValue& value) { setValue(value); };

  //operator int() { return asInt(); };

protected:
  union {
    int mInt;
    float mFloat;
    double mDouble;
    CCRDate* mDate;
    CCRString* mString;
  };

  void clear();

private:
  byte mInfo;
};

///////////////////  CCRField  ///////////////////

const int bufSize = 30;

class CCRField {
public:
  CCRField();
  CCRField(const char* name, TCRDataType dataType, int size, bool required = false, int fieldNo = 0);
  ~CCRField();

  const char* name() const;
  int dataType() const;
  int size() const;      // internal data size
  int offset() const;    // internal offset
  bool required() const;
  int fieldNo() const;
  int length() const;
  int precision() const;
  int scale() const;

  bool isComplex() const;
  bool hasParent() const;

  bool isNull();
  void setNull();

  CCRDate getDate();
  void setDate(const CCRDate& value);
  double getDouble();
  void setDouble(double value);
  float getFloat();
  void setFloat(float value);
  int getInt();
  void setInt(int value);
  const char* getString();
  char* getString(char* result);
  void setString(const char* value);
  void setString(const CCRString& value);
  CCRBlob& getBlob();
  void setBlob(const CCRBlob& value);

  void assign(const CCRDate& value) { setDate(value); };
  void assign(int value) { setInt(value); };
  void assign(double value) { setDouble(value); };
  void assign(const char* value) { setString(value); };
  void assign(const CCRString& value) { setString(value); };

  void assign(const CCRField& value);

protected:
  CCRString mName;
  CCRString mActualName;
  TCRDataType mDataType;
  bool mRequired;
  int mFieldNo;
  int mLength;
  int mPrecision;
  int mScale;
  int mSize;  // size of memory for storage data
  int mOffset;  // offset 
  char mBuf[bufSize];

  CCRDataset* mDataset;

  int getData(void* buffer);
  void setData(void* buffer);

  friend class CCRDataset;
};

//////////////////  CCRFields  ///////////////////

typedef CCRNamedList <CCRField> CCRFields;

//////////////////  CCRDataset  //////////////////

enum TCRDatasetState {dsInactive,dsBrowse,dsInsert,dsEdit};

class CCRDataset {
public:
  CCRDataset();
  virtual ~CCRDataset();

// Open / close
  void prepare();
  void unprepare();
  void open();
  void close();
  void refresh();

  bool isPrepared() const;
  bool isActive() const;

// Fields
  virtual void initFields();

  int fieldCount() const;
  CCRFields& fields();

  CCRField& field(int index) const;
  CCRField& field(const char* name) const;
  CCRField* findField(int index) const;
  CCRField* findField(const char* name) const;

// Edit
  void insert();
  void append();
  void remove();
  void edit();

  void post();
  void cancel();

// Navigation
  virtual bool isEOF() const;
  virtual bool isBOF() const;

  void first();
  void last();
  void next();
  void prev();
  virtual int move(long distance);
  virtual bool moveTo(long recNo);

// Bookmarks
  virtual void getBookmark(void** bookmark);
  virtual bool moveToBookmark(void* bookmark);
  void freeBookmark(void* bookmark);

// Misc
  long recordCount() const;
  virtual long recordNo() const;

  CCRField& operator[](int index) const { return field(index); };
  CCRField& operator[](const char* name) const { return field(name); };

protected:
  CCRFields mFields;

  int mDataSize;       // size of data
  int mIndicatorsSize; // size of indicators
  int mRecordSize;     // FDataSize + TIndicatorSize
  long mRecordCount;
  int mComplexFieldCount;

  bool mBOF;
  bool mEOF;
  TCRDatasetState mState;
  bool mPrepared;
  bool mImplicitPrepare;

  char* activeBuffer;
  char* tempBuffer;

// Open / close
  virtual void internalPrepare();
  virtual void internalUnprepare();

  virtual void internalOpen();
  virtual void internalClose();

  virtual void internalRefresh();

// Items / data
  virtual void initData();
  virtual void freeData();
  virtual void prepareData();

// Fields
  virtual void internalInitFields();

  bool getField(CCRField* field, void* recBuf, void* dest);
  bool getFieldBuf(CCRField* field, void* recBuf, void** fieldBuf);
  void putField(CCRField* field, void* recBuf, void* source);

  virtual bool getNull(CCRField* field, void* recBuf);
  virtual void setNull(CCRField* field, void* recBuf, bool value);

  virtual void getDateFromBuf(void* buf, void* date);
  virtual void putDateToBuf(void* buf, void* date);

  bool getFieldData(CCRField* field, void* dest);
  bool getFieldDataBuf(CCRField* field, void** fieldBuf);
  void putFieldData(CCRField* field, void* source);

  bool hasComplexFields();
  virtual void createComplexFields(void* recBuf, bool withBlob = true);
  virtual void freeComplexFields(void* recBuf, bool withBlob = true);

// Records / buffers
  char* allocRecBuf();
  void freeRecBuf(void* recBuf);

  void allocBuffers();
  void freeBuffers();
  virtual bool validBuffer();

  void initRecord(void* recBuf);

  virtual void getRecord(void* recBuf);
  virtual void getNextRecord(void* recBuf);
  virtual void getPrevRecord(void* recBuf);
  virtual void putRecord(void* recBuf);

  virtual void insertRecord(void* recBuf);
  virtual void appendRecord(void* recBuf);
  void appendBlankRecord();
  virtual void updateRecord(void* recBuf);
  virtual void deleteRecord();

  void omitRecords();

// Edit
  virtual void doInsert();
  virtual void doDelete();
  virtual void doUpdate();

// Navigation
  virtual void internalFirst();
  virtual void internalLast();

  friend class CCRField;
};

/////////////////  CBlockman  ///////////////////

const int btSign = 0xDD;   // DEBUG
const int flUsed = 0xEE;
const int flFree = 0xDD;

const int defaultPieceSize = 64*1024 - 22;

struct TBlockHeader {
  word itemCount;
  word usedItems;
  TBlockHeader* prev;
  TBlockHeader* next;
  byte test;       // DEBUG
};

struct TItemHeader {
  TBlockHeader* block;
  TItemHeader* prev;
  TItemHeader* next;
  TItemHeader* rollback;
  //TItemStatus status;
  long order;
  byte flag;
};

class CBlockman {
public:
  CBlockman();
  ~CBlockman();

  TBlockHeader* allocBlock(int itemCount);
  void freeBlock(TBlockHeader* block);

  void addFreeBlock();
  void freeAllBlock();

  TItemHeader* allocItem();
  void freeItem(TItemHeader* item);

  void getData(TItemHeader* item, void* desc);
  void putData(TItemHeader* item, void* source);

  TBlockHeader* firstBlock();
  TItemHeader* firstFree();
  void setFirstFree(TItemHeader* firstFree);
  void setDataSize(int dataSize);

protected:
  TBlockHeader* mFirstBlock;
  TItemHeader* mFirstFree;
  word mDataSize;
  word mDefaultItemCount;
};

////////////////  CCRMemDataset  /////////////////

enum TReorderOption {roInsert,roDelete,roFull};

class CCRMemDataset : public CCRDataset {
public:
  CCRMemDataset();
  virtual ~CCRMemDataset();

// Navigation
  virtual bool isEOF() const;
  virtual bool isBOF() const;
  virtual bool moveTo(long recNo);

// Bookmarks
  virtual void getBookmark(void** bookmark);
  virtual bool moveToBookmark(void* bookmark);

// Misc
  virtual long recordNo() const;

protected:
  CBlockman mBlockman;
  TItemHeader* mFirstItem;
  TItemHeader* mLastItem;
  TItemHeader* mCurrentItem;
  long mRecordNoOffset;

// Items / data
  TItemHeader* insertItem();
  TItemHeader* appendItem();
  void deleteItem(TItemHeader* item);

  virtual void initData();
  virtual void freeData();
  virtual void prepareData();

  void reorderItems(TItemHeader* item, TReorderOption reorderOption);

// Records / buffers
  virtual bool validBuffer();

  virtual void getRecord(void* recBuf);
  virtual void getNextRecord(void* recBuf);
  virtual void getPrevRecord(void* recBuf);
  virtual void putRecord(void* recBuf);

  virtual void insertRecord(void* recBuf);
  virtual void appendRecord(void* recBuf);
  virtual void updateRecord(void* recBuf);
  virtual void deleteRecord();

  bool omitRecord(TItemHeader* item);

// Navigation
  virtual void internalFirst();
  virtual void internalLast();

private:
  long mRefreshIteration;
};

////////////////  CSharedObject  ////////////////

class CCRSharedObject {
public:
  CCRSharedObject();

  int addRef();
  void release();

protected:
  int mRefCount;
};

///////////////////  CCRBlob  ////////////////////

struct TPieceHeader {
  CCRBlob* blob;
  long size;
  long used;  // offest 8 uses GetUsedPtr
  TPieceHeader* prev;
  TPieceHeader* next;
  byte test;       // DEBUG
};

class CCRBlob : public CCRSharedObject {
public:
  CCRBlob();
  ~CCRBlob();

// Pieces
  TPieceHeader* allocPiece(long size);
  void reallocPiece(TPieceHeader** piece, long size);
  void freePiece(TPieceHeader* piece);
  void appendPiece(TPieceHeader* piece);
  void deletePiece(TPieceHeader* piece);
  void compressPiece(TPieceHeader** piece);

  TPieceHeader* firstPiece() const;
  long defPieceSize() const;

  long read(long position, long count, void* dest);
  void write(long position, long count, void* source);
  void clear();
  void truncate(long newSize);
  void compress();

// Stream/File

  void loadFromFile(const char* fileName);
  void saveToFile(const char* fileName);

  const char* getString() const;
  char* getString(char* result);
  void setString(const char* value);
  void setString(const CCRString& value);

  void assign(CCRBlob& source);

// Cached
  void enableCache();
  void commit();
  void cancel();

  long size() const;

protected:
  long mDefPieceSize;
  byte test;   // DEBUG

  void checkValid();   // DEBUG
  void checkCached();

  void saveToRollback();

private:
  TPieceHeader* mFirstPiece;
  bool mCached;
  CCRBlob* mRollback;
};

///////////////////  CCRDBSession  ////////////////////

class CCRDBSession {
public:
  CCRDBSession();
  virtual ~CCRDBSession();

  virtual void connect(const char* connectString = "");
  virtual void disconnect();
  bool isConnected() const;

// Transaction control
  virtual void commit() = 0;
  virtual void rollback() = 0;

  const char* username() const;
  void setUsername(const char* username);
  const char* password() const;
  void setPassword(const char* password);
  const char* server() const;
  void setServer(const char* server);
  virtual void setConnectString(const char* connectString);

protected:
  bool mConnected;
  char mUsername[30];
  char mPassword[30];
  char mServer[30];

private:
  
};

void DBError(const char* msg);

#endif
