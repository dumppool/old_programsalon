
//////////////////////////////////////////////////
//  Oracle Class Library
//  Copyright � 1999-2001 Core Lab. All right reserved.
//  SQLParser
//  Last modified:      13.03.00
//////////////////////////////////////////////////

#ifndef __ORAPARS_H__
#define __ORAPARS_H__

#include "crparser.h"

const int lxSELECT   = 20;
const int lxFROM     = 21;
const int lxWHERE    = 22;
const int lxORDER    = 23;
const int lxBY       = 24;
const int lxGROUP    = 25;
const int lxPROCEDURE  = 26;
const int lxFUNCTION = 27;
const int lxPACKAGE  = 28;
const int lxTRIGGER  = 29;
//const int lxTYPE     = 30;
const int lxUNION    = 31;
const int lxFOR      = 32;
const int lxBEGIN    = 33;
const int lxEND      = 34;
const int lxDECLARE  = 35;
const int lxIS       = 36;
const int lxAS       = 37;
const int lxAND      = 38;
const int lxOR       = 39;
const int lxCREATE   = 40;
const int lxREPLACE  = 41;

const int lxEndLexem = 41;

class COraParser : public CCRParser {
public:
  COraParser(const char* Text);

protected:
  virtual bool IsAlpha(char Ch);

};

#endif


