
//////////////////////////////////////////////////
//  Oracle Class Library
//  Copyright � 1999-2001 Core Lab. All right reserved.
//  OCL
//  Last modified:      09.09.99
//////////////////////////////////////////////////

#ifndef __OCL_H__
#define __OCL_H__

#include "crdef.h"
#include "crdb.h"
#include "oracall.h"
#include "ora.h"
#include "oratrace.h"

#endif