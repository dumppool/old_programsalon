
/////////////////////////////////////////////////
//  Oracle Class Library
//  Copyright � 1999-2001 Core Lab. All right reserved.
//  OCL definations
//  Last modified:      28.03.00
/////////////////////////////////////////////////

#ifndef __OCLDEF_H__
#define __OCLDEF_H__

#include <string>
#include <vector>
#include <assert.h>
#include <string.h>

#if !defined(_MFC_) && !defined(_VCL_)
  #define _SCL_
#endif

typedef unsigned short word;
typedef unsigned char byte;

typedef std::string CCRString;

/////////  Standart C++ library support  ////////

#ifdef _SCL_

#include <exception>

class CCRException : public std::exception {
protected:
  CCRString mMsg;

public:
  CCRException(const char* msg);
  virtual ~CCRException() throw() {}

  const char* message();
  void setMessage(const char* msg);

  virtual const char *what() const throw();
};

#if !defined(_MSC_VER) && !defined(_BORLAND_)

char* strupr(char* s);
int stricmp(const char* string1, const char* string2);
int strnicmp(const char *string1, const char *string2, size_t count);

#endif

#endif

////////////////  MFC support  //////////////////

#ifdef _MFC_

#include <afx.h>

class CCRException : public CException {
protected:
  CCRString mMsg;

public:
  CCRException(const char* msg);

  const char* message();
  void setMessage(const char* msg);

  virtual BOOL GetErrorMessage(LPTSTR lpszError, UINT nMaxError, PUINT pnHelpContext = NULL);
};

#endif

//////////////////  VCL support  ////////////////

#ifdef _VCL_

#include <vcl.h>
#pragma hdrstop

class CCRException : public Exception {
public:
  CCRException(const char* msg);

  const char* message();
  void setMessage(const char* msg);
};

#endif

////////////////////////  CCRDate  ///////////////////////

class CCRDate {
public:
  CCRDate();
  CCRDate(unsigned year, unsigned month, unsigned day, unsigned hour = 0,
         unsigned minute = 0, unsigned second = 0/*, unsigned Millesecond = 0*/);

  unsigned year() const { return mYear; };
  void setYear(unsigned year);
  unsigned month() const { return mMonth; };
  void setMonth(unsigned month);
  unsigned day() const { return mDay; };
  void setDay(unsigned day);
  unsigned hour() const { return mHour; };
  void setHour(unsigned hour);
  unsigned minute() const { return mMinute; };
  void setMinute(unsigned minute);
  unsigned second() const { return mSecond; };
  void setSecond(unsigned second);
  unsigned dayOfWeek();

  CCRString format(const char* format = NULL) const;
  void now();

private:
  word mYear;
  byte mMonth;
  byte mDay;
  byte mHour;
  byte mMinute;
  byte mSecond;
  byte mMillesecond;
};

////////////////////////  CCRList  ///////////////////////

template <class T>
class CCRList : public std::vector<T*> {
public:
  ~CCRList();

  void add(T* item) { push_back(item); };
  void insert(int index, T* item);
  void remove(int index) { erase(begin() + index); };
  void clear();
  int count() const { return size(); };
  T& item(int index) const;
  T* findItem(int index) const;

  T& operator[](int index) const { return item(index); };
};

template <class T>
CCRList<T>::~CCRList() {

  clear();
}

template <class T>
void CCRList<T>::clear() {

  for(int i = 0; i < count(); i++)
    delete *(begin() + i);

  erase(begin(), end());
  //std::vector<T>::clear();
}

template <class T>
T& CCRList<T>::item(int index) const {

  if (index >= (int)size())
    throwError("Index %u is not bound", index);

  return **(begin() + index);
}

template <class T>
T* CCRList<T>::findItem(int index) const {

  if (index < (int)size())
    return *(begin() + index);
  else
    return NULL;
}

////////////////////////  CCRNamedList  ///////////////////////

template <class T>
class CCRNamedList : public CCRList<T> {
public:
  T& item(int index) const { return CCRList<T>::item(index); };
  T& item(const char* name) const;
  T* findItem(int index) const { return CCRList<T>::findItem(index); };
  T* findItem(const char* name) const;

  T& operator[](int index) const { return item(index); };
  T& operator[](const char* name) const { return item(name); };
};

template <class T>
T* CCRNamedList<T>::findItem(const char* name) const {

  if (name)
    for (int i= 0; i < count(); i++)
      if (!stricmp((*(begin() + i))->name(), name))
        return *(begin() + i);

  return NULL;
}

template <class T>
T& CCRNamedList<T>::item(const char* name) const {
  T* res;

  res = findItem(name);
  if (!res)
    throwError("Item %s not found", name);

  return *res;
}

void throwError(const char* format, ...);

#endif
