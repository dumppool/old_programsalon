
//////////////////////////////////////////////////
//  Oracle Class Library
//  Copyright � 1999-2001 Core Lab. All right reserved.
//  Ora classes
//  Last modified:      22.03.00
//////////////////////////////////////////////////

#ifndef __ORA_H__
#define __ORA_H__

#include "crdef.h"
#include "crdb.h"
#include "oracall.h"

const TCRDataType dtRowId   = 20;
const TCRDataType dtLong    = dtMemo;
const TCRDataType dtLongRaw = dtBlob;
const TCRDataType dtCursor  = 23;
const TCRDataType dtBLob    = 24;  // Oracle8 BLOB
const TCRDataType dtCLob    = 25;
const TCRDataType dtBFile   = 26;
const TCRDataType dtCFile   = 27;
const TCRDataType dtObject  = 30;

///////////////  COraException  /////////////////

class COraException : public CCRDBException {
public:
  COraException(sword errorCode, const char* msg);

  int errorCode();

private:
  int mErrorCode;
};

class COraSQL;
class COraField;

/////////////////  COraSession  /////////////////

class COraSession;

typedef void TCRSessionEvent(COraSession& session);

class COraSession : public CCRDBSession {
public:
  COraSession();
  ~COraSession();

  virtual void connect(const char* connectString = "");
  virtual void disconnect();

// Transaction control
  void startTransaction();
  virtual void commit();
  virtual void rollback();
  void savepoint(const char* savepoint);
  void rollbackToSavepoint(const char* savepoint);
  bool inTransaction() const;
  bool isAutoCommit() const;
  void setAutoCommit(bool value);

// Multi Thread
  void busy();
  void busyWait();
  void release();

  void breakExec();

  virtual void setConnectString(const char* connectString);

  TLDA* getLDA();

  void setBeforeConnect(TCRSessionEvent* value);
  void setAfterConnect(TCRSessionEvent* value);
  void setBeforeDisconnect(TCRSessionEvent* value);
  void setAfterDisconnect(TCRSessionEvent* value);

protected:
  void checkOCI() const;
  void checkOCI73() const;
  void checkOCI80() const;

  void check(sword res);
  void error(TOCIVersion OCICallStyle, sword errorCode);

private:
  bool mAutoCommit;
  TOCIVersion mOCICallStyle;
  TOCIVersion mOCIVersion;
  bool mInTransaction;
// OCI73
  TLDA* mLDA;
  THDA* mHDA;
// OCI80

  TCRSessionEvent* mBeforeConnect;
  TCRSessionEvent* mAfterConnect;
  TCRSessionEvent* mBeforeDisconnect;
  TCRSessionEvent* mAfterDisconnect;

  void _init();

  friend class COraSQL;
  friend class COraDataset;
};

/////////////////  COraCursor  //////////////////

enum TCRCursorState {csInactive, csOpen, csParsed, csPrepared, csBound,
  csExecuting, csExecuted, csFetching, csFetchingAll, csCanceled};

class COraCursor : public CCRSharedObject {
public:
  COraCursor();
  ~COraCursor();

  void allocCursor();
  void freeCursor();

  bool canFetch() const;

  TOCIVersion OCICallStyle() const;
  void setOCICallStyle(TOCIVersion OCICallStyle);
  TCRCursorState state() const;

  TCDA* CDA();

protected:
  TCDA* mCDA;
  TCRCursorState mState;

  void checkOCI() const;
  void checkOCI73() const;
  void checkOCI80() const;

private:
  TOCIVersion mOCICallStyle;

  friend class COraSQL;
  friend class COraDataset;
};

//////////////////  COraParam  /////////////////////

enum TCRParamType {ptUnknown, ptInput, ptOutput, ptInputOutput};

class COraParam {
public:
  COraParam();
  ~COraParam();

  const char* name() const;
  TCRDataType dataType() const;
  void setDataType(TCRDataType dataType);
  TCRParamType paramType() const;
  void setParamType(TCRParamType paramType);
  int size() const;
  void setSize(int size);
  int bufferSize() const;
  void setBufferSize(int bufferSize);
  bool isTable() const;
  void setTable(bool value);
  int length() const;
  void setLength(int length);  // Length of table

  short indicator(int index) const;
  void setIndicator(int index, short value);

  bool isNull(int index = 1);
  void setNull(bool value);
  void setNull(int index, bool value);

  CCRDate getDate(int index = 1);
  void setDate(const CCRDate& value);
  void setDate(int index, const CCRDate& value);

  double getDouble(int index = 1);
  void setDouble(double value);
  void setDouble(int index, double value);

  int getInt(int index = 1);
  void setInt(int value);
  void setInt(int index, int value);

  const char* getString(int index = 1);
  char* getString(char* result);
  char* getString(int index, char* result);

  void setString(const char* value);
  void setString(int index, const char* value);
  void setString(const CCRString& value);
  void setString(int index, const CCRString& value);

  CCRBlob& getBlob();
  void setBlob(CCRBlob& value);
  CCRBlob& getMemo();
  void setMemo(CCRBlob& value);
  COraCursor& getCursor();
  void setCursor(COraCursor& value);

  CCRValue getValue(int index = 1);
  void setValue(const CCRValue& value);
  void setValue(int index, const CCRValue& value);

  void assign(const CCRDate& value) { setDate(value); };
  void assign(int value) { setInt(value); };
  void assign(double value) { setDouble(value); };
  void assign(const char* value) { setString(value); };
  void assign(const CCRString& value) { setString(value); };

  void assign(COraParam& value);

  void operator =(const CCRValue& value);

protected:
  void reallocBuffers(int newBufferSize, int newLength);
  void freeBuffers();

  void createValue();
  void freeValue();
  void initValue();

  void* valuePtr();
  void* indicatorPtr();

  void refreshIndicator();

  void checkRange(int index) const;

private:
  CCRString mName;
  TCRDataType mDataType;
  int mBufferSize;
  void* mValue;
  sb2 mDefIndicator;
  sb2* mIndicator;
  bool mTable;
  long mLength;  // Table Length
  ub4 mActualLength;
  TCRParamType mParamType;
  CCRString mStringValue;

  friend class COraSQL;
  friend class COraDataset;
};

/////////////////  COraParams  //////////////////

typedef CCRNamedList<COraParam> COraParams;

/////////////////  COraSQL  /////////////////////

class COraSQL {
public:
  COraSQL();
  COraSQL(COraSession& Session);
  ~COraSQL();

// Open/close
  void prepare();
  void unprepare();
  bool isPrepared() const;

// Executing
  void execute();
  void breakExec();

// Params
  void bindParams();

  int paramCount() const;
  COraParams& params();

  COraParam& param(int index) const;
  COraParam& param(const char* name) const;
  COraParam* findParam(int index) const;
  COraParam* findParam(const char* name) const;

// Stored proc
  void createProcCall(const char* name); // buildProcCall

// Info
  int SQLType() const;
  bool isQuery() const;
  bool isPLSQL() const;
  const char* rowId() const;
  int rowsProcessed() const;

  COraSession* session() const;
  void setSession(COraSession& session);
  void setSession(COraSession* session);
  const char* SQL() const;
  void setSQL(const char* SQL);
  COraCursor* cursor() const;
  void setCursor(COraCursor* cursor);
  TCRCursorState cursorState() const;
  TOCIVersion OCICallStyle() const;
  void setOCICallStyle(TOCIVersion OCICallStyle);

  COraParam& operator [](int index) const {  return param(index); };
  COraParam& operator [](const char* name) const {  return param(name); };

protected:
  COraSession* mSession;

  void checkOCI() const;
  void checkOCI73() const;
  void checkOCI80() const;

  void check(sword status) const;
  void checkSession() const;
  void checkActive() const;
  void checkInactive() const;

// OCI73
  int getOraType7(int dataType);
  int getFieldDesc7(int fieldNo, COraField* field);
  int internalFetch7(int rows);
  int internalFetchPiece7();
  void initProcParams7(const char* name);

// OCI80
  int getOraType8(int dataType);
  int getFieldDesc8(int fieldNo, COraField* field);
  int internalFetch8(int rows);
  int internalFetchPiece8();
  void initProcParams8(const char* name);

  int getOraType(int dataType);

// OCI functions
  void internalOpen();
  void internalParse();
  void internalPrepare();
  void bindParam(COraParam* param);
  sword internalExecute(int mode);
  void exec();
  int getFieldDesc(int fieldNo, COraField* field);
  void defineData(COraField* field, void* buf, sb2* ind);
  void defineArrayData(COraField* field, void* buf, sb2* ind, int bufSkip, int indSkip);
  void definePieceData(COraField* field, void* buf, sb2* ind);
  int internalFetch(int rows);
  int internalFetchPiece();
  void internalCancel();
  void internalClose();

  void getPI(void** handle, long* hType, byte* piece, void** buf, long* iteration, long* index);
  void setPI(void* handle, long hType, byte piece, void* buf, long* bufLen, sb2* ind);

  void initProcParams(const char* name);

// Executing
  void doExecute();
  void endExecute(bool result);

// Params
  void scanParams();

// Multi Thread
  void busy();
  void release();

  bool isActive() const;

  bool nativeCursor();
  void setCursorState(TCRCursorState cursorState);

  int rowsReturn();
  void checkRowsReturn();

private:
  COraCursor* mCursor;
  COraCursor* mCursorRef;
  CCRString mSQL;
  COraParams mParams;
  TOCIVersion mOCICallStyle;
  word mSQLType;
  bool mNonBlocking;
  bool mAutoCommit;
  int mErrorOffset;
  int mRowsProcessed;
  int mFetchedRows;

  void _init();

  friend class COraDataset;
};

/////////////////  COraField  ///////////////////

class COraField : public CCRField {
  friend class COraSQL;
  friend class COraDataset;
};

////////////////  COraDataset  //////////////////

class COraDataset : public CCRMemDataset, public COraSQL {
public:
  COraDataset();
  COraDataset(COraSession& session);
  virtual ~COraDataset();

// Open / close
  void prepare();
  void unprepare();

  bool isActive() const { return CCRDataset::isActive(); }
  bool isPrepared() const { return CCRDataset::isPrepared(); }

// Navigation
  virtual bool isEOF() const;

// Fetch
  void fetchAll();

  int fetchRows() const;
  void setFetchRows(int value);
  bool isCached() const;
  void setCached(bool value);

  void setSQL(const char* SQL);

  CCRField& operator [](int index) const { return field(index); };
  CCRField& operator [](const char* name) const { return field(name); };

protected:
// Items / data
  virtual void prepareData();

// Open / close
  virtual void internalPrepare();
  virtual void internalUnprepare();

  virtual void internalOpen();
  virtual void internalClose();

  virtual void internalRefresh();

  bool rowsReturn();
  void checkRowsReturn();

// Fields
  CCRField* createField(int fieldNo);
  virtual void internalInitFields();

  virtual void getDateFromBuf(void* buf, void* date);
  virtual void putDateToBuf(void* buf, void* date);

  virtual void createComplexFields(void* recBuf, bool withBlob = true);
  virtual void freeComplexFields(void* recBuf, bool withBlob = true);

// Records / buffers
  virtual void getNextRecord(void* recBuf);
  virtual void getPrevRecord(void* recBuf);

// Navigation
  virtual void internalLast();

// Fetch
  bool fetch();
  bool fetchArray();
  bool fetchPiece();

  void doExecFetch();
  void endExecFetch(bool result);
  void execFetch();

  void doFetchAll();
  void doFetchAllPulse();
  void endFetchAll(bool result);

private:
  COraCursor* mFetchCursor;
  TItemHeader* fetchItem;
  bool mFetchAll;
  int mFetchRows;
  bool mCached;
  void* mFetchBlock;
  int mFetchBlockItemSize;
  bool mPieceFetch;
  bool mAutoClose;

  void _init();

  void allocFetchBlock();
  void freeFetchBlock();

  void initBlock();
  void prepareBlock(int fetched);
  void clearBlock();
};

//////////////////  COraLob  ///////////////////

class COraLob : public CCRBlob {
};

//////////////////  COraFile  ///////////////////

class COraFile : public COraLob {
public:
  char* fileDir() { return NULL; };
  char* fileName() { return NULL; };
};

#endif
