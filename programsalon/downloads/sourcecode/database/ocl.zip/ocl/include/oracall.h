
//////////////////////////////////////////////////
//  Oracle Class Library
//  Copyright � 1999-2001 Core Lab. All right reserved.
//  OCI
//  Last modified:      28.08.99
//////////////////////////////////////////////////

#ifndef __OCI_H__
#define __OCI_H__

extern "C" {
  #include "oratypes.h"
  #include "ocidfn.h"
  #include "ociapr.h"
}

// For parse

#define OCI_PARSE_NODEFER    0
#define OCI_PARSE_DEFER      1
#define OCI_LANG_V6          0
#define OCI_LANG_NORM        1
#define OCI_LANG_V7          2

// Internal/external datatype codes

#define UNKNOWN_TYPE         0
#define VARCHAR2_TYPE        1
#define NUMBER_TYPE          2
#define INTEGER_TYPE         3
#define FLOAT_TYPE           4
#define STRING_TYPE          5
#define LONG_TYPE            8
#define ROWID_TYPE           11
#define DATE_TYPE            12
#define RAW_TYPE             23
#define LONGRAW_TYPE         24
#define CHAR_TYPE            96
#define CURSOR_TYPE          102

// SQL function codes

#define SQL_UNKNOWN          0
#define SQL_INSERT           3
#define SQL_SELECT           4
#define SQL_UPDATE           5
#define SQL_DELETE           9
#define SQL_PLSQL            34

#define FC_OOPEN             14

// ORACLE error codes

#define OCI_SUCCESS          0
#define OCI_VAR_NOT_IN_LIST  -303 // 1007
#define OCI_NO_DATA_FOUND    4    // 1403
#define OCI_NULL_VALUE_RETURNED  1405
#define OCI_BLOCKED          -3123
#define OCI_CONNECTION_BUSY  -3127
#define OCI_NOT_CONNECTED    -3114
#define OCI_NO_INTERFACE     -3121
#define OCI_SESSION_KILLED   -28
#define OCI_STILL_IS_PIECE   -3130
#define OCI_STILL_IS_PIECE1  -3129
#define OCI_BREAKED          -1013

// OCI7 specific

#define HDA_SIZE 256

typedef Cda_Def TCDA;
typedef Lda_Def TLDA;
typedef unsigned char THDA[HDA_SIZE];


struct TRD {
  ub4 rcs4;   // obj num
  ub2 rcs5;   // file num
  ub1 rcs6;
};

// RowId structure

struct TRowId7 {
  TRD rd;
  ub4 rcs7;   // block num
  ub2 rcs8;   // slot num
};

// OCI8 specific

struct TRowId8 {
  ub4 ridobjnum;  // data obj#--this field is unused in restricted ROWIDs
  ub2 ridfilenum;
  ub2 filler;
  ub4 ridblocknum;
  ub2 ridslotnum;
};

struct TRowId81 {
  ub1 filler;
  ub4 ridobjnum; // data obj#--this field is unused in restricted ROWIDs
  ub2 ridfilenum;
  ub4 ridblocknum;
  ub2 ridslotnum;
};

// OCI initialization

enum TOCIVersion {None,OCI73,OCI80,OCI81};

extern TOCIVersion OCIVersion;
extern TOCIVersion OCICallStyle;

void OCIInit();
void OCIDone();

///////////////////////// Temp

#define OCI_DEFAULT 0
#define OCI_DESCRIBE_ONLY 1
#define OCI_NEED_DATA 0
//#define OCI_LAST_PIECE 0
#define OCI_NO_DATA 0

#endif
