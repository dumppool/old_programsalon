
//////////////////////////////////////////////////
//  Parser
//  Copyright � 1999-2001 Core Lab. All right reserved.
//  Last modified:      13.03.00
//////////////////////////////////////////////////

#ifndef __CRPARSER_H__
#define __CRPARSER_H__

const int lcError   =  -1;  // ??

const int lcEnd     =  0;
const int lcReserve = -100;
const int lcSymbol  = -102;
const int lcIdent   = -103;  // identificator
const int lcNumber  = -105;
const int lcString  = -106;
const int lcBlank   = -107;
const int lcComment = -108;

class CCRParser {
public:
  CCRParser(char** Lexems, int Count);
  CCRParser(const char* Text);
  virtual ~CCRParser();

  void SetLexems(char** Lexems, int Count);

  void ToBegin();
  int GetNext(char* StrLexem);
  int GetNextEx(char* StrLexem, int* Code);
  int GetNextCode();

  void Back();

  int GetCurrPos();
  int GetPrevPos();

  bool GetOmitBlank();
  void SetOmitBlank(bool Value);

  /*property OmitComment:boolean read FOmitComment write FOmitComment;
  property Uppered:boolean read FUppered write FUppered;*/
  
protected:
  int ReserveCount;
  char** ArrReserve;
  char* CommentBegin;
  char* CommentEnd;
  char* InlineComment;

  unsigned Size;

  void _Init();

  virtual bool IsBlank(char Ch);
  virtual bool IsSymbol(char Ch);
  virtual bool IsAlpha(char Ch);
  virtual bool IsNumber(char Ch);
  virtual bool IsStringQuote(char Ch);

private:
  const char* mText;
  char* mPos;
  char* mOldPos;
  bool mOmitBlank;
  bool mOmitComment;
  bool mUppered;

};

#endif
