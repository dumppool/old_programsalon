
REM ***********************************************************
REM *              ORACLE script file for OCL demmos          *
REM ***********************************************************

REM !!!!!!!!!!!!!!!!!!!!!!!!
REM Remove ora to your alias
REM !!!!!!!!!!!!!!!!!!!!!!!!

CONNECT scott/tiger@ora

DROP TABLE OCL_BFILE
/
DROP TABLE OCL_BLOB
/
DROP TABLE OCL_CLOB
/
DROP TABLE OCL_LONG
/
DROP TABLE OCL_LONG_CHAR
/
DROP TABLE OCL_THREADS
/

CREATE TABLE OCL_BFILE
(
  ID NUMBER NOT NULL,
  TITLE VARCHAR2(30),
  VALUE BFILE
)
/

REM Leave empty

CREATE TABLE OCL_BLOB
(
  ID NUMBER NOT NULL,
  TITLE VARCHAR2(30),
  VALUE BLOB
)
/

--INSERT INTO OCL_BLOB VALUES (1, 'first blob', 1234567890);
--INSERT INTO OCL_BLOB VALUES (2, 'second blob', 0987654321);
--INSERT INTO OCL_BLOB VALUES (3, 'third blob', 'blob value');

CREATE TABLE OCL_CLOB
(
  ID NUMBER NOT NULL,
  TITLE VARCHAR2(30),
  VALUE CLOB
)
/

INSERT INTO OCL_CLOB VALUES (1, 'first clob', 'first clob value')
/
INSERT INTO OCL_CLOB VALUES (2, 'second clob', 'second clob value')
/
INSERT INTO OCL_CLOB VALUES (3, 'third clob', 1234567890)
/

CREATE TABLE OCL_LONG
(
  ID NUMBER NOT NULL,
  TITLE VARCHAR2(30),
  VALUE LONG
)
/

INSERT INTO OCL_LONG VALUES (1, 'first long', 1234567890)
/
INSERT INTO OCL_LONG VALUES (2, 'second long', 0987654321)
/
INSERT INTO OCL_LONG VALUES (3, 'third long', 'long value')
/

CREATE TABLE OCL_LONG_CHAR
(
  ID NUMBER NOT NULL,
  TITLE VARCHAR2(30),
  VALUE VARCHAR2(4000)
)
/

INSERT INTO OCL_LONG_CHAR VALUES (1, 'ordinary string', 'ordinary string value')
/
INSERT INTO OCL_LONG_CHAR VALUES (2, 'first long string', 'Oracle Class Library (OCL)
														   provides native connectivity
														   to the Oracle database server.
														   OCL uses Oracle Call Interface
														   (OCI) directly. OCI is low-level
														   native application programming
														   interface to access to Oracle.
														   Using OCI in Oracle Class Library
														   allows to create lightweight and
														   fast applications working with
														   Oracle. Oracle Class Library
														   encapsulates OCI calls in
														   high-level classes that allows
														   to hide the complexity of using
														   OCI directly and keep performance
														   and all abilities of native
														   routines. With OCL you can use
														   the power and flexibility of SQL
														   in your application programs
														   without any restrictions.
														   OCL contains classes to control
														   connection, execute SQL statements,
														   store and process result rows
														   of queries and some common classes
														   useful for developing database
														   applications. All classes have
														   intuitive, easy to use interface. 
														   OCL is written with ANSI C++ and
														   uses Standard C++ Library only
														   that allows you to port your
														   application easily to another
														   platform.
														   Oracle Class Library provides
														   easiness in using from Pro*C/C++
														   and power of Oracle Call Interface.')
/

INSERT INTO OCL_LONG_CHAR VALUES (3, 'another ordinary string', 'ordinary string value')
/

CREATE TABLE OCL_THREADS
(
  ID NUMBER NOT NULL,
  VALUE VARCHAR2(30)
)
/

CREATE OR REPLACE PACKAGE OCLPACK
AS

TYPE TCursor IS REF CURSOR; 

PROCEDURE outparam(empno OUT NUMBER,
                   job OUT VARCHAR2,
                   hiredate OUT DATE,
                   sal OUT NUMBER);
                   
PROCEDURE inoutparam(empno IN NUMBER,
                     job OUT VARCHAR2,
                     hiredate OUT DATE,
                     sal OUT NUMBER);
                     
PROCEDURE outCursor(cur OUT TCursor);

END OCLPACK;
/

CREATE OR REPLACE PACKAGE BODY OCLPACK
IS
PROCEDURE outparam(empno OUT NUMBER,
                   job OUT VARCHAR2,
                   hiredate OUT DATE,
                   sal OUT NUMBER) is
begin

  SELECT empno, job, hiredate, sal INTO
        empno, job, hiredate, sal
  FROM emp
  WHERE empno = 7782;
  
end outparam;

PROCEDURE inoutparam(empno IN NUMBER,
                     job OUT VARCHAR2,
                     hiredate OUT DATE,
                     sal OUT NUMBER) is
begin

  SELECT job, hiredate, sal INTO
         job, hiredate, sal
  FROM emp
  WHERE empno = empno;
  
end inoutparam;

PROCEDURE outCursor(cur OUT TCursor) 
is 
begin 
    OPEN Cur FOR 
      SELECT * 
      FROM Scott.Emp 
      ORDER BY EmpNo; 
end outCursor;  

end OCLPACK;
/

COMMIT
/

EXIT;