
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "ocl.h"

char* getCGIParam(const char* name, const char* buf, char* desc) {
  const char* ch;
  char* ch1;

  ch = buf;
  do {
  // scan name
    ch1 = desc;
    while (*ch && *ch != '=') {
      *ch1 = *ch;
      ch++;
      ch1++;
    }

    if (*ch == '=') {
      *ch1 = 0;
      if (!stricmp(name, desc)) {
        ch++;
        ch1 = desc;
      // scan value
        while (*ch && *ch != '&') {
          if (*ch == '%') {
            ch++;
            if (*ch >= '0' && *ch <= '9')
              *ch1 = (*ch - '0') * 16;
            else
              *ch1 = (*ch - 'A' + 0xA) * 16;
            ch++;
            if (*ch >= '0' && *ch <= '9')
              *ch1 += *ch - '0';
            else
              *ch1 += *ch - 'A' + 0xA;
          }
          else 
            if (*ch == '+')
              *ch1 = 0x20;
            else 
              *ch1 = *ch;
            
          ch++;
          ch1++;
        }
        *ch1 = 0;
        return desc;
      }
      else {
      // omit value
        while (*ch && *ch != '&')
          ch++;
        if (*ch == '&')
          ch++;
      }
    }
  }
  while (*ch);

  return NULL;
}

char* pad(char* buf, const char* st, unsigned int len) {

  strncpy(buf, st, len);
  if (len > strlen(buf)) {
    memset(buf + strlen(buf), 0x20, len - strlen(buf));
    buf[len] = 0;
  }
  
  return buf;
}

const int bufLen = 200; 

char* formatField(char* buf, CCRField& field, bool title = false) {
  const char* text;
  int len;
  
  switch (field.dataType()) {
    case dtString:
      len = (bufLen < field.length()) ? bufLen : field.length();
      if (!title)
        text = field.getString();
      break;
    case dtInteger:
    case dtFloat:
      len = 15;
      if (!title)
        text = field.getString();
      break;
    default:
      len = 10;
      if (!title)
        text = "UNKNOWN";
  }
  if (title)
    text = field.name();
  return pad(buf, text, len);
}

int main(int argc, char **argv) { 
  COraSession session;
  COraDataset dataset;
  char username[30];
  char password[30];
  char server[30];
  char sql[1000];
  char params[1000];
  int i;

  printf("Content-type: text/html\n\n"); // header

  if (argc > 1)
    strcpy(params, argv[1]);
  else
    if (!strcmp(getenv("REQUEST_METHOD"),"POST")) 
      scanf("%s", params);
    else
      printf("<font color=red><b>Parameters: Username, Password, Server, SQL</b></font><br>\n");

  printf("<html>\n");
  printf("<head>\n  <title>Result</title>\n</head>\n\n");
  printf("<body>\n\n");
  try {
    getCGIParam("Username", params, username);
    getCGIParam("Password", params, password);
    getCGIParam("Server", params, server);
    getCGIParam("SQL", params, sql);

    session.setUsername(username);
    session.setPassword(password);
    session.setServer(server);
    session.connect();

    dataset.setSession(session);
    dataset.setFetchRows(25);
    dataset.setCached(false);
    dataset.setSQL(sql);
    dataset.open();
  
    if (dataset.isQuery()) {
      printf("<table border=0 cellspacing=0 cellpadding=0>\n");

      printf("<tr>\n");
      for (i = 0; i < dataset.fieldCount(); i++)
      printf("  <td><b><font face='Arial' size=2 color=navy>%s&nbsp&nbsp\n", dataset.field(i).name());
      printf("</tr>\n");
      printf("<tr><td colspan=%u><font size=-3><hr align=left></tr>\n", dataset.fieldCount());

      dataset.first();

      while (!dataset.isEOF()) {
        if (dataset.recordNo() % 2)
          printf("<tr bgcolor=\"#E0E0E0\">\n");
        else
          printf("<tr>\n");
        for (i = 0; i < dataset.fieldCount(); i++)
          printf("  <td><code>%s&nbsp&nbsp\n", dataset.field(i).getString());    
        printf("</tr>\n");

        dataset.next();
      }
      printf("</table>\n");
      printf("</b>\n");

      printf("<br>\n");
      printf("<i>%i rows selected</i><br>\n", dataset.recordCount());
    }
    else {
      printf("<i>Statement executed<br><br></i>\n");
    };

    dataset.close();

    session.disconnect();
  }
  catch (COraException e) {
    printf("<font color=red><b>%s</b></font><br>\n", e.message());
    printf("<br>Username: %s<br>\nServer: %s<br>\nSQL: %s<br>\n", username, server, sql);
  }
  printf("<br>\n\n");
  printf("</body>\n");
  printf("</html>\n");

  return 0;
}
