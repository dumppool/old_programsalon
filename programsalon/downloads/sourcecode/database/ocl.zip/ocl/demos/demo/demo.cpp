
#ifdef _BORLAND_

#pragma hdrstop
#include <condefs.h>

USELIB("..\..\lib\bcb\ocl.lib");
USELIB("..\..\oci\lib\bcb\ociw32.lib");

#pragma argsused

#endif

#include <stdlib.h>
#include <stdio.h>
#include "ocl.h"  // include OCL header

int main(/*int argc, char **argv*/)
{
  COraSession session;
  COraDataset dataset(session);
  int recordCount = 0;
  char* connectString = "scott/tiger@ora";  // replace ora with your TNS alias

  try {
    session.setConnectString(connectString);  // set login information 
    printf("Connecting as %s ...\n", connectString);
    
    session.connect();  // establish connection
    printf("Connected\n");
    dataset.setSQL("SELECT * FROM Scott.Dept");

    dataset.setCached(false);  // noncached mode
    dataset.setFetchRows(10);
     
    printf("\nOpening %s ...\n", dataset.SQL());
    dataset.open();   // query result rows
    printf("Opened\n\n");

    printf("Fetching...\n\n");
    while (!dataset.isEOF()) {
      printf("DeptNo: %-4s DName: %-15s Loc: %s\n",
        dataset.field("DeptNo").getString(),
        dataset.field("DName").getString(),
        dataset.field("Loc").getString());
      recordCount++;
      dataset.next();  // go to next record 
    }

    printf("\nFetched:\n");
    printf(" - %u rows\n", recordCount);
    if (dataset.isCached())
      printf(" - cached\n");
    else
      printf(" - no cached\n");
    printf(" - fetch rows: %u\n", dataset.fetchRows());

    dataset.close();  

    session.disconnect();  // close connection
    printf("\nDisconnected\n\n");

  }
  catch (CCRException& E) {
    printf("Error: %s\n", E.message());
  }
  
  printf("Press ENTER to exit\n");
  getchar();
  //getch();

  return 0;
}
