
/*
 Oracle Class Library Demos - stored procedure

 This demo shows how call stored procedure with OCL.
 It:
  - connects to database;
  - creates package OCLPack;
  - calls OCLPack.GetDept procedure that returns REF CURSOR;
  - fetchs and display all record from returned cursor;
  - closes connection;
*/

#ifdef _BORLAND_

#pragma hdrstop
#include <condefs.h>

USELIB("..\..\lib\bcb\ocl.lib");
USELIB("..\..\oci\lib\bcb\ociw32.lib");

#pragma argsused

#endif

#include <stdlib.h>
#include <stdio.h>
#include "ocl.h"  // include OCL header

const char* PackIntf = 
"create or replace package OCLPack is TYPE TCursor IS REF CURSOR; procedure GetDept(Cur OUT TCursor); end;";

const char* PackBody = 
"create or replace package body OCLPack is procedure GetDept(Cur OUT TCursor) is begin OPEN Cur FOR SELECT * FROM Scott.Dept ORDER BY DeptNo; end; end;";

int main(/*int argc, char **argv*/)
{
  COraSession session;
  COraDataset dataset(session);
  COraSQL sql(session);
  int recordCount = 0;
  char* connectString = "scott/tiger@ora";  // replace ora with your TNS alias

  try {
    session.setConnectString(connectString);  // set login information 
    printf("Connecting as %s ...\n", connectString);

  // establish connection    
    session.connect();  
    printf("Connected\n");

  // create stored procedure
    sql.setSQL(PackIntf);
    sql.execute();
        
    sql.setSQL(PackBody);
    sql.execute();
    printf("Package created\n");

  // call stored proc
    dataset.createProcCall("OCLPack.GetDept");

    dataset.setCached(false);  // noncached mode
    dataset.setFetchRows(10);
     
    printf("\nOpening\n%s\n\n", dataset.SQL());
    dataset.open();   // query result rows
    printf("Opened\n\n");

  // fetch records 
    printf("Fetching...\n\n");
    while (!dataset.isEOF()) {
      printf("DeptNo: %-4s DName: %-15s Loc: %s\n",
        dataset.field("DeptNo").getString(),
        dataset.field("DName").getString(),
        dataset.field("Loc").getString());
      recordCount++;
      dataset.next();  // go to next record 
    }

    printf("\nFetched:\n");
    printf(" - %u rows\n", recordCount);
    if (dataset.isCached())
      printf(" - cached\n");
    else
      printf(" - no cached\n");
    printf(" - fetch rows: %u\n", dataset.fetchRows());

    dataset.close();  

  // close connection
    session.disconnect();
    printf("\nDisconnected\n\n");

  }
  catch (CCRException& E) {
    printf("Error: %s\n", E.message());
  }
  
  printf("Press ENTER to exit\n");
  getchar();
  //getch();

  return 0;
}
