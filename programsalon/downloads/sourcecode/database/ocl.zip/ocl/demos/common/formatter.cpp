  
#include "formatter.h"

#include <strstream>

Formatter::Formatter(COraDataset &ds) : dataset(ds)
{
  maxFieldLength = 30;
}

Formatter::~Formatter()
{
  head.erase();
  sql.erase();

}

string Formatter::getHeader()
{
  int fieldLength = 0;
  int fieldType, fieldNameLength, headerLength = 0;
  string header, currentSQL;
  ostrstream ostr;

  if (!dataset.isActive())
    throw CCRException("you must open dataset\n");  

  currentSQL = dataset.SQL();

  if (sql == currentSQL && head != "")
    return head;
  else
    //change sql on new
    sql = currentSQL;

  //clear field length array
  fieldsLength.clear();

  //find gratest field
  for (int i = 0; i < dataset.fieldCount(); i++) {
    fieldLength = 0;
    
    fieldType = dataset.field(i).dataType();
#ifdef OCI8
    //leave out LOB fields
    if (fieldType == dtBlob || fieldType == dtOraBlob || fieldType == dtCFILE || fieldType == dtBFILE) {
      fieldLength = strlen("binary value");
    }
    else if ((fieldType == dtMemo) && (dataset.field(i).getBlob().size() > maxFieldLength)) {
      //first maxFieldLength characters and dots
      fieldLength = maxFieldLength + 3; // + '...'
    }
    else if ((fieldType == dtOraClob) && (dataset.field(i).getOraLob().size() > maxFieldLength)) {
      //first maxFieldLength characters and dots
      fieldLength = maxFieldLength + 3;
    }

    else {
#endif
      dataset.first();

      //find lagest field value
      while (!dataset.isEOF()) {

        //dataset.field(i).getString(str);
        int temp = strlen(dataset.field(i).getString());

        if (temp > fieldLength)
          //if field length greate max field length truncate them
          if (temp > maxFieldLength) {
            fieldLength = maxFieldLength + 3; // + '...'
            break;
          }
          else
            fieldLength = temp;

        dataset.next();
      }

//    }

    fieldNameLength = strlen(dataset.field(i).name());
    
    //if field name lager field value size
    if (fieldNameLength > fieldLength)
      fieldLength = fieldNameLength;
    
    ostr << setw(fieldLength) << dataset.field(i).name() << " ";

    //1 for space separator
    headerLength += fieldLength + 1;
    
    fieldsLength.push_back(fieldLength);
  }

  ostr << "\n" << setw(headerLength - 1) << setfill('-') << "" << "\n" << '\0';

  head = ostr.str();

  dataset.first();
  
  return head;
}

void Formatter::displayRecord()
{

  int fieldLength = 0;
  int fieldType;

  char *field = new char[maxFieldLength + 4];
  
  memset(field, '\0', sizeof(field));

  dataset.first();  

  for (int i = 0; i < dataset.fieldCount(); i++) {

    fieldType = dataset.field(i).dataType();    

    //leave out LOB fields
    if (fieldType == dtBlob) { // || fieldType == dtOraBlob || fieldType == dtBFILE) {
      fieldLength = strlen("binary value");
      strcpy(field, "binary value");
    }
    else if (fieldType == dtMemo) {

      if (dataset.field(i).getBlob().size() > maxFieldLength) {
        //first maxFieldLength characters and dots
        fieldLength = maxFieldLength + 3;
        strncpy(field, dataset.field(i).getBlob().getString(), maxFieldLength);
        strcat(field, "...");
      }
      else
        dataset.field(i).getBlob().getString(field);
      
    }
#ifdef OCI8
    else if (fieldType == dtOraClob) {

      if (dataset.field(i).getOraLob().size() > maxFieldLength) {
        //first maxFieldLength characters and dots
        fieldLength = maxFieldLength + 3;
        strncpy(field, dataset.field(i).getOraLob().getString(), maxFieldLength);
        field[maxFieldLength] = '\0';
        strcat(field, "...");
      }
      else
        dataset.field(i).getOraLob().getString(field);
      
    }  
#endif
    else {

      if (strlen(dataset.field(i).getString()) > maxFieldLength) {
        strncpy(field, dataset.field(i).getString(), maxFieldLength);
        strcat(field, "...");
      }
      else
        dataset.field(i).getString(field);
    }

    //format string
    cout << setw(fieldsLength[i])
         << field
         << " ";
  }

  cout << '\n';

  delete field;
}