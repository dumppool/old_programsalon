

#ifndef __FORMATTER_H__
#define __FORMATTER_H__

#ifndef __OCL_H__
#include "ocl.h"
#endif

#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

class Formatter
{
protected:

  COraDataset& dataset;

  //maximum field value length for displaing
  unsigned short maxFieldLength;

  //array of field length in dataset
  vector<int> fieldsLength;

  //prepared header for displaing
  string head;

  //cuurent SQL statement
  string sql;

public:
  Formatter(COraDataset &ds);
  ~Formatter();

  //header for table
  string getHeader();

  //formatted record
  void displayRecord();

  //set maximum field length
  void setFieldLength(unsigned short length) { maxFieldLength = length; }
  unsigned short getFieldLength() const { return maxFieldLength; }

};


#endif // __FORMATTER_H__