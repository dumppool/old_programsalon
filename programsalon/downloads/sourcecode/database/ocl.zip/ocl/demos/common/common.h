
#ifndef __COMMON_H__
#define __COMMON_H__

#ifndef __OCL_H__
#include "ocl.h"
#endif

#include "formatter.h"

char displayCommonMenu();
void connect(COraSession&);
void disconnect(COraSession&);
void selectCommon(COraDataset&, Formatter&);

#endif