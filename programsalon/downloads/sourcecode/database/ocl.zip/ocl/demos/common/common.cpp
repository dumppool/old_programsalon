
#include <iostream>
#include <cstdio>

#include "common.h"

#include "formatter.h"


char displayCommonMenu()
{
  cout << "-----MENU-----\n"
          "1 - Connect\n"
          "2 - Select\n"
          "3 - Disconnect\n"
          "4 - Exit\n"
          "--------------\n";

  char res;

  cin >> res;

  return res;
}

void connect(COraSession& session)
{
  string serverName, userName, password;

  if (session.isConnected())
    session.disconnect();

  cout << "Enter server name: ";
  cin >> serverName;

  cout << "Enter user name (by default \"scott\"): ";
  getline(cin ,userName);

  cout << "Enter password (by default \"tiger\"): ";
  getline(cin, password);

  if (userName == "")
    userName = "scott";

  if (password == "")
    password = "tiger";

  session.setServer(serverName.c_str());
  session.setUsername(userName.c_str());
  session.setPassword(password.c_str());

  session.connect();

  cout << "\nConnected.\n";
}

void disconnect(COraSession& session)
{
  session.disconnect();

  cout << "\nDisconnected.\n";
}

void selectCommon(COraDataset& dataset, Formatter& formatter)
{
  int i = 0;

  dataset.open();

  cout << formatter.getHeader();

  while (!dataset.isEOF()) {
    
    if (i == 10) {
      cout << "\n" << formatter.getHeader();
      i = 0;
    }

    formatter.displayRecord();
    dataset.next();
    i++;
  }

  dataset.close();
}