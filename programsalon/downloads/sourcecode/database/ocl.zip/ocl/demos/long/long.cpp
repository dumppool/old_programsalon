
#include <cstdio>

#include "ocl.h"

#include "../common/common.h"

using namespace std;

string sql("SELECT VALUE FROM OCL_LONG");

COraSession session;
COraDataset dataset(session);

Formatter formatter(dataset);

char displayMenu()
{
  cout << "-----------Main menu--------\n"
       << "1 - Connect\n"
       << "2 - Select records with LONG type\n"
       << "3 - Disconnect\n"
       << "4 - Exit\n"
       << "----------------------------\n";

  return getchar();
}

void select(COraDataset& dataset)
{
  int i = 0;

  dataset.setSQL(sql.c_str());
  dataset.open();

  cout << formatter.getHeader();

  while (!dataset.isEOF()) {
    
    if (i == 10) {
      cout << "\n" << formatter.getHeader();
      i = 0;
    }

    formatter.displayRecord();
    dataset.next();
    i++;
  }

  dataset.close();  
}

int main()
{
  char choice;

  while ((choice = displayMenu()) != '4') {
    try {
      switch (choice) {
      case '1':
        connect(session);
        break;
        
      case '2':
        select(dataset);
        break;
        
      case '3':
        disconnect(session);
        break;
        
      default:
        cout << "Enter valid number\n";
      }
    }
    catch (CCRException& e) {

      cerr << e.message() << "\n";
      
    }
  }

  dataset.close();
  session.disconnect();


  return 0;
}