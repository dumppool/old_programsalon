
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

#include "../../global/err.h"

char *GetFilePath(char *file, char *path)
{
  int i, len =strlen(file);

  for(i =len-1; i >-1; i--)
    if(file[i] =='\\' || file[i] =='/' || file[i] ==':') break;
  if(i ==0) strcpy(path, ".");
  else
  {
    strcpy(path, file);
    path[i] =0;
  }
  return path;
}

char *GetFileName(char *file)
{
  int i, len =strlen(file);

  for(i =len-1; i >-1; i--)
    if(file[i] =='\\' || file[i] =='/' || file[i] ==':') break;
  if(i ==0) return file;
  else return &file[i+1];
}

char *del_all_spaces(char *p)  /* I>3}KySP?U8q */
{
  char buf[2000];
  char *p1 =&buf[0], *pp =p;

  while(*pp)
  {
    if(*pp !=' ') *p1++ =*pp;
    pp++;
  }
  *p1 =0;
  strcpy(p, buf);
  return p;
}

char *del_lr_spaces(char *pbuf)  /* I>3}WsSR5D?U8q */
{
  char *p =pbuf;
  int i =0;

  i =0;
  while(*p ==' ') p++;
  strcpy(pbuf, p);

  i =strlen(pbuf);
  while(i >=0 && *(p + i-1) ==' ') i--;
  *(p+i) =0;

  return pbuf;
}

char *del_rn(char *pbuf)
{
  char *p;

  if((p =strchr(pbuf, '\r')) !=NULL) *p =0;
  if((p =strchr(pbuf, '\n')) !=NULL) *p =0;

  return pbuf;
}

int write_log(char *log_file, char *format, ...)
{
  va_list args;
  char temp[6000];
  FILE *fp =NULL;
  time_t t;
  struct tm *ptm;

  time(&t);
  ptm =localtime(&t);

  if((fp =fopen(log_file, "a")) ==NULL)
    return EOPENFILE;

  va_start(args, format);
  vsprintf(temp, format, args);
  va_end(args);
  if(temp[0] && temp[strlen(temp)-1] =='\n')
    temp[strlen(temp)-1] =0;
  fprintf(fp, "%02d.%02d %02d:%02d:%02d - %s\n", ptm->tm_mon+1, ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec, temp);
  fclose(fp);
  printf("%s\n", temp);

  return 0;
}

int read_config_string(char *config_file, char *item, char *str_buf)
{
  FILE *fp =NULL;
  char buf[256], *p;

  if((fp =fopen(config_file, "r")) ==NULL)
  {
    printf("open file %s failed!\n", config_file);
    return EOPENFILE;
  }
  while(!feof(fp) && fgets(buf, sizeof(buf), fp) !=NULL)
  {
    if(buf[0] =='#') continue;
    if(!strncmp(buf, item, strlen(item)))
    {
      del_rn(buf);
      p =strchr(buf, '=');
      if(p ==NULL) continue;
      p++;
      p =del_lr_spaces(p);
      fclose(fp);
      strcpy(str_buf, p);
      return 0;
    }
  }
  fclose(fp);
  return ENOTFOUND;
}

int read_config_int(char *config_file, char *item, int *int_buf)
{
  char buf[256];

  if(read_config_string(config_file, item, buf) <0) return ENOTFOUND;
  else
    *int_buf =atoi(buf);
  return *int_buf;
}

int write_config_string(char *config_file, char *item, char *str_buf)
{
  FILE *fp, *fp1;
  char file_temp[128], buf[2000];
  
  sprintf(file_temp, "%s.T", config_file);

  if((fp =fopen(config_file, "r")) ==NULL)
  {
    if((fp =fopen(config_file, "w")) ==NULL)
      return EOPENFILE;
    fprintf(fp, "%s=%s\n", item, str_buf);
    fclose(fp);
    return 0;
  }
  if((fp1 =fopen(file_temp, "a")) ==NULL)
  {
    fclose(fp);
    return ECREATEFILE;
  }
  while(!feof(fp) && fgets(buf, sizeof(buf), fp) !=NULL)
  {
    if(!strncmp(buf, item, strlen(item)))
      fprintf(fp1, "%s=%s\n", item, str_buf);
    else fprintf(fp1, buf);
  }
  fclose(fp);
  fclose(fp1);
  if(remove(config_file) !=0)
    return EREMOVEFILE;
  if(rename(file_temp, config_file) !=0)
    return ERENAMEFILE;

  return 0;
}

int write_config_int(char *config_file, char *item, int i)
{
  char temp[20];
  sprintf(temp, "%d", i);
  return write_config_string(config_file, item, temp);
}

char *upper_case(char *str)
{
  char *p =str;

  while(*p)
  {
    if(*p >='a' && *p <='z') *p =*p -'a'+'A';
    p++;
  }
  return str;
}

char *lower_case(char *str)
{
  char *p =str;

  while(*p)
  {
    if(*p >='A' && *p <='Z') *p =*p-'A' +'a';
    p++;
  }
  return str;  
}

int strcmpi(char *s1, char *s2)
{
  char ls1[2000], ls2[2000];

  strcpy(ls1, s1);
  strcpy(ls2, s2);
  return strcmp(lower_case(ls1), lower_case(ls2));
}

