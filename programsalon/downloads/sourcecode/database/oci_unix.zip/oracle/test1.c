#include <stdio.h>

#include "oracle.h"

void main()
{
  DB_INFO db;
  DB_QUERY_INFO query;

  if(db_init(&db) <0)
  {
    printf("db_init failed");
    return;
  }
  int i;
  for(i =0; i<10000; i++)
  {
printf("connect...\n");
    if(db_connect(&db, "ca43", "ceradmin2", "ceradmin") <0)
    {
      printf("db_connect failed");
      return;
    } 
printf("connect ok.\n");
    int ret;
    db_query_init(&query, &db);
    printf("select...\n");
    if((ret =db_query_select(&query, "select * from certi_person_req")) <0)
    {
      printf("query failed\n");
    }
    printf("fetch, ret=%d\n", ret);
    if(ret >0)
    {
      while(db_query_fetch(&query))
      {
        printf("%s\t%s\n", get_field_value(&query,0), get_field_value(&query, 1)); 
      }
    }
     
    db_query_close(&query);
  db_close(&db); 
  }

  db_exit(&db);
}

