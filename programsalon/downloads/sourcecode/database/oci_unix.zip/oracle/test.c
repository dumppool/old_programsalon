#include <stdio.h>

#include "oracle.h"

void main()
{
  DB_INFO db;
  DB_QUERY_INFO query;

  if(db_init(&db) <0)
  {
    printf("db_init failed");
    return;
  }
  if(db_connect(&db, "ceradmin", "system", "manager") <0)
  {
    printf("db_connect failed");
    return;
  } 
  int ret;
  db_query_init(&query, &db);
  char pub_key[2048];
  char pri_key[2048];
  if((ret =db_query_select(&query, "select public_key, private_key from key_pair")) <0)
  {
    printf("query failed\n");
  }
  if(ret >0)
  {
    while(db_query_fetch(&query))
    {
      get_field_value_by_name2(&query, "public_key", pub_key);
      get_field_value_by_name2(&query, "private_key", pri_key);
      printf("%s\t%s\n", pub_key, pri_key); 
    }
  }
     
  db_query_close(&query);
  db_close(&db); 
}

