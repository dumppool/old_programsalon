
CREATE TABLE TR  
(
	NUN int,
	NAME character (4),
	NAME1 character,
--        NUM0 numeric (3,2),
--        NUM0 numeric (3,2),
        NUM1 numeric (3),
        NUM2 numeric (7),
--        NUM4 numeric (20,10),
        NUM3 numeric,
--        NUM10 decimal (3,2),
        NUM11 decimal (3),
        NUM12 decimal (15),
        NUM13 decimal,
        NUM21 dec (3),
        NUM22 smallint,

        MARK1 float (5) DEFAULT 5.,  -- 5. ,0.5
        MARK11 float,
        MARK12 real,
        MARK13 double precision,
        MARK2 integer DEFAULT 4, -- +4,
        BOY char DEFAULT NULL,
        GIRL char(20) DEFAULT USER,
        SCORE float (3)
)






