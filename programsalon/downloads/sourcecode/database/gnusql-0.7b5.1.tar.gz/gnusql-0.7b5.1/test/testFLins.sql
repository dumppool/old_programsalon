-- 
-- failed test: pass 2
-- reported by Andreas Florath <florath@stochastik.rwth-aachen.de>
-- Date: Fri, 28 Feb 1997 10:42:37 +0100 (MET)
--
-- kml@ispras.ru : We didn't expect that such code can be found in .sql file but
--                 'service crash' is not the best reaction on it. 

INSERT INTO SPIELER VALUES 
( 6, 'Peters', 'R', NULL, 1964, 'M', 1977, 'Hafenalle', '80', '4000', 
  'Duesseldorf', '0211-476537', '8467' )

--
--
--
