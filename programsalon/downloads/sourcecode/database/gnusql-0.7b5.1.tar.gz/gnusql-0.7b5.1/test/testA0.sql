
CREATE TABLE ins
(
	k     int not null primary key,
        info  char(20)
)






