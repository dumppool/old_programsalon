/*
 * subquery.c  - processing single nested queries                
 *               GNU SQL server
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by Eugene W. Woynov
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:  gss@ispras.ru
 *
 */

/* $Id: subquery.c,v 1.245 1997/03/31 03:46:38 kml Exp $ */

#include <assert.h>
#include "tassert.h"
#include "global.h"
#include "seman.h"
#include "funall.h"
#include "trlinter.h"


#define SUBQ_PRINT      SEM_PRINT(SEM_OUTFILE,"\n subquery...")
#define SUBQ_PRINT_END  SEM_PRINT(SEM_OUTFILE,"OK")

/********************************************************************/

static void subq  __P((TXTREF));
TXTREF rule_Type_N (i4_t *, TXTREF);
TXTREF rule_Type_JA (i4_t *, TXTREF);
static void change_scan  __P((TXTREF, TXTREF));
static void change_scol  __P((TXTREF, TXTREF));
static void copy_scan  __P((TXTREF));
/********************************************************************/
/*                         scan       tblptr    from      query     */     
#define find_scan(query)  (TABL_DESC (DOWN_TRN (DOWN_TRN (query))))
/********************************************************************/

static i4_t    f_subq = 0;
static TXTREF new_scan;
static VCBREF local_vcb;

/********************************************************************/

CODERT 
subq_main (TXTREF txtref)
{
  for (; txtref; txtref = RIGHT_TRN (txtref))
    {
      if (CODE_TRN (txtref) == CUR_AREA)
	local_vcb = XVCB_TRN (DOWN_TRN (txtref), 7);
      else
	local_vcb = XVCB_TRN (txtref, 7);
      subq (txtref);
    }
  if (f_subq)
    SUBQ_PRINT_END;
  if (s_e_error)
    {
      char *s = "s";
      errors += s_e_error;
      if (s_e_error == 1)
        s = "";
      SEM_PRINT (SEM_OUTFILE, "\nThere was %d error%s at ", s_e_error, s);
      return (SQL_ERROR);
    }
  
  return (SQL_SUCCESS);
}				/* end subq_main */

/**********************************************************************/

/**********************************************************************/

static void
subq (TXTREF txtref)
{

  TXTREF curr_txtref;
  i4_t arity;
  enum token code;
  i4_t done;
  
  if (txtref) return;
  if (!HAS_DOWN(txtref))
    return;

  for (arity = (i4_t) ARITY_TRN (txtref), txtref = DOWN_TRN (txtref);
       arity > 0;
       arity--, txtref = RIGHT_TRN (txtref))
    {
      code = CODE_TRN (txtref);
      if (code == QUERY ||
	  code == SUBQUERY)
	if (TstF_TRN (txtref, SUBQUERY_F))
	  {
	    rule_Type_N (&done, txtref);
	    if (done)
	      {
		if (!f_subq)
		  SUBQ_PRINT;
                f_subq = 1;
		SEM_PRINT (SEM_OUTFILE, " *NJ* ");
		ClrF_TRN (txtref, SUBQUERY_F);
	      }
	    curr_txtref = rule_Type_JA (&done, txtref);
	    if (done)
	      {
		if (!f_subq)
		  SUBQ_PRINT;
                f_subq = 1;
		SEM_PRINT (SEM_OUTFILE, " *JA* ");
		copy_scan (VCB_ROOT);
		change_scan (curr_txtref, find_scan (curr_txtref));
	      }
	  }
      if (HAS_DOWN(txtref))
	subq (txtref);
    }
}				/* end subq */

/********************************************************************/

static void
copy_scan (TXTREF txtref)
{
  VCBREF v, scol;

  new_scan = gen_node (SCAN);
  COR_TBL (new_scan) = txtref;
  COR_NEXT (new_scan) = RIGHT_TRN (local_vcb);
  RIGHT_TRN (local_vcb) = new_scan;
/* copy columns chain */
  for (v = TBL_COLS (VCB_ROOT); v; v = COL_NEXT (v))
    {
      scol = gen_node (SCOLUMN);
      COL_NEXT (scol) = COR_COLUMNS (new_scan);
      COR_COLUMNS (new_scan) = scol;
      COL_NO (scol) = COL_NO (v);
      COL_TYPE (scol) = COL_TYPE (v);
      COL_TBL (scol) = new_scan /*COL_TBL(v)*/ ;
    }
}

/********************************************************************/

static void
change_scan (TXTREF query, TXTREF scan)
{
  TXTREF p;

  /*scan     tblptr    from      */     
  TABL_DESC (DOWN_TRN (DOWN_TRN (query))) = new_scan;
  p = gen_node (COLPTR);
  OBJ_DESC (p) = COR_COLUMNS (new_scan);
  /*1st col  selection  from      */     
  DOWN_TRN  (RIGHT_TRN (DOWN_TRN (query))) = p;

  change_scol (query, scan);

}

/********************************************************************/

static void
change_scol (TXTREF query, TXTREF scan)
{
  TXTREF t;
  for (t = DOWN_TRN (query); t; t = RIGHT_TRN (t))
    {
      if (HAS_DOWN(t))
	change_scol (t, scan);
      if (CODE_TRN (t) == COLPTR)
	if (COL_TBL (OBJ_DESC (t)) == scan)
	  OBJ_DESC (t) = COL_NEXT (COR_COLUMNS (new_scan));
    }

}

/************************************************************************/
