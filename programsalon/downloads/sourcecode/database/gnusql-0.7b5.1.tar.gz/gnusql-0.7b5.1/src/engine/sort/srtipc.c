/*
 *  srtpc.c - Interpocess communications of Sorter
 *            Kernel of GNU SQL-server. Sorter    
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: srtipc.c,v 1.246 1997/03/31 11:05:02 kml Exp $ */

#include "setup_os.h"
#include <sys/types.h>

#include <stdio.h>
#include <signal.h>

#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/shm.h>

#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif


#include "dessrt.h"
#include "inpop.h"
#include "pupsi.h"
#include "f1f2decl.h"
#include "fdclsrt.h"
#include "strml.h"



i4_t TRNUM, msqid, msqida, msqidb;
pid_t parent;
i4_t segsize;
u2_t fields_n;
extern i4_t EXNSSIZE;
extern char *adrseg;
extern u2_t trn,fdfn,kn;
extern COST cost;
extern i4_t pinit;
extern i4_t NFP;
extern u2_t *cutfpn;
extern u2_t *arrfpn;
extern u2_t *arrpn;


#define SMMAX 6

static i4_t N_AT_SEG;
/*extern struct shminfo	shminfo;*/

#define PRINT(x) PRINTF(x)

#define ARG(num, what, type)   sscanf (argv[num], "%d", &argum); \
                               what = (type)(argum)

void
main (i4_t argc, char **argv)
{
  char *p;
  i4_t op, n;
  key_t keysr, keybf, keyadm;
  struct msg_buf rbuf;
  u2_t *mfs, fpn, sn, lpn, arr_kn[BD_PAGESIZE];
  char prdbl;
  i4_t argum;
  struct des_field *adf, df[BD_PAGESIZE];

  MEET_DEBUGGER;
  
  setbuf (stdout, NULL);
  ARG(1, keysr,    key_t);
  ARG(2, keybf,    key_t);
  ARG(3, EXNSSIZE, i4_t  );
  ARG(4, parent,   pid_t);
  ARG(5, keyadm,   key_t);
  
  if ((msqid = msgget (keysr, IPC_CREAT | DEFAULT_ACCESS_RIGHTS)) < 0)
    {
      perror ("SRT.msgget");
      exit (1);
    }
  MSG_INIT (msqidb, keybf, "BUF");
  MSG_INIT (msqida, keyadm, "ADM");
  
  N_AT_SEG = 0;
  
/*  max_att_seg = shminfo.shmseg;*/
  
  if (PINIT > SMMAX)
    pinit = SMMAX - 2;
  else
    pinit = PINIT;
  
  if ((adrseg = (char *) malloc (segsize = BD_PAGESIZE * PINIT)) == NULL)
    {
      perror ("SRT.malloc: No segment");
      exit (1);
    }  
  arrfpn = (u2_t *) malloc (pinit * size2b);
  cutfpn = (u2_t *) malloc (pinit * size2b);
  if (pinit < EXNSSIZE)
    NFP = pinit;
  else
    NFP = EXNSSIZE;  
  arrpn = (u2_t *) malloc (NFP * size2b);
  
  for (;;)
    {
      __MSGRCV(msqid, &rbuf, BD_PAGESIZE, -(ANSSRT - 1), 0,"SRT.msgrcv");
      
      op = rbuf.mtype;
      p = rbuf.mtext;
      BUFUPACK(p,trn);
      TRNUM = trn - CONSTTR;
      switch (op)
	{
	case TRSORT:
          BUFUPACK(p,fpn);
          BUFUPACK(p,fields_n);
          BUFUPACK(p,fdfn);
          for (adf = df, n = fields_n; n != 0; n--, adf++)
            BUFUPACK(p,*adf);
          BUFUPACK(p,kn);
          for (mfs = arr_kn, n = kn; n != 0; n--, mfs++)
            BUFUPACK(p,*mfs);
          prdbl = *p++;
/*
  if (kn == fn)
  lpn = sort_tuples (&fpn, df,mfs,prdbl,p);
  else
  */
          lpn = trsort (&fpn, df, arr_kn, prdbl, p);
          ans_srt (fpn, lpn);
          break;
	case FLSORT:
          BUFUPACK(p,fpn);
          BUFUPACK(p,fields_n);
          BUFUPACK(p,fdfn);
          for (adf = df, n = fields_n; n != 0; n--, adf++)
            BUFUPACK(p,*adf);
          BUFUPACK(p,sn);
          BUFUPACK(p,kn);
          for (mfs = arr_kn, n = kn; n != 0; n--, mfs++)
            BUFUPACK(p,*mfs);
	  prdbl = *p++;
	  lpn = flsort (sn, &fpn, df, arr_kn, prdbl, p);
	  ans_srt (fpn, lpn);
	  break;
	case TIDSRT:
          BUFUPACK(p,fpn);
	  lpn = tidsort (&fpn);
	  ans_srt (fpn, lpn);
	  break;
	case CRTRN:
	  crtrn ();
	  break;
	case FINIT:
	  finit ();
	  break;
	default:
	  perror ("SRT.main: No such operation");
	  break;
	}
    }
}

u2_t 
getext (void)
{
  struct msg_buf sbuf;
  
  t2bpack (GETEXT, sbuf.mtext);
  t2bpack (TRNUM,  sbuf.mtext + size2b);
      
  ADM_SEND (NUM_SRT /* SORTER number in TABTR = 1*/,
	    size2b * 2, "SRT.msgsnd: GETEXT");
      
  __MSGRCV(msqid, &sbuf, size2b, CONSTTR + NUM_SRT, 0,
           "SRT.msgrcv: Answer on GETEXT");
  return t2bunpack (sbuf.mtext);
}

void
ADMT_putext (u2_t * mfpn, u2_t exn)
{
  char *p;
  u2_t i;
  struct msg_buf sbuf;

  if (exn == 0)
    return;
  
  PRINT (("SRT.PUTEXT:  exn = %d\n", (i4_t)exn));
  
  p = sbuf.mtext + + size2b ;
  t2bpack(PUTEXT, sbuf.mtext);
  p = sbuf.mtext + + size2b ;
  BUFPACK(exn, p);
  for (i = 0; i < exn; i++)
    BUFPACK(mfpn[i], p);
  ADM_SEND (NUM_SRT, p - sbuf.mtext, "SRT.msgsnd: PUTEXT");
  return;
}

char *
getpage(struct A *ppage, u2_t sn, u2_t pn)
{
  struct msg_buf sbuf;
  u2_t size;
  char *p;
  key_t keyseg;
  i4_t shmid;
  char *shm;

  ppage->p_sn = sn;
  ppage->p_pn = pn;
  p = sbuf.mtext;
  t2bpack (trn, p);
  p += size2b;
  t2bpack (ppage->p_sn, p);
  p += size2b;
  t2bpack (ppage->p_pn, p);
  p += size2b;
  size = size2b * 3;
  if (sn != NRSNUM)
    {
      sbuf.mtype = LOCKGET;
      *(char *) p = WEAK;
      size += 1;
    }
    else
    sbuf.mtype = GETPAGE;
  keyseg = BACKUP;
  while (keyseg == BACKUP)
    {
      __MSGSND(msqidb, &sbuf, size, 0,"SRT.msgsnd: BUF GETPAGE");
      __MSGRCV(msqidb, &sbuf, sizeof (key_t), trn, 0,"SRT.msgrcv: Answer on GETPAGE");
      keyseg = *(key_t *) sbuf.mtext;
    }
  if ((shmid = shmget (keyseg, BD_PAGESIZE, DEFAULT_ACCESS_RIGHTS)) < 0)
    {
      perror ("SRT.shmget");
      exit (1);
    }
  if ((shm = (char *) shmat (shmid, NULL, 0)) == (char *) -1)
    {
      perror ("SRT.shmat");
      exit (1);
    }
  N_AT_SEG++;
  ppage->p_shm = shm;
  if (sn != NRSNUM)
    cost += 2;
  else
    cost += 1;
  return (shm);
}

char *
getnew(struct A *ppage, u2_t sn, u2_t pn)
{
  struct msg_buf sbuf;
  char *p;
  i4_t shmid;
  char *shm;

  sbuf.mtype = NEWGET;
  p = sbuf.mtext;
  t2bpack (trn, p);
  p += size2b;
  t2bpack (sn, p);
  p += size2b;
  t2bpack (pn, p);
  
  __MSGSND(msqidb, &sbuf, 3 * size2b, 0,"SRT.msgsnd: NEWGET to BUF");
  __MSGRCV (msqidb, &sbuf, sizeof (key_t), trn, 0,"SRT.msgrcv: NEWGET from BUF");
      
  if ((shmid = shmget (*(key_t *) sbuf.mtext, BD_PAGESIZE,
                       DEFAULT_ACCESS_RIGHTS)) < 0)
    {
      perror ("SRT.shmget");
      exit (1);
    }
  if ((shm = (char *) shmat (shmid, NULL, 0)) == (char *) -1)
    {
      perror ("SRT.shmat");
      exit (1);
    }
  N_AT_SEG++;
  ppage->p_shm = shm;
  ppage->p_sn = sn;
  ppage->p_pn = pn;
  cost += 1;
  return (shm);
}

void
putpage (struct A *ppage, char type)
{
  struct msg_buf sbuf;
  u2_t sn;
  char *p;

  sn = ppage->p_sn;
  if (sn == NRSNUM)
    sbuf.mtype = PUTPAGE;
  else
    sbuf.mtype = PUTUNL;
  p = sbuf.mtext;
  t2bpack (trn, p);
  p += size2b;
  t2bpack (sn, p);
  p += size2b;
  t2bpack (ppage->p_pn, p);
  p += size2b;
  t4bpack (0, p);
  p += size4b;
  *p = ((type == 'm')? PRMOD:PRNMOD);
  __MSGSND(msqidb, &sbuf, 5 * size2b + 1, 0,"SRT.msgsnd: PUTPAGE to BUF");
  __MSGRCV(msqidb, &sbuf, sizeof (i4_t), trn, 0,"SRT.msgrcv: PUTPAGE from BUF");
  shmdt (ppage->p_shm);
  N_AT_SEG--;
}

void
crtrn (void)
{
}

void
ans_srt (u2_t fpn, u2_t lpn)
{
  struct msg_buf sbuf;
  char *p;

  sbuf.mtype = trn;
  p = sbuf.mtext;
  BUFPACK(fpn,p);
  BUFPACK(lpn,p);
  BUFPACK(cost,p);
  __MSGSND(msqid, &sbuf, 2 * size2b + sizeof (COST), 0,"SRT.msgsnd");
  PRINT (("SRT.ans_srt.e: fpn = %d, lpn = %d\n", fpn, lpn));
}

void
finit (void)
{
  PRINTF (("SRT.finit: before exit\n"));
  exit (0);
}
