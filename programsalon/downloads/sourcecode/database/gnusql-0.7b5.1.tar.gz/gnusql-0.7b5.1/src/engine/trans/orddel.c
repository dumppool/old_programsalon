/*
 *  orddel.c  - Ordinary Deletion
 *              Kernel of GNU SQL-server 
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: orddel.c,v 1.247 1997/04/15 11:45:41 vera Exp $ */

#include "destrn.h"
#include "strml.h"
#include "fdcltrn.h"

extern i4_t idtr;

void
orddel (u2_t sn, i4_t rn, struct des_tid *tid,
        struct des_tid *ref_tid, u2_t oldsize)
{
  char *a, *asp = NULL;
  u2_t *ai, pn, pn2;
  struct A pg;
  i4_t idm;

  pn = tid->tpn;
  while ((asp = getpg (&pg, sn, pn, 'x')) == NULL);
  ai = (u2_t *) (asp + phsize) + tid->tindex;
  a = asp + *ai;
  idm = begmop (asp);
  pn2 = ref_tid->tpn;
  if (pn2 != (u2_t) ~ 0)
    recmjform (OLD, sn, pn, idm, *ai, MIN_TUPLE_LENGTH, a, 0);
  else
    {
      compress (sn, tid, idm, asp, oldsize, MIN_TUPLE_LENGTH);
      a += oldsize - MIN_TUPLE_LENGTH;
    }
  t4bpack (idtr, a + 1);
  *a = IDTR;
  MJ_PUTBL ();
  putpg (&pg, 'm');
  if (pn2 != (u2_t) ~ 0)
    {
      while ((asp = getpg (&pg, sn, pn2, 'x')) == NULL);
      idm = begmop (asp);
      compress (sn, ref_tid, idm, asp, oldsize, 0);
      MJ_PUTBL ();
      putpg (&pg, 'm');
      modrec (sn, rn, pn2, oldsize + size2b);
      modrec (sn, rn, pn, MIN_TUPLE_LENGTH + size2b);
    }
  else
    modrec (sn, rn, pn, oldsize + size2b);
}
