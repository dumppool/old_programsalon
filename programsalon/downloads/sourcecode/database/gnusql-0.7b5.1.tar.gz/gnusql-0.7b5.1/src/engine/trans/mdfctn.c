/*
 *  mdfctn.c  - Modification 
 *              Kernel of GNU SQL-server 
 *
 *  $Id: mdfctn.c,v 1.246 1997/04/10 06:57:28 vera Exp $
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

#include <assert.h>

#include "destrn.h"
#include "sctp.h"
#include "strml.h"
#include "fdcltrn.h"
#include "xmem.h"

extern char **scptab;
extern i2_t maxscan;
extern char *pbuflj;
extern i4_t ljrsize;
extern i4_t ljmsize;
extern struct ADBL adlj;

static
int
mod_tt_tuple(struct d_mesc *scpr, u2_t fmnum, u2_t *mfn, char *fl)
{
  struct des_trel *destrel;
  struct des_field *df;
  struct A pg;
  struct des_tid *tid;
  u2_t pn, newsize, fdf;
  i2_t delta;
  char *asp, *a;
  u2_t *afi, *ai;
  char *fval;
  
  destrel = (struct des_trel *) scpr->pobsc;
  df = (struct des_field *) (destrel + 1);
  fdf = destrel->fdftr;
  if (testcmod (df, fdf, scpr->fmnsc, mfn, fl, &fval) != OK)
    return (NCF);
  tid = &((struct d_sc_r *) scpr)->curtid;
  pn = tid->tpn;
  asp = getwl (&pg, NRSNUM, pn);
  afi = (u2_t *) (asp + phtrsize);
  ai = afi + tid->tindex;
  if (*ai == 0)
    {
      putwul (&pg, 'n');
      scpr->prcrt = 0;
      return (NCR);
    }
  assert (*ai <= BD_PAGESIZE);
  a = asp + *ai;
  newsize = cortform (df, fdf, destrel->fieldn, fl, fval, a, pbuflj, mfn);
  delta = calsc (afi, ai) - newsize;
  if (delta > 0)
    comptr (asp, ai, delta);
  if (delta >= 0)
    {
      bcopy (pbuflj, a, newsize);
      putwul (&pg, 'm');
    }
  else
    {
      deltr (scpr, asp, ai, &(destrel->tobtr), pn);
      putwul (&pg, 'm');
      instr (&(destrel->tobtr), pbuflj, newsize);
    }
  return (OK);
}

static int
mod_cort (char *fl, struct d_mesc *s, u2_t fmnum, u2_t *mfn,
          struct d_r_t *desrel, struct des_tid *tid)
{  
  char *cort, *nc, *selc, *fval;
  u2_t newsize, n, ni, ndc, corsize, fn, sn;
  struct des_field *df;
  i4_t rn;
  CPNM cpn;
  struct id_rel idr;
  struct ADBL last_adlj;
  struct des_tid ref_tid;

  sn = desrel->segnr;
  df = (struct des_field *) (desrel + 1);
  if (testcmod (df, desrel->desrbd.fdfnum, fmnum, mfn, fl, &fval) != OK)
    return (NCF);
  cort = pbuflj + ljmsize;
  if (readcort (sn, tid, cort, &corsize, &ref_tid) == NCR)
    {
      s->prcrt = 0;
      return (NCR);
    }
  rn = desrel->desrbd.relnum;
  fn = desrel->desrbd.fieldnum;
  ndc = s->ndc;
  idr.urn.segnum = sn;
  idr.urn.obnum = rn;
  idr.pagenum = desrel->pn_r;
  idr.index = desrel->ind_r;
  if (ndc < MAXCL)
    {
      if ((cpn = synlock (&idr, &desrel->desrbd, cort)) != 0)
	return (cpn);
      s->ndc++;
    }
  else if (ndc == MAXCL)
    {
      selc = s->pslc;
      if ((cpn = synlsc (s->modesc, &idr, selc + size2b, *(u2_t *) selc, fn, NULL)) != 0)
	return (cpn);
      s->ndc++;
    }
  nc = cort + corsize;
  newsize = cortform (df, desrel->desrbd.fdfnum, fn, fl, fval, cort, nc, mfn);
  if ((cpn = synlock (&idr, &desrel->desrbd, nc)) != 0)
    return (cpn);
  modmes ();
  last_adlj = adlj;
  wmlj (MODLJ, ljmsize + corsize + newsize, &adlj, &idr, tid, 0);
  if (newsize <size4b)
    newsize = size4b;
  ordmod (sn, rn, tid, &ref_tid, corsize, nc, newsize);
  n = desrel->desrbd.indnum;
  ni = mproind (desrel, n, cort, nc, tid);
  if (ni < n)
    {
      wmlj (RLBLJ, ljrsize, &last_adlj, &idr, tid, 0);
      mproind (desrel, ni + 1, nc, cort, tid);
      ordmod (sn, rn, tid, &ref_tid, corsize, nc, newsize);
      BUF_endop ();
      return (NU);
    }
  BUF_endop ();
  return (OK);
}

static
int
modcort (char *fl, struct d_mesc *s, u2_t scsz, struct d_r_t *desrel, struct des_tid *tid)
{
  u2_t *mfn;
  
  mfn = (u2_t *) ((char *) s + scsz + s->fnsc * size2b);
  return (mod_cort( fl, s, s->fnsc, mfn, desrel, tid));
}

int
mdfctn (i4_t scnum, char *fl)
{
  struct ldesscan *desscan;
  struct d_mesc *scpr;
  i4_t sctype;
  
  scpr = (struct d_mesc *) * (scptab + scnum);
  if (scnum >= maxscan || scpr == NULL)
    return (NDSC);
  if (scpr->modesc != WSC && scpr->modesc != MSC)
    return (NMS);
  if (scpr->prcrt == 0)
    return (NCR);
  if ((sctype = scpr->obsc) == SCR)
    {				/* relation scan */
      desscan = &((struct d_sc_i *) scpr)->dessc;
      return (modcort (fl, scpr, scisize, (struct d_r_t *) scpr->pobsc, &desscan->ctidi));
    }
  else if (sctype == SCTR)
    {
      u2_t *mfn;
      mfn = (u2_t *) ((char *) scpr + scrsize + scpr->fnsc * size2b);
      return (mod_tt_tuple (scpr, scpr->fmnsc, mfn, fl));
    }
  else if (sctype == SCI)
    {				/* index scan */
      desscan = &((struct d_sc_i *) scpr)->dessc;
      return (modcort (fl, scpr, scisize, desscan->pdi->dri, &desscan->ctidi));
    }
  else
    {				/* filter scan */
      struct d_sc_f *scfltr;
      char *asp;
      struct A pg;
      struct des_tid *tid;
      scfltr = (struct d_sc_f *) scpr;
      asp = getwl (&pg, NRSNUM, scfltr->pnf);
      tid = (struct des_tid *) (asp + scfltr->offf);
      putwul (&pg, 'n');
      return (modcort (fl, scpr, scfsize, ((struct des_fltr *) scpr->pobsc)->pdrtf, tid));
    }
}

int
testcmod (struct des_field *df, u2_t fdf, u2_t fmn, u2_t *mfn, char *fml, char **fval)
{
  u2_t i,fn,type;
  unsigned char t;
  i4_t sst;
  char *a, *sc;

  sst = 1;
  a = fml;
  for (i = 0; ((t = selsc1 (&a, sst++)) != ENDSC) && (i < fmn); i++)
    {
      fn = mfn[i];
      if (t != EQ && t != NEQ && t != EQUN)
	return (NCF);
      if (fn < fdf && t == EQUN)
	return (NCF);
    }
  if (t != ENDSC)
    return (NCF);
  if (sst % 2 == 0)
    a++;
  *fval = a;
  sst = 1;
  sc = fml; 
  for (i = 0; (t = selsc1 (&sc, sst++)) != ENDSC; i++)
    {
      fn = mfn[i];
      if(t2bunpack(a)>(df+fn)->field_size) return(NCF);
      type= (df+fn)->field_type;
      if(type== T1B || type==T2B || type==T4B || type== TFLOAT)
	a+=size2b;
      a=proval(a,type);
    }  
  return (OK);
}

int
mod_spec_flds (i4_t scnum, u2_t fmnum, u2_t * fmn, char * fl)
{
  struct ldesscan *desscan;
  struct d_mesc *scpr;
  i4_t sctype;

  scpr = (struct d_mesc *) * (scptab + scnum);
  if (scnum >= maxscan || scpr == NULL)
    return (NDSC);
  if (scpr->modesc != WSC && scpr->modesc != MSC)
    return (NMS);
  if (scpr->prcrt == 0)
    return (NCR);
  if ((sctype = scpr->obsc) == SCR)
    {				/* relation scan */
      desscan = &((struct d_sc_i *) scpr)->dessc;
      return (mod_cort (fl, scpr, fmnum, fmn, (struct d_r_t *) scpr->pobsc, &desscan->ctidi));
    }
  else if (sctype == SCTR)
    {
      return (mod_tt_tuple (scpr, fmnum, fmn, fl));
    }
  else if (sctype == SCI)
    {				/* index scan */
      desscan = &((struct d_sc_i *) scpr)->dessc;
      return (mod_cort (fl, scpr, fmnum, fmn, desscan->pdi->dri, &desscan->ctidi));
    }
  else
    {				/* filter scan */
      struct d_sc_f *scfltr;
      char *asp;
      struct A pg;
      struct des_tid *tid;
      scfltr = (struct d_sc_f *) scpr;
      asp = getwl (&pg, NRSNUM, scfltr->pnf);
      tid = (struct des_tid *) (asp + scfltr->offf);
      putwul (&pg, 'n');
      return (mod_cort (fl, scpr, fmnum, fmn, ((struct des_fltr *) scpr->pobsc)->pdrtf, tid));
    }
}
