/*
 *  proind.c  -  Processing of all DB table indexes in the time of an insertion, a deletion or a modification
 *               Kernel of GNU SQL-server 
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: proind.c,v 1.246 1997/03/31 11:04:21 kml Exp $ */

#include "destrn.h"
#include "strml.h"
#include "fdcltrn.h"

u2_t
proind (i4_t (*f) (), struct d_r_t *desrel, u2_t cinum, char *cort, struct des_tid *tid)
{
  u2_t n, fdf;
  struct ldesind *desind;
  char a[BD_PAGESIZE];

  desind = desrel->pid;
  fdf = desrel->desrbd.fdfnum;
  for (n = 0; desind != NULL && n != cinum; desind = desind->listind, n++)
    {
      keyform (desind, fdf, a, cort);
      if ((*f) (desind, a, tid) != OK)
	return (n);
    }
  return (n);
}

u2_t
mproind (struct d_r_t *desrel, u2_t cinum, char *cort, char *newc, struct des_tid *tid)
{
  u2_t n, k;
  struct ldesind *desind;
  char a[BD_PAGESIZE];

  desind = desrel->pid;
  k = desrel->desrbd.fdfnum;
  for (n = 0; desind != NULL && n != cinum; desind = desind->listind, n++)
    {
      keyform (desind, k, a, cort);
      ordindd (desind, a, tid);
      keyform (desind, k, a, newc);
      if (ordindi (desind, a, tid) != OK)
	return (n);
    }
  return (n);
}
