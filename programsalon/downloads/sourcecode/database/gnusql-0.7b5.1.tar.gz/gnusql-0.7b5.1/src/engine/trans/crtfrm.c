/*
 *  crtfrm.c  - forming of a tuple
 *              Kernel of GNU SQL-server 
 *
 * This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: crtfrm.c,v 1.246 1997/03/31 11:04:50 kml Exp $ */

#include "xmem.h"
#include "destrn.h"
#include "sctp.h"
#include "strml.h"
#include "fdcltrn.h"

u2_t
cortform (struct des_field *df, u2_t fdf, u2_t fields_n, char *fc,
          char *fval, char *cort, char *buf, u2_t * mfn)
{
  u2_t k, fn, n, scsize, type;
  i4_t t, sst;
  char *arrpnt[BD_PAGESIZE];
  u2_t arrsz[BD_PAGESIZE];
  char *val, *newval, *endsc, *a, *sc;
  i4_t size;
  
  tuple_break (cort, arrpnt, arrsz, df, fdf, fields_n);  
  scsize = scscal (cort);
  sst = 1;

  for (endsc = buf, a = buf + scsize; endsc < a;)
    *endsc++ = *cort++ & ~EOSC;
  for (n = 0; (t = selsc1 (&fc, sst++)) != ENDSC; n++)
    {
      fn = mfn[n];
      if (t == EQ)
	continue;
      if (t == NEQ)
	{
	  type=(df + fn)->field_type;
	  if(type == T1B || type == T2B || type == T4B || type == TFLOAT)
	    fval += size2b;
	  newval = proval (fval, type);
	  arrpnt[fn] = fval;
	  arrsz[fn] = newval - fval;
	  fval = newval;
        }
      else
	arrpnt[fn] = NULL;
      if (fn < fdf)
	continue;
      k = fn - fdf;
      sc = buf + 1;
      if (k >= 7)
	{
          sc += k / 7;
	  k = k % 7;
	}
      while (endsc <= sc)
	*endsc++ = 0;
      if (t == NEQ)
	*sc |= BITVL(k);	/* write 1 in a new tuple scale */
      else
	*sc &= ~BITVL(k);
    }
  while (*(--endsc) == 0);
  *endsc++ |= EOSC;
  val = endsc;
  for (fn = 0; fn < fields_n; fn++)
    if ((a = arrpnt[fn]) != NULL)
      {
        size = arrsz[fn];
        bcopy (a, val, size);
        val += size;
      }
  return (val - buf);
}

