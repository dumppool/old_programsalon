/*  fdclsrt.h - functions declarations of Sorter
 *              Kernel of GNU SQL-server. Sorter   
 *
 * This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: fdclsrt.h,v 1.245 1997/03/31 03:46:38 kml Exp $ */

#include "f1f2decl.h"
/* cmpkey.c */
/*      35 */ i4_t cmpkey(u2_t *afn, struct des_field *df, char *drctn, char *pk1, char *pk2);
/*     135 */ u2_t scscal(char *a);

/* extsrt.c */
/*      42 */ struct el_tree *extsort(i4_t M, char prdbl, char *drctn, u2_t *afn, struct des_field *df, struct el_tree *tree);

/* push.c */
/*      41 */ void push(void (*putr1 )(), struct el_tree *tree, struct el_tree *q, char prdbl, char *drctn, u2_t *afn, struct des_field *df, i4_t nbnum);
/*     116 */ i4_t geteltr(i4_t nbnum, struct el_tree *q, i4_t i);
i4_t next_el_tree (i4_t nbnum, struct el_tree *q, i4_t i, char *pkr);

/* puts.c */
/*      41 */ void putkr(char *pkr);
void middleput ( char *pkr, u2_t size);
/*      62 */ void putcrt(char *pkr);
/*     121 */ void puttid(char *pkr);
/*     140 */ void getptob(void);
void middle_put_tid (char *pkr);
/*     158 */ u2_t calsc(u2_t *afi, u2_t *ai);
/*     170 */ void getptmp(void);

/* quicksor.c */
/*      36 */ void quicksort(i4_t M, char prdbl, char *drctn, u2_t *afn, struct des_field *df);

/* rkfrm.c */
/*      46 */ void rkfrm(char *cort, u2_t pn, u2_t ind, char prdbl, char *drctn, i4_t M, struct des_field *df, u2_t *mfn);
/*     139 */ void putkf(void);
/*     181 */ char *remval(char *aval, char **a, u2_t type);

/* sort.c */
/*      35 */ i4_t trsort(u2_t *fpn, struct des_field *adf, u2_t *mfn, char prdbl, char *drctn);
/*      92 */ i4_t flsort(u2_t segn, u2_t *fpn, struct des_field *adf, u2_t *mfn, char prdbl, char *drctn);
/*     149 */ i4_t tidsort(u2_t *fpn);
/*     199 */ void bgnng();
/*     228 */ u2_t getfpn(void);
/*     238 */ void addext(void);

/* srtipc.c */
/*      50 */ void main(i4_t argc, char **argv);
/*     164 */ u2_t getext(void);
/*     185 */ void ADMT_putext(u2_t *mfpn, u2_t exn);
/*     211 */ char *getpage(struct A *ppage, u2_t sn, u2_t pn);
/*     276 */ char *getnew(struct A *ppage, u2_t sn, u2_t pn);
/*     325 */ void putpage(struct A *ppage, char type);
/*     369 */ void crtrn(void);
/*     374 */ void ans_srt(u2_t fpn, u2_t lpn);
/*     395 */ void finit(void);

/* tidsrt.c */
/*      47 */ void quick_sort_tid(i4_t M);
/*     116 */ void puts_tid(void);
/*     154 */ struct el_tree *ext_sort_tid(i4_t M, struct el_tree *tree);
/*     253 */ void push_tid(void (*pnt_puttid )(), struct el_tree *tree, struct el_tree *q, i4_t nbnum);
/*     302 */ i4_t get_el_tr_tid(i4_t nbnum, struct el_tree *q, i4_t i);
/*     355 */ void put_tid(char *pkr);
/*     371 */ i4_t cmp_tid(char *pnt1, char *pnt2);
