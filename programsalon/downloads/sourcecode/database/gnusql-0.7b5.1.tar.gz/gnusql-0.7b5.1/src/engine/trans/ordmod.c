/*
 *  ordmod.c  - Ordinary Modification
 *              Kernel of GNU SQL-server  
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: ordmod.c,v 1.247 1997/04/15 11:45:41 vera Exp $ */

#include "destrn.h"
#include "strml.h"
#include "fdcltrn.h"
#include "xmem.h"

extern struct d_r_t *firstrel;

void
ordmod (u2_t sn, i4_t rn, struct des_tid *tid,
        struct des_tid *ref_tid, u2_t oldsize, char *nc, u2_t newsize)
{
  char *asp = NULL;
  i2_t delta;
  u2_t pn, ind, pn2;
  i4_t idm;
  struct A pg;

  delta = oldsize - newsize;
  if (delta >= 0)
    {
      u2_t *ai;
      if (ref_tid->tpn != (u2_t) ~ 0)
	{
	  tid = ref_tid;
	}
      pn = tid->tpn;
      while ((asp = getpg (&pg, sn, pn, 'x')) == NULL);
      idm = begmop (asp);
      ai = (u2_t *) (asp + phsize) + tid->tindex;
      if (delta > 0)
        compress (sn, tid, idm, asp, oldsize, newsize);
      else
        recmjform (OLD, sn, pn, idm, *ai, oldsize, asp + *ai, 0);
      bcopy (nc, asp + *ai, newsize);
      MJ_PUTBL ();
      putpg (&pg, 'm');
      if (delta > 0)
        modrec (sn, rn, pn, delta);
    }
  else
    {
      pn = tid->tpn;
      ind = tid->tindex;
      if (ref_tid->tpn == (u2_t) ~ 0)
	{
	  if (nordins (sn, rn, tid, CORT, oldsize, newsize, nc) != 0)
	    {
	      doindir (sn, rn, tid, oldsize, newsize, nc);
	      modrec (sn, rn, pn, oldsize - MIN_TUPLE_LENGTH);
	    }
	}
      else
	{
	  if (nordins (sn, rn, tid, CORT, MIN_TUPLE_LENGTH, newsize, nc) == 0)
            {
              pn2 = ref_tid->tpn;
              while ((asp = getpg (&pg, sn, pn2, 'x')) == NULL);
              idm = begmop (asp);
              compress (sn, ref_tid, idm, asp, oldsize, 0);
              MJ_PUTBL ();
              putpg (&pg, 'm');
              modrec (sn, rn, pn2, oldsize + size2b);
            }
	  else if (nordins (sn, rn, ref_tid, CREM, oldsize, newsize, nc) != 0)
	    {
	      doindir (sn, rn, tid, MIN_TUPLE_LENGTH, newsize, nc);
              pn2 = ref_tid->tpn;
              while ((asp = getpg (&pg, sn, pn2, 'x')) == NULL);
              idm = begmop (asp);
              compress (sn, ref_tid, idm, asp, oldsize, 0);
              MJ_PUTBL ();
              putpg (&pg, 'm');
              modrec (sn, rn, pn2, oldsize + size2b);
	    }
	}
    }
}

static int
analoc (u2_t sn, u2_t pn, u2_t delta, struct A *pg, i4_t * idm, u2_t pfms)
{
  u2_t lind, fs;
  char *asp = NULL;
  
  while ((asp = getpg (pg, sn, pn, 'x')) == NULL);
  lind = ((struct page_head *) asp)->lastin;
  fs = *((u2_t *) (asp + phsize) + lind) - (phsize + size2b * (lind + 1));
  if (testfree (asp, fs, delta) == -1)
    {
      putpg (pg, 'n');
      return (-1);
    }
  *idm = begmop (asp);
  if (fs < pfms)
    rempbd (asp, sn, pn, *idm);
  return (0);
}

int
nordins (u2_t sn, i4_t rn, struct des_tid *tid, i4_t type,
         u2_t oldsize, u2_t newsize, char *nc)
{
  struct A pg;
  u2_t size, offloc, pn;
  i2_t delta;

  delta = newsize - oldsize;
  pn = tid->tpn;
  if ((size = getrec (sn, rn, pn, &pg, &offloc)) >= (u2_t) delta)
    {
      char *asp, *a;
      i4_t idm;
      u2_t *ai, pnifam;
      struct A pg_table;
      
      if (analoc (sn, pn, delta, &pg_table, &idm, size) != 0)
	{
	  BUF_unlock (sn, 1, &pg.p_pn);
	  return (-1);
	}
      *nc = type;
      asp = pg_table.p_shm;
      ai = (u2_t *) (asp + phsize) + tid->tindex;
      if (*ai == 0)
        inscort (sn, tid, idm, asp, nc, newsize);
      else
        exspind (sn, tid, idm, asp, oldsize, newsize, nc);
      MJ_PUTBL ();
      putpg (&pg_table, 'm');
      pnifam = pg.p_pn;
      while (BUF_enforce (sn, pnifam) < 0);
      asp = getwl (&pg, sn, pnifam);
      a = asp + offloc;
      idm = begmop (asp);
      recmjform (OLD, sn, pn, idm, offloc, size2b, a, 0);
      MJ_PUTBL ();
      t2bpack (size - delta, a);
      putpg (&pg, 'm');
      return (0);
    }
  else
    {
      BUF_unlock (sn, 1, &pg.p_pn);
      return (-1);
    }
}

void
doindir (u2_t sn, i4_t rn, struct des_tid *tid,
         u2_t oldsize, u2_t newsize, char *nc)
{
  i4_t rep, idm;
  struct d_r_t *desrel;
  char *a, *asp = NULL;
  u2_t cpn, pfms, *ai, pn;
  struct d_sc_i *scind;
  struct ldesscan *disc;
  i2_t num;
  struct A pg;
  struct des_tid ref_tid;

  for (desrel = firstrel; desrel != NULL; desrel = desrel->drlist)
    if (desrel->desrbd.relnum == rn)
      break;
  *nc = CREM;
  scind = rel_scan (sn, rn, (char *) desrel, &num, 0, NULL, NULL, 0, 0, NULL);
  disc = &scind->dessc;
  pn = cpn = tid->tpn;
  rep = fgetnext (disc, &cpn, &pfms, FASTSCAN);
  while (rep != EOI && cpn != pn)
    rep = getnext (disc, &cpn, &pfms, FASTSCAN);
  if (rep != EOI)
    rep = getnext (disc, &cpn, &pfms, FASTSCAN);
  if (rep != EOI && pfms >= newsize)
    {
      if (analoc (sn, cpn, (i2_t) newsize, &pg, &idm, pfms) == 0)
        {
          u2_t nind = 0, lind;
          asp = pg.p_shm;
          ai = (u2_t *) (asp + phsize);
          lind = ((struct page_head *) asp)->lastin;
          while ((nind <= lind) && (*ai != 0))
            {
              CHECK_PG_ENTRY(ai);
              ai++;
              nind++;
            }
          ref_tid.tpn = cpn;
          ref_tid.tindex = nind;
          inscort (sn, &ref_tid, idm, asp, nc, newsize);
          MJ_PUTBL ();
          putpg (&pg, 'm');
          modcur (disc, pfms - newsize - size2b);
	}
      else
        {
          BUF_unlock (sn, 1, &disc->curlpn);
          ref_tid = ordins (sn, rn, nc, newsize, 'n');
        }
    }
  else
    {
      if (rep != EOI)
        BUF_unlock (sn, 1, &disc->curlpn);
      ref_tid = ordins (sn, rn, nc, newsize, 'n');
    }
  delscan (num);
  while ((asp = getpg (&pg, sn, tid->tpn, 'x')) == NULL);
  idm = begmop (asp);
  if (oldsize > MIN_TUPLE_LENGTH)
    compress (sn, tid, idm, asp, oldsize, MIN_TUPLE_LENGTH);
  ai = (u2_t *) (asp + phsize) + tid->tindex;
  a = asp + *ai;
  *a++ = IND;
  t2bpack (ref_tid.tindex, a);
  t2bpack (ref_tid.tpn, a + size2b);
  MJ_PUTBL ();
  putpg (&pg, 'm');
}
