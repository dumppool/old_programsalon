/*
 *  opinpg.c  -  Low level operations inside DB pages
 *               Kernel of GNU SQL-server 
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: opinpg.c,v 1.246 1997/04/15 11:45:41 vera Exp $ */

#include "xmem.h"
#include "destrn.h"
#include "strml.h"
#include "fdcltrn.h"

extern i4_t minidnt;

static int
lookidtr (char *a) /* 1 - this record may be removed, 0 - not */
{
  unsigned char t;

  t = *a & MSKCORT;
  if (t == IDTR)
    {
      i4_t idtran;
      idtran = t4bunpack (a + 1);
      if (idtran < minidnt)
        return (1);
    }
  return (0);
}

int
testfree (char *asp, u2_t fs, u2_t corsize)
	/*  1 - this page is empty    */
	/* -1 - no allocation         */
        /*  0 - allocation is present */
{
  u2_t *ali, *ai;

  ai = (u2_t *) (asp + phsize);
  for (ali = ai + ((struct page_head *) asp)->lastin; ai <= ali; ai++)
    if (*ai != 0 && CHECK_PG_ENTRY(ai) && (lookidtr (*ai + asp) == 1))
      {
	fs += MIN_TUPLE_LENGTH + size2b;
	if (fs == BD_PAGESIZE - phsize)
	  return (1);		/* this page is empty */
      }
  if (fs >= corsize + size2b)
    return (0);
  return (-1);
}

static void
shift_cut (u2_t *ai, char *asp, i4_t idt_count, u2_t *afi, u2_t sn, u2_t pn, i4_t idm)
{
  i2_t shsize = 0;
  u2_t fs, off, *aci;
  char *af, *src, *dst;
  i4_t n;

  n = ai - afi;
  if (n != 0)
    {
      shsize = idt_count * MIN_TUPLE_LENGTH;
      off = *afi;
      af = asp + off;
      fs = *afi - *ai;
      recmjform (COMBR, sn, pn, idm, off, fs, af, shsize);
      for (src = af - 1, dst = src + shsize; fs != 0; fs--)
        *dst-- = *src--;
    }
  af = (char *)(afi - idt_count);
  recmjform (OLD, sn, pn, idm, af - asp, idt_count * size2b, af, 0);
  for (aci = (u2_t *)af; idt_count >= 0; idt_count--)
    *aci++ = 0;
  for (; n != 0; n--)
    *aci++ += shsize;
}

void
rempbd (char *asp, u2_t sn, u2_t pn, i4_t idm)
{/* remove records about committed transactions deletions */
  i4_t what_do = 0, idt_count = 0;
  u2_t *ali, *ai, *afi;
  struct page_head *ph;
  
  afi = ai = (u2_t *) (asp + phsize);
  ph = (struct page_head *) asp;
  for (ali = ai + ph->lastin; ai <= ali; ai++)
    {
      if (*ai != 0 && CHECK_PG_ENTRY(ai))
        {
          if (lookidtr (*ai + asp) == 1)
            {
              if (what_do == 2)
                {
                  shift_cut (ai - 1, asp, idt_count, afi, sn, pn, idm);
                  what_do = 0;
                  idt_count = 0;
                }
              idt_count++;
              afi = ai;
              what_do = 1;
            }
          else if (what_do == 1)
            what_do = 2;
        }
      else if (what_do != 0)
        {
          shift_cut (ai - 1, asp, idt_count, afi, sn, pn, idm);
          what_do = 0;
          idt_count = 0;
        }
    }
  if (what_do != 0)
    shift_cut (ai - 1, asp, idt_count, afi, sn, pn, idm);
  if (*ali == 0)
    {
      char *b;
      b = (char *) &ph->lastin;
      afi = (u2_t *) (asp + phsize);
      recmjform (OLD, sn, pn, idm, b - asp, size2b, b, 0);
      for (ai = ali - 1; ai >= afi && *ai == 0; )
	ai--;
      ph->lastin = ai - afi;
    }
}

void
inscort (u2_t sn, struct des_tid *tid, i4_t idm, char *asp, char *cort, u2_t corsize)
{
  u2_t *ali, *ai;
  struct page_head *ph;
  
  ai = (u2_t *) (asp + phsize);
  ph = (struct page_head *) asp;
  ali = ai + ph->lastin;
  ai += tid->tindex;
  if (ai > ali)
    {
      char *b;
      b = (char *) &ph->lastin;
      recmjform (OLD, sn, tid->tpn, idm, b - asp, size2b, b, 0);
      ph->lastin += 1;
      *ai = *ali - corsize;
      bcopy (cort, asp + *ai, corsize);
    }
  else
    exspind (sn, tid, idm, asp, 0, corsize, cort);
}

void
exspind (u2_t sn, struct des_tid *tid, i4_t idm, char *asp,
         u2_t oldsize, u2_t newsize, char *nc)
{
  char *a;
  u2_t *afi, *ali, *ai, *aci, pn;
  i2_t delta;

  afi = (u2_t *) (asp + phsize);
  ai = afi + tid->tindex;
  ali = afi + ((struct page_head *) asp)->lastin;
  delta = newsize - oldsize;
  a = (char *) ai;
  pn = tid->tpn;
  recmjform (OLD, sn, pn, idm, a - asp, (ali - ai + 1) * size2b, a, 0);
  for (aci = ai; aci > afi && *aci == 0;)
    aci--;
  if (ai != ali)
    {
      u2_t fs;
      if (aci == afi)
        fs = BD_PAGESIZE - *ali;
      else
        fs = *aci - *ali;
      recmjform (SHF, sn, pn, idm, *ali, fs, NULL, delta);
      a = asp + *ali;
      bcopy (a, a - delta, fs);
    }
  if (*ai != 0)
    {
      recmjform (OLD, sn, pn, idm, *ai, oldsize, *ai + asp, 0);
      *ai -= delta;
    }
  else
    {
      if (aci == afi)
	*ai = BD_PAGESIZE - newsize;
      else
	*ai = *aci - newsize;
    }
  for (afi = ai + 1; afi <= ali; afi++)
    if (*afi != 0)
      *afi -= delta;
  bcopy (nc, asp + *ai, newsize);
}

void
compress (u2_t sn, struct des_tid *tid, i4_t idm, char *asp,
          u2_t oldsize, u2_t newsize)
{
  char *src, *dst, *af;
  u2_t *ali, *aci, *ai, pn;
  i2_t delta;

  ai = (u2_t *)(asp + phsize) + tid->tindex;
  pn = tid->tpn;
  src = asp + *ai;
  delta = oldsize - newsize;
  ali = (u2_t *) (asp + phsize) + ((struct page_head *) asp)->lastin;
  af = (char *) ai;
  recmjform (OLD, sn, pn, idm, af - asp, (ali - ai + 1) * size2b, af, 0);
  recmjform (OLD, sn, pn, idm, *ai, oldsize, src, 0);
  if (ai != ali)
    {
      u2_t fs;
      fs = *ai - *ali;
      recmjform (SHF, sn, pn, idm, *ali, fs, NULL, -delta);
      for (src--, dst = src + delta; fs != 0; fs--)
        *dst-- = *src--;
    }
  for (aci = ai; aci <= ali; aci++)
    if (*aci != 0)
      *aci += delta;
}
