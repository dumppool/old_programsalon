/*
 *  insfltr.c  - Insertion into a filter 
 *               Kernel of GNU SQL-server 
 *
 *  $Id: insfltr.c,v 1.245 1997/03/31 03:46:38 kml Exp $
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

#include "destrn.h"
#include "strml.h"
#include "fdcltrn.h"

extern char **scptab;
extern i2_t maxscan;
extern struct des_nseg desnseg;

int
insfltr (i4_t scnum, i4_t idfl)
{
  struct d_mesc *scpr;
  struct des_tob *destob;
  char sctype, *asp;
  struct p_h_f *ph;
  struct d_r_t *desrel, *fdesrel;
  struct des_fltr *desfltr;
  struct des_tid tid;
  struct  A pg;

  scpr = (struct d_mesc *) * (scptab + scnum);
  if (scnum >= maxscan || scpr == NULL)
    return (NDSC);
  if (scpr->prcrt == 0)
    return (NCR);
  if ((u2_t) idfl > desnseg.mtobnum)
    return (NIOB);  
  desfltr = (struct des_fltr *) * (desnseg.tobtab + idfl);
  if (desfltr == NULL)
    return (NIOB);
  destob = &desfltr->tobfl;
  if (destob->prdt.prob != FLTR)
    return (NIOB);
  fdesrel = desfltr->pdrtf;
  if ((sctype = scpr->obsc) == SCR)
    {				/* relation scan */
      struct d_sc_r *screl;
      screl = (struct d_sc_r *) scpr;
      desrel = (struct d_r_t *) scpr->pobsc;
      tid = screl->curtid;
    }
  else if (sctype == SCI)
    {				/* index scan */
      struct d_sc_i *scind;
      scind = (struct d_sc_i *) scpr;
      desrel = (&scind->dessc)->pdi->dri;
      tid = scind->dessc.ctidi;
    }
  else
    return (NIOB);
  if (fdesrel != desrel)
    return (NCF);
  asp = getwl (&pg, NRSNUM, destob->lastpn);
  ph = (struct p_h_f *) asp;
  if ((ph->freeoff + tidsize) > BD_PAGESIZE)
    {
      asp = getptob (&pg, destob);
      ph = (struct p_h_f *) asp;
      ph->freeoff = phfsize;
    }
  ph->freeoff += tidsize;
  *(struct des_tid *) (asp + ph->freeoff) = tid;
  putwul (&pg, 'm');
  destob->prdt.prsort = NSORT;
  return (OK);
}
