/*
 *  inscon.c  - mass insertion of rows satisfyed specific condition
 *               on basis scanning of specific table
 *               by itself, by specific index, by specific filter
 *              Kernel of GNU SQL-server  
 *
 * This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: inscon.c,v 1.246 1997/04/10 06:57:28 vera Exp $ */

#include "destrn.h"
#include "strml.h"
#include "fdcltrn.h"
#include "xmem.h"

extern struct des_nseg desnseg;
extern char *pbuflj;
extern struct ADBL adlj;
extern i4_t ljmsize;
extern i4_t ljrsize;
extern struct ldesind **TAB_IFAM;

#define CMP_REL \
  if (sn_out != NRSNUM)\
    {\
      if ((cpn = cont_fir (pidrl_out, &dr_out)) != OK)\
	return (cpn);\
      if ((cpn = synlsc (WSC, pidrl_out, sc, slsz, fn, (u2_t *) NULL)) != OK)\
        return (cpn);\
      fn2 = dr_out->desrbd.fieldnum;\
      fdf2 = dr_out->desrbd.fdfnum;\
      df2 = (struct des_field *) (dr_out + 1);\
    }\
  else\
    {				/* The insertion in the temporary relation */\
      dtr_out = (struct des_trel *) * (desnseg.tobtab + pidrl_out->urn.obnum);\
      if (dtr_out->tobtr.prdt.prob != TREL)\
	return (NDR);\
      fn2 = dtr_out->fieldn;\
      fdf2 = dtr_out->fdftr;\
      df2 = (struct des_field *) (dtr_out + 1);\
      dt = (struct des_tob *) dtr_out;\
    }\
  if ((cpn = cmprel (fn, fdf, df, fn2, fdf2, df2)) != OK)\
    return (cpn);

#define INSERTION_BY_TID(pn,ind) \
  if (oldpn != pn)\
    {\
      putpg (&inpage, 'n');\
      while ((asp = getpg (&inpage, sn_in, pn, 's')) == NULL);\
      afi = (u2_t *) (asp + phsize);\
      oldpn = pn;\
     }\
  ai = afi + ind;

#define MASS_INSERTION \
  if (*ai != 0 && CHECK_PG_ENTRY(ai))\
    {\
       if (sn_out != NRSNUM)\
         {\
           if ((corsize = fndslc (dr_in, asp, ai, sc,\
                          slsz, cort)) != 0)\
             mins (cort, corsize, outpage, &freesz, dr_out);\
         }\
       else\
         if ((corsize = fndslc (dr_in, asp, ai, sc,\
                          slsz, NULL)) != 0)\
           minstr (outpage, asp + *ai, corsize, dt);\
    }

#define END_MASS_INS \
if (sn_out != NRSNUM)\
    eop_mass_ins (pidrl_out->urn.obnum, outpage, freesz);\
  else\
    {\
      dtr_out->tobtr.prdt.prsort = NSORT;\
      putwul (outpage, 'm');\
    }

static int
cmprel (u2_t fn1, u2_t fdf1, struct des_field *df1, u2_t fn2,
        u2_t fdf2, struct des_field *df2)
{
  struct des_field *ldf;
  u2_t type;
  
  if (fn1 != fn2 || fdf1 != fdf2)
    return (N_EQV);
  for (ldf = df1 + fn1; df1 < ldf; df1++, df2++)
    {
      if ((type = df1->field_type) != df2->field_type)
	return (N_EQV);
      if (type == TCH || type == TFL)
	if (df1->field_size > df2->field_size)
	  return (N_EQV);
    }
  return (OK);
}

static void
eop_mass_ins (i4_t rn, struct A *outpage, u2_t freesz)
{
  if (outpage->p_shm != NULL)
    {
      u2_t sn;
      sn = outpage->p_sn;
      tab_difam (sn);
      insrec (TAB_IFAM[sn], rn, outpage->p_pn, freesz);
      putwul (outpage, 'm');
    }
}

static void
mins (char *cort, u2_t corsize, struct A *outpage, u2_t *freesz,
      struct d_r_t *desrel)
{
  char *tuple, *outasp;
  struct page_head *ph;
  i4_t n, ni, rn;
  u2_t size, delta, sn;
  struct des_tid tid;
  struct id_rel idr;
  struct ADBL last_adlj;

  modmes ();
  *cort = CORT;
  delta = corsize + size2b;
  last_adlj = adlj;
  tuple = cort;
  sn = desrel ->segnr;
  rn = desrel->desrbd.relnum;
  if (delta > * freesz)
    {
      u2_t newpn;
      eop_mass_ins (rn, outpage, *freesz);
      newpn = getempt (sn);
      outasp = getnew (outpage, sn, newpn);
      tid.tpn = newpn;
      tid.tindex = 0;
      size = BD_PAGESIZE - corsize;
      ph = (struct page_head *) outasp;
      ph->lastin = 0;
      t2bpack (size, outasp + phsize);
      *freesz = BD_PAGESIZE - phsize - delta;
    }
  else
    {
      u2_t *ai;
      outasp = outpage->p_shm;
      ph = (struct page_head *) outasp;
      ai = (u2_t *) (outasp + phsize) + ph->lastin;
      size = *ai - corsize;
      ph->lastin++;
      tid.tpn = outpage->p_pn;
      tid.tindex = ph->lastin;
      *(ai + 1) = size;
      *freesz -= delta;
    }
  idr.urn.segnum = sn;
  idr.urn.obnum = rn;
  idr.pagenum = desrel->pn_r;
  idr.index = desrel->ind_r;
  wmlj (INSLJ, ljmsize + corsize, &adlj, &idr, &tid, 0);
  bcopy (cort, outasp + size, corsize);
  n = desrel->desrbd.indnum;
  ni = proind (ordindi, desrel, n, tuple, &tid);
  if (ni < n)
    {
      struct des_tid ref_tid;
      wmlj (RLBLJ, ljrsize, &last_adlj, &idr, &tid, 0);
      proind (ordindd, desrel, ni, tuple, &tid);
      ref_tid.tpn = (u2_t) ~ 0;
      orddel (sn, rn, &tid, &ref_tid, corsize);
    }
}

CPNM
inscrl (struct id_rel *pidrl_in, struct id_rel *pidrl_out, u2_t fln,
        u2_t * fl, u2_t slsz, char *sc)
{
  u2_t fn, fdf, fn2, fdf2, *ali, sn_in, sn_out, *ai;
  char *cort, *asp = NULL;
  struct des_field *df, *df2;
  u2_t pn, corsize, freesz = 0;
  struct d_r_t *dr_out;
  struct des_trel *dtr_out = NULL;
  struct des_tob *dt = NULL;
  CPNM cpn;
  char *outasp = NULL;
  struct A inpage, *outpage, outpg;
  char *arrpnt[BD_PAGESIZE];
  u2_t arrsz[BD_PAGESIZE];

  sn_in = pidrl_in->urn.segnum;
  sn_out = pidrl_out->urn.segnum;
  if (sn_in == sn_out && pidrl_in->urn.obnum == pidrl_out->urn.obnum)
    return (NDR);
  cort = pbuflj + ljmsize;
  outpage = &outpg;
  outpage->p_shm = NULL;
  if (sn_in != NRSNUM)
    {
      struct d_r_t *dr_in;
      struct d_sc_i *scind;
      struct ldesscan *disc;
      u2_t size;
      i4_t rep;
      i2_t num;
      
      if ((cpn = contir (pidrl_in, &dr_in)) != OK)
	return (cpn);
      fn = dr_in->desrbd.fieldnum;
      fdf = dr_in->desrbd.fdfnum;
      df = (struct des_field *) (dr_in + 1);
      if (testcond (df, fn, fdf, 0, NULL, &slsz, sc, 0, NULL) != OK)
	return (NCF);
      if ((cpn = synlsc (RSC, pidrl_in, sc, slsz, fn, (u2_t *) NULL)) != OK)
	return (cpn);      
      CMP_REL;
      if (sn_out == NRSNUM)
	outasp = getwl (outpage, NRSNUM, dtr_out->tobtr.lastpn);
      scind = rel_scan (sn_in, pidrl_in->urn.obnum, (char *) dr_in,
                        &num, 0, NULL, NULL, 0, 0, NULL);
      disc = &scind->dessc;
      rep = fgetnext (disc, &pn, &size, FASTSCAN);
      for (; rep != EOI;)
	{
	  while ((asp = getpg (&inpage, sn_in, pn, 's')) == NULL);
	  ai = (u2_t *) (asp + phsize);
	  ali = ai + ((struct page_head *) asp)->lastin;
	  for (; ai <= ali; ai++)
            MASS_INSERTION;
	  putpg (&inpage, 'n');
	  rep = getnext (disc, &pn, &size, FASTSCAN);
	}
      delscan (num);
    }
  else       /* sn_in == NRSNUM */
    {
      struct des_trel *dtr_in;
      
      dtr_in = (struct des_trel *) * (desnseg.tobtab + pidrl_in->urn.obnum);
      if (dtr_in->tobtr.prdt.prob != TREL)
	return (NDR);
      fn = dtr_in->fieldn;
      fdf = dtr_in->fdftr;
      df = (struct des_field *) (dtr_in + 1);
      if (testcond (df, fn, fdf, 0, NULL, &slsz, sc, 0, NULL) != OK)
	return (NCF);
      CMP_REL;
      if (sn_out == NRSNUM)
	outasp = getwl (outpage, NRSNUM, dtr_out->tobtr.lastpn);	
      for (pn = dtr_in->tobtr.firstpn; pn != (u2_t) ~ 0;)
	{
	  asp = getwl (&inpage, NRSNUM, pn);
	  ai = (u2_t *) (asp + phtrsize);
	  ali = ai + ((struct p_h_tr *) asp)->linptr;
	  for (; ai <= ali; ai++)
	    if (*ai != 0 &&
                (corsize = tstcsel (df, fn, fdf, slsz,
                                       sc, asp + *ai, arrpnt, arrsz)) != 0 )
              {
		if (sn_out != NRSNUM)
                  mins (asp + *ai, corsize, outpage, &freesz, dr_out);
		else
                  minstr (outpage, asp + *ai, corsize, dt);
	      }	      
	  pn = ((struct listtob *) asp)->nextpn;
	  putwul (&inpage, 'n');
	}
    }
  END_MASS_INS;
  return (OK);
}

int
inscin (struct id_ind *pidind, struct id_rel *pidrl_out, u2_t fln,
        u2_t * fl, u2_t slsz, char *sc, u2_t diasz, char *diasc)
{
  u2_t fn, fdf, fn2, fdf2, sn_in, sn_out, oldpn;
  char *asp = NULL, *cort;
  struct des_field *df, *df2;
  struct ldesscan *disc;
  struct d_sc_i *scind;
  struct ldesind *di;
  u2_t *afi, *ai, corsize, kn, dscsz, freesz = 0;
  struct d_r_t *dr_in, *dr_out;
  struct id_rel *pidrl_in;
  struct des_tid tid;
  struct des_trel *dtr_out = NULL;
  char *outasp = NULL;
  i2_t n;
  i4_t cpn;
  struct des_tob *dt = NULL;  
  struct A inpage, *outpage, outpg;
  i4_t rep;

  pidrl_in = &pidind->irii;
  sn_in = pidrl_in->urn.segnum;
  sn_out = pidrl_out->urn.segnum;
  if (sn_in == sn_out && pidrl_in->urn.obnum == pidrl_out->urn.obnum)
    return (NDR);
  if ((cpn = cont_id (pidind, &dr_in, &di)) != OK)
    return (cpn);
  fn = dr_in->desrbd.fieldnum;
  fdf = dr_in->desrbd.fdfnum;
  df = (struct des_field *) (dr_in + 1);
  if (testcond (df, fn, fdf, 0, NULL, &slsz, sc, 0, NULL) != OK)
    return (NCF);
  ai = (u2_t *) (di + 1);
  if ((cpn = testdsc (dr_in, &diasz, diasc, ai, &dscsz)) != OK)
    return (cpn);

  if ((cpn = synlsc (RSC, pidrl_in, sc, slsz, fn, (u2_t *) NULL)) != OK)
    return (cpn);
  kn = di->ldi.kifn & ~UNIQ & MSK21B;
  if ((cpn = synlsc (RSC, pidrl_in, diasc, diasz, kn, ai)) != OK)
    return (cpn);
  CMP_REL;
  scind = (struct d_sc_i *) lusc (&n, scisize, (char *) di, SCI, WSC,
                                  0, NULL, sc, slsz,
				  0, NULL, diasz + size2b);
  disc = &scind->dessc;
  disc->curlpn = (u2_t) ~ 0;
  asp = (char *) scind + scisize + slsz + size2b;
  disc->dpnsc = asp;
  t2bpack (diasz, asp);
  disc->dpnsval = asp + size2b + dscsz;
  bcopy (diasc, asp + size2b, diasz);
  cort = pbuflj + ljmsize;
  outpage = &outpg;
  outpage->p_shm = NULL;
  if ((rep = ind_ftid (disc, &tid, FASTSCAN)) != EOI)
    {
      oldpn = tid.tpn;
      while ((asp = getpg (&inpage, sn_in, oldpn, 's')) == NULL);
      afi = (u2_t *) (asp + phsize);
    }
  else
    goto m1;
  if (sn_out == NRSNUM)
    outasp = getwl (outpage, NRSNUM, dtr_out->tobtr.lastpn);
  for (; rep != EOI; rep = ind_tid (disc, &tid, FASTSCAN))
    {
      INSERTION_BY_TID(tid.tpn,tid.tindex);
      MASS_INSERTION;
    }
  END_MASS_INS;
m1:
  delscan (n);
  return (OK);
}

int
inscfl (i4_t idfl, struct id_rel *pidrl_out, u2_t fln, u2_t * fl,
        u2_t slsz, char *sc)
{
  u2_t fn, fdf, fn2, fdf2, sn_out, flpn, off;
  struct des_tid *tid, *tidb;
  char *aspfl, *cort, *asp = NULL;
  u2_t oldpn, *afi, *ai, corsize, sn_in, freesz = 0;
  struct d_r_t *dr_in, *dr_out;
  struct des_field *df, *df2;
  struct des_trel *dtr_out = NULL;
  struct des_fltr *desfl;
  char *outasp = NULL;
  struct des_tob *dt = NULL;  
  CPNM cpn;
  struct A inpage, *outpage, inflpg, outpg;

  if ((u2_t) idfl > desnseg.mtobnum)
    return (NIOB);
  desfl = (struct des_fltr *) * (desnseg.tobtab + idfl);
  if (desfl == NULL)
    return (NIOB);    
  if (((struct prtob *) desfl)->prob != FLTR)
    return (NIOB);
  dr_in = desfl->pdrtf;
  fn = dr_in->desrbd.fieldnum;
  fdf = dr_in->desrbd.fdfnum;
  df = (struct des_field *) (dr_in + 1);
  if (testcond (df, fn, fdf, 0, NULL, &slsz, sc, 0, NULL) != OK)
    return (NCF);
  sn_in = dr_in->segnr;
  sn_out = pidrl_out->urn.segnum;
  cort = pbuflj + ljmsize;
  outpage = &outpg;
  outpage->p_shm = NULL;
  CMP_REL; 
  if (sn_out == NRSNUM)
    outasp = getwl (outpage, sn_out, dtr_out->tobtr.lastpn);  
  for (flpn = desfl->tobfl.firstpn; flpn != (u2_t) ~ 0;)
    {
      aspfl = getwl (&inflpg, NRSNUM, flpn);
      off = ((struct p_h_f *) aspfl)->freeoff;
      tid = (struct des_tid *) (aspfl + phfsize);
      oldpn = tid->tpn;
      while ((asp = getpg (&inpage, sn_in, oldpn, 's')) == NULL);
      afi = (u2_t *) (asp + phsize);
      tidb = (struct des_tid *) (aspfl + off);
      for (; tid < tidb; tid++)
        {
          INSERTION_BY_TID(tid->tpn,tid->tindex);
          MASS_INSERTION;
        }
      flpn = ((struct p_h_f *) aspfl)->listfl.nextpn;
      putwul (&inflpg, 'n');
    }
  END_MASS_INS;  
  return (OK);
}

