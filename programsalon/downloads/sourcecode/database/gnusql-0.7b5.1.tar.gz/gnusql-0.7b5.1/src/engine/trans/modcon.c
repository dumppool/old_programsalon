/*
 *  modcon.c  - mass modification of rows satisfyed specific condition
 *              on basis scanning of specific table
 *              by itself, by specific index, by specific filter
 *              Kernel of GNU SQL-server  
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: modcon.c,v 1.247 1997/04/10 06:57:28 vera Exp $ */

#include "destrn.h"
#include "strml.h"
#include "fdcltrn.h"
#include "xmem.h"

extern struct des_nseg desnseg;
extern char *pbuflj;
extern struct ADBL adlj;
extern i4_t ljmsize;
extern i4_t ljrsize;

static void
mmod (struct d_r_t *dr, struct des_field *df, char *cort,
      u2_t corsize, struct des_tid *tid, struct des_tid *ref_tid,
      char *fl, char *fval, u2_t * mfn)
{
  char *nc;
  u2_t newsize, sn;
  i4_t n, ni, rn;
  struct ADBL last_adlj;
  struct id_rel idr;

  nc = cort + corsize;
  newsize = cortform (df, dr->desrbd.fdfnum, dr->desrbd.fieldnum,
                      fl, fval, cort, nc, mfn);
  if (newsize <size4b)
    newsize = size4b;
  modmes ();
  last_adlj = adlj;
  idr.urn.segnum = sn = dr->segnr;
  idr.urn.obnum = rn = dr->desrbd.relnum;
  idr.pagenum = dr->pn_r;
  idr.index = dr->ind_r;
  wmlj (MODLJ, ljmsize + corsize + newsize, &adlj, &idr, tid, 0);
  ordmod (sn, rn, tid, ref_tid, corsize, nc, newsize);
  n = dr->desrbd.indnum;
  ni = mproind (dr, n, cort, nc, tid);
  if (ni < n)
    {
      wmlj (RLBLJ, ljrsize, &last_adlj, &idr, tid, 0);
      mproind (dr, ni + 1, nc, cort, tid);
      ordmod (sn, rn, tid, ref_tid, corsize, nc, newsize);
    }
  BUF_endop ();
}

int
modcrl (struct id_rel *pidrl, u2_t slsz, char *sc, u2_t flsz,
        u2_t * fl, u2_t flmsz, char *flmod)
{
  u2_t fn, fdf, *ali, *afi, *ai, sn, pn, corsize;
  char *asp = NULL, *cort;
  struct des_field *df;
  char *fval;
  struct A pg;

  sn = pidrl->urn.segnum;
  if (sn != NRSNUM)
    {
      struct d_r_t *dr;
      struct d_sc_i *scind;
      struct ldesscan *disc;
      struct des_tid tid, ref_tid;
      i4_t rn;
      CPNM cpn;
      i2_t num;
      i4_t rep;
      u2_t size, ind, pnr, indr;
      if ((cpn = cont_fir (pidrl, &dr)) != OK)
	return (cpn);
      fn = dr->desrbd.fieldnum;
      fdf = dr->desrbd.fdfnum;
      df = (struct des_field *) (dr + 1);
      if (testcond (df, fn, fdf, 0, NULL, &slsz, sc, 0, NULL) != OK)
	return (NCF);
      if (testcmod (df,fdf, flsz, fl, flmod, &fval) != OK)
	return (NCF);
      if ((cpn = synlsc (WSC, pidrl, sc, slsz, fn, NULL)) != OK)
	return (cpn);
      if ((cpn = syndmod (pidrl, df, flmod)) != OK)
	return (cpn);
      rn = pidrl->urn.obnum;
      pnr = pidrl->pagenum;
      indr = pidrl->index;
      cort = pbuflj + ljmsize;
      scind = rel_scan (sn, rn, (char *) dr, &num, 0, NULL, NULL, 0, 0, NULL);
      disc = &scind->dessc;
      rep = fgetnext (disc, &pn, &size, SLOWSCAN);
      for (; rep != EOI;)
	{
	  ind = 0;
	m1:
          while ((asp = getpg (&pg, sn, pn, 's')) == NULL);
	  afi = (u2_t *) (asp + phsize);
	  ali = afi + ((struct page_head *) asp)->lastin;
	  for (ai = afi + ind; ai <= ali; ai++)
	    if (*ai != 0 && CHECK_PG_ENTRY(ai) &&
		(corsize = fnd_slc (dr, asp, ai, sc, slsz,
                         cort, &ref_tid)) != 0)
	      {
		tid.tpn = pn;
		tid.tindex = ind;
                putpg (&pg, 'n');
		mmod (dr, df, cort, corsize,
                      &tid, &ref_tid, flmod, fval, fl);
		ind++;
		goto m1;
	      }
	  putpg (&pg, 'n');
	  rep = getnext (disc, &pn, &size, SLOWSCAN);
	}
      delscan (num);
    }
  else
    {
      struct des_trel *dtr;
      i2_t delta;
      u2_t newsize;
      struct A pg_out;
      char *arrpnt[BD_PAGESIZE];
      u2_t arrsz[BD_PAGESIZE];
  
      dtr = (struct des_trel *) * (desnseg.tobtab + pidrl->urn.obnum);
      if (dtr->tobtr.prdt.prob != TREL)
	return (NDR);
      fn = dtr->fieldn;
      fdf = dtr->fdftr;
      df = (struct des_field *) (dtr + 1);
      if (testcond (df, fn, fdf, 0, NULL, &slsz, sc, 0, NULL) != OK)
	return (NCF);
      if (testcmod (df,fdf, flsz, fl, flmod, &fval) != OK)
	return (NCF);
      getwl (&pg_out, NRSNUM, dtr->tobtr.lastpn);
      for (pn = dtr->tobtr.firstpn; pn != (u2_t) ~ 0;)
	{
	  asp = getwl (&pg, sn, pn);
	  ai = (u2_t *) (asp + phtrsize);
	  ali = ai + ((struct p_h_tr *) asp)->linptr;
	  pn = ((struct listtob *) asp)->nextpn;
	  for (; ai <= ali; ai++)
	    if (*ai != 0 &&
                (corsize = tstcsel (df, fn, fdf, slsz, sc, asp + *ai,
                                    arrpnt, arrsz)) != 0)
              {
                cort = asp + *ai;
                newsize = cortform (df, fdf, fn, flmod, fval, cort, pbuflj, fl);
                delta = corsize - newsize;
                if (delta > 0)
                  comptr (asp, ai, (u2_t) delta);
                if (delta >= 0)
                  bcopy (pbuflj, cort, newsize);
                else
                  {
                    comptr (asp, ai, corsize);
                    *ai = 0;
                    minstr (&pg_out, pbuflj, newsize, (struct des_tob *)dtr);
                  }
              }
	  if (frptr (asp) == 1)
	    frptob ((struct des_tob *) dtr, asp, pn);
	  else
	    putwul (&pg, 'n');
	}
      putwul (&pg_out, 'm');
      dtr->tobtr.prdt.prsort = NSORT;
    }
  return (OK);
}

CPNM
modcin (struct id_ind *pidind, u2_t slsz, char *sc, u2_t diasz,
        char *diasc, u2_t flsz, u2_t * fl, u2_t flmsz, char *flmod)
{
  u2_t fn, fdf, *ai, sn, pn, oldpn, corsize, dscsz, kn;
  char *asp = NULL, *cort, *fval;
  struct des_field *df;
  struct ldesscan *disc;
  struct d_sc_i *scind;
  struct ldesind *di;
  struct id_rel *pidrl;
  struct d_r_t *dr;
  i4_t pr, rep;
  i2_t n;
  CPNM cpn;
  struct des_tid tid, ref_tid;
  struct A pg;

  oldpn = 0;
  pidrl = &pidind->irii;
  sn = pidrl->urn.segnum;
  if ((cpn = cont_id (pidind, &dr, &di)) != OK)
    return (cpn);
  fn = dr->desrbd.fieldnum;
  fdf = dr->desrbd.fdfnum;
  df = (struct des_field *) (dr + 1);
  if (testcond (df, fn, fdf, 0, NULL, &slsz, sc, 0, NULL) != OK)
    return (NCF);
  if (testcmod (df,fdf, flsz, fl, flmod, &fval) != OK)
    return (NCF);
  ai = (u2_t *) (di + 1);
  if (testdsc (dr, &diasz, diasc, ai, &dscsz) != OK)
    return (NCF);

  if ((cpn = synlsc (WSC, pidrl, sc, slsz, fn, NULL)) != OK)
    return (cpn);
  if ((cpn = syndmod (pidrl, df, flmod)) != OK)
    return (cpn);
  kn = di->ldi.kifn & ~UNIQ & MSK21B;
  if ((cpn = synlsc (RSC, pidrl, diasc, diasz, kn, ai)) != OK)
    return (cpn);

  cort = pbuflj + ljmsize;
  scind = (struct d_sc_i *) lusc (&n, scisize, (char *) di, SCI, 'w',
                                  0, NULL, sc, slsz,
				  0, NULL, diasz + size2b);
  disc = &scind->dessc;
  disc->curlpn = (u2_t) ~ 0;
  asp = (char *) scind + scisize + slsz + size2b;
  disc->dpnsc = asp;
  t2bpack (diasz, asp);
  disc->dpnsval = asp + size2b + dscsz;
  bcopy (diasc, asp + size2b, diasz);
  pr = 1;
  if ((rep = ind_ftid (disc, &tid, SLOWSCAN)) != EOI)
    {
      oldpn = tid.tpn;
      while ((asp = getpg (&pg, sn, oldpn, 's')) == NULL);
      pr = 0;
    }
  for (; rep != EOI; rep = ind_tid (disc, &tid, SLOWSCAN))
    {
      pn = tid.tpn;
      assert( pr == 1 || oldpn != 0 );
      if (pr == 1)
	{
	  while ((asp = getpg (&pg, sn, pn, 's')) == NULL);
	  oldpn = pn;
	  pr = 0;
	}
      else if (oldpn != pn)
	{
	  putpg (&pg, 'n');
	  while ((asp = getpg (&pg, sn, pn, 's')) == NULL);
	  oldpn = pn;
	}
      ai = (u2_t *) (asp + phsize) + tid.tindex;
      if (*ai != 0 &&
	  (corsize = fnd_slc (dr, asp, ai, sc, slsz, cort, &ref_tid)) != 0)
	{
          putpg (&pg, 'n');
	  mmod (dr, df, cort, corsize, &tid, &ref_tid, flmod, fval, fl);
	  pr = 1;
	}
    }
  delscan (n);
  if (pr == 0)
    putpg (&pg, 'n');
  return (OK);
}

int
modcfl (i4_t idfl, u2_t slsz, char *sc, u2_t flsz, u2_t * fl,
        u2_t flmsz, char *flmod)
{
  u2_t fn, fdf, *afi, *ai, pn, off, oldpn, flpn, sn, corsize;
  char *asp = NULL, *cort, *aspfl, *fval;
  struct d_r_t *dr;
  struct des_field *df;
  struct des_tid *tid, *tidb, ref_tid;
  struct des_fltr *desfl;
  struct id_rel idrl;
  struct A inflpg, pg;
  CPNM cpn;

  if ((u2_t) idfl > desnseg.mtobnum)
    return (NIOB);
  desfl = (struct des_fltr *) * (desnseg.tobtab + idfl);
  if (desfl == NULL)
    return (NIOB);    
  if (((struct prtob *) desfl)->prob != FLTR)
    return (NIOB);
  dr = desfl->pdrtf;
  fn = dr->desrbd.fieldnum;
  fdf = dr->desrbd.fdfnum;
  df = (struct des_field *) (dr + 1);
  if (testcond (df, fn, fdf, 0, NULL, &slsz, sc, 0, NULL) != OK)
    return (NCF);
  if (testcmod (df,fdf, flsz, fl, flmod, &fval) != OK)
    return (NCF);
  sn = dr->segnr;
  idrl.urn.segnum = sn;
  idrl.urn.obnum = dr->desrbd.relnum;
  idrl.pagenum = dr->pn_r;
  idrl.index = dr->ind_r;
  if ((cpn = synlsc (WSC, &idrl, sc, slsz, fn, NULL)) != OK)
    return (cpn);
  if ((cpn = syndmod (&idrl, df, flmod)) != OK)
    return (cpn);
  cort = pbuflj + ljmsize;
  for (flpn = desfl->tobfl.firstpn; flpn != (u2_t) ~ 0;)
    {
      aspfl = getwl (&inflpg, NRSNUM, flpn);
      off = ((struct p_h_f *) aspfl)->freeoff;
      tid = (struct des_tid *) (aspfl + phfsize);
      oldpn = tid->tpn;
      while ((asp = getpg (&pg, sn, oldpn, 's')) == NULL);
      afi = (u2_t *) (asp + phsize);
      tidb = (struct des_tid *) (aspfl + off);
      for (; tid < tidb; tid++)
	{
	  pn = tid->tpn;
	  if (oldpn != pn)
	    {
	      putpg (&pg, 'n');
	      while ((asp = getpg (&pg, sn, pn, 's')) == NULL);
	      afi = (u2_t *) (asp + phsize);
	      oldpn = pn;
	    }
	  ai = afi + tid->tindex;
	  if (*ai != 0 &&
	      (corsize = fnd_slc (dr, asp, ai, sc, slsz, cort, &ref_tid)) != 0)
            {
              putpg (&pg, 'n');
              mmod (dr, df, cort, corsize, tid, &ref_tid, flmod, fval, fl);
            }
	}
      flpn = ((struct p_h_f *) aspfl)->listfl.nextpn;
      putwul (&inflpg, 'n');
    }
  putpg (&pg, 'n');
  return (OK);
}
