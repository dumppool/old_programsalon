/*
 *  rdcort.c  -  Read  a tuple 
 *               Kernel of GNU SQL-server 
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: rdcort.c,v 1.248 1997/04/15 11:45:41 vera Exp $ */

#include "destrn.h"
#include "strml.h"
#include "fdcltrn.h"
#include "xmem.h"

int
readcort (u2_t sn, struct des_tid *tid, char *cort,
          u2_t * corsize, struct des_tid *ref_tid)
{
  char *asp = NULL, *a;
  u2_t *afi, *ai;
  struct A pg;
  unsigned char t;

  while ((asp = getpg (&pg, sn, tid->tpn, 's')) == NULL);
  afi = (u2_t *) (asp + phsize);
  ai = afi + tid->tindex;
  if (*ai == 0)
    {
      putpg (&pg, 'n');
      return (NCR);
    }
  a = asp + *ai;
  t = *a & MSKCORT;
  if (t == IND)
    {			/* indirect reference */
      u2_t pn2, ind2;
      ref_tid->tindex = ind2 = t2bunpack (a + 1);
      ref_tid->tpn = pn2 = t2bunpack (a + 1 + size2b);
      putpg (&pg, 'n');
      while ((asp = getpg (&pg, sn, pn2, 's')) == NULL);
      afi = (u2_t *) (asp + phsize);
      ai = afi + ind2;
      a = asp + *ai;
      assert ((*a & CREM) != 0 && *ai != 0);
    }
  else
    ref_tid->tpn = (u2_t) ~ 0;
  *corsize = calsc (afi, ai);
  bcopy (a, cort, *corsize);
  putpg (&pg, 'n');
  return (OK);
}

u2_t
calsc (u2_t *afi, u2_t *ai)
{
  u2_t *aci;
  
  for (aci = ai - 1; aci >= afi && *aci == 0; aci--);
  if (aci < afi)
    return (BD_PAGESIZE - *ai);
  else
    return (*aci - *ai);
}

