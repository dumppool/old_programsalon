/*
 * aggrsfn.c  - calculation of aggregate functions
 *               on specific temporary table
 *              Kernel of GNU SQL-server  
 *
 * This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: aggrsfn.c,v 1.248 1997/04/21 12:38:34 vera Exp $ */

#include "xmem.h"
#include "destrn.h"
#include "strml.h"
#include "fdcltrn.h"
#include "cmpdecl.h"

extern struct des_nseg desnseg;

static u2_t
fsvfrm (char *buf, char *val, struct des_trel *destrel)
{
  char *sc;
  u2_t type, k, k1, fn, n;
  struct des_field *df;

  df = (struct des_field *) (destrel + 1);
  fn = *(u2_t *) ((char *) destrel + destrel->fieldn * rfsize);
  type = (df + fn)->field_type;
  sc = val + 1;
  val += scscal (val);
  for (k = 0, k1 = 0; k < fn; k1 = 0, sc++)
    for (; k1 < 7 && k < fn; k++, k1++)
      if ((*sc & BITVL(k1)) != 0)
	val = proval (val, type);
  n = get_length (val, type);
  bcopy (val, buf, n);
  return (n);
}

u2_t
minstab (struct id_rel *pidrel, char *val)
{
  u2_t *ai, sz, ntob;
  struct des_trel *destrel;
  char *asp;
  struct A pg;

  if (pidrel->urn.segnum != NRSNUM)
    return (NIOB);
  ntob = pidrel->urn.obnum;
  if (ntob > desnseg.mtobnum)
    return (NIOB);
  destrel = (struct des_trel *) * (desnseg.tobtab + ntob);
  if (destrel == NULL)
    return (NIOB);
  if (((struct prtob *) destrel)->prob != TREL)
    return (NIOB);
  if (((struct prtob *) destrel)->prsort != SORT)
    return (N_SORT);
  if (((struct prtob *) destrel)->prdrctn == GROW)
    {
      asp = getwl (&pg, NRSNUM, destrel->tobtr.firstpn);
      for (ai = (u2_t *) (asp + phtrsize); *ai != 0; ai++);
    }
  else
    {
      asp = getwl (&pg, NRSNUM, destrel->tobtr.lastpn);
      ai = (u2_t *) (asp + phtrsize) + ((struct p_h_tr *) asp)->linptr;
    }
  sz = fsvfrm (val, asp + *ai, destrel);
  putwul (&pg, 'n');
  return (sz);
}

u2_t
maxstab (struct id_rel * pidrel, char *val)
{
  u2_t *ai, sz, ntob;
  struct des_trel *destrel;
  char *asp;
  struct A pg;

  if (pidrel->urn.segnum != NRSNUM)
    return (NIOB);
  ntob = pidrel->urn.obnum;
  if (ntob > desnseg.mtobnum)
    return (NIOB);
  destrel = (struct des_trel *) * (desnseg.tobtab + ntob);
  if (((struct prtob *) destrel)->prob != TREL)
    return (NIOB);
  if (((struct prtob *) destrel)->prsort != SORT)
    return (N_SORT);
  if (((struct prtob *) destrel)->prdrctn == GROW)
    {
      asp = getwl (&pg, NRSNUM, destrel->tobtr.lastpn);
      ai = (u2_t *) (asp + phtrsize) + ((struct p_h_tr *) asp)->linptr;
    }
  else
    {
      asp = getwl (&pg, NRSNUM, destrel->tobtr.firstpn);
      for (ai = (u2_t *) (asp + phtrsize); *ai != 0; ai++);
    }
  sz = fsvfrm (val, asp + *ai, destrel);
  putwul (&pg, 'n');
  return (sz);
}

void
agrfrel (struct ans_next *ans, struct id_rel *pidrel, u2_t nf,
         u2_t * mnf, u2_t slsz, char *sc, char *flaglist)
{
  u2_t fn, fdf, sn, *ai, *ali, pn;
  struct des_field *df;
  i4_t i = 0;
  char **agrl, *asp = NULL;
  i2_t n;
  struct A pg;
  char *arrpnt[BD_PAGESIZE];
  u2_t arrsz[BD_PAGESIZE];

  sn = pidrel->urn.segnum;
  if (sn == NRSNUM)
    {
      struct des_trel *destrel;
      
      n = pidrel->urn.obnum;
      if (n > desnseg.mtobnum)
	{
	  ans->cotnxt = NIOB;
	  return;
	}
      destrel = (struct des_trel *) * (desnseg.tobtab + n);
      if (destrel == NULL)
	{
	  ans->cotnxt = NIOB;
	  return;
	}
      if (((struct prtob *) destrel)->prob != TREL)
	{
	  ans->cotnxt = NIOB;
	  return;
	}
      fn = destrel->fieldn;
      fdf = destrel->fdftr;
      df = (struct des_field *) (destrel + 1);
      if ((ans->cotnxt = testcond (df, fn, fdf, 0, NULL, &slsz, sc, 0, NULL)) != OK)
	return;
      agrl = (char **) xmalloc (nf * sizeof (char *));
      agrl_frm (agrl, df, nf, mnf, flaglist);      
      pn = destrel->tobtr.firstpn;
      if (pn != (u2_t) ~ 0)
        i = 1;
      for ( ; pn != (u2_t) ~ 0; )
	{
	  asp = getwl (&pg, NRSNUM, pn);
	  ai = (u2_t *) (asp + phtrsize);
	  ali = ai + ((struct p_h_tr *) asp)->linptr;
          for (; ai <= ali; ai++)
            if (*ai != 0 &&
                tstcsel (df, fn, fdf, slsz,
                         sc, asp + *ai, arrpnt, arrsz) != 0)
              agrcount (agrl, asp + *ai, df, fdf, fn, nf, mnf, flaglist);
          pn = ((struct listtob *) asp)->nextpn;
          putwul (&pg, 'n');
	}
    }
  else
    {
      struct d_sc_i *scind;
      struct d_r_t *desrel;
      struct ldesscan *disc;
      u2_t size;
      i4_t rep;
      
      if ((ans->cotnxt = contir (pidrel, &desrel)) != OK)
	return;
      fn = desrel->desrbd.fieldnum;
      fdf = desrel->desrbd.fdfnum;
      df = (struct des_field *) (desrel + 1);
      if ((ans->cotnxt = testcond (df, fn, fdf, 0, NULL, &slsz, sc, 0, NULL)) != OK)
	return;
      if ((ans->cotnxt = synlsc (RSC, pidrel, sc, slsz, fn, NULL)) != OK)
	return;
      scind = rel_scan (sn, pidrel->urn.obnum, (char *) desrel,
                        &n, 0, NULL, sc, slsz, 0, NULL);
      agrl = (char **) xmalloc (nf * sizeof (char *));
      agrl_frm (agrl, df, nf, mnf, flaglist);      
      disc = &scind->dessc;
      rep = fgetnext (disc, &pn, &size, FASTSCAN);
      if (rep != EOI)
        i = 1;      
      while (rep != EOI)
	{
          while ((asp = getpg (&pg, sn, pn, 's')) == NULL);
          ai = (u2_t *) (asp + phsize);
          ali = ai + ((struct page_head *) asp)->lastin;
          for (; ai <= ali; ai++)
            if (*ai != 0 && CHECK_PG_ENTRY(ai) &&
                fndslc (desrel, asp, ai, sc, slsz, NULL) != 0)
              agrcount (agrl, asp + *ai, df, fdf, fn, nf, mnf, flaglist);
          putpg (&pg, 'n');
          rep = getnext (disc, &pn, &size, FASTSCAN);
        }
      if (i == 1)
        xfree (disc->cur_key);
      delscan (n);      
    }
  if (i == 1)
    distagr_frm (agrl, nf, flaglist);
  ans->csznxt = write_val (ans->cadnxt, agrl, df, nf, mnf, flaglist);
  for (i = 0; i < nf; i++)
    xfree (agrl[i]);
  xfree ((char *) agrl);
  return;
}
