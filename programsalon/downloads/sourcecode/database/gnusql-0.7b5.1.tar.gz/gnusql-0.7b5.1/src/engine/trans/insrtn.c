/*
 *  insrtn.c  - Insertion operation
 *              Kernel of GNU SQL-server 
 *
 * $Id: insrtn.c,v 1.247 1997/04/15 11:45:41 vera Exp $
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

#include "destrn.h"
#include "strml.h"
#include "fdcltrn.h"
#include "xmem.h"

extern struct des_nseg desnseg;
extern struct ADBL adlj;
extern char *pbuflj;
extern i4_t ljmsize;
extern i4_t ljrsize;

static
int
tuple_frm (struct des_field *df, u2_t fnum, u2_t fdf, char *c,
           u2_t scsize, char *tuple, u2_t * corsize)
{
  i4_t k, kt;
  char *aval, *b, *d, *t;
  u2_t fn, size, type;

  t = tuple;
  b = c;
  d = aval = c + scsize;
  for (k = 0, fn = 0; fn < fdf; fn++, k++)	/* for always defined fields */
    if (k == 7)
      {
	k = 0;
	b++;
      }
  for (kt = 0, *t++ = CORT, *t = 0; b < d && fn < fnum; k++, kt++, fn++)
    {
      if (k == 7)
	{
	  k = 0;
	  b++;
	}
      if (kt == 7)
	{
	  kt = 0;
	  t++;
	  *t = 0;
	}
      if ((*b & BITVL(k)) != 0)
	*t |= BITVL(kt);
    }
  *t |= EOSC;
  t++;
  for (k = 0, fn = 0; c < d && fn < fnum; k++, df++, fn++)
    {
      if (k == 7)
	{
	  k = 0;
	  c++;
	}
      if ((*c & BITVL(k)) != 0)
	{
	  size = t2bunpack (aval);
	  aval += size2b;
	  if (size > df->field_size)
	    size = df->field_size;
	  if ((type = df->field_type) == TCH || type == TFL)
	    {
	      t2bpack (size, t);
	      t += size2b;
	    }
          bcopy (aval, t, size);
          t += size;
          aval += size;
	}
      else if (fn < fdf)
	return (NCF);
    }
  *corsize = t - tuple;
  if (*corsize > BD_PAGESIZE - phsize)
    return (NCF);
  return (OK);
}

int
insrtn (struct id_rel *pidrel, char *cort)
{
  char *tuple;
  struct des_field *df;
  u2_t sn, scsize = 1, corsize, fn, fdf;
  
  for (tuple = cort; (*tuple & EOSC) == 0; tuple++)
    {
      scsize += 1;
        if (scsize > BD_PAGESIZE - phsize)
	  return (NCF);
    }      
  sn = pidrel->urn.segnum;
  if (sn == NRSNUM)
    {
      struct des_trel *destrel;
      destrel = (struct des_trel *) * (desnseg.tobtab + pidrel->urn.obnum);
      if (destrel->tobtr.prdt.prob != TREL)
	return (NIOB);
      df = (struct des_field *) (destrel + 1);
      fn = destrel->fieldn;
      fdf = destrel->fdftr;
      if (tuple_frm (df, fn, fdf, cort, scsize, pbuflj, &corsize) != OK)
	return (NCF);
      if (corsize < MIN_TUPLE_LENGTH)
        corsize = MIN_TUPLE_LENGTH;
      return (instr ((struct des_tob *) destrel, pbuflj, corsize));
    }
  else
    {
      struct d_r_bd *drbd;
      struct ADBL last_adlj;
      struct d_r_t *desrel;
      i4_t n, ni;
      struct des_tid tid;
      i4_t rn;
      CPNM cpn;
      if ((cpn = cont_fir (pidrel, &desrel)) != OK)
	return (cpn);
      df = (struct des_field *) (desrel + 1);
      drbd = &desrel->desrbd;
      fn = drbd->fieldnum;
      fdf = drbd->fdfnum;
      tuple = pbuflj + ljmsize;
      if (tuple_frm (df, fn, fdf, cort, scsize, tuple, &corsize) != OK)
	return (NCF);
      if ((cpn = synlock (pidrel, drbd, tuple)) != 0)
	return (cpn);
      modmes ();
      last_adlj = adlj;
      rn = pidrel->urn.obnum;
      if (corsize < MIN_TUPLE_LENGTH)
        corsize = MIN_TUPLE_LENGTH;
      tid = ordins (sn, rn, tuple, corsize, 'w');
      n = drbd->indnum;
      ni = proind (ordindi, desrel, n, tuple, &tid);
      if (ni < n)
	{
          struct des_tid ref_tid;
	  wmlj (RLBLJ, ljrsize, &last_adlj, pidrel, &tid, 0);
	  proind (ordindd, desrel, ni, tuple, &tid);
          ref_tid.tpn = (u2_t) ~ 0;
	  orddel (sn, rn, &tid, &ref_tid, corsize);
          BUF_endop ();
	  return (NU);
	}
      BUF_endop ();
      return (OK);
    }
}

