/*  rkfrm.c - Key record forming
 *            Kernel of GNU SQL-server. Sorter    
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at the Institute of System Programming
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: rkfrm.c,v 1.245 1997/03/31 03:46:38 kml Exp $ */

#include <assert.h>
#include "setup_os.h"

#include "dessrt.h"
#include "pupsi.h"
#include "fdclsrt.h"
#include "xmem.h"

extern u2_t pnex, lastpnex, fdfn, freesz;
extern u2_t *cutfpn;
extern u2_t kn;
extern i4_t N;
extern i4_t NB;
extern i4_t pinit;
extern char *akr;
extern char *regakr;
extern char **regpkr;
extern char *nonsense;
extern struct A *outpage;
extern i4_t segsize;
extern u2_t fields_n;

void
rkfrm(char *cort, u2_t pn, u2_t ind, char prdbl, char *drctn,
      i4_t M, struct des_field *df, u2_t *mfn)
{
  char *aval, *val, *sc, *ak, *newval;
  u2_t kscsz, recsz, keysz, k, k1, fn, sz;
  char *arrpnt[BD_PAGESIZE];
  u2_t arrsz[BD_PAGESIZE];
  char *keyval;

  sc = cort + 1;
  aval = val = cort + scscal (cort);
  for (k = 0, fn = 0; sc < val; fn++)
    {
      if (fn < fdfn || (*sc & BITVL(k)) != 0)
	{			/* a value is present */
	  newval = proval (aval, (df + fn)->field_type);
	  arrpnt[fn] = aval;
	  arrsz[fn] = newval - aval;
	  aval = newval;
	}
      else
	{
	  arrpnt[fn] = NULL;
	  arrsz[fn] = 0;
	}
      if (fn >= fdfn)
	{
	  k++;
	  if (k == 7)
	    {
	      k = 0;
	      sc++;
	    }
	}
    }
  for (; fn < fields_n; fn++)
    {
      arrpnt[fn] = NULL;
      arrsz[fn] = 0;
    }      
  keysz = 0;
  for (k1 = 0, k = 0; k < kn; k++)
    {
      fn = mfn[k];
      if (arrpnt[fn] != NULL)
	{
	  k1++;
	  keysz += arrsz[fn];
	}
    }
  kscsz = k1 / 7;
  if ((k1 % 7) != 0)
    kscsz++;
  keysz += kscsz;
  recsz = keysz + size2b + 2 * size2b;
  
  if (freesz < (recsz + pntsize))
    {				/* initial cut form */
      quicksort (M, prdbl, drctn, mfn, df);
      putkf ();
      N = 0;
      if ((NB % pinit) == 0)
	cutfpn = (u2_t *) realloc ((void *) cutfpn, (size_t) (pinit + NB) * size2b);
    }
  
  ak = akr;
  t2bpack (recsz, ak);
  ak += size2b;
  t2bpack (pn, ak);
  ak += size2b;
  assert (ind < BD_PAGESIZE / 2);
  t2bpack (ind, ak);
  ak += size2b;  
  keyval = ak + kscsz;
  for (k1 = 0, k = 0, *ak = 0; k1 < kn; k1++)
    {
      fn = mfn[k1];
      if ((sz = arrsz[fn]) != 0)
	{
          bcopy (arrpnt[fn], keyval, sz);
          keyval += sz;
	  *ak |= BITVL(k);	/* a value is present */
	}
      k++;
      if (k == 7)
	{
	  k = 0;
	  *(++ak) = 0;
	}
    }
  if (k == 0)
    ak--;
  *ak |= EOSC;
  N++;
  *(--regpkr) = akr;
  akr += recsz;
  freesz -= recsz + pntsize;
}

void
putkf (void)
{
  char *asp, *a, *pkr;
  i4_t i;
  u2_t off, size, fpn;

  asp = getnew (outpage, NRSNUM, pnex);
  off = size4b;
  a = asp + off;
  fpn = pnex;
  for (i = 0; i < N; i++)
    {
      pkr = regpkr[i];
      if (pkr != nonsense)
	{
	  size = t2bunpack (pkr);
	  if ((size + off) > BD_PAGESIZE)
	    {
	      ++pnex;
	      if (pnex == lastpnex)
		addext ();
	      t2bpack (pnex, asp);
	      t2bpack (off, asp + size2b);
	      putpage (outpage, 'm');
	      asp = getnew (outpage, NRSNUM, pnex);
	      off = size4b;
	      a = asp + off;
	    }
          bcopy (pkr, a, size);
          a += size;
	  off += size;
	}
    }
  t2bpack ((u2_t) ~ 0, asp);
  t2bpack (off, asp + size2b);
  putpage (outpage, 'm');
  cutfpn[NB] = fpn;
  NB++;
  pnex++;
  if (pnex == lastpnex)
    addext ();  
  akr = regakr;
  regpkr = (char **) (akr + segsize);
  freesz = segsize;
}

