/*
 *  tmpob.c  - Temporary objects manipulations 
 *
 *  This file is a part of GNU SQL Server
 *
 *  Copyright (c) 1996, 1997, Free Software Foundation, Inc
 *  Developed at Institute of System Programming of Russian Academy of Science
 *  This file is written by  Vera Ponomarenko
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Contacts:   gss@ispras.ru
 *
 */

/* $Id: tmpob.c,v 1.245 1997/03/31 03:46:38 kml Exp $ */

#include "xmem.h"
#include "destrn.h"
#include "strml.h"
#include "fdcltrn.h"

extern u2_t EXNSSIZE;
extern struct des_nseg desnseg;

struct ans_ctob
crtrel (i4_t fn, i4_t fdf, struct des_field *df)
{
  struct ans_ctob ans;
  struct des_trel *destrel;
  struct des_field *dftr;
  i2_t n;
  struct A pg; 

  if (fdf > fn)
    {
      ans.cpncob = NCF;
      return (ans);
    }
  destrel = (struct des_trel *) gettob (&pg, dtrsize + fn * rfsize, &n, TREL);
  putwul (&pg, 'm');
  destrel->fieldn = fn;
  destrel->fdftr = fdf;
  destrel->keysntr = 0;
  dftr = (struct des_field *) (destrel + 1);
  for (; fn != 0; fn--)
    *dftr++ = *df++;
  ans.cpncob = OK;
  ans.idob.segnum = NRSNUM;
  ans.idob.obnum = n;
  return (ans);
}
struct ans_ctob
crfltr (struct id_rel *pidrel)
{
  struct ans_ctob ans;
  struct des_fltr *desfltr;
  i2_t n;
  struct d_r_t *desrel;
  struct A pg;

  if (pidrel->urn.segnum == NRSNUM)
    {
      ans.cpncob = NIOB;
      return (ans);
    }
  if ((ans.cpncob = contir (pidrel, &desrel)) != OK)
    return (ans);
  desfltr = (struct des_fltr *) gettob (&pg, dflsize, &n, FLTR);
  putwul (&pg, 'm');
  desfltr->pdrtf = desrel;
  ans.cpncob = OK;
  ans.idob.segnum = NRSNUM;
  ans.idob.obnum = n;
  return (ans);
}

static struct des_exns *
getext ( u2_t *pn)
{
  struct des_exns *desext, *dd;
  u2_t mn, n;

  ADMT_getext (pn);
  for (mn = desnseg.mexnum, desext = desnseg.dextab, n = 0;
       n < mn;
       n++, desext++)
    if (desext->efpn == (u2_t) ~ 0)
      goto m1;
  dd = desnseg.dextab;
  desnseg.dextab = (struct des_exns *) xrealloc ((char *) dd, (mn + DEXTD) * dexsize);
  for (n = 0, desext = desnseg.dextab + mn;
       n < DEXTD;
       n++, desext++)
    desext->efpn = (u2_t) ~ 0;
  desnseg.lexnum = mn;
  desnseg.mexnum += DEXTD;
  desext = desnseg.dextab + mn;
m1:desext->efpn = *pn;
  desext->funpn = *pn + 1;
  desext->ldfpn = (u2_t) ~ 0;
  desext->freecntr = EXNSSIZE;
  return (desext);
}

struct des_tob *
gettob (struct A *pg, u2_t size, i2_t * n, i4_t type)
{
  u2_t *b, pn;
  struct des_exns *desext;
  struct des_tob *a;
  struct listtob *l;
  char *asp;
  
  *n = lunt (&desnseg.tobtab, &desnseg.mtobnum, TOBPTD);
  a = (struct des_tob *) xmalloc (size);
  *(desnseg.tobtab + *n) = (char *) a;
  a->prdt.prob = type;
  a->prdt.prsort = NSORT;
  desext = getext (&pn);
  desext->freecntr--;
  a->firstpn = pn;
  a->lastpn = pn;
  a->osctob = 0;
  asp = getnew (pg, NRSNUM, pn);
  l = (struct listtob *) asp;
  l->prevpn = (u2_t) ~ 0;
  l->nextpn = (u2_t) ~ 0;
  b = (u2_t *) (asp + sizeof (struct listtob));
  if (type == FLTR)
    {
      *b = phfsize;
      a->free_sz = BD_PAGESIZE - phfsize;
    }
  else
    {
      a->free_sz = BD_PAGESIZE - phtrsize;
      *b++ = 0;
      *b = 0;
    }
  return (a);
}

static
struct des_exns *
ludext (u2_t pn)
{
  struct des_exns *desext;
  u2_t mext, n;

  pn = pn / EXNSSIZE * EXNSSIZE;
  mext = desnseg.mexnum;
  desext = desnseg.dextab;
  for (n = 0; n < mext; desext++, n++)
    if ( desext->efpn == pn )
      return (desext); 
  return (NULL);
}

static
void
freeext (struct des_exns *desext)
{
  desext->freecntr++;
  if (desext->freecntr == EXNSSIZE)
    {
      ADMT_putext (&desext->efpn, 1);
      desext->efpn = (u2_t) ~ 0;
    }
}

int
deltob (struct id_ob *pidtob)
{
  struct des_tob *dt, *des_tob;
  struct des_exns *desext;
  char **a, *asp;
  u2_t sn, pn, fpn, num_tob, n;
  struct A pg;

  sn = pidtob->segnum;
  if (sn != NRSNUM)
    return (NIOB);
  a = desnseg.tobtab + pidtob->obnum;
  dt = (struct des_tob *) * a;
  fpn = dt->firstpn;
  num_tob = desnseg.mtobnum; 
  for (n = 0; n < num_tob; n++)
    {
      des_tob = (struct des_tob *) *(desnseg.tobtab + n);
      if (des_tob != NULL && dt != des_tob)
	if (fpn == des_tob->firstpn) goto m1;
    }
  for (pn = fpn; pn != (u2_t) ~ 0;)
    {
      desext = ludext (pn);
      if (desext == NULL)
	break;
      asp = getwl (&pg, NRSNUM, pn);
      pn = ((struct listtob *) asp)->nextpn;
      putwul (&pg, 'n');
      freeext (desext);
    }
m1:
  delscd (dt->osctob, (char *) dt);
  xfree ((void *) dt);
  *a = NULL;
  return (OK);
}

int
instr (struct des_tob *dt, char *cort, u2_t corsize)
{
  u2_t pn;
  char *asp;
  struct A pg;

  pn = dt->lastpn;
  asp = getwl (&pg, NRSNUM, pn);
  minstr (&pg, cort, corsize, dt);
  putwul (&pg, 'm');
  dt->prdt.prsort = NSORT;
  return (OK);
}

void
minstr (struct A *pg, char *cort, u2_t corsize, struct des_tob *dt)
{
  char *a;

  a = getloc (pg, corsize, dt);
  bcopy (cort, a, corsize);
}

char *
getloc (struct A *pg, u2_t corsize, struct des_tob *dt)
{
  u2_t *ai, off;
  struct p_h_tr *phtr;
  char *asptr;
  
  if (dt->free_sz < corsize + size2b)
    {
      asptr = getptob (pg, dt);
      phtr = (struct p_h_tr *) asptr;
      phtr->linptr = 0;
      off = BD_PAGESIZE - corsize;
      dt->free_sz = BD_PAGESIZE - phtrsize;
    }
  else if (dt->free_sz == BD_PAGESIZE - phtrsize)
    {
      asptr = pg->p_shm;
      phtr = (struct p_h_tr *) asptr;
      phtr->linptr = 0;
      off = BD_PAGESIZE - corsize;
    }
  else
    {
      asptr = pg->p_shm;
      phtr = (struct p_h_tr *) asptr;
      off = *((u2_t *) (asptr + phtrsize) + phtr->linptr) - corsize;
      phtr->linptr += 1;
    }
  if (corsize != 0)
    {
      ai = (u2_t *) (phtr + 1) + phtr->linptr;
      *ai = off;
      dt->free_sz -= corsize + size2b;
    }
  return (off + asptr);
}

char *
getptob (struct A *pg, struct des_tob *destob)
{
  char *asp;
  u2_t pn, oldpn, *b;
  struct des_exns *desext;
  struct listtob *lsttob;
  i4_t i = 0;
  
  oldpn = destob->lastpn;
  if (destob->prdt.prsort == SORT)
    {
      desext = getext (&pn);
    }
  else
    {
      u2_t cpn;
      desext = ludext (oldpn);
      if ((pn = desext->funpn) != (u2_t) ~ 0)
	{
	  cpn = pn + 1;
	  if (cpn == desext->efpn + EXNSSIZE)
	    desext->funpn = (u2_t) ~ 0;
	  else
	    desext->funpn = cpn;
	}
      else
	{
	  if ((pn = desext->ldfpn) != (u2_t) ~ 0)
	    i = 1;
	  else
	    {
	      desext = desnseg.dextab + desnseg.lexnum;
	      if ((pn = desext->funpn) != (u2_t) ~ 0)
		{
		  cpn = pn + 1;
		  if (cpn == desext->efpn + EXNSSIZE)
		    desext->funpn = (u2_t) ~ 0;
		  else
		    desext->funpn = cpn;
		}
	      else
		{
		  if ((pn = desext->ldfpn) != (u2_t) ~ 0)
		    i = 1;
		  else
		    desext = getext (&pn);
		}
	    }
	}
    }
  asp = pg->p_shm;
  lsttob = (struct listtob *) asp;
  lsttob->nextpn = pn;
  putwul (pg, 'm');
  asp = getnew (pg, NRSNUM, pn);
  lsttob = (struct listtob *) asp;
  if (i != 0)
    desext->ldfpn = lsttob->prevpn;
  lsttob->nextpn = (u2_t) ~ 0;
  lsttob->prevpn = oldpn;
  b = (u2_t *) (asp + sizeof (struct listtob));
  if (destob->prdt.prob == FLTR)
    {
      *b = phfsize;
      destob->free_sz = BD_PAGESIZE - phfsize;
    }
  else
    {
      destob->free_sz = BD_PAGESIZE - phtrsize;
      *b++ = 0;
      *b = 0;
    }
  desext->freecntr--;
  destob->lastpn = pn;
  return (asp);
}

void
deltr (struct d_mesc *scpr, char *asp, u2_t * ai, struct des_tob *destob, u2_t pn)
{
  u2_t *afi;
  
  afi = (u2_t *) (asp + phtrsize);
  comptr (asp, ai, calsc (afi, ai));
  *ai = 0;
  if (frptr (asp) == 1)
    frptob (destob, asp, pn);
  scpr->prcrt = 0;
  destob->prdt.prsort = NSORT;
}

int
frptr (char *asp)
{
  u2_t *ali, *afi;

  afi = (u2_t *) (asp + phtrsize);
  ali = afi + ((struct p_h_tr *) asp)->linptr;
  for (; afi <= ali; afi++)
    if (*afi != 0)
      return (0);
  return (1);
}

void
comptr (char *asp, u2_t * ai, u2_t size)
{
  u2_t *ali, *afi;
  char *a, *b, *c;

  afi = (u2_t *) (asp + phtrsize);
  ali = afi + ((struct p_h_tr *) asp)->linptr;
  for (; ai <= ali; ai++)
    if (*ai != 0)
      *ai += size;
  for (a = asp + *ai - 1, b = a - size, c = asp + *ali; a <= c;)
    *a-- = *b--;
}

static
void
corltob (u2_t pn, u2_t type, u2_t newpn)
{
  char *asp;
  struct A pg;
  
  asp = getwl (&pg, NRSNUM, pn);
  if (type == 1)
    ((struct listtob *) asp)->prevpn = newpn;
  else
    ((struct listtob *) asp)->nextpn = newpn;
  putwul (&pg, 'm');
}

void
frptob (struct des_tob *destob, char *asp, u2_t pn)
{
  struct listtob *phtob;
  struct des_exns *desext;
  u2_t npn, ppn;

  phtob = (struct listtob *) asp;
  npn = phtob->nextpn;
  phtob->nextpn = (u2_t) ~ 0;
  ppn = phtob->prevpn;
  phtob->prevpn = (u2_t) ~ 0;
  desext = ludext (pn);
  if (desext != NULL)
    {
      *(u2_t *) asp = desext->ldfpn;
      desext->ldfpn = pn;
      if (pn == destob->firstpn)
	{
	  if (pn != destob->lastpn)
	    {
	      destob->firstpn = npn;
	      corltob (npn, 1, 0);
	    }
	}
      else
	{
	  if (pn == destob->lastpn)
	    {
	      destob->lastpn = ppn;
	      corltob (ppn, 2, 0);
	    }
	  else
	    {
	      corltob (ppn, 2, npn);
	      corltob (npn, 1, ppn);
	    }
	}
      freeext (desext);
    }
}  

struct ans_ctob
trsort (struct id_rel *pidrel, u2_t kn, u2_t * mfn, char *drctn, char prdbl)
{
  struct des_tob *dt, *dtnew;
  struct des_trel *destrel;
  u2_t *a, *b, fn, fdf, size;
  i2_t n;
  struct des_field *adf;
  u2_t fpn, lpn;
  struct ans_ctob ans;

  if (pidrel->urn.segnum != NRSNUM)
    {
      ans.cpncob = NIOB;
      return (ans);
    }
  dt = (struct des_tob *) * (desnseg.tobtab + pidrel->urn.obnum);
  if (dt->prdt.prob != TREL)
    {
      ans.cpncob = NDR;
      return (ans);
    }
  fpn = dt->firstpn;
  destrel = (struct des_trel *) dt;
  fn = destrel->fieldn;
  fdf = destrel->fdftr;
  adf = (struct des_field *) (destrel + 1);
  srtr_trsort (&fpn, adf, fn, fdf, mfn, kn, prdbl, drctn, &lpn);
  n = lunt (&desnseg.tobtab, &desnseg.mtobnum, TOBPTD);
  size = dtrsize + fn * rfsize;
  dtnew = (struct des_tob *) xmalloc (size + kn * size2b);
  *(desnseg.tobtab + n) = (char *) dtnew;
  bcopy ((char *) dt, (char *) dtnew, size);
  ((struct des_trel *) dtnew)->keysntr = kn;
  for (a = mfn, b = (u2_t *) ((char *)dtnew + size); kn != 0; kn--)
    *b++ = *a++;
  dtnew->prdt.prob = TREL;
  dtnew->prdt.prsort = SORT;
  dtnew->prdt.prdbl = prdbl;
  dtnew->prdt.prdrctn = *drctn;
  dtnew->osctob = 0;
  dtnew->firstpn = fpn;
  dtnew->lastpn = lpn;
  
  ans.cpncob = OK;
  ans.idob.segnum = NRSNUM;
  ans.idob.obnum = n;
  return (ans);
}
struct ans_ctob
flsort (struct id_ob *pidtob, u2_t kn, u2_t *mfn, char *drctn, char prdbl)
{
  struct des_tob *dt, *dtnew;
  struct des_fltr *desfltr;
  struct d_r_bd *drbd;
  u2_t *a, *b, sn, fn, fdfn, size;
  i2_t n;
  u2_t fpn, lpn;
  struct des_field *adf;
  struct ans_ctob ans;

  if (pidtob->segnum != NRSNUM)
    {
      ans.cpncob = NIOB;
      return (ans);
    }
  dt = (struct des_tob *) * (desnseg.tobtab + pidtob->obnum);
  if (dt->prdt.prob != FLTR)
    {
      ans.cpncob = NIOB;
      return (ans);
    }
  fpn = dt->firstpn;
  desfltr = (struct des_fltr *) dt;
  sn = desfltr->pdrtf->segnr;
  drbd = &desfltr->pdrtf->desrbd;
  fn = drbd->fieldnum;
  fdfn = drbd->fdfnum;
  adf = (struct des_field *) ((char *) drbd + drbdsize);
  srtr_flsort (sn, &fpn, adf, fn, fdfn, mfn, kn, prdbl, drctn, &lpn);
  n = lunt (&desnseg.tobtab, &desnseg.mtobnum, TOBPTD);
  size = dflsize + desfltr->selszfl;
  dtnew = (struct des_tob *) xmalloc (size + kn * size2b);
  *(desnseg.tobtab + n) = (char *) dtnew;
  bcopy ((char *) dt, (char *) dtnew, size);
  ((struct des_fltr *) dtnew)->keysnfl = kn;
  for (a = mfn, b = (u2_t *) ((char *)dtnew + size); kn != 0; kn--)
    *b++ = *a++;
  dtnew->prdt.prsort = SORT;
  if (prdbl == 'd')
    dtnew->prdt.prdbl = NODBL;
  else
    dtnew->prdt.prdbl = DBL;
  if (*drctn == 'g')
    dtnew->prdt.prdrctn = GROW;
  else
    dtnew->prdt.prdrctn = DECR;
  dtnew->osctob = 0;
  dtnew->firstpn = fpn;
  dtnew->lastpn = lpn;
  ans.cpncob = OK;
  ans.idob.segnum = NRSNUM;
  ans.idob.obnum = n;
  return (ans);
}

