Oramon README
Version 2.10 beta
Copyright (c) 1999-2000, Vermeer Corporation
All Rights Reserved. Patents Pending.


TABLE OF CONTENTS
-----------------

1.  License Information
2.  System requirements
3.  What is Oramon ?
4.  How do I install Oramon ?
5.  Contact


1. License information
======================

Oramon
Oracle database Monitor
Copyright (C) 1999-2000, by Raymond Vermeer.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.



2. System requirements
======================

All you need is the following :

- telnet session to a unix host
- screen width minimum 80 characters
- ksh
- sqlplus
- sqlnet
- ops$-user with DBA role granted to



3. What is Oramon ?
===================

Oramon is a simple oracle database monitor.
It doesn't need any sophisticated runtime enviroment.
It just need an Unix box and Oracle installed on it.

Below you see the syntax :

oramon 2.1 beta by Raymond Vermeer

Usage: oramon [ses cpu|disk      [interval count records]]
       oramon [usr sid statistic [interval count records]]
       oramon [sql sid           [interval count records]]
       oramon [tbs               [interval count records]]
       oramon [dbf               [interval count records]]
       oramon [fio nodelta|delta [interval count records]]
       oramon [rbs               [interval count records]]


       ses = session information
       usr = user information
       sql = user sql information
       tbs = tablespace information
       dbf = datafile information
       fio = datafile io information
       rbs = rollback information


       default => oramon 5 99999999999999 20 ses disk


4.  How do I install Oramon ?
=============================

FTP all files in ASCII mode to your Unix host.
Put them in one directory.
Place the x-bit for the user executing the oramon shell-script.
=>chmod u+x oramon

Set your Oracle environment
=>ORACLE_SID=<dbname> . oraenv

Start the monitor 
=>oramon

For syntax of oramon
=>oramon -h



5. Contact
==============================

Questions, remarks and bugs can be send to :

r.vermeer@zonnet.nl


Have fun,
Raymond Vermeer