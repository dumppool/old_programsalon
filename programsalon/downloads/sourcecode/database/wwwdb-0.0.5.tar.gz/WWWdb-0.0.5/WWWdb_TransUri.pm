#!/usr/bin/perl
# -----------------------------------------------------------------------------
# TWC
# Treuwert-Computer GmbH
# Schlo�bergring 9
# 79098 Freiburg
#
# -----------------------------------------------------------------------------
# Program-Data
# -----------------------------------------------------------------------------
# Project  :
# System   :
# Program  :
# Modul    : $RCSfile: WWWdb_TransUri.pm,v $
# Version  : $Revision: 1.7 $
# Date     : $Date: 1999/12/21 17:55:41 $
# State    : $State: Exp $
#
# Description:
#   This module maps adresses of the form
#   http://myhost/wwwdb/<Database>/<config-file>
#   to the real call of WWWDb
#
# -----------------------------------------------------------------------------
# $Log: WWWdb_TransUri.pm,v $
# Revision 1.7  1999/12/21 17:55:41  klaus
# New features of WWWdb-0.0.5:
#      System:
#          New General form layout (FormHeader, Navigation, TableHeader, Application-area,
#          TableFooter, FormFooter)
#          New Plugin: PreDoAction
#          New Plugins: FormHeader, TableHeader, TableFooter, FormFooter
#          Navigation through hierarchy
#          Navigation through search-words
#          Default-session-id is now 0000000000000000
#          File-hierarchy of configfiles is now possible: x/y/z => x:y:z
#          Passing parameters via URL in the form URL;Param=Value
#          New config-entries for simple field checking / converting: Mandantory, MustMatch,ToUpper, ToLower
#          The navigation column is generated from database
#          Query-fields can be attributed
#          Different ways to select a record in the browse: Btn, Check, None (implies selection via link)
#          Vertical alignment of single entries
#          Generate WWWdb-References in Labels
#     API:
#          ResolveRefField - Resolve a WWWdb-Reference for HTML
#          InternalFieldCheck - perform the default-checks for a field
#          Get-Attr - Get WWWdb Attributes
#          ConfigPath - the file-path of the config-file
#          UrlParams - the params passed by the URL
#          GetLastBtn - -deleted-
#     Applications:
#          Navigation in wwwdb via hierarchy or search-words
#          Edit navigation-categories
#          Edit navigation-objects
#          Link category and object
#          Edit docu-entries
#
# Revision 1.6  1999/12/06 10:44:27  klaus
# - implemented file-hierarchy
#
# Revision 1.5  1999/12/02 15:19:02  klaus
#  - New General Table-Layout
#  - If config-file is missing, we take Empty.rc
#  - New Plugins:
#    + PreDoAction
#    + FormHeader, TableHeader, TableFooter, FormFooter
#  - Generated menu-structure (from database)
#  - Different way to select records in Qry-Mode
#  - Default session-id is now 0000000000000000
#  - a : in url generates a file hierarchy (x:y:z => x/y/z)
#  - pass params via the url in the form url;param=value[;paramn=valuen]
#  - API-function GetLastBtn deleted
#
# Revision 1.4  1999/11/02 12:01:58  klaus
# Check-in to store actual state
#
# Revision 1.3  1999/10/06 08:42:13  klaus
# Checkpoint before copying to WWW-server
#
#
# --- FIX ----- FIX ----- FIX -----FIX ----- FIX ----- FIX -------------------

package Apache::WWWdb_TransUri;

use strict;
use Apache::Constants qw(:common);

use constant APACHE_BASE_PATH => "/usr/local/httpd/";

# --- This Routine gets linked into the Apache-Server -----------------------
sub handler
{
   my $hReqObj = shift;

   my $cOrigUri = $hReqObj->uri;

   my $cApplication;
   my $cDatabase;
   my $cJunk;
   my $cNewUri;
   my $cParam;
   my $cSessionId;
   my $cWWWdb;
   my @lRest;



   my @quick_and_dirty;

   open TMP, ">>/tmp/TransUri.log";
   print TMP "URI: $cOrigUri\n";
   # print TMP "CONTENT: " . $hReqObj->content() . "\n";

   # @quick_and_dirty = $hReqObj->headers_in();
   # print TMP "HEADERS_IN: @quick_and_dirty\n";



   ($cJunk, $cWWWdb, @lRest) = split '/', $cOrigUri;

   unless ($cWWWdb =~ /^wwwdb(_devel)?$/)
   {
      return DECLINED;
   }

   $cWWWdb =~ s/www/WWW/;

   $cNewUri = "/cgi-bin/$cWWWdb.cgi";

   # Look, if we have a session-id
   if ($lRest[0] =~ /^[0-9a-h]{16}$/)
   {
      $cSessionId = shift @lRest;
   }
   else
   {
      $cSessionId = "0000000000000000";
   }

   $hReqObj->subprocess_env('WWWDB_SESSION_ID' => $cSessionId);

   $cDatabase    = (@lRest)? shift @lRest: 'Default';
   $cApplication = (@lRest)? shift @lRest: 'WWWdb/Index';
   $cParam       = "";

   # Generate a directory-path
   $cApplication =~ s.:./.g;

   $hReqObj->subprocess_env('WWWDB_BASE_PATH'   => (APACHE_BASE_PATH .
                                                    "htdocs/$cWWWdb"));
   $hReqObj->subprocess_env('WWWDB_DATABASE'    => $cDatabase);


   if ($cApplication =~ /([^;]*)(;(.*))/)
   {
      $cApplication = $1;
      $cParam       = $3;
   }

   $hReqObj->subprocess_env('WWWDB_CONFIG_FILE' => $cApplication);
   $hReqObj->subprocess_env('WWWDB_PARAMS'      => $cParam);


   # here we have anything else (graphics, etc.)
   if (@lRest)
   {
        $cNewUri = join  "/", APACHE_BASE_PATH . "htdocs/$cWWWdb", @lRest;
   }

   print TMP ("New URI: $cNewUri Path:htdocs/$cWWWdb, Db:$cDatabase, App:$cApplication, ID:$cSessionId\n");

   $hReqObj->uri($cNewUri);

   close TMP;

   return DECLINED;
}

1;

__END__











