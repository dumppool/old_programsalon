# Generates Errors, when syntax is invalid
system("perl -cw WWWdb.cgi");
system("perl -cw WWWdb_TransUri.pm");
system("perl -T WWWdb.cgi");
system("perl -T WWWdb_TransUri.pm");

