sub Check_dummypassword_username ()
{
   my $cSqlStmt;
   my @lSqlData;

   &AddError("username", "No username, please enter!!")
       if(!&GetField("username"));

   $cSqlStmt = sprintf("SELECT 1
		        FROM wwwdb_state
                        WHERE
                           key       =    'login' and
                           key_value LIKE '%s,%%'",
                       &GetField("username"));

   @lSqlData = &SQLSelectList($cSqlStmt);

   &AddError("username",
             "Sorry, that username already exists, please re-enter!!")
       if (@lSqlData);

}

sub Check_dummypassword_password1 ()
{
   if(&GetField("password1") ne &GetField("password2"))
   {
      &AddError("password1", "Difference in passwords, please re-enter!!");
      &SetField("password1", "");
      &SetField("password2", "");
   }
}



sub MyBtnNew()
{

   if(!&GetAttr("RecordOk"))
   {
      &GenPage();
   }
   else
   {
      my $cSessionId;
      my $cUsername;

      $cSessionId = &SessionIdGenerate();
      $cUsername = &GetField("username");

      &SQLDo(sprintf ("INSERT INTO wwwdb_state
                           (session_id, key, key_value)
                         VALUES
                           ('%s', 'login', '%s')",
                      $cSessionId,
                      $cUsername . "," .
                      crypt(&GetField("password1"), "WW")));

      &SetField("username", "");
      &SetField("password1", "");
      &SetField("password2", "");

      &OkForm("Information",
              i18n(sprintf("WWWdb-User '%s' created",
                           $cUsername)));


   }
}

sub xxx ()
{

   {
      &SQLDo(sprintf ("DELETE FROM wwwdb_state WHERE
                          session_id = '%s' AND
                          key        = 'ActualLogin'",
                      $lSqlData[0]));


      &SQLDo(sprintf ("INSERT INTO wwwdb_state
                           (session_id, key, key_value)
                         VALUES
                           ('%s', 'ActualLogin', '%s')",
                      $lSqlData[0],
                      scalar(localtime())));

      &Redirect($lSqlData[0], "WWWdb:Demo:Menu");
   }

}

1;

