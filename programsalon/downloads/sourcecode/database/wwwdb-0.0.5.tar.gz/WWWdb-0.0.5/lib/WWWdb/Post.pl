
# this call (FirstColumn) overrides the WWWdb-Link-Box
sub FirstColumn_X
{
   return " ";
}
