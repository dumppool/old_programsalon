#!/usr/bin/perl


sub PreCreateForm ()
{
   if(&SessionIdGetState("ActualLogin"))
   {
      &Redirect(&GetAttr("SessionId"), "WWWdb:Tools:ShowDoc;id_doc=25");
   }
   else
   {
      &Redirect(&GetAttr("SessionId"), "WWWdb:System:Login");
   }
}

1;



