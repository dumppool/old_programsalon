
sub PreCreateForm ()
{
   my $cRecord;
   my $pDbHdl;
   my $pStmtHdl;
   my @lResult = ();


   if(&GetLastBtn() ne "BtnNext")
   {

      &SetField("DbDriver",
                &SessionIdGetState("CreateDbRc_1,DbDriver"));
      &SetField("Database",
                &SessionIdGetState("CreateDbRc_2,Database"));
      &SetField("User",
                &SessionIdGetState("CreateDbRc_2,User"));
      &SetField("Password",
                &SessionIdGetState("CreateDbRc_2,Password"));
   }

   $pDbHdl = DBI->connect("dbi:Pg(RaiseError=>0, PrintError=>0, AutoCommit=>1)" .
                          ":dbname=template1", "", "");

   $pStmtHdl = $pDbHdl->prepare("SELECT datname
                                 FROM pg_database
                                 WHERE datname != 'template1'");
   $pStmtHdl->execute();

   while ($cRecord = join ",", $pStmtHdl->fetchrow_array)
   {
      push @lResult, $cRecord;
   }

   &MySetVal("Layout Field Database", "Values", @lResult);

   $pStmtHdl->finish();
   $pDbHdl->disconnect();
}


sub Check_DbRc_DbDriver()
{
   &AddError("Database", "Please select a database")
       if(!&GetField("Database"));
}



sub MyBtnNext ()
{
   &CheckRecord();

   if(!&GetField("Database"))
   {
      &GenPage();
   }
   else
   {
      &SessionIdSaveState("CreateDbRc_2,Database", &GetField("Database"));
      &SessionIdSaveState("CreateDbRc_2,User",     &GetField("User"));
      &SessionIdSaveState("CreateDbRc_2,Password", &GetField("Password"));

      print &Redirect(&GetAttr("SessionId"), "WWWdb:Wiz:CreateDbRc_3");
   }
}


sub MyBtnPrev ()
{
   print &Redirect(&GetAttr("SessionId"), "WWWdb:Wiz:CreateDbRc_1");
}

1;
