
sub PreDoAction ()
{
   my $cUrlParams = &GetAttr("UrlParams");
   my $cLastBtn   = &GetAttr("LastBtn");
   my @lUrlParams = split ";", $cUrlParams;
   my $iCat       = &GetField("id_category");

   &MySetVal("DB", "IdField", "DISTINCT link");


   # the url-param overloads the value of the form
   foreach (@lUrlParams)
   {

      $iCat = $1
          if (/^cat=(\d+)/);
   }

   if ($iCat)
   {
      &SetField("id_category", $iCat);
   }
   else
   {
      &SetField("id_category", 1)
          if !&GetField("id_category");
   }

   &MyParam('$valuesplit', "[ \t]");
   &MyParam('$valueconj', "or");

   # &SetField("search_cond", &MyParam('$valueconj'));
}



sub PreCreateForm ()
{
   my $cList;
   my @lHistory;
   my $iCategory;
   my $cLastBtn   = &GetAttr("LastBtn");

   $iCategory = &GetField("id_category");


   # Generate a path upwards
   $cList = "";

   # get category-info
   $cEntry = (&SQLSelectList
              (sprintf("SELECT
                          id_category,
                          id_cat_of_cat,
                          name,
                          id_chain,
                          name_chain,
                          sort_nr,
                          attribs
                        FROM
                          wwwdb_category
                        WHERE
                          id_category = %d
                        ORDER BY
                          sort_nr",
                       $iCategory)))[0];

   @lFields = split /\\,/, $cEntry;

   @lIdChain = split /,/, $lFields[3];
   @lIdNames = split /,/, $lFields[4];


   # generate the access-path with the corresponding links
   for ($iInd = @lIdChain - 1; $iInd >= 0; $iInd--)
   {

      $cResult = &ResolveRefField(sprintf("wwwdb://%s;cat=%s",
                                          &GetAttr("ConfigFile"),
                                          $lIdChain[$iInd]),
                                  $lIdNames[$iInd]);

      $cList = $cResult . " / " . $cList;

   }

   # Add a trailing / and remove the last /
   $cList = ("/ " .
             &ResolveRefField("wwwdb://" . &GetAttr("ConfigFile"),
                              i18n("Top")) .
             " / " .
             $cList);

   # remove trailing /
   $cList =~ s: / $::;

   &MySetVal("Layout Label hier", "Text", "$cList");


   # get sub-categories
   $cList = &HtmlListFromSelect
       (sprintf("SELECT
                   'Cat',
                   id_category,
                   description,
                   nr_of_subcats,
                   nr_of_objs,
                   sort_nr,
                   attribs
                 FROM
                   wwwdb_nav_in_cat
                 WHERE
                   id_cat_of_cat = %d
                 ORDER BY
                   sort_nr",
                &GetField("id_category")));

   # Show list or disable label
   if ($cList)
   {
      &MySetVal("Layout Label subcat1", "Text", "$cList");
   }
   else
   {
     &MySetVal("Layout Label subcat", "Text", " ");
   }


   # get related categories
   $cList = &HtmlListFromSelect
       (sprintf("SELECT
                   'Cat',
                   id_category,
                   description,
                   nr_of_subcats,
                   nr_of_objs,
                   sort_nr,
                   attribs
                 FROM
                   wwwdb_get_cat_of_cat
                 WHERE
                   id_cat_of_cat = %d
                 ORDER BY
                   sort_nr",
                &GetField("id_category")));

   # Show list or disable label
   if ($cList)
   {
      &MySetVal("Layout Label see_also1", "Text", "$cList");
   }
   else
   {
      &MySetVal("Layout Label see_also", "Text", " ");
   }


   # get the objects of this category
   $cList = &HtmlListFromSelect
       (sprintf("SELECT
                   'Obj',
                   link,
                   descript,
                   sort_nr,
                   attribs
                 FROM
                   wwwdb_get_obj_of_cat
                 WHERE
                   id_category = %d
                 ORDER BY
                   sort_nr",
                &GetField("id_category")));

   # Show list or disable label
   if ($cList)
   {
      &MySetVal("Layout Label objects1", "Text", "$cList");
   }
   else
   {
      &MySetVal("Layout Label objects", "Text", " ");
   }

}




sub HtmlListFromSelect($)
{
   my $cSqlStmt = shift;

   my @lRecord;
   my $iNrOfEntries = 0;

   # &nbsp; prevents <UL> to be seen as "< UL" from DBIx::Recordset
   my $cResult = "&nbsp;<UL>";

   @lRecord = &SQLSelectList($cSqlStmt);

   foreach (@lRecord)
   {
      my $lFields;

      @lFields = split /\\,/;


      if ($lFields[0] eq "Cat")
      {
         next
             if(!&IsAttribOK($lFields[6]));

         # categories and/or objects
         if($lFields[3] + $lFields[4])
         {
            my $cNrOfChilds;

            # categories, but no objects
            if ($lFields[3] and !$lFields[4])
            {
               $cNrOfChilds = sprintf(" (<B>%d</B>)",
                                      $lFields[3]);
            }
            # no categories, but objects
            elsif (!$lFields[3] and $lFields[4])
            {
               $cNrOfChilds = sprintf(" (%d)",
                                      $lFields[4]);
            }
            # both
            else
            {
               $cNrOfChilds = sprintf(" (<B>%d</B>/%d)",
                                      $lFields[3],
                                      $lFields[4]);
            }

            $cResult .= li(&ResolveRefField(sprintf("wwwdb://%s;cat=%s",
                                                    &GetAttr("ConfigFile"),
                                                    $lFields[1]),
                                            $lFields[2]) . $cNrOfChilds);
         }
      }
      elsif($lFields[0] eq "Obj")
      {

         next
             if(!&IsAttribOK($lFields[4]));

         # if there's only one wwwdb-object, jump directly to it
         if ((@lRecord == 1) and
             ($lFields[1] =~ "^wwwdb://(.*)\$")) {

            &Redirect(&GetAttr("SessionId"), $1);
         }
         else {
            $cResult .= li(&ResolveRefField($lFields[1], $lFields[2]));
         }


      }
      else
      {
         $cResult .= li($_);
      }

      $cResult .= "\n";

      $iNrOfEntries ++;
   }

   if(!$iNrOfEntries)
   {
      $cResult = "";
   }
   else
   {
      $cResult .= "</UL>";
   }

   return $cResult;

}



sub PreBtnQry ()
{

   # &MyParam('$valueconj', &GetField("search_cond"))
   #     if &GetField("search_cond");

   &SetField("sword",
             lc(&GetField("sword")));

}

sub XMyFirstColumn()
{
   return "&nbsp;";
}

1;


