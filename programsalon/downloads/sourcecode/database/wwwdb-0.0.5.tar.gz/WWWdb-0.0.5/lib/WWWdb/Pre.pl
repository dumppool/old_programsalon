
sub MyFormHeader ($)
{
   my $cTitlePI = shift;

   # &TableHeader($cTitlePI);

}

sub MyFormFooter ($)
{
   my $cTitlePI = shift;

   # &TableFooter($cTitlePI);


}

sub XTableHeader ($)
{
   my $cTitlePI = shift;

}


sub TWCMyTableFooter ($)
{
   my $cTitlePI = shift;

   print <<EOF;
<HR>
<TABLE  BORDER=0 HEIGHT="100%" WIDTH="100%"  CELLPADDING=1 CELLSPACING=1>
<TR>

<TD ALIGN=Center><B><SMALL>TREUWERT
<BR>
COMPUTER GmbH</SMALL></B></TD>

<TD ALIGN=Center><B><SMALL>Schlo&szlig;bergring 9
<BR>
79098 Freiburg</SMALL></B></TD>

<TD><SMALL>EMail: </SMALL>
<SMALL><A HREF="mailto:Vertrieb\@twc.de">Vertrieb\@twc.de</A></SMALL>
<SMALL><BR>WWW: </SMALL>
<SMALL><A HREF="http://www.twc.de">http://www.twc.de</A></SMALL></TD>

<TD><SMALL>Fon: +49 (761) 38 707 - 0
<BR>
Fax: +49 (761) 23 422</SMALL></TD>
</TR>
</TABLE>
EOF


}
