# defined Plugins:
#
# --- Things, to do, before WWWdb does any Action
# PreDoAction()
#
# --- Check-Routine for every field of the Table <Table>
# Check_<Table>_EveryField()
#
# --- Check-Routine for field <Field> of the Table <Table>
# Check_<Table>_<Field>()
#
# --- Conversion for fieldtype <FieldType> of db <Db> coming from form
# <Db>_<FieldType>_Form2Db()
#
# --- Conversion for fieldtype <FieldType> of db <Db> coming from db
# <Db>_<FieldType>_Db2Form()
#
# --- Do action for Button <Btn>
# (Pre|Post|My)Btn<Btn>()
#
# --- Set up the navigation-column on the left side
# (Pre|Post|My)FirstColumn()
#
# --- Generate the header of the form
# (Pre|Post|My)FormHeader()
#
# --- Generate the header of the table
# (Pre|Post|My)TableHeader($)
#
# --- Generate the footer of the table
# (Pre|Post|My)TableFooter()
#
# --- Generate the footer of the page
# (Pre|Post|My)FormFooter()

# --- Things to do, before the HTML-form will be generated
sub PreCreateForm()
{
   my @lCategories;

#     if (&GetField("link") =~ m|^(.+://)(.+)$|)
#     {
#        &SetField("link_type",  $1);
#        &SetField("link_value", $2);
#     }

   if (&GetField("id_object") and
       &GetField("id_object") < 10000)
   {
      &SetField("id_system",  1);
   }


   @lCategories = &SQLSelectList(sprintf("SELECT id_category
                                          FROM wwwdb_get_cat_of_obj
                                          WHERE id_object = %d",
                                         &GetField("id_object")));

   &SetField("cat", join "\\,", @lCategories);


   @lSWords = &SQLSelectList(sprintf("SELECT sword
                                      FROM   wwwdb_get_swd_of_obj
                                      WHERE  id_object = %d",
                                     &GetField("id_object")));

   &SetField("swords", join " ", @lSWords);

}


# --- Check-Routine for the Table after all single-checks
sub Check_wwwdb_object()
{

   foreach ("cat", "swords")
   {
      &InternalFieldCheck($_);
   }

#     &SetField("link",
#               (&GetField("link_type") .
#                &GetField("link_value")));

}



sub PreBtnNew()
{
   my $iMaxCatId;

   # generate a new object-id
   $iMaxObjId = (&SQLSelectList(sprintf
                                ("SELECT MAX(id_object)
                                  FROM   wwwdb_object
                                  WHERE  %s",
                                 &GetField("id_system")?
                                 "id_object < 10000":
                                 "id_object >= 10000")))[0];

   &SetField("id_object", ($iMaxObjId?
                           $iMaxObjId + 1:
                           (&GetField("id_system")?
                            1 : 10000)));


}



sub PostBtnNew()
{
   &UpdateObjRelations("New")
       if &GetAttr("RecordOk");
}


sub PostBtnUpd()
{

   &UpdateObjRelations("Upd")
       if &GetAttr("RecordOk");

}


sub PostBtnDel()
{

   &UpdateObjRelations("Del");

}



sub UpdateObjRelations($)
{
   my $cUpdTypePI = shift;

   my $iIdObject = &GetField("id_object");

   assert ($iIdObject)
       if DEBUG;

   # Delete all links of this object to category and sword
   if($cUpdTypePI eq "Upd" or $cUpdTypePI eq "Del")
   {
      &SQLDo(sprintf("DELETE FROM wwwdb_obj_cat
                        WHERE id_object = %d",
                     $iIdObject));

      &SQLDo(sprintf("DELETE FROM wwwdb_obj_swd
                        WHERE id_object = %d",
                     $iIdObject));
   }

   if($cUpdTypePI eq "Upd" or $cUpdTypePI eq "New")
   {

      # Connect object to categories
      foreach $iIdCat (split /\\,/, &GetField("cat"))
      {
         &SQLDo(sprintf("INSERT INTO wwwdb_obj_cat
                            (id_object, id_category)
                          VALUES
                            (%d, %d)",
                        $iIdObject,
                        $iIdCat));


      }

      # now handle every sword
      foreach $cSword (split " ", &GetField("swords"))
      {
         my $iIdSword;
         my $iMaxIdSword;

         $iIdSword = (&SQLSelectList(sprintf("SELECT id_sword
                                              FROM wwwdb_sword
                                              WHERE  sword = '%s'",
                                             lc($cSword))))[0];

         # if this sword does not exist, insert it
         unless ($iIdSword)
         {
            $iMaxIdSword = (&SQLSelectList
                            ("SELECT MAX(id_sword) FROM wwwdb_sword"))[0];
            $iMaxIdSword ++;

            &SQLDo(sprintf("INSERT INTO wwwdb_sword
                              (id_sword, sword)
                            VALUES
                              (%d, '%s')",
                           $iMaxIdSword,
                           lc($cSword)));

            $iIdSword = $iMaxIdSword;
         }

         &SQLDo(sprintf("INSERT INTO wwwdb_obj_swd
                            (id_object, id_sword)
                          VALUES
                            (%d, %d)",
                        $iIdObject,
                        $iIdSword));
      }
   }
}


sub BtnCat ()
{
   print &Redirect(&GetAttr("SessionId"), "WWWdb:NavCat");
}


1;





