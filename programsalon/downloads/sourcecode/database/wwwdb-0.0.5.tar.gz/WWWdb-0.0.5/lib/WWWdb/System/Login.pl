
sub MyBtnLogin()
{
   my $cSqlStmt;
   my @lSqlData;

   $cSqlStmt = sprintf("SELECT session_id
		        FROM wwwdb_state
                        WHERE
                           key = 'login' and
                           key_value = '%s,%s'",
                       &GetField("username"),
                       crypt(&GetField("password"), "WW"));

   @lSqlData = &SQLSelectList($cSqlStmt);

   unless (@lSqlData)
   {
      &OkForm("ERROR",
              b("Huh!!") .
              "<BR>Not with this password!!!!!");

   }
   else
   {
      &SQLDo(sprintf ("DELETE FROM wwwdb_state WHERE
                          session_id = '%s' AND
                          key        = 'ActualLogin'",
                      $lSqlData[0]));


      &SQLDo(sprintf ("INSERT INTO wwwdb_state
                           (session_id, key, key_value)
                         VALUES
                           ('%s', 'ActualLogin', '%s')",
                      $lSqlData[0],
                      scalar(localtime())));

      &Redirect($lSqlData[0], "WWWdb:Index");
   }

}

1;

