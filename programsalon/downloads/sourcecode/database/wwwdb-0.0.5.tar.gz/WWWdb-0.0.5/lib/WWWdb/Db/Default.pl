#!/usr/bin/perl
# -----------------------------------------------------------------------------
# TWC
# Treuwert-Computer GmbH
# Schlo�bergring 9
# 79098 Freiburg
#
# -----------------------------------------------------------------------------
# Programm-Daten
# -----------------------------------------------------------------------------
# Projekt  :
# System   :
# Programm :
# Modul    : $RCSfile: Pg.pl,v $
# Version  : $Revision: 1.1 $
# Stand von: $Date: 1999/12/02 16:19:20 $
# Status   : $State: Exp $
#
# Kurzbeschreibung:
# Field-conversions for the Pg-Driver
# -----------------------------------------------------------------------------
# Changes
# $Log: Pg.pl,v $
# Revision 1.1  1999/12/02 16:19:20  klaus
# new file-struct
#
# Revision 1.2  1999/12/02 15:19:03  klaus
#  - New General Table-Layout
#  - If config-file is missing, we take Empty.rc
#  - New Plugins:
#    + PreDoAction
#    + FormHeader, TableHeader, TableFooter, FormFooter
#  - Generated menu-structure (from database)
#  - Different way to select records in Qry-Mode
#  - Default session-id is now 0000000000000000
#  - a : in url generates a file hierarchy (x:y:z => x/y/z)
#  - pass params via the url in the form url;param=value[;paramn=valuen]
#  - API-function GetLastBtn deleted
#
# Revision 1.1  1999/11/23 15:38:24  klaus
# New lib-directory
#
# Revision 1.4  1999/11/15 13:52:37  klaus
# - HTML-output buffered
# - WWWdb_(Pre|Post).(rc|pl)
# - own tmp-directory
# - little customizations  for qry-mode
# - enhancement of debug-trace-utilities
# - API: GetAttr()
#
# Revision 1.3  1999/10/22 11:06:06  klaus
# - Corrections of the data-conversion between Db and Html-Form
#
# Revision 1.2  1999/10/21 13:35:05  klaus
# - Select and Radio-Fields can now be filled with SQL
# - WWWdb is now "-w"-proof
# - Database-Errors are now shown uniquely
#
# Revision 1.1  1999/10/20 13:01:34  klaus
# Version 1.0.3
# - Getting field-type-information
# - Plugins to convert DB-data to Form-data and vice versa
# - New API-functions
#    $current_state = GetState();
#    $cust_type = GetFieldTypeName($field_name);
#
# BUGFIX:
# -kfm, lynx and w3m seem to work now
#
#
# ----------------------------------------------------------------------------


# --- Convert datetime-fields from form to db ---------------------------------
sub Pg_date_Form2Db ($)
{
   my $cFieldPI = shift;

   my $cResult;

   # Format is: DD.MM.YYYY
   if ($cFieldPI =~ /(\d+)[.-](\d+)([.-](\d+)?)?/)
   {
      my ($iDay, $iMon, $iYear) =
          ($1, $2, $4);

      if (!$iYear)
      {
         $iYear = (localtime)[5] + 1900;
      }
      elsif($iYear < 100)
      {
         $iCentury = $iYear < 50? 2000: 1900;

         $iYear += $iCentury;
      }

      # Convert to MM-DD-YYYY
      $cResult = sprintf("%02d-%02d-%04d",
                         $iMon,
                         $iDay,
                         $iYear);
   }
   else
   {
      $cResult = "$cFieldPI";
   }

   return $cResult;
}


# --- Convert time-fields from db to form ---------------------------------
sub Pg_date_Db2Form ($)
{
   my $cFieldPI = shift;

   my $cResult;

   # Format is: DD-MM-YYYY
   if ($cFieldPI =~ /(\d+)[.-](\d+)([.-](\d+)?)?/)
   {
      my ($iDay, $iMon, $iYear) =
          ($1, $2, $4);

      if (!$iYear)
      {
         $iYear = (localtime)[5] + 1900;
      }
      elsif($iYear < 100)
      {
         $iCentury = $iYear < 50? 2000: 1900;

         $iYear += $iCentury;
      }

      # Convert to MM.DD.YYYY
      $cResult = sprintf("%02d.%02d.%04d",
                         $iMon,
                         $iDay,
                         $iYear);
   }
   else
   {
      $cResult = "$cFieldPI";
   }

   return $cResult;
}



# --- Convert abstime-fields from form to db ---------------------------------
sub Pg_abstime_Form2Db($)
{
    return &Pg_datetime_Form2Db(shift);
}



# --- Convert abstime-fields from db to form ---------------------------------
sub Pg_abstime_Db2Form($)
{
    return &Pg_datetime_Db2Form(shift);
}



# --- Convert datetime-fields from form to db ---------------------------------
sub Pg_datetime_Form2Db ($)
{
   my $cFieldPI = shift;

   my $cResult;

   # Format is: DD.MM.YYYY hh:mm:ss
   if ($cFieldPI =~ /(\d+)[.](\d+)([.](\d+)?)?(\s+(\d+:\d+(:(\d+))?))?/)
   {
      print MY_LOG "Pg_datetime_Form2Db DATE_FORMAT: $cFieldPI\n";# FIXME

      my ($iDay, $iMon, $iYear, $cTime) =
          ($1, $2, $4, $6);

      if (!$iYear)
      {
         $iYear = (localtime)[5] + 1900;
      }
      elsif($iYear < 100)
      {
         $iCentury = $iYear < 50? 2000: 1900;

         $iYear += $iCentury;
      }

      if (!$cTime)
      {
         $cTime = "00:00:00";
      }

      # Convert to MM-DD-YYYY hh:mm:ss
      $cResult = sprintf("%02d-%02d-%04d %s",
                         $iMon,
                         $iDay,
                         $iYear,
                         $cTime);
   }
   else
   {
      print MY_LOG "Pg_datetime_Form2Db NO DATE_FORMAT: $cFieldPI\n"; # FIXME
      $cResult = "$cFieldPI";
   }

   return $cResult;
}

# --- Convert datetime-fields from db to form ---------------------------------
sub Pg_datetime_Db2Form ($)
{
   my $cFieldPI = shift;

   my $cResult;

   print MY_LOG "Pg_datetime_Db2Form DATE_FORMAT: db->Form $cFieldPI\n";# FIXME

   # Format is: Wed Oct 20 09:22:15 1999 MEST
   if ($cFieldPI =~ /(\w+)\s(\w+)\s(\d+)\s(\d+):(\d+):(\d+)\s(\d+)\s(\w+)/)
   {
      my %hMonths = (Jan => 1,  Feb => 2,  Mar => 3,
                     Apr => 4,  May => 5,  Jun => 6,
                     Jul => 7,  Aug => 8,  Sep => 9,
                     Oct => 10, Nov => 11, Dec => 12);
      my ($iDay, $cMon, $iYear, $iHr, $iMin, $iSec) =
          ($3, $2, $7, $4, $5, $6);

      # convert to DD.MM.YYYY hh:mm:ss
      $cResult = sprintf("%02d.%02d.%04d %02d:%02d:%02d",
                         $iDay,
                         $hMonths{$cMon},
                         $iYear,
                         $iHr,
                         $iMin,
                         $iSec);

   }
   else
   {
      $cResult = "$cFieldPI";
   }

   return $cResult;
}



# --- Convert float4-fields from form to db ---------------------------------
sub Pg_float4_Form2Db ($)
{
   my $cFieldPI = shift;

   my $cResult;

   ($cResult = $cFieldPI) =~ s/,/./g;

   return $cResult;
}


# --- Convert float4-fields from db to form ---------------------------------
sub Pg_float4_Db2Form ($)
{
   my $cFieldPI = shift;

   my $cResult;

   ($cResult = $cFieldPI) =~ s/\./,/g;

   return $cResult;
}



# --- Convert float8-fields from form to db ---------------------------------
sub Pg_float8_Form2Db($)
{
    return &Pg_float4_Form2Db(shift);
}



# --- Convert float8-fields from db to form ---------------------------------
sub Pg_float8_Db2Form($)
{
    return &Pg_float4_Db2Form(shift);
}


# --- used for internal tests --------------------------------------------------
sub _test_pg
{

   print Pg_datetime_Form2Db("20.10.2052 12:34") . "\n";
   print Pg_datetime_Db2Form("Wed Oct 20 09:22:15 1999 MEST") . "\n";
}

# &_test_pg(); # for testing only

1;
