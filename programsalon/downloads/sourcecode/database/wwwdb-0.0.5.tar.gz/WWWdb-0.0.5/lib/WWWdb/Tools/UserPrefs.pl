
sub PreCreateForm ()
{
   my $cConfigDirName;
   my @lAlleImages;
   my $cImageName;

   $cConfigDirName = &GetAttr("BaseDir") . "/lib/Images";

   opendir BASE_DIR, $cConfigDirName or
       die(sprintf(i18n("Can't open %s"),
                   $cConfigDirName));
   @lAlleImages = grep /^.+\..+$/, readdir BASE_DIR;
   closedir BASE_DIR;

   &MySetVal("Layout Field BgImageForm", "Values", @lAlleImages);

   if(&GetAttr("LastBtn") ne "BtnNew")
   {
      # Remove path
      $cImageName = &SessionIdGetState("[GUI] BgImage");
      $cImageName =~ s%.*/%%;

      &SetField("BgColorForm",
                &SessionIdGetState("[GUI] BgColor"));
      &SetField("BgImageForm", $cImageName);
      &SetField("BgColorTable",
                &SessionIdGetState("[Layout Table] BgColor"));
      &SetField("BgColorTable1stCol",
                &SessionIdGetState("[Layout Table] BgColor1stCol"));
      &SetField("BorderTable",
                &SessionIdGetState("[Layout Table] Border"));
      &SetField("WidthTable",
                &SessionIdGetState("[Layout Table] LinkWidth"));
      &SetField("ConfirmIns",
                &SessionIdGetState("[GUI] DontConfirmAfterInsert"));
      &SetField("ConfirmUpd",
                &SessionIdGetState("[GUI] DontConfirmAfterUpdate"));
      &SetField("ConfirmDel",
                &SessionIdGetState("[GUI] DontConfirmAfterDelete"));
      &SetField("DebugMode",
                &SessionIdGetState("[Debug] Level"));
   }

}



sub MyBtnNew ()
{
   my $cApplName = &GetAttr("ScriptName");

   &SessionIdSaveState("[GUI] BgColor", &GetField("BgColorForm"));

   &SessionIdSaveState("[GUI] BgImage",
                       "/" . $cApplName .
                       "/lib/Images/" .
                       &GetField("BgImageForm"));

   &SessionIdSaveState("[Layout Table] BgColor",
                       &GetField("BgColorTable"));

   &SessionIdSaveState("[Layout Table] BgColor1stCol",
                       &GetField("BgColorTable1stCol"));

   &SessionIdSaveState("[Layout Table] Border",
                       &GetField("BorderTable"));

   &SessionIdSaveState("[Layout Table] LinkWidth",
                       &GetField("WidthTable"));

   &SessionIdSaveState("[GUI] DontConfirmAfterInsert",
                       &GetField("ConfirmIns"));

   &SessionIdSaveState("[GUI] DontConfirmAfterUpdate",
                       &GetField("ConfirmUpd"));

   &SessionIdSaveState("[GUI] DontConfirmAfterDelete",
                       &GetField("ConfirmDel"));

   &SessionIdSaveState("[Debug] Level",
                       &GetField("DebugMode"));

   &OkForm("", i18n("Defaults changed!"));

   &MyExit();
}


sub MyBtnDef ()
{

   &SessionIdDelState("[GUI] BgColor", "");
   &SessionIdDelState("[GUI] BgImage", "");
   &SessionIdDelState("[Layout Table] BgColor", "");
   &SessionIdDelState("[Layout Table] BgColor1stCol", "");
   &SessionIdDelState("[Layout Table] LinkWidth", "");
   &SessionIdDelState("[Layout Table] Border", "");
   &SessionIdDelState("[GUI] DontConfirmAfterDelete", "");
   &SessionIdDelState("[GUI] DontConfirmAfterUpdate", "");
   &SessionIdDelState("[GUI] DontConfirmAfterInsert", "");
   &SessionIdDelState("[Debug] Level", "");

   &OkForm("", i18n("Set to defaults!"));

   &MyExit();
}


sub MyBtnLogin ()
{
   &Redirect(&GetAttr("SessionId"), "WWWdb:System:Login");
}

1;
