# defined Plugins:
#
# --- Things, to do, before WWWdb does any Action
# PreDoAction()
#
# --- Things to do, before the HTML-form will be generated
# PreCreateForm()
#
# --- Check-Routine for every field of the Table <Table>
# Check_<Table>_EveryField()
#
# --- Check-Routine for field <Field> of the Table <Table>
# Check_<Table>_<Field>()
#
# --- Check-Routine for the Table <Table> after all single-checks
# Check_<Table>()
#
# --- Conversion for fieldtype <FieldType> of db <Db> coming from form
# <Db>_<FieldType>_Form2Db()
#
# --- Conversion for fieldtype <FieldType> of db <Db> coming from db
# <Db>_<FieldType>_Db2Form()
#
# --- Do action for Button <Btn>
# (Pre|Post|My)Btn<Btn>()
#
# --- Set up the navigation-column on the left side
# (Pre|Post|My)FirstColumn()
#
# --- Generate the header of the form
# (Pre|Post|My)FormHeader()
#
# --- Generate the header of the table
# (Pre|Post|My)TableHeader($)
#
# --- Generate the footer of the table
# (Pre|Post|My)TableFooter()
#
# --- Generate the footer of the page
# (Pre|Post|My)FormFooter()


sub MyBtnNew()
{
   &ReorgCategories();

   &OkForm("",
           i18n("The categories in WWWdb were successfully reorganized"));

   &MyExit();

}


sub ReorgCategories()
{
   my $iCat;
   my $cCat;
   my @lCat;

   @lCat = &SQLSelectList("SELECT id_category
                           FROM wwwdb_category");

   foreach $iCat (@lCat)
   {
      my $iWorkCat = $iCat;
      my $cIdChain   = "";
      my $cNameChain = "";


      while (1)
      {
         my @lFields;
         my $cEntry;

         # get parent-category
         $cEntry = (&SQLSelectList
                    (sprintf("SELECT
                             id_category,
                             id_cat_of_cat,
                             name
                           FROM
                             wwwdb_nav_in_cat
                           WHERE
                             id_category = %d",
                             $iWorkCat)))[0];

         last
             if !$cEntry;

         @lFields = split /\\,/, $cEntry;

         $iWorkCat = $lFields[1];

         $cIdChain   = $lFields[0] . "\\," . $cIdChain;
         $cNameChain = $lFields[2] . "\\," . $cNameChain;

      } # while (1)

      # remove trailing /
      $cIdChain =~ s:\\,$::;
      $cNameChain =~ s:\\,$::;

      &SQLDo(sprintf("UPDATE wwwdb_category
                      SET
                        id_chain   = '%s',
                        name_chain = '%s'
                      WHERE
                        id_category = %d",
                     $cIdChain,
                     $cNameChain,
                     $iCat));

   } # foreach $iCat (@lCat)


   @lCat = &SQLSelectList("SELECT id_category, name_chain
                           FROM wwwdb_category");

   foreach $cCat (@lCat)
   {
      my $iNrOfSubcats;
      my $iNrOfObjects;

      @lFields = split /\\,/, $cCat;

      $iNrOfSubcats = (&SQLSelectList
                      (sprintf("SELECT COUNT(*)
                                FROM  wwwdb_category
                                WHERE name_chain like '%s%%'",
                               $lFields[1])))[0];

      $iNrOfObjects = (&SQLSelectList
                       (sprintf("SELECT COUNT(*)
                                 FROM
                                   wwwdb_category c,
                                   wwwdb_obj_cat  oc
                                 WHERE
                                   c.id_category = oc.id_category AND
                                   c.name_chain like '%s%%'",
                               $lFields[1])))[0];


      &SQLDo(sprintf("UPDATE wwwdb_category
                      SET
                        nr_of_subcats = %d,
                        nr_of_objs    = %d
                      WHERE
                        id_category = %d",
                     $iNrOfSubcats - 1,
                     $iNrOfObjects,
                     $lFields[0]));
   }
}
