
sub PreCreateForm ()
{
   my $cDriver;
   my $cDatabase;
   my $cUser;
   my $cPassword;

   my $cPgConfigText;

   $cDriver   = &SessionIdGetState("CreateDbRc_1,DbDriver");
   $cDatabase = &SessionIdGetState("CreateDbRc_2,Database");
   $cUser     = &SessionIdGetState("CreateDbRc_2,User");
   $cPassword = &SessionIdGetState("CreateDbRc_2,Password");

   $cPgConfigText = <<EOF;

[DB]
Driver    = Pg

Username  = $cUser
Password  = $cPassword
Opts      = Pg(RaiseError=>0, PrintError=>0, AutoCommit=>1):dbname=$cDatabase

EOF

    &SetField("ConfigText", $cPgConfigText);

}


sub Check_DbRc_DriverName ()
{

   &AddError("Database", "Please select a name for the Db-driver!")
       if(!&GetField("Database"));
}



sub MyBtnFinish ()
{

   &CheckRecord();

   if(!&GetField("DriverName"))
   {
      &GenPage();
   }
   else
   {
      my $cDriverName;
      my $cFileName;

      $cFileName = &GetAttr("BasePath") . "/lib/" .
          &GetField("DriverName") . ".rc";

      print MY_LOG "DbDriver written to -> $cFileName\n";

      open DRIVER_CONFIG_FILE, ">$cFileName" or
          die(sprintf(i18n("Can't open file %s"),
                         "$cFileName"));

      print DRIVER_CONFIG_FILE &GetField("ConfigText");

      close DRIVER_CONFIG_FILE;

      &SessionIdDelState("CreateDbRc_1,DbDriver");
      &SessionIdDelState("CreateDbRc_2,Database");
      &SessionIdDelState("CreateDbRc_2,User");
      &SessionIdDelState("CreateDbRc_2,Password");

      print &Redirect(&GetAttr("SessionId"), "WWWdb:Index");
   }
}

sub MyBtnPrev ()
{
   my $cDriver;

   $cDriver   = &SessionIdGetState("CreateDbRc_1,DbDriver");

   print &Redirect(&GetAttr("SessionId"),
                   "WWWdb:Wiz:CreateDbRc${cDriver}_2");
}

1;
