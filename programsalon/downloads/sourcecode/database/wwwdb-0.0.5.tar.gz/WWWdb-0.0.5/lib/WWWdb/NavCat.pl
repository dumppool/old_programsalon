# defined Plugins:
#
# --- Things, to do, before WWWdb does any Action
# PreDoAction()
#
# --- Check-Routine for every field of the Table <Table>
# Check_<Table>_EveryField()
#
# --- Check-Routine for field <Field> of the Table <Table>
# Check_<Table>_<Field>()
#
# --- Conversion for fieldtype <FieldType> of db <Db> coming from form
# <Db>_<FieldType>_Form2Db()
#
# --- Conversion for fieldtype <FieldType> of db <Db> coming from db
# <Db>_<FieldType>_Db2Form()
#
# --- Do action for Button <Btn>
# (Pre|Post|My)Btn<Btn>()
#
# --- Set up the navigation-column on the left side
# (Pre|Post|My)FirstColumn()
#
# --- Generate the header of the form
# (Pre|Post|My)FormHeader()
#
# --- Generate the header of the table
# (Pre|Post|My)TableHeader($)
#
# --- Generate the footer of the table
# (Pre|Post|My)TableFooter()
#
# --- Generate the footer of the page
# (Pre|Post|My)FormFooter()

# --- Things to do, before the HTML-form will be generated
sub PreCreateForm()
{
   if (&GetField("id_category") and
       &GetField("id_category") < 10000)
   {
      &SetField("id_system",  1);
   }



}


sub PreBtnNew()
{
   my $iMaxCatId;

   # generate a new object-id
   $iMaxCatId = (&SQLSelectList(sprintf
                                ("SELECT MAX(id_category)
                                  FROM   wwwdb_category
                                  WHERE  %s",
                                 &GetField("id_system")?
                                 "id_category < 10000":
                                 "id_category >= 10000")))[0];

   &SetField("id_category", ($iMaxCatId?
                             $iMaxCatId + 1:
                             (&GetField("id_system")?
                              1 : 10000)));


   &SetField("id_chain", sprintf(i18n("%s - Please reorganize!"),
                                 &GetField("name")));
   &SetField("name_chain", sprintf(i18n("%s - Please reorganize!"),
                                   &GetField("description")));

}

sub BtnObj ()
{
   print &Redirect(&GetAttr("SessionId"), "WWWdb:NavObj");
}

1;








