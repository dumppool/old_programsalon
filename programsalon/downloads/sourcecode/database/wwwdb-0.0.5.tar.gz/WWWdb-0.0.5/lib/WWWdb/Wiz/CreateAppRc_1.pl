sub PreCreateForm ()
{
   my @lAlleRcFiles;
   my @lDbRcFiles;
   my $cConfigDirName;

   $cConfigDirName = &GetAtt("BasePath") . "/lib";


   opendir BASE_DIR, $cConfigDirName or
       die(sprintf(i18n("Can't open %s"),
                      $cConfigDirName));

   @lAlleRcFiles = grep /^.*\.rc$/, readdir BASE_DIR;

   closedir BASE_DIR;

   &MySetVal("Layout Field DbDriver", "Values", @lAlleRcFiles);


}



sub Check_DbRc_DbDriver()
{
   &AddError("DbDriver", "No Driver, please select!!")
       if(!&GetField("DbDriver"));
}



sub MyBtnNext ()
{
   &CheckRecord();

   if(!&GetField("DbDriver"))
   {
      &GenPage();
   }
   else
   {
      &SessionIdSaveState("CreateAppRc_1,DbDriver", &GetField("DbDriver"));

      print &Redirect(&GetAttr("SessionId"), "WWWdb:Wiz:CreateAppRc_2");
   }
}

