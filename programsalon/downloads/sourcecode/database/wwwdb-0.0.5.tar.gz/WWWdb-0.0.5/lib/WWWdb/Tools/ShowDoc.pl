
sub PreDoAction ()
{
   my $cLastBtn   = &GetAttr("LastBtn");
   my $cUrlParams = &GetAttr("UrlParams");
   my @lUrlParams = split ";", $cUrlParams;
   my $iOid       = 0;
   my @lDocInfo   = "";
   my $cDocInfo   = "";

   foreach (@lUrlParams)
   {

      if (/^id_doc=(\d+)/)
      {
         # FIXME: make it db-independant
         $iOid = (&SQLSelectList("SELECT oid
                                  FROM   wwwdb_doc
                                  WHERE  $_"))[0];
      }

      $iOid = $1
          if (/^BtnSelect=(\d+)/);

      if ($iOid)
      {
         $cLastBtn = "BtnSelect" . $iOid;
         &MyParam("BtnSelect" . $iOid, $iOid);
         &MyParam("WWWdbLastBtn",
                  "BtnSelect" . $iOid);
      }
   }

   &MySetVal("Header", "Title", &GetField("description"));

   # Get previous document, if possible
   {
      my $iPrevDoc = 0;
      my $iNextDoc = 0;

      $cDocInfo = (&SQLSelectList
                   (sprintf("SELECT
                               id_doc, category, sub_category, sort_nr
                             FROM
                               wwwdb_doc
                             WHERE
                               oid = '%s'",
                            $iOid)))[0];

      @lDocInfo  = split  /\\,/, $cDocInfo;


      $iPrevDoc = (&SQLSelectList
                   (sprintf("SELECT
                               id_doc
                             FROM
                               wwwdb_doc
                             WHERE
                               category     =  '%s' AND
                               sub_category =  '%s' AND
                               sort_nr      in (
                               SELECT
                                 MAX(sort_nr)
                               FROM
                                 wwwdb_doc
                               WHERE
                                 category     =  '%s' AND
                                 sub_category =  '%s' AND
                                 sort_nr      <  %d)",
                            $lDocInfo[1],
                            $lDocInfo[2],
                            $lDocInfo[1],
                            $lDocInfo[2],
                            $lDocInfo[3])))[0];

      $iNextDoc = (&SQLSelectList
                   (sprintf("SELECT
                               id_doc
                             FROM
                               wwwdb_doc
                             WHERE
                               category     =  '%s' AND
                               sub_category =  '%s' AND
                               sort_nr      in (
                               SELECT
                                 MIN(sort_nr)
                               FROM
                                 wwwdb_doc
                               WHERE
                                 category     =  '%s' AND
                                 sub_category =  '%s' AND
                                 sort_nr      >  %d)",
                            $lDocInfo[1],
                            $lDocInfo[2],
                            $lDocInfo[1],
                            $lDocInfo[2],
                            $lDocInfo[3])))[0];

      if($iPrevDoc)
      {

         &MySetVal("Layout Label nav_top_prev", "Text",
                   &ResolveRefField(sprintf("wwwdb://%s;id_doc=%d",
                                            &GetAttr("ConfigFile"),
                                            $iPrevDoc),
                                    "<< Prev."));
         &MySetVal("Layout Label nav_bot_prev", "Text",
                   &ResolveRefField(sprintf("wwwdb://%s;id_doc=%d",
                                            &GetAttr("ConfigFile"),
                                            $iPrevDoc),
                                    "<< Prev."));
      }

      if($iNextDoc)
      {

         &MySetVal("Layout Label nav_top_next", "Text",
                   &ResolveRefField(sprintf("wwwdb://%s;id_doc=%d",
                                            &GetAttr("ConfigFile"),
                                            $iNextDoc),
                                    "Next >>"));
         &MySetVal("Layout Label nav_bot_next", "Text",
                   &ResolveRefField(sprintf("wwwdb://%s;id_doc=%d",
                                            &GetAttr("ConfigFile"),
                                            $iNextDoc),
                                    "Next >>"));
      }

      # Disable rulers, if no navigation is shown
      if(!$iPrevDoc && !$iNextDoc)
      {
         &MySetVal("Layout Label hr1", "Text", " ");
         &MySetVal("Layout Label hr2", "Text", " ");
      }

   }




   &MyParam("WWWdbState", "Init");
}




sub PreCreateForm ()
{
   &MySetVal("Header", "Title", &GetField("description"));

}


1;

