#!/usr/bin/perl
# -----------------------------------------------------------------------------
# TWC
# Treuwert-Computer GmbH
# Schlo�bergring 9
# 79098 Freiburg
#
# -----------------------------------------------------------------------------
# Programm-Daten
# -----------------------------------------------------------------------------
# Projekt  :
# System   :
# Programm :
# Modul    : $RCSfile: Oracle.pl,v $
# Version  : $Revision: 1.1 $
# Stand von: $Date: 1999/12/02 16:19:20 $
# Status   : $State: Exp $
#
# Kurzbeschreibung:
# Field-conversions for the Oracle-Driver
# -----------------------------------------------------------------------------
# Changes
# $Log: Oracle.pl,v $
# Revision 1.1  1999/12/02 16:19:20  klaus
# new file-struct
#
# Revision 1.1  1999/11/23 15:38:20  klaus
# New lib-directory
#
# Revision 1.1  1999/11/11 13:22:49  klaus
# Snapshot for internal installation
#
# ----------------------------------------------------------------------------


# --- Convert date-fields from db to form ---------------------------------
sub Oracle_DATE_Form2Db ($)
{
   my $cFieldPI = shift;

   my $cResult;

   print MY_LOG "Oracle_date_Db2Form DATE: db->Form ($cFieldPI)\n";# FIXME

   # Format is:      Wed    Oct    20     09:22:15           1999 MEST
   if ($cFieldPI =~ /(\w+)\s+(\w+)\s+(\d+)\s+(\d+):(\d+):(\d+)\s+(\d+).*/)
   {
      my %hMonths = (Jan => 1,  Feb => 2,  Mar => 3,
                     Apr => 4,  May => 5,  Jun => 6,
                     Jul => 7,  Aug => 8,  Sep => 9,
                     Oct => 10, Nov => 11, Dec => 12);
      my ($iDay, $cMon, $iYear, $iHr, $iMin, $iSec) =
          ($3, $2, $7, $4, $5, $6);

      # convert to DD.MM.YYYY hh:mm:ss
      $cResult = sprintf("%02d-%s-%04d", #  %02d:%02d:%02d",
                         $iDay,
                         uc($cMon),
                         $iYear,
                         $iHr,
                         $iMin,
                         $iSec);

   }
   else
   {
      $cResult = "$cFieldPI";
   }

   return $cResult;
}



# --- Convert float4-fields from form to db ---------------------------------
sub Oracle_FLOAT_Form2Db ($)
{
   my $cFieldPI = shift;

   my $cResult;

   ($cResult = $cFieldPI) =~ s/,/./g;

   return $cResult;
}


# --- Convert float4-fields from db to form ---------------------------------
sub Oracle_FLOAT_Db2Form ($)
{
   my $cFieldPI = shift;

   my $cResult;

   ($cResult = $cFieldPI) =~ s/\./,/g;

   return $cResult;
}

# :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(
# OK, this is horrible!!!!!!
#
# But I found no other way to insert an 'empty' string without getting
# converted to a NULL-value
#
# If anyone has a good idea, how to fix this 'feature' I like to hear from!
#
# :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(   :-(

# --- Convert varchar2-fields from form to db ---------------------------------
sub Oracle_VARCHAR2_Form2Db ($)
{
   my $cFieldPI = shift;

   my $cResult;

   $cResult = $cFieldPI? $cFieldPI: " ";

   return $cResult;
}


# --- Convert varchar2-fields from db to form ---------------------------------
sub Oracle_VARCHAR2_Db2Form ($)
{
   my $cFieldPI = shift;

   my $cResult;

   $cResult = ($cFieldPI eq " ")? "": $cFieldPI;

   return $cResult;
}



# --- used for internal tests --------------------------------------------------
sub _test_Oracle
{
   print Oracle_VARCHAR2_Form2Db("") . "\n";
   print Oracle_VSRCHAR2_Form2Db("X") . "\n";
   print Oracle_VARCHAR2_Db2Form("") . "\n";
   print Oracle_VARCHAR2_Db2Form("X") . "\n";

   print Oracle_DATE_Form2Db("Tue Nov 9 14:23:33 1999") . "\n";
   print Oracle_DATE_Form2Db("Tue Nov 9 14:23:33 1999 MET") . "\n";

   print Oracle_FLOAT_Form2Db("123,456") . "\n";
   print Oracle_FLOAT_Db2Form("123,456") . "\n";



}

# &_test_Oracle(); # for testing only

1;
