
sub PreCreateForm ()
{
   if(!&SessionIdGetState("ActualLogin") ||
      !&SessionIdGetState("IsAdmin"))
   {
      &OkForm("ERROR",
              sprintf(i18n("Sorry, please %s first as WWWdb-admin!"),
                      "<A HREF=" .
                      &CreateReference(&GetAttr("SessionId"),
                                       "Login") .
                      ">" .
                      i18n("login") .
                      "</A>"),
              "BtnExit");
      &MyExit();
   }
}


1;
