
sub PreCreateForm ()
{
   if(!&SessionIdGetState("ActualLogin") ||
      !&SessionIdGetState("IsAdmin"))
   {
      &OkForm("ERROR",
              sprintf(i18n("Sorry, please %s first as WWWdb-admin!"),
                      "<A HREF=" .
                      &CreateReference(&GetAttr("SessionId"),
                                       "Login") .
                      ">" .
                      i18n("login") .
                      "</A>"),
              "BtnExit");
      &MyExit();
   }

   &SetField("session_id", &GetAttr("SessionId"));

}

sub Check_wwwdb_state_key()
{
   &AddError("key", "Please enter a valid key!!")
       if(!&GetField("key"));
}




sub PreBtnQry ()
{

   &SetField("session_id", &GetAttr("SessionId"));

}


sub PreBtnNew ()
{
   &SetField("session_id", &GetAttr("SessionId"));
}


1;
