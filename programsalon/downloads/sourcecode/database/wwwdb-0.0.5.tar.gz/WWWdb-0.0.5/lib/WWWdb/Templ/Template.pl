# defined Plugins:
#
# --- Things, to do, before WWWdb does any Action
# PreDoAction()
#
# --- Things to do, before the HTML-form will be generated
# PreCreateForm()
#
# --- Check-Routine for every field of the Table <Table>
# Check_<Table>_EveryField()
#
# --- Check-Routine for field <Field> of the Table <Table>
# Check_<Table>_<Field>()
#
# --- Check-Routine for the Table <Table> after all single-checks
# Check_<Table>()
#
# --- Conversion for fieldtype <FieldType> of db <Db> coming from form
# <Db>_<FieldType>_Form2Db()
#
# --- Conversion for fieldtype <FieldType> of db <Db> coming from db
# <Db>_<FieldType>_Db2Form()
#
# --- Do action for Button <Btn>
# (Pre|Post|My)Btn<Btn>()
#
# --- Set up the navigation-column on the left side
# (Pre|Post|My)FirstColumn()
#
# --- Generate the header of the form
# (Pre|Post|My)FormHeader()
#
# --- Generate the header of the table
# (Pre|Post|My)TableHeader($)
#
# --- Generate the footer of the table
# (Pre|Post|My)TableFooter()
#
# --- Generate the footer of the page
# (Pre|Post|My)FormFooter()
