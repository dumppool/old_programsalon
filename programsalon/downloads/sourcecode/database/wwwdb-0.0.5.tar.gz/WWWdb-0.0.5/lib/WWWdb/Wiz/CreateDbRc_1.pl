
# --- Feld conttyp1 pr�fen -----------------------------------------------
sub Check_DbRc_DbDriver()
{
   &AddError("DbDriver", "No Driver, please select!!")
       if(!&GetField("DbDriver"));
}



sub MyBtnNext ()
{
   &CheckRecord();

   if(!&GetField("DbDriver"))
   {
      &GenPage();
   }
   else
   {
      &SessionIdSaveState("CreateDbRc_1,DbDriver", &GetField("DbDriver"));

      print &Redirect(&GetAttr("SessionId"),
                      "WWWdb:Wiz:CreateDbRc" . &GetField("DbDriver") . "_2");
   }
}

