
sub PreCreateForm ()
{
   if(&SessionIdGetState("ActualLogin"))
   {
      &SessionIdDelState('ActualLogin');

   }

   &Redirect("0000000000000000", "WWWdb:Index");
}


1;
