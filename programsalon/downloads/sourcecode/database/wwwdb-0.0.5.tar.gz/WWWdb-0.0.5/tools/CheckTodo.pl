#!/usr/bin/perl
use strict;

my $iHours = 0;


while (<STDIN>)
{
   # Add Hours
   if(/(\d+)h/)
   {
      $iHours += $1;
   }

   # Add days
   # Add Hours
   if(/(\d+)d/)
   {
      $iHours += $1 * 8;
   }

}

printf ("Total is %d days and %d hours\n",
        $iHours / 8,
        $iHours % 8);
