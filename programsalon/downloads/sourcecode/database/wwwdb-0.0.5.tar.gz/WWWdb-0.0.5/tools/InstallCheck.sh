#!/bin/sh
# set -x
cd ~/Work/WWWdb
echo "Setting the right permissions:"
find . \( -name "*.rc" -or -name "*.pl" -or -name "*.jpg" -or -name "*.png" \) ! -perm -444 -print \
    -exec chmod a+r {} \;

cd lib/WWWdb/Db
echo "Creating default-files:"
rm .pl .rc Default.pl Default.rc
echo -n "Default-DB: "
read A
if [ -f "$A.rc" -a "$A" != "" ]
then
    echo "   ... .rc"
    ln -sf "$A.rc" ".rc"
    ln -sf "$A.rc" "Default.rc"
fi

if [ -f "$A.pl" -a "$A" != "" ]
then
    echo "   ... .pl"
    ln -sf "$A.pl" ".pl"
    ln -sf "$A.pl" "Default.pl"
fi
cd ../..

echo "Cleaning up ..."
perl Makefile.PL
make clean >/dev/null

echo "Please check all filed marked with '-'"
sleep 1
find . ! -type d | \
    sed "s%^./%%" | \
    sort | \
    diff -u - MANIFEST | \
    grep -v @@ | \
    less

make -f Makefile.old dist
