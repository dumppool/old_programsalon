#!/bin/bash

Usage ()
{
    cat <<EOF
$0: usage
    $0 [-D] [-d <Database_Driver>] [-b <Button>]

        -D      Start the Debugger
        -d      Defines which Database-config-file should be used
        -b      Emulates the Button Btn<Button>

EOF

    exit 1 ;
}



PERLDEBUG=""
DATABASE="Pg"
BUTTON=""

# We need TEMP as the `eval set --' would nuke the return value of getopt.
TEMP=`getopt -o Dd:b:h --long debug,database:,button::,help \
     -n 'TestWWW.sh' -- "$@"`

if [ $? != 0 ]
then
    Usage;
    exit 1
fi

# Note the quotes around `$TEMP': they are essential!
eval set -- "$TEMP"

while true
do
    case "$1" in
        -D|--debug)
            PERLDEBUG=-d;
            shift;;
        -d|--database)
            DATABASE=$2;
            shift 2 ;;
        -b|--button)
            BUTTON="Btn$2=$2";
            shift 2 ;;
        -h|--help)
            Usage;;
        --) shift ; break ;;
        *) echo "Internal error!" ; exit 1 ;;
        esac
done

export    WWWDB_DATABASE=$DATABASE
export   WWWDB_BASE_PATH=/usr/local/httpd/htdocs/WWWdb
export  WWWDB_SESSION_ID=1234567812345678
export WWWDB_CONFIG_FILE=$1

echo "$BUTTON" | cat - /tmp/xxx_my_state.log | perl $PERLDEBUG WWWdb.cgi

