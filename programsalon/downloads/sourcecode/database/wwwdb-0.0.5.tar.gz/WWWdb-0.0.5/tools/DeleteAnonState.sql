delete from wwwdb_state where session_id not in (select session_id from
wwwdb_state where key = 'login');   
