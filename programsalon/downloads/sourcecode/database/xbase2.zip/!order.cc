   To order Bullet by credit card (or Eurochecks in DM) use this form,
   payable to BMT Micro.  All other orders should use the Direct-To-
   Author order form.  All shipping is done by the author direct to
   you, and is always the current release of Bullet.  All Bullet 2
   versions include a printed manual and include free shipping to all
   destinations (AirMail).

                  Mail Orders To: BMT Micro
                                  PO Box 15016
                                  WILMINGTON NC 28408
                                  USA

                    Voice Orders: 800AM - 700PM EST (-5 GMT)
                                  (800) 414-4268 (orders only)
                                  (910) 791-7052

                      Fax Orders: (910) 350-2937  24 hours / 7 Days
                                  (800) 346-1672  24 hours / 7 Days

         Online Orders via modem: (910) 350-8061  10 lines, all 14.4K
                                  (910) 799-0923  Direct 28.8K line

     Ordering and general ordering questions:
                         Via AOL: bmtmicro
                         via MSN: bmtmicro
                     Via Prodigy: HNGP66D
                  via Compuserve: 74031,307
                    via Internet: orders@bmtmicro.com
                                  telnet@bmtmicro.com
                                  www.bmtmicro.com


     We accept Visa, Mastercard, Discover, American Express, Diners
     Club, Carte Blanche, Cashiers Check, Personal Check.   Personal
     checks are subject to clearance.  Eurochecks in DM are welcome.
     DM, Sterling, and US Currency is welcome but send only by
     registered mail, return reciept requested.   We cannot be liable
     for lost cash sent through the mail.

     Purchase orders are welcome, subject to approval.   The minimum
     amount is $250.00.

     Information for our German customers is explained in the last
     paragraph of this order form.

     -------------------------------cut here-----------------------------
     Name:
          ------------------------------------------------------(required)
     Company:
             ---------------------------------------------------(optional)
     Address:
             -------------------------------------------------------------

             -------------------------------------------------------------
     City:                                State/Province:
          --------------------------------               -----------------
     Postal/ZIP Code:                     Country:
                     ---------------------        ------------------------
     Phone:
           ---------------------------------------------------------------
     Fax:
         -----------------------------------------------------------------
     E-Mail #1
              ------------------------------------------------------------
     E-Mail #2
              ------------------------------------------------------------
                                        Cost Per    Number of
       ORDERING:  BULLET 2 for Win32    License     Licenses    Extended
     -----------------------------------            --------    --------
     Option A.  Single-license, 2 processes/100 files per process DLL
                                        $  95.00  x          = $
     -----------------------------------            -------     ---------
     Option B.  Single-license, 32 processes/250 files per process DLL
                                        $ 145.00  x          =
     -----------------------------------            -------     ---------
     Option C.  Single-license, unlimited processes/1024 files per process
                DLL and static link library (OMF and COFF versions)
                                        $ 195.00  x          =
     -----------------------------------           --------     ---------
     Option E.  Single-license, unlimited processes/1024 files per process
                DLL and static link libraries for DOSX32, OS/2, and Win32
                                        $ 249.00  x          =
     -----------------------------------           --------     ---------
                                                 SUB-TOTAL  = $
                                                                ---------
                 North Carolina Residents add 6% Sales Tax  =  +
                                                                ---------
                                           BULLET 2  TOTAL  = $
                                                                =========
     ---------------------------------------------------------------------
     |                                                                   |
     | For credit card payment only                                      |
     |                                                                   |
     | Circle one: VISA / Master / Discover / American Express / Diners  |
     |                                                                   |
     | Credit card number:                                               |
     |                     --------------------------------------------- |
     | Expiration date:                                                  |
     |                  ------------------------------------------------ |
     |                                                                   |
     | Authorization signature:                                          |
     |                          ---------------------------------------- |
     ---------------------------------------------------------------------
     -------------------------------cut here-----------------------------


                   ORDERING FROM INSIDE GERMANY ONLY
                   =================================

Persons in Germany wishing to order shareware may also transfer funds
into our account with Deutsche Bank.   Once the money is deposited you
may either fax a confirmation to us with proof of deposit or wait until
Deutsche Bank notifies us of the transaction (usually 10-18 business days).
Account information is as follows:

Deutsche Bank / Frankfurt Branch
Empf�nger:  Thomas Bradford / BMT Micro
Konto-Nummer: 0860221
Bankleitzahl: 500-700-10

When you make the transfer, be sure to put your name and the program you
are registering on the transfer.

Current exchange rates can be obtained by sending an email to
dm_to_us@bmtmicro.com.   An automated reply will return todays exchange
rates.

It is very important that you send us a completed order form by
either email or fax if you deposit money into this account for a
registration.  Fill the order form out as usual except in the credit
card number field put "DEUTSCHE BANK".   We will file the order and
use it to match against the deposit information we receive from the
bank.

                               IMPORTANT!
                               ----------
When you email us your order form, we will reply with an
acknowledgement.   If you do not get an acknowledgement within 24 hours
please send your order again in case it was lost.  This extra bit of
caution can save a lot of confusion.

If you are concerned that your order is taking too long to process, feel
free to check with us about the status of your order.   It's important
to all of us that you feel safe doing business with our company and
please feel free to suggest ways we can improve our service to you.
