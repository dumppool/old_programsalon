/* Dummy file used for nothing at this point
 *
 * see dgux.h
 *
 * $Id: dgux.c,v 1.3 1998/02/26 04:34:24 momjian Exp $
 */
