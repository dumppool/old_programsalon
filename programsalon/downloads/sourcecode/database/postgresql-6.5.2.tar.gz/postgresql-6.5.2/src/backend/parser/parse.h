typedef union
{
	double				dval;
	int					ival;
	char				chr;
	char				*str;
	bool				boolean;
	bool*				pboolean;	/* for pg_shadow privileges */
	List				*list;
	Node				*node;
	Value				*value;

	Attr				*attr;

	TypeName			*typnam;
	DefElem				*defelt;
	ParamString			*param;
	SortGroupBy			*sortgroupby;
	JoinExpr			*joinexpr;
	IndexElem			*ielem;
	RangeVar			*range;
	RelExpr				*relexp;
	A_Indices			*aind;
	ResTarget			*target;
	ParamNo				*paramno;

	VersionStmt			*vstmt;
	DefineStmt			*dstmt;
	RuleStmt			*rstmt;
	InsertStmt			*astmt;
} YYSTYPE;
#define	ABSOLUTE	257
#define	ACTION	258
#define	ADD	259
#define	ALL	260
#define	ALTER	261
#define	AND	262
#define	ANY	263
#define	AS	264
#define	ASC	265
#define	BEGIN_TRANS	266
#define	BETWEEN	267
#define	BOTH	268
#define	BY	269
#define	CASCADE	270
#define	CASE	271
#define	CAST	272
#define	CHAR	273
#define	CHARACTER	274
#define	CHECK	275
#define	CLOSE	276
#define	COALESCE	277
#define	COLLATE	278
#define	COLUMN	279
#define	COMMIT	280
#define	CONSTRAINT	281
#define	CREATE	282
#define	CROSS	283
#define	CURRENT	284
#define	CURRENT_DATE	285
#define	CURRENT_TIME	286
#define	CURRENT_TIMESTAMP	287
#define	CURRENT_USER	288
#define	CURSOR	289
#define	DAY_P	290
#define	DECIMAL	291
#define	DECLARE	292
#define	DEFAULT	293
#define	DELETE	294
#define	DESC	295
#define	DISTINCT	296
#define	DOUBLE	297
#define	DROP	298
#define	ELSE	299
#define	END_TRANS	300
#define	EXCEPT	301
#define	EXECUTE	302
#define	EXISTS	303
#define	EXTRACT	304
#define	FALSE_P	305
#define	FETCH	306
#define	FLOAT	307
#define	FOR	308
#define	FOREIGN	309
#define	FROM	310
#define	FULL	311
#define	GLOBAL	312
#define	GRANT	313
#define	GROUP	314
#define	HAVING	315
#define	HOUR_P	316
#define	IN	317
#define	INNER_P	318
#define	INSENSITIVE	319
#define	INSERT	320
#define	INTERSECT	321
#define	INTERVAL	322
#define	INTO	323
#define	IS	324
#define	ISOLATION	325
#define	JOIN	326
#define	KEY	327
#define	LANGUAGE	328
#define	LEADING	329
#define	LEFT	330
#define	LEVEL	331
#define	LIKE	332
#define	LOCAL	333
#define	MATCH	334
#define	MINUTE_P	335
#define	MONTH_P	336
#define	NAMES	337
#define	NATIONAL	338
#define	NATURAL	339
#define	NCHAR	340
#define	NEXT	341
#define	NO	342
#define	NOT	343
#define	NULLIF	344
#define	NULL_P	345
#define	NUMERIC	346
#define	OF	347
#define	ON	348
#define	ONLY	349
#define	OPTION	350
#define	OR	351
#define	ORDER	352
#define	OUTER_P	353
#define	PARTIAL	354
#define	POSITION	355
#define	PRECISION	356
#define	PRIMARY	357
#define	PRIOR	358
#define	PRIVILEGES	359
#define	PROCEDURE	360
#define	PUBLIC	361
#define	READ	362
#define	REFERENCES	363
#define	RELATIVE	364
#define	REVOKE	365
#define	RIGHT	366
#define	ROLLBACK	367
#define	SCROLL	368
#define	SECOND_P	369
#define	SELECT	370
#define	SET	371
#define	SUBSTRING	372
#define	TABLE	373
#define	TEMP	374
#define	TEMPORARY	375
#define	THEN	376
#define	TIME	377
#define	TIMESTAMP	378
#define	TIMEZONE_HOUR	379
#define	TIMEZONE_MINUTE	380
#define	TO	381
#define	TRAILING	382
#define	TRANSACTION	383
#define	TRIM	384
#define	TRUE_P	385
#define	UNION	386
#define	UNIQUE	387
#define	UPDATE	388
#define	USER	389
#define	USING	390
#define	VALUES	391
#define	VARCHAR	392
#define	VARYING	393
#define	VIEW	394
#define	WHEN	395
#define	WHERE	396
#define	WITH	397
#define	WORK	398
#define	YEAR_P	399
#define	ZONE	400
#define	TRIGGER	401
#define	COMMITTED	402
#define	SERIALIZABLE	403
#define	TYPE_P	404
#define	ABORT_TRANS	405
#define	ACCESS	406
#define	AFTER	407
#define	AGGREGATE	408
#define	ANALYZE	409
#define	BACKWARD	410
#define	BEFORE	411
#define	BINARY	412
#define	CACHE	413
#define	CLUSTER	414
#define	COPY	415
#define	CREATEDB	416
#define	CREATEUSER	417
#define	CYCLE	418
#define	DATABASE	419
#define	DELIMITERS	420
#define	DO	421
#define	EACH	422
#define	ENCODING	423
#define	EXCLUSIVE	424
#define	EXPLAIN	425
#define	EXTEND	426
#define	FORWARD	427
#define	FUNCTION	428
#define	HANDLER	429
#define	INCREMENT	430
#define	INDEX	431
#define	INHERITS	432
#define	INSTEAD	433
#define	ISNULL	434
#define	LANCOMPILER	435
#define	LIMIT	436
#define	LISTEN	437
#define	LOAD	438
#define	LOCATION	439
#define	LOCK_P	440
#define	MAXVALUE	441
#define	MINVALUE	442
#define	MODE	443
#define	MOVE	444
#define	NEW	445
#define	NOCREATEDB	446
#define	NOCREATEUSER	447
#define	NONE	448
#define	NOTHING	449
#define	NOTIFY	450
#define	NOTNULL	451
#define	OFFSET	452
#define	OIDS	453
#define	OPERATOR	454
#define	PASSWORD	455
#define	PROCEDURAL	456
#define	RENAME	457
#define	RESET	458
#define	RETURNS	459
#define	ROW	460
#define	RULE	461
#define	SEQUENCE	462
#define	SERIAL	463
#define	SETOF	464
#define	SHARE	465
#define	SHOW	466
#define	START	467
#define	STATEMENT	468
#define	STDIN	469
#define	STDOUT	470
#define	TRUSTED	471
#define	UNLISTEN	472
#define	UNTIL	473
#define	VACUUM	474
#define	VALID	475
#define	VERBOSE	476
#define	VERSION	477
#define	IDENT	478
#define	SCONST	479
#define	Op	480
#define	ICONST	481
#define	PARAM	482
#define	FCONST	483
#define	OP	484
#define	UMINUS	485
#define	TYPECAST	486


extern YYSTYPE yylval;
