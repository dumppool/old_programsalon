/* Dummy file used for nothing at this point
 *
 * see solaris_i386.h
 */
