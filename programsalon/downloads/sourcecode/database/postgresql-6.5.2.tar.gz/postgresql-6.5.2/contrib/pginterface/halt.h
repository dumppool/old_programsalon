/*
** halt.h
**
*/

void		halt();
