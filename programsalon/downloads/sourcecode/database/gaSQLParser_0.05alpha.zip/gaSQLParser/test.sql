/* Comment at multiple

Lines
lines
lines
  */

select *
from MYOWNTABLE -- comment @ end of line
where Me = :Myself or Your = ':YourSelf' // Lets have a comment
