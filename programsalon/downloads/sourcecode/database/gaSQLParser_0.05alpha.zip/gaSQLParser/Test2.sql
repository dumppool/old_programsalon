select all, (select me from my) 
from test 
where myself 
order by all