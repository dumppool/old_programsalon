insert into testtable
select * from test1Table
