insert into testTable (Mina, tema)
values
('Meie', 23)