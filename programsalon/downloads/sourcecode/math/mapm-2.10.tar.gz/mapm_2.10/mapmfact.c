
/* 
 *  M_APM  -  mapmfact.c
 *
 *  Copyright (C) 1999   Michael C. Ring
 *
 *  Permission to use, copy, and distribute this software and its
 *  documentation for any purpose with or without fee is hereby granted, 
 *  provided that the above copyright notice appear in all copies and 
 *  that both that copyright notice and this permission notice appear 
 *  in supporting documentation.
 *
 *  Permission to modify the software is granted, but not the right to
 *  distribute the modified code.  Modifications are to be distributed 
 *  as patches to released version.
 *  
 *  This software is provided "as is" without express or implied warranty.
 */

/*
 *      $Id: mapmfact.c,v 1.3 1999/06/19 21:25:21 mike Exp $
 *
 *      This file contains the FACTORIAL function.
 *
 *      $Log: mapmfact.c,v $
 *      Revision 1.3  1999/06/19 21:25:21  mike
 *      changed local static variables to MAPM stack variables
 *
 *      Revision 1.2  1999/05/23 18:21:12  mike
 *      minor variable name tweaks
 *
 *      Revision 1.1  1999/05/15 21:06:11  mike
 *      Initial revision
 */

#include "m_apm_lc.h"

/****************************************************************************/
void	m_apm_factorial(rr,aa)
M_APM	rr, aa;
{
M_APM	ftmp1, ftmp2, ftmp3;

if (m_apm_compare(aa, MM_One) <= 0)
  {
   m_apm_copy(rr, MM_One);
   return;
  }

ftmp1 = M_get_stack_var();
ftmp2 = M_get_stack_var();
ftmp3 = M_get_stack_var();

m_apm_copy(rr, aa);
m_apm_copy(ftmp1, aa);

while (TRUE)
  {
   m_apm_subtract(ftmp2, ftmp1, MM_One);
   m_apm_multiply(ftmp3, ftmp2, rr);

   if (m_apm_compare(ftmp2, MM_Two) <= 0)
     {
      m_apm_copy(rr, ftmp3);
      break;
     }

   m_apm_subtract(ftmp1, ftmp2, MM_One);
   m_apm_multiply(rr, ftmp3, ftmp1);

   if (m_apm_compare(ftmp1, MM_Two) <= 0)
     break;
  }

M_restore_stack(3);                    /* restore the 3 locals we used here */
}
/****************************************************************************/
