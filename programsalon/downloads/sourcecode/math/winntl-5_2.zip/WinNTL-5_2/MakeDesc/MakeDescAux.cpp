
long f1(void)
{
   return -1;
}

long f2(long bpl)
{
   return (((long)1) << (bpl-1)) - 1;
}

double f3(void)
{
   return 1.75;
}

void f4(double *p)
{ }

void f5(int *p)
{ }

long f6(void)
{
   return 1;
}

long f7(void)
{
   return -2L;
}

long f8(void)
{
   return 0;
}

