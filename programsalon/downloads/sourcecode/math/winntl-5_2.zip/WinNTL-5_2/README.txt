NTL  -- a library for doing numbery theory --  version 5.2

Author: Victor Shoup (victor@shoup.net)

NTL is open-source software distributed under the terms of the
GNU General Public License.
See the file doc/copying.txt for complete details on the licensing
of NTL.

Documentation is available in the file doc/tour.html, which can
be viewed with a web browser.

For a detailed guide to installation, please see the appropriate
documentation: 
   * doc/tour-unix.html for unix systems
   * doc/tour-win.html for Windows and other systems

The latest version of NTL is available at http://www.shoup.net.
