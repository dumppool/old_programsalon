
#include <NTL/vec_xdouble.h>

#include <NTL/new.h>

NTL_START_IMPL

NTL_vector_impl(xdouble,vec_xdouble)

NTL_io_vector_impl(xdouble,vec_xdouble)

NTL_eq_vector_impl(xdouble,vec_xdouble)

NTL_END_IMPL
