
#include <NTL/vec_vec_GF2E.h>

#include <NTL/new.h>

NTL_START_IMPL

NTL_vector_impl(vec_GF2E,vec_vec_GF2E)

NTL_eq_vector_impl(vec_GF2E,vec_vec_GF2E)

NTL_io_vector_impl(vec_GF2E,vec_vec_GF2E)

NTL_END_IMPL
