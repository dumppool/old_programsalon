
#include <NTL/vec_vec_lzz_pE.h>

#include <NTL/new.h>

NTL_START_IMPL

NTL_vector_impl(vec_zz_pE,vec_vec_zz_pE)

NTL_eq_vector_impl(vec_zz_pE,vec_vec_zz_pE)

NTL_io_vector_impl(vec_zz_pE,vec_vec_zz_pE)

NTL_END_IMPL
