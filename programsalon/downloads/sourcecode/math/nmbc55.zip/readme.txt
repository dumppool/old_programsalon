14 September, 2000

Files for compiling newmat10 under Borland C++ 5.5 or when using
a makefile to make a console executable with Borland Builder 4
or 5.

Edit Bc55.mak so that BORLANDPATH points to the directory where
Borland's include, lib and bin files are stored. Also include this
directory and the bin directory in your path statement.

Call the make file with a command like

   bmake -f bc55.mak

where bmake is the name of the make file in the bin directory.

If you want to make a console application using the IDE with
Borland Builder 4 (I don't know whether this applies to 5)
open "new" under the file menu and then select the "console wizard".
You should rename your main() function as my_main and call this
from a new main() function in a file which has the same name
to the left of the . as the exe file you want to generate.
Builder will load a lot more stuff that it wants into this file.
