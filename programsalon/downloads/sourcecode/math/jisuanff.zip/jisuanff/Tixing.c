#define f(x) 1/(1+(x)*(x))
int n=10;
main()
{
 double fabs();
 const float a=0,b=1;
 double pi,s=0,t1,t2,e=1E-9;
 int k;
 for (k=0;k<n;k++)
 s=s+f(a+k*(b-a)/n)+f(a+(k+1)*(b-a)/n);
 t1=(s*(b-a)/n)/2;
 do
 {
  s=0;
  for(k=1;k<=n;k++)
  s=s+f(a+(2*k-1)*(b-a)/(2*n));
  t2=t1;
  t1=t1/2+s*(b-a)/(2*n);
  n=2*n;
 }while(fabs(t1-t2)>e);
 pi=4*t1;
 printf("\npi=%.10lf",pi);
 getch();
}
double fabs(double x)
{
 if(x>0) return x;
 else return -x;
}