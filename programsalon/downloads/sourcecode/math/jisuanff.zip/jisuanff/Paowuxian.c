#define f(x) 1/(1+(x)*(x))
int m=2;
main()
{
 const float a=0,b=1;
 double pi,s1=0,s2=0,S=0,s,e=1E-10;
 int k;
 m=2*m;
 for (k=2;k<=m-2;k+=2)
  s1+=f(a+k*(b-a)/m);
 for (k=1;k<=m-1;k+=2)
  s2+=f(a+k*(b-a)/m);
 do
 {
  s=S;
  S=(((b-a)/m)/3)*(f(a)+f(b)+2*s1+4*s2);
  s1=s1+s2;
  s2=0;
  m=2*m;
  for (k=1;k<=m-1;k+=2)
   s2+=f(a+k*(b-a)/m);
 }while(S-s>e||s-S<-e);
 pi=4*S;
 printf("\npi=%.10lf",pi);
 getch();
}