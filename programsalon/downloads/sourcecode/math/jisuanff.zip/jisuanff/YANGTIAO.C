#define N 10
#define Y(x) 1/(1+25*(x)*(x))
double x[N+1],y[N+1],A[N+1],B[N+1],a[N],b[N],m[N+2];
main()
{
double y1();
double y2();
double s();
int i1();
int i;
double ix;
for(i=0;i<=N;i++)
{
 x[i]=-1+0.2*i;
 y[i]=Y(x[i]);
}
for(i=1;i<N;i++)
{
 A[i]=0.5;
 B[i]=3*(2.5*(y[i]-y[i-1])+2.5*(y[i+1]-y[i]));
}
A[0]=1;A[N]=0;
B[0]=15*(y[1]-y[0]);B[N]=15*(y[N]-y[N-1]);
a[0]=-A[0]/2;b[0]=B[0]/2;
for(i=1;i<=N;i++)
{
 a[i]=-A[i]/(2+(1-A[i])*a[i-1]);
 b[i]=(B[i]-(1-A[i])*b[i-1])/(2+(1-A[i])*a[i-1]);
}
m[N+1]=0;
for(i=N;i>=0;i--)
m[i]=a[i]*m[i+1]+b[i];
printf("\ninput the x:");
scanf("%lf",&ix);
printf("\nS(%lf)=%lf\tY(%lf)=%lf",ix,s(ix),ix,Y(ix));
}
double s(double ix)
{int i;
double ss;
i=i1(ix);
ss=(1+2*y1(ix))*y2(ix)*y2(ix)*y[i]+(1+2*y2(ix))*y1(ix)*y1(ix)*y[i+1]+(ix-x[i])*y2(ix)*y2(ix)*m[i]+(ix-x[i+1])*y1(ix)*y1(ix)*m[i+1];
return ss;
}
double y1(double ix)
{int i;
i=i1(ix);
return (ix-x[i])/(x[i+1]-x[i]);
}
double y2(double ix)
{int i;
i=i1(ix);
return (ix-x[i+1])/(x[i]-x[i+1]);
}
int i1(double ix)
{int i;
for(i=0;i<N;i++)
 {
  if (ix>=x[i]&&ix<=x[i+1])
  break;
 }
return i;
}