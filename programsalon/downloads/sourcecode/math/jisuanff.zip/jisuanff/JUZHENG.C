#define n 4
main()
{
 float a[n][n+1]={{10,-1,2,0,6},{-1,11,-1,3,25},{2,-1,10,-1,-11},{0,3,-1,8,15}};
 int i,j,k;
 float s=0,x[n],e=1E-6;
 for(k=0;k<n-1;k++)
 {
  if(a[k][k]<e&&a[k][k]>-e) exit(0);
  for(i=k+1;i<n;i++)
  {
   a[i][k]/=a[k][k];
   for(j=k+1;j<=n;j++)
   a[i][j]-=a[i][k]*a[k][j];
  }
 }
 for(k=n-1;k>=0;k--)
 {
  for(j=k+1;j<n;j++)
  s+=a[k][j]*x[j];
  x[k]=(a[k][n]-s)/a[k][k];
  s=0;
 }
 for(i=0;i<n;i++)
 printf("\nx%d = %f",i+1,x[i]);
 getch();
}


