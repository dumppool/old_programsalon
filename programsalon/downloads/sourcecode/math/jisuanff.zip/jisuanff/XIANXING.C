#define N 10 /*the point you want to insert*/
#define f(x) (1/(1+25*x*x)) /*the funcation*/
main()
{
double x1,y[N+1],x[N+1];
int j,i;
for (i=0;i<N+1;i++)
{
x[i]=-1+0.2*i;
y[i]=f(x[i]);
}
printf("\ninput the x:");
scanf("%lf",&x1);
for (j=0;j<N;j++)
for (i=10;i>j;i--)
y[i]=(y[j]*(x1-x[i])-y[i]*(x1-x[j]))/(x[j]-x[i]);
printf("f(%f)=%lf",x1,y[10]);
}