/**  By Kristi Thompson and Sean McLaughlin
 *
 *	  April 10 & 11, 1997
 *
 *    CISC 235 - Information Structures (Winter 1997) taught by David Alex Lamb
 *
 *    Dept of Computer Science
 *    Queen's University, Kingston
 *
 *    kristi@merlan.ca , seanster@merlan.ca
 *
 *    http://qlink.queensu.ca/~3sm79/BplusTree
 *
 * Feel free to copy and modify this applet, but please give credit
 * to the original author where appropriate
 *
 * This applet was inspired by and partly based upon the BST Search Tree Applet
 * by James Stewart.
 *
 * http://www.dgp.toronto.edu/people/JamesStewart/applets/bst/bst-property.html
 *
 */

import java.awt.*;


/** //
	// Pointer
	//

	A Pointer is an animated moveable object which displays as
	just a small box.
	
	The cool part is that it draws an arrow pointing to it's child
	(the object it points to)

	The arrow must be drawn in the parent's Graphics area
	since we can't make our bounds big enough or we overwrite
	other screen objects such as other pointers and arrows

	Pointers Use the Observer mechanism to know when the pointee has
	moved so that we can update our arrow automatically.

*/

class Pointer extends