/**  By Kristi Thompson and Sean McLaughlin
 *
 *	  April 10 & 11, 1997
 *
 *    CISC 235 - Information Structures (Winter 1997) taught by David Alex Lamb
 *
 *    Dept of Computer Science
 *    Queen's University, Kingston
 *
 *    kristi@merlan.ca , seanster@merlan.ca
 *
 *    http://qlink.queensu.ca/~3sm79/BplusTree
 *
 * Feel free to copy and modify this applet, but please give credit
 * to the original author where appropriate
 *
 * This applet was inspired by and partly based upon the BST Search Tree Applet
 * by James Stewart.
 *
 * http://www.dgp.toronto.edu/people/JamesStewart/applets/bst/bst-property.html
 *
 */

import java.awt.*;


/** //
	// Record
	//

	A Record is an animated moveable object which displays a Key and Data object;
	
	Records have Pointer objects pointing to them sometimes, so we should
	deal with the Observer mechanism so that our pointers know when we
	move around or are destroyed
*/

class Record extends Sprite
{ 

final Color RecordColor		= Color.orange;
static int  RECORD_WIDTH	= 25;
}


