/**  By Kristi Thompson and Sean McLaughlin
 *
 *	  April 10 & 11, 1997
 *
 *    CISC 235 - Information Structures (Winter 1997) taught by David Alex Lamb
 *
 *    Dept of Computer Science
 *    Queen's University, Kingston
 *
 *    kristi@merlan.ca , seanster@merlan.ca
 *
 *    http://qlink.queensu.ca/~3sm79/BplusTree
 *
 * Feel free to copy and modify this applet, but please give credit
 * to the original author where appropriate
 *
 * This applet was inspired by and partly based upon the BST Search Tree Applet
 * by James Stewart.
 *
 * http://www.dgp.toronto.edu/people/JamesStewart/applets/bst/bst-property.html
 *
 */

import java.awt.*;


/** //
	// Data
	//

	A Data is an animated moveable object which displays a 'Data Value' (or values)
	
	Ideally subclassed for Different types of data being stored
*/

class Data extends Sprite
{ 

static final	Color DataColor		= Color.black;
static int  DATA_WIDTH			= 25;
//static Font dataFont;
//static FontMetrics datafm;

	Data()
	{
//		dataFont = new Font( "TimesRoman", Font.PLAIN, 14 );
//		datafm = getFontMetrics( dataFont );
	}
}

