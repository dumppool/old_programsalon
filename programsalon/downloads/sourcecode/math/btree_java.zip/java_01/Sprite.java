/**  By Kristi Thompson and Sean McLaughlin
 *
 *	  April 10 & 11, 1997
 *
 *    CISC 235 - Information Structures (Winter 1997) taught by David Alex Lamb
 *
 *    Dept of Computer Science
 *    Queen's University, Kingston
 *
 *    kristi@merlan.ca , seanster@merlan.ca
 *
 *    http://qlink.queensu.ca/~3sm79/BplusTree
 *
 * Feel free to copy and modify this applet, but please give credit
 * to the original author where appropriate
 *
 * This applet was inspired by and partly based upon the BST Search Tree Applet
 * by James Stewart.
 *
 * http://www.dgp.toronto.edu/people/JamesStewart/applets/bst/bst-property.html
 *
 */

import java.awt.*;


/** A Sprite is an animated moveable object This is an abstract class*/

abstract class Sprite extends java.awt.Canvas
{ 
static final int	DEF_WIDTH	= 20; // Size of an individual sprite
static final int	DEF_HEIGHT	= 20;

static final int	DEF_SPACE_X	= 10;	// When a new sprite is created, move over this much
static final int	DEF_SPACE_Y	= 10;	// When a new sprite is created, move over this much

static final int	ANIM_PIX	= 1;	// # of pixels to move before redrawing

static final Color	DEF_BACK_COLOR	= Color.white;
static final Color	DEF_LINE_COLOR	= Color.black;

static final int    DEF_SPEED	= 250; // Pixels/sec

//////////////////////////////////////////////////////////////

int speed;  // Pixels/sec


//////////////////////////////////////////////////////////////

/**	//////////////////////////////////////////////////////////
	//
	// Constructor
	//
*/

	public Sprite()
	{
		speed = DEF_SPEED;
		//width = DEF_WIDTH;
		//height = DEF_HEIGHT;
		//setBackground(DEF_BACK_COLOR);
		//setColor(DEF_LINE_COLOR);
	}




/**	//////////////////////////////////////////////////////////
	//
	// paint
	//
*/

	public void paint( Graphics g )
	{

		// Draw the Outline

		g.drawRect( bounds().x, bounds().y, bounds().width, bounds().height);


	}


/**	/////////////////////////////////////
	//
	// dmove_A - move a certain distance - in an animated manner though
	//
*/

	public void dmove_A( int dx, int dy )
	{
	int i;

	int x, xo, xf, xdist;
	int y, yo, yf, ydist;
	int time, steps, delay, inc;
	int rise, run;
	double slope;

	boolean Axis;
	boolean xA = true, yA = false;


		if ( dx == 0 && dy == 0 ) return; // Why bother?

		if ( isShowing() == false )
		{
			dmove( dx, dy);
			return;
		}

		x = bounds().x;	// Our initial position
		y = bounds().y;

		xo = x; // Primitives don't copy handles do they?
		yo = y;

		xf = x + dx;	// Our final position
		yf = y + dy;

		xdist = Math.abs(dx);			// Distance to go
		ydist = Math.abs(dy);

		if ( ydist > xdist )
		{
			Axis = yA;
			rise = dx;
			run  = dy;
		}
		else
		{ 
			Axis = xA;
			rise = dy;
			run  = dx;
		}

		slope = (double) rise / run; // Run is the longer axis

		time = run / speed;		// Time to cover distance
		steps = run / ANIM_PIX;	// # of steps to cover distance

		if ( steps < 1 )
		{
			delay = 0;
		}
		else
		{
			delay = (int) ((double) ((double) time / (double) steps) * 1000);		// delay needed between steps to maintain speed
		}

			// Set the correct increment
			// if the distance is negligible, don't even move until the final positioning

		if ( run < 0 )
		{
			inc = -ANIM_PIX;
		}
		else
		{
			inc = ANIM_PIX;
		}


			// Move in Steps

		for ( i = 1; i < steps; i++)
		{	
			if ( Axis == xA )
			{
				x = x + inc;
				y = yo + ((int) (i * inc * slope));
				
			}
			else
			{
				y = y + inc;
				x = xo + ((int) ( (double) i * inc * slope));
			}

			move( x, y );	// Finally get to move!

			repaint();

			if ( isShowing() )
			{
				try
				{
				Thread.sleep( delay );	// Pause to maintain speed and give time to redraw
				}
				catch (InterruptedException e)
				{}
			}

		}

		move( xf, yf);	// Move to the precise spot (needed if ANIM_PIX is large)
		repaint();

	}


/** ///////////////////////////////////
	//
	// move_A - move to a certain spot in an animated manner
	//
*/
	public void move_A( int x, int y )
	{

		dmove_A( x - bounds().x, y - bounds().y);

	}



/**	/////////////////////////////////////
	//
	// dmove - move a certain in a NON-animated manner though
	//
*/

	public void dmove( int dx, int dy )
	{

		move( bounds().x + dx, bounds().y + dy);

	}


/**	//////////////////////////////////////////////////////////
	//
	// resize self-adjust size according to object contents
	//
*/

	public void resize()
	{
		// Do nothing
	}


/**	//////////////////////////////////////////////////////////
	//
	// Move our bottom-leftmost child to the left edge, and all bottommost
	// children against the right edge returned.
	// and then centre ourselves
	// between the immediate left child's leftmost edge, and the
	// immediate right child's rightmost edge.
	//
	// If we don't have children, position ourselves at the left edge
	//
	// This of course constructs a tree shape.
*/

	public int Reshape_Tree( int left) // Returns right edge
	{
		return (left);
	}

}