 /**  By Kristi Thompson and Sean McLaughlin
 *
 *	  April 10 & 11, 1997
 *
 *    CISC 235 - Information Structures (Winter 1997) taught by David Alex Lamb
 *
 *    Dept of Computer Science
 *    Queen's University, Kingston
 *
 *    kristi@merlan.ca , seanster@merlan.ca
 *
 *    http://qlink.queensu.ca/~3sm79/BplusTree
 *
 * Feel free to copy and modify this applet, but please give credit
 * to the original author where appropriate
 *
 * This applet was inspired by and partly based upon the BST Search Tree Applet
 * by James Stewart.
 *
 * http://www.dgp.toronto.edu/people/JamesStewart/applets/bst/bst-property.html
 *
 */

import java.awt.*;


// This allows us to pass Node Pointers back up the tree
// during the insert operation (Promoting)

class NodeInfo
{
	Node rc;	// Really we just want a node pointer
	int key;	// Key

}

/** A B+ Tree node Abstract Class */



abstract class Node extends Sprite
{
 
// DEFINES
boolean PROMOTION = true;
boolean NO_PROMOTION = false;

final Color LineColor      = Color.black;
final Color HighlightColor = Color.orange;
final Color BackgroundColor   = Color.lightGray;

static final int SPLIT_SPEED = 5;

// DEFINES

  boolean highlight_node;	// true if node is to be highlighted
  Color highlight_colour;
  boolean hide_edge;		// true if parent edge is to be hidden (i.e. not drawn)

  // Things having to do with appearance:

	public Node()
	{
	}

	//in sprite abstract public void dmove( int dx, int dy );
	//in sprite abstract public void resize();
	// must be subclassed!!!
	
	//
	// insert
	//

	abstract boolean Insert( int k, String d, NodeInfo promo_d );

}
