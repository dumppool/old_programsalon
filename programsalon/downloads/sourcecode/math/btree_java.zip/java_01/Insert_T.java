import BplusTree;

class Insert_T extends Thread implements Runnable
{

BplusTree tree;			// tree in which rotation occurs


	Insert_T( BplusTree t )
	{
		tree = t;
	}

	public void run()
	{
		tree.Insert(tree.newKey, tree.newData);

		tree.repaint();

	}
}

