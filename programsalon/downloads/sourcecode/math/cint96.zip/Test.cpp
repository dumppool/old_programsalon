#include "stdafx.h"
#include <stdlib.h>
#include "int96.h"


inline void test()
{
  int y = 33;
}



void main()
{
  test();

  srand(time(NULL));

  //Try out the FormatAsDecimal function using a value starting with "10".
  CInt96 u;
  u.ConvertFromDecimalString(_T("106686720"));
  CString sText = u.FormatAsDecimal();

  CInt96 xbig(1);
  xbig <<= 95;
  xbig = ~xbig;
  CString sBig = xbig.FormatAsDecimal();

  //Try out the display functions
  CInt96 hh;
  CString sDisplay = hh.FormatAsBinary(TRUE);
  sDisplay = hh.FormatAsBinary(FALSE);
  sDisplay = hh.FormatAsHex(TRUE);
  sDisplay = hh.FormatAsHex(FALSE);
  sDisplay = hh.FormatAsDecimal();

  hh = CInt96(0x12345678987654);
  sDisplay = hh.FormatAsBinary(TRUE);
  sDisplay = hh.FormatAsBinary(FALSE);
  sDisplay = hh.FormatAsHex(TRUE);
  sDisplay = hh.FormatAsHex(FALSE);
  sDisplay = hh.FormatAsDecimal();
  hh.Negate();
  sDisplay = hh.FormatAsDecimal();

  CInt96 g;
  BOOL bSuccess = g.ConvertFromBinaryString(_T("  0110100101010110101  "));
  bSuccess = g.ConvertFromHexString(_T("  abcdef12345678fecaABCD  "));
  bSuccess = g.ConvertFromDecimalString(_T(" - 1234567"));
  g.Negate();
  bSuccess = g.ConvertFromDecimalString(_T("  1234567  "));
  bSuccess = g.ConvertFromBinaryString(_T(""));
  bSuccess = g.ConvertFromHexString(_T(""));
  bSuccess = g.ConvertFromDecimalString(_T(""));


  //Test the division functions
  int xx = 55 / -2;
  int yy = 55 % -2;

  xx = 55 / -1;
  yy = 55 % -1;

  xx = 55 / 4;
  yy = 55 % 4;

  xx = -55 / -2;
  yy = -55 % -2;

  xx = -55 / -1;
  yy = -55 % -1;

  xx = 55 / 4;
  yy = 55 % 4;

  CInt96 a(55);
  CInt96 Quotient;
  CInt96 Remainder;
  a.Modulus(CInt96(2), Quotient, Remainder);
  a.Modulus(CInt96(1), Quotient, Remainder);
  a.Modulus(CInt96(4), Quotient, Remainder);

  Remainder = a % CInt96(4);
  Quotient = a / CInt96(4);

  a.Modulus(CInt96(-2), Quotient, Remainder);
  Quotient.Negate();
  a.Modulus(CInt96(-1), Quotient, Remainder);
  Quotient.Negate();
  a.Modulus(CInt96(-4), Quotient, Remainder);
  Quotient.Negate();

  //a.Modulus(CInt96(0), Quotient, Remainder);
  a = CInt96(0);
  a.Modulus(CInt96(2), Quotient, Remainder);
  a.Modulus(CInt96(1), Quotient, Remainder);
  a.Modulus(CInt96(4), Quotient, Remainder);
  //a.Modulus(CInt96(0), Quotient, Remainder); //should cause a devide by 0 exception

  a = CInt96(-61);
  a.Modulus(CInt96(2), Quotient, Remainder);
  Quotient.Negate();
  a.Modulus(CInt96(1), Quotient, Remainder);
  Quotient.Negate();
  a.Modulus(CInt96(4), Quotient, Remainder);
  Quotient.Negate();
  a.Modulus(CInt96(-2), Quotient, Remainder);
  a.Modulus(CInt96(-1), Quotient, Remainder);
  a.Modulus(CInt96(-4), Quotient, Remainder);


  //Try the operator<< function
  CInt96 w(0x10101);
  TRACE(_T("w is %s"), w.FormatAsBinary());

  CInt96 y;
  for (int j=0; j<96; j++)
  {
    CInt96 q = w << j;
    TRACE(_T("\nq << %02d is %s"), j, q.FormatAsBinary());

    if (j == 76)
      y = q;
  }


  //Try the operator>> function
  TRACE(_T("\n\ny is       %s"), y.FormatAsBinary());

  for (j=0; j<96; j++)
  {
    CInt96 q = y >> j;
    TRACE(_T("\nq >> %02d is %s"), j, q.FormatAsBinary());
  }


  //Test the addition functions
  CInt96 z = CInt96(3) + CInt96(14);
  z = CInt96(3) + CInt96(-14);
  z.Negate();
  z = CInt96(-3) + CInt96(14);
  z.Negate();
  z = CInt96(-3) + CInt96(-14);
  z.Negate();


  //Try the subtraction functions
  z = CInt96(3) - CInt96(14);
  z.Negate();
  z = CInt96(3) - CInt96(-14);
  z = CInt96(-3) - CInt96(14);
  z.Negate();
  z = CInt96(-3) - CInt96(-14);

  z = CInt96(0) - CInt96(1);
  z = -z;  
  z = CInt96(0) - CInt96(-1);


  //Test the multiplication functions
  z = CInt96(0xFFFF) * CInt96(0x1ef04);
  TRACE(_T("\nz = %s"), z.FormatAsBinary());

  z = CInt96(3) * CInt96(14);
  z = CInt96(-3) * CInt96(14);
  z.Negate();
  z = CInt96(-3) * CInt96(-14);
  z = CInt96(3) * CInt96(-14);
  z.Negate();


  //Test the bug discovered in CInt96 v1.03
  CInt96 mula;
  mula.ConvertFromDecimalString(_T("1387233076032"));
  CInt96 mulb;
  mulb.ConvertFromDecimalString(_T("1000000000"));
  z = mula * mulb;
  sText = z.FormatAsDecimal();
  z = mulb * mula;
  sText = z.FormatAsDecimal();


  //Do some speed tests on addition
  DWORD dwStart = GetTickCount();
  for (int i=0; i<900000; i++)
  {
    __int64 x = ((__int64)rand()) + ((__int64)rand());
  }
  DWORD dwTimeTaken = GetTickCount() - dwStart;
  _tprintf(_T("Time taken for addition of __int64's was %d ms\n"), dwTimeTaken);

  dwStart = GetTickCount();
  for (i=0; i<900000; i++)
  {
    CInt96 x = CInt96(rand()) + CInt96(rand());
  }
  dwTimeTaken = GetTickCount() - dwStart;
  _tprintf(_T("Time taken for addition of CInt96's was %d ms\n"), dwTimeTaken);


  //Do some speed tests on subtraction
  dwStart = GetTickCount();
  for (i=0; i<900000; i++)
  {
    __int64 x = ((__int64)rand()) - ((__int64)rand());
  }
  dwTimeTaken = GetTickCount() - dwStart;
  _tprintf(_T("Time taken for subtraction of __int64's was %d ms\n"), dwTimeTaken);

  dwStart = GetTickCount();
  for (i=0; i<900000; i++)
  {
    CInt96 x = CInt96(rand()) - CInt96(rand());
  }
  dwTimeTaken = GetTickCount() - dwStart;
  _tprintf(_T("Time taken for subtraction of CInt96's was %d ms\n"), dwTimeTaken);


  //Do some speed tests on multiplication
  dwStart = GetTickCount();
  for (i=0; i<900000; i++)
  {
    __int64 x = ((__int64)rand()) * ((__int64)rand());
  }
  dwTimeTaken = GetTickCount() - dwStart;
  _tprintf(_T("Time taken for multiplication of __int64's was %d ms\n"), dwTimeTaken);

  dwStart = GetTickCount();
  for (i=0; i<900000; i++)
  {
    CInt96 x = CInt96(rand()) * CInt96(rand());
  }
  dwTimeTaken = GetTickCount() - dwStart;
  _tprintf(_T("Time taken for multiplication of CInt96's was %d ms\n"), dwTimeTaken);


  //Do some speed tests on division
  dwStart = GetTickCount();
  for (i=0; i<100000; i++)
  {
    __int64 divisor = ((__int64)rand());
    if (divisor)
      __int64 x = ((__int64)rand()) / divisor;
  }
  dwTimeTaken = GetTickCount() - dwStart;
  _tprintf(_T("Time taken for division of __int64's was %d ms\n"), dwTimeTaken);

  dwStart = GetTickCount();
  for (i=0; i<100000; i++)
  {
    CInt96 divisor = CInt96(rand());
    if (!divisor.IsZero())
      CInt96 x = CInt96(rand()) / divisor;
  }
  dwTimeTaken = GetTickCount() - dwStart;
  _tprintf(_T("Time taken for division of CInt96's was %d ms\n"), dwTimeTaken);
}