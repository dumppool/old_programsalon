/*
Module : INT96.H
Purpose: Interface for a 96 bit integer class
Created: PJN / 24-04-1998
History: None

Copyright (c) 1998 by PJ Naughter.  
All rights reserved.

*/

////////// Defines ///////////////////////

#ifndef __INT96_H__
#define __INT96_H__



////////// Classes ///////////////////////

class CInt96
{
public:
//constructors / destructors
  CInt96();
  CInt96(unsigned short value);
  CInt96(unsigned int value);
  CInt96(unsigned long value);
  CInt96(const unsigned __int64& value);
  CInt96(short value);
  CInt96(int value);
  CInt96(long value);
  CInt96(const __int64& value);
  CInt96(const CInt96& value);

//assignment operator
  CInt96& operator=(const CInt96& value);

//arithmetic operators
  CInt96 operator+(const CInt96& value);
  CInt96 operator-(const CInt96& value);
  friend CInt96 operator-(const CInt96& value);
  CInt96& operator++();
  CInt96& operator--();
  CInt96  operator*(const CInt96& value) const;
  CInt96  operator/(const CInt96& value) const;
  CInt96  operator%(const CInt96& value) const;
  CInt96& operator*=(const CInt96& value);
  CInt96& operator/=(const CInt96& value);
  CInt96& operator+=(const CInt96& value);
  CInt96& operator-=(const CInt96& value);
  CInt96& operator%=(const CInt96& value);
  CInt96  operator~() const;

//equality operators
  int operator==(const CInt96& value) const;
  int operator!=(const CInt96& value) const;
  int operator>(const CInt96& value) const;
  int operator>=(const CInt96& value) const;
  int operator<(const CInt96& value) const;
  int operator<=(const CInt96& value) const;

//Misc operators
  CInt96  operator>>(int nShift) const;
  CInt96  operator<<(int nShift) const;
  CInt96& operator>>=(int nShift);
  CInt96& operator<<=(int nShift);
  CInt96  operator^(const CInt96& value) const;
  CInt96  operator|(const CInt96& value) const;
  CInt96  operator&(const CInt96& value) const;
  CInt96& operator^=(const CInt96& value);
  CInt96& operator|=(const CInt96& value);
  CInt96& operator&=(const CInt96& value);

//Operators to convert back to basic types
  operator int();
  operator unsigned int();
  operator __int64();
  operator unsigned __int64();

//String conversion functions
  CString FormatAsHex(BOOL bLeadingZeros = TRUE) const;
  CString FormatAsBinary(BOOL bLeadingZeros = TRUE) const;
  CString FormatAsDecimal() const;
  BOOL ConvertFromBinaryString(const CString& sText);
  BOOL ConvertFromHexString(const CString& sText);
  BOOL ConvertFromDecimalString(const CString& sText);

//Misc. Functions
  BOOL GetBit(int nIndex) const;
  void SetBit(int nIndex, BOOL value);
  BOOL IsZero() const;
  void Zero();
  void Negate();
  BOOL IsNegative() const;
  BOOL IsPositive() const;
  void Modulus(const CInt96& divisor, CInt96& Quotient, CInt96& Remainder) const;

//Serialization
  virtual void Serialize(CArchive& ar);

protected:
  void TwosComplement();
  void InverseTwosComplement();

  //Actual member data variables
  DWORD m_MSB;
  DWORD m_CSB;
  DWORD m_LSB;
};


#endif //__INT96_H__