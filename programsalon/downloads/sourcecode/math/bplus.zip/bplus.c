/********************************************************************/
/*                                                                  */
/*             BPLUS file indexing program - Version 1.0            */
/*                                                                  */
/*                      A "shareware program"                       */
/*                                                                  */
/*                                                                  */
/*                      Copyright (C) 1987 by                       */
/*                                                                  */
/*                      Hunter and Associates                       */
/*                      7050 NW Zinfandel Lane                      */
/*                      Corvallis, Oregon  97330                    */
/*                      (503) 745 - 7186                            */
/*                                                                  */
/********************************************************************/

/*#define	_BCC_*/

#include <stdio.h>
#include <fcntl.h>

#ifdef AIX
#include <sys/io.h>
#endif

#include <sys/types.h>            /*  delete this line for Turbo C  */
#include <sys/stat.h>
#include <string.h>
#include "bplus.h"


#ifndef O_BINARY
#define	O_BINARY	0
#endif

/*  macros, constants, data types  */

#define  NULLREC      (-1L)
#define  FREE_BLOCK   (-2)

#define  ENT_ADR(pb,off)  ((ENTRY*)((char*)((pb)->entries) + off))
#define  ENT_SIZE(pe)     (int)strlen((pe)->key) + 1 + 2 * sizeof(RECPOS)
#define  BUFDIRTY(ix,j)   (ix->bt_buffer.cache[j].dirty)
#define  BUFHANDLE(ix,j)     (ix->bt_buffer.cache[j].handle)
#define  BUFBLOCK(ix,j)      (ix->bt_buffer.cache[j].mb)
#define  BUFCOUNT(ix,j)      (ix->bt_buffer.cache[j].count)
#define  CB(ix,j)            (ix->pos[j].cblock)
#define  CO(ix,j)            (ix->pos[j].coffset)


/*  declare some global variables  */

/*IX_DESC      *pci;
IX_BUFFER    bt_buffer;
IX_BUFFER    *mci = &bt_buffer;
BLOCK        *block_ptr;
BLOCK        *spare_block;
int          cache_ptr = 0;
int  cache_init = 0;
*/

int  split_size = IXB_SPACE;
int  comb_size  = (IXB_SPACE/2);

void  error(int, long);
int  read_if(int, long, char *, int);
int  write_if(int, long, char *, int);
int   creat_if(char *);
int   open_if(char *);
void  close_if(int);
void  update_block(IX_DESC *);
void  init_cache(IX_DESC *);
int   find_cache(IX_DESC *, RECPOS);
int   new_cache(IX_DESC *);
void  load_cache(IX_DESC *, RECPOS);
void  get_cache(IX_DESC *, RECPOS);
void  retrieve_block(IX_DESC *,int, RECPOS);
int   prev_entry(IX_DESC *, int);
int   next_entry(IX_DESC *, int);
void  copy_entry(ENTRY *, ENTRY *);
int   scan_blk(IX_DESC *, int);
int   last_entry(IX_DESC *);
void   write_free(IX_DESC *, RECPOS, BLOCK *);
RECPOS  get_free(IX_DESC *);
int   find_block(IX_DESC *, ENTRY *, int *);
void  movedown(BLOCK *, int, int);
void  moveup(BLOCK *, int, int);
void ins_block(BLOCK *, ENTRY *, int);
void  del_block(BLOCK *, int);
void   split(IX_DESC *, int, ENTRY *, ENTRY *);
void  ins_level(IX_DESC *,int, ENTRY *);
int   insert_ix(ENTRY *, IX_DESC *);
int   find_ix(ENTRY *, IX_DESC *, int);
int   combineblk(IX_DESC *, RECPOS, int);
void  replace_entry(IX_DESC *, ENTRY *);
void print_blk(BLOCK *);


/*  file I/O for B-PLUS module  */

void  error(j, l)
  int j;
  long l;
  {
    static char *msg[3] = {"ERROR - CANNOT OPEN/CLOSE FILE",
			   "ERROR WHILE READING FILE",
			   "ERROR WHILE WRITING FILE"};
    printf("\n  %s - Record Number %ld\n", msg[j], l);
    exit(1);
  } /* error */


int read_if(int hfile, long start, char *buf, int nwrt)
{
    long err;
    err = start - lseek(hfile, start, SEEK_SET);
    if (err == 0) err = nwrt - read(hfile, buf, nwrt);
    if (err != 0)
	error(1, start);
    if(err) return -1;
    else return 0;
} /* read_if */


int  write_if(handle, start, buf, nwrt)
  int handle;
  long start;
  char *buf;
  int nwrt;
  {
    long err;
    err = start - lseek(handle, start, SEEK_SET);
    if (err == 0) err = nwrt - write(handle, buf, nwrt);
    if (err != 0) error(2, start);
    if(err) return -1;
    else return 0;
  } /* write_if */


int creat_if(fn)
  char *fn;
  {
    int   ret;
    ret = open(fn,O_RDWR|O_CREAT|O_TRUNC|O_BINARY,S_IWUSR|S_IRUSR);
    if (ret  < 0) error(0,0L);
    return (ret);
  } /* creat_if */


int  open_if(char *fn)
{
    int  ret;
    ret = open(fn,O_RDWR|O_BINARY);
    if (ret < 1) error(0,0L);
    return (ret);
} /* open_if */


void  close_if(handle)
  int handle;
  {
    if(close(handle) < 0)  error(2,0L);
  } /*  close_if */


int  open_index(char *name, IX_DESC *pix, int dup)
{
  pix->cache_ptr =0;
  pix->cache_init =0;
  memset(&pix->pos, 0, sizeof(pix->pos));
  memset(&pix->bt_buffer, 0, sizeof(pix->bt_buffer));

  pix->ixfile = open_if(name);
  pix->duplicate = dup;
  read_if(pix->ixfile, 0L,(char *)&(pix->root), (sizeof(BLOCK) + sizeof(IX_DISK)));
  if(!pix->cache_init)
  {
    init_cache(pix);
    pix->cache_init = 1;
  }
  first_key(pix);

  return ( IX_OK );
} /* open_index */


int  close_index(IX_DESC *pix)
{
    int i;
    write_if(pix->ixfile, 0L,(char *)&(pix->root),
               (sizeof(BLOCK) + sizeof(IX_DISK)));
    for (i = 0; i < NUM_BUFS; i++)
      if (BUFDIRTY(pix, i) && (BUFHANDLE(pix, i) == pix->ixfile))
      {
          write_if(BUFHANDLE(pix, i),
                   BUFBLOCK(pix, i).brec,
                   (char *) &BUFBLOCK(pix, i),
                   sizeof(BLOCK));
          BUFDIRTY(pix, i) = 0;
      }
    close_if(pix->ixfile);
    return( IX_OK );
} /* close_index */

int  make_index(char *fname, IX_DESC *pix, int dup)
{
  pix->cache_ptr =0;
  memset(&pix->pos, 0, sizeof(pix->pos));
  memset(&pix->bt_buffer, 0, sizeof(pix->bt_buffer));

  pix->ixfile = creat_if(fname);
  pix->duplicate = dup;
  pix->dx.nl = 1;
  pix->dx.ff = NULLREC;
  pix->level = 0;
  pix->cache_init =0;

  CO(pix, 0) = -1;
  CB(pix, 0) = 0L;
  pix->root.brec = 0L;
  pix->root.bend = 0;
  pix->root.p0 = NULLREC;
  write_if(pix->ixfile, 0L,(char *)&(pix->root),
               (sizeof(BLOCK) + sizeof(IX_DISK)));
  if (!pix->cache_init)
  {
      init_cache(pix);
      pix->cache_init = 1;
  }
  first_key(pix);
  return ( IX_OK );
} /* make_index */


/*  cache I/O for BPLUS  */

void  update_block(IX_DESC *pix)
{
    if (pix->block_ptr != &(pix->root))
       BUFDIRTY(pix, pix->cache_ptr) = 1;
} /* update_block */


void init_cache(IX_DESC *pix)
{
  register int  j;

  for (j = 0; j < NUM_BUFS; j++)
  {
    BUFDIRTY(pix, j) = 0;
    BUFCOUNT(pix, j) = 0;
    BUFBLOCK(pix, j).brec = NULLREC;
  }
} /* init_cache */

int  find_cache(IX_DESC *pix, RECPOS r)
{
  register int  j;
  for (j = 0; j < NUM_BUFS; j++)
  {
    if((BUFBLOCK(pix, j).brec == r) && (BUFHANDLE(pix, j) == pix->ixfile))
    {
      pix->cache_ptr = j;
      return (1);
    }
  }
  return (-1);
} /* find_cache */


int  new_cache(IX_DESC *pix)
{
  register int  i;

  i = (pix->cache_ptr + 1) % NUM_BUFS;
  if (BUFDIRTY(pix, i)) write_if(BUFHANDLE(pix,i),
                              BUFBLOCK(pix,i).brec,
			      (char *) &BUFBLOCK(pix, i),
                              sizeof(BLOCK));
  BUFHANDLE(pix, i) = pix->ixfile;
  BUFDIRTY(pix, i) = 0;
  return (pix, i);
} /* new_cache */


void  load_cache(IX_DESC *pix, RECPOS r)
{
  pix->cache_ptr = new_cache(pix);
  read_if(pix->ixfile, r, (char *)&BUFBLOCK(pix, pix->cache_ptr), sizeof(BLOCK));
} /* load_cache */


void  get_cache(IX_DESC *pix, RECPOS r)
{
    if (find_cache(pix, r) < 0)
       load_cache(pix, r);
    pix->block_ptr = &BUFBLOCK(pix, pix->cache_ptr);
} /* get_cache */


void  retrieve_block(IX_DESC *pix, int j, RECPOS r)
{
  if (j == 0)
     pix->block_ptr = &(pix->root);
  else
     get_cache(pix, r);
  CB(pix, j) = pix->block_ptr->brec;
} /* retrieve_block */


/*  low level functions of BPLUS  */

int  prev_entry(IX_DESC *pix, int off)
{
   if (off <= 0)
   {
     off = -1;
     CO(pix, pix->level) = off;
   }
   else
     off = scan_blk(pix, off);
   return(off);
} /* prev_entry */


int next_entry(IX_DESC *pix, int off)
{
   if (off == -1)
     off = 0;
   else
   {
     if (off < pix->block_ptr->bend)
       off += ENT_SIZE(ENT_ADR(pix->block_ptr,off));
   }
   CO(pix, pix->level) = off;
   return (off);
} /* next_entry */


void  copy_entry(ENTRY *to, ENTRY *from)
{
  int me;
  me = ENT_SIZE(from);
  memmove(to, from, me);
} /* copy_entry */


int  scan_blk(IX_DESC *pix, int n)
{
   register int off, last;

   off = 0;
   last = -1;
   while (off < n )
   {
     last = off;
     off += ENT_SIZE(ENT_ADR(pix->block_ptr,off));
   }
   CO(pix, pix->level) = last;
   return (last);
} /* scan_blk */


int  last_entry(IX_DESC *pix)
{
     return( scan_blk(pix, pix->block_ptr->bend) );
} /* last_entry *;*/


/*  maintain list of free index blocks  */

void  write_free(IX_DESC *pix, RECPOS r, BLOCK *pb)
{
    pb->p0 = FREE_BLOCK;
    pb->brec = pix->dx.ff;
    write_if(pix->ixfile, r, (char *) pb, sizeof(BLOCK));
    pix->dx.ff = r;
} /* write_free */

long filelength(int hd)
{
  struct stat sb;

  fstat(hd, &sb);

  return sb.st_size;
}

RECPOS  get_free(IX_DESC *pix)
{
  RECPOS  r, rt;

  r = pix->dx.ff;
  if ( r != NULLREC )
  {
    read_if(pix->ixfile, r, (char *)&rt, sizeof( RECPOS ));
    pix->dx.ff = rt;
  }
  else
    r = filelength (pix->ixfile);
  return (r);
} /* get_free */

/*extern int b_show;*/
/*  general BPLUS block level functions  */
int  find_block(IX_DESC *pix, ENTRY *pe, int *poff)
{
  register int pos, nextpos, ret;
  pos = -1;
  nextpos = 0;
  ret = 1;
  while ( nextpos < pix->block_ptr->bend)
  {
    ret = strcmp((char *)(pe->key),
                 (char *)(ENT_ADR(pix->block_ptr, nextpos)->key));
    if (ret <= 0)
    {
       if (ret == 0) pos = nextpos;
       break;
    }
    pos = nextpos;
    nextpos = next_entry(pix, pos);
  }
  CO(pix, pix->level) = pos;
  *poff = pos;
  return (ret);
} /* find_block */

void  movedown(BLOCK *pb, int off, int n)
{
  memmove(ENT_ADR(pb, off),
         ENT_ADR(pb, off + n),
         pb -> bend - (off + n));
} /* movedown */


void  moveup(BLOCK *pb, int off, int n)
{
  memmove(ENT_ADR(pb, off + n),
          ENT_ADR(pb, off),
          pb->bend - off);
} /* moveup */


void ins_block(BLOCK *pb, ENTRY *pe, int off)
{
  int size;
  size = ENT_SIZE(pe);
  moveup(pb,off,size);
  copy_entry(ENT_ADR(pb,off),pe);
  pb->bend += size;
} /* ins_block */


void  del_block(BLOCK *pb, int off)
{
    int ne;
    ne = ENT_SIZE(ENT_ADR(pb, off));
    movedown(pb, off, ne);
    pb->bend -= ne;
} /* del_block */


/*  position at start/end of index  */

int  first_key(IX_DESC *pix)
{
    pix->block_ptr = &(pix->root);
    CB(pix, 0) = 0L;
    CO(pix, 0) = -1;
    pix->level = 0;
    while(pix->block_ptr->p0 != NULLREC)
    {
      retrieve_block(pix, ++(pix->level), pix->block_ptr->p0);
      CO(pix, pix->level) = -1;
    }
    return ( IX_OK );
} /* first_key */


int  last_key(IX_DESC *pix)
{
    long  ads;

    pix->block_ptr = &(pix->root);
    CB(pix, 0) = 0L;
    pix->level = 0;
    if(last_entry(pix) >= 0)
    {
        while ((ads = ENT_ADR(pix->block_ptr,last_entry(pix))->idxptr) != NULLREC)
             retrieve_block(pix, ++(pix->level), ads);
    }
    CO(pix, pix->level) = pix->block_ptr->bend;
    return ( IX_OK );
} /* last_key */


/*  get next, previous entries  */

int  next_key(ENTRY *pe, IX_DESC *pix)
{
    RECPOS  address;

    retrieve_block(pix, pix->level, CB(pix, pix->level));
    address = ENT_ADR(pix->block_ptr, CO(pix, pix->level))->idxptr;
    while (address != NULLREC)
    {
         retrieve_block(pix, ++(pix->level), address);
         CO(pix, pix->level) = -1;
         address = pix->block_ptr->p0;
    }
    next_entry(pix, CO(pix, pix->level));
    if (CO(pix, pix->level) == pix->block_ptr->bend)
    {
      do
      {
        if(pix->level == 0)
        {
          last_key(pix);
          return (EOIX);
        }
        --(pix->level);
        retrieve_block(pix, pix->level, CB(pix, pix->level));
        next_entry(pix, CO(pix, pix->level));
      } while (CO(pix, pix->level) == pix->block_ptr->bend);
    }
    copy_entry(pe, ENT_ADR(pix->block_ptr, CO(pix, pix->level)));
    return ( IX_OK );
} /* next_key */


int  prev_key(ENTRY *pe, IX_DESC *pix)
{
    RECPOS  address;
    retrieve_block(pix, pix->level, CB(pix, pix->level));
    prev_entry(pix, CO(pix, pix->level));
    if (CO(pix, pix->level) == -1)
      address = pix->block_ptr->p0;
    else
      address = ENT_ADR(pix->block_ptr, CO(pix, pix->level))->idxptr;
    if (address != NULLREC)
    {
      do
      {
        retrieve_block(pix, ++(pix->level), address);
        address = ENT_ADR(pix->block_ptr, last_entry(pix))->idxptr;
      } while (address != NULLREC);
    }
    if (CO(pix, pix->level) == -1)
    {
      do
      {
        if(pix->level == 0)
        {
          first_key(pix);
          return (EOIX);
        }
        --(pix->level);
      } while (CO(pix, pix->level) == -1);
      retrieve_block(pix, pix->level, CB(pix, pix->level));
    }
    copy_entry(pe, ENT_ADR(pix->block_ptr, CO(pix, pix->level)));
    return ( IX_OK );
} /* prev_key */


/*  insert new entries into tree  */

void  split(IX_DESC *pix, int l, ENTRY *pe, ENTRY *e)
{
    int  half, ins_pos, size;

    ins_pos = CO(pix, pix->level);
    half = scan_blk(pix, pix->block_ptr->bend / 2 + sizeof(RECPOS));
    if (half == ins_pos)
      *e = *pe;
    else
    {
         copy_entry(e, ENT_ADR(pix->block_ptr, half));
         size = ENT_SIZE(e);
         movedown(pix->block_ptr, half, size);
         pix->block_ptr->bend -= size;
    }
    pix->spare_block = &BUFBLOCK(pix, new_cache(pix));
    memcpy(pix->spare_block->entries,
           ENT_ADR(pix->block_ptr,half),
           pix->block_ptr->bend - half);
    pix->spare_block->brec = get_free(pix);
    pix->spare_block->bend = pix->block_ptr->bend - half;
    pix->spare_block->p0 = e->idxptr;
    pix->block_ptr->bend = half;
    e->idxptr = pix->spare_block->brec;
    if (ins_pos < half)
      ins_block(pix->block_ptr,pe,ins_pos);
    else if (ins_pos > half)
      {
         ins_pos -= ENT_SIZE(e);
         ins_block(pix->spare_block,pe,ins_pos - half);
         CB(pix, l) = e->idxptr;
         CO(pix, l) = CO(pix, l) - half;
      }
    write_if(pix->ixfile, pix->spare_block->brec,
             (char *) pix->spare_block, sizeof(BLOCK));
} /* split */


void  ins_level(IX_DESC *pix, int l, ENTRY *e)
{
    int  i;
    if ( l < 0)
    {
      for (i = 1; i < MAX_LEVELS; i++)
      {
        CO(pix, MAX_LEVELS - i) = CO(pix, MAX_LEVELS - i - 1);
        CB(pix, MAX_LEVELS - i) = CB(pix, MAX_LEVELS - i - 1);
      }
      memcpy(pix->spare_block, &(pix->root), sizeof(BLOCK));
      pix->spare_block->brec = get_free(pix);
      write_if(pix->ixfile, pix->spare_block->brec,
                  (char *) pix->spare_block, sizeof(BLOCK));
      pix->root.p0 = pix->spare_block->brec;
      copy_entry((ENTRY *) (pix->root.entries), e);
      pix->root.bend = ENT_SIZE(e);
      CO(pix, 0) = 0;
      pix->level = 0;
      (pix->dx.nl)++;
    }
    else ins_block(pix->block_ptr,e,CO(pix, l));
} /* ins_level */


int  insert_ix(ENTRY *pe, IX_DESC *pix)
{
  ENTRY    e, ee;
  ee = *pe;
  do
  {
    if(CO(pix, pix->level) >= 0)
      CO(pix, pix->level) +=
                  ENT_SIZE(ENT_ADR(pix->block_ptr, CO(pix, pix->level)));
    else
      CO(pix, pix->level) = 0;
    update_block(pix);
    if( (pix->block_ptr->bend + ENT_SIZE(&ee)) <= split_size)
    {
      ins_level(pix, pix->level, &ee);
      break;
    }
    else
    {
      split(pix, pix->level,&ee, &e);
      ee = e;
      pix->level--;
      if (pix->level < 0)
      {
        ins_level(pix, pix->level, &e);
        break;
      }
      retrieve_block(pix, pix->level, CB(pix, pix->level));
    }
  } while (1);
  return ( IX_OK );
} /* insert_ix */


/*  BPLUS find and add key functions  */

int  find_ix(ENTRY *pe, IX_DESC *pix, int find)
{
    int      level, off, ret;
    RECPOS   ads;
    ENTRY    found;

    ads = 0L;
    level = ret = 0;
    while (ads != NULLREC)
    {
      pix->level = level;
      retrieve_block(pix, level, ads);
      if (find_block(pix, pe, &off) == 0) ret = 1;
      if (ret && find) break;
      if (off == -1)
        ads = pix->block_ptr->p0;
      else
        ads = ENT_ADR(pix->block_ptr, off)->idxptr;
      CO(pix, level++) = off;
   }
   return ( ret );
} /* find_ix */


int  find_key(ENTRY *pe, IX_DESC *pix)
{
    int ret;
    ret = find_ix(pe, pix, 1);
    if ( ret ) copy_entry(pe, ENT_ADR(pix->block_ptr, CO(pix, pix->level)));
    return ( ret );
} /* find_key */


int  add_key(ENTRY *pe, IX_DESC *pix)
{
  int ret;

  ret = find_ix(pe, pix, 0);
  if ( ret && (pix->duplicate == 0)) return ( IX_FAIL );
  pe->idxptr = NULLREC;
  return (insert_ix(pe, pix));
} /* add_key */


int locate_key(ENTRY *pe, IX_DESC *pix)
{
    int ret;
    ENTRY e;

    ret = find_ix(pe, pix, 1);
    if (ret) copy_entry(pe, ENT_ADR(pix->block_ptr, CO(pix, pix->level)));
    else if (next_key(pe,pix) == EOIX) ret = EOIX;
    return ( ret );
} /* locate_key */


int find_exact(ENTRY *pe, IX_DESC *pix)
{
    int  ret;
    ENTRY e;

    copy_entry(&e, pe);
    ret = find_key(&e, pix);
    if ( ret && pix->duplicate)
    {
      do
      {
        ret = (e.recptr == pe->recptr);
        if( !ret )  ret = next_key(&e, pix);
        if (ret) ret = (strcmp(e.key, pe->key) == 0);
        if ( !ret ) return ( 0 );
      } while ( !ret );
    }
    copy_entry(pe, &e);

    return ( ret );
} /* find_exact */


/* BPLUS delete key functions */

int delete_key(ENTRY *pe, IX_DESC *pix)
{
     ENTRY   e;
     RECPOS  ads;
     int     h, leveli, levelf;

     if (!find_exact(pe, pix))  return( IX_FAIL );
     h = 1;
     if ((ads = pe->idxptr) != NULLREC)
     {
       leveli = pix->level;
       do
       {
         retrieve_block(pix, ++(pix->level), ads);
         CO(pix, pix->level) = -1;
       }
       while ((ads = pix->block_ptr->p0) != NULLREC);
       CO(pix, pix->level) = 0;
       copy_entry(&e, ENT_ADR(pix->block_ptr, CO(pix, pix->level)));
       levelf = pix->level;
       pix->level = leveli;
       replace_entry(pix, &e);
       pix->level = levelf;
    }
    while ( h )
    {
      retrieve_block(pix, pix->level, CB(pix, pix->level));
      del_block(pix->block_ptr, CO(pix, pix->level));
      update_block(pix);
      if ( (pix->level == 0) && (pix->block_ptr->bend == 0))
      /* tree was reduced in height */
      {
        if (pix->root.p0 != NULLREC)
        {
          retrieve_block(pix, ++pix->level, pix->root.p0);
          memcpy(&(pix->root), pix->block_ptr, sizeof(BLOCK));
          (pix->dx.nl)--;
          write_free(pix, pix->block_ptr->brec, pix->block_ptr);
          BUFDIRTY(pix, pix->cache_ptr) = 0;
          BUFHANDLE(pix, pix->cache_ptr) = 0;
        }
        break;
      }
      h = (pix->block_ptr->bend < comb_size) && (pix->level > 0);
      if ( h )
        h = combineblk(pix, CB(pix, pix->level), pix->block_ptr->bend);
    }
    return( IX_OK );
} /* delete_key */


int  combineblk(IX_DESC *pix, RECPOS ads, int size)
{
    ENTRY  e;
    RECPOS address;
    int    esize, off, ret, saveoff, ibuff;

    ret = 0;
    saveoff = CO(pix, --(pix->level));
    retrieve_block(pix, pix->level, CB(pix, pix->level));
    if ((off = next_entry(pix, saveoff )) < pix->block_ptr->bend)
    /* combine with page on right */
    {
      if ( (ENT_SIZE(ENT_ADR(pix->block_ptr, off)) + size) < split_size)
      {
        copy_entry(&e, ENT_ADR(pix->block_ptr, off));
        address = ENT_ADR(pix->block_ptr, CO(pix, pix->level))->idxptr;
        retrieve_block(pix, ++pix->level, address);
        ibuff = pix->cache_ptr;
        pix->spare_block = pix->block_ptr;
        retrieve_block(pix, pix->level, ads);
        esize = ENT_SIZE(&e);
        if(((pix->block_ptr->bend + pix->spare_block->bend + esize) >= split_size)
           && (pix->spare_block->bend <= pix->block_ptr->bend + esize))
        return( ret );
        e.idxptr = pix->spare_block->p0;
        ins_block(pix->block_ptr, &e, pix->block_ptr->bend);
        update_block(pix);
        if ((pix->block_ptr->bend + pix->spare_block->bend) < split_size)
        /* combine the blocks */
        {
          memcpy(ENT_ADR(pix->block_ptr, pix->block_ptr->bend),
                       ENT_ADR(pix->spare_block, 0),
                       pix->spare_block->bend);
          pix->block_ptr->bend += pix->spare_block->bend;
          write_free(pix, pix->spare_block->brec, pix->spare_block);
          BUFDIRTY(pix, ibuff) = 0;
          BUFHANDLE(pix, ibuff) = 0;
          --pix->level;
          ret = 1;
        }
        else
        /* move an entry up to replace the one moved */
        {
          copy_entry(&e, ENT_ADR(pix->spare_block, 0));
          esize = ENT_SIZE(&e);
          movedown(pix->spare_block, 0, esize);
          pix->spare_block->bend -= esize;
          pix->spare_block->p0 = e.idxptr;
          BUFDIRTY(pix, ibuff) = 1;
          --(pix->level);
          replace_entry(pix, &e);
        }
      }
    }
    else
    /* move from page on left */
    {
      if ( (ENT_SIZE(ENT_ADR(pix->block_ptr, CO(pix, pix->level))) + size)
                 < split_size)
      {
        copy_entry(&e, ENT_ADR(pix->block_ptr, saveoff));
        off = prev_entry(pix, saveoff);
        if (CO(pix, pix->level) == -1) address = pix->block_ptr->p0;
        else address = ENT_ADR(pix->block_ptr, CO(pix, pix->level))->idxptr;
        retrieve_block(pix, ++pix->level, address);
        off = last_entry(pix);
        ibuff = pix->cache_ptr;
        pix->spare_block = pix->block_ptr;
        retrieve_block(pix, pix->level, ads);
        esize = ENT_SIZE(&e);
        if(((pix->block_ptr->bend + pix->spare_block->bend + esize) >= split_size)
            && (pix->spare_block->bend <= pix->block_ptr->bend + esize))
               return( ret );
        BUFDIRTY(pix, ibuff) = 1;
        CO(pix, pix->level) = 0;
        e.idxptr = pix->block_ptr->p0;
        ins_block(pix->block_ptr, &e, 0);
        if ((pix->block_ptr->bend + pix->spare_block->bend) < split_size)
        /* combine the blocks */
        {
          memcpy(ENT_ADR(pix->spare_block, pix->spare_block->bend),
                 ENT_ADR(pix->block_ptr, 0),
          pix->block_ptr->bend);
          pix->spare_block->bend += pix->block_ptr->bend;
          write_free(pix, pix->block_ptr->brec, pix->block_ptr);
          BUFDIRTY(pix, pix->cache_ptr) = 0;
          BUFHANDLE(pix, pix->cache_ptr) = 0;
          CO(pix, --(pix->level)) = saveoff;
          ret = 1;
        }
        else
        /* move an entry up to replace the one moved */
        {
          pix->block_ptr->p0 = ENT_ADR(pix->spare_block,off)->idxptr;
          copy_entry(&e, ENT_ADR(pix->spare_block, off));
          pix->spare_block->bend = off;
          update_block(pix);
          CO(pix, --(pix->level)) = saveoff;
          replace_entry(pix, &e);
        }
      }
    }
    return ( ret );
} /* combineblk */


void  replace_entry(IX_DESC *pix, ENTRY *pe)
{
  retrieve_block(pix, pix->level, CB(pix, pix->level));
  pe->idxptr = ENT_ADR(pix->block_ptr, CO(pix, pix->level))->idxptr;
  del_block(pix->block_ptr, CO(pix, pix->level));
  prev_entry(pix, CO(pix, pix->level));
  insert_ix(pe, pix);
} /* replace_entry */

