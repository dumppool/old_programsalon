//
//     Copyright (c) 1990 by Optimal Software, All Rights Reserved
//

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>

static void check4( char *name, void *(*func)( void *ptr, size_t nbytes ) );
static void report( char *name, void *old, size_t size, void *new );

#define PNAME(ptr) ( (ptr) == NULL ? "NULL   " : "pointer" )

//
//    Demonstrate the actual behavior of the MSC heap manager
//
void main()
{
size_t size = 0xFFFF;

void *malloc0 = malloc(0);

#if defined( M_I86SM ) || defined( M_I86MM )

   printf("Statistics on \"near\" heap are uninteresting\n");

   exit(0);

#endif

printf("\nOriginal MSC heap manager\n\n");

//
//    To change the value returned by _msize(NULL) change the size
//    parameter in the following call to _expand().
//
_expand( NULL, 1234 );    /* set value of _msize(NULL) */

printf("  _msize( NULL ) returns %u\n\n", _msize(NULL) );

printf("  malloc( 0 ) returns %s to %u bytes\n\n", PNAME(malloc0), _msize(malloc0) );

check4( "_expand", _expand );

check4( "realloc", realloc );

while( size > 0
   &&  malloc( size ) == NULL )

   size--;

printf("  Allocation limit is %u bytes per block\n\n", size );

exit( !(_heapchk() == _HEAPOK) );
}

static void check4( char *name, void *(*func)( void *ptr, size_t nbytes ) )
{
void *ptr1 = malloc( 64);
void *ptr2 = malloc(256);

void *test00 = (*func)( NULL,   0 );
void *test01 = (*func)( NULL, 128 );
void *test10 = (*func)( ptr1,   0 );
void *test11 = (*func)( ptr2, 128 );

report( name, NULL,   0, test00 );
report( name, NULL, 128, test01 );
report( name, ptr1,   0, test10 );
report( name, ptr2, 128, test11 );
printf("\n");
}

static void report( char *name, void *old, size_t size, void *new )
{
printf( "  %s( %s, %3d ) returns %s",
        name,
        old == NULL ? " NULL" : "!NULL",
        size,
        PNAME( new ) );

if (new != NULL)

   printf(" to %3u bytes", _msize( new ) );

printf("\n");
}



