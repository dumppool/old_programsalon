# CCM Library compilation script
#     run from distribution directory:  'makelibs.sh'
# when installing on an Intel based platform
#     respond with  y  to the prompt
# otherwise respond  n  ,  and run the non_intel script first

LST="cfit complex fft geom intg matrix roots sfunc simu sort statf tseries util xarm"
MDR=`pwd`
LSOD=$MDR/tmp
echo "Intel platform ? (y/n)"
read F
for dr in $LST
  do
    cd $MDR/$dr
    echo `pwd`
    cc -c -O3 *.c
    mv *.o $LSOD
  done
if [ $F = "y" ]
  then cd $MDR/matrix
    cc -c -O3 solv.s
    mv *.o $LSOD
    cd $MDR/simu
    cc -c -O3 *.s
    mv *.o $LSOD
fi
cd $LSOD
ar r ccm.a *.o
ld -shared -soname,lccm.so -o lccm.so *.o
rm *.o
