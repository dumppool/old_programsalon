/*  numcmp.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
dubcmp(x,y)
double *x,*y;
{ if(*x > *y) return 1;
  if(*x < *y) return -1;
  return 0;
}
intcmp(x,y)
int *x,*y;
{ if(*x > *y) return 1;
  if(*x < *y) return -1;
  return 0;
}
unicmp(x,y)
unsigned *x,*y;
{ if(*x > *y) return 1;
  if(*x < *y) return -1;
  return 0;
}
