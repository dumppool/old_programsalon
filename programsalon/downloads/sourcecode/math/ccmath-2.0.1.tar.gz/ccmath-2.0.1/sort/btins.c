/*  btins.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include "tree.h"
struct tnode *btins(kin,hd)
char *kin; struct tnode *hd;
{ struct tnode **v; int ef; char *malloc();
  while(hd!=NULL){
    if((ef=strcmp(kin,hd->key))==0) return hd;
    else if(ef<0) v= &(hd->pl); else v= &(hd->pr);
    hd= *v;
   }
  hd= *v=(struct tnode *)malloc(sizeof(*hd));
  hd->key=kin; hd->pr=hd->pl=NULL;
  return hd;
}
