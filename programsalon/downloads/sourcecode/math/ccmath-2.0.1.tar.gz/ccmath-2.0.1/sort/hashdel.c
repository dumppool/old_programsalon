/*  hashdel.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include "hash.h"
hashdel(kin)
char *kin;
{ int hv,m; struct tabl *pe,*ps;
  extern struct tabl *harray[];
  hv=hval(kin); pe=harray[hv]; ps=NULL;
  while(pe!=NULL){
    if((m=strcmp(kin,pe->key))==0) break;
    if(m<0) return 0; ps=pe; pe=pe->pt;
   }
  if(pe==NULL) return 0;
  if(ps!=NULL) ps->pt=pe->pt; else harray[hv]=pe->pt;
  free(pe); return 1;
}
