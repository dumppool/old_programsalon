/*  tsearch.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include "tree.h"
struct tnode *tsearch(kin,hd)
char *kin; struct tnode *hd;
{ int ef;
  while(hd!=NULL){
     if((ef=strcmp(kin,hd->key))==0) return hd;
     if(ef<0) hd=hd->pl; else hd=hd->pr;
   }
  return hd;
}
