/*  hfind.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include "hash.h"
struct tabl *hfind(kin)
char *kin;
{ int hv,m; struct tabl *pe;
  extern struct tabl *harray[];
  hv=hval(kin); pe=harray[hv];
  while(pe!=NULL){
    if((m=strcmp(kin,pe->key))==0) return pe;
    if(m<0) return NULL; pe=pe->pt;
   }
  return NULL;
}
