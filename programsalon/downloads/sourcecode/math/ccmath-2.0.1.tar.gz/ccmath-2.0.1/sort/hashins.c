/*  hashins.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include "hash.h"
struct tabl *hashins(kin)
char *kin;
{ int hv,m; struct tabl *pe,*ps,*pc;
  extern struct tabl *harray[]; char *malloc();
  hv=hval(kin); pe=harray[hv]; ps=NULL;
  while(pe!=NULL){
    if((m=strcmp(kin,pe->key))==0) return pe;
    if(m<0) break; ps=pe; pe=pe->pt;
   }
  pc=(struct tabl *)malloc(sizeof(*pe));
  pc->key=kin; pc->pt=pe;
  if(ps==NULL) harray[hv]=pc; else ps->pt=pc;
  return pc;
}
