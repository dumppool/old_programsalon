/*  armaf.h    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#ifndef NULL
#define NULL 0L
#endif
struct mcof {double cf; int lag;};
struct fmod {int fac; double val;};

