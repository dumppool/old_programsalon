/*  sdiff.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#define MXD 6
static double f[MXD];
double sdiff(y,nd,k)
double y; int nd,k;
{ double s;
  if(k==0) for(k=0; k<nd ;) f[k++]=0.;
  for(k=0; k<nd ;){
    s=y-f[k]; f[k++]=y; y=s; }
  return s;
}
double sintg(y,nd,k)
double y; int nd,k;
{ double s;
  if(k==0) for(k=0; k<nd ;) f[k++]=0.;
  for(k=nd-1; k>=0 ;){
    s=f[k]; f[k--]+=y; y=s; }
  return f[0];
}
