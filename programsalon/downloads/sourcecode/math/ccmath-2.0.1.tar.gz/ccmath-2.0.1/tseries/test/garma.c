/*  garma.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  sarma  setsim     (generates an ARMA model test series)

    Uses:  nrml  setnrml

    Input parameters:  n -> integer: length of series

                       control_file -> name of model definition file

                               [ ts?.dat -> time series model ]

                       outfile -> name of output file
                                  [binary data -> a series size header
                                   and the values of the series]
*/
#include <stdlib.h>
#include "ccmath.h"
double *y;
struct mcof *par,*pma; int nar,nma,np;
main(na,av)
int na; char **av;
{ double z; FILE *fp,*fo;
  int n,i,j,k; long seed;
  struct mcof *pa; char cfl[32],ofl[32];
  if(na!=4){ printf("para: n control_file outfile\n"); exit(-1);}
  n=atoi(*++av);
  y=(double *)calloc(n,sizeof(*y));
  fp=fopen(*++av,"r"); strcpy(cfl,*av);
  fo=fopen(*++av,"wb"); strcpy(ofl,*av);
  fscanf(fp,"%d %d",&nar,&nma); np=nar+nma;
  par=(struct mcof *)calloc(np,sizeof(*pa)); pma=par+nar;
  for(j=0,pa=par; j<np ;++j,++pa){
    fscanf(fp,"%lf %d",&(pa->cf),&(pa->lag));
    pa->lag-=1;
   }
  fscanf(fp,"%lu",&seed);
  setnrml(seed);

/* initialize series simulation */
  setsim(1); n+=25;
  for(j=k=0; j<n ;++j){

/* generate time series values (skip first 25) */
    z=sarma(nrml()); if(j>=25) y[k++]=z;

   }

/* write series to output file with size as a header record */
  n-=25; fwrite((void *)&n,sizeof(int),1,fo);
  k=fwrite((void *)y,sizeof(double),n,fo);
  if(k!=n){ printf("I/O error\n"); exit(1);}

/* write model specification */
  printf("  control file = %s\n",cfl);
  printf("  output file  = %s\n",ofl);
  printf("  %d points generated\n",n);
  printf("    random seed= %lu\n",seed);
  if(nar){
    printf(" autoregressive parameters and lags\n");
    for(j=0,pa=par; j<nar ;j++,pa++)
      printf("%f  %d\n",pa->cf,pa->lag+1);
   }
  if(nma){
    printf(" moving average paramerers and lags\n");
    for(j=0,pa=pma; j<nma ;j++,pa++)
      printf("%f  %d\n",pa->cf,pa->lag+1);
   }
}
/*  Test output

  control file = data/ts0.dat
  output file  = ts0.b
  400 points generated
    random seed= 123456789
 autoregressive parameters and lags
0.800000  1
-0.600000  2
 moving average paramerers and lags
0.300000  1

 length of ARMA series = 400
    1   -1.492021
    2   -1.557274
    3    1.044174
    4    1.328194
    5    1.785135
    6   -0.438948
    7   -1.613255
    8   -0.137244
    9    1.244463
   10    2.069642
   11    0.774102
   12   -1.536896
   13   -2.151043
   14   -1.508561
   15   -0.870966
   16    2.009030
   17    1.884057
   18   -1.380098
   19   -3.682623
   20   -0.694761
*/
