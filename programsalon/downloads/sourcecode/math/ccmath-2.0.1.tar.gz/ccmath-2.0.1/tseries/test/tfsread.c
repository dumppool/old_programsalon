/*  tfsread.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Utility reads and displays contents of a binary factor model
    time series file.

    Input parameter:  binary_in_file -> name of input file
                                        [ created by gfarma ]
*/
#include <stdlib.h>
#include "ccmath.h"
main(na,av)
int na; char **av;
{ FILE *fin; int i,j,k,n,m; char xl[4];
  struct fmod y[20];
  if(na!=2){ printf("para: binary_input_file\n"); exit(1);}
  fin=fopen(*++av,"rb");
  fread((void *)&n,sizeof(int),1,fin);

/* read and print series in blocks of 20 */
  printf(" series length = %d\n",n);
  fprintf(stderr,"enter: q or Q to quit\n");
  for(j=0,m=20;;){
    k=fread((void *)y,sizeof(struct fmod),m,fin);
    for(i=0; i<k ;++i)
      printf("%4d  %2d %10.6f\n",++j,y[i].fac,y[i].val);
    if(k<m) break;
    gets(xl); if(xl[0]=='q' || xl[0]=='Q') break;
   }
}
/*  Test output

    (first 20 factors and values from a series generated
     using data/tfs0.dat)

 series length = 400
   1   0  -2.071880
   2   1  -1.088331
   3   1  -0.179773
   4   1   0.847146
   5   0  -0.547736
   6   0  -1.139061
   7   0  -2.343127
   8   0  -1.620442
   9   0  -0.196469
  10   1   3.474594
  11   0   1.837482
  12   0  -0.367609
  13   0  -0.677050
  14   1   1.771577
  15   1   1.688654
  16   0   0.704925
  17   1   2.108264
  18   0  -0.007099
  19   0  -1.147067
  20   0  -1.867540
*/
