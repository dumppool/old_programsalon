/*  tparma.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  parma

    Uses:  sarma  setsim  nrml  setnrml

    Input parameter:  model_file -> name of file specifying an ARMA
                                    time series model [ ts?.dat ]
*/
#include <stdlib.h>
#include "ccmath.h"
struct mcof *par,*pma; int nar,nma,np;
double x[50],e[50];
main(na,av)
int na; char **av;
{ struct mcof *pa; int n,i,j,j1;
  double y; long seed;
  FILE *fp;
  if(na!=2){ printf("para: model_file\n"); exit(-1);}
  printf("     Test of Time Series Prediction\n\n");
  fp=fopen(*++av,"r");
  printf("  model file: %s\n",*av);

/* load and print model data */
  fscanf(fp,"%d %d",&nar,&nma); np=nar+nma;
  par=(struct mcof *)calloc(np,sizeof(*pa));
  pma=par+nar;
  printf(" model inputs:\n");
  for(j=0,pa=par; j<np ;++j,++pa){
    fscanf(fp,"%lf %d",&(pa->cf),&(pa->lag));
    printf(" %6.3f  %2d  ",pa->cf,pa->lag);
    if(j<nar) printf("ar\n"); else printf("ma\n");
    pa->lag-=1;
   }

/* initialize series simulation */
  fscanf(fp,"%ld",&seed);
  setnrml(seed);
  printf("  random seed= %ld\n",seed);
  setsim(1); n=45;
  printf("    x          e           p1");
  printf("          p2          p3\n");

/* generate series */
  for(j=0; j<n ;++j){
    x[j]=sarma(e[j]=nrml());
    if(j>=25){
      printf(" %10.2e  %10.2e",x[j],e[j]);
      for(i=1,j1=j+i; i<4 ;++i){

/* compute one step predictions of the series */
        y=parma(x+j1,e+j1); ++j1;

        printf("  %10.2e",y);
       }
      printf("\n");
     }
   }
}
/*  Test output

     Test of Time Series Prediction

  model file: data/ts2.dat
 model inputs:
  0.800   1  ar
  0.400   1  ma
  random seed= 2137714571
    x          e           p1          p2          p3
  -1.76e-01   -1.41e-01   -8.44e-02   -6.75e-02   -5.40e-02
   7.97e-01    8.82e-01    2.85e-01    2.28e-01    1.82e-01
  -9.31e-01   -1.22e+00   -2.58e-01   -2.07e-01   -1.65e-01
   1.00e+00    1.26e+00    2.97e-01    2.38e-01    1.90e-01
   7.69e-01    4.72e-01    4.27e-01    3.41e-01    2.73e-01
  -3.33e-03   -4.30e-01    1.69e-01    1.35e-01    1.08e-01
  -8.34e-01   -1.00e+00   -2.66e-01   -2.13e-01   -1.70e-01
  -1.33e+00   -1.06e+00   -6.36e-01   -5.09e-01   -4.07e-01
  -3.77e-01    2.59e-01   -4.06e-01   -3.24e-01   -2.60e-01
   4.96e-01    9.01e-01    3.61e-02    2.89e-02    2.31e-02
  -1.70e+00   -1.74e+00   -6.66e-01   -5.33e-01   -4.26e-01
  -4.98e-01    1.68e-01   -4.66e-01   -3.72e-01   -2.98e-01
   7.81e-01    1.25e+00    1.26e-01    1.01e-01    8.07e-02
   3.48e-02   -9.13e-02    6.44e-02    5.15e-02    4.12e-02
  -2.85e-01   -3.49e-01   -8.81e-02   -7.05e-02   -5.64e-02
  -4.87e-01   -3.99e-01   -2.30e-01   -1.84e-01   -1.47e-01
  -5.63e-01   -3.33e-01   -3.17e-01   -2.54e-01   -2.03e-01
  -6.58e-01   -3.41e-01   -3.90e-01   -3.12e-01   -2.50e-01
  -2.29e-01    1.61e-01   -2.48e-01   -1.98e-01   -1.59e-01
  -3.31e+00   -3.06e+00   -1.42e+00   -1.14e+00   -9.10e-01
*/
