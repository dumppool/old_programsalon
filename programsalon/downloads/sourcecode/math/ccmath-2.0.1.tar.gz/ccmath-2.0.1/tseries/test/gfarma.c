/*  gfarma.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  sarma  setsim  sintg     (generate an ARIMA factor model)

    Uses:  nrml  setnrml  bran  setbran

    Input parameters:  n -> integer: length of generated series

                       control_file -> name of input file specifing model

                             [ tsf?.dat -> time series factor model ]

                       outfile -> name of file for series output
                                  [binary data -> a series size header
                                   and the values of the generated series]
*/
#include <stdlib.h>
#include "ccmath.h"
struct mcof *pfc,*par,*pma;
int nfc,nar,nma,np,ndif;
struct fmod *y;
main(na,av)
int na; char *av[];
{ struct mcof *pa; int n,np,i,j,k,m;
  double sm,z; long seed;
  FILE *fp,*fout;
  char cfl[32],ofl[32];
  if(na!=4){ printf("para: n control_file outfile\n"); exit(-1);}
  n=atoi(*++av);
  y=(struct fmod *)calloc(n,sizeof(*y));
  fp=fopen(*++av,"r"); strcpy(cfl,*av);
  fout=fopen(*++av,"wb"); strcpy(ofl,*av);
/* read model parameters from control file */
  fscanf(fp,"%d %d %d %d",&nfc,&nar,&nma,&ndif);
  np=nma+nar+nfc;
  pfc=(struct mcof *)calloc(np,sizeof(*pa));
  par=pfc+nfc; pma=par+nar;
  for(j=0,pa=pfc; j<np ;j++,++pa){
     fscanf(fp,"%lf %d",&(pa->cf),&(pa->lag));
     pa->lag-=1;
    }
  fscanf(fp,"%ld",&seed);
  setnrml(seed); setbran(seed);

/* initialize series simulation */
  setsim(1); n+=25;

  for(j=0,k=0,sm=0.; j<n ;j++){

/* generate series values */
      z=sarma(nrml());

/* integrate series values if difference is nonzero */
      if(ndif) z=sintg(z,ndif,j);


/* generate factors and add factor levels to integrated series */
      if(j>=25){ y[k].fac=m=bran(nfc);
           sm+=( y[k++].val=z+(pfc+m)->cf);}
    }

/* write series size header and series values to output file */
  n-=25; fwrite((void *)&n,sizeof(int),1,fout);
  k=fwrite((void *)y,sizeof(y[0]),n,fout);
  if(k!=n){ printf("I/O error\n"); exit(1);}

/* write model specification */
  printf("  control file = %s\n",cfl);
  printf("  output file  = %s\n",ofl);
  printf("  %d points generated\n",n);
  printf("  random seed= %lu\n",seed);
  printf(" factor parameters:\n");
  for(j=0,pa=pfc; j<nfc ;j++,pa++)
      printf("%f\n",pa->cf);
  if(nar){
    printf(" autoregressive parameters and lags\n");
    for(j=0,pa=par; j<nar ;j++,pa++)
      printf("%f  %d\n",pa->cf,pa->lag+1);
   }
  if(nma){
    printf(" moving average paramerers and lags\n");
    for(j=0,pa=pma; j<nma ;j++,pa++)
      printf("%f  %d\n",pa->cf,pa->lag+1);
   }
  printf("  difference order = %d\n",ndif);
  printf("  series mean = %.4f\n",sm/n);
}
/*  Test output

  control file = data/tfs0.dat
  output file  = tfs0.b
  400 points generated
  random seed= 123456789
 factor parameters:
0.000000
1.000000
 autoregressive parameters and lags
0.800000  1
-0.400000  2
 moving average paramerers and lags
-0.500000  1
  difference order = 0
  series mean = 0.2782

 series length = 400
   1   0  -2.212230
   2   0  -3.280324
   3   0  -1.486362
   4   1   1.454822
   5   0   2.186266
   6   1   2.539846
   7   1   0.623113
   8   1   0.656758
   9   1   1.879724
  10   0   2.327022
  11   0   2.316440
  12   0   0.182498
  13   0  -1.916793
  14   0  -2.885694
  15   1  -2.235292
  16   0  -0.618697
  17   1   2.698323
  18   1   1.071088
  19   1  -2.372047
  20   0  -2.851726
*/
