/*  tsread.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Utility reads and displays values in a binary ARMA model time
    series file.

    Input parameter:  binary_in_file -> name of binary ARMA time series
                                        file [ created by garma ]
*/
#include <stdlib.h>
#include "ccmath.h"
main(na,av)
int na; char **av;
{ FILE *fp; double y[20];
  int i,j,k,n,m; char lx[4];
  if(na!=2){ printf("para: binary_in_file\n"); exit(-1);}
  fp=fopen(*++av,"rb");
  fread((void *)&n,sizeof(int),1,fp);
  printf(" length of ARMA series = %d\n",n);

/* read and display series in blocks of 20 */
  fprintf(stderr,"enter q or Q to quit\n");
  for(m=20,j=0;;){
    k=fread((void *)y,sizeof(y[0]),m,fp);
    for(i=0; i<k ;++i) printf(" %4d %11.6f\n",++j,y[i]);
    if(k<m) break;
    gets(lx); if(lx[0]=='q' || lx[0]=='Q') break;
   }
}
/*  Test output

    (first 20 values from series generated using data/ts0.dat)
    
 length of ARMA series = 400
    1   -1.677979
    2   -0.293827
    3    0.284102
    4    0.704379
    5   -0.641409
    6   -0.911335
    7   -1.778801
    8    0.134777
    9    0.892696
   10    2.709296
   11   -0.222042
   12   -1.657804
   13   -0.659364
   14    1.260928
   15    0.458213
   16    0.605549
   17    0.392739
   18   -0.998428
   19   -1.074300
   20   -0.983728
*/
