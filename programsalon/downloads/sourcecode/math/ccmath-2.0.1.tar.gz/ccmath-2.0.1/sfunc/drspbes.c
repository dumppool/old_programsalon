/*  drspbes.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include <math.h>
double drspbes(x,n,f,p)
double x,*p; int n,f;
{ double y,jspbes(),yspbes(),kspbes();
  if(x==0.){
    if(f=='j'){ if(n==1) return 1./3.; else return 0.;}
    return HUGE_VAL;
   }
  if(p!=0L) y= *p*n/x; else y=0.;
  switch(f){
    case 'j': if(p==0L && n) y=jspbes(n,x)*n/x;
              return y-jspbes(++n,x);
    case 'y': if(p==0L && n) y=yspbes(n,x)*n/x;
              return y-yspbes(++n,x);
    case 'k': if(p==0L && n) y=kspbes(n,x)*n/x;
              y-=kspbes(++n,x);
              if(x>0.) return y; else return -y;
   } return 0.;
}
