/*  tdrbes.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  drbes

    Prompted input:  at prompt  'type(j,y,i,k) '
                         enter  j    {to compute dJ(v,x)/dx}
                                y    {to compute dN(v,x)/dx}
                                i    {to compute dI(v,x)/dx}
                                k    {to compute dK(v,x)/dx}

                     at prompt 'order '
                         enter  v    { real order with v > 0 }
*/
#include "ccmath.h"
#include <math.h>
main()
{ double v,x,dx,f; char t[2];
  printf("     Bessel Function Derivatives Test\n");
  printf("type(j,y,i,k) "); scanf("%s",t);
  switch(t[0]){
    case 'j': printf(" dJ(v,x)/dx\n"); break;
    case 'y': printf(" dN(v,x)/dx\n"); break;
    case 'i': printf(" dI(v,x)/dx\n"); break;
    case 'k': printf(" dK(v,x)/dx\n"); break;
   }
  printf("order "); scanf("%lf",&v);
  printf(" order v= %.2f\n",v);
  for(x=dx=1.; x<5.1 ;x+=dx){

/* compute Bessel function derivatives */
    f=drbes(x,v,t[0],0L);

    printf(" %6.2f   %16.9e\n",x,f); }
}
/* Test output

     Bessel Function Derivatives Test
  dJ(v,x)/dx
  order v= 0.00
   1.00   -4.400505857e-001
   2.00   -5.767248078e-001
   3.00   -3.390589585e-001
   4.00   6.604332802e-002
   5.00   3.275791376e-001

        Bessel Function Derivatives Test
  dN(v,x)/dx
  order v= 2.30
   1.00   4.233060404e+000
   2.00   5.612797098e-001
   3.00   4.110031448e-001
   4.00   3.418366582e-001
   5.00   1.119654120e-001

        Bessel Function Derivatives Test
  dI(v,x)/dx
  order v= 4.50
   1.00   4.055269384e-003
   2.00   5.547527821e-002
   3.00   3.096205351e-001
   4.00   1.254918692e+000
   5.00   4.373491960e+000

        Bessel Function Derivatives Test
  dK(v,x)/dx
  order v= 3.25
   1.00   -3.766688974e+001
   2.00   -1.704264579e+000
   3.00   -2.344344551e-001
   4.00   -4.821152089e-002
   5.00   -1.202528422e-002
*/
