/*  tgaml.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  gaml
*/
#include "ccmath.h"
#include <math.h>
main()
{ double x,y,z;
  printf("     Test of Gamma Function Evaluation\n");
  printf("    x       log(gamma(x))            gamma(x)\n");  
  for(x=.5; x<10.1 ; x+=.5){

/* compute the logarithm of the gamma function and the gamma function */
    y=gaml(x); z=exp(y);

    printf(" %6.3f  %16.12f  %19.11e\n",x,y,z);
   }
}
/* Test output

     Test of Gamma Function Evaluation
    x       log(gamma(x))            gamma(x)
  0.500    0.572364942925   1.77245385091e+000
  1.000    0.000000000000   1.00000000000e+000
  1.500   -0.120782237635   8.86226925453e-001
  2.000    0.000000000000   1.00000000000e+000
  2.500    0.284682870473   1.32934038818e+000
  3.000    0.693147180560   2.00000000000e+000
  3.500    1.200973602347   3.32335097045e+000
  4.000    1.791759469228   6.00000000000e+000
  4.500    2.453736570842   1.16317283966e+001
  5.000    3.178053830348   2.40000000000e+001
  5.500    3.957813967619   5.23427777846e+001
  6.000    4.787491742782   1.20000000000e+002
  6.500    5.662562059857   2.87885277815e+002
  7.000    6.579251212010   7.20000000000e+002
  7.500    7.534364236759   1.87125430580e+003
  8.000    8.525161361065   5.04000000000e+003
  8.500    9.549267257301   1.40344072935e+004
  9.000   10.604602902745   4.03200000000e+004
  9.500   11.689333420797   1.19292461995e+005
 10.000   12.801827480081   3.62880000000e+005
*/
