/*  tspbes.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  jspbes  yspbes  kspbes

    Prompted input:  at prompt  'type(j,y,k,e) '
                                 enter  j  {to compute jspbes}
                                 enter  y  {to computr yspbes}
                                 enter  k  {to compute kspbes with x>0}
                                 enter  e  {to compute kspbes with x<0}

                     at prompt  'order '
                                 enter  n  {integer order n, with n>=0}

                     at prompt  'max-x interval '
                                 enter  xmx  dx  { tabulate function at
                                                   intervals dx while the
                                                   argument x <= xmx }
*/
#include "ccmath.h"
#include <math.h>
main()
{ double (*funs)();
  double x,dx,xmx,f; char t[2]; int n,m;
  printf("     Test of Spherical Bessel Functions\n");
  printf("type(j,y,k,e) "); scanf("%s",t);
  switch(t[0]){
    case 'j': funs=jspbes; printf("  j(n,x)\n"); break;
    case 'y': funs=yspbes; printf("  y(n,x)\n"); break;
    case 'k': funs=kspbes; printf("  k(n,x)\n"); break;
    case 'e': funs=kspbes; printf("  k(n,-x)\n");
   }
  printf("order "); scanf("%d",&n);
  printf(" order n= %d\n",n);
  printf("max-x interval ");
  scanf("%lf %lf",&xmx,&dx); xmx+=dx/4.;
  if(t[0]=='j') x=0.; else x=dx;
  if(t[0]=='e') m= -1; else m=1;
  for(; x<xmx ;x+=dx){

/* compute specified spherical Bessel function */
    f=(*funs)(n,m*x);

    printf(" %7.2f   %16.9e\n",x,f);
   }
}
/*  Test output

     Test of Spherical Bessel Functions
   j(n,x)
  order n= 0
    0.00   1.000000000e+000
    0.50   9.588510772e-001
    1.00   8.414709848e-001
    1.50   6.649966577e-001
    2.00   4.546487134e-001
    2.50   2.393888576e-001
    3.00   4.704000269e-002
    3.50   -1.002237793e-001
    4.00   -1.892006238e-001
    4.50   -2.172289150e-001
    5.00   -1.917848549e-001
    5.50   -1.282800592e-001
    6.00   -4.656924970e-002
    6.50   3.309538278e-002
    7.00   9.385522839e-002
    7.50   1.250666636e-001
    8.00   1.236697808e-001
    8.50   9.393966031e-002
    9.00   4.579094280e-002
    9.50   -7.910644259e-003
   10.00   -5.440211109e-002

     Test of Spherical Bessel Functions
   y(n,x)
  order n= 1
    0.50   -4.469181325e+000
    1.00   -1.381773291e+000
    1.50   -6.964354140e-001
    2.00   -3.506120043e-001
    2.50   -1.112058792e-001
    3.00   6.295916360e-002
    3.50   1.766692232e-001
    4.00   2.300533501e-001
    4.50   2.276385841e-001
    5.00   1.804383675e-001
    5.50   1.048529592e-001
    6.00   1.989785285e-002
    6.50   -5.620988280e-002
    7.00   -1.092409887e-001
    7.50   -1.312290692e-001
    8.00   -1.213963428e-001
    8.50   -8.560731563e-002
    9.00   -3.454242105e-002
    9.50   1.895964322e-002
   10.00   6.279282638e-002

     Test of Spherical Bessel Functions
   k(n,x)
  order n= 1
    0.50   3.639183958e+000
    1.00   7.357588823e-001
    1.50   2.479224002e-001
    2.00   1.015014624e-001
    2.50   4.596759923e-002
    3.00   2.212758594e-002
    3.50   1.109291636e-002
    4.00   5.723637153e-003
    4.50   3.017258319e-003
    5.00   1.617107280e-003
    5.50   8.781492347e-004
    6.00   4.819795899e-004
    6.50   2.668826970e-004
    7.00   1.488786883e-004
    7.50   8.357719371e-005
    8.00   4.717443205e-005
    8.50   2.675362638e-005
    9.00   1.523577828e-005
    9.50   8.708523145e-006
   10.00   4.993992274e-006

     Test of Spherical Bessel Functions
   k(n,-x)
  order n= 1
    0.50   3.297442541e+000
    1.00   0.000000000e+000
    1.50   -9.959309045e-001
    2.00   -1.847264025e+000
    2.50   -2.923798551e+000
    3.00   -4.463452650e+000
    3.50   -6.758255502e+000
    4.00   -1.023715313e+001
    4.50   -1.555851652e+001
    5.00   -2.374610546e+001
    5.50   -3.640045273e+001
    6.00   -5.603177687e+001
    6.50   -8.658648478e+001
    7.00   -1.342816112e+002
    7.50   -2.089293457e+002
    8.00   -3.260422798e+002
    8.50   -5.101836166e+002
    9.00   -8.003045854e+002
    9.50   -1.258256821e+003
   10.00   -1.982381922e+003
*/
