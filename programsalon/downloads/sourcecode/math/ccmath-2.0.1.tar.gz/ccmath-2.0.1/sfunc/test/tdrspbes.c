/*  tdrspbes.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  drspbes

    Prompted input:  at prompt  'type(j,k,y) '
                         enter  j   {to compute dj(v,x)/dx}
                                k   {to compute dk(v,x)/dx}
                                y   {to compute dy(v,x)/dx}

                     at prompt 'order '
                         enter  n   { integer order with n >= 0 }

                     at prompt 'max-x interval '
                         enter  xmax delx    { tabulate function
                                               at intervals delx
                                               while x <= xmax }
*/
#include "ccmath.h"
#include <math.h>
main()
{ double x,dx,xmx,f; char t[2]; int n;
  printf("     Sperical Bessel Function Derivative Test\n");
  printf("type(j,k,y) "); scanf("%s",t);
  switch(t[0]){
    case 'j': printf(" dj(n,x)/dx\n"); break;
    case 'y': printf(" dy(n,x)/dx\n"); break;
    case 'k': printf(" dk(n,x)/dx\n"); break;
   }
  printf("order "); scanf("%d",&n);
  printf(" order n= %d\n",n);
  printf("max-x interval ");
  scanf("%lf %lf",&xmx,&dx); xmx+=dx/4.;
  if(t[0]=='j') x=0.; else x=dx;
  for(; x<xmx ;x+=dx){

/* compute derivative of spherical Bessel function */
    f=drspbes(x,n,t[0],0L);

    printf(" %6.2f   %16.9e\n",x,f); }
}
/*  Test output

     Sperical Bessel Function Derivative Test
  dj(n,x)/dx
  order n= 0

   0.00   0.000000000e+000
   2.00   -4.353977750e-001
   4.00   -1.161107493e-001
   6.00   1.677899227e-001
   8.00   -3.364622683e-002
  10.00   -7.846694180e-002

     Sperical Bessel Function Derivative Test
  dy(n,x)/dx
  order n= 3

   2.00   2.234741690e+000
   4.00   2.277710733e-001
   6.00   8.881070525e-002
   8.00   -1.044995752e-001
  10.00   -2.693831344e-002

     Sperical Bessel Function Derivative Test
  dk(n,x)/dx
  order n= 2

   2.00   -4.313812153e-001
   4.00   -1.237736534e-002
   6.00   -8.090371688e-004
   8.00   -6.953314724e-005
  10.00   -6.805449471e-006

     Sperical Bessel Function Derivative Test
  dk(n,x)/dx
  order n= -4

   2.00   -2.030029249e-001
   4.00   -9.157819444e-003
   6.00   -6.885422713e-004
   8.00   -6.289924273e-005
  10.00   -6.355990167e-006
*/
