/*  trcbes.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  rcbes  setrcb

    Uses:  (implicit) jbes  nbes  ibes  kbes

    Prompted input:  at prompt  'type(j,y,i,k) '
                                 enter  j  {to compute J}
                                        y  {to compute N}
                                        i  {to compute I}
                                        k  {to compute K}

                     at prompt  'direction(u,d) '
                                 enter  u  {for recursion up in order}
				          stable for N and K
                                        d  {for recursion down in order}
					  stable for J and I

                     at prompt  'starting order '
                                 enter  v  { real initial order with v >= 0 }

                     at prompt  'argument '
                                 emter  x  { real argument x, with x > 0 }
*/
#include "ccmath.h"
#include <math.h>
#include <stdio.h>
main()
{ double v,x,f[10]; int i;
  char ty[2],dr[2];
  printf("type(j,y,i,k) "); scanf("%s",ty);
  printf("direction(u,d) "); scanf("%s",dr);
  printf("starting order "); scanf("%lf",&v);
  printf("argument "); scanf("%lf",&x);
  switch(ty[0]){
    case 'j': printf(" J(v,x)\n"); break;
    case 'y': printf(" Y(v,x)\n"); break;
    case 'i': printf(" I(v,x)\n"); break;
    case 'k': printf(" K(v,x)\n"); break;
   }
  printf("  argument x= %.4f\n",x);

/* initialize recursion */
  setrcb(v,x,ty[0],dr[0],f,f+1);

  for(i=0; i<10 ;++i){

/* recursive computation of Bessel functions */
    if(i>=2) f[i]=rcbes();

    printf(" %6.2f  %17.10e\n",v,f[i]);
    if(dr[0]=='u') v+=1.; else v-=1.;
   }
}
/*  Test output

  J(v,x)
  argument x= 2.0000
  11.40  8.6376508522e-009
  10.40  9.7768393658e-008
   9.40  1.0081536432e-006
   8.40  9.3788758523e-006
   7.40  7.7774403516e-005
   6.40  5.6615171017e-004
   5.40  3.5455965416e-003
   4.40  1.8580069614e-002
   3.40  7.8206709761e-002
   2.40  2.4732274357e-001

  I(v,x)
  argument x= 2.5000
  13.20  2.0221881829e-009
  12.20  2.1531045323e-008
  11.20  2.1216519053e-007
  10.20  1.9225311525e-006
   9.20  1.5900019395e-005
   8.20  1.1894667390e-004
   7.20  7.9619020017e-004
   6.20  4.7050022269e-003
   5.20  2.4133001245e-002
   4.20  1.0509828741e-001

  Y(v,x)
  argument x= 5.1000
   1.40  2.7224466731e-001
   2.40  3.2976192606e-001
   3.40  3.8119498395e-002
   4.40  -2.7893592820e-001
   5.40  -5.1942070784e-001
   6.40  -8.2101380605e-001
   7.40  -1.5411629623e+000
   8.40  -3.6513806726e+000
   9.40  -1.0486914548e+001
  10.40  -3.5006265111e+001

  K(v,x)
  argument x= 0.8000
   2.30  4.2863097295e+000
   3.30  2.5784282930e+001
   4.30  2.1700664390e+002
   5.30  2.3586057049e+003
   6.30  3.1468532234e+004
   7.30  4.9798798839e+005
   8.30  9.1197493203e+006
   9.30  1.8973278638e+008
  10.30  4.4204070328e+009
  11.30  1.1401521388e+011
*/
