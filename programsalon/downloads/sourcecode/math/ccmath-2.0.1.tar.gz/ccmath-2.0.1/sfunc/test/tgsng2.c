/*  tgsng2.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  gelp  g2elp  gsng  gsng2

    Input file:  gel2c.dat
*/
#include "ccmath.h"
#include <math.h>
main(na,av)
int na; char **av;
{ double ap,bp,cp,k; FILE *fp;
  double ax,bx,cx,b,ia,ib,i2;
  double s1,s2,ss,h,dd,ga,gb,g2;
  if(na!=2){ printf("para: input_file\n"); exit(-1);}
  fp=fopen(*++av,"r");
  fscanf(fp,"%lf %lf %lf %lf",&k,&ap,&bp,&cp);
  b=sqrt(1.-k*k);
  printf(" Parameters: k=%f\n",k);
  printf("  Bartky a=%f b=%f c=%f\n\n",ap,bp,cp);
  while(fscanf(fp,"%lf %lf",&s1,&s2)!=EOF){
    printf(" angles: aa=%f ab=%f\n",s1,s2);
/* evaluate first elliptic integral */
    ss=fabs(s1); ax=ap; bx=bp; cx=cp;
    ga=gelp(ss,k,ax,bx,cx,0L,0L,0L);
    printf("  ga0= %e\n",ga); h=ga;
/* check first integral */
    ia=gsng(&ax,&bx,&cx,b,ss);
    printf("  T-Bartky: %f %f %f  ia= %e\n",ax,bx,cx,ia);
    ga=gelp(ss,k,ax,bx,cx,0L,0L,0L);
    printf("     sa= %e  ia+sa= %e\n",ga,ia+ga);
/* evaluate second elliptic integral */
    ax=ap; bx=bp; cx=cp;
    gb=gelp(s2,k,ax,bx,cx,0L,0L,0L);
    printf("  gb0= %e\n",gb);

/* set dd equal to general limit integral integral */
    if(s1>0.) dd=gb-h; else dd=gb+h;

/* check second integral */
    ib=gsng(&ax,&bx,&cx,b,s2);
    printf("  T-Bartky: %f %f %f  ib= %e\n",ax,bx,cx,ib);
    gb=gelp(s2,k,ax,bx,cx,0L,0L,0L);
    printf("     sb= %e  ib+sb= %e\n",gb,ib+gb);

/* evaluate elliptic integral using general limits */
    ax=ap; bx=bp; cx=cp;
    g2=g2elp(s1,s2,k,ax,bx,cx); h=g2;
    printf("  g20= %e\n",g2);

/* transform singular elliptic integral with general limits */
    i2=gsng2(&ax,&bx,&cx,b,s1,s2);
/* check general limit integral */
    printf("  T-Bartky: %f %f %f  i2= %e\n",ax,bx,cx,i2);
    g2=g2elp(s1,s2,k,ax,bx,cx);
    printf("     g2= %e  g2+i2= %e\n",g2,i2+g2);

/* compare direct general limit integral with result obtained by
   combining single limit integrals */
    printf("  comparison: g2: %e  diff: %e\n",h,dd);
   }
}
/*  Test output

 Parameters: k=0.500000
  Bartky a=1.000000 b=-1.000000 c=-1.154701

 angles: aa=0.392699 ab=1.178097
  ga0= 4.437389e-001
  T-Bartky: 0.000000 -0.142857 1.010363  ia= 4.462410e-001
     sa= -2.502116e-003  ia+sa= 4.437389e-001
  gb0= 3.836264e-001
  T-Bartky: 0.000000 -0.142857 1.010363  ib= 4.436868e-001
     sb= -6.006035e-002  ib+sb= 3.836264e-001
  g20= -6.011246e-002
  T-Bartky: 0.000000 -0.142857 1.010363  i2= -2.554232e-003
     g2= -5.755823e-002  g2+i2= -6.011246e-002
  comparison: g2: -6.011246e-002  diff: -6.011246e-002
 angles: aa=-0.392699 ab=1.178097
  ga0= 4.437389e-001
  T-Bartky: 0.000000 -0.142857 1.010363  ia= 4.462410e-001
     sa= -2.502116e-003  ia+sa= 4.437389e-001
  gb0= 3.836264e-001
  T-Bartky: 0.000000 -0.142857 1.010363  ib= 4.436868e-001
     sb= -6.006035e-002  ib+sb= 3.836264e-001
  g20= 8.273654e-001
  T-Bartky: 0.000000 -0.142857 1.010363  i2= 8.899278e-001
     g2= -6.256246e-002  g2+i2= 8.273654e-001
  comparison: g2: 8.273654e-001  diff: 8.273654e-001
*/
