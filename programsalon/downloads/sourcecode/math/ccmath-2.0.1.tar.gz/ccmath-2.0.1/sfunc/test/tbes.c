/*  tbes.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  jbes  or  nbes  or  ibes  or  kbes

    Prompted input:  at prompt 'type(j,y,i,k) '
                         enter  j    {to compute J(v,x)}
                                y    {to compute N(v,x)}
                                i    {to compute I(v,x)}
                                k    {to compute K(v,x)}

                     at prompt 'order '
                         enter  v  { real order with v > 0 }

                     at prompt 'max-x interval '
                         enter  xmax  delx  { tabulate function
                                              at intervals delx
                                              while x <= xmax }
*/
#include "ccmath.h"
#include <math.h>
main()
{ double (*fun)();
  double x,dx,f,v,xmx; char t[2];
  printf("     Test of Bessel Functions\n");
  printf("type(j,y,i,k) "); scanf("%s",t);
  switch(t[0]){
    case 'j': fun=jbes; printf("     J(v,x)\n"); break;
    case 'y': fun=nbes; printf("     N(v,x)\n"); break;
    case 'i': fun=ibes; printf("     I(v,x)\n"); break;
    case 'k': fun=kbes; printf("     K(v,x)\n"); break;
   }
  printf("order "); scanf("%lf",&v);
  printf(" order v= %.2f\n",v);
  printf("max-x interval ");
  scanf("%lf %lf",&xmx,&dx); xmx+=dx/4.;
  if(t[0]=='j') x=0.; else x=dx;
  for(; x<xmx ; x+=dx){

/* compute Bessel function selected by switch */
    f=(*fun)(v,x);

    printf(" %7.2f   %17.9e\n",x,f); }
}
/* Test output

     Test of Bessel Functions
  J(v,x)
  order v= 1.80

    1.00    1.564953153e-001
    2.00    4.096192323e-001
    3.00    4.956809158e-001
    4.00    3.044283399e-001
    5.00   -4.117469407e-002
    6.00   -2.907158917e-001
    7.00   -2.746423137e-001
    8.00   -3.957021527e-002
    9.00    1.999476991e-001
   10.00    2.461068874e-001
   11.00    7.871065873e-002
   12.00   -1.415053711e-001

 ----------------------------------
     Test of Bessel Functions
  N(v,x)
  order v= 3.50

    2.00   -1.674928300e+000
    3.00   -7.020759742e-001
    4.00   -3.489020979e-001
    5.00   -2.755206800e-002
    6.00    2.379492346e-001
    7.00    3.224108545e-001
    8.00    1.840993147e-001
    9.00   -6.725432557e-002
   10.00   -2.405238622e-001
   11.00   -2.101775567e-001
   12.00   -1.521971922e-002

 ------------------------------------
        Test of Bessel Functions
  I(v,x)
  order v= 2.70

    2.00    3.118860810e-001
    3.00    1.271523610e+000
    4.00    4.154641771e+000
    5.00    1.234063243e+001
    6.00    3.498606239e+001
    7.00    9.676060706e+001
    8.00    2.639019977e+002
    9.00    7.138835084e+002
   10.00    1.921606696e+003
   11.00    5.156916697e+003
   12.00    1.381396141e+004

 ------------------------------------
     Test of Bessel Functions
  K(v,x)
  order v= 4.60

    2.00    5.131572415e+000
    3.00    5.856692563e-001
    4.00    1.052128995e-001
    5.00    2.369073691e-002
    6.00    6.076438677e-003
    7.00    1.692442684e-003
    8.00    4.983859739e-004
    9.00    1.526807305e-004
   10.00    4.815737551e-005
   11.00    1.552996382e-005
   12.00    5.095534214e-006
*/
