/*  tjbes.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  jbes

    Prompted input:  at prompt  'order '
                                  enter v
                                          { real order v >=0)

                     at prompt  'max-x interval '
                                  enter xmx dx
                                               { real maximum x-value
                                                 and interval -> table
                                                 from x=0 to xmx at
                                                 intervals dx }
*/
#include "ccmath.h"
#include <math.h>
main()
{ double x,dx,f,v,xmx;
  printf("     Test of Bessel Functions\n");
  printf("     J(v,x)\n");
  printf("order "); scanf("%lf",&v);
  printf(" order= %.2f\n",v);
  printf("max-x interval ");
  scanf("%lf %lf",&xmx,&dx); xmx+=dx/4.;
  for(x=0.; x<xmx ; x+=dx){

/* computr Bessel function of the first kind J(v,x) */
    f=jbes(v,x);

    printf(" %7.2f   %16.9e\n",x,f); }
}
/*  Test output

     Test of Bessel Functions
     J(v,x)
order  order= 1.50
    0.00   0.000000000e+000
    0.50   9.170169963e-002
    1.00   2.402978391e-001
    1.50   3.871422173e-001
    2.00   4.912937787e-001
    2.50   5.250802647e-001
    3.00   4.777182151e-001
    3.50   3.566426626e-001
    4.00   1.852859484e-001
    4.50   -2.419664543e-003
    5.00   -1.696513061e-001
    5.50   -2.847463357e-001
    6.00   -3.279303109e-001
    6.50   -2.952716270e-001
    7.00   -1.990517133e-001
    7.50   -6.455319613e-002
    8.00   7.593140281e-002
    8.50   1.904625582e-001
    9.00   2.545042184e-001
    9.50   2.560880845e-001
   10.00   1.979824928e-001
   10.50   9.646316101e-002
   11.00   -2.293459484e-002
   11.50   -1.316247917e-001
   12.00   -2.046634485e-001
*/
