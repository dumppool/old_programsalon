/*  tpsi.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  psi  psih
*/
#include "ccmath.h"
main()
{ double h,p,ph; int i;
  printf("    Test of the psi Functions\n");
  for(i=1; i<=16 ;++i){
    h=(double)i+0.5;

/* evaluate psi functions for integer and half-integer argument */
    p=psi(i); ph=psih(h);

    printf(" psi(%2d)= %14.6e  psi(%4.1f)= %14.6e\n",i,p,h,ph);
   }
}
/*  Test output

    Test of the psi Functions
 psi( 1)= -5.772157e-001  psi( 1.5)=  3.648997e-002
 psi( 2)=  4.227843e-001  psi( 2.5)=  7.031566e-001
 psi( 3)=  9.227843e-001  psi( 3.5)=  1.103157e+000
 psi( 4)=  1.256118e+000  psi( 4.5)=  1.388871e+000
 psi( 5)=  1.506118e+000  psi( 5.5)=  1.611093e+000
 psi( 6)=  1.706118e+000  psi( 6.5)=  1.792911e+000
 psi( 7)=  1.872784e+000  psi( 7.5)=  1.946757e+000
 psi( 8)=  2.015641e+000  psi( 8.5)=  2.080091e+000
 psi( 9)=  2.140641e+000  psi( 9.5)=  2.197738e+000
 psi(10)=  2.251753e+000  psi(10.5)=  2.303001e+000
 psi(11)=  2.351753e+000  psi(11.5)=  2.398239e+000
 psi(12)=  2.442662e+000  psi(12.5)=  2.485196e+000
 psi(13)=  2.525995e+000  psi(13.5)=  2.565196e+000
 psi(14)=  2.602918e+000  psi(14.5)=  2.639270e+000
 psi(15)=  2.674347e+000  psi(15.5)=  2.708235e+000
 psi(16)=  2.741013e+000  psi(16.5)=  2.772751e+000
*/
