/*  trcspbs.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  rcspbes  setrcsb

    Uses:  (implicit)  jspbes  yspbes  kspbes

    Interactive input:  at prompt  'type(j,y,k) '
                                    enter  j  {to compute jspbes}
                                    enter  k  {to compute kspbes}
                                    enter  y  {to compute yspbes}

                        at prompt  'direction(u,d) '
                                    enter  u  {for recursion up in order}
				         stable for y and k
                                    enter  d  {for recursion down in order}
				         stable for j

                        at prompt  'starting order '
                                    enter  n  { integer initial order,
                                                with n >= 0 }

                        at prompt  'argument '
                                    enter  x  { real argument x,
                                                with x > 0 }
*/
#include "ccmath.h"
#include <math.h>
main()
{ double x,f[10]; int i,n;
  char ty[2],dr[2];
  printf("type(j,y,k) "); scanf("%s",ty);
  printf("direction(u,d) "); scanf("%s",dr);
  printf("starting order "); scanf("%d",&n);
  printf("argument "); scanf("%lf",&x);
  switch(ty[0]){
    case 'j': printf(" j(n,x)\n"); break;
    case 'y': printf(" y(n,x)\n"); break;
    case 'k': printf(" k(n,x)\n"); break;
   }
  printf("  argument x= %.4f\n",x);

/* initialize spherical Bessel function recursion */
  setrcsb(n,x,ty[0],dr[0],f,f+1);

  for(i=0; i<10 ;++i){

/* recursive computation of spherical Bessel functions */
    if(i>=2) f[i]=rcspbs();

    printf(" %3d  %17.10e\n",n,f[i]);
    if(dr[0]=='u') ++n; else --n;
   }
}
/*  Test output

  j(n,x)
  argument x= 2.0000
  11  5.9768716122e-009
  10  6.8253008650e-008
   9  7.1067971921e-007
   8  6.6832043238e-006
   7  5.6096557033e-005
   6  4.1404097343e-004
   5  2.6351697702e-003
   4  1.4079392763e-002
   3  6.0722097663e-002
   2  1.9844794906e-001

  y(n,x)
  argument x= 1.5000
   1  -6.9643541403e-001
   2  -1.3457126936e+000
   3  -3.7892735647e+000
   4  -1.6337563942e+001
   5  -9.4236110085e+001
   6  -6.7472724335e+002
   7  -5.7533999989e+003
   8  -5.6859272746e+004
   9  -6.3865169112e+005
  10  -8.0327288148e+006

  k(n,x)
  argument x= 1.5000
   1  2.4792240016e-001
   2  6.4459824043e-001
   3  2.3965832016e+000
   4  1.1828653181e+001
   5  7.3368502289e+001
   6  5.4986433663e+002
   7  4.8388594198e+003
   8  4.8938458534e+004
   9  5.5947472281e+005
  10  7.1356182808e+006
*/
