/*  tg2elp.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  g2elp

    Uses:  gelp

    Prompted input:  at prompt  'k= '
                         enter   k
                                    {real order with 0 < k < 1}

                     at prompt  'l-lim u-lim (deg)'
                         enter   a  b
                                      {lower limit (a) and upper limit (b)
                                       of integral in degrees  a < b and
                                       b > 0 }

                     at prompt  'q-par '
                         enter   q
                                      { real with 0 < q < 1 }
*/
#include "ccmath.h"
#include <math.h>
main()
{ double a,b,k,af,bf,df,g,h,q;
  double rad=1.74532925199433e-2;
  printf("     Test of Elliptic Integral with General Limits\n");
  printf("k= "); scanf("%lf",&k);
  printf("l-lim u-lim (deg.)"); scanf("%lf %lf",&a,&b);
  printf(" k=%.2f l-lim= %.2f u-lim= %.2f\n",k,a,b);
  a*=rad; b*=rad;
  printf("q-par "); scanf("%lf",&q);
  af=1.; df=1.-q; bf=1./df; df/=sqrt(1.-k*k);
  printf(" Bartky parameters: %f %f %f\n",af,bf,df);
  printf(" integrals:\n");

/* compute general elliptic integral with general limits */
  g=g2elp(a,b,k,af,bf,df);
  printf(" a to b = %e\n",g);

/* check using elliptic integrals with zero lower limit */
  g=gelp(fabs(a),k,af,bf,df,&h,0L,0L);
  printf("     0 to |a| = %e",g);
  g=gelp(b,k,af,bf,df,&h,0L,0L); printf("   0 to b = %e\n",g);
  printf("     0 to pi/2 = %e\n",h);
}
/*  Test output

     Test of Elliptic Integral with General Limits
 k=0.70 l-lim= 20.00 u-lim= 80.00
 Bartky parameters: 1.000000 2.500000 0.560112
 integrals:
 a to b = 2.070947e+000
     0 to |a| = 3.613756e-001   0 to b = 2.432323e+000
     0 to pi/2 = 3.031457e+000

          Test of Elliptic Integral with General Limits
 k=0.95 l-lim= -15.00 u-lim= 75.00
 Bartky parameters: 1.000000 4.000000 0.800641
 integrals:
 a to b = 3.635292e+000
     0 to |a| = 2.691872e-001   0 to b = 3.366105e+000
     0 to pi/2 = 6.267922e+000
*/
