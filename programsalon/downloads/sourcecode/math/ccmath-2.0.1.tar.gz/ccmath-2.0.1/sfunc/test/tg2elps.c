/*  tg2elps.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  g2elp

    Uses:  gelp  (implicit)  gsng  gsng2

    Input file:  gel2?.dat
*/
#include <stdio.h>
#include "ccmath.h"
#include <math.h>
main(na,av)
int na; char **av;
{ double ap,bp,cp,k; FILE *fp;
  double s1,s2,ga,gb,g2,cf;
  if(na!=2){ printf("para: input_file\n"); exit(1);}
  fp=fopen(*++av,"r");
  fscanf(fp,"%lf %lf %lf %lf",&k,&ap,&bp,&cp);
  printf(" Parameters: k=%f\n",k);
  printf("  Bartky a=%f b=%f c=%f\n\n",ap,bp,cp);
  while(fscanf(fp,"%lf %lf",&s1,&s2)!=EOF){
    printf(" angles: s1=%f s2=%f\n",s1,s2);

/* general elliptic integral with general limits */
    g2=g2elp(s1,s2,k,ap,bp,cp);
    printf("   g2= %e\n",g2);

/* check using general elliptic integrals with zero lower limit */
    ga=gelp(s1,k,ap,bp,cp,&cf,0L,0L);
    gb=gelp(s2,k,ap,bp,cp,&cf,0L,0L);
    printf("   i1= %e  i2= %e  i2-i1= %e\n",ga,gb,gb-ga);
   }
}
/*  Test output

 Parameters: k=0.500000
  Bartky a=1.000000 b=1.000000 c=1.000000

 angles: s1=0.392699 s2=1.178097
   g2= 8.407987e-001
   i1= 3.951872e-001  i2= 1.235986e+000  i2-i1= 8.407987e-001
 angles: s1=-0.392699 s2=1.178097
   g2= 1.631173e+000
   i1= -3.951872e-001  i2= 1.235986e+000  i2-i1= 1.631173e+000

 Parameters: k=0.500000
  Bartky a=1.000000 b=0.750000 c=0.866025

 angles: s1=0.392699 s2=1.178097
   g2= 7.466728e-001
   i1= 3.913911e-001  i2= 1.138064e+000  i2-i1= 7.466728e-001
 angles: s1=-0.392699 s2=1.178097
   g2= 1.529455e+000
   i1= -3.913911e-001  i2= 1.138064e+000  i2-i1= 1.529455e+000

 Parameters: k=0.500000
  Bartky a=1.000000 b=-1.000000 c=-1.154701

 angles: s1=0.392699 s2=1.178097
   g2= -6.011246e-002
   i1= 4.437389e-001  i2= 3.836264e-001  i2-i1= -6.011246e-002
 angles: s1=-0.392699 s2=1.178097
   g2= 8.273654e-001
   i1= -4.437389e-001  i2= 3.836264e-001  i2-i1= 8.273654e-001

 Parameters: k=0.500000
  Bartky a=1.000000 b=2.000000 c=0.577350

 angles: s1=0.392699 s2=1.178097
   g2= 1.149577e+000
   i1= 4.055485e-001  i2= 1.555125e+000  i2-i1= 1.149577e+000
 angles: s1=-0.392699 s2=1.178097
   g2= 1.960674e+000
   i1= -4.055485e-001  i2= 1.555125e+000  i2-i1= 1.960674e+000
*/
