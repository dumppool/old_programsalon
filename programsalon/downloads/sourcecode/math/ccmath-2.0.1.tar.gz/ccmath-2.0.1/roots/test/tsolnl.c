/*  tsolnl.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  solnl
*/
#include "ccmath.h"
#define NN 3
main()
{ double x[NN],f[NN],(*fv[NN])(),test=1.e-28;
  double fa(),fb(),fc(); int i,m;
  fv[0]=fa; fv[1]=fb; fv[2]=fc;
  printf("     Test of Nonlinear System Solver\n");
  printf(" enter initial x-vector (%d components)\n",NN);
  for(i=0; i<NN ;) scanf("%lf",x+i++);
  printf(" initial vector:\n");
  for(i=0; i<NN ;) printf(" %f",x[i++]); printf("\n");
  m=solnl(x,f,fv,NN,test);
  printf(" solution status = %d\n",m);
  printf(" solution vector:\n");
  for(i=0; i<NN ;) printf(" %f",x[i++]); printf("\n");
  printf("    final function values:\n");
  for(i=0; i<NN ;++i) printf("  %d  %e\n",i+1,f[i]);
}
/* functions of nonlinear system */
double fa(x)
double x[];
{ return (x[0]*x[0]+2.*x[1]*x[1]-4.);
}
double fb(x)
double x[];
{ return (x[0]*x[0]+x[1]*x[1]+x[2]-8.);
}
double fc(x)
double x[];
{ double a,b,c,sqrt();
  a=x[0]-1.; b=2.*x[1]-sqrt(2.); c=x[2]-5.;
  return (a*a+b*b+c*c-4.);
}
/* Test output

     Test of Nonlinear System Solver
 enter initial x-vector (3 components)
 initial vector:
 1.000000 0.000000 1.000000
 solution status = 1
 solution vector:
 0.000000 1.414214 6.000000
    final function values:
  1  1.776357e-015
  2  0.000000e+000
  3  -3.552714e-015
*/
