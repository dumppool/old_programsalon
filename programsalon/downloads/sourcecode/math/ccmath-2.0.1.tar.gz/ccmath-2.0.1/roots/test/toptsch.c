/*  toptsch.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  optsch

    For other functions replace descriptor dfn, limit arguments
    to optsch, and define a new test function ft(x).
*/
#include "ccmath.h"
#include <math.h>
char dfn[]="1-sin(x) on 0 to Pi";
main()
{ double xopt,dx,ft();
  printf("     Test of Optimum Line Search\n");
  printf(" minimum of %s\n",dfn);
  xopt=optsch(ft,0.,3.14159,1.e-14);
  printf(" minimum at  x = %e\n",xopt);
  dx=.0001;
  printf("     test:      f(x)= %e\n",ft(xopt));
  printf("          f(x+.0001)= %e\n",ft(xopt+dx));
  printf("          f(x-.0001)= %e\n",ft(xopt-dx));
}
/* Function to be optimized */
double ft(x)
double x;
{ return 1.-sin(x);
}
/* Test output

     Test of Optimum Line Search
 minimum of 1-sin(x) on 0 to Pi
 minimum at  x = 1.570796e+000
     test:      f(x)= 4.499439e-018
          f(x+.0001)= 4.999700e-009
          f(x-.0001)= 5.000300e-009
*/
