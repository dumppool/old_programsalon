/*  secrt.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
double secrt(func,x,dx,test)
double x,dx,test,(*func)();
{ double f,fp,y; int k;
  y=x-dx; fp=(*func)(y);
  for(k=0;;++k){ f=(*func)(x);
    dx=f*(x-y)/(f-fp); fp=f; y=x; x-=dx;
    if(((dx<0.)?-dx:dx)<test || k==50)
      return x;
   }
}
