/*  polyc.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
struct complex {double re,im;} polyc(z,cof,n)
struct complex z; double cof[]; int n;
{ int i; struct complex py; double s;
  for(i=n-1,py.re=cof[n],py.im=0.; i>=0 ;--i){
    s=py.re*z.re-py.im*z.im;
    py.im=py.im*z.re+py.re*z.im; py.re=s+cof[i];
   }
  return py;
}
