/*  tpwr.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  pwr
*/
#include "ccmath.h"
main()
{ double y; int n;
  printf("  Test of Integer Powers Function\n");
  printf("     values of 3^n and 3^-n\n");

/* compute integer powers of y */
  for(n=1,y=3.; n<8 ;++n)
     printf(" %d  %f  %e\n",n,pwr(y,n),pwr(y,-n));
}
/*  Test output

  Test of Integer Powers Function
     values of 3^n and 3^-n
 1  3.000000  3.333333e-001
 2  9.000000  1.111111e-001
 3  27.000000  3.703704e-002
 4  81.000000  1.234568e-002
 5  243.000000  4.115226e-003
 6  729.000000  1.371742e-003
 7  2187.000000  4.572474e-004
*/
