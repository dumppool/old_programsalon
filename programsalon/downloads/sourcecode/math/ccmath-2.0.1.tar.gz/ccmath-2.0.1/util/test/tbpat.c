/*  tbpat.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  bitpc  bitps  bitpl  bitpf  bitpd  (print bit patterns)
*/
#include "ccmath.h"
main()
{ char c; short n; long l;
  float f; double d;
  c='0'; n=9; l=-1L;
  f=1.; d=.333333333333333333;
  printf(" char c= %c\n",c);
  printf("c: "); bitpc(c);
  printf(" short int n= %d\n",n);
  printf("n: "); bitps(n);
  printf(" long int l= %ld\n",l);
  printf("l: "); bitpl(l);
  printf(" float f= %13.6e\n",f);
  printf("f: "); bitpf(f);
  printf(" double d= %21.14e\n",d);
  printf("d: "); bitpd(d);
}
/*  Test output

 char c= 0
c: 00110000
 short int n= 9
n: 0000000000001001
 long int l= -1
l: 11111111111111111111111111111111
 float f= 1.000000e+000
f: 000000000^00000000000000000000000
 double d= 3.33333333333333e-001
d: 001111111101^0101010101010101010101010101010101010101010101010101
*/
