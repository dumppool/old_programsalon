/*  bits.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
unsigned short bset(x,n)
unsigned short x,n;
{ unsigned t=01;
  t<<=n; return (x|t);
}
bget(x,n)
unsigned short x,n;
{ unsigned t=01;
  t<<=n; if(x&t) return 1; else return 0;
}
bcnt(x)
unsigned short x;
{ int c=0;
  if(x) ++c;
  while((x=x&(x-1))!=0) ++c;
  return c;
}
