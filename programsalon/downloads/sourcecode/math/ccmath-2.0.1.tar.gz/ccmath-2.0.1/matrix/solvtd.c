/*  solvtd.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
solvtd(a,b,c,x,m)
double a[],b[],c[],x[]; int m;
{ double s; int j;
  for(j=0; j<m ;++j){ s=b[j]/a[j];
    a[j+1]-=s*c[j]; x[j+1]-=s*x[j];}
  for(j=m,s=0.; j>=0 ;--j){
    x[j]-=s*c[j]; s=(x[j]/=a[j]);}
}
