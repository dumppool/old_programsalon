/*  trncm.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include "complex.h"
trncm(a,n)
Cpx *a; int n;
{ Cpx s,*p,*q;
  int i,j,e;
  for(i=0,e=n-1; i<n-1 ;++i,--e,a+=n+1){
    for(j=0,p=a+1,q=a+n; j<e ;++j){
      s= *p; *p++ = *q; *q=s; q+=n;
     }
   }
}
