/*  vmul.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
vmul(vp,mat,v,n)
double *vp,*mat,*v; int n;
{ double s,*q; int k,i;
  for(k=0; k<n ;++k){
    for(i=0,q=v,s=0.; i<n ;++i) s+= *mat++ * *q++;
    *vp++ =s;
   }
}
double vnrm(u,v,n)
double *u,*v; int n;
{ double s; int i;
  for(i=0,s=0.; i<n ;++i) s+= *u++ * *v++;
  return s;
}

