/*  mattr.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
mattr(a,b,m,n)
double *a,*b; int m,n;
{ double *p; int i,j;
  for(i=0; i<n ;++i,++b)
    for(j=0,p=b; j<m ;++j,p+=n) *a++ = *p;
}
