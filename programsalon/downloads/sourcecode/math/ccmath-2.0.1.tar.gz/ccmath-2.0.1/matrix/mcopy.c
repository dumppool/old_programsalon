/*  mcopy.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
mcopy(a,b,m)
double a[],b[]; int m;
{ double *p,*q; int k;
  for(p=a,q=b,k=0; k<m ;++k) *p++ = *q++;
}
