/*  eigval.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
eigval(a,ev,n)
double *a,*ev; int n;
{ double *dp;
  dp=(double *)calloc(n,sizeof(double));
  house(a,ev,dp,n);
  qreval(ev,dp,n);
}
