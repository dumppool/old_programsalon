/*  thevmax.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  hevmax

    Uses:  unitary  hmgen  cvmul  cvnrm  cmprt

    Input parameter:  n -> dimension (matrix is n by n)
*/
#include <stdio.h>
#include <time.h>
#include "ccmath.h"
main(na,av)
int na; char **av;
{ Cpx *h,*u,*v,*w,c; int i,n;
  double *ev,e; void *calloc();
  unsigned long seed;
  if(na!=2){ printf("para: dim\n"); exit(1);}
  n=atoi(*++av);
  seed=time(NULL); setunfl(seed);
  ev=(double *)calloc(n,sizeof(double));
  h=(Cpx *)calloc(2*(n*n+n),sizeof(Cpx));
  u=h+n*n; v=u+n*n; w=v+n;
  for(i=0,e=1.; i<n ;++i,e+=.5) ev[i]=e;

/* generate a Hermitian matrix */
  unitary(u,n);
  hmgen(h,ev,u,n);
  printf(" input matrix h:\n");
  cmprt(h,n,n,"(%6.3f,%6.3f)");

/* compute eigenvalue of maximum modulus and corresponding
   eigenvector for a Hermitian matrix */
  e=hevmax(h,v,n);

  printf(" max. eigenvalue = %12.4e\n",e);
  printf(" eigenvector v:\n");
  cmprt(v,1,n,"(%6.3f,%6.3f)");
/* check eigenvalue and vector */
  cvmul(w,h,v,n);
  printf(" vector h*v:\n");
  cmprt(w,1,n,"(%6.3f,%6.3f)");
  c=cvnrm(w,v,n);
  printf(" v^*h*v= (%6.3f,%6.3f)\n",c.re,c.im);
}
/* Test output

 input matrix h:
( 1.509,-0.000)( 0.045, 0.138)(-0.186,-0.099)( 0.179,-0.166)
( 0.045,-0.138)( 1.727, 0.000)( 0.046, 0.214)( 0.281, 0.407)
(-0.186, 0.099)( 0.046,-0.214)( 1.729, 0.000)(-0.344,-0.138)
( 0.179, 0.166)( 0.281,-0.407)(-0.344, 0.138)( 2.035,-0.000)
 max. eigenvalue =   2.5000e+00
 eigenvector v:
( 0.153, 0.000)( 0.321, 0.320)(-0.280,-0.213)( 0.803, 0.042)
 vector h*v:
( 0.384, 0.000)( 0.803, 0.801)(-0.700,-0.532)( 2.008, 0.106)
 v^*h*v= ( 2.500,-0.000)
*/
