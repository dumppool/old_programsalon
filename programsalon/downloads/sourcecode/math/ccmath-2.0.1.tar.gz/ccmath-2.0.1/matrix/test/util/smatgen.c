/*  smatgen.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include <stdio.h>
#include "ccmath.h"
FILE *fq;
main(na,av)
int na; char **av;
{ int n,m; unsigned long seed;
  double *a,*ev,*evc,s;
  if(na!=3){ printf("para: dim o_file\n"); exit(1);}
  n=atoi(*++av); m=n*n;
  fq=fopen(*++av,"wb");
  evc=(double *)calloc(2*m+n,sizeof(*a));
  a=evc+m; ev=a+m;
  for(m=0,s=1.; m<n ;++m){ ev[m]=s; s+=0.5;}
  seed=(unsigned long)time(NULL); setunfl(seed);
  ortho(evc,n);
  smgen(a,ev,evc,n);
  fwrite((void *)&n,sizeof(int),1,fq);
  fwrite((void *)a,sizeof(double),n*n,fq);
}
