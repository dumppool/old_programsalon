/*  tmmul.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  mmul

    Uses:  matprt

    Input parameter:  n -> size square matrices are n by n
*/
#include <stdio.h>
#include "ccmath.h"
long seed=123456789;
main(na,av)
int na; char **av;
{ int i,n,m;
  double *a,*b,*c,*p,*q;
  if(na!=2){ printf("para: dim\n"); exit(1);}
  n=atoi(*++av); m=n*n;
  a=(double *)calloc(3*m,sizeof(double));
  b=a+m; c=b+m;
  setunfl(seed);
  for(i=0,p=a,q=b; i<m ;++i){
    *p++ =nrml(); *q++ =nrml();
   }

/* multiply two real square matrices */
  mmul(c,a,b,n);

  printf("matrix a:\n"); matprt(a,n,n," %8.4f");
  printf("matrix b:\n"); matprt(b,n,n," %8.4f");
  printf("product c:\n"); matprt(c,n,n," %8.4f");
}
/* Test output

matrix a:
   0.0000  -0.3284   0.7770   1.4409  -0.2555
  -0.0266  -1.3738   0.0705   1.5157   1.0709
   1.1795   1.4293  -0.5953   2.1380   1.6353
   0.8131   1.9874   0.9566   0.5443  -1.1819
  -0.9047   0.8590  -0.3838   1.1679  -0.0306
matrix b:
  -1.3883  -0.0855   0.8884  -0.0220  -2.4956
  -0.2718   0.4262  -2.4138  -0.1238   0.3198
   0.7989  -0.5758   0.5012  -0.9558  -0.1341
   2.3736   0.1626   0.1823  -1.3795   0.5096
  -0.1473  -0.1292   0.4813   0.4648  -0.5387
product c:
   4.1677  -0.3201   1.3218  -2.8085   0.6627
   3.9064  -0.5158   4.1196  -1.4898  -0.1870
   2.3321   0.9874  -1.5237  -1.8233  -2.1981
   0.5613   0.4679  -4.0650  -2.4786  -0.6079
   3.4924   0.8583  -2.8712  -1.3449   3.1954
*/
