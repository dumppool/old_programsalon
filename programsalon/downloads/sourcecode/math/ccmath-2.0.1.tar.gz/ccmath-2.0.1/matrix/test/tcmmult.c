/*  tcmmult.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  cmmult

    Uses:  cminv  cmprt  nrml

    Input parameters:  n1 n2 n3 -> size with
                                   matrix A n1 by n2
                                   matrix B n2 by n3
                                   product C n1 by n3
*/
#include <stdio.h>
#include <stdlib.h>
#include "ccmath.h"
char fmt[]="(%7.3f,%7.3f)";
main(na,av)
int na; char **av;
{ int n,m,k,i; Cpx *a,*b,*c,*d;
  long seed; double nrml();
  if(na!=4){ printf("para: dim1 dim2 dim3\n"); exit(1);}
  n=atoi(*++av); m=atoi(*++av); k=atoi(*++av);
  a=(Cpx *)calloc(n*m,sizeof(Cpx));
  b=(Cpx *)calloc(m*k,sizeof(Cpx));
  c=(Cpx *)calloc(n*k,sizeof(Cpx));
  d=(Cpx *)calloc(n*k,sizeof(Cpx));
  seed=123456789; setunfl(seed);
  for(i=0; i<n*m ;++i){ a[i].re=nrml(); a[i].im=nrml();}
  for(i=0; i<m*k ;++i){ b[i].re=nrml(); b[i].im=nrml();}
/* print matrix inputs */
  printf(" matrix a:\n");
  cmprt(a,n,m,fmt);
  printf(" matrix b:\n");
  cmprt(b,m,k,fmt);

/* general complex matrix multiply */
  cmmult(c,a,b,n,m,k);

  printf(" product matrix c=a*b:\n");
  cmprt(c,n,k,fmt);
/* check for first matrix factor a square matrix */
  if(n==m){
    cminv(a,n); cmmult(d,a,c,n,m,k);
    printf(" matrix b?:\n");
    cmprt(d,n,k,fmt);
   }
}
/* Test output

 matrix a:
(  0.000, -1.388)( -0.328, -0.086)(  0.777,  0.888)(  1.441, -0.022)
( -0.256, -2.496)( -0.027, -0.272)( -1.374,  0.426)(  0.070, -2.414)
(  1.516, -0.124)(  1.071,  0.320)(  1.180,  0.799)(  1.429, -0.576)
( -0.595,  0.501)(  2.138, -0.956)(  1.635, -0.134)(  0.813,  2.374)
 matrix b:
(  1.987,  0.163)(  0.957,  0.182)
(  0.544, -1.380)( -1.182,  0.510)
( -0.905, -0.147)(  0.859, -0.129)
( -0.384,  0.481)(  1.168,  0.465)
 product matrix c=a*b:
( -1.185, -2.569)(  3.160, -0.088)
(  1.949, -4.335)(  0.460, -4.369)
(  2.836, -1.291)(  3.097,  0.851)
( -4.373, -3.210)( -1.467,  5.414)
 matrix b?:
(  1.987,  0.163)(  0.957,  0.182)
(  0.544, -1.380)( -1.182,  0.510)
( -0.905, -0.147)(  0.859, -0.129)
( -0.384,  0.481)(  1.168,  0.465)
*/
