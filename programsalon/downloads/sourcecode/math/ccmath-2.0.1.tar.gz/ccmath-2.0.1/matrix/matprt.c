/*  matprt.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include <stdio.h>
matprt(a,n,m,fmt)
double a[]; int n,m; char fmt[];
{ int i,j; double *p;
  for(i=0,p=a; i<n ;++i){
    for(j=0; j<m ;++j) printf(fmt,*p++);
    printf("\n");
   }
}
fmatprt(fp,a,n,m,fmt)
FILE *fp; double a[]; int n,m; char fmt[];
{ int i,j; double *p;
  for(i=0,p=a; i<n ;++i){
    for(j=0; j<m ;++j) fprintf(fp,fmt,*p++);
    fprintf(fp,"\n");
   }
}
