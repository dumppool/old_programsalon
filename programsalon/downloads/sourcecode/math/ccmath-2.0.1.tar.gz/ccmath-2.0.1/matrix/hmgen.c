/*  hmgen.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include "complex.h"
hmgen(h,ev,u,n)
double *ev; Cpx *h,*u; int n;
{ Cpx *v,*p;
  void *calloc();
  int i,j; double e;
  v=(Cpx *)calloc(n*n,sizeof(Cpx));
  cmcpy(v,u,n*n); hconj(v,n);
  for(i=0,p=v; i<n ;++i){
    for(j=0,e=ev[i]; j<n ;++j,++p){
      p->re*=e; p->im*=e;
     }
   }
  cmmul(h,u,v,n);
  free(v);
}
