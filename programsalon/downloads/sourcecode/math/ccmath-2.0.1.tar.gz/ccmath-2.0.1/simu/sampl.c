/*  sampl.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
sampl(s,n,d,m)
char *s[],**d; int n,m;
{ int k;
  for(k=0; k<n ;--m,++d)
    if(bran(m)<n-k) s[k++]= *d;
}
