/*  bran.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
static unsigned long s,h,sbuf[256];
static unsigned long a=1664525U,c=4098479U;
static unsigned long r=0xffff;
int bran(n)
int n;
{ register int i,j;
  i=(int)(s>>24); s=sbuf[i];
  h=h*a+c; sbuf[i]=h;
  i=n*(s>>16); j=n*(s&r); i+=(j>>16);
  return (i>>16);
}
void setbran(sa)
unsigned long sa;
{ int c;
  for(h=sa,c=0; c<=256 ;++c){
    h=h*a+c;
    if(c<256) sbuf[c]=h; else s=h;
   }
}

