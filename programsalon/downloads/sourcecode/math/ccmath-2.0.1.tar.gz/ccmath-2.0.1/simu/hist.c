/*  hist.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
int *hist(x,n,xmin,xmax,kbin,bin)
double *x,*bin,xmin,xmax; int n,kbin;
{ int k,*p; double *pm,u; char *calloc();
  p=(int *)calloc(kbin+2,sizeof(int)); ++p;
  *bin=(xmax-xmin)/kbin;
  for(pm=x+n; x<pm ;++x){
    if(*x > xmax) k=kbin;
    else if ((u=(*x-xmin))<0.) k= -1;
    else k=u / *bin;
    *(p+k)+=1;
   }
  return p;
}
