/*  tprand.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  autcor  hist

    Uses:  setunfl  setunfl2  setnrml  setnorm2
           unfl  unfl2  nrml  norm2

    Input parameters:  f -> integer: type flag 0 or 1  with
                                     0 -> uniform distribution
                                     1 -> normal distribution
                       k -> integer: generation flag 0 or 1  with
                                     0 -> standard generator
                                     1 -> use shuffle
                       n -> integer: size of generated sampl

		       seed -> unsigned long: random generator seed
*/
#include <stdlib.h>
#include "ccmath.h"
#include <math.h>
main(na,av)
int na; char **av;
{ int n,f,k,j,lag,kb,*his;
  unsigned long seed;
  double *x,*p,a,b,h,bin,err[2];
  if(na!=5){
  printf("para: type(0=u,1=n) shuffel? size seed\n"); exit(1);}
  f=atoi(*++av); k=atoi(*++av);
  n=atoi(*++av); sscanf(*++av,"%lx",&seed);
  lag=20;
  x=(double *)calloc(sizeof(*x),n);
  printf("     Test of Pseudorandom Generators\n");
  if(f) printf(" normal distribution ");
  else printf(" uniform distribution ");
  printf("generator type %d\n",k); printf("  seed = %lx\n",seed);

/* generate sample of requested type */
  if(f){ a= -(b=3.); kb=12;
     if(k) setnorm2(seed); else setnrml(seed);
     for(j=0,p=x; j<n ;++j){
       if(k){ if((j&1)==0){ norm2(err); *p++ =err[0];}
              else *p++ =err[1];
        }
       else *p++ =nrml();
      }
   }
  else{ a=0.; b=1.; kb=10;
     if(k) setunfl2(seed); else setunfl(seed);
     for(j=0,p=x; j<n ;++j){
       if(k) *p++ =unfl2(); else *p++ =unfl(); }
   }

/* compute sample histogram */
  printf(" histrogram\n");
  his=hist(x,n,a,b,kb,&bin);
  for(k=0,h=a; k<kb ;a+=bin,++k)
    printf(" %6.2f to %6.2f  %4d\n",a,h+=bin,*(his+k));
  printf("  under= %d  over= %d\n",*(his-1),*(his+kb));
  if(!f){ for(k=0; k<n ;) x[k++]-=.5;}

/* compute sample autocorrelations */
  printf(" series autocorrelations\n");
  p=autcor(x,n,lag);
  printf("   second moment = %e  ",*p);
  printf("sig. cf = %f\n",sqrt(1./n));
  for(k=1,kb=lag/2+1; k<=lag/2 ;++k,++kb)
    printf("   %2d  %8.4f    %2d  %8.4f\n",k,*(p+k),kb,*(p+kb));
}
/*  Test output

     Test of Pseudorandom Generators
 uniform distribution generator type 0
  seed = 4c7605e3
 histrogram
   0.00 to   0.10  100686
   0.10 to   0.20  99872
   0.20 to   0.30  99988
   0.30 to   0.40  100152
   0.40 to   0.50  100347
   0.50 to   0.60  100049
   0.60 to   0.70  99832
   0.70 to   0.80  100019
   0.80 to   0.90  99549
   0.90 to   1.00  99506
  under= 0  over= 0
 series autocorrelations
   second moment = 8.330915e+04  sig. cf = 0.001000
    1   -0.0003    11   -0.0001
    2   -0.0001    12    0.0009
    3   -0.0025    13    0.0012
    4    0.0006    14   -0.0000
    5   -0.0012    15    0.0019
    6   -0.0009    16    0.0008
    7   -0.0001    17    0.0001
    8   -0.0008    18   -0.0002
    9    0.0009    19   -0.0004
   10    0.0001    20    0.0009

     Test of Pseudorandom Generators
 normal distribution generator type 0
  seed = 35f8202d
 histrogram
  -3.00 to  -2.50  4824
  -2.50 to  -2.00  16444
  -2.00 to  -1.50  44178
  -1.50 to  -1.00  91842
  -1.00 to  -0.50  149648
  -0.50 to   0.00  191592
   0.00 to   0.50  191504
   0.50 to   1.00  149453
   1.00 to   1.50  92165
   1.50 to   2.00  43911
   2.00 to   2.50  16889
   2.50 to   3.00  4843
  under= 1359  over= 1348
 series autocorrelations
   second moment = 1.001029e+06  sig. cf = 0.001000
    1   -0.0024    11   -0.0010
    2   -0.0017    12   -0.0016
    3    0.0002    13    0.0003
    4   -0.0010    14   -0.0007
    5    0.0009    15    0.0007
    6   -0.0020    16    0.0005
    7    0.0013    17   -0.0001
    8   -0.0005    18    0.0011
    9    0.0006    19   -0.0000
   10   -0.0007    20   -0.0009

     Test of Pseudorandom Generators
 uniform distribution generator type 1
  seed = 9a20fa3f
 histrogram
   0.00 to   0.10  100265
   0.10 to   0.20  100068
   0.20 to   0.30  100035
   0.30 to   0.40  99605
   0.40 to   0.50  100068
   0.50 to   0.60  99892
   0.60 to   0.70  99975
   0.70 to   0.80  100414
   0.80 to   0.90  99891
   0.90 to   1.00  99787
  under= 0  over= 0
 series autocorrelations
   second moment = 8.337816e+04  sig. cf = 0.001000
    1    0.0001    11   -0.0000
    2    0.0008    12   -0.0007
    3   -0.0024    13   -0.0011
    4    0.0017    14   -0.0020
    5   -0.0001    15    0.0012
    6   -0.0001    16    0.0014
    7    0.0009    17   -0.0008
    8    0.0007    18   -0.0012
    9    0.0001    19    0.0001
   10    0.0003    20   -0.0004

     Test of Pseudorandom Generators
 normal distribution generator type 1
  seed = 6d1e1bf7
 histrogram
  -3.00 to  -2.50  4715
  -2.50 to  -2.00  16550
  -2.00 to  -1.50  44100
  -1.50 to  -1.00  92046
  -1.00 to  -0.50  149370
  -0.50 to   0.00  190997
   0.00 to   0.50  191856
   0.50 to   1.00  150264
   1.00 to   1.50  91982
   1.50 to   2.00  44076
   2.00 to   2.50  16593
   2.50 to   3.00  4798
  under= 1339  over= 1314
 series autocorrelations
   second moment = 9.993327e+05  sig. cf = 0.001000
    1   -0.0014    11   -0.0007
    2   -0.0002    12    0.0018
    3    0.0001    13    0.0015
    4   -0.0002    14    0.0001
    5   -0.0019    15   -0.0011
    6    0.0009    16   -0.0012
    7    0.0000    17    0.0008
    8   -0.0010    18   -0.0001
    9   -0.0009    19   -0.0012
   10   -0.0006    20   -0.0013
*/
