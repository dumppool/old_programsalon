/*  tsampl.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
                    CCM
    Numerical Analysis Library Test Program
    Copyright 1993, 1996 by The Calculating
    Company. All rights reserved.
*/
/*
    Test:  sampl

    Uses:  bran  setbran

    Input parameters:  nt -> integer: number of samples
                       seed -> long integer: pseudorandom generator seed
*/
#include <stdlib.h>
#include "ccmath.h"
#define MM 30
main(na,av)
int na; char **av;
{ int dat[MM],*bdf[MM],his[MM],*sam[6];
  int nt,ns,n,m,i,j,k,p; long seed;
  n=MM; m=6;
  if(na!=3){ printf("para: reps seed\n"); exit(-1);}
  nt=atoi(*++av);
  if(nt>30) p=0; else p=1;
/* initialize random generator */
  sscanf(*++av,"%lx",&seed); setbran(seed);
  printf("     Random Sample Generator Test\n");
  printf("      seed= %ld\n",seed);
  for(i=0,ns=0; i<n ;++i){
    dat[i]=i+1; bdf[i]=dat+i;
    his[i]=0;
   }
  for(i=0; i<nt ;++i){

/* generate  a random sample */
    sampl((void *)sam,m,(void *)bdf,n);

    for(j=0; j<m ;++j){
      if(p) printf("%3d",*sam[j]);
      k= *sam[j]-1; ++his[k];
     }
    if(p) printf("\n");
    ns+=m;
   }
  printf("\n total points %d\n",ns);
  printf(" frequency of appearence\n");
  for(i=0; i<n ;++i){
    nt+=his[i];
    printf(" %2d %3d\n",i+1,his[i]);
   }
}
/*  Test output

     Random Sample Generator Test
      seed= 640131534

 total points 18000
 frequency of appearence
  1 612
  2 631
  3 574
  4 594
  5 576
  6 596
  7 600
  8 528
  9 598
 10 590
 11 626
 12 599
 13 632
 14 584
 15 623
 16 563
 17 622
 18 583
 19 567
 20 639
 21 598
 22 621
 23 635
 24 617
 25 603
 26 578
 27 607
 28 591
 29 620
 30 593
*/
