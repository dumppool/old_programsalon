/*  timnrml.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include <time.h>
#include "ccmath.h"
main(int na,char **av)
{ unsigned long s; double e;
  int i,n; clock_t st,en;
  double dt,tms;
  if(na!=2){ printf("para: count\n"); exit(1);}
  n=atoi(*++av);
  s=0x5a7d3b28;
  setnrml(s);
  st=clock();
  for(i=0; i<n ;++i) e=nrml();
  en=clock();
  dt=(en-st)/(double)CLOCKS_PER_SEC;
  tms =1.0e6*(dt/(double)n);
  printf(" %d evaluations in %.3f sec.\n",n,dt);
  printf("  %.3e microsec per evaluation\n",tms);
}
