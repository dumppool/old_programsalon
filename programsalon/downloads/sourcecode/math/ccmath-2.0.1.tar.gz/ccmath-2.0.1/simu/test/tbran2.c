/*  tbran2.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  bran2  setbran2

    Input parameters:  s -> long integer: pseudorandom generator seed
                       n -> integer parameter
                       m -> sample size
*/
#include <stdlib.h>
#include "ccmath.h"
main(na,av)
int na; char **av;
{ unsigned long s; int n,m,i,k,*nh;
  if(na!=4){ printf("para: seed(hex) argument num_out\n"); exit(-1);}
  sscanf(*++av,"%lx",&s); n=atoi(*++av); m=atoi(*++av);
  printf(" seed= %lx\n",s);
  printf(" arg: n= %d\n",n);
  printf(" sample size m= %d\n",m);
  nh=(int *)calloc(sizeof(int),n+1);

/* initialize pseudorandom integer generator */
  setbran2(s);

  for(i=0; i<m ;++i){

/* generate a random integer in thr range 0 to n-1 */
    k=bran2(n); ++nh[k];
    if(m<100) printf(" %4d  %4d\n",i,k);
   }
  printf(" distribution\n");
  for(i=0; i<=n ;++i) printf("%3d  %4d\n",i,nh[i]);
}
/* Test output

 seed= fb797c17
 arg: n= 5
 sample size m= 30
    0     2
    1     4
    2     4
    3     0
    4     4
    5     1
    6     4
    7     2
    8     1
    9     2
   10     0
   11     1
   12     0
   13     2
   14     4
   15     0
   16     0
   17     3
   18     1
   19     3
   20     3
   21     2
   22     1
   23     3
   24     1
   25     2
   26     3
   27     4
   28     4
   29     4
 distribution
  0     5
  1     6
  2     6
  3     5
  4     8
  5     0

 seed= ef7bdb3
 arg: n= 12
 sample size m= 240000
 distribution
  0  19750
  1  20128
  2  20234
  3  20022
  4  20118
  5  20006
  6  19816
  7  20083
  8  19867
  9  20116
 10  19963
 11  19897
 12     0

*/
