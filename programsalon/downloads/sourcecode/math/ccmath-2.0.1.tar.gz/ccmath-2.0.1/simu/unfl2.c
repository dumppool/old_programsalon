/*  unfl2.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
static unsigned long s,h,ss[256];
unsigned long lranb();
double unfl2()
{ register int i; unsigned long c;
  s=lranb(s);
  h=h*69069U+4098479U;
  i=(h>>24); c=ss[i]; ss[i]=s;
  return (double)c*4.656612875245797e-10;
}
void setunfl2(sa)
unsigned long sa;
{ int k;
  for(s=sa,k=0; k<=256 ;++k){
    s=lranb(s);
    if(k<256) ss[k]=s; else h=s;
   }
}
