/*  bran2.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
static unsigned long s,h,sbuf[256];
static unsigned long a=69069U,c=4098479U;
static unsigned long r=0xffff;
unsigned long lrana();
int bran2(n)
int n;
{ register int i,j,k;
  unsigned long u;
  s=lrana(s); h=h*a+c; k=(h>>24);
  u=sbuf[k]; sbuf[k]=s;
  i=n*(u>>16); j=n*(u&r); i+=(j>>16);
  return (i>>15);
}
void setbran2(sa)
unsigned long sa;
{ int k;
  for(s=sa,k=0; k<=256 ;++k){
    s=lrana(s);
    if(k<256) sbuf[k]=s; else h=s;
   }
}
