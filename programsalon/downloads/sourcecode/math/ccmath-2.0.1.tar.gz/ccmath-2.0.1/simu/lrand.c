/*  lrand.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
static unsigned long s;
unsigned long lrana();
long lrand()
{ return (s=lrana(s));
}
setlrand(u)
unsigned long u;
{ s=u;
}
