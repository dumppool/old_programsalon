/*  autcor.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
double *autcor(x,n,lag)
double x[]; int n,lag;
{ double *p,*q,*pmax,*cf; int j; char *calloc();
  cf=(double *)calloc(lag+1,sizeof(double));
  for(p=x,pmax=x+n; p<pmax ;++p)
    for(q=p,j=0; j<=lag &&q>=x ;) *(cf+j++)+= *p* *q--;
  for(j=1; j<=lag ;) *(cf+j++)/= *cf;
  return cf;
}
