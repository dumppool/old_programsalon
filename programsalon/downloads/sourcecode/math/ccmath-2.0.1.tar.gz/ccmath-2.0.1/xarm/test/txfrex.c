/*  txfrex.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  xfrex  xpr2

    Uses:  atox  prxpr

    Prompted input:  at prompt  ' s? '
                         enter  s -> extended precision: argument

                                Ctrl-z to terminate the session
*/
#define XMATH 1
#include <stdio.h>
#include "ccmath.h"
int decd=30;
main()
{ struct xpr s; int e;
  char str[64];
  while(1){
    fprintf(stderr," s? ");
    if(scanf("%s",str)==EOF) break;
    s=atox(str);
    printf(" s-in="); prxpr(s,decd);

/* extract exponent of extended precision number */
    s=xfrex(s,&e);

    printf(" exp= %d\n",e);
    printf(" <s>= "); prxpr(s,decd);

/* restore exponent of extended precision number */
    s=xpr2(s,e);

    printf("  s1= "); prxpr(s,decd);
   }
}
/*  Test output

 s-in=  1.234500000000000000000000000000e+0
 exp= 1
 <s>=   6.172500000000000000000000000000e-1
  s1=   1.234500000000000000000000000000e+0
 s-in= -2.134500786953241108760000000000e+0
 exp= 2
 <s>=  -5.336251967383102771900000000000e-1
  s1=  -2.134500786953241108760000000000e+0
*/
