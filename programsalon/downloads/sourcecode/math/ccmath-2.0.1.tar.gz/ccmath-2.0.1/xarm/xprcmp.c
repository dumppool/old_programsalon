/*  xprcmp.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include "xpre.h"
xprcmp(pa,pb)
unsigned short *pa,*pb;
{ unsigned short e,k; int m;
  e= *pa&m_sgn; k= *pb&m_sgn;
  if(e && !k) return -1; if(!e && k) return 1;
  if(e) m= -1; else m=1;
  e= *pa&m_exp; k= *pb&m_exp;
  if(e>k) return m; if(e<k) return -m;
  for(e=0; *++pa== *++pb && e<XDIM ;++e);
  if(e<XDIM){ if(*pa> *pb) return m; else return -m;}
  return 0;
}
