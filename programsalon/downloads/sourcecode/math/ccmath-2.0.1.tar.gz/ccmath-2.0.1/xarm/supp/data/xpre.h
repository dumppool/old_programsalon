/*
   Simply alter the value of XDIM to correspond to the desired
   precision extension 11,15,19,23,27,31 below and copy the
   corresponding constant definitions to constant.h
*/
#define XDIM 7
struct xpr {unsigned short nmm[XDIM+1];};
extern unsigned short m_sgn,m_exp;
extern short bias;
extern int itt_div,k_tanh;
extern int ms_exp,ms_trg,ms_hyp;
extern short max_p,k_lin;
extern short d_bias,d_max,d_lex;
extern struct xpr zero,one,two,ten;
extern struct xpr x_huge;
extern struct xpr pi,pi2,pi4;
extern struct xpr ee,srt2,ln2;
struct xpr xadd(),xmul(),xdiv(),atox();
struct xpr dubtox(),inttox(),sfmod(),xpwr(),xpr2();
struct xpr xneg(),xabs(),xfrex(),xfmod();
double xtodub();
struct xpr xtan(),xsin(),xcos();
struct xpr xatan(),xasin(),xacos(),xatan2();
struct xpr xsqrt(),xexp(),xlog();
struct xpr xtanh(),xsinh(),xcosh();
