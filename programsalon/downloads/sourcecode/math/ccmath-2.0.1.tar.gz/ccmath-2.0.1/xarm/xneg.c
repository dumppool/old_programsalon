/*  xneg.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include "xpre.h"
struct xpr xneg(s)
struct xpr s;
{ unsigned short *p=(unsigned short *)&s;
  *p^=m_sgn; return s;
}
struct xpr xabs(s)
struct xpr s;
{ unsigned short *p=(unsigned short *)&s;
  *p&=m_exp; return s;
}
xex(ps)
unsigned short *ps;
{ return (*ps&m_exp)-bias;
}
neg(ps)
unsigned short *ps;
{ return (*ps&m_sgn);
}
