/*  scalv.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
scalv(r,s,n)
double *r,s; int n;
{ double *mx;
  for(mx=r+n; r<mx ;) *r++ *=s;
}
