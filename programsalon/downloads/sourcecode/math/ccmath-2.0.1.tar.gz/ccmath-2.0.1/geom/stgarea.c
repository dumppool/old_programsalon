/*  stgarea.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
double stgarea(a,b,c)
double a,b,c;
{ double pi=3.141592653589793;
  return (a+b+c-pi);
}
