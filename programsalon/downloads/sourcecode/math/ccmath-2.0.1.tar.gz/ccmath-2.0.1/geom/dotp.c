/*  dotp.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
double dotp(u,v,m)
double *u,*v; int m;
{ double s,*umx;
  for(umx=u+m,s=0.; u<umx ;) s+= *u++ * *v++;
  return s;
} 
