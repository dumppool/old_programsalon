/*  pshuf.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
pshuf(pa,pb,kk,n)
int kk[],n,*pa[],*pb[];
{ int *mm,*m,i,j,k,jk,**p,**q; char *malloc();
  mm=(int *)malloc((kk[0]+1)*sizeof(int));
  for(i=1,*mm=1,m=mm; i<=kk[0] ;++i,++m) *(m+1)= *m*kk[i];
  for(j=0,p=pb; j<n ;++j){ jk=j; q=pa;
    for(i=1,m=mm; i<=kk[0] ;++i){
      k=n/ *++m; q+=(jk/k)* *(m-1); jk%=k; }
    *q= *p++;
   }
  free(mm);
}
