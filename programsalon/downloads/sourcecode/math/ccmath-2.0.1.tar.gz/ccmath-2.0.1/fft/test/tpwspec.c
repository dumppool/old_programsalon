/*  tpwspec.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test: pwspec
    Uses: pfac
*/
#include <stdio.h>
#include "ccmath.h"
#include <math.h>
#define MPT 50
double x[MPT];
main()
{ double y; int kk[32],n=MPT,i;
  printf("     Test of Power Spectra Estimator\n");
  printf("       F = 1/(k+1)\n");
  for(i=0; i<n ;++i) x[i]=1./(1.+i);
  n=pfac(n,kk,'o');
  printf("      n= %d\n",n);
  pwspec(x,n,0);
  printf("  output spectra and cumulative spectra\n");
  for(i=0,y=0.; i<n ;++i){
    printf("%2d  %12e  %7.3f\n",i,x[i],y);
    y+=x[i]; }
  printf("%2d                 %7.3f\n",i,y);
}
/* Test output

     Test of Power Spectra Estimator
       F = 1/(k+1)
      n= 50
  output spectra and cumulative spectra
 0  2.491224e-001    0.000
 1  7.494981e-002    0.249
 2  4.668625e-002    0.324
 3  3.380395e-002    0.371
 4  2.633160e-002    0.405
 5  2.145248e-002    0.431
 6  1.803054e-002    0.452
 7  1.551236e-002    0.470
 8  1.359417e-002    0.486
 9  1.209478e-002    0.499
10  1.089931e-002    0.512
11  9.931375e-003    0.522
12  9.138283e-003    0.532
13  8.482576e-003    0.542
14  7.936963e-003    0.550
15  7.481164e-003    0.558
16  7.099866e-003    0.565
17  6.781358e-003    0.573
18  6.516610e-003    0.579
19  6.298621e-003    0.586
20  6.121969e-003    0.592
21  5.982480e-003    0.598
22  5.876995e-003    0.604
23  5.803207e-003    0.610
24  5.759544e-003    0.616
25  5.745090e-003    0.622
26  5.759544e-003    0.627
27  5.803207e-003    0.633
28  5.876995e-003    0.639
29  5.982480e-003    0.645
30  6.121969e-003    0.651
31  6.298621e-003    0.657
32  6.516610e-003    0.663
33  6.781358e-003    0.670
34  7.099866e-003    0.677
35  7.481164e-003    0.684
36  7.936963e-003    0.691
37  8.482576e-003    0.699
38  9.138283e-003    0.708
39  9.931375e-003    0.717
40  1.089931e-002    0.727
41  1.209478e-002    0.738
42  1.359417e-002    0.750
43  1.551236e-002    0.763
44  1.803054e-002    0.779
45  2.145248e-002    0.797
46  2.633160e-002    0.818
47  3.380395e-002    0.845
48  4.668625e-002    0.878
49  7.494981e-002    0.925
50                   1.000
*/
