/*  tctrig.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  csin  casin
           ccos  cacos
	   ctan  catan

    interactive input with 'tctrig'	   
    input from file with 'tctrig ctrg.dat'
*/
#include <stdio.h>
#include "ccmath.h"
main(na,av)
int na; char **av;
{ Cpx z,s,c,t,u; FILE *fp;
  if(na>1) fp=fopen(*++av,"r");
  while(1){
    if(na==1){ printf(" z? ");     /* enter Ctrl-Z to terminate */    
      if(scanf("%lf %lf",&z.re,&z.im)==EOF) break;
     }
    else{
      if(fscanf(fp,"%lf %lf",&z.re,&z.im)==EOF) break;
      printf(" z= (%f, %f)\n",z.re,z.im);
     }
    s=csin(z); c=ccos(z); t=ctan(z);
    printf("  sin= (%e, %e)\n",s.re,s.im); u=casin(s);
    printf(" asin= (%e, %e)\n",u.re,u.im);
    printf("  cos= (%e, %e)\n",c.re,c.im); u=cacos(c);
    printf(" acos= (%e, %e)\n",u.re,u.im);
    printf("  tan= (%e, %e)\n",t.re,t.im); u=catan(t);
    printf(" atan= (%e, %e)\n",u.re,u.im);
   }
}
/* Test output

 z= (1.000000, 1.000000)
  sin= (1.298458e+000, 6.349639e-001)
 asin= (1.000000e+000, 1.000000e+000)
  cos= (8.337300e-001, -9.888977e-001)
 acos= (1.000000e+000, 1.000000e+000)
  tan= (2.717526e-001, 1.083923e+000)
 atan= (1.000000e+000, 1.000000e+000)
 z= (-1.000000, 2.000000)
  sin= (-3.165779e+000, 1.959601e+000)
 asin= (-1.000000e+000, 2.000000e+000)
  cos= (2.032723e+000, 3.051898e+000)
 acos= (1.000000e+000, -2.000000e+000)
  tan= (-3.381283e-002, 1.014794e+000)
 atan= (-1.000000e+000, 2.000000e+000)
 z= (-2.000000, 3.000000)
  sin= (-9.154499e+000, -4.168907e+000)
 asin= (-1.141593e+000, -3.000000e+000)
  cos= (-4.189626e+000, 9.109228e+000)
 acos= (2.000000e+000, -3.000000e+000)
  tan= (3.764026e-003, 1.003239e+000)
 atan= (1.141593e+000, 3.000000e+000)
 z= (-0.800000, -1.200000)
  sin= (-1.298885e+000, -1.051652e+000)
 asin= (-8.000000e-001, -1.200000e+000)
  cos= (1.261496e+000, -1.082821e+000)
 acos= (8.000000e-001, 1.200000e+000)
  tan= (-1.808284e-001, -9.888710e-001)
 atan= (-8.000000e-001, -1.200000e+000)
*/
