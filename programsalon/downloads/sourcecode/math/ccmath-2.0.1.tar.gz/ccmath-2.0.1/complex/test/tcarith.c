/*  tcarith.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  cadd  csub  cmul  cdiv

    interactive input with 'tcarith'
    input from file with 'tcarith carith.dat'
*/
#include <stdio.h>
#include "ccmath.h"
main(na,av)
int na; char **av;
{ Cpx a,b,f; FILE *fp;
  if(na>1) fp=fopen(*++av,"r");
  while(1){
    if(na==1){ printf(" a? b?\n");
      if(scanf("%lf %lf %lf %lf",&a.re,&a.im,&b.re,&b.im)==EOF) break;
     }
    else if(fscanf(fp,"%lf %lf %lf %lf",&a.re,&a.im,&b.re,&b.im) ==EOF) break;
    printf("   a=(%f, %f) b=(%f, %f)\n",a.re,a.im,b.re,b.im);
    f=cadd(a,b); printf(" a+b=(%e, %e)\n",f.re,f.im);
    f=csub(a,b); printf(" a-b=(%e, %e)\n",f.re,f.im);
    f=cmul(a,b); printf(" a*b=(%e, %e)\n",f.re,f.im);
    f=cdiv(a,b); printf(" a/b=(%e, %e)\n",f.re,f.im);
   }
}
/* Test output

   a=(1.000000, 1.000000) b=(2.000000, -0.500000)
 a+b=(3.000000e+000, 5.000000e-001)
 a-b=(-1.000000e+000, 1.500000e+000)
 a*b=(2.500000e+000, 1.500000e+000)
 a/b=(3.529412e-001, 5.882353e-001)
   a=(1.000000, 3.000000) b=(-3.000000, -1.600000)
 a+b=(-2.000000e+000, 1.400000e+000)
 a-b=(4.000000e+000, 4.600000e+000)
 a*b=(1.800000e+000, -1.060000e+001)
 a/b=(-6.747405e-001, -6.401384e-001)
   a=(0.200000, -1.000000) b=(-0.700000, 4.000000)
 a+b=(-5.000000e-001, 3.000000e+000)
 a-b=(9.000000e-001, -5.000000e+000)
 a*b=(3.860000e+000, 1.500000e+000)
 a/b=(-2.510612e-001, -6.064281e-003)
*/
