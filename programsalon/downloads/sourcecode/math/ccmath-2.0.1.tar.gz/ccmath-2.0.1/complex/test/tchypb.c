/*  tchypb.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  csinh  casinh
           ccosh  cacosh
	   ctanh  catanh

    interactive input with 'tchypb'
    input from file with 'tchypb chypb.dat'
*/
#include "ccmath.h"
#include <stdio.h>
main(na,av)
int na; char **av;
{ Cpx z,f,u; FILE *fp;
  if(na>1) fp=fopen(*++av,"r");
  while(1){
    if(na==1){ printf("z ? ");     /* enter Ctrl-Z to terminate */    
      if(scanf("%lf %lf",&z.re,&z.im)==EOF) break;
     }
    else{
      if(fscanf(fp,"%lf %lf",&z.re,&z.im)==EOF) break;
      printf(" z=(%f, %f)\n",z.re,z.im);
     }
    f=csinh(z); u=casinh(f);
    printf(" sinh = (%e, %e)\n",f.re,f.im);
    printf(" asinh= (%e, %e)\n",u.re,u.im);
    f=ccosh(z); u=cacosh(f);
    printf(" cosh = (%e, %e)\n",f.re,f.im);
    printf(" acosh= (%e, %e)\n",u.re,u.im);
    f=ctanh(z); u=catanh(f);
    printf(" tanh = (%e, %e)\n",f.re,f.im);
    printf(" atanh= (%e, %e)\n",u.re,u.im);
   }
}
/* Test output

 z=(1.000000, 1.000000)
 sinh = (6.349639e-001, 1.298458e+000)
 asinh= (1.000000e+000, 1.000000e+000)
 cosh = (8.337300e-001, 9.888977e-001)
 acosh= (1.000000e+000, 1.000000e+000)
 tanh = (1.083923e+000, 2.717526e-001)
 atanh= (1.000000e+000, 1.000000e+000)
 z=(-0.800000, 0.750000)
 sinh = (-6.498173e-001, 9.116475e-001)
 asinh= (-8.000000e-001, 7.500000e-001)
 cosh = (9.785863e-001, -6.053675e-001)
 acosh= (8.000000e-001, -7.500000e-001)
 tanh = (-8.970495e-001, 3.766688e-001)
 atanh= (-8.000000e-001, 7.500000e-001)
 z=(-0.300000, -1.200000)
 sinh = (-1.103453e-001, -9.742964e-001)
 asinh= (-3.000000e-001, -1.200000e+000)
 cosh = (3.787865e-001, 2.838248e-001)
 acosh= (3.000000e-001, 1.200000e+000)
 tanh = (-1.420875e+000, -1.507490e+000)
 atanh= (-3.000000e-001, -1.200000e+000)
 z=(1.500000, -0.600000)
 sinh = (1.757370e+000, -1.328270e+000)
 asinh= (1.500000e+000, -6.000000e-001)
 cosh = (1.941527e+000, -1.202282e+000)
 acosh= (1.500000e+000, -6.000000e-001)
 tanh = (9.604848e-001, -8.936120e-002)
 atanh= (1.500000e+000, -6.000000e-001)
*/
