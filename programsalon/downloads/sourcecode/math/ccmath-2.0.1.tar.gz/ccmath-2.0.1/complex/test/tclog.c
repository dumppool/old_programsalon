/*  tclog.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  clog  cexp

    input from file with 'tclog < clog.dat'
*/
#include <stdio.h>
#include "ccmath.h"
main(na,av)
int na; char **av;
{ Cpx z,f; FILE *fp;
  if(na>1) fp=fopen(*++av,"r");
  while(1){
    if(na==1){ printf(" z? ");     /* terminate input with Ctrl-Z */    
      if(scanf("%lf %lf",&z.re,&z.im)==EOF) break;
     }
    else{ if(fscanf(fp,"%lf %lf",&z.re,&z.im)==EOF) break;
      printf(" z= (%f, %f)\n",z.re,z.im);
     }
    f=cexp(z); z=clog(f);
    printf("      exp= (%e, %e)\n",f.re,f.im);
    printf("      log= (%e, %e)\n",z.re,z.im);
    f=cexp(z);
    printf(" exp(log)= (%e, %e)\n",f.re,f.im);
   }
}
/* Test output

 z= (1.000000, 2.000000)
      exp= (-1.131204e+000, 2.471727e+000)
      log= (1.000000e+000, 2.000000e+000)
 exp(log)= (-1.131204e+000, 2.471727e+000)
 z= (1.000000, -0.500000)
      exp= (2.385517e+000, -1.303214e+000)
      log= (1.000000e+000, -5.000000e-001)
 exp(log)= (2.385517e+000, -1.303214e+000)
 z= (0.500000, 4.000000)
      exp= (-1.077676e+000, -1.247756e+000)
      log= (5.000000e-001, -2.283185e+000)
 exp(log)= (-1.077676e+000, -1.247756e+000)
 z= (-1.200000, 3.000000)
      exp= (-2.981800e-001, 4.250453e-002)
      log= (-1.200000e+000, 3.000000e+000)
 exp(log)= (-2.981800e-001, 4.250453e-002)
*/
