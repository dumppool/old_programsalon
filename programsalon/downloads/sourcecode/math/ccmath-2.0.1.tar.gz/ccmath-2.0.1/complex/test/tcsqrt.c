/*  tcsqrt.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  csqrt
    Uses:  cmul

    interactive input with 'tcsqrt'
    input from file with 'tcsqrt csqrt.dat'
*/
#include <stdio.h>
#include "ccmath.h"
main(na,av)
int na; char **av;
{ Cpx z,f; FILE *fp;
  if(na>1) fp=fopen(*++av,"r");
  while(1){
    if(na==1){
      printf(" z? ");     /* enter Ctrl-Z to terminate input */    
      if(scanf("%lf %lf",&z.re,&z.im)==EOF) break;
     }
    else{ if(fscanf(fp,"%lf %lf",&z.re,&z.im)==EOF) break;
      printf(" z=(%f, %f)\n",z.re,z.im);
     }
    f=csqrt(z);
    printf("  sqrt=(%e, %e)\n",f.re,f.im);
    f=cmul(f,f);
    printf(" check=(%e, %e)\n",f.re,f.im);
   }
}
/* Test output

 z=(1.000000, 1.000000)
  sqrt=(1.098684e+000, 4.550899e-001)
 check=(1.000000e+000, 1.000000e+000)
 z=(-1.000000, 0.500000)
  sqrt=(2.429341e-001, 1.029086e+000)
 check=(-1.000000e+000, 5.000000e-001)
 z=(-1.000000, -0.500000)
  sqrt=(2.429341e-001, -1.029086e+000)
 check=(-1.000000e+000, -5.000000e-001)
 z=(2.000000, -1.000000)
  sqrt=(1.455347e+000, -3.435607e-001)
 check=(2.000000e+000, -1.000000e+000)
*/
