/*  carith.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include "complex.h"
struct complex cmul(s,t)
struct complex s,t;
{ double u;
  u=s.re*t.re-s.im*t.im;
  s.im=s.im*t.re+s.re*t.im; s.re=u;
  return s;
}
struct complex cdiv(s,t)
struct complex s,t;
{ double u,r;
  r=t.re*t.re+t.im*t.im;
  u=(s.re*t.re+s.im*t.im)/r;
  s.im=(s.im*t.re-s.re*t.im)/r; s.re=u;
  return s;
}
struct complex cadd(s,t)
struct complex s,t;
{ s.re+=t.re; s.im+=t.im;
  return s;
}
struct complex csub(s,t)
struct complex s,t;
{ s.re-=t.re; s.im-=t.im;
  return s;
}
struct complex crmu(a,z)
struct complex z; double a;
{ z.re*=a; z.im*=a; return z;
}
struct complex cimu(b,z)
struct complex z; double b;
{ double u;
  u=z.re*b; z.re= -z.im*b; z.im=u;
  return z;
}
struct complex ccng(z)
struct complex z;
{ z.im= -z.im; return z;
}
struct complex cdef(r,i)
double r,i;
{ struct complex s;
  s.re=r; s.im=i; return s;
}
double cabs(c)
struct complex c;
{ return sqrt(c.re*c.re+c.im*c.im);
}
double cnrm(z)
struct complex z;
{ return z.re*z.re+z.im*z.im;
}
