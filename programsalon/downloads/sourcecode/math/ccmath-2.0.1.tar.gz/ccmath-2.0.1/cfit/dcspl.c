/*  dcspl.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
double dcspl(x,u,v,z,m)
double x,u[],v[],z[]; int m;
{ int i,k; double h,d;
  if(x>u[m] || x<u[0]) return 0.;
  for(i=1; x>u[i] ;++i);
  k=i-1; h=u[i]-u[k];
  x-=u[k]; x/=h;
  d=(v[i]-v[k])/h;
  return d-h*((z[i]-z[k])*(1.-3.*x*x)+z[k]*(3.-6.*x));
}
