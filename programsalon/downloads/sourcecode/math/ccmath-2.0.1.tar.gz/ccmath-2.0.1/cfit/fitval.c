/*  fitval.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include <math.h>
static double *h,dl=1.e-8;
double fitval(x,s,par,fun,v,n)
double x,*s,*par,*v,(*fun)(); int n;
{ double f,r,d; int i,j;
  f=(*fun)(x,par);
  for(i=0; i<n ;++i){
    par[i]+=dl; h[i]=((*fun)(x,par)-f)/dl;
    par[i]-=dl;
   }
  for(i=0,r=0.; i<n ;){
    for(j=0,d=0.; j<n ;) d+= *v++ *h[j++];
    r+=d*h[i++];
   }
  *s=sqrt(r); return f;
}
setfval(i,n)
int i,n;
{ char *calloc();
  if(i==0) h=(double *)calloc(n,sizeof(*h));
  else free(h);
}
