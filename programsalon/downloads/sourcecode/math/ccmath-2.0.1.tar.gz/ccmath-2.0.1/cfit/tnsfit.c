/*  tnsfit.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include <math.h>
double tnsfit(w,x,y,z,m,tn)
double w,x[],y[],z[],tn; int m;
{ double s,t,u,a=sinh(tn); int j,k;
  if(w<x[0] || w>x[m]) return 0.;
  for(j=1; w>x[j] ;++j); k=j-1;
  t=(w-x[k])/(s=x[j]-x[k]); s*=s/(a-tn); u=1.-t;
  return t*y[j]+u*y[k]+s*(z[j]*(sinh(tn*t)-t*a)+z[k]*(sinh(tn*u)-u*a));
}
