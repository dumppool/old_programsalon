/*  tchpade.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  chpade  ftch
    Uses:  chcof  matprt

    Alternative values for the degree of the numerator (nn) and
    denominator (nd) can be used with the call: 'tchpade nn nd'
    mc > nn+nd is required
*/
#include "ccmath.h"
#include <math.h>
#define ND 15
#define NP 30
int nn=3,nd=3;
/* increase mc if you intend to use nn+nd > 12 */
int mc=12;
char fnam[]="exp([1+x]/2)";
main(na,av)
int na; char **av;
{ double c[NP],a[ND],b[ND],fun(),y,f,er,xx,maxer;
  int j;
  if(na==3){
    nn=atoi(*++av); nd=atoi(*++av);
   }
  printf("     Test of Rational Tchebycheff Approximation\n");
  printf("          approximating %s\n\n",fnam);
  chcof(c,mc,fun);
  printf(" series coefficients:\n");
  for(j=0; j<=mc ;++j) printf(" %2d  %12e\n",j,c[j]);
  chpade(c,a,nn,b,nd);
  printf(" numerator coef.:\n"); matprt(a,nn,1,"  %e");
  printf(" denominator coef.:\n"); matprt(b,nd,1," %e");
/*
   loop for approximate evaluation of the maximum error of
   the Tchebycheff Pade' approximation
*/
  for(maxer=0.,y=-1.; y<1.01 ;y+=.05){
    er=ftch(y,a,nn,b,nd); f=fun(y); er-=f;
    if((er=fabs(er))>maxer){ maxer=er; xx=y;}
   }
  printf(" maximum error = %e at x= %f\n",maxer,xx);
}
/*
   The function used here is evaluated on the interval
   -1 <= x <= 1. Other functions defined on this
   interval may be substituted.
*/
double fun(x)
double x;
{ double y=(1.+x)/2.;
  return exp(y);
}
/* Test output

     Test of Rational Tchebycheff Approximation
          approximating exp([1+x]/2)

 series coefficients:
  0  3.506775e+000
  1  8.503917e-001
  2  1.052087e-001
  3  8.722105e-003
  4  5.434368e-004
  5  2.711543e-005
  6  1.128133e-006
  7  4.024558e-008
  8  1.256585e-009
  9  3.487902e-011
 10  8.766577e-013
 11  1.726824e-014
 12  1.680280e-015
 numerator coef.:
  1.648767e+000
  4.085534e-001
  2.036711e-002
 denominator coef.:
 1.000000e+000
 -2.475755e-001
 1.232562e-002
 maximum error = 2.916285e-009 at x= 1.000000
*/
