/*  tfitval.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  fitval  setfval

    Variance matrix array for 3-parameter test function 'frat'.
*/    
double v[]={1.2e-2,2.1e-3,4.0e-3,2.1e-3,5.3e-3,
 9.0e-4,4.0e-3,9.0e-4,8.5e-3};
/*
    Test function 'frat' used in variance analysis test.
*/    
double frat(x,p)
double x,*p;
{ return p[0]*x/(p[1]+p[2]*x*x);
}

#include "ccmath.h"
main()
{ double par[3],f,s,x,dx;
  int i,n,m;
  printf("     Test of Fit-Confidence Bound\n");
  m=3;
  par[0]=2.; par[1]=1.; par[2]=.5;
  setfval(0,m);
  x=0.2; dx=.2; n=20;
  printf("    x      value           sigma\n");
  for(i=0; i<n ;++i,x+=dx){
    f=fitval(x,&s,par,frat,v,m);
    printf(" %6.2f  %12.5e   %9.2e\n",x,f,s);
   }
}
/* Test output

     Test of Fit-Confidence Bound
    x      value           sigma
   0.20  3.92157e-001   3.03e-002
   0.40  7.40741e-001   5.46e-002
   0.60  1.01695e+000   7.24e-002
   0.80  1.21212e+000   8.72e-002
   1.00  1.33333e+000   1.02e-001
   1.20  1.39535e+000   1.17e-001
   1.40  1.41414e+000   1.31e-001
   1.60  1.40351e+000   1.42e-001
   1.80  1.37405e+000   1.50e-001
   2.00  1.33333e+000   1.55e-001
   2.20  1.28655e+000   1.57e-001
   2.40  1.23711e+000   1.58e-001
   2.60  1.18721e+000   1.57e-001
   2.80  1.13821e+000   1.55e-001
   3.00  1.09091e+000   1.53e-001
   3.20  1.04575e+000   1.49e-001
   3.40  1.00295e+000   1.46e-001
   3.60  9.62567e-001   1.42e-001
   3.80  9.24574e-001   1.38e-001
   4.00  8.88889e-001   1.35e-001
*/
