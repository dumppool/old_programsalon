/*  tgnlsq.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  gnlsq
    Uses:  matprt
*/
#include "ccmath.h"
#define ND 50
#define NP 4
/* true function parameters */
double parm[]={2.,-1.,1.5,2.};
char fnc[]="(p0+x*p1)/(1+p2*x+p3*x^2)";
main()
{ double x[ND],y[ND],var[NP*NP],de,z,dz,*p;
  double ssq,fit();
  int n=ND,np=NP,j;
  char fl[4];
  printf("     Test of Gauss-Newton Least Squares\n");
  printf(" f(x) = %s\n\n",fnc);
/* define the input values by using true parameters */
  for(j=0,z=0.,dz=.1; j<n ;++j){
    x[j]=z; y[j]=fit(z,parm); z+=dz; }
/* loop of prompts for initial fit function parameters */
  for(j=0,p=parm; j<np ;){
    fprintf(stderr,"input para %d ",j++); scanf("%lf",p++); }
  printf(" initial parameters:\n");
  matprt(parm,1,np," %.3f");
  for(de=.02,j=1;;++j){
    ssq=gnlsq(x,y,n,parm,var,np,de,fit);
    printf("\n step %d  ssq= %e\n",j,ssq);
    printf(" estimated parameters:\n");
    matprt(parm,1,np," %f");
/* prompt for next step */
    fprintf(stderr," continue ? (y/n) "); scanf("%s",fl);
    if(*fl=='n') break;
   }
  printf("\n variance matrix:\n");
  matprt(var,np,np," %11.3e");
}
/*
 The following code defines the fit function.  Code for new functions
 can be substituted. Be sure to alter the values for number of points
 ND and parameters NP if these are different in the new function. The
 initialization of fnc should also be altered to describe the new function.
*/
double fit(x,parm)
double x,parm[];
{ return (parm[0]+x*parm[1])/(1.+x*(parm[2]+parm[3]*x));
}
/* Test output

     Test of Gauss-Newton Least Squares
 f(x) = (p0+x*p1)/(1+p2*x+p3*x^2)

 initial parameters:
 1.000 0.000 0.000 1.000

 step 1  ssq= 2.968270e+000
 estimated parameters:
 1.950656 -0.777336 2.219134 0.297415

 step 2  ssq= 1.757230e-001
 estimated parameters:
 2.028739 -0.952354 1.979850 1.225173

 step 3  ssq= 1.583770e-002
 estimated parameters:
 2.002749 -0.999820 1.540071 1.909456

 step 4  ssq= 1.586472e-004
 estimated parameters:
 2.000022 -1.000069 1.500247 1.998958

 step 5  ssq= 2.748435e-008
 estimated parameters:
 2.000000 -1.000000 1.499998 2.000006

 step 6  ssq= 7.076529e-013
 estimated parameters:
 2.000000 -1.000000 1.500000 2.000000

 step 7  ssq= 2.743347e-017
 estimated parameters:
 2.000000 -1.000000 1.500000 2.000000

 variance matrix:
  8.646e-001 -3.123e-001  3.307e+000 -1.370e+000
 -3.123e-001  1.278e+000  4.294e-001  3.909e-001
  3.307e+000  4.294e-001  3.003e+001 -2.878e+001
 -1.370e+000  3.909e-001 -2.878e+001  5.872e+001
*/
