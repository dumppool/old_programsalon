/*  tlsqsv.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  lsqsv

    Uses:  svdlsq  eigen

    Test input:  lsqsv.dat
*/
#include <stdio.h>
#include "ccmath.h"
main(na,av)
int na; char **av;
{ double x,dx,f,t,ssq;
  double *a,*b,*c,*d,*v,*var,*p;
  int n,m,i,j;
  FILE *fp;
  if(na!=2){ printf("para: in_file\n"); exit(-1);}
  fp=fopen(*++av,"r");
  fscanf(fp,"%d %d %lf",&n,&m,&dx);
  a=(double *)calloc(m*n,sizeof(double));
  b=(double *)calloc(m,sizeof(double));
  c=(double *)calloc(n,sizeof(double));
  d=(double *)calloc(n,sizeof(double));
  v=(double *)calloc(n*n,sizeof(double));
  var=(double *)calloc(n*n,sizeof(double));
  for(i=0; i<n ;++i) fscanf(fp,"%lf",c+i);
  printf(" %d meas. %d param.\n",m,n);
  printf(" cf-in:\n"); matprt(c,1,n," %9.4f");
  for(i=0,x=0.,p=a; i<m ;++i){
    x+=dx;
    for(j=0,f=0.,t=1.; j<n ;++j){
      f+=c[j]*(*p++ =t); t*=x;
     }
    b[i]=f;
   }
  
/* Compute lsq solution using a singular value decomposition */
  svdlsq(d,a,b,m,v,n);

  printf(" sing-val:\n"); matprt(d,1,n," %.2e");
/* enter threshold for a a singular value effectively = zero */
  printf(" enter threshold: "); scanf("%lf",&t);
/* compute least squares reduced rank solution */
  ssq=lsqsv(c,&j,var,d,b,v,m,n,t);

  printf(" rank: %d ssq= %.2e\n",j,ssq);
  printf(" cf-out:\n"); matprt(c,1,n," %14.6e");
  printf(" cf-var-mat:\n"); matprt(var,n,n," %11.3e");
/* compute eigenvectors and values of the variance matrix */
  eigen(var,d,n);
  printf(" var-ev:\n"); matprt(d,1,n," %11.3e");
  printf(" var-evec:\n"); matprt(var,n,n," %11.6f");
}
/* Test output

 8 meas. 5 param.
 cf-in:
    1.0000    0.4000    2.1000   -1.2000   -0.7000
 sing-val:
 3.27e+000 9.33e-001 1.84e-001 2.42e-002 1.81e-003
 
 enter threshold: (2.e-3 was entered -> reduced rank solution)
 
 rank: 4 ssq= 8.10e-006
 cf-out:
  9.880617e-001  5.725394e-001  1.359790e+000  9.697705e-003 -1.365042e+000
 cf-var-mat:
  1.186e-005 -8.538e-005  1.347e-004  3.166e-005 -1.147e-004
 -8.538e-005  7.003e-004 -1.186e-003 -2.550e-004  1.039e-003
  1.347e-004 -1.186e-003  2.121e-003  4.174e-004 -1.911e-003
  3.166e-005 -2.550e-004  4.174e-004  9.660e-005 -3.557e-004
 -1.147e-004  1.039e-003 -1.911e-003 -3.557e-004  1.752e-003
 var-ev:
  4.599e-003  7.943e-005  3.102e-006  2.523e-007  2.121e-019
 var-evec:
    0.043243   -0.171071   -0.491188   -0.852960    0.007576
   -0.379459    0.686195    0.447672   -0.415632   -0.109486
    0.678953   -0.029656    0.506425   -0.247091    0.469705
    0.133146   -0.427051    0.429523   -0.161764   -0.767622
   -0.612728   -0.562690    0.342590   -0.111746    0.422006
*/
