/*  tplsq.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  plsq  psqcf  psqvar
*/
#include "ccmath.h"
#define ND 100
#define NP 5
double x[ND],y[ND];
main()
{ double dx,z;
/* set dimensions of arrays
   used by plsq for output */
  double ssq[NP]; Opol cf[NP];
  double bc[NP],var[NP*NP];
  int n,np,j;
  printf("     Test of Polynominal Least Squares\n");
/* set number of input points */
  n=ND;
/*
  The test fit inputs are the values of a polynominal of
  degree 4, defined in this loop.
*/
  for(j=0,dx=.1; j<n ;++j){
    z=(x[j]=j*dx); y[j]=1.+z*(1.+z*(2.+z*(-3.+.5*z))); }
/* set maximum fit order */
  np=NP;

/* compute polynominal fits to maximum order */
  plsq(x,y,n,cf,ssq,np);
  for(j=0; j<np ;++j)
    printf(" fit order: %d  ssq= %e\n",j+1,ssq[j]);
  printf(" orthogonal polynominal cf df hs\n");
  for(j=0; j<np ;++j)
    printf(" %d  %e  %e  %e\n",j,cf[j].cf,cf[j].df,cf[j].hs);
  for(j=2; j<=np ;++j){
/* compute polynominal coefficients */	  
    psqcf(bc,cf,j);
    z=ssq[j-1]/(double)(n-j);
/* compute coefficient variances */    
    psqvar(var,z,cf,j);
    printf(" fit: %d\n",j);
    printf("  coefficients:\n"); matprt(bc,1,j," %9.4f");
    printf("  coefficient variance matrix:\n");
    matprt(var,j,j," %11.3e");
   }
}
/* Test output

     Test of Polynominal Least Squares
 fit order: 1  ssq= 2.923643e+007
 fit order: 2  ssq= 1.139496e+007
 fit order: 3  ssq= 1.754497e+006
 fit order: 4  ssq= 5.651943e+004
 fit order: 5  ssq= 7.038785e-024
 orthogonal polynominal cf df hs
 0  3.117117e+002  4.950000e+000  1.000000e+002
 1  1.463281e+002  4.950000e+000  8.332500e+000
 2  4.166714e+001  4.950000e+000  6.664000e+000
 3  6.900000e+000  4.950000e+000  6.422786e+000
 4  5.000000e-001  0.000000e+000  6.339048e+000
 fit: 2
  coefficients:
 -412.6124  146.3281
  coefficient variance matrix:
  4.582e+003 -6.907e+002
 -6.907e+002  1.395e+002
 fit: 3
  coefficients:
  261.1453 -266.1766   41.6671
  coefficient variance matrix:
  1.564e+003 -6.289e+002  5.267e+001
 -6.289e+002  3.410e+002 -3.225e+001
  5.267e+001 -3.225e+001  3.257e+000
 fit: 4
  coefficients:
  -63.5322  137.5493  -60.7979    6.9000
  coefficient variance matrix:
  8.747e+001 -6.592e+001  1.325e+001 -7.768e-001
 -6.592e+001  6.761e+001 -1.539e+001  9.659e-001
  1.325e+001 -1.539e+001  3.746e+000 -2.451e-001
 -7.768e-001  9.659e-001 -2.451e-001  1.651e-002
 fit: 5
  coefficients:
    1.0000    1.0000    2.0000   -3.0000    0.5000
  coefficient variance matrix:
  1.647e-026 -1.985e-026  6.980e-027 -9.353e-028  4.230e-029
 -1.985e-026  3.295e-026 -1.318e-026  1.894e-027 -8.950e-029
  6.980e-027 -1.318e-026  5.641e-027 -8.458e-028  4.116e-029
 -9.353e-028  1.894e-027 -8.458e-028  1.306e-028 -6.489e-030
  4.230e-029 -8.950e-029  4.116e-029 -6.489e-030  3.277e-031
*/
