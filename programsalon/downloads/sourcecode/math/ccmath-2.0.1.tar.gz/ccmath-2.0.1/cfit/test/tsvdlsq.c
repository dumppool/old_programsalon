/*  tsvdlsq.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  svdlsq

    Uses:  svduv

    Test input:  tlsq1.dat
*/
#include <stdio.h>
#include "ccmath.h"
main(na,av)
int na; char **av;
{ int m,n,i;
  double *a,*b,*d,*v,*p;
  double *a1,*b1,*u,s;
  FILE *fp;
  if(na!=2){ printf("para: in_file\n"); exit(-1);}
  fp=fopen(*++av,"r");
  fscanf(fp,"%d %d",&m,&n);
  printf(" %d meas. %d param.\n",m,n);
  a=(double *)calloc(m*n,sizeof(double));
  b=(double *)calloc(m,sizeof(double));
  d=(double *)calloc(n,sizeof(double));
  v=(double *)calloc(n*n,sizeof(double));
  a1=(double *)calloc(m*n,sizeof(double));
  b1=(double *)calloc(m,sizeof(double));
  u=(double *)calloc(m*m,sizeof(double));
  for(i=0,p=a; i<m*n ;++i) fscanf(fp,"%lf",p++);
  for(i=0,p=b; i<n ;++i) fscanf(fp,"%lf",p++);
  mcopy(a1,a,m*n); mcopy(b1,b,m);

/* compute least squares solution using SVD */
  svdlsq(d,a,b,m,v,n);
  
  printf(" sing-val:\n"); matprt(d,1,n," %13.6e");
  printf(" vec-b~:\n"); matprt(b,1,m," %13.6e");
  printf(" v-mat:\n"); matprt(v,n,n," %9.6f");
  for(i=n,s=0.; i<m ;++i) s+=b[i]*b[i];
  printf(" ssq= %e\n\n",s);

/* Compute singular values */  
  svduv(d,a1,u,m,v,n);
  
  printf(" sing-val:\n"); matprt(d,1,n," %13.6e");
  trnm(u,m); vmul(b,u,b1,m);
  printf(" vec-b1~:\n"); matprt(b,1,m," %13.6e");
  printf(" v1-mat:\n"); matprt(v,n,n," %9.6f");
}
/* Test output

 7 meas. 4 param.
 sing-val:
 7.639121e+000 5.102374e+000 4.015163e+000 1.421469e+000
 vec-b~:
 1.204588e+000 -2.114046e+000 -4.099105e-002 4.222126e-001 -7.935015e-001 1.041232e+000 -1.898106e-001
 v-mat:
  0.195529 -0.515817  0.811628  0.192251
 -0.581590 -0.642625 -0.352005  0.353381
  0.595632  0.034045 -0.298332  0.745025
 -0.518405  0.565514  0.358260  0.532071
 ssq= 1.749837e+000

 sing-val:
 7.639121e+000 5.102374e+000 4.015163e+000 1.421469e+000
 vec-b1~:
 1.204588e+000 -2.114046e+000 -4.099105e-002 4.222126e-001 -7.935015e-001 1.041232e+000 -1.898106e-001
 v1-mat:
  0.195529 -0.515817  0.811628  0.192251
 -0.581590 -0.642625 -0.352005  0.353381
  0.595632  0.034045 -0.298332  0.745025
 -0.518405  0.565514  0.358260  0.532071
*/
