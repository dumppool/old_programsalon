/*  tchpade2.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  chpade  ftch
    Uses:  chcof  matprt

    This test uses a restricted range for the argument of the
    exponential function.

    Alternative values for the degree of the numerator (nn) and
    denominator (nd) can be used with the call: 'tchpade2 nn nd'
    mc > nn+nd is required.
*/
#include "ccmath.h"
#include <math.h>
#define ND 15
#define NP 30
int nn=3,nd=3;
int mc=12;
char fnam[]="exp([1+x]/4)";
main(na,av)
int na; char **av;
{ double c[NP],a[ND],b[ND],fun(),y,f,er,xx,maxer;
  int j;
  if(na==3){
    nn=atoi(*++av); nd=atoi(*++av);
   }
  printf("     Test of Rational Tchebycheff Approximation\n");
  printf("          approximating  %s\n\n",fnam);
  chcof(c,mc,fun);
  printf(" series coefficients:\n");
  for(j=0; j<=mc ;++j) printf(" %2d  %12e\n",j,c[j]);
  chpade(c,a,nn,b,nd);
  printf(" numerator coef.:\n"); matprt(a,nn,1,"  %23.15e");
  printf(" denominator coef.:\n"); matprt(b,nd,1,"  %23.15e");
  for(maxer=0.,y=-1.; y<1.005 ;y+=.01){
    er=ftch(y,a,nn,b,nd); f=fun(y); er-=f;
    if((er=fabs(er))>maxer){ maxer=er; xx=y;}
   }
  printf(" maximum error = %e at x= %f\n",maxer,xx);
}
/* function evaluated on interval -1 <= x <= 1 */
double fun(x)
double x;
{ double y=(1.+x)/4.;
  return exp(y);
}
/* Test output

     Test of Rational Tchebycheff Approximation
          approximating  exp([1+x]/4)

 series coefficients:
  0  2.608334e+000
  1  3.235208e-001
  2  2.016760e-002
  3  8.392246e-004
  4  2.620531e-005
  5  6.547918e-007
  6  1.363642e-008
  7  2.434385e-010
  8  3.803675e-012
  9  5.077989e-014
 10  5.209508e-015
 11  -2.651725e-015
 12  1.509476e-015
 numerator coef.:
   1.284027647638398e+000
   1.601461934741684e-001
   4.000677855926660e-003
 denominator coef.:
   1.000000000000000e+000
  -1.246940729282121e-001
   3.113993581481599e-003
 maximum error = 1.466804e-011 at x= 1.000000
*/
