/*  tcspl.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  cspl  csfit  dcspl (when tn=0) or  tnsfit (when tn!=0)

    To set a nonzero tension call: 'tcspl tn'  0 <= tn < 1 is assumed.
    A user specified point set can be stored as x-y pairs in a file
    and specified with the call: 'tcspl tn file'.

    The file cspin.dat is a sample file specifing the same points as
    the test arrays initialized in this code.
*/
#include "ccmath.h"
#include <stdio.h>
#define MD 20
/* number of splines = interpolation points - 1 */
int n=7;
/* x values */
double x[MD]={
 0.0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4};
/* y values */
double y[MD]={
 0.0, 1.5, 1.8, 0.5, -1.0, -1.2, -0.3, 0.5};
/* tension of spline */
double tn=0.;
main(na,av)
int na; char **av;
{ double p[MD],s,ds; int j;
  double atof(); FILE *fp;
  if(na>=2) tn=atof(*++av);
  if(na==3){
    fp=fopen(*++av,"r");
    for(n=0; fscanf(fp,"%lf %lf",x+n,y+n)!=EOF ;++n);
    --n;
   }
/* ds is the x-interval used in spline evaluation */
  ds=.04;
  printf("     Test of Cubic Spline Interpolation\n");
  printf("  tension= %f\n",tn);
  cspl(x,y,p,n,tn);
  printf("  spline coefficients\n");
  for(j=0; j<=n ;++j)
    printf(" %d x=%f y=%f z=%e\n",j,x[j],y[j],p[j]);
  if(tn==0.) printf("  evaluation of spline and derivative\n");
  else printf("  evaluation of spline with tension\n");
  for(s=0.; s<=1.4 ;s+=ds){
    if(tn==0.){ printf(" x= %8.3f  F= %14.6e",s,csfit(s,x,y,p,n));
      printf("  F'= %14.6e\n",dcspl(s,x,y,p,n));
     }
    else printf(" x= %8.3f  F= %14.6e\n",s,tnsfit(s,x,y,p,n,tn));
   }
}
/* Test output

     Test of Cubic Spline Interpolation
  tension= 0.000000
  spline coefficients
 0 x=0.000000 y=0.000000 z=0.000000e+000
 1 x=0.200000 y=1.500000 z=-5.391618e+000
 2 x=0.400000 y=1.800000 z=-8.433528e+000
 3 x=0.600000 y=0.500000 z=-8.742700e-001
 4 x=0.800000 y=-1.000000 z=6.930608e+000
 5 x=1.000000 y=-1.200000 z=5.651838e+000
 6 x=1.200000 y=-0.300000 z=-2.037959e+000
 7 x=1.400000 y=0.500000 z=0.000000e+000
  evaluation of spline and derivative
 x=    0.000  F=  0.000000e+000  F'=  8.578324e+000
 x=    0.040  F=  3.414076e-001  F'=  8.448925e+000
 x=    0.080  F=  6.724633e-001  F'=  8.060728e+000
 x=    0.120  F=  9.828153e-001  F'=  7.413734e+000
 x=    0.160  F=  1.262111e+000  F'=  6.507942e+000
 x=    0.200  F=  1.500000e+000  F'=  5.343353e+000
 x=    0.240  F=  1.686881e+000  F'=  3.976359e+000
 x=    0.280  F=  1.816162e+000  F'=  2.463353e+000
 x=    0.320  F=  1.882002e+000  F'=  8.043353e-001
 x=    0.360  F=  1.878562e+000  F'= -1.000694e+000
 x=    0.400  F=  1.800000e+000  F'= -2.951735e+000
 x=    0.440  F=  1.643869e+000  F'= -4.794359e+000
 x=    0.480  F=  1.421289e+000  F'= -6.274139e+000
 x=    0.520  F=  1.146775e+000  F'= -7.391075e+000
 x=    0.560  F=  8.348411e-001  F'= -8.145167e+000
 x=    0.600  F=  5.000000e-001  F'= -8.536414e+000
 x=    0.640  F=  1.568445e-001  F'= -8.558921e+000
 x=    0.680  F= -1.797186e-001  F'= -8.206795e+000
 x=    0.720  F= -4.947040e-001  F'= -7.480034e+000
 x=    0.760  F= -7.731262e-001  F'= -6.378640e+000
 x=    0.800  F= -1.000000e+000  F'= -4.902611e+000
 x=    0.840  F= -1.163247e+000  F'= -3.269955e+000
 x=    0.880  F= -1.262415e+000  F'= -1.698681e+000
 x=    0.920  F= -1.299960e+000  F'= -1.887874e-001
 x=    0.960  F= -1.278336e+000  F'=  1.259725e+000
 x=    1.000  F= -1.200000e+000  F'=  2.646857e+000
 x=    1.040  F= -1.069458e+000  F'=  3.818743e+000
 x=    1.080  F= -8.994221e-001  F'=  4.621518e+000
 x=    1.120  F= -7.046576e-001  F'=  5.055184e+000
 x=    1.160  F= -4.999288e-001  F'=  5.119739e+000
 x=    1.200  F= -3.000000e-001  F'=  4.815184e+000
 x=    1.240  F= -1.165227e-001  F'=  4.374985e+000
 x=    1.280  F=  5.130306e-002  F'=  4.032607e+000
 x=    1.320  F=  2.073902e-001  F'=  3.788052e+000
 x=    1.360  F=  3.556515e-001  F'=  3.641319e+000
*/
/* Test output

  tensioned spline (tcspl .6)

     Test of Cubic Spline Interpolation
  tension= 0.600000
  spline coefficients
 0 x=0.000000 y=0.000000 z=0.000000e+000
 1 x=0.200000 y=1.500000 z=-5.328654e+000
 2 x=0.400000 y=1.800000 z=-8.302055e+000
 3 x=0.600000 y=0.500000 z=-8.658951e-001
 4 x=0.800000 y=-1.000000 z=6.827926e+000
 5 x=1.000000 y=-1.200000 z=5.563006e+000
 6 x=1.200000 y=-0.300000 z=-1.980140e+000
 7 x=1.400000 y=0.500000 z=0.000000e+000
  evaluation of spline with tension
 x=    0.000  F=  0.000000e+000
 x=    0.040  F=  3.409533e-001
 x=    0.080  F=  6.718217e-001
 x=    0.120  F=  9.823751e-001
 x=    0.160  F=  1.262090e+000
 x=    0.200  F=  1.500000e+000
 x=    0.240  F=  1.685896e+000
 x=    0.280  F=  1.814274e+000
 x=    0.320  F=  1.880162e+000
 x=    0.360  F=  1.877690e+000
 x=    0.400  F=  1.800000e+000
 x=    0.440  F=  1.643392e+000
 x=    0.480  F=  1.420012e+000
 x=    0.520  F=  1.145284e+000
 x=    0.560  F=  8.338949e-001
 x=    0.600  F=  5.000000e-001
 x=    0.640  F=  1.576137e-001
 x=    0.680  F= -1.786437e-001
 x=    0.720  F= -4.938814e-001
 x=    0.760  F= -7.729055e-001
 x=    0.800  F= -1.000000e+000
 x=    0.840  F= -1.162315e+000
 x=    0.880  F= -1.260533e+000
 x=    0.920  F= -1.298027e+000
 x=    0.960  F= -1.277297e+000
 x=    1.000  F= -1.200000e+000
 x=    1.040  F= -1.069603e+000
 x=    1.080  F= -8.993089e-001
 x=    1.120  F= -7.043696e-001
 x=    1.160  F= -4.996814e-001
 x=    1.200  F= -3.000000e-001
 x=    1.240  F= -1.169270e-001
 x=    1.280  F=  5.061079e-002
 x=    1.320  F=  2.066891e-001
 x=    1.360  F=  3.552183e-001
*/
