/*  tchcof.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  chcof
*/
#include "ccmath.h"
#include <math.h>
char fnam[]="exp(x)";
main()
{ double c[20],fun();
  int m=16,j;
  printf(" Test of Tchebycheff Coefficient Generator\n");
  printf("     function = %s\n",fnam);
  chcof(c,m,fun);
  for(j=0; j<=m ;++j) printf(" %2d %e\n",j,c[j]);
}
/* other functions whose Tchebycheff series is
   desired can be substituted below. */
double fun(x)
double x;
{ double y=exp(x);
  return y;
}
/* Test output

 Test of Tchebycheff Coefficient Generator
     function = exp(x)
  0 2.532132e+000
  1 1.130318e+000
  2 2.714953e-001
  3 4.433685e-002
  4 5.474240e-003
  5 5.429263e-004
  6 4.497732e-005
  7 3.198436e-006
  8 1.992125e-007
  9 1.103677e-008
 10 5.505888e-010
 11 2.497943e-011
 12 1.038901e-012
 13 4.005619e-014
 14 3.373119e-015
 15 4.326604e-016
 16 -9.959354e-017
*/
