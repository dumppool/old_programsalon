/*  tqrlsq2.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  qrlsq  qrvar

    Uses:  mattr  mmul

    Input file:  tqr2.dat
*/
#include <stdio.h>
#include "ccmath.h"
main(na,av)
int na; char **av;
{ double x,dx,f,t;
  double *b,*c,*ad,*r,*rt,*v1,*p;
  int n,m,i,j,k;
  FILE *fp;
  if(na!=2){ printf("para: in_file\n"); exit(-1);}
  fp=fopen(*++av,"r");
  fscanf(fp,"%d %d %lf",&n,&m,&dx);
  c=(double *)calloc(n,sizeof(double));
  b=(double *)calloc(m,sizeof(double));
  ad=(double *)calloc(m*n,sizeof(double));
  r=(double *)calloc(n*n,sizeof(double));
  rt=(double *)calloc(n*n,sizeof(double));
  v1=(double *)calloc(n*n,sizeof(double));
  for(i=0; i<n ;++i) fscanf(fp,"%lf",c+i);
  printf(" %d meas. %d param.\n",m,n);
  printf(" cf-in:\n"); matprt(c,1,n," %9.4f");
  for(i=0,x=0.,p=ad; i<m ;++i){
    x+=dx;
    for(j=0,f=0.,t=1.; j<n ;++j){
      f+=c[j]*(*p++ =t); t*=x;
     }
    b[i]=f;
   }

/* Linear least squares via a QR transform */  
  t=qrlsq(ad,b,m,n,&j);
  
  mcopy(r,ad,n*n);
  for(i=0,p=r; i<n ;++i){
    for(k=0; k<n ;++k,++p) if(k<i) *p=0.;
   }
  printf(" ssq= %.3e\n",t);
  if(j== -1) printf(" singular reduced matrix\n");
  else{
    printf(" cf-out:\n"); matprt(b,1,n," %13.6e");

/* Parameter variance computation for QR least squares */
    t=qrvar(ad,m,n,t);
    
    printf(" sig*sig= %e\n",t);
    printf(" var-mat:\n"); matprt(ad,n,n," %13.6e");
    mattr(rt,r,n,n); mmul(v1,rt,r,n);
    for(i=0,k=n*n,t=1./t,p=ad; i<k ;++i) *p++ *=t;
    mmul(rt,v1,ad,n);
    printf(" r'*r*var/(sig*sig):\n");
    matprt(rt,n,n," %13.6e");
   }
}
/* Test output

 50 meas. 5 param.
 cf-in:
   -1.0000    2.5000    1.5000   -2.0000    0.5000
 ssq= 7.559e-027
 cf-out:
 -1.000000e+000 2.500000e+000 1.500000e+000 -2.000000e+000 5.000000e-001
 sig*sig= 1.679771e-028
 var-mat:
 1.078220e-028 -2.555684e-028 1.769647e-028 -4.670963e-029 4.162244e-030
 -2.555684e-028 7.626251e-028 -5.826314e-028 1.624462e-028 -1.499061e-029
 1.769647e-028 -5.826314e-028 4.715058e-028 -1.364537e-028 1.292375e-029
 -4.670963e-029 1.624462e-028 -1.364537e-028 4.054309e-029 -3.915458e-030
 4.162244e-030 -1.499061e-029 1.292375e-029 -3.915458e-030 3.838685e-031
 r'*r*var/(sig*sig):
 1.000000e+000 7.958079e-013 -9.094947e-013 8.526513e-014 -1.065814e-014
 -6.821210e-013 1.000000e+000 -1.364242e-012 0.000000e+000 2.842171e-014
 -2.728484e-012 7.275958e-012 1.000000e+000 9.094947e-013 0.000000e+000
 -2.364686e-011 5.820766e-011 -6.548362e-011 1.000000e+000 -4.547474e-013
 -8.003553e-011 1.746230e-010 -2.037268e-010 2.910383e-011 1.000000e+000
*/
