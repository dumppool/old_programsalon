/*  tcsplp.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  csplp
    Uses:  csfit (when tn=0)  tnsfit (when tn!=0)

    To set a nonzero tension call: 'tcsplp tn', 0 <= tn is assumed.

    The points for the interpolation lie on an ellipse, centered at
    the origin with major axis along the x-coordinate. The number of
    interpolation points (2m) and ellipse axes (a,b) can be altered
    with the call: 'tcsplp tn a b m'
*/
#include "ccmath.h"
#include <math.h>
#define MD 20
/* spline tension */
double tn=0.;
/* 1/2 the number of points */
int m= 4;
/* ellipse axes (closed curve is an ellipse) */
double a=2.,b=1.;
main(na,av)
int na; char **av;
{ double x[MD],y[MD],z[MD],w[MD],t[MD];
  double s,ds,u,atof(); int j;
  double pi=3.1415926535897932;
  if(na>=2) tn=atof(*++av);
  if(na==5){
    a=atof(*++av); b=atof(*++av); m=atoi(*++av);
   }
  printf("     Test of Periodic Splines\n");
  printf(" ellipse: a= %f  b= %f\n",a,b);
  printf(" interpolation angle = %9.3f\n",180./m);
  printf("   tension= %f\n\n",tn);
  s=0.; ds=pi/m; m*=2;
  for(j=0; j<=m ;s+=ds){ x[j]=a*cos(s); y[j]=b*sin(s); t[j++]=s;}
  csplp(t,x,z,m,tn); csplp(t,y,w,m,tn);
  printf("  periodic spline coefficients\n");
  for(j=0; j<=m ;++j)
    printf(" %2d x=%9f z=%9f y=%9f w=%9f\n",j,x[j],z[j],y[j],w[j]);
  if(tn==0.) printf("\n  evaluation of periodic cubic spline\n");
  else printf("\n  evaluation of periodic tensioned spline\n");
  for(s=t[0],ds=pi/12.,u=t[m]+ds/2.; s<u ;s+=ds){
    if(s>t[m]) s=t[m];
    if(tn==0.){ a=csfit(s,t,x,z,m); b=csfit(s,t,y,w,m);}
    else{ a=tnsfit(s,t,x,z,m,tn); b=tnsfit(s,t,y,w,m,tn);}
    printf(" x= %14e   y= %14e\n",a,b);
   }
}
/* Test output

 cubic spline  (tcsplp)

     Test of Periodic Splines
 ellipse: a= 2.000000  b= 1.000000
 interpolation angle =    45.000
   tension= 0.000000

  periodic spline coefficients
  0 x= 2.000000 z=-0.350796 y= 0.000000 w= 0.000000
  1 x= 1.414214 z=-0.248050 y= 0.707107 w=-0.124025
  2 x= 0.000000 z= 0.000000 y= 1.000000 w=-0.175398
  3 x=-1.414214 z= 0.248050 y= 0.707107 w=-0.124025
  4 x=-2.000000 z= 0.350796 y= 0.000000 w= 0.000000
  5 x=-1.414214 z= 0.248050 y=-0.707107 w= 0.124025
  6 x= 0.000000 z= 0.000000 y=-1.000000 w= 0.175398
  7 x= 1.414214 z=-0.248050 y=-0.707107 w= 0.124025
  8 x= 2.000000 z=-0.350796 y= 0.000000 w= 0.000000

  evaluation of periodic cubic spline
 x=  2.000000e+000   y=  0.000000e+000
 x=  1.930218e+000   y=  2.583704e-001
 x=  1.730261e+000   y=  4.997396e-001
 x=  1.414214e+000   y=  7.071068e-001
 x=  9.994793e-001   y=  8.651305e-001
 x=  5.167407e-001   y=  9.651090e-001
 x=  6.367467e-016   y=  1.000000e+000
 x= -5.167407e-001   y=  9.651090e-001
 x= -9.994793e-001   y=  8.651305e-001
 x= -1.414214e+000   y=  7.071068e-001
 x= -1.730261e+000   y=  4.997396e-001
 x= -1.930218e+000   y=  2.583704e-001
 x= -2.000000e+000   y= -3.206184e-016
 x= -1.930218e+000   y= -2.583704e-001
 x= -1.730261e+000   y= -4.997396e-001
 x= -1.414214e+000   y= -7.071068e-001
 x= -9.994793e-001   y= -8.651305e-001
 x= -5.167407e-001   y= -9.651090e-001
 x= -3.673819e-016   y= -1.000000e+000
 x=  5.167407e-001   y= -9.651090e-001
 x=  9.994793e-001   y= -8.651305e-001
 x=  1.414214e+000   y= -7.071068e-001
 x=  1.730261e+000   y= -4.997396e-001
 x=  1.930218e+000   y= -2.583704e-001
 x=  2.000000e+000   y= -1.988047e-015

 Test output

 tensioned spline  (tcsplp 5. 1. 1. 4)

     Test of Periodic Splines
 ellipse: a= 1.000000  b= 1.000000
 interpolation angle =    45.000
   tension= 5.000000

  periodic spline coefficients
  0 x= 1.000000 z=-0.095029 y= 0.000000 w= 0.000000
  1 x= 0.707107 z=-0.067195 y= 0.707107 w=-0.067195
  2 x= 0.000000 z= 0.000000 y= 1.000000 w=-0.095029
  3 x=-0.707107 z= 0.067195 y= 0.707107 w=-0.067195
  4 x=-1.000000 z= 0.095029 y= 0.000000 w= 0.000000
  5 x=-0.707107 z= 0.067195 y=-0.707107 w= 0.067195
  6 x= 0.000000 z= 0.000000 y=-1.000000 w= 0.095029
  7 x= 0.707107 z=-0.067195 y=-0.707107 w= 0.067195
  8 x= 1.000000 z=-0.095029 y= 0.000000 w= 0.000000

  evaluation of periodic tensioned spline
 x=  1.000000e+000   y=  0.000000e+000
 x=  9.457002e-001   y=  2.489880e-001
 x=  8.447722e-001   y=  4.926499e-001
 x=  7.071068e-001   y=  7.071068e-001
 x=  4.926499e-001   y=  8.447722e-001
 x=  2.489880e-001   y=  9.457002e-001
 x=  3.105497e-016   y=  1.000000e+000
 x= -2.489880e-001   y=  9.457002e-001
 x= -4.926499e-001   y=  8.447722e-001
 x= -7.071068e-001   y=  7.071068e-001
 x= -8.447722e-001   y=  4.926499e-001
 x= -9.457002e-001   y=  2.489880e-001
 x= -1.000000e+000   y= -3.007970e-016
 x= -9.457002e-001   y= -2.489880e-001
 x= -8.447722e-001   y= -4.926499e-001
 x= -7.071068e-001   y= -7.071068e-001
 x= -4.926499e-001   y= -8.447722e-001
 x= -2.489880e-001   y= -9.457002e-001
 x= -1.836910e-016   y= -1.000000e+000
 x=  2.489880e-001   y= -9.457002e-001
 x=  4.926499e-001   y= -8.447722e-001
 x=  7.071068e-001   y= -7.071068e-001
 x=  8.447722e-001   y= -4.926499e-001
 x=  9.457002e-001   y= -2.489880e-001
 x=  1.000000e+000   y= -1.907050e-015
*/
