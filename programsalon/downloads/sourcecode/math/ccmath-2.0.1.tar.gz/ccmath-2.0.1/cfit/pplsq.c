/*  pplsq.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
#include "orpol.h"
double pplsq(x,y,n,bc,m)
double *x,*y,*bc; int n,m;
{ Opol *c; double *ss,sq;
  c=(Opol *)calloc(m,sizeof(Opol));
  ss=(double *)calloc(m,sizeof(double));
  plsq(x,y,n,c,ss,m);
  psqcf(bc,c,m);
  sq=ss[m-1];
  free(c); free(ss);
  return sq;
}
