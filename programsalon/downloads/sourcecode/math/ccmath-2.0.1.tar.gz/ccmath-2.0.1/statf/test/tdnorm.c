/*  tdnorm.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  qnorm  pctn
*/
#include "ccmath.h"
main()
{ double z,dz,f,d,qnorm(),pctn();
  printf("     Test of Normal Distribution\n");
  printf("    z         Q(z)               Pct(Q)\n");
  for(z= -2.5,dz=.25; z<2.6 ;z+=dz){

/* compute distribution function for standard normal */
    f=qnorm(z);

/* compute the percentage point to check the distribution */
    d=pctn(f);

    printf(" %6.2f  %18.11e  %12.8f\n",z,f,d);
   }
}
/*  Test output

     Test of Normal Distribution
    z         Q(z)               Pct(Q)
  -2.50  9.93790334674e-001   -2.50000000
  -2.25  9.87775527345e-001   -2.25000000
  -2.00  9.77249868052e-001   -2.00000000
  -1.75  9.59940843136e-001   -1.75000000
  -1.50  9.33192798731e-001   -1.50000000
  -1.25  8.94350226333e-001   -1.25000000
  -1.00  8.41344746069e-001   -1.00000000
  -0.75  7.73372647623e-001   -0.75000000
  -0.50  6.91462461274e-001   -0.50000000
  -0.25  5.98706325683e-001   -0.25000000
   0.00  5.00000000000e-001    0.00000000
   0.25  4.01293674317e-001    0.25000000
   0.50  3.08537538726e-001    0.50000000
   0.75  2.26627352377e-001    0.75000000
   1.00  1.58655253931e-001    1.00000000
   1.25  1.05649773667e-001    1.25000000
   1.50  6.68072012689e-002    1.50000000
   1.75  4.00591568638e-002    1.75000000
   2.00  2.27501319482e-002    2.00000000
   2.25  1.22244726550e-002    2.25000000
   2.50  6.20966532578e-003    2.50000000
*/
