/*  tdgama.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  qgama  pctg

    Input parameter:  a -> real: distribution parameter
*/
#include <stdlib.h>
#include "ccmath.h"
#define N 11
double pct[]={.001,.01,.05,.1,.25,.5,.75,.9,.95,.99,.999};
main(na,av)
int na; char **av;
{ double a,p,z,c; int k;
  if(na!=2){ printf("para: pg\n"); exit(-1);}
  printf("     Test of Gamma Distribution\n");
  a=atof(*++av); printf("  parameter = %.3f\n",a);
  printf("    p         Z(p)               check\n");
  for(k=0; k<N ;){ p=pct[k++];

/* compute percentage point of gamma distribution */
    z=pctg(p,a);

/* compute distribution function to check percentage point */
    c=qgama(z,a);

    printf(" %7.3f  %16.9e  %12.9f\n",p,z,c);
   }
}
/*  Test output

     Test of Gamma Distribution
  parameter = 4.330
    p         Z(p)               check
   0.001  1.364314052e+001   0.001000000
   0.010  1.056708734e+001   0.010000000
   0.050  8.220937190e+000   0.050000000
   0.100  7.118199152e+000   0.100000000
   0.250  5.496086650e+000   0.250000000
   0.500  4.001617542e+000   0.500000000
   0.750  2.808001804e+000   0.750000000
   0.900  1.967598809e+000   0.900000000
   0.950  1.560462720e+000   0.950000000
   0.990  9.671768471e-001   0.990000000
   0.999  5.239585499e-001   0.999000000
*/
