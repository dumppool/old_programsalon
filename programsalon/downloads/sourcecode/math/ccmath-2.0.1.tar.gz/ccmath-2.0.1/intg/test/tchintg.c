/*  tchintg.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  chintg  fchb

    To specify a new order parameter use 'tchintg' order
*/
#include <math.h>
#include "ccmath.h"
#define MDM 60
/* order of Tchebycheff approximation */
int mp=8;
double Pi=3.14159265358979324;
double func();
main(na,av)
int na; char **av;
{ double x,y,f,a[MDM],Pi2=Pi/2.;
  printf("     Test of Tchebycheff Integration\n\n");
  if(na!=1) mp=atoi(*++av);
  printf("  order = %d\n",mp);
  f=chintg(a,mp,func);
  printf("  test magnitude = %e\n\n",f);
  printf("     y       computed       exact\n");
  for(y= -1.; y<=1. ;y+=.5){
    f=fchb(y,a,mp)*Pi2/2.; x=Pi2*(1.+y)/2.;
    printf("  %6.3f  %13.5e  %13.5e\n",y,f,1.-cos(x));
   }
}
/* test integrand function
   defined on x from -1 to 1.
   Integral is 1-cos(Pi*(1+x)/4).
*/
double func(x)
double x;
{ double y;
  y=(1.+x)/2.; return sin(Pi*y/2.);
}
/*  Test output

     Test of Tchebycheff Integration

  order = 8
  test magnitude = 8.971624e-006

     y       computed       exact
  -1.000   2.17992e-017   0.00000e+000
  -0.500   7.61205e-002   7.61205e-002
   0.000   2.92893e-001   2.92893e-001
   0.500   6.17317e-001   6.17317e-001
   1.000   1.00000e+000   1.00000e+000

    output with call tchingg 5

     Test of Tchebycheff Integration

  order = 5
  test magnitude = 1.748417e-002

     y       computed       exact
  -1.000  -2.17992e-017   0.00000e+000
  -0.500   7.61208e-002   7.61205e-002
   0.000   2.92908e-001   2.92893e-001
   0.500   6.17318e-001   6.17317e-001
   1.000   1.00000e+000   1.00000e+000
*/
