/*  tcnvx.c    CCM mathematics library source code.
 *
 *  Copyright (C)  2000   Daniel A. Atkinson    All rights reserved.
 *  This code may be redistributed under the terms of the GNU general
 *  public license. ( See the gpl.license file for details.)
 * ------------------------------------------------------------------------
 */
/*
    Test:  fintg
*/
#include <math.h>
#include "ccmath.h"
/* convergence test threshold */
double te=1.e-12;
/* initial convolution displacement and increment*/
double r=0.,dr=0.1;
char fi[]="norm(x-r)";
double cs=0.398942280402;
main()
{ double a,b,te=1.e-12;
  double fnrm();
  printf(" Convolution Integrals Test\n\n");
  printf("   convergence threshold= %e\n\n",te);
  printf(" %s over x : [-1, 1]\n",fi);
  for(a= -1.,b=1.; r<2.0001 ;r+=dr){
    printf(" r=%10.6f  I= %e\n",r,fintg(a,b,25,te,fnrm));
   }
}
/* Normal probability density of x-r.
   Note that the parameter r is delivered as an external
   to the standard format integrand fnrm.
*/
double fnrm(x)
double x;
{ double ldexp();
  x-=r;
  return exp(-ldexp(x*x,-1))*cs;
}
/* Test output

 Convolution Integrals Test

   convergence threshold= 1.000000e-012

 norm(x-r) over x : [-1, 1]
 r=  0.000000  I= 6.826895e-001
 r=  0.100000  I= 6.802738e-001
 r=  0.200000  I= 6.730749e-001
 r=  0.300000  I= 6.612359e-001
 r=  0.400000  I= 6.449902e-001
 r=  0.500000  I= 6.246553e-001
 r=  0.600000  I= 6.006224e-001
 r=  0.700000  I= 5.733460e-001
 r=  0.800000  I= 5.433294e-001
 r=  0.900000  I= 5.111113e-001
 r=  1.000000  I= 4.772499e-001
 r=  1.100000  I= 4.423077e-001
 r=  1.200000  I= 4.068368e-001
 r=  1.300000  I= 3.713645e-001
 r=  1.400000  I= 3.363807e-001
 r=  1.500000  I= 3.023279e-001
 r=  1.600000  I= 2.695919e-001
 r=  1.700000  I= 2.384967e-001
 r=  1.800000  I= 2.093003e-001
 r=  1.900000  I= 1.821943e-001
 r=  2.000000  I= 1.573054e-001
*/
