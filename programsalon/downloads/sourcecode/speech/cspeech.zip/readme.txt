CSpeech 1.0
-----------

This is a C++ class for making the text-to-speech part of the
Microsoft Speech SDK (SAPI) more palatable and easy to use.

Note that you need the Microsoft Speech SDK to compile and use
CSpeech.

Please see the cspeech.hlp manual in the docs directory for
more information.

Julian Smart, February 1998
julian.smart@ukonline.co.uk
