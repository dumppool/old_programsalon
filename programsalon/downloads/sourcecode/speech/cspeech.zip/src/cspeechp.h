/////////////////////////////////////////////////////////////////////////////
// Name:        cspeechp.h
// Purpose:		Text to speech class - private
// Author:		Julian Smart
// Modified by:	
// Created:		07/02/98
// RCS-ID:		$Id$
// Copyright:	(c) Julian Smart
// Licence:		wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef __CSPEECHP_H__
#define __CSPEECHP_H__

#ifdef __MFC__

#ifndef _DEBUG
// #define _AFX_NOFORCE_LIBS
#endif

// #define  _AFX_NO_BSTR_SUPPORT

#include <afxwin.h>         // MFC core and standard components

#endif
  // __MFC__

#include <objbase.h>                    // OLE stuff

#ifdef DIRECTSOUND
#include <dsound.h>
#endif

#include "speech.h"

/////////////////////////////////////////////////////////////////////////////

class CSpeech;

/************************************************************************
Notification objects */
class CTestNotify : public ITTSNotifySink {
   protected:
      CSpeech *m_speech;
   public:
      CTestNotify (CSpeech *speech);
      ~CTestNotify (void);

      // IUnkown members that delegate to m_punkOuter
      // Non-delegating object IUnknown
      STDMETHODIMP         QueryInterface (REFIID, LPVOID FAR *);
      STDMETHODIMP_(ULONG) AddRef(void);
      STDMETHODIMP_(ULONG) Release(void);

      // ITTSNotifySink
		STDMETHOD (AttribChanged)  (DWORD);
		STDMETHOD (AudioStart)     (QWORD);
		STDMETHOD (AudioStop)      (QWORD);
		STDMETHOD (Visual)         (QWORD, CHAR, CHAR, DWORD, PTTSMOUTH);
   };
typedef CTestNotify * PCTestNotify;

class CTestBufNotify : public ITTSBufNotifySink {
private:

public:
      CTestBufNotify (CSpeech* speech);
      ~CTestBufNotify (void);

      // IUnkown members that delegate to m_punkOuter
      // Non-delegating object IUnknown
      STDMETHODIMP         QueryInterface (REFIID, LPVOID FAR *);
      STDMETHODIMP_(ULONG) AddRef(void);
      STDMETHODIMP_(ULONG) Release(void);

      // ITTSNotifySink
	   STDMETHOD (BookMark)		   	(QWORD, DWORD);
	   STDMETHOD (TextDataDone)   	(QWORD, DWORD);
	   STDMETHOD (TextDataStarted)   (QWORD);
	   STDMETHOD (WordPosition)      (QWORD, DWORD);
protected:
	  CSpeech* m_speech;
};

typedef CTestBufNotify * PCTestBufNotify;

class CSpeechImpl
{
// Construction
public:
	CSpeechImpl(CSpeech* speech);
	~CSpeechImpl();

// Accessors
	// Get the mode GUID by index (normally won't be needed by application)
	inline GUID GetModeGUID(int mode) const { return m_GUIDModes[mode] ; }
// Implementation
public:
    BOOL InitTTS(void);
    BOOL TerminateTTS(void);

// Variables
public:
    PITTSENUM 		m_pITTSEnum;
    PITTSCENTRAL    m_pITTSCentral;
    PITTSATTRIBUTES m_pITTSAttributes;
    PITTSDIALOGS	m_pITTSDialogs;
    PCTestNotify    m_pTestNotify;
    PCTestBufNotify m_pTestBufNotify;
#ifdef DIRECTSOUND
    PIAUDIODIRECT   m_pIAD;
#else
    PIAUDIOMULTIMEDIADEVICE m_pIMMD;
#endif
    unsigned long   m_dwRegKey;
    GUID 			m_GUIDModes[100];
	int				m_noModes;
	CString			m_modeNames[100];
	long			m_modeFeatures[100];
	CSpeech*		m_speech;
};

// Framework-independent message box
void CSpeechMessage(const CString& msg, const CString& label = "CSpeech Error");

#endif

