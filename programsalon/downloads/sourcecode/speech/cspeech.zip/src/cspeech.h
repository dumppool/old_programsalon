/////////////////////////////////////////////////////////////////////////////
// Name:        cspeech.h
// Purpose:		Text to speech class
// Author:		Julian Smart
// Modified by:	
// Created:		07/02/98
// RCS-ID:		$Id$
// Copyright:	(c) Julian Smart
// Licence:		wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/*
 * TODO:
 * - Plain Windows sample.
 * - Documentation.
 * - Perhaps make CSpeechImpl pluggable so we can plug in non-SAPI engines.
 */

#ifndef __CSPEECH_H__
#define __CSPEECH_H__

// Set your framework - if all are undefined, we're using native Windows.
#define	__MFC__
// #define __WXWIN__

#ifdef __MFC__
#include <afx.h>
#elif defined(__WXWIN__)
#include <wx.h>
#include <wxstring.h>
#else
#include <windows.h>
#endif

#ifndef u_int8_t
#  define u_int8_t unsigned char
#  define u_int16_t unsigned short
#  define u_int32_t unsigned int
#  define u_int64_t unsigned __int64
#  define int8_t char
#  define int16_t short
#  define int32_t int
#  define int64_t __int64
#endif

#define timestamp_t u_int64_t

// Stands in for HWND
typedef void* window_t;

#ifdef __MFC__
// Nothing
#elif defined(__WXWIN__)
#define CString wxString
#define BOOL Bool
#else
#define CString char*
#endif

/////////////////////////////////////////////////////////////////////////////

class CSpeechImpl;

class CSpeechMouth
{
public:
	int m_mouthHeight;
	int m_mouthWidth;
	int m_mouthUpturn;
	int m_jawOpen;
	int m_teethUpperVisible;
	int m_teethLowerVisible;
	int m_tonguePosn;
	int m_lipTension;
};

class CSpeech: public
#ifdef wx_msw
 wxObject
#else
 CObject
#endif
{
// Construction
public:
	CSpeech();
	~CSpeech();

// Accessors
	// Get the mode name by index
	CString GetModeName(int mode) const ;

	// Get the mode features by index
	long GetModeFeatures(int mode) const ;

	// Get the number of modes
	int GetModeCount(void) const ;

	// Set the current mode
	BOOL SetMode(int mode) ;

	// Find a mode by name
	int FindMode(const CString modeName);

// Operations

	// Initialize and enumerate modes
	BOOL Init();

	// Cleanup TTS
	BOOL Terminate();

	// Pause
	BOOL Pause(BOOL pause);

	// Say the text
	BOOL Say(const CString& text, BOOL tagged = FALSE);

	// Resets TTS
	BOOL Reset();

	// Injects \rst
	BOOL Default();

	// Inject a tag
	BOOL Inject(const CString& text);

	// Set the pitch
	BOOL SetPitch(int pitch);

	// Get the pitch
	int GetPitch(void) const;

	// Get the min pitch
	int GetMinPitch(void) const;

	// Get the max pitch
	int GetMaxPitch(void) const;

	// Set the speed
	BOOL SetSpeed(long speed);

	// Get the speed
	long GetSpeed(void) const;

	// Get the min speed
	long GetMinSpeed(void) const;

	// Get the max speed
	long GetMaxSpeed(void) const;

	// Set the volume
	BOOL SetVolume(long volume);

	// Get the volume
	long GetVolume(void) const;

	// Get the min volume
	long GetMinVolume(void) const;

	// Get the max volume
	long GetMaxVolume(void) const;

	// Find all possible modes (voices). Called in Init but you may wish
	// to call it again if an engine has been installed/removed
    BOOL EnumerateModes(void);

	// Shows an engine-specific About dialog.
	// Returns FALSE if not supported or there is some other error.
	BOOL AboutDialog(window_t parentWindow, const CString& title = "");

	// Shows an engine-specific general settings dialog.
	// Returns FALSE if not supported or there is some other error.
	BOOL GeneralDialog(window_t parentWindow, const CString& title = "");

	// Shows an engine-specific lexicon dialog.
	// Returns FALSE if not supported or there is some other error.
	BOOL LexiconDialog(window_t parentWindow, const CString& title = "");

	// Shows an engine-specific translation dialog.
	// Returns FALSE if not supported or there is some other error.
	BOOL TranslateDialog(window_t parentWindow, const CString& title = "");

// Overridables
	// ITTSNotifySink
	virtual BOOL OnAttribChanged(long attribId);
	virtual BOOL OnAudioStart(timestamp_t timeStamp);
	virtual BOOL OnAudioStop(timestamp_t timeStamp);
	virtual BOOL OnVisual(timestamp_t timeStamp, char cIPAPhoneme,
				char cEnginePhoneme, long dwHints, const CSpeechMouth& mouth);

	// ITTSBufNotifySink
	virtual BOOL OnBookMark(timestamp_t qTimeStamp, long dwMarkNum);
	virtual BOOL OnTextDataStarted (timestamp_t qTimeStamp);
	virtual BOOL OnTextDataDone (timestamp_t qTimeStamp, long dwFlags);
	virtual BOOL OnWordPosition (timestamp_t qTimeStamp, long dwByteOffset);

// Implementation
public:
	inline CSpeechImpl* GetSpeechImpl() const { return m_speechImpl; }
protected:
	// Implementation object, so this header file eliminates speech/OLE-specific
	// includes.
	CSpeechImpl*	m_speechImpl;
};

#endif

