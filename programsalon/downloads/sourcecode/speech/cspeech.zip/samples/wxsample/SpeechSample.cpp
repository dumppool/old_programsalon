/*
 * File:	SpeechSample.cpp
 * Purpose:	CSpeech sample for wxWindows
 * Author:	Julian Smart
 * Created:	1998
 * Updated:	
 * Copyright:	(c) 1998, Julian Smart
 */

// For compilers that support precompilation, includes "wx.h".
#include "wx_prec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx.h"
#endif

// CSpeech
#include "cspeech.h"

// OLE
#include <objbase.h>

// Define a new application type
class MyApp: public wxApp
{ public:
    wxFrame *OnInit(void);
};

// Define a new frame type
class MyFrame: public wxFrame
{
public:
    MyFrame(wxFrame *frame, char *title, int x, int y, int w, int h);
    void OnMenuCommand(int id);
    Bool OnClose(void) ;

	CSpeech& GetSpeech() { return m_speech; }

	wxMultiText*	m_speechCtrl;
	CSpeech			m_speech;
};

// ID for the menu quit command
#define SPEECH_QUIT 1
#define SPEECH_SAY 2

// This statement initializes the whole application and calls OnInit
MyApp myApp;

// A macro needed for some compilers (AIX) that need 'main' to be defined
// in the application itself.
IMPLEMENT_WXWIN_MAIN

// `Main program' equivalent, creating windows and returning main app frame
wxFrame *MyApp::OnInit(void)
{
  if (FAILED(CoInitialize(NULL))) return FALSE;

  // Create the main frame window
  MyFrame *frame = new MyFrame(NULL, "wxWindows Speech Sample", 50, 50, 320, 165);

  // Give it an icon
  frame->SetIcon(new wxIcon("mondrian"));

  // Make a menubar
  wxMenu *file_menu = new wxMenu;

  file_menu->Append(SPEECH_SAY, "&Say text");
  file_menu->Append(SPEECH_QUIT, "E&xit");
  wxMenuBar *menu_bar = new wxMenuBar;
  menu_bar->Append(file_menu, "&File");
  frame->SetMenuBar(menu_bar);

  // Make a panel with a message
  wxPanel *panel = new wxPanel(frame, 0, 0, 350, 200);

  panel->SetLabelPosition(wxVERTICAL) ;
  frame->m_speechCtrl = new wxMultiText(panel, (wxFunction) NULL, "Enter text to speak:",
  	"Hello, welcome to the wxWindows speech sample.", 5, 5, 300, 100);

  // Show the frame
  frame->Show(TRUE);

  // Return the main frame window
  return frame;
}

// My frame constructor
MyFrame::MyFrame(wxFrame *frame, char *title, int x, int y, int w, int h):
  wxFrame(frame, title, x, y, w, h)
{
	m_speech.Init();
}

// Intercept menu commands
void MyFrame::OnMenuCommand(int id)
{
  switch (id) {
    case SPEECH_SAY:
	{
		char* val = m_speechCtrl->GetValue();

		wxString str(val);
		if (str != "")
			m_speech.Say(str);
    	break;
	}
    case SPEECH_QUIT:
	{
      	this->Close();
    	break;
	}
  }
}

Bool MyFrame::OnClose(void)
{
	m_speech.Terminate();

    CoUninitialize ();
	return TRUE;
}

