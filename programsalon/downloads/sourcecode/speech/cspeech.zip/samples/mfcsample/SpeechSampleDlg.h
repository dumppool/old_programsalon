// SpeechSampleDlg.h : header file
//

#if !defined(AFX_SPEECHSAMPLEDLG_H__90E57029_9FA9_11D1_9F11_444553540000__INCLUDED_)
#define AFX_SPEECHSAMPLEDLG_H__90E57029_9FA9_11D1_9F11_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "cspeech.h"

class CSpeechSampleDlg;

class CSampleSpeech: public CSpeech
{
public:
	CSampleSpeech(CSpeechSampleDlg* dlg) { m_dialog = dlg; }

	virtual BOOL OnAudioStart (timestamp_t qTimeStamp);
	virtual BOOL OnAudioStop(timestamp_t qTimeStamp);
protected:
	CSpeechSampleDlg* m_dialog;
};

/////////////////////////////////////////////////////////////////////////////
// CSpeechSampleDlg dialog

class CSpeechSampleDlg : public CDialog
{
// Construction
public:
	CSpeechSampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSpeechSampleDlg)
	enum { IDD = IDD_SPEECHSAMPLE_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpeechSampleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON	m_hIcon;
	CSampleSpeech	m_speech;

	// Generated message map functions
	//{{AFX_MSG(CSpeechSampleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSpeak();
	afx_msg void OnVoice();
	afx_msg void OnClose();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPEECHSAMPLEDLG_H__90E57029_9FA9_11D1_9F11_444553540000__INCLUDED_)
