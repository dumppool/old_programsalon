// SpeechSample.h : main header file for the SPEECHSAMPLE application
//

#if !defined(AFX_SPEECHSAMPLE_H__90E57027_9FA9_11D1_9F11_444553540000__INCLUDED_)
#define AFX_SPEECHSAMPLE_H__90E57027_9FA9_11D1_9F11_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSpeechSampleApp:
// See SpeechSample.cpp for the implementation of this class
//

class CSpeechSampleApp : public CWinApp
{
public:
	CSpeechSampleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpeechSampleApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSpeechSampleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPEECHSAMPLE_H__90E57027_9FA9_11D1_9F11_444553540000__INCLUDED_)
