// SpeechSampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SpeechSample.h"
#include "SpeechSampleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSpeechSampleDlg dialog

CSpeechSampleDlg::CSpeechSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSpeechSampleDlg::IDD, pParent), m_speech(this)
{
	//{{AFX_DATA_INIT(CSpeechSampleDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSpeechSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSpeechSampleDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSpeechSampleDlg, CDialog)
	//{{AFX_MSG_MAP(CSpeechSampleDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDSPEAK, OnSpeak)
	ON_BN_CLICKED(IDVOICE, OnVoice)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpeechSampleDlg message handlers

BOOL CSpeechSampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	if (!m_speech.Init())
		return FALSE;

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSpeechSampleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSpeechSampleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSpeechSampleDlg::OnSpeak() 
{
	CString text;
	CEdit* editCtrl = (CEdit*) GetDlgItem(IDC_SPEAKEDIT);
	editCtrl->GetWindowText(text);

	m_speech.Say(text);
}

void CSpeechSampleDlg::OnVoice() 
{
}

void CSpeechSampleDlg::OnClose() 
{
	CDialog::OnClose();

	m_speech.Terminate();
}

void CSpeechSampleDlg::OnOK() 
{
	m_speech.Terminate();
	CDialog::OnOK();
}

// CSampleSpeech

BOOL CSampleSpeech::OnAudioStart (timestamp_t qTimeStamp)
{
	CButton* speakButton = (CButton*) m_dialog->GetDlgItem(IDSPEAK);
	CButton* voiceButton = (CButton*) m_dialog->GetDlgItem(IDVOICE);
	CButton* exitButton = (CButton*) m_dialog->GetDlgItem(IDOK);

	speakButton->EnableWindow(FALSE);
	voiceButton->EnableWindow(FALSE);
	exitButton->EnableWindow(FALSE);

	return TRUE;
}

BOOL CSampleSpeech::OnAudioStop (timestamp_t qTimeStamp)
{
	CButton* speakButton = (CButton*) m_dialog->GetDlgItem(IDSPEAK);
	CButton* voiceButton = (CButton*) m_dialog->GetDlgItem(IDVOICE);
	CButton* exitButton = (CButton*) m_dialog->GetDlgItem(IDOK);

	speakButton->EnableWindow(TRUE);
	voiceButton->EnableWindow(TRUE);
	exitButton->EnableWindow(TRUE);

	return TRUE;
}
