//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestApp.rc
//
#define IDC_EDIT_TEXT                   40010
#define IDC_SPEAK                       40011
#define IDC_STATIC                      40012
#define IDC_SAVE_TO_FILE                40013
#define IDC_SAVE_TO_WAVE_FILE           40014
#define IDC_LOAD_FROM_FILE              40015
#define IDC_STOP                        40016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
