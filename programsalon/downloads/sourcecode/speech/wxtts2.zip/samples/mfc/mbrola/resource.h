//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by F:\mbrola\Mbroli\Mbroli.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MBROLI_DIALOG               102
#define IDS_WINDOWTITLE                 102
#define IDR_MAINFRAME                   128
#define IDI_LOGO                        130
#define IDD_OPEN_DIALOG                 131
#define IDLOAD                          1000
#define IDC_EDIT1                       1001
#define IDC_EDITPITCH                   1003
#define IDC_EDITLENGTH                  1004
#define IDC_COMBOLANG                   1005
#define IDC_EDITVOICE                   1006
#define IDC_STOP                        1009
#define IDC_SPINPITCH                   1010
#define IDC_SPINLENGTH                  1011
#define IDC_DATABASE                    1014
#define IDC_SLIDER1                     1015
#define IDC_STATICTITLE                 1016
#define IDC_MBROLAVERSION               1017
#define IDC_SPINVOICE                   1020
#define IDC_INFO                        1024
#define IDC_LABEL                       1025
#define IDC_PATH                        1026
#define IDABOUT                         1027
#define IDC_AUTHOR                      1030
#define IDC_COPYRIGHT                   1031
#define ID_FILE_EXIT                    32772
#define ID_TOOLS_PLAY                   32773
#define ID_TOOLS_STOP                   32774
#define ID_HELP_ABOUTMBROLI             32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
