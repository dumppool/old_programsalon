  wxTTS ReadMe
  -----------------------------

  This is a work-in-progress to make a simple-to-use
  text-to-speech system available to C++ programmers, especially
  on the Windows platform. It combines the excellent MBROLA
  phoneme-to-speech with the FreePhone system, and wraps these
  up in C++ classes.

  For details and installation instructions, please see the manual
  available in a number of formats:

  docs/winhelp/wxtts.hlp                Windows Help
  docs/htmlhelp/wxtts.chm               Windows HTML Help
  docs/html/wxtts.htm                   Plain HTML

  Julian Smart, May 2000

