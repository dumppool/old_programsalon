/////////////////////////////////////////////////////////////////////////////
// Name:        make_wave.cpp
// Purpose:     ??
// Author:      Alistair Conkie
// Modified by:
// Created:
// RCS-ID:      $Id: make_wave.cpp,v 1.1 1998/10/03 11:41:31 julian Exp $
// Copyright:   (c) 1996 Alistair Conkie
// Licence:     You may distribute under the terms of the GNU General Public
//              Licence as specified in the README file.
/////////////////////////////////////////////////////////////////////////////

#include <math.h>
#include <stdio.h>
#include "t2s.h"

void tsFreePhoneImplementation::make_wave(CONFIG *config, ACOUSTIC *as)
{
	/* the code from this file has been removed  */
}
