// testhtsoundDlg.cpp : implementation file
//

#include "stdafx.h"
#include "testhtsound.h"
#include "testhtsoundDlg.h"
#include "StrSound.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTesthtsoundDlg dialog

CTesthtsoundDlg::CTesthtsoundDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTesthtsoundDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTesthtsoundDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTesthtsoundDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTesthtsoundDlg)
	DDX_Control(pDX, IDC_EDIT1, m_TextControl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTesthtsoundDlg, CDialog)
	//{{AFX_MSG_MAP(CTesthtsoundDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_PLAY, OnButtonPlay)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_HELP, OnButtonHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTesthtsoundDlg message handlers

BOOL CTesthtsoundDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
  CString	m_String;
  m_String="��ӭʹ�ú���������Ʒ\r\n��ַ��ɽ��ʡ�ɽ��������·17��\r\n�ʱࣺ043200 ��ϵ�ˣ��ַ���\r\n�绰��0359-5523345\r\n��ַ��http://htrjfw.topcool.net/";
  m_TextControl.SetWindowText(m_String);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTesthtsoundDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTesthtsoundDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTesthtsoundDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTesthtsoundDlg::OnOK() 
{
	InitHtTextSound();
}

void CTesthtsoundDlg::OnButtonPlay() 
{
  CString	m_String;
  m_TextControl.GetWindowText(m_String);
  StartTextPlay((LPTSTR)(LPCTSTR)m_String,70);
}

void CTesthtsoundDlg::OnButtonStop() 
{
  StopPlayStr();	
}

void CTesthtsoundDlg::OnButtonHelp() 
{
char dqlj1[MAX_PATH];
CString dqlj2;
CString dqlj3;
GetModuleFileName(AfxGetInstanceHandle(),dqlj1,sizeof(dqlj1));//ȡ�õ�ǰ·��ȫ��
dqlj2=AfxGetApp()->m_pszExeName;
dqlj3=dqlj1;
dqlj3=dqlj3.Left(dqlj3.GetLength()-(dqlj2.GetLength()+4));//����ͼ�⹤��·��������ֵ���Ա��ȡͼ��ʱ�á�
	CString helppath=dqlj3+"Readmeht.hlp";
	::WinHelp(GetSafeHwnd(),helppath,HELP_CONTENTS,0L);
}
