// testhtsound.h : main header file for the TESTHTSOUND application
//

#if !defined(AFX_TESTHTSOUND_H__D471D714_32CA_11D4_BD27_CE00EE489B55__INCLUDED_)
#define AFX_TESTHTSOUND_H__D471D714_32CA_11D4_BD27_CE00EE489B55__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTesthtsoundApp:
// See testhtsound.cpp for the implementation of this class
//

class CTesthtsoundApp : public CWinApp
{
public:
	CTesthtsoundApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTesthtsoundApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTesthtsoundApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTHTSOUND_H__D471D714_32CA_11D4_BD27_CE00EE489B55__INCLUDED_)
