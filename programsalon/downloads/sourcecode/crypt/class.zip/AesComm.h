#ifndef _AESCOMM_H_
#define _AESCOMM_H_

typedef	unsigned char	u1byte;	/* an 8 bit unsigned character type	*/
typedef	unsigned short  u2byte;	/* a 16 bit unsigned integer type	*/
typedef	unsigned long	u4byte;	/* a 32 bit unsigned integer type	*/
typedef	signed char		s1byte;	/* an 8 bit signed character type	*/
typedef	signed short	s2byte;	/* a 16 bit signed integer type		*/
typedef	signed long		s4byte;	/* a 32 bit signed integer type		*/

typedef union
{	u4byte	ll[4];
	u2byte	ww[8];
	u1byte	bb[16];
} uu;

#ifdef	__cplusplus

extern "C"
{
	s1byte *cipher_name(void);
	u4byte *set_key(u4byte key_blk[], u4byte key_len);
	void encrypt(u4byte in_blk[], u4byte out_blk[]);
	void decrypt(u4byte in_blk[], u4byte out_blk[]);
};

#else

s1byte *cipher_name(void);
u4byte *set_key(u4byte key_blk[], u4byte key_len);
void encrypt(u4byte in_blk[], u4byte out_blk[]);
void decrypt(u4byte in_blk[], u4byte out_blk[]);

#endif

#endif