// RC6Base.cpp: implementation of the CRC6Base class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RC6Base.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#ifndef _MSC_VER

#define rotr(x,n)   (((x) >> ((int)(n))) | ((x) << (32 - (int)(n))))
#define rotl(x,n)   (((x) << ((int)(n))) | ((x) >> (32 - (int)(n))))

#else

#include <stdlib.h>

#pragma intrinsic(_lrotr,_lrotl)
#define rotr(x,n)   _lrotr(x,n)
#define rotl(x,n)   _lrotl(x,n)

#endif

#define f_rnd(i,a,b,c,d)                                \
        t = rotl(b * (b + b + 1), 5);                   \
        u = rotl(d * (d + d + 1), 5);                   \
        a = rotl(a ^ t, u & 0x0000001f) + m_key[i];     \
        c = rotl(c ^ u, t & 0x0000001f) + m_key[i + 1]  \

#define i_rnd(i,a,b,c,d)                                \
        u = rotl(d * (d + d + 1), 5);                   \
        t = rotl(b * (b + b + 1), 5);                   \
        c = rotr(DWORD_Sub(c, m_key[i + 1]), t & 0x0000001f) ^ u; \
        a = rotr(DWORD_Sub(a, m_key[i]), u & 0x0000001f) ^ t      \

/* initialise the key schedule from the user supplied key   */


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRC6Base::CRC6Base()
{
	memset(m_key,0,44 * 4);
}

CRC6Base::~CRC6Base()
{

}

DWORD CRC6Base::DWORD_Sub(DWORD A, DWORD B)
{
	if(A >= B) return A - B;
	
	B = 0xffffffff - B + 1;
	return A + B;
}


// virtual functions

int CRC6Base::CipherInitail(DWORD dwParam)
{
	return 0;
}

int CRC6Base::KeyInitial(BYTE *pByte, DWORD nKeySize, DWORD dwParam)
{
	if(nKeySize > 32) return -1;

	m_KeySize = nKeySize;

	DWORD dwKeySize = nKeySize / 4;
	DWORD *pDWORD = (DWORD *)pByte;

	u4byte  i, j, k, a, b, l[8];

    m_key[0] = 0xb7e15163;

    for(k = 1; k < 44; ++k)
        
        m_key[k] = m_key[k - 1] + 0x9e3779b9;

    for(k = 0; k < dwKeySize; ++k)

        l[k] = pDWORD[k];

    for(a = b = k = 0; k < 132; ++k)
    {
        i = k % 44; 
		j = k % dwKeySize;
        a = rotl(m_key[i] + a + b, 3); b += a;
        b = rotl(l[j] + b, b & 0x0000001f);
        m_key[i] = a; l[j] = b;
    }
	return 0;
}

int CRC6Base::Encrypt(BYTE *pByte, DWORD nBlockSize)
{
	u4byte  a,b,c,d,t,u;

	DWORD *pDWORD = (DWORD *)pByte;

    a = pDWORD[0]; b = pDWORD[1] + m_key[0];
    c = pDWORD[2]; d = pDWORD[3] + m_key[1];

    f_rnd( 2,a,b,c,d); f_rnd( 4,b,c,d,a);
    f_rnd( 6,c,d,a,b); f_rnd( 8,d,a,b,c);
    f_rnd(10,a,b,c,d); f_rnd(12,b,c,d,a);
    f_rnd(14,c,d,a,b); f_rnd(16,d,a,b,c);
    f_rnd(18,a,b,c,d); f_rnd(20,b,c,d,a);
    f_rnd(22,c,d,a,b); f_rnd(24,d,a,b,c);
    f_rnd(26,a,b,c,d); f_rnd(28,b,c,d,a);
    f_rnd(30,c,d,a,b); f_rnd(32,d,a,b,c);
    f_rnd(34,a,b,c,d); f_rnd(36,b,c,d,a);
    f_rnd(38,c,d,a,b); f_rnd(40,d,a,b,c);

    pDWORD[0] = a + m_key[42]; pDWORD[1] = b;
    pDWORD[2] = c + m_key[43]; pDWORD[3] = d;
	return 0;
}

int CRC6Base::Decrypt(BYTE *pByte, DWORD nBlockSize)
{
	u4byte  a,b,c,d,t,u;
	DWORD *pDWORD = (DWORD *)pByte;

    d = pDWORD[3]; c = DWORD_Sub(pDWORD[2] , m_key[43]); 
    b = pDWORD[1]; a = DWORD_Sub(pDWORD[0] , m_key[42]);

    i_rnd(40,d,a,b,c); i_rnd(38,c,d,a,b);
    i_rnd(36,b,c,d,a); i_rnd(34,a,b,c,d);
    i_rnd(32,d,a,b,c); i_rnd(30,c,d,a,b);
    i_rnd(28,b,c,d,a); i_rnd(26,a,b,c,d);
    i_rnd(24,d,a,b,c); i_rnd(22,c,d,a,b);
    i_rnd(20,b,c,d,a); i_rnd(18,a,b,c,d);
    i_rnd(16,d,a,b,c); i_rnd(14,c,d,a,b);
    i_rnd(12,b,c,d,a); i_rnd(10,a,b,c,d);
    i_rnd( 8,d,a,b,c); i_rnd( 6,c,d,a,b);
    i_rnd( 4,b,c,d,a); i_rnd( 2,a,b,c,d);

    pDWORD[3] = DWORD_Sub(d , m_key[1]); pDWORD[2] = c; 
    pDWORD[1] = DWORD_Sub(b , m_key[0]); pDWORD[0] = a; 
	return 0;
}

int CRC6Base::GetBlockSize()
{
	return 16;
}

int CRC6Base::GetKeySize() 
{
	return m_KeySize;
}

int CRC6Base::GetRounds()
{
	return 16;
}

