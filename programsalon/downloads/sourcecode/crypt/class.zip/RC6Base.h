// RC6Base.h: interface for the CRC6Base class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RC6BASE_H__B7A2C822_5B59_11D2_9653_041ECB000000__INCLUDED_)
#define AFX_RC6BASE_H__B7A2C822_5B59_11D2_9653_041ECB000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CipherBase.h"
#include "AesComm.h"

class CRC6Base : public CCipherBase  
{
public:
	CRC6Base();
	virtual ~CRC6Base();

	virtual int CipherInitail(DWORD dwParam) ;
	virtual int KeyInitial(BYTE *pByte, DWORD nKeySize, DWORD dwParam) ;
	virtual int Encrypt(BYTE *pByte, DWORD nBlockSize) ;
	virtual int Decrypt(BYTE *pByte, DWORD nBlockSize) ;
	virtual int GetBlockSize() ;
	virtual int GetKeySize() ;
	virtual int GetRounds();

protected:

	u4byte   m_key[44];
	DWORD m_KeySize;

	DWORD DWORD_Sub(DWORD A, DWORD B);

};

#endif // !defined(AFX_RC6BASE_H__B7A2C822_5B59_11D2_9653_041ECB000000__INCLUDED_)
