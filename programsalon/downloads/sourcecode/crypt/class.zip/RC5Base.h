// RC5Base.h: interface for the CRC5Base class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RC5BASE_H__C4B53089_4416_11D2_9650_106923000000__INCLUDED_)
#define AFX_RC5BASE_H__C4B53089_4416_11D2_9650_106923000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "CipherBase.h"



/* The RC5 blocksize */

#define RC5_BLOCKSIZE		8

/* The default and maximum (sane) number of RC5 rounds */

#define RC5_DEFAULT_ROUNDS	12
#define RC5_MAX_ROUNDS		32

/* The maximum RC5 expanded key size: 256 bytes.  Note that sizeof( LONG )
   may not equal 4, so the total size may in fact be more than 256 bytes,
   however the total information content is only 256 bytes */

#define RC5_EXPANDED_KEYSIZE_LONG	64
#define RC5_EXPANDED_KEYSIZE		( RC5_EXPANDED_KEYSIZE_LONG * sizeof( LONG ) )

/* A structure to hold the RC5 key */

typedef struct {
	LONG S[ RC5_EXPANDED_KEYSIZE_LONG ];	/* S-box */
	int noRounds;							/* Number of rounds */
	} RC5_KEY;

class CRC5Base : public CCipherBase  
{
public:
	CRC5Base();
	virtual ~CRC5Base();

	virtual int CipherInitail(DWORD dwParam) ;
	virtual int KeyInitial(BYTE *pByte, DWORD nKeySize, DWORD dwParam) ;
	virtual int Encrypt(BYTE *pByte, DWORD nBlockSize) ;
	virtual int Decrypt(BYTE *pByte, DWORD nBlockSize) ;
	virtual int GetBlockSize() ;
	virtual int GetKeySize() ;
	virtual int GetRounds();

private:
	RC5_KEY m_key;
	DWORD m_KeySize;

};

#endif // !defined(AFX_RC5BASE_H__C4B53089_4416_11D2_9650_106923000000__INCLUDED_)
