#include <stdio.h>
#include <dos.h>
#include <io.h>
#include <string.h>
#define T 1
#define F 0
#define PASSLEN 8
FILE *fp1,*fp2,*fpout;
union REGS in,out;

union{
  unsigned axreg;
  struct
   {   unsigned diskette:1;
       unsigned ndp:1;
       unsigned  sys_ram:2;
       unsigned video_mode:2;
       unsigned drive_num:2;
       unsigned dma:1;
       unsigned serial_ports:3;
       unsigned game_adapter:1;
       unsigned pcjr_printer:1;
       unsigned printer_num:2;
   }flags;
     }equip;
void inputpassword( char *key);
void  writepassword(char *key);
void  testhardware();
void makepassword(char *key);
void readpassword(char *key);
void installware();
char buff1[20],key1[9],buff2[20],key2[9];
unsigned long int len;
int flag;
main(int argc,char *argv[])
{
int newdisk,olddisk,m;
 if(argc<2||argc>3)
  {
   printf("\n\n\t\t Usage:[drive][path] install [targetdrive]\n");
   exit(0);
  }
olddisk=getdisk();
newdisk=toupper(argv[1][0])-'A';
setdisk(newdisk);
flag=testflag();
if(!flag)
  {
    setflag();
    inputpassword(key1);
    makepassword(key1);
    writepassword(key1);
    testhardware();
    installware();
  }
else
  {
    testhardware();
    m=readhardware();
    if(m)  /* �Ƚ�Ӳ���ı�û�� */
       installware();
    else
       {
	inputpassword(key1);
	readpassword(key2);
	if(!strcmp(key1,key2))
	  {
	   makepassword(key1);
	   writepassword(key1);
	   installware();
	  }
	else
	 exit(-2);
       }

   }
setdisk(olddisk);
}

int testflag()  /* ����ĸA��ASCII����Ϊ�Ƿ�װ�ı�־, AΪ�Ѱ�װ
		   ��AΪδ��װ  */
{
char c,j;
 if((fp1=fopen("ch.exe","rb"))==NULL)
   exit(-1);
 c=65;
 fseek(fp1,-1,2);
 fread(&j,sizeof(char),1,fp1);
 fclose(fp1);
 if(c==j)
   return T;
 else
   return F;
}

int setflag()   /* ���ļ�CH.EXE��ĩβд����ĸA,��Ϊ�Ѱ�װ��־  */
{
char c;
 if((fp1=fopen("ch.exe","a+"))==NULL)
   exit(-1);
 c=65;
 fseek(fp1,0,2);  /* ����ĸAд��CH.EXE�ļ���ĩβ */
 fwrite(&c,sizeof(char),1,fp1);
 fclose(fp1);
}

void inputpassword( char *key)  /* Ҫ���û����밲װ���� */
{
 char k[PASSLEN],l[PASSLEN],c;
 int i;
 strcpy(k,'\0');
 strcpy(l,'\0');
 clrscr();
 printf("\n\n\n\n\n\n\n\n\t\tPlease Input Your Password: ");
 for(i=0;i<PASSLEN;i++)
   {
    c=getch();
    strcat(k,&c);
    }
 strcat(k,'\0');
 clrscr();
 printf("\n\n\n\n\n\n\n\n\t\tPlease Verfiy Your Password: ");
 for(i=0;i<PASSLEN;i++)
   {
    c=getch();
    strcat(l,&c);
    }
 strcat(l,'\0');
 if(strcmp(k,l))
   {
   printf("Please Try Again!\n");
   printf("Press any key to continue......\n");
   getch();
   inputpassword(k);
   }
 else
   strcpy(key,k);
}

void makepassword(char *key) /* ��������任,���������� */
{
   static char word[]={'a','b','c','d','e','f','g','h','i','j','k','l',
   'm','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C',
   'D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T',
   'U','V','W','X','Y','Z','\0'};
  static int passkey[]={4,3,5,10,23,7,11,37};
  int i,j,k,l,m[PASSLEN];
  char s[PASSLEN],c;
  l=strlen(word);
  k=PASSLEN;
  for(i=0;i<k;i++)
    {
     for(j=0;j<l;j++)
      if(key[i]==word[j])
	 m[i]=j;
    }
 for(i=0;i<k;i++)
   {
     m[i]*=passkey[i];
     if(m[i]>51)
       m[i]=m[i]%52;
   }
 strcpy(s,'\0');
 for(i=0;i<k;i++)
   {
    c=word[m[i]];
    strcat(s,&c);
   }
 strcat(s,'\0');
 strcpy(key,s);
}

void  writepassword(char *key)  /* ��������д��set.exe�ļ� */
{
 if((fp2=fopen("set.exe","a+"))==NULL)
   {
    printf("Can not Open File........\n");
    printf("press any key to continue\n");
    getch();
    exit(-1);
   }
 fseek(fp2,0,2);
 len=ftell(fp2);   /* ��¼SET.EXE�ļ���ԭʼ���� */
 fwrite(key,PASSLEN,1,fp2); /* ������д��SET.EXE�ļ���ĩβ */
 fseek(fp2,0,2); /* ��SET.EXE��ԭʼ����д��SET.EXE�ļ���ĩβ */
 fwrite(&len,sizeof(unsigned long int),1,fp2);
 fclose(fp2);
}

void  testhardware()  /* ���Բ���¼Ӳ������ */
{
int x[6],i;
if((fpout=fopen("ch.exe","a+"))==NULL)
exit(0);
fseek(fpout,0,2);
len=ftell(fpout);  /* ��¼Ӳ���������λ�� */
int86(0x11,&in,&out);
equip.axreg=out.x.ax;
if(equip.flags.game_adapter==0)
  x[0]=0;
  else if(equip.flags.game_adapter==1)
      x[0]=1;
      else if(equip.flags.game_adapter==2)
       x[0]=2;
	else x[0]=0;
if(equip.flags.serial_ports==0)
  x[1]=0;
  else if(equip.flags.serial_ports==1)
      x[1]=1;
      else if(equip.flags.serial_ports==2)
       x[1]=2;
	else x[1]=0;
if(equip.flags.dma==0)
  x[2]=0;
  else if(equip.flags.dma==1)
      x[2]=1;
      else if(equip.flags.dma==2)
       x[2]=2;
	else x[2]=0;
if((equip.flags.drive_num+1)==0)
  x[3]=1;
  else if((equip.flags.drive_num+1)==1)
      x[3]=2;
      else if((equip.flags.drive_num+1)==2)
       x[3]=3;
	else x[3]=1;
if(equip.flags.video_mode==0)
  x[4]=0;
else if(equip.flags.video_mode==1)
      x[4]=1;
      else if(equip.flags.video_mode==2)
       x[4]=2;
	else x[4]=0;

x[5]=0;
for(i=0;i<5;i++)
  fprintf(fpout,"%d",x[i]);
in.h.ah=0x08;
in.h.dl=0x80;
int86(0x13,&in,&out);
for(i=0;i<out.h.dl;i++)
  {
   in.h.dl=0x80+i;
   int86(0x13,&in,&out);
   fprintf(fpout,"%d",++out.h.dh);
   out.h.bh=(out.h.cl&0xc0)>>6;
   out.h.bl=out.h.ch;
   fprintf(fpout,"%d",out.x.bx);
   fprintf(fpout,"%d",out.h.cl&0x3f);
  }
fwrite(&len,sizeof(unsigned long int),1,fpout);
fclose(fpout);
}

int readhardware()  /* ��Ӳ�������������Ӳ���������бȽ�,
		   ��ͬ����T,���򷵻�F */
{
  int i,j,k,l;
  char x[PASSLEN],y[PASSLEN];
 union REGS in,out;
 if((fp1=fopen("ch.obj","rb"))==NULL)
     exit(-1);
 l=sizeof(unsigned long int);
 fseek(fp1,-l,2);
 fread(&len,l,1,fp1);  /* ��Ӳ���������λ�� */
 fseek(fp1,len,0);
 fread(y,sizeof(int)*5,1,fp1);

 int86(0x11,&in,&out);
 equip.axreg=out.x.ax;
if(equip.flags.game_adapter==0)
  x[0]=0;
  else if(equip.flags.game_adapter==1)
      x[0]=1;
      else if(equip.flags.game_adapter==2)
       x[0]=2;
	else x[0]=0;
if(equip.flags.serial_ports==0)
  x[1]=0;
  else if(equip.flags.serial_ports==1)
      x[1]=1;
      else if(equip.flags.serial_ports==2)
       x[1]=2;
	else x[1]=0;
if(equip.flags.dma==0)
  x[2]=0;
  else if(equip.flags.dma==1)
      x[2]=1;
      else if(equip.flags.dma==2)
       x[2]=2;
	else x[2]=0;
if((equip.flags.drive_num+1)==0)
  x[3]=1;
  else if((equip.flags.drive_num+1)==1)
      x[3]=2;
      else if((equip.flags.drive_num+1)==2)
       x[3]=3;
	else x[3]=1;
if(equip.flags.video_mode==0)
  x[4]=0;
else if(equip.flags.video_mode==1)
      x[4]=1;
      else if(equip.flags.video_mode==2)
       x[4]=2;
	else x[4]=0;

x[5]=0;
for(i=0;i<5;i++)
    if(x[i]!=y[i])
       return F;
in.h.ah=0x08;
in.h.dl=0x80;
int86(0x13,&in,&out);
for(i=0;i<out.h.dl;i++)
  {
   in.h.dl=0x80+i;
   int86(0x13,&in,&out);
   fscanf(fp1,"%d",&k);
   if(k!=++out.h.dh)
     return F;
   out.h.bh=(out.h.cl&0xc0)>>6;
   out.h.bl=out.h.ch;
   fscanf(fp1,"%d",&k);
   if(k!=out.x.bx)
     return F;
   fscanf(fp1,"%d",&k);
   if(k!=(out.h.cl&0x3f))
      return F;
  }
 in.h.ah=0x08;
 in.h.dl=0x80;
 int86(0x13,&in,&out);
 for(i=0;i<out.h.dl;i++)
   {

    in.h.dl=0x80+i;
    int86(0x13,&in,&out);
    j=++out.h.dh;
    fread(&k,sizeof(int),1,fp1);
    if(j!=k)
      return F;
    out.h.bh=(out.h.cl&0xc0)>>6;
    out.h.bl=out.h.ch;
    fread(&j,sizeof(int),1,fp1);
    if(j!=out.x.bx)
      return F;
    fread(&j,sizeof(int),1,fp1);
    k=out.h.cl&0x3f;
    if(j!=k)
      return F;
   }
  fclose(fp1);
  return T;
}

void readpassword(char *key)   /* ����¼���ļ��е����� */
{
 if((fp2=fopen("set.exe","r"))==NULL)
   {
    printf("Can not Open File........\n");
    printf("press any key to continue\n");
    getch();
    exit(-1);
   }
 fseek(fp2,0,2);  /* ��������λ�� */
 fread(&len,sizeof(unsigned long int ),1,fp2);
 fseek(fp2,len,0);
 fread(key,PASSLEN,1,fp2);  /* ������ */
 fclose(fp2);
 }

void installware()
{  /*  �ڴ�ģ����,�ɽ��������н�ѹ�����й��ļ���
       Ӳ�̵�ָ��Ŀ¼��;��Ȼ,����Ҫ�Ŀ�ִ���ļ���
       Ӧ������Ӳ�����ý��в��Բ��Ƚϵĺ���,�籾��
       ���е�testhardware(),readhardware()��,�緢��Ӳ
       �����øı���ܾ�ִ��,������������г��� */

}