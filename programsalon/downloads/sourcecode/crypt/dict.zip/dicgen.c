/*  This file is a part of the samsa-dix dictionary generator 
 *  Copyright  (c) 1999  by Samsa Hacking Corp.
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>        
#include <unistd.h>
#include <signal.h>

#define MAXPASS   8

/* default: all letters are small    */
/*#define FIRSTCAP*/                   
/* FIRSTCAP: first letter is capital:e.g. Rong */
/*#define ALLCAP*/		 
/* ALLCAP  : all letters are capital:e.g. RONG */

static char * syllables [] = {
    /* consonants */
	"b","p","m","f",
	"d","t","n","l",
	"g","k","h",
	"j","q","x",
	"zh","ch","sh",
	"r","z","c","s",
    /* valid syllables */
    /* -- a -- */
	"a","ai","an","ang","ao",
    /* -- b -- */
	"ba","bai","ban","bang","bao","bei","ben","beng",
	"bi","bian","biao","bie","bin","bing","bo","bu",
    /* -- c -- */
	"ca","cai","can","cang","cao","ce","cen","ceng",
	"cha","chai","chan","chang","chao","che","chen",
	"cheng","chi","chong","chou","chu","chua","chuai",
	"chuan","chuang","chui","chun","chuo","ci","cong",
	"cou","cu","cuan","cui","cun","cuo",
    /* -- d -- */
	"da","dai","dan","dang","dao","de","dei","den",
	"deng","di","dia","dian","diao","die","ding","diu",
	"dong","dou","du","duan","dui","dun","duo",
    /* -- e -- */
	"e","ei","en","eng","er",
    /* -- f -- */
	"fa","fan","fang","fei","fen","feng","fo","fou","fu",
    /* -- g -- */
	"ga","gai","gan","gang","gao","ge","gei","gen","geng",
	"gong","gou","gu","gua","guan","guang","gui","gun","guo",
    /* -- h -- */
	"ha","hai","han","hang","hao","he","hei","hen","heng",
	"hm","hng","hong","hou","hu","hua","huai","huan",
	"huang","hui","hun","huo",
    /* -- j -- */
	"ji","jia","jian","jiang","jiao","jie","jin","jing",
	"jiong","jiu","ju","juan","jue","jun",
    /* -- k -- */
	"ka","kai","kan","kang","kao","ke","kei","ken","keng",
	"kong","kou","ku","kua","kuai","kuan","kuang","kui",
	"kun","kuo",
    /* -- l -- */
	"la","lai","lan","lang","lao","le","lei","len","leng",
	"li","lia","lian","liang","liao","lie","lin","ling",
	"liu","lo","long","lou","lu","lv","luan","lue","lun","luo",
    /* -- m -- */
	"ma","mai","man","mang","mao","me","mei","men","meng",
	"mi","mian","miao","mie","min","ming","miu","mo","mou","mu",
    /* -- n -- */
	"na","nai","nan","nang","nao","ne","nei","nen","neng","ng",
	"ni","nia","nian","niang","niao","nie","nin","ning",
	"niu","nong","nou","nu","nv","nuan","nue","nuo",
    /* -- o -- */
	"o","ou",
    /* -- p -- */
	"pa","pai","pan","pang","pao","pei","pen","peng","pi","pian",
	"piao","pie","pin","ping","po","pou","pu",
    /* -- q -- */
	"qi","qia","qian","qiang","qiao","qie","qin","qing",
	"qiong","qiu","qu","quan","que","qun",
    /* -- r -- */
    	"ran","rang","rao","re","ren","reng","ri","rong","rou",
    	"ru","rua","ruan","rui","run","ruo",
    /* -- s -- */
	"sa","sai","san","sang","sao","se","sen","seng",
	"sha","shai","shan","shang","shao","she","shei","shen",
	"sheng","shi","shou","shu","shua","shuai",
	"shuan","shuang","shui","shun","shuo","si","song",
	"sou","su","suan","sui","sun","suo",
    /* -- t -- */
	"ta","tai","tan","tang","tao","te","tei",
	"teng","ti","tian","tiao","tie","ting",
	"tong","tou","tu","tuan","tui","tun","tuo",
    /* -- w -- */
	"wa","wai","wan","wang","wei","wen","weng","wo","wu",
    /* -- x -- */
	"xi","xia","xian","xiang","xiao","xie","xin","xing",
	"xiong","xiu","xu","xuan","xue","xun",
    /* -- y -- */
	"ya","yan","yang","ye","yi","yin","ying","yo",
	"yong","you","yu","yuan","yue","yun",    	
    /* -- s -- */
	"za","zai","zan","zang","zao","ze","zen","zeng",
	"zha","zhai","zhan","zhang","zhao","zhe","zhei","zhen",
	"zheng","zhi","zhou","zhu","zhua","zhuai",
	"zhuan","zhuang","zhui","zhun","zhuo","zi","zong",
	"zou","zu","zuan","zui","zun","zuo",

#ifdef FIRSTCAP
    /* consonants */
	"B","P","M","F",
	"D","T","N","L",
	"G","K","H",
	"J","Q","X",
	"Zh","Ch","Sh",
	"R","Z","C","S",
    /* valid syllables */
    /* -- a -- */
	"A","Ai","An","Ang","Ao",
    /* -- b -- */
	"Ba","Bai","Ban","Bang","Bao","Bei","Ben","Beng",
	"Bi","Bian","Biao","Bie","Bin","Bing","Bo","Bu",
    /* -- c -- */
	"Ca","Cai","Can","Cang","Cao","Ce","Cen","Ceng",
	"Cha","Chai","Chan","Chang","Chao","Che","Chen",
	"Cheng","Chi","Chong","Chou","Chu","Chua","Chuai",
	"Chuan","Chuang","Chui","Chun","Chuo","Ci","Cong",
	"Cou","Cu","Cuan","Cui","Cun","Cuo",
    /* -- d -- */
	"Da","Dai","Dan","Dang","Dao","De","Dei","Den",
	"Deng","Di","Dia","Dian","Diao","Die","Ding","Diu",
	"Dong","Dou","Du","Duan","Dui","Dun","Duo",
    /* -- e -- */
	"E","Ei","En","Eng","Er",
    /* -- f -- */
	"Fa","Fan","Fang","Fei","Fen","Feng","Fo","Fou","Fu",
    /* -- g -- */
	"Ga","Gai","Gan","Gang","Gao","Ge","Gei","Gen","Geng",
	"Gong","Gou","Gu","Gua","Guan","Guang","Gui","Gun","Guo",
    /* -- h -- */
	"Ha","Hai","Han","Hang","Hao","He","Hei","Hen","Heng",
	"Hm","Hng","Hong","Hou","Hu","Hua","Huai","Huan",
	"Huang","Hui","Hun","Huo",
    /* -- j -- */
	"Ji","Jia","Jian","Jiang","Jiao","Jie","Jin","Jing",
	"Jiong","Jiu","Ju","Juan","Jue","Jun",
    /* -- k -- */
	"Ka","Kai","Kan","Kang","Kao","Ke","Kei","Ken","Keng",
	"Kong","Kou","Ku","Kua","Kuai","Kuan","Kuang","Kui",
	"Kun","Kuo",
    /* -- l -- */
	"La","Lai","Lan","Lang","Lao","Le","Lei","Len","Leng",
	"Li","Lia","Lian","Liang","Liao","Lie","Lin","Ling",
	"Liu","Lo","Long","Lou","Lu","Lv","Luan","Lue","Lun","Luo",
    /* -- m -- */
	"Ma","Mai","Man","Mang","Mao","Me","Mei","Men","Meng",
	"Mi","Mian","Miao","Mie","Min","Ming","Miu","Mo","Mou","Mu",
    /* -- n -- */
	"Na","Nai","Nan","Nang","Nao","Ne","Nei","Nen","Neng","Ng",
	"Ni","Nia","Nian","Niang","Niao","Nie","Nin","Ning",
	"Niu","Nong","Nou","Nu","Nv","Nuan","Nue","Nuo",
    /* -- o -- */
	"O","Ou",
    /* -- p -- */
	"Pa","Pai","Pan","Pang","Pao","Pei","Pen","Peng","Pi","Pian",
	"Piao","Pie","Pin","Ping","Po","Pou","Pu",
    /* -- q -- */
	"Qi","Qia","Qian","Qiang","Qiao","Qie","Qin","Qing",
	"Qiong","Qiu","Qu","Quan","Que","Qun",
    /* -- r -- */
    	"Ran","Rang","Rao","Re","Ren","Reng","Ri","Rong","Rou",
    	"Ru","Rua","Ruan","Rui","Run","Ruo",
    /* -- s -- */
	"Sa","Sai","San","Sang","Sao","Se","Sen","Seng",
	"Sha","Shai","Shan","Shang","Shao","She","Shei","Shen",
	"Sheng","Shi","Shou","Shu","Shua","Shuai",
	"Shuan","Shuang","Shui","Shun","Shuo","Si","Song",
	"Sou","Su","Suan","Sui","Sun","Suo",
    /* -- t -- */
	"Ta","Tai","Tan","Tang","Tao","Te","Tei",
	"Teng","Ti","Tian","Tiao","Tie","Ting",
	"Tong","Tou","Tu","Tuan","Tui","Tun","Tuo",
    /* -- w -- */
	"Wa","Wai","Wan","Wang","Wei","Wen","Weng","Wo","Wu",
    /* -- x -- */
	"Xi","Xia","Xian","Xiang","Xiao","Xie","Xin","Xing",
	"Xiong","Xiu","Xu","Xuan","Xue","Xun",
    /* -- y -- */
	"Ya","Yan","Yang","Ye","Yi","Yin","Ying","Yo",
	"Yong","You","Yu","Yuan","Yue","Yun",    	
    /* -- s -- */
	"Za","Zai","Zan","Zang","Zao","Ze","Zen","Zeng",
	"Zha","Zhai","Zhan","Zhang","Zhao","Zhe","Zhei","Zhen",
	"Zheng","Zhi","Zhou","Zhu","Zhua","Zhuai",
	"Zhuan","Zhuang","Zhui","Zhun","Zhuo","Zi","Zong",
	"Zou","Zu","Zuan","Zui","Zun","Zuo",
#endif

#ifdef ALLCAP
    /* consonants */
	"B","P","M","F",
	"D","T","N","L",
	"G","K","H",
	"J","Q","X",
	"ZH","CH","SH",
	"R","Z","C","S",
    /* valid syllables */
    /* -- a -- */
	"A","AI","AN","ANG","AO",
    /* -- b -- */
	"BA","BAI","BAN","BANG","BAO","BEI","BEN","BENG",
	"BI","BIAN","BIAO","BIE","BIN","BING","BO","BU",
    /* -- c -- */
	"CA","CAI","CAN","CANG","CAO","CE","CEN","CENG",
	"CHA","CHAI","CHAN","CHANG","CHAO","CHE","CHEN",
	"CHENG","CHI","CHONG","CHOU","CHU","CHUA","CHUAI",
	"CHUAN","CHUANG","CHUI","CHUN","CHUO","CI","CONG",
	"COU","CU","CUAN","CUI","CUN","CUO",
    /* -- d -- */
	"DA","DAI","DAN","DANG","DAO","DE","DEI","DEN",
	"DENG","DI","DIA","DIAN","DIAO","DIE","DING","DIU",
	"DONG","DOU","DU","DUAN","DUI","DUN","DUO",
    /* -- e -- */
	"E","EI","EN","ENG","ER",
    /* -- f -- */
	"FA","FAN","FANG","FEI","FEN","FENG","FO","FOU","FU",
    /* -- g -- */
	"GA","GAI","GAN","GANG","GAO","GE","GEI","GEN","GENG",
	"GONG","GOU","GU","GUA","GUAN","GUANG","GUI","GUN","GUO",
    /* -- h -- */
	"HA","HAI","HAN","HANG","HAO","HE","HEI","HEN","HENG",
	"HM","HNG","HONG","HOU","HU","HUA","HUAI","HUAN",
	"HUANG","HUI","HUN","HUO",
    /* -- j -- */
	"JI","JIA","JIAN","JIANG","JIAO","JIE","JIN","JING",
	"JIONG","JIU","JU","JUAN","JUE","JUN",
    /* -- k -- */
	"KA","KAI","KAN","KANG","KAO","KE","KEI","KEN","KENG",
	"KONG","KOU","KU","KUA","KUAI","KUAN","KUANG","KUI",
	"KUN","KUO",
    /* -- l -- */
	"LA","LAI","LAN","LANG","LAO","LE","LEI","LEN","LENG",
	"LI","LIA","LIAN","LIANG","LIAO","LIE","LIN","LING",
	"LIU","LO","LONG","LOU","LU","LV","LUAN","LUE","LUN","LUO",
    /* -- m -- */
	"MA","MAI","MAN","MANG","MAO","ME","MEI","MEN","MENG",
	"MI","MIAN","MIAO","MIE","MIN","MING","MIU","MO","MOU","MU",
    /* -- n -- */
	"NA","NAI","NAN","NANG","NAO","NE","NEI","NEN","NENG","NG",
	"NI","NIA","NIAN","NIANG","NIAO","NIE","NIN","NING",
	"NIU","NONG","NOU","NU","NV","NUAN","NUE","NUO",
    /* -- o -- */
	"O","OU",
    /* -- p -- */
	"PA","PAI","PAN","PANG","PAO","PEI","PEN","PENG","PI","PIAN",
	"PIAO","PIE","PIN","PING","PO","POU","PU",
    /* -- q -- */
	"QI","QIA","QIAN","QIANG","QIAO","QIE","QIN","QING",
	"QIONG","QIU","QU","QUAN","QUE","QUN",
    /* -- r -- */
    	"RAN","RANG","RAO","RE","REN","RENG","RI","RONG","ROU",
    	"RU","RUA","RUAN","RUI","RUN","RUO",
    /* -- s -- */
	"SA","SAI","SAN","SANG","SAO","SE","SEN","SENG",
	"SHA","SHAI","SHAN","SHANG","SHAO","SHE","SHEI","SHEN",
	"SHENG","SHI","SHOU","SHU","SHUA","SHUAI",
	"SHUAN","SHUANG","SHUI","SHUN","SHUO","SI","SONG",
	"SOU","SU","SUAN","SUI","SUN","SUO",
    /* -- t -- */
	"TA","TAI","TAN","TANG","TAO","TE","TEI",
	"TENG","TI","TIAN","TIAO","TIE","TING",
	"TONG","TOU","TU","TUAN","TUI","TUN","TUO",
    /* -- w -- */
	"WA","WAI","WAN","WANG","WEI","WEN","WENG","WO","WU",
    /* -- x -- */
	"XI","XIA","XIAN","XIANG","XIAO","XIE","XIN","XING",
	"XIONG","XIU","XU","XUAN","XUE","XUN",
    /* -- y -- */
	"YA","YAN","YANG","YE","YI","YIN","YING","YO",
	"YONG","YOU","YU","YUAN","YUE","YUN",    	
    /* -- s -- */
	"ZA","ZAI","ZAN","ZANG","ZAO","ZE","ZEN","ZENG",
	"ZHA","ZHAI","ZHAN","ZHANG","ZHAO","ZHE","ZHEI","ZHEN",
	"ZHENG","ZHI","ZHOU","ZHU","ZHUA","ZHUAI",
	"ZHUAN","ZHUANG","ZHUI","ZHUN","ZHUO","ZI","ZONG",
	"ZOU","ZU","ZUAN","ZUI","ZUN","ZUO",
#endif
	NULL
	};



void start(){  /* daemonlization */
  int i;

  if (fork() != 0) exit(0);      /* background */

  setsid();                      /* a new session */
			  	 /* not controlling terminal */
  signal (SIGHUP,SIG_IGN);       /* can't be hang up */

  if (fork() != 0) exit(0);      /* am not session leader */
				 /* can't get controlling terminal later */

  for (i=0; i<3; i++) close(i);  /* close all file descriptor */
 
}
 
void gen_words(char *buf,int buflen,int level){
  char ** pptr;
  int  len;

  if (buflen >= MAXPASS || level == 0){
	printf("%s\n",buf);
	return;
  }   /* output a word */

  pptr = syllables ;
  for (; *pptr != NULL ; pptr ++){
	len = strlen(*pptr);
	if ((buflen + len) <= MAXPASS){
		strcpy(buf + buflen,*pptr);
		gen_words(buf,buflen+len,level-1);
	}
  }

}


main(int argc,char **argv){
  char buf[MAXPASS+1];
  int  cnt;
  int  out;

  umask(0);

  if (argc == 2){
	cnt = 3;
	out = open(argv[1],O_WRONLY | O_CREAT | O_TRUNC);
  }
  if (argc == 3){
	cnt = atoi(argv[1]);
	out = open(argv[2],O_WRONLY | O_CREAT | O_TRUNC);
  }
  else {
	printf("Usage: %s [syllable count] outfile\n",argv[0]);
	printf("e.g. %s 2 ./words\n",argv[0]);
	exit(0);
  }

  if (cnt > 3) {
	printf("Syllable count must be less than 3(include 3).\n");
	exit(0);
  }

  start();      /* daemonlize it */

  dup2(out,1);

  gen_words(buf,0,cnt);
}
	
