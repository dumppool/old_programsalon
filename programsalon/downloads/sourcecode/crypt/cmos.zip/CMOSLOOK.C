/* CMOSLOOK.C - Look at IBM PC/AT's Real-time Clock/CMOS RAM information

   Jim Cronin  2-86
*/

#include <stdio.h>
#define IOADDRESS 0x070
#define IODATA    0x071

static char *what[] = {
/* 00 */ "Seconds",                            "Second alarm", 
/* 02 */ "Minutes",                            "Minute alarm", 
/* 04 */ "Hours",                              "Hour alarm",   
/* 06 */ "Day of week",                        "Date of month",
/* 08 */ "Month",                              "Year",
/* 0A */ "Status register A",                  "Status register B",
/* 0C */ "Status register C",                  "Status register D", 
/* 0E */ "Diagnostic status byte",             "Shutdown status byte",
/* 10 */ "Diskette drive type byte - drives A and B","Reserved",
/* 12 */ "Fixed disk type byte - drives C and D",    "Reserved",
/* 14 */ "Equipment byte",                     "Low base memory byte",   
/* 16 */ "High base memory byte",              "Low expansion memory byte",
/* 18 */ "High expansion memory byte",         "Reserved",
/* 1A */ "Reserved",                           "Reserved",
/* 1C */ "Reserved",                           "Reserved",
/* 1E */ "Reserved",                           "Reserved",
/* 20 */ "Reserved",                           "Reserved",
/* 22 */ "Reserved",                           "Reserved",
/* 24 */ "Reserved",                           "Reserved",
/* 26 */ "Reserved",                           "Reserved",
/* 28 */ "Reserved",                           "Reserved",
/* 2A */ "Reserved",                           "Reserved", 
/* 2C */ "Reserved",                           "Reserved",
/* 2E */ "Checksum byte 1",                    "Checksum byte 2",
/* 30 */ "Low expansion memory byte",          "High expansion memory byte",
/* 32 */ "Date century byte",                  "Information flags",
/* 34 */ "Reserved",                           "Reserved",
/* 36 */ "Reserved",                           "Reserved",
/* 38 */ "Reserved",                           "Reserved",
/* 3A */ "Reserved",                           "Reserved",
/* 3C */ "Reserved",                           "Reserved", 
/* 3E */ "Reserved",                           "Reserved", ""};


main ()
{
   unsigned char location, value;
   extern unsigned char inportb();

   printf (" Loc.  Hex  Binary  Name\n ----  ---  --------  ----\n");
   for (location = 0; *what[location] != '\0'; location++)
       {
       outportb (IOADDRESS, location);
       value = inportb (IODATA);
       printf (" %4x  %3x  %8b  %s\n", 
               location, value, value, what[location]);
       }
}





