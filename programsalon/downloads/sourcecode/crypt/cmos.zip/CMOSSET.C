/* CMOSSET.C - Set IBM PC/AT's Real-time Clock/CMOS RAM information

   Jim Cronin  2-86
*/

#include <stdio.h>
#define IOADDRESS 0x070
#define IODATA    0x071

main ()
{
   unsigned char location, value;
   extern unsigned char inportb();

   for ( ; ; )
       {
       printf ("Location: ");
       if (! scanf ("%x", &location)) break;

       outportb (IOADDRESS, location);
       value = inportb (IODATA);
       printf ("Was: %02x set to: ", value);
       if (! scanf ("%x", &value)) break;

       outportb (IOADDRESS, location);
       outportb (IODATA, value);
       }
}




