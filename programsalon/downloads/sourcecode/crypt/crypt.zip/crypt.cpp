
void Krypt::caesar()
{
    char *krypttext;
    krypttext = new char [size];
    char key[33];
    key[0] = 31;
    cout << "\n Write key: ";
    cgets(key);
    cout << endl;
    unsigned long j=2;
    int crypt;
    for(unsigned long i=0; i<size; i++) // the encryption algoritm
    {
        crypt=krypttext[i]+key[j];
        if (crypt>255)
            krypttext[i]=crypt-256;
        else
            krypttext[i]=crypt;
        if(key[j+1]=='\0')
            j=2;
        else
            j++;
    }
    delete[] array;
    array = krypttext;        // put everything back in "array"
}

void Krypt::dekryptera_Caesar()
{
    char *dekrypttext;
    dekrypttext = new char[size];
    char key[33];
    key[0] = 31;
    cout << "\nWrite key: ";
    cgets(key); cout << endl;
    unsigned long j=2;
    int decrypt;
    for(unsigned long i=0; i<size; i++)   // the decryption algoritm
    {
        decrypt=array[i]-key[j];
        if (decrypt<0)
            dekrypttext[i]=decrypt+256;
        else
            dekrypttext[i]=decrypt;
        if(key[j+1]=='\0')
            j=2;
        else
            j++;
    }
    array = dekrypttext;
}


