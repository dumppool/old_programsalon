#include<dos.h>
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

#define CMOS_ADDR   0x70
#define CMOS_DATA   0x71

unsigned char buf[128];

void ReadCMOS(void)
{
   register int i;

   for(i = 0; i < 128; i++)
   {
      outportb(CMOS_ADDR, i);
      buf[i] = inportb(CMOS_DATA);
   } //End for   Read CMOS Data
} //ReadCMOS

void WriteCMOS(void)
{
   register int i;

   for(i = 0; i < 128; i++)
   {
      outportb(CMOS_ADDR, i);
      outportb(CMOS_DATA, buf[i]);
   } //End for   Write CMOS Data
} //WriteCMOS

FILE* OpenFile(char* FileName, char* Mode)
{
   FILE *fp;

   if((fp = fopen(FileName, Mode)) == NULL)
   {
      clrscr();
      gotoxy(20, 15);
      printf("File Open Error!\a\n");
      fclose(fp);
      exit(1);
   } //End if
   return fp;
} //OpenFile

void Success(void)
{
   gotoxy(20, 15);
   printf("OK! Please press a key to continue...\n");
   getch();
} //Success

void SaveCMOS(void)
{
   char* FileName;
   int size;
   FILE* fp;

   gotoxy(20, 22);
   printf("Save As:");
   scanf("%s", FileName);
   fp = OpenFile(FileName, "wb");
   ReadCMOS();
   size = fwrite(buf+10, 118, 1, fp);
   if(size != 1)
   {
      clrscr();
      gotoxy(20, 15);
      printf("Saveing Data Error!\a\n");
      fclose(fp);
      exit(1);
   } //End if
   fprintf(fp, "\n");
   fclose(fp);
   Success();
} //SaveCMOS

void RestallCMOS(void)
{
   char* FileName;
   int size;
   FILE *fp;

   gotoxy(20, 22);
   printf("Open:");
   scanf("%s", FileName);
   fp = OpenFile(FileName, "rb");
   size = fread(buf+10, 118, 1, fp);
   if(size != 1)
   {
      clrscr();
      gotoxy(20, 15);
      printf("Reading Data Error!\a\n");
      fclose(fp);
      exit(1);
   } //End if
   WriteCMOS();
   fclose(fp);
   Success();
} //RestallCMOS

void CheckCMOS(void)
{
   unsigned char buf1[118];
   register int  i;
   char* FileName;
   FILE* fp;

   gotoxy(20, 22);
   printf("Open:");
   scanf("%s", FileName);
   fp = OpenFile(FileName, "rb");
   ReadCMOS();
   fread(buf1, 118, 1, fp);
   for(i = 10; i < 128; i++)
      if(buf1[i-10] != buf[i])
	 break;
   if(i != 128)
   {
      gotoxy(20, 15);
      printf("Data change in CMOS! Please press a key to continue...\a\n");
      getch();
   } // End if
   else
      Success();
} //CheckCMOS

void ClearCMOS(void)
{
   char c;
   int i;

   gotoxy(0, 23);
   printf("The CMOS data will all lost. Are you want to save it?(Y/N)N\a");
   gotoxy(59, 20);
   c = getch();
   if((c != 'n') && (c != 'N'))
   {
      SaveCMOS();
   } //End if
   for (i = 1; i < 128; i++)
      buf[i] = 0;
   WriteCMOS();
   Success();
} //ClearCMOS

void main(void)
{
   int Key = 0;
   while(Key != 5 && Key != 27)
   {
      clrscr();
      gotoxy(20, 3);
      printf("CMOS Wizard Ver 1.0\n\t\tCopyright Gong Minmin,1999\n\n\t\tE-Mail:gongmm@163.net\n\t\t========================\n");
      gotoxy(20, 10);
      printf("1---Save CMOS\n");
      gotoxy(20, 11);
      printf("2---Restall CMOS\n");
      gotoxy(20, 12);
      printf("3---Check CMOS\n");
      gotoxy(20, 13);
      printf("4---Clear CMOS\n");
      gotoxy(20, 14);
      printf("--------------\n");
      gotoxy(20, 15);
      printf("5---Exit\n");
      gotoxy(20, 17);
      printf("Please choose(1--5):");
      gotoxy(40, 17);
      Key = getch() - 48;
      switch(Key)
      {
	 case 1:
	    SaveCMOS();
	    break;

	 case 2:
	    RestallCMOS();
	    break;

	 case 3:
	    CheckCMOS();
	    break;

	 case 4:
	    ClearCMOS();
	    break;

	 case 27:
	    break;
      } //End switch
   }
   clrscr();
} //main
