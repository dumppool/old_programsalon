/*
 * Generated S-box files.
 *
 * Produced by Matthew Kwan - March 1998
 */


static void
s1 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	*out1,
	unsigned long	*out2,
	unsigned long	*out3,
	unsigned long	*out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54, x55, x56;

	x1 = a3 & ~a5;
	x2 = x1 ^ a4;
	x3 = a3 & ~a4;
	x4 = x3 | a5;
	x5 = a6 & x4;
	x6 = x2 ^ x5;
	x7 = a4 & ~a5;
	x8 = a3 ^ a4;
	x9 = a6 & ~x8;
	x10 = x7 ^ x9;
	x11 = a2 | x10;
	x12 = x6 ^ x11;
	x13 = a5 ^ x5;
	x14 = x13 & x8;
	x15 = a5 & ~a4;
	x16 = x3 ^ x14;
	x17 = a6 | x16;
	x18 = x15 ^ x17;
	x19 = a2 | x18;
	x20 = x14 ^ x19;
	x21 = a1 & x20;
	x22 = x12 ^ ~x21;
	*out2 ^= x22;
	x23 = x1 | x5;
	x24 = x23 ^ x8;
	x25 = x18 & ~x2;
	x26 = a2 & ~x25;
	x27 = x24 ^ x26;
	x28 = x6 | x7;
	x29 = x28 ^ x25;
	x30 = x9 ^ x24;
	x31 = x18 & ~x30;
	x32 = a2 & x31;
	x33 = x29 ^ x32;
	x34 = a1 & x33;
	x35 = x27 ^ x34;
	*out4 ^= x35;
	x36 = a3 & x28;
	x37 = x18 & ~x36;
	x38 = a2 | x3;
	x39 = x37 ^ x38;
	x40 = a3 | x31;
	x41 = x24 & ~x37;
	x42 = x41 | x3;
	x43 = x42 & ~a2;
	x44 = x40 ^ x43;
	x45 = a1 & ~x44;
	x46 = x39 ^ ~x45;
	*out1 ^= x46;
	x47 = x33 & ~x9;
	x48 = x47 ^ x39;
	x49 = x4 ^ x36;
	x50 = x49 & ~x5;
	x51 = x42 | x18;
	x52 = x51 ^ a5;
	x53 = a2 & ~x52;
	x54 = x50 ^ x53;
	x55 = a1 | x54;
	x56 = x48 ^ ~x55;
	*out3 ^= x56;
}


static void
s2 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	*out1,
	unsigned long	*out2,
	unsigned long	*out3,
	unsigned long	*out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50;

	x1 = a1 ^ a6;
	x2 = x1 ^ a5;
	x3 = a6 & a5;
	x4 = a1 & ~x3;
	x5 = a2 & ~x4;
	x6 = x2 ^ x5;
	x7 = x3 | x5;
	x8 = x7 & ~x1;
	x9 = a3 | x8;
	x10 = x6 ^ x9;
	x11 = a5 & ~x4;
	x12 = x11 | a2;
	x13 = a4 & x12;
	x14 = x10 ^ ~x13;
	*out1 ^= x14;
	x15 = x4 ^ x14;
	x16 = x15 & ~a2;
	x17 = x2 ^ x16;
	x18 = a6 & ~x4;
	x19 = x6 ^ x11;
	x20 = a2 & x19;
	x21 = x18 ^ x20;
	x22 = a3 & x21;
	x23 = x17 ^ x22;
	x24 = a5 ^ a2;
	x25 = x24 & ~x8;
	x26 = x6 | a1;
	x27 = x26 ^ a2;
	x28 = a3 & ~x27;
	x29 = x25 ^ x28;
	x30 = a4 | x29;
	x31 = x23 ^ x30;
	*out3 ^= x31;
	x32 = x18 | x25;
	x33 = x32 ^ x10;
	x34 = x27 | x20;
	x35 = a3 & x34;
	x36 = x33 ^ x35;
	x37 = x24 & x34;
	x38 = x12 & ~x37;
	x39 = a4 | x38;
	x40 = x36 ^ ~x39;
	*out4 ^= x40;
	x41 = a2 ^ x2;
	x42 = x41 & ~x33;
	x43 = x42 ^ x29;
	x44 = a3 & ~x43;
	x45 = x41 ^ x44;
	x46 = x3 | x20;
	x47 = a3 & x3;
	x48 = x46 ^ x47;
	x49 = a4 & ~x48;
	x50 = x45 ^ ~x49;
	*out2 ^= x50;
}


static void
s3 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	*out1,
	unsigned long	*out2,
	unsigned long	*out3,
	unsigned long	*out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54, x55;

	x1 = a6 ^ a2;
	x2 = a5 & ~a3;
	x3 = x1 ^ x2;
	x4 = a4 | a5;
	x5 = x3 ^ x4;
	x6 = a3 ^ a6;
	x7 = a2 & ~x6;
	x8 = a3 ^ x7;
	x9 = a5 & x8;
	x10 = x8 ^ x9;
	x11 = a6 & ~x7;
	x12 = x11 ^ a5;
	x13 = x12 & ~a4;
	x14 = x10 ^ x13;
	x15 = a1 & ~x14;
	x16 = x5 ^ x15;
	*out4 ^= x16;
	x17 = a3 ^ x5;
	x18 = a6 & ~x3;
	x19 = a6 & ~a5;
	x20 = x18 ^ x19;
	x21 = a4 & ~x20;
	x22 = x17 ^ x21;
	x23 = x10 & ~a3;
	x24 = x7 ^ x18;
	x25 = a4 & x24;
	x26 = x23 ^ x25;
	x27 = a1 | x26;
	x28 = x22 ^ x27;
	*out2 ^= x28;
	x29 = x1 ^ x24;
	x30 = x6 & ~x29;
	x31 = a5 & ~x30;
	x32 = x29 ^ x31;
	x33 = x32 ^ a4;
	x34 = x8 ^ x20;
	x35 = a6 | a2;
	x36 = a5 & ~x35;
	x37 = x34 ^ x36;
	x38 = a4 & ~x37;
	x39 = x34 ^ x38;
	x40 = x39 & ~a1;
	x41 = x33 ^ ~x40;
	*out1 ^= x41;
	x42 = x35 & ~x6;
	x43 = x42 ^ a5;
	x44 = a5 | x22;
	x45 = a2 ^ x44;
	x46 = a4 & x45;
	x47 = x43 ^ x46;
	x48 = x37 & ~a6;
	x49 = x46 & ~a5;
	x50 = x48 ^ x49;
	x51 = x3 ^ x30;
	x52 = a4 | x51;
	x53 = x50 ^ x52;
	x54 = a1 | x53;
	x55 = x47 ^ ~x54;
	*out3 ^= x55;
}


static void
s4 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	*out1,
	unsigned long	*out2,
	unsigned long	*out3,
	unsigned long	*out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39;

	x1 = a1 | a3;
	x2 = a5 & x1;
	x3 = a1 ^ x2;
	x4 = a2 | a3;
	x5 = x3 ^ x4;
	x6 = a3 & ~a1;
	x7 = x6 | x3;
	x8 = a2 & x7;
	x9 = a5 ^ x8;
	x10 = a4 & x9;
	x11 = x5 ^ x10;
	x12 = a3 ^ x2;
	x13 = a2 & ~x12;
	x14 = x7 ^ x13;
	x15 = x12 | x3;
	x16 = a3 ^ a5;
	x17 = x16 & ~a2;
	x18 = x15 ^ x17;
	x19 = a4 | x18;
	x20 = x14 ^ x19;
	x21 = a6 | x20;
	x22 = x11 ^ x21;
	*out1 ^= x22;
	x23 = a6 & x20;
	x24 = x23 ^ ~x11;
	*out2 ^= x24;
	x25 = a2 & x9;
	x26 = x25 ^ x15;
	x27 = a3 ^ x8;
	x28 = x27 ^ x17;
	x29 = a4 & ~x28;
	x30 = x26 ^ x29;
	x31 = x11 ^ x30;
	x32 = a2 & ~x31;
	x33 = x22 ^ x32;
	x34 = x31 & ~a4;
	x35 = x33 ^ x34;
	x36 = a6 | x35;
	x37 = x30 ^ ~x36;
	*out3 ^= x37;
	x38 = x23 ^ x35;
	x39 = x38 ^ x37;
	*out4 ^= x39;
}


static void
s5 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	*out1,
	unsigned long	*out2,
	unsigned long	*out3,
	unsigned long	*out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54, x55, x56;
	unsigned long	x57, x58;

	x1 = a4 & a1;
	x2 = ~(x1 ^ a3);
	x3 = a3 & a4;
	x4 = ~(a1 | x3);
	x5 = a3 ^ x4;
	x6 = a5 & x5;
	x7 = x2 ^ x6;
	x8 = x5 & ~a4;
	x9 = a2 | x8;
	x10 = x7 ^ x9;
	x11 = a5 ^ x7;
	x12 = ~(x11 | a4);
	x13 = a3 | a1;
	x14 = x13 & ~a4;
	x15 = a2 & x14;
	x16 = x12 ^ x15;
	x17 = a6 | x16;
	x18 = x10 ^ x17;
	*out2 ^= x18;
	x19 = a4 ^ x13;
	x20 = a5 & a3;
	x21 = x19 ^ x20;
	x22 = x2 ^ x19;
	x23 = ~(x22 | a5);
	x24 = a2 | x23;
	x25 = x21 ^ x24;
	x26 = x4 & ~x18;
	x27 = x26 ^ x1;
	x28 = x4 ^ x14;
	x29 = x28 & x18;
	x30 = a2 & x29;
	x31 = x27 ^ x30;
	x32 = a6 | x31;
	x33 = x25 ^ x32;
	*out3 ^= x33;
	x34 = a3 & ~x7;
	x35 = a5 | x33;
	x36 = x34 ^ x35;
	x37 = a5 ^ x10;
	x38 = ~(a2 | x37);
	x39 = x36 ^ x38;
	x40 = a5 & ~x21;
	x41 = x40 ^ a4;
	x42 = x11 ^ x27;
	x43 = a2 & x42;
	x44 = x41 ^ x43;
	x45 = a6 & x44;
	x46 = x39 ^ x45;
	*out4 ^= x46;
	x47 = a4 & ~x42;
	x48 = x47 ^ x34;
	x49 = x21 & x46;
	x50 = ~(x49 ^ x3);
	x51 = a2 & x50;
	x52 = x48 ^ x51;
	x53 = x50 & ~x6;
	x54 = x12 & ~a1;
	x55 = ~(a2 & x54);
	x56 = x53 ^ x55;
	x57 = a6 | x56;
	x58 = x52 ^ x57;
	*out1 ^= x58;
}


static void
s6 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	*out1,
	unsigned long	*out2,
	unsigned long	*out3,
	unsigned long	*out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51, x52, x53, x54;

	x1 = a2 ^ a5;
	x2 = ~(x1 ^ a1);
	x3 = x2 ^ a6;
	x4 = a5 & a1;
	x5 = ~(x4 | a2);
	x6 = a5 & x2;
	x7 = a6 & x6;
	x8 = x5 ^ x7;
	x9 = a4 & x8;
	x10 = x3 ^ x9;
	x11 = a6 ^ x8;
	x12 = x11 & a1;
	x13 = ~(a5 ^ x4);
	x14 = a6 & x12;
	x15 = x13 ^ x14;
	x16 = a4 | x15;
	x17 = x12 ^ x16;
	x18 = a3 & x17;
	x19 = x10 ^ x18;
	*out2 ^= x19;
	x20 = a2 ^ x3;
	x21 = x12 | ~x20;
	x22 = a1 ^ x5;
	x23 = x22 | ~a6;
	x24 = a4 & x23;
	x25 = x21 ^ x24;
	x26 = x23 & ~x4;
	x27 = ~(x26 ^ x2);
	x28 = ~(x1 ^ x12);
	x29 = a6 & x28;
	x30 = a5 ^ x29;
	x31 = a4 | x30;
	x32 = x27 ^ x31;
	x33 = a3 | x32;
	x34 = x25 ^ x33;
	*out1 ^= x34;
	x35 = x26 & ~x3;
	x36 = ~(x35 ^ x28);
	x37 = x3 & ~x15;
	x38 = a4 & ~x37;
	x39 = x36 ^ x38;
	x40 = ~(x13 & x28);
	x41 = a3 & x40;
	x42 = x39 ^ x41;
	*out3 ^= x42;
	x43 = a1 & ~x20;
	x44 = ~(x43 ^ x15);
	x45 = x11 & ~a2;
	x46 = x40 & ~x45;
	x47 = a4 & x46;
	x48 = x44 ^ x47;
	x49 = x1 ^ x15;
	x50 = x27 & ~a6;
	x51 = a4 & x50;
	x52 = x49 ^ x51;
	x53 = a3 & x52;
	x54 = x48 ^ x53;
	*out4 ^= x54;
}


static void
s7 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	*out1,
	unsigned long	*out2,
	unsigned long	*out3,
	unsigned long	*out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51;

	x1 = a2 & a4;
	x2 = x1 ^ a5;
	x3 = a4 & x2;
	x4 = ~(x3 ^ a2);
	x5 = a3 & x4;
	x6 = x2 ^ x5;
	x7 = ~(a3 ^ x5);
	x8 = a6 & x7;
	x9 = x6 ^ x8;
	x10 = a2 | a4;
	x11 = x10 | a5;
	x12 = a5 & ~a2;
	x13 = a3 | x12;
	x14 = x11 ^ x13;
	x15 = x3 ^ x6;
	x16 = a6 | x15;
	x17 = x14 ^ x16;
	x18 = a1 & x17;
	x19 = x9 ^ x18;
	*out1 ^= x19;
	x20 = a4 & ~a3;
	x21 = a2 & ~x20;
	x22 = ~(a6 & x21);
	x23 = x9 ^ x22;
	x24 = ~(a4 ^ x4);
	x25 = a3 | x3;
	x26 = x24 ^ x25;
	x27 = a3 ^ x3;
	x28 = ~(x27 & a2);
	x29 = a6 & x28;
	x30 = x26 ^ x29;
	x31 = a1 | x30;
	x32 = x23 ^ x31;
	*out2 ^= x32;
	x33 = ~(x7 ^ x30);
	x34 = a2 | x24;
	x35 = ~(x34 ^ x19);
	x36 = a6 | x35;
	x37 = x33 ^ x36;
	x38 = x26 & ~a3;
	x39 = ~(x38 | x30);
	x40 = a1 | x39;
	x41 = x37 ^ x40;
	*out3 ^= x41;
	x42 = a5 | x20;
	x43 = x42 ^ x33;
	x44 = a2 ^ x15;
	x45 = x24 & ~x44;
	x46 = a6 & x45;
	x47 = x43 ^ x46;
	x48 = a3 & ~x22;
	x49 = x48 ^ x46;
	x50 = a1 | x49;
	x51 = x47 ^ x50;
	*out4 ^= x51;
}


static void
s8 (
	unsigned long	a1,
	unsigned long	a2,
	unsigned long	a3,
	unsigned long	a4,
	unsigned long	a5,
	unsigned long	a6,
	unsigned long	*out1,
	unsigned long	*out2,
	unsigned long	*out3,
	unsigned long	*out4
) {
	unsigned long	x1, x2, x3, x4, x5, x6, x7, x8;
	unsigned long	x9, x10, x11, x12, x13, x14, x15, x16;
	unsigned long	x17, x18, x19, x20, x21, x22, x23, x24;
	unsigned long	x25, x26, x27, x28, x29, x30, x31, x32;
	unsigned long	x33, x34, x35, x36, x37, x38, x39, x40;
	unsigned long	x41, x42, x43, x44, x45, x46, x47, x48;
	unsigned long	x49, x50, x51;

	x1 = ~(a3 ^ a1);
	x2 = a1 & ~a3;
	x3 = x2 ^ a4;
	x4 = a5 | x3;
	x5 = x1 ^ x4;
	x6 = a1 | x5;
	x7 = x6 ^ a3;
	x8 = a5 | x7;
	x9 = a4 ^ x8;
	x10 = a2 & x9;
	x11 = x5 ^ x10;
	x12 = x6 & ~a4;
	x13 = x12 ^ x1;
	x14 = x13 ^ a5;
	x15 = x3 & ~x14;
	x16 = x15 ^ x7;
	x17 = a2 & x16;
	x18 = x14 ^ x17;
	x19 = a6 | x18;
	x20 = x11 ^ x19;
	*out1 ^= x20;
	x21 = a3 & x16;
	x22 = x9 & ~x21;
	x23 = a2 | ~x6;
	x24 = x22 ^ x23;
	x25 = x2 & ~x14;
	x26 = a3 & a4;
	x27 = x26 & a1;
	x28 = a2 & x27;
	x29 = x25 ^ x28;
	x30 = a6 | x29;
	x31 = x24 ^ x30;
	*out2 ^= x31;
	x32 = x5 & ~a5;
	x33 = x32 ^ x3;
	x34 = a4 | x11;
	x35 = a2 & x34;
	x36 = x33 ^ x35;
	x37 = a1 & ~x32;
	x38 = a5 & x2;
	x39 = ~(x38 ^ x34);
	x40 = ~(a2 & x39);
	x41 = x37 ^ x40;
	x42 = a6 | x41;
	x43 = x36 ^ x42;
	*out3 ^= x43;
	x44 = a5 | x1;
	x45 = x44 & ~a4;
	x46 = a3 ^ a5;
	x47 = ~(x46 ^ x25);
	x48 = a2 | x47;
	x49 = x45 ^ x48;
	x50 = a6 & x49;
	x51 = x11 ^ x50;
	*out4 ^= x51;
}
