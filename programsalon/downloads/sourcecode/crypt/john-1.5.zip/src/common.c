/*
 * This file is part of John the Ripper password cracker,
 * Copyright (c) 1996-98 by Solar Designer
 */

#include <string.h>

#include "arch.h"

char itoa64[64] =
	"./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

/* signed */ char atoi64[0x100];

static int initialized = 0;

void common_init()
{
	char *pos;

	if (initialized) return;

	memset(atoi64, -1, sizeof(atoi64));
	for (pos = itoa64; pos <= &itoa64[63]; pos++)
		atoi64[(ARCH_INDEX)*pos] = pos - itoa64;

	initialized = 1;
}
