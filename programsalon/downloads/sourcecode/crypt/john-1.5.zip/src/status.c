/*
 * This file is part of John the Ripper password cracker,
 * Copyright (c) 1996-98 by Solar Designer
 */

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/times.h>

#include "times.h"

#include "arch.h"
#include "misc.h"
#include "math.h"
#include "params.h"
#include "cracker.h"
#include "status.h"

struct status_main status;
unsigned int status_restored_time = 0;

static int (*status_get_progress)();

static clock_t get_time()
{
	struct tms buf;

	return times(&buf);
}

void status_init(int (*get_progress)())
{
	if (!status_restored_time)
		memset(&status, 0, sizeof(status));
	status.start_time = get_time() - status_restored_time * CLK_TCK;

	status_get_progress = get_progress;
}

void status_update_crypts(unsigned int count)
{
	add32to64(&status.crypts, count);
}

unsigned int status_get_time()
{
	return (get_time() - status.start_time) / CLK_TCK;
}

static char *status_get_cps(char *buffer)
{
	unsigned int time, cps_hi, cps_lo;
	int64 tmp;

	if (!(time = status_get_time())) time = 1;

	cps_hi = div64by32lo(&status.crypts, time);

	tmp = status.crypts;
	mul64by32(&tmp, 100);
	cps_lo = div64by32lo(&tmp, time) % 100;

	sprintf(buffer, cps_hi < 100 ? "%u.%02u" : "%u", cps_hi, cps_lo);

	return buffer;
}

void status_print()
{
	unsigned int time = status_get_time();
	char *key, saved_key[PLAINTEXT_BUFFER_SIZE];
	int percent_value;
	char s_percent[8];
	char s_cps[64];

	s_percent[0] = 0;
	if (status_get_progress)
	if ((percent_value = status_get_progress()) >= 0)
		sprintf(s_percent, " %d%%", percent_value);

	if ((key = crk_get_key2()))
		strnzcpy(saved_key, crk_get_key2(), PLAINTEXT_BUFFER_SIZE);
	else
		saved_key[0] = 0;

	printf(
		"guesses: %u  "
		"time: %u:%02u:%02u:%02u"
		"%s  "
		"c/s: %s  "
		"trying: %s%s%s\n",
		status.guess_count,
		time / 86400, time % 86400 / 3600, time % 3600 / 60, time % 60,
		s_percent,
		status_get_cps(s_cps),
		crk_get_key1(),
		saved_key[0] ? " - " : "",
		saved_key ? saved_key : "");
}
