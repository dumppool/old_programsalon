/*
 * This file is part of John the Ripper password cracker,
 * Copyright (c) 1996-98 by Solar Designer
 */

#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <sys/times.h>

#include "times.h"

#include "arch.h"
#include "misc.h"
#include "params.h"
#include "signals.h"
#include "formats.h"
#include "bench.h"

static int bench_running;

static void bench_handle_timer(int signum)
{
	bench_running = 0;
}

static void bench_set_keys(struct fmt_main *format)
{
	struct fmt_tests *current;
	int index;

	current = format->params.tests;
	for (index = 0; index < format->params.max_keys_per_crypt; index++) {
		if (!current->ciphertext) current = format->params.tests;
		format->methods.set_key(current->plaintext, index);
		current++;
	}
}

int benchmark_format(struct fmt_main *format, int salts,
	struct bench_results *results)
{
#if OS_TIMER
	struct itimerval it;
#endif
	struct tms buf;
	clock_t start_real, start_virtual, end_real, end_virtual;
	unsigned ARCH_WORD count;
	void *salt;
	int index;

	if (!format->params.tests) return 1;
	if (fmt_self_test(format)) return 1;

	salt = format->methods.salt(format->params.tests[0].ciphertext);
	bench_set_keys(format);

#if OS_TIMER
	memset(&it, 0, sizeof(it));
	if (setitimer(ITIMER_REAL, &it, NULL)) pexit("setitimer");
#endif

	bench_running = 1;
	signal(SIGALRM, bench_handle_timer);

#if OS_TIMER
	it.it_value.tv_sec = BENCHMARK_TIME;
	if (setitimer(ITIMER_REAL, &it, NULL)) pexit("setitimer");
#else
	sig_timer_emu_init(BENCHMARK_TIME * CLK_TCK);
#endif

	start_real = times(&buf);
	start_virtual = buf.tms_utime + buf.tms_stime;
	count = 0;

	index = salts;
	do {
		if (!--index) {
			index = salts;
			bench_set_keys(format);
		}

		if (salts > 1) format->methods.set_salt(salt);
		format->methods.crypt_all(format->params.max_keys_per_crypt);

		count++;
#if !OS_TIMER
		sig_timer_emu_tick();
#endif
	} while (bench_running && !event_abort);

	end_real = times(&buf);
	end_virtual = buf.tms_utime + buf.tms_stime;
	if (end_virtual == start_virtual) end_virtual++;

	results->real = end_real - start_real;
	results->virtual = end_virtual - start_virtual;
	results->count = count * format->params.max_keys_per_crypt;

	if (event_abort) return -1; else return 0;
}

void benchmark_cps(unsigned ARCH_WORD count, clock_t time, char *buffer)
{
	unsigned long cps_hi, cps_lo;

	cps_hi = count * CLK_TCK / time;
	cps_lo = count * ((unsigned ARCH_WORD)CLK_TCK * 10) / time % 10;

	sprintf(buffer, cps_hi < 100 ? "%lu.%lu" : "%lu", cps_hi, cps_lo);
}

void benchmark_all()
{
	struct fmt_main *format;
	struct bench_results results_1, results_m;
	char s_real[64], s_virtual[64];
	int result;

	if ((format = fmt_list))
	do {
		printf("Benchmarking: %s%s [%s]... ",
			format->params.format_name,
			format->params.benchmark_comment,
			format->params.algorithm_name);
		fflush(stdout);

		if ((result = benchmark_format(format, BENCHMARK_MANY,
		    &results_m))) {
			if (result > 0) puts("FAILED"); else putchar('\n');
			continue;
		}

		if ((result = benchmark_format(format, 1, &results_1))) {
			if (result > 0) puts("FAILED"); else putchar('\n');
			continue;
		}

		puts("DONE");

		benchmark_cps(results_m.count, results_m.real, s_real);
		benchmark_cps(results_m.count, results_m.virtual, s_virtual);
		printf("Many salts:\t%s c/s"
#ifndef __DJGPP__
			" real, %s c/s virtual\n",
			s_real, s_virtual);
#else
			"\n",
			s_real);
#endif

		benchmark_cps(results_1.count, results_1.real, s_real);
		benchmark_cps(results_1.count, results_1.virtual, s_virtual);
		printf("Only one salt:\t%s c/s"
#ifndef __DJGPP__
			" real, %s c/s virtual\n\n",
			s_real, s_virtual);
#else
			"\n\n",
			s_real);
#endif
	} while ((format = format->next) && !event_abort);
}
