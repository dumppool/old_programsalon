/*
 * This file is part of John the Ripper password cracker,
 * Copyright (c) 1996-98 by Solar Designer
 */

/*
 * Things common to many ciphertext formats.
 */

#ifndef _JOHN_COMMON_H
#define _JOHN_COMMON_H

/*
 * ASCII <-> binary conversion tables.
 */
extern char itoa64[64];
extern /* signed */ char atoi64[0x100];

/*
 * Initializes the tables.
 */
extern void common_init();

#endif
