int CALLBACK InstKillTimer (BOOL fInstall ,HTASK hTask);
int CALLBACK InstKillTimerMsg (BOOL fInstall ,HTASK hTask);
