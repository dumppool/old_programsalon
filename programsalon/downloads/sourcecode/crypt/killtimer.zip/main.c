#include <windows.h>
#include <string.h>

HINSTANCE hInstance;

BOOL WINAPI _CRT_INIT (HINSTANCE hDLL, DWORD dwReason, LPVOID lpReserved);

BOOL WINAPI DllMain(HANDLE hModule, DWORD, LPVOID);
int   CALLBACK InstallCbtFilter (BOOL fInstall ,HTASK hTask);
LRESULT  CALLBACK CbtFunc (int nCode, WPARAM wParam, LPARAM lParam );

LRESULT CALLBACK KillTimerProc(HWND hWnd, UINT nMsg, 
                           WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK KTMsgProc(INT hc, WPARAM wParam, LPARAM lParam);

BOOL HookInstalled = 0 ; // State Table of my hooks

HHOOK hhookCbt =NULL, hhookMsg =NULL;
static HWND ghWndXSession =NULL;
static WNDPROC lpfnOldWndProc = NULL;     

//---------------------------------------------------------------------------
// DllMain
//---------------------------------------------------------------------------
BOOL APIENTRY DllMain(HANDLE hModule, DWORD dwReason, LPVOID lpReserved)
{
    hInstance = hModule;
    switch(dwReason)
	{
	case DLL_PROCESS_ATTACH:
		break;
	case DLL_PROCESS_DETACH:
		break;
    default:
      break;
	}

	return TRUE;
}

//---------------------------------------------------------------------------
int CALLBACK InstKillTimer(BOOL fInstall ,HTASK hTask)
{
  if ( fInstall ) 
  {
    if(HookInstalled) return FALSE;
    hhookCbt = SetWindowsHookEx(WH_CBT, CbtFunc, 
				  hInstance, 0);
    HookInstalled = TRUE;
  }
  else 
  {
    if(!HookInstalled) return FALSE;
    UnhookWindowsHookEx(hhookCbt);    
    HookInstalled = FALSE;
  }                              
  return TRUE;
}

int CALLBACK InstKillTimerMsg(BOOL fInstall ,HTASK hTask)
{
  if ( fInstall ) 
  {
    if(HookInstalled) return FALSE;
    hhookMsg = SetWindowsHookEx(WH_GETMESSAGE, KTMsgProc, 
				  hInstance, 0);
    HookInstalled = TRUE;
  }
  else 
  {
    if(!HookInstalled) return FALSE;
    UnhookWindowsHookEx(hhookMsg);    
    HookInstalled = FALSE;
  }                              
  return TRUE;
}

//---------------------------------------------------------------------------
// CbtFunc
//
// Filter function for the WH_CBT
//
//---------------------------------------------------------------------------
LRESULT CALLBACK CbtFunc (int nCode, WPARAM wParam, LPARAM lParam )
{
   static HWND hWndHookParentDlg = NULL;
   LPCREATESTRUCT lpcs;
   
  if(nCode == HCBT_CREATEWND)
  {
    lpcs = ((LPCBT_CREATEWND)lParam)->lpcs;
    if (!strcmp(lpcs->lpszClass, "XWPxserver"))
    {
      hWndHookParentDlg = (HWND)wParam;       // hook it
    }
    else if (hWndHookParentDlg != NULL)
    {
      if ((WNDPROC)GetWindowLong(hWndHookParentDlg,
		    GWL_WNDPROC) == lpfnOldWndProc)
      {
	(WNDPROC)SetWindowLong(hWndHookParentDlg,
		GWL_WNDPROC, (DWORD)KillTimerProc);
      }
      hWndHookParentDlg = NULL;
    }
  }               
  return(CallNextHookEx(hhookCbt, nCode,wParam,lParam));
}

LRESULT CALLBACK KillTimerProc(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{                                      
    if(nMsg ==WM_TIMER) return 0L;

	return CallWindowProc((FARPROC)lpfnOldWndProc, hWnd, nMsg, wParam, lParam);
}

LRESULT CALLBACK KTMsgProc(INT hc, WPARAM wParam, LPARAM lParam)
{
	PMSG pmsg;

	pmsg = (PMSG)lParam;

	if (hc >= 0 && pmsg && pmsg->hwnd)
	{
		if(pmsg->message ==WM_TIMER &&ghWndXSession ==NULL)
		{
			ghWndXSession =FindWindow(NULL, "X-Session");
			if(ghWndXSession && pmsg->hwnd ==ghWndXSession)
				return 0;
		}
	}

	return CallNextHookEx(NULL, hc, wParam, lParam);
}
