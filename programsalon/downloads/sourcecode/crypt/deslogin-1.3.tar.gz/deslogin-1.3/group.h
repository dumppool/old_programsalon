#ifndef _GROUP_H
#define _GROUP_H
#endif
#if defined(__STDC__) || defined(__cplusplus)
int getLoginGroups(int gidsetsize, gid_t grouplist[], char *name);
int setGroups(int, gid_t *);

#ifdef __cplusplus
extern "C" {
#endif

struct group *getgrent(void);	/* put here because POSIX doesn't have it */

#ifdef __cplusplus
}
#endif

#else

int getLoginGroups();
int setGroups();
extern struct group *getgrent();
#endif
