#define PTY_NAMESIZE	16

#if defined(__STDC__) || defined(__cplusplus)
extern int openSlavePty(char *slaveName, int mode);
extern int openPty(int mode, char *slaveName, char *masterName, 
   unsigned size, int *slaveFd);
#else
extern int openSlavePty();
extern int openPty();
#endif
