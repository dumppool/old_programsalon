#ifndef _TXFR_H
#define _TXFR_H
#if defined(__STDC__) || defined(__cplusplus)
extern int txfr(int fd1, int fdin, int fdout, unsigned bufsize, unsigned timeout, 
   keyType key);
extern int getString(int fd, char *buf, unsigned size, unsigned timeout);
extern int getBlock(int fd, char *buf, unsigned size, unsigned timeout);
extern int cipherCopy(int dstfd, int srcfd, unsigned timeoutSec, keyType key);
extern int waitReady(int fd, char *buf, unsigned size, unsigned timeout);
extern int mkReady(int fd, char *buf, unsigned size, unsigned timeout);
#else
extern int txfr();
extern int getString();
extern int getBlock();
extern int cipherCopy();
extern int waitReady();
extern int mkReady();
#endif
#endif
