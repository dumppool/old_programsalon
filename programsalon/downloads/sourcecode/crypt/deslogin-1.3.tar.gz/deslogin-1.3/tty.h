#ifndef _TTY_H
#define _TTY_H

#if defined(__STDC__) || defined(__cplusplus)
int isTty(int fd);
int openCtty(void);
int restoreTty(int ttyfd, struct termios *oldmodes);
int setTtyBin(int ttyfd, struct termios *oldmodes);
int setTtyAscii(int ctty);
int setTtyEcho(int ttyfd, int echo);
int mkCtrlTty(int ttyfd, int flag);
int askTty(char *, char *, unsigned, int);
#else
int isTty();
int openCtty();
int restoreTty();
int setTtyBin();
int setTtyAscii();
int setTtyEcho();
int mkCtrlTty();
int askTty();
#endif

#endif
