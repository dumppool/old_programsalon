#ifndef _SOCKET_H
#define SOCKET_H
#if defined(__STDC__) || defined(__cplusplus)
extern int openClient(char *hostName, int port);
extern int openServer(int port, char *hostName, unsigned size, unsigned *rport,
		      int serverflag);
extern int getRemoteAddr(int sock, 
				char *hostName, unsigned size, unsigned *port);
extern int getLocalAddr(int sock, 
		        	char *hostName, unsigned size, unsigned *port);
extern int getServicePort(char *name);
extern int socktype(int fd);
#else
extern int openServer();
extern int openClient();
extern int getRemoteAddr();
extern int getLocalAddr();
extern int getServerPort();
extern int socktype();
#endif

#define	issocket(fd)	socktype(fd)
#endif
