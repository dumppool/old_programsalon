#ifndef _LOG_H
#define _LOG_H

#if !defined(ERRMSG) /* { */
#if (!defined(sparc) && !defined(sun3)) || defined(__SOLARIS__)	/* { ANSI */
#define	ERRMSG	strerror(errno)	
#else  /* } { strerror missing on SunOS 4.1.3_U1 */
#define ERRMSG	sys_errlist[errno] 

extern char 	*sys_errlist[];
#endif /* } */
#endif /* } */

#if defined(__STDC__) || defined(__cplusplus)
extern void log(char *, ...);
extern int openLog(char *fname);
extern void closeLog(void);
#else
extern void log();
extern int openLog();
extern void closeLog();
#endif
#endif
