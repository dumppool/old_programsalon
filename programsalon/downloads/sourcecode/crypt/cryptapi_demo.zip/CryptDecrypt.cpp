// CryptDecrypt.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#define _WIN32_WINNT 0x0400
#include <windows.h>
#include <tchar.h>
#include <stdio.h>

BOOL SetupCryptoClient()
{
	// Ensure that the default cryptographic client is set up.	
	HCRYPTPROV hProv;
	HCRYPTKEY hKey;		
	// Attempt to acquire a handle to the default key container.
	if (!CryptAcquireContext(&hProv, NULL, MS_DEF_PROV, PROV_RSA_FULL, 0))	
	{
		// Some sort of error occured, create default key container.
		if (!CryptAcquireContext(&hProv, NULL, MS_DEF_PROV, PROV_RSA_FULL, CRYPT_NEWKEYSET))
		{	
			// Error creating key container!			
			return FALSE;		
		}	
	}
	// Attempt to get handle to signature key.
	if (!CryptGetUserKey(hProv, AT_SIGNATURE, &hKey))	
	{
		if (GetLastError() == NTE_NO_KEY)		
		{			
			// Create signature key pair.
			if (!CryptGenKey(hProv, AT_SIGNATURE, 0, &hKey))			
			{
				// Error during CryptGenKey!				
				CryptReleaseContext(hProv, 0);
				return FALSE;			
			}			
			else			
			{				
				CryptDestroyKey(hKey);			
			}		
		}		
		else 		
		{
			// Error during CryptGetUserKey!			
			CryptReleaseContext(hProv, 0);
			return FALSE;		
		}	
	}	
	
	// Attempt to get handle to exchange key.
	if (!CryptGetUserKey(hProv,AT_KEYEXCHANGE,&hKey))	
	{
		if (GetLastError()==NTE_NO_KEY)		
		{			
			// Create key exchange key pair.
			if (!CryptGenKey(hProv,AT_KEYEXCHANGE,0,&hKey))			
			{
				// Error during CryptGenKey!				
				CryptReleaseContext(hProv, 0);
				return FALSE;			
			}			
			else			
			{				
				CryptDestroyKey(hKey);			
			}		
		}		
		else		
		{
			// Error during CryptGetUserKey!			
			CryptReleaseContext(hProv, 0);
			return FALSE;		
		}	
	}	

	CryptReleaseContext(hProv, 0);	
	return TRUE;
}


BOOL SavePasswordToRegistry(TCHAR* szPassword)
{	
	BOOL bResult = TRUE;	
	TCHAR szKey[256];	
	HKEY hRegKey = NULL;
	_tcscpy(szKey, _T("SOFTWARE\\Your Company\\Your Program\\"));	
	if (RegCreateKey(HKEY_CURRENT_USER, szKey, &hRegKey) != ERROR_SUCCESS) 
		return FALSE;				
	
	HCRYPTPROV hProv = NULL;	
	HCRYPTKEY hKey = NULL;
	HCRYPTKEY hXchgKey = NULL;	
	HCRYPTHASH hHash = NULL;	
	DWORD dwLength;
	// Used to encrypt the real password	
	TCHAR szLocalPassword[] = _T("Mz6@a0i*");
	// Get handle to user default provider.
	if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, 0))	
	{
		// Create hash object.		
		if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash))		
		{
			// Hash password string.			
			dwLength = sizeof(TCHAR)*_tcslen(szLocalPassword);
			if (CryptHashData(hHash, (BYTE *)szLocalPassword, dwLength, 0))			
			{
				// Create block cipher session key based on hash of the password.
				if (CryptDeriveKey(hProv, CALG_RC4, hHash, CRYPT_EXPORTABLE, &hKey))				
				{
					// Determine number of bytes to encrypt at a time.
					dwLength = sizeof(TCHAR)*_tcslen(szPassword);					
					// Allocate memory.
					BYTE *pbBuffer = (BYTE *)malloc(dwLength);					
					if (pbBuffer != NULL)					
					{
						memcpy(pbBuffer, szPassword, dwLength);						
						// Encrypt data
						if (CryptEncrypt(hKey, 0, TRUE, 0, pbBuffer, &dwLength, dwLength)) 						
						{
							// Write data to registry.							
							DWORD dwType = REG_BINARY;
							// Add the password.
							if (::RegSetValueEx(hRegKey, _T("Password"), 0, REG_BINARY, pbBuffer, dwLength)!=ERROR_SUCCESS)
							{								
								bResult = FALSE;							
							}							
							::RegCloseKey(hRegKey);
						}	
						else						
						{							
							bResult = FALSE;						
						}						
						// Free memory.
					  free(pbBuffer);					
					}
					else					
					{						
						bResult = FALSE;					
					}
					CryptDestroyKey(hKey);  // Release provider handle.				
				}				
				else				
				{
					// Error during CryptDeriveKey!					
					bResult = FALSE;				
				}			
			}			
			else			
			{
				// Error during CryptHashData!				
				bResult = FALSE;			
			}
			CryptDestroyHash(hHash); 
			// Destroy session key.		
		}		
		else		
		{
			// Error during CryptCreateHash!			
			bResult = FALSE;		
		}
		CryptReleaseContext(hProv, 0);	
	}	
	return bResult;
}


BOOL ReadPasswordFromRegistry(TCHAR* szPassword) 
{	
	BOOL bResult = TRUE;	
	TCHAR szKey[256];	
	HKEY hRegKey = NULL;
	_tcscpy(szKey, _T("SOFTWARE\\Your Company\\Your Program\\"));	
	if (RegOpenKeyEx(HKEY_CURRENT_USER, szKey, 0, KEY_QUERY_VALUE, &hRegKey) == ERROR_SUCCESS) 
	{		
		HCRYPTPROV hProv = NULL;		
		HCRYPTKEY hKey = NULL;		
		HCRYPTKEY hXchgKey = NULL;
		HCRYPTHASH hHash = NULL;		
		DWORD dwLength;
		// has to be the same used to encrypt!
		TCHAR szLocalPassword[] = _T("Mz6@a0i*");
		// Get handle to user default provider.
		if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, 0))		
		{
			// Create hash object.			
			if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash))
			{				
				// Hash password string.
				dwLength = sizeof(TCHAR)*_tcslen(szLocalPassword);
				if (CryptHashData(hHash, (BYTE *)szLocalPassword, dwLength, 0))				
				{
					// Create block cipher session key based on hash of the password.
					if (CryptDeriveKey(hProv, CALG_RC4, hHash, CRYPT_EXPORTABLE, &hKey))					
					{
						// the password is less than 32 characters
						dwLength = 32*sizeof(TCHAR);						
						DWORD dwType = REG_BINARY;
						if (RegQueryValueEx(hRegKey, _T("Password"), NULL, &dwType, (BYTE*)szPassword, &dwLength)==ERROR_SUCCESS)
						{
							if (!CryptDecrypt(hKey, 0, TRUE, 0, (BYTE *)szPassword, &dwLength))
								bResult = FALSE;						
						}						
						else						
						{							
							bResult = FALSE;						
						}
						CryptDestroyKey(hKey);  // Release provider handle.					
					}					
					else					
					{
						// Error during CryptDeriveKey!						
						bResult = FALSE;					
					}				
				}				
				else
				{					
					// Error during CryptHashData!					
					bResult = FALSE;				
				}
				CryptDestroyHash(hHash); // Destroy session key.			
			}			
			else			
			{
				// Error during CryptCreateHash!				
				bResult = FALSE;			
			}
			CryptReleaseContext(hProv, 0);		
		}		
		::RegCloseKey(hRegKey);	
	}		
	else
		bResult = FALSE;	

	return bResult;
}

int main(int argc, char* argv[])
{
	BOOL bResult = SetupCryptoClient();
	if (bResult)
		printf("Cryptographic client Ok\r\n");
	else
		printf("Cryptographic client error\r\n");

	TCHAR szPassword[32] = _T("kl");
	SavePasswordToRegistry(szPassword);

	_tcscpy(szPassword, _T(""));
	ReadPasswordFromRegistry(szPassword);

	printf("The pasword is %s\r\n", szPassword);
	return 0;
}
