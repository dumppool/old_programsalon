#!/bin/sh
diff --ignore-space-change --ignore-blank-lines --context=2 $*
