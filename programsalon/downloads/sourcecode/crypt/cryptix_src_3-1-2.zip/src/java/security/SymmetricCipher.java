/*
// $Log: SymmetricCipher.java,v $
// Revision 1.1.1.1  1997/11/03 22:36:57  hopwood
// + Imported to CVS (tagged as 'start').
//
// $Endlog$
*/

package java.security;

/**
 * This interface is implemented by symmetric ciphers.
 */
public interface SymmetricCipher {
}
