// $Log: ForbiddenTargetException.java,v $
// Revision 1.1.1.1  1997/11/03 22:36:57  hopwood
// + Imported to CVS (tagged as 'start').
//
// $Endlog$
package netscape.security;

/**
 * Dummy class.
 */
public class ForbiddenTargetException extends RuntimeException {
    public ForbiddenTargetException() { super(); }
    public ForbiddenTargetException(String s) { super(s); }
}
