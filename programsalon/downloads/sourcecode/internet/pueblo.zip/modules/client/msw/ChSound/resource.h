//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ChSound.rc
//
#define IDS_NO_SOUND                    1
#define IDS_INVALID_SOUND               2
#define IDS_PREF_NO_DEVICES             3
#define IDD_PREF_PAGE_SOUND             515
#define IDC_SLIDER_VOLUME_MIDI          1017
#define IDC_SLIDER_VOLUME_ALERT         1018
#define IDC_SLIDER_MIKE_SENSITIVITY     1018
#define IDC_SLIDER_VOLUME_WAVE          1019
#define IDC_SLIDER_MIKE_SENSITIVITY2    1019
#define IDC_SLIDER_VOLUME_SPEECH        1019
#define IDC_ALERT_SOUND                 1020
#define IDC_ALERT_SOUND_NAME            1022
#define IDC_NO_SOUND                    1023
#define IDC_TEST                        1024
#define IDC_TIME_UNITS                  1026
#define IDC_TIME_COUNT                  1028
#define IDC_STATIC_MAX                  1029
#define IDC_STATIC_OFF                  1030
#define IDC_STATIC_MUSIC                1031
#define IDC_STATIC_EFFECTS              1032
#define IDC_STATIC_ALERTS               1033
#define IDC_STATIC_MSG                  1034
#define IDC_STATIC_BOX                  1035
#define IDC_STATIC_DISABLE_MSG          1036
#define IDC_CHECK_DISABLE               1037
#define IDC_CHECK_REJECT_CALLS          1042
#define IDC_SLIDER_MIKE_VOLUME          1043
#define stc32                           0x045f
#define IDD_SOUND_FILE_OPEN             1536
#define IDD_SOUND_FILE_OPEN_95          1537
#define IDD_PREF_PAGE_SPEECH            1539

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
