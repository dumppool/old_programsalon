//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ChGraphx.rc
//
#define ID_OPT_PREFERENCES              102
#define ID_HELP_ABOUT_CHACO             103
#define IDC_PICKER                      133
#define IDC_HANDMONO                    141
#define IDD_PREF_PAGE_RLAB              174
#define IDR_EMBED                       174
#define IDD_PREF_PAGE_VRML              515
#define IDC_COMBO_STILL                 1006
#define IDC_COMBO_MOVING                1007
#define IDC_CHECK_VECTOR                1008
#define IDC_CHECK_SCALE                 1009
#define IDC_HEADLIGHT_BRIGHTNESS        1010
#define IDC_OVERRIDE_SCENE_MOVE_MODE    1011
#define IDC_COMBO_VIEWER_MODE           1012
#define IDC_COMBO_COLLISION_MODE        1013
#define IDC_OVERRIDE_SCENE_COLLISION_MODE 1014
#define IDC_COLLISION_SOUND             1015
#define IDC_COMBO_ASCII_QUALITY         1119
#define IDM_CAMERA_START                32772
#define IDM_CAMERA_NEXT                 32773
#define IDM_CAMERA_PREV                 32774
#define ID_VIEW_REFRESH                 32782
#define ID_VIEW_RESET_CAMERA            32796
#define ID_OPT_MOVE_FASTER              32798
#define ID_OPT_MOVE_SLOWER              32799
#define ID_OPT_HEADLIGHT_SWITCH         32800
#define IDM_BRIGHTEN                    32804
#define IDM_DIMMER                      32805
#define IDM_EXAMINE                     32806
#define IDM_WALK                        32807
#define IDM_FLY                         32808
#define ID_OPT_RESET_SPEED              32815
#define IDM_OPTIMIZE_FASTER             32817
#define IDM_OPTIMIZE_BETTER             32818
#define IDM_COLLISION_CHECKING          32819
#define IDM_CAMERA_FIRST                40100
#define IDM_CAMERA_LAST                 40200
#define IDS_HEADLIGHT_ON                51469
#define IDS_HEADLIGHT_OFF               51470
#define IDS_CHACO_URL                   61471
#define IDS_PUEBLO_URL                  61472
#define IDS_TRANSFER_FAILED             61473

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
