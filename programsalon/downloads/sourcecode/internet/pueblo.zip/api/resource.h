//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Pueblo.rc
//
#define IDD_DUMMY                       1
#define IDS_APP_NAME                    1
#define IDS_WIZARD_BTN_BACK             2
#define IDS_WIZARD_BTN_NEXT             3
#define IDS_WIZARD_BTN_CANCEL           4
#define IDS_WIZARD_BTN_CLOSE            5
#define IDS_WIZARD_BTN_FINISH           6
#define IDS_HTTP_ERR_600                7
#define IDS_HTTP_ERR_601                8
#define IDS_HTTP_ERR_602                9
#define IDS_HTTP_ERR_603                10
#define IDS_HTTP_ERR_604                11
#define IDS_HTTP_ERR_605                12
#define IDS_HTTP_ERR_606                13
#define IDS_HTTP_ERR_607                14
#define IDS_HTTP_ERR_608                15
#define IDS_HTTP_ERR_609                16
#define IDS_HTTP_ERR_610                17
#define IDS_COOKIE_HDR1                 18
#define IDS_COOKIE_HDR2                 19
#define IDS_COOKIE_HDR3                 20
#define IDS_TRACE_PANE_NAME             21
#define IDS_TRACE_PANE_TITLE            22
#define IDS_TRACE_PANE_TEXT             23
#define IDB_BASE_BAR                    129
#define IDC_HOTSPOT_CURSOR              130
#define IDC_COL_SPLITTER                132
#define IDC_HOTSPOT_CUR                 134
#define IDC_ROW_SPLITTER                138
#define IDB_JPEGPAL                     140
#define IDI_BOOK                        142
#define IDI_SCROLL                      143
#define IDI_ICON1                       144
#define IDI_MAP                         144
#define IDR_TXTWND_PAL                  145
#define IDI_BOOK_LOG                    145

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
