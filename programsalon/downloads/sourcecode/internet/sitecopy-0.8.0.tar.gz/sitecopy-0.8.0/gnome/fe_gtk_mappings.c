/* 
 *      XSitecopy, for managing remote web sites with a GNOME interface.
 *      Copyright (C) 1999, Lee Mallabone <lee0@callnetuk.com
 *                                                                        
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *     
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *     
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 */
#include "fe_gtk_main.h"
#include "fe_gnome_common.h"

extern struct site_t *all_sites;
extern GtkWidget *site_list, *status_bar;

GtkWidget *name_map_clist, *name_map_local_entry, *name_map_remote_entry;
extern struct site_t *selected_site;
struct name_mapping_t *selected_mapping;

int name_map_row = -1;

void populate_name_map (void) {
   struct name_mapping_t *name;
   gchar *to_add[2];

   for (name = selected_site->renames; name != NULL; name=name->next) {
      to_add[0] = name->local;
      to_add[1] = name->remote;
      name_map_row = gtk_clist_append (GTK_CLIST (name_map_clist), to_add);
      gtk_clist_set_row_data (GTK_CLIST (name_map_clist), name_map_row,
			      (gpointer) name);
   }
}

void select_name_map (GtkWidget *list, gint row) {
   gchar *local_to_change, *remote_to_change;
   name_map_row = row;
   selected_mapping = (struct name_mapping_t *) gtk_clist_get_row_data (GTK_CLIST (name_map_clist), 
									name_map_row);
   gtk_clist_get_text (GTK_CLIST (name_map_clist), row, 0, &local_to_change);
   gtk_clist_get_text (GTK_CLIST (name_map_clist), row, 1, &remote_to_change);
   gtk_entry_set_text (GTK_ENTRY (name_map_local_entry), local_to_change);
   gtk_entry_set_text (GTK_ENTRY (name_map_remote_entry), remote_to_change);
}

/* Should probably be in fe_gtk_changes.c but what the hell */

void change_local_map (GtkWidget *entry, gpointer data) {
   gchar *text;
   extern bool rcfile_saved;
   
   text = gtk_entry_get_text (GTK_ENTRY (name_map_local_entry));
   gtk_clist_set_text (GTK_CLIST (name_map_clist), name_map_row, 0, text);

   strcpy (selected_mapping->local, text);
   rcfile_saved = false;
}

void change_remote_map (GtkWidget *entry, gpointer data) {
   gchar *text;
   
   text = gtk_entry_get_text (GTK_ENTRY (name_map_remote_entry));
   gtk_clist_set_text (GTK_CLIST (name_map_clist), name_map_row, 1, text);
   
   strcpy (selected_mapping->remote, text);
//   printf ("Row number: %d\n", name_map_row);
}

void add_name_map (GtkWidget *button, gpointer data) {
   struct name_mapping_t *new_map;
   gchar *to_add[2];
   
   new_map = malloc (sizeof (struct name_mapping_t));
   to_add[0] = "Local filename";
   to_add[1] = "Filename on server";
   name_map_row = gtk_clist_append (GTK_CLIST (name_map_clist), to_add);
   new_map->local = strdup (to_add[0]);
   new_map->remote = strdup (to_add[1]);
   new_map->next = selected_site->renames;
   selected_site->renames = new_map;
   gtk_clist_set_row_data (GTK_CLIST (name_map_clist), name_map_row,
			   (gpointer) new_map);
   gtk_clist_select_row (GTK_CLIST (name_map_clist), name_map_row, -1);
}

struct name_mapping_t *find_prev_map (struct name_mapping_t *mapping) {
   struct name_mapping_t *tmp;
   tmp = selected_site->renames;
   while ( tmp->next != NULL) {
      if (   (strcmp (tmp->next->local, mapping->local) == 0)
	  && (strcmp (tmp->next->remote, mapping->remote) == 0)  ){
	 return tmp;
      } else {
	 tmp = tmp->next;
      }
   }
   return NULL; //should never reach here.
}

void remove_name_map (GtkWidget *delete_button, gpointer data) {

   struct name_mapping_t *tmp, *tmp2;
   
   if ( (selected_mapping != NULL) && (selected_site->renames != NULL) ) {

      if ( (strcmp (selected_site->renames->local, selected_mapping->local) == 0)
	  && (strcmp (selected_site->renames->remote, selected_mapping->remote) == 0) ) {
	 selected_site->renames = selected_site->renames->next;
      } else {
	 tmp = find_prev_map (selected_mapping);
	 if (tmp->next != NULL) {
	    tmp2 = tmp->next;
	    tmp->next = tmp2->next;
	 }
      }
      gtk_clist_remove (GTK_CLIST (name_map_clist), name_map_row);
      
   } else {
      fe_status ("That button deletes a name mapping. So you must select one first.");
   }
}

