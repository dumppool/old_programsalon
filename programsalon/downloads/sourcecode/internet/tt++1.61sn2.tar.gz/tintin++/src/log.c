/* New for v2.0: readline support -- daw */

/* i put the logging crap in it's own file, in case we wanna change it later */

#include <stdio.h>
#include "tintin.h"

void
logit(s, b)
	struct session	*s;
	char		*b;
{
	static char	bb[BUFFER_SIZE+1];
	int		i, j;

	if (s->logfile == NULL)
		return;

#if	OLD_LOG
	fputs(b, s->logfile);
#else
	/* new logging behavior: ignore control-m's */
	for (i=j=0; b[i]; i++)
		if (b[i] != '\r')
			bb[j++] = b[i];
	bb[j] = '\0';
	fputs(bb, s->logfile);
#endif
}
