/*
 * CH.C
 *
 * Usage: ch input.htm > output.txt
 * CH wraps text and indents tags, the better to SEE inside HTML files.
 * The output file will be corrupt, but easier to read in a text editer.
 *
 * Copyright (C) 1998 Glenn Scheper. This program is free software;
 * you can redistribute it and/or modify it under the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details. You should have
 * received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Contact CH's author Glenn Scheper at <URL:mailto:scheper@hughes.net>.
 * Download CH.C and CH.EXE at <URL:http://hughes.net/~scheper/>.
 * GNU General Public License: <URL:http://www.fsf.org/copyleft/gpl.html>.
 *
 * Compiled under Microsoft Developer Studio and
 * Microsoft Visual C++ 5.0 compiler as follows:
 * 
 * Go where you make new VC++ projects. ( I use C:\I\VC. )
 * Make a new directory ch.
 * Copy ch.c to directory ch.
 * Execute MS VC++.
 * Do: File | New...
 * Make sure or fix so Location says "C:\I\VC" or whatever.
 * Scroll down to "Win32 Console Application".
 * Tab to "Project Name". Type in "ch". Click OK.
 * A new workspace for ch will appear.
 * Click on the "File View" tab.
 * Right-Click on "ch Files".
 * Select "Add Files to Project...".
 * Select the file "ch.c". Click OK.
 * Do: Build | "Set Active Configuration..."
 * Select "ch - Win32 release". Click OK.
 * Do: Build, Rebuild all.
 * Copy ./release/ch.exe to a directory in the path.
 */

char CHVersionAndDate [] = "CH version 1.0, Dec 1, 1998.";

#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>

void GiveUsageMessage( )
{
	fprintf( stderr,
" Usage: ch input.htm > output.txt\n"
" CH wraps text and indents tags, the better to SEE inside HTML files.\n"
" The output file will be corrupt, but easier to read in a text editer.\n"
"\n"
" %s Copyright (C) 1998 Glenn Scheper.\n"	// ...CHVersionAndDate here
" CH comes with ABSOLUTELY NO WARRANTY; See source code for details.\n"
" This is free software, and you are welcome to redistribute it under\n"
" certain conditions; See source code for details. <scheper@hughes.net>.\n"
" Download source and executable from <URL:http://www.hughes.net/~scheper/>.\n",
	CHVersionAndDate );
	return;
}

char space[256];
int column = 0;
int InTag = 0;
int CanSpace = 0;
int OweSpace = 0;

void StartTag()
{
	InTag = 1;
	if (column != 0)
	{
		putchar('\r');
		putchar('\n');
	}
	putchar('\t');
	column = 8;
	CanSpace=0;
	OweSpace=0;
}

void StopTag()
{
	InTag = 0;
	putchar('\r');
	putchar('\n');
	column = 0;
	CanSpace=0;
	OweSpace=0;
}

void CharOut(int c)
{
	if(OweSpace) {
		putc(' ', stdout);
		column ++;
	}
	OweSpace=0;
	if(InTag) {
		putc(c, stdout);
		column ++;
	} else {
		putc(c, stdout);
		column ++;
	}
	CanSpace=1;
}

void SpaceOut()
{
	if(CanSpace) {
		if(InTag) {
			if(column > 60) {
				putchar('\r');
				putchar('\n');
				putchar('\t');
				putchar('\t');
				CanSpace=0;
				column = 16;
			} else {
				OweSpace=1;
			}
		} else {
			if(column > 60) {
				putchar('\r');
				putchar('\n');
				CanSpace=0;
				column = 0;
			} else {
				OweSpace=1;
			}
		}
	}
	CanSpace=0;
}

void main( int argc, char ** argv )
{
	int c;
	FILE * fp;
	if( argc != 2 )
	{
		GiveUsageMessage( );
		exit( 1 );
	}
	fp = freopen( argv[1], "r", stdin );
	if( fp == ( FILE* )0 )
	{
		fprintf( stderr, "Error: CH cannot open %s.\r\n", argv[1] );
		exit ( 1 );
	}
	if( setmode( 0, O_BINARY )==-1 )
	{
		fprintf( stderr, "Error: CH cannot change input file mode to O_BINARY" );
		exit( 1 );
	}
	if( setmode( 1, O_BINARY )==-1 )
	{
		fprintf( stderr, "Error: CH cannot change stdout file mode to O_BINARY" );
		exit( 1 );
	}

	space[' '] = 1;
	space['\t'] = 1;
	space['\r'] = 1;
	space['\n'] = 1;
	space['\f'] = 1;

	while( ( c=getchar( ) ) != -1 )
	{
		if(space[c]) {
			SpaceOut();
		} else if(c == '<') {
			StartTag();
			CharOut(c);
		} else if(c == '>') {
			CharOut(c);
			StopTag();
		} else {
			CharOut(c);
		}
	}
	exit( 0 );
}
