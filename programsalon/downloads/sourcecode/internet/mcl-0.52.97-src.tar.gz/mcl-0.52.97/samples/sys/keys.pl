# Some useful keys
# Maybe autoconvert this somehow...

$keyBackspace = 127;
$keyTab = 9;
