#define VERSION 5297
#define COMPILED_BY "root@erwin"
