// This file defines some global desktop variables

