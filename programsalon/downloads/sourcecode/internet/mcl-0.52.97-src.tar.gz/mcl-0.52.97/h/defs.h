#ifndef __DEFS_H
#define __DEFS_H

#define MAX_MUD_BUF 4096
#define MAX_INPUT_BUF 1024
#define NUL '\0'

#define _GNU_SOURCE 1

typedef unsigned char byte;
typedef unsigned int uint;

#endif
