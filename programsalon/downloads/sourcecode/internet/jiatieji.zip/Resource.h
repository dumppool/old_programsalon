//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mfcapp.rc
//
#define IDD_MFCAPP_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDC_REFIMG                      1000
#define IDC_EMAIL                       1001
#define IDC_TITLE                       1002
#define IDC_AUTHOR                      1003
#define IDC_BODY                        1004
#define IDC_REFURL                      1005
#define IDC_PASS                        1006
#define IDC_COPYFROM                    1007
#define IDC_URLNAME                     1008
#define IDC_RADIO1                      1009
#define IDC_RADIO2                      1010
#define IDC_REFID                       1011
#define IDC_REPSTATIC                   1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
