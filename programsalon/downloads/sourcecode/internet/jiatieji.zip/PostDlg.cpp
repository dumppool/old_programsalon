/*
	��Ȩ���У�������
	          http://www.geocities.com/zhoutianshu
			  zhoutianshu@yahoo.com
	��л���Ĳˡ�
*/
#include "stdafx.h"
#include "mfcapp.h"
#include "PostDlg.h"
#include "crobotinternet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define TRYNUM 3
//#define SETMESSAGE

/////////////////////////////////////////////////////////////////////////////
// PostDlg dialog


PostDlg::PostDlg(CWnd* pParent /*=NULL*/)
	: CDialog(PostDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(PostDlg)
	m_author = _T("");
	m_body = _T("");
	m_subject = _T("");
	m_urlname = _T("");
	m_copyfrom = _T("");
	m_pass = _T("");
	m_refimg = _T("");
	m_refurl = _T("");
	m_newORreply = -1;
	m_newORreply=0;
	m_refid = _T("");
	//}}AFX_DATA_INIT
}


void PostDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(PostDlg)
	DDX_Text(pDX, IDC_AUTHOR, m_author);
	DDX_Text(pDX, IDC_BODY, m_body);
	DDX_Text(pDX, IDC_TITLE, m_subject);
	DDX_Text(pDX, IDC_URLNAME, m_urlname);
	DDX_Text(pDX, IDC_COPYFROM, m_copyfrom);
	DDX_Text(pDX, IDC_PASS, m_pass);
	DDX_Text(pDX, IDC_REFIMG, m_refimg);
	DDX_Text(pDX, IDC_REFURL, m_refurl);
	DDX_Radio(pDX, IDC_RADIO1, m_newORreply);
	DDX_Text(pDX, IDC_REFID, m_refid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(PostDlg, CDialog)
	//{{AFX_MSG_MAP(PostDlg)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// PostDlg message handlers

void PostDlg::OnOK() 
{
	PostRichwin();
	//CDialog::OnOK();
}

void PostDlg::PostRichwin()
{

	UpdateData();
	
	//convert abnormal characters
	TransformString(m_author);
	TransformString(m_body);
	TransformString(m_copyfrom);
	TransformString(m_pass);
	TransformString(m_refimg);
	TransformString(m_refurl);
	TransformString(m_subject);
	TransformString(m_urlname);

	CRobotInternet internet;
	CString sURL, sData, sResponse, sErrMsg;
	int nResult;
	int i = 0;
	internet.m_sUserAgent = "Mozilla/4.0 (compatible; MSIE4.0; windows95)";

	//���Ƚ��е�½
	sURL = "http://bbs2.sina.com.cn/newfbin/add.pl";
	sData = "forumid=71&type=login&loginname="+m_author+"&password="+m_pass;
	internet.httpPost(sURL,sData, sResponse, nResult, sErrMsg);

	if(!m_newORreply) //������
	{
		sURL = "http://bbs2.sina.com.cn/newfbin/post.pl?forumid=71";
		sData = "post=new&forumid=71&subject=" + m_subject +
			"&copyfrom=" +  m_copyfrom +
			"&body=" + m_body ;
			"&urlname=" +	m_urlname +
			"&refurl=" + m_refurl +
			"&refimg=" + m_refimg;
		if(internet.httpPost(sURL,sData, sResponse, nResult, sErrMsg))
			::MessageBox(NULL,sResponse,"������Ϣ",MB_OK);
	}
	else			//����
	{
		sURL = "http://bbs2.sina.com.cn/newfbin/post.pl?forumid=71";
		sData = "post=reply&forumid=71&subject=" + m_subject +
			"&postid=" + m_refid +
		    "&copyfrom=" +  m_copyfrom +
			"&body=" + m_body ;
			"&urlname=" +	m_urlname +
			"&refurl=" + m_refurl +
			"&refimg=" + m_refimg;
		if(internet.httpPost(sURL,sData, sResponse, nResult, sErrMsg))
			::MessageBox(NULL,sResponse,"������Ϣ",MB_OK);
	}
}
void PostDlg::TransformString(CString &s)
{
	CString t = "";
	int i;
	for(i = 0; i < s.GetLength(); i++) {
		switch (s.GetAt(i)) {
		case '&': 
			t = t + "%26";
			break;
		case '%':
			t = t + "%25";
			break;
		case '<':
			t = t + "%3c";
			break;
		case '>':
			t = t + "%3e";
			break;
		case '=':
			t = t + "%3d";
			break;
		default:
			t = t + s.GetAt(i);
			break;
		}
	}
	s = t;
}


void trash()
{
/*
//1LLFC
	sURL = "http://www.bbsland.com/cgi-bin/post_rm.cgi";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&sender=" + sName +
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle;
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
		MessageBox(NULL, sFile, "LLFC", MB_OK);
#endif
//2�����������ô�   not
	sURL = "http://yangyang.virtualave.net/canada/mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "�����������ô�", MB_OK);
#endif


//3���������̳
	sURL = "http://www.toptoday.com/cgi-freebbs/freeforum.cgi?corydon";
	sData = "name=" + sName + 
			"&password=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "���������̳", MB_OK);
#endif


//4ͳ����̳http://omniboard.hypermart.net/ui/mainpage.pl
	sURL = "http://omniboard.hypermart.net/ui/mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "ͳ����̳", MB_OK);
#endif


//5��ά������̳ http://www.creaders.org/cgi-bin/mainpage.cgi
	sURL = "http://www.creaders.org/cgi-bin/post_pol.cgi";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&sender=" + sName +
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "��ά������̳", MB_OK);
#endif


//6��������ʱ����̳ http://www.washeng.com/HuaShan/BBS/shishi/gbcurrent.html
	sURL = "http://washeng.com/cgi-bin/hbbs-add.cgi";
	sData = "barcode=1909434&forum=shishi&lang=gb&action=add&shijian=20:22:59&username=" + sName + 
			"&password=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "��������ʱ����̳", MB_OK);
#endif

	
//7�⽻�뷽��http://omniboard.hypermart.net/diplomacy/mainpage.pl
	sURL = "http://omniboard.hypermart.net/diplomacy/mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "�⽻�뷽��", MB_OK);
#endif


//8��ѧ����̳http://www.chinese-e.com/cgi-bin/life.pl
	sURL = "http://www.chinese-e.com/cgi-bin/lifeboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "��ѧ����̳", MB_OK);
#endif


//9�»�ͨ��̳http://207.151.76.245/cgi-bin/mainpage.pl     not
	sURL = "http://207.151.76.245/cgi-bin/mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "�»�ͨ��̳", MB_OK);
#endif

//10�´�½http://www.bbsland.com/cgi-bin/newland.cgi
	sURL = "http://www.bbsland.com/cgi-bin/post_nl.cgi";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "�´�½", MB_OK);
#endif

//11���������̳http://www.wforum.com/home/wmfmain.html
	sURL = "http://www.wforum.com/cgi-bin/wmf/anyboard.cgi/wmf/";
	sData = "abc=hV&cmd=sA&name=" + sName + 
			"&passwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "���������̳", MB_OK);
#endif

//12ս������http://omniboard.hypermart.net/military/mainpage.pl
	sURL = "http://omniboard.hypermart.net/military/mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "ս������", MB_OK);
#endif

//13ָ�㽭ɽhttp://207.151.76.248/cgi-bin/mainpage.pl
	sURL = "http://207.151.76.248/cgi-bin/mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "ָ�㽭ɽ", MB_OK);
#endif

//14�绨ѩ��http://207.151.76.247/cgi-bin/mainpage.pl
	sURL = "http://207.151.76.247/cgi-bin/mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "�绨ѩ��", MB_OK);
#endif


//15�����̳http://www.duoweinews.com/BBS/Dajia/mainpage.cgi?encoding=gb
	sURL = "http://www.duoweinews.com/BBS/Dajia/mainboard.cgi";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=&unidoc=gb2312" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "�����̳", MB_OK);
#endif

//16��˵��˵��̳http://nsws.hypermart.net/forum/mainpage.pl
	sURL = "http://nsws.hypermart.net/forum/mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "��˵��˵��̳", MB_OK);
#endif

//17���������̳http://www.toptoday.com/freebbs/corydon/corydon1.shtml
	sURL = "http://nsws.hypermart.net/forum/mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "���������̳", MB_OK);
#endif

//18������̳ http://www.jumperhome.com/forums/F-pltc.htm
	sURL = "http://www.jumperhome.com/cgi-bin/pltc-mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&sort=[���̸̸]" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "������̳", MB_OK);
#endif

//19���л�ǿ����̳http://www.auch.com.au/greatchina/forum/mainpage.pl
	sURL = "http://www.auch.com.au/greatchina/forum/mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "���л�ǿ����̳", MB_OK);
#endif

//20У����̳http://www.omnitalk.net/alumni/mainpage.pl
	sURL = "http://www.omnitalk.net/alumni/mainboard.pl";
	sData = "name=" + sName + 
			"&usrpwd=" + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "У����̳", MB_OK);
#endif

//21�� �� ѧ �� �� �� ��http://www.cstudent.com/usabbs/usabbs1.shtml
	sURL = "http://www.cstudent.com/cgi-usabbs/usabbs.cgi";
	sData = "name=" + sName + 
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "�� �� ѧ �� �� �� ��", MB_OK);
#endif

//22�������http://www.bbsland.com/cgi-bin/tea.cgi
	sURL = "http://www.bbsland.com/cgi-bin/post_tea.cgi";
	sData = "name=" + sName + 
			"&usrpwd=" +
			"&email=" + 
			"&subject=" + sTitle +
			"&body=" + sBody +
			"&url=" + sUrl +
			"&url_title=" + sUrlTitle +
			"&img=";
	for (i = 0; i < TRYNUM; i++) 
		if (internet.httpPost(sURL,sData, sFile, nResult, sErrMsg)) break;
#ifdef SETMESSAGE
	if (i <= TRYNUM)
	MessageBox(NULL, sFile, "�������", MB_OK);
#endif


//23����http://bbs2.sina.com.cn/fbin/list.pl?forumid=46&startfullpath=/939588307c25771&count=150

	sName = "full123";
	sURL = "http://bbs2.sina.com.cn/fbin/post.pl";
	sData = "author=" + sName + 
			"&password=" + sName +
			"&email=" + 
			"&subject=" + sTitle +
			"&copyfrom=" +
			"&body=" + sBody +
			"&urlname" + sUrlTitle +
			"&refurl=" + sUrl +
			"&refimg=";
	while(!internet.httpPost(sURL,sData, sFile, nResult, sErrMsg, "multipart/form-data")){
		MessageBox(NULL, sErrMsg, "", MB_OK);
	};
	MessageBox(NULL, sFile, "�� �� ѧ �� �� �� ��", MB_OK);
*/
}

void PostDlg::OnRadio1() 
{
	GetDlgItem(IDC_REFID)->EnableWindow(FALSE);	
	GetDlgItem(IDC_REPSTATIC)->EnableWindow(FALSE);	
}

void PostDlg::OnRadio2() 
{
	GetDlgItem(IDC_REFID)->EnableWindow(TRUE);	
	GetDlgItem(IDC_REPSTATIC)->EnableWindow(TRUE);	
}

BOOL PostDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	GetDlgItem(IDC_REFID)->EnableWindow(FALSE);	
	GetDlgItem(IDC_REPSTATIC)->EnableWindow(FALSE);	
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
