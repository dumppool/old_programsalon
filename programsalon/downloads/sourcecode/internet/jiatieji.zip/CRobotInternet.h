/*
	��Ȩ���У�������
	          http://www.geocities.com/zhoutianshu
			  zhoutianshu@yahoo.com
	��л���Ĳˡ�
*/


////////////////////////////////////////////////////////////////////
//
//  CRobotInternet.h - CRobotInternet class declarations
//
//  Source: "Programming Robots, Spiders and Intelligent Agents
//           Using Visual C++"
//
//	Copyright (C) 1999 David Pallmann. All Rights Reserved.

class CRobotInternet
{
public:
	BOOL m_bReadFromCache, m_bWriteToCache;
	int m_nContext;
	CString m_sProxyLogonMethod, m_sProxyLogonUsername, m_sProxyLogonPassword;
	CString m_sLogonUsername, m_sLogonPassword;
	CString m_sUserAgent;
	
	// Header (httpHeader, httpHeaderFields)
	CString m_sHeader;
	
	// Number of header fields (httpHeaderFields)
	int m_nHeaderFields;
	
	// Header field names (httpHeaderFields)
	CString m_sHeadName[100];

	// Header field values (httpHeaderFields)
	CString m_sHeadValue[100];

//---- Public functions ----

public:
	CRobotInternet();
	~CRobotInternet();
	
	//---- HTTP functions ----
	BOOL httpPost(const CString& sUrl,
				  const CString& sData,
				  CString& sResponse,
				  int& nResult,
				  CString& sErrMsg);

	//---- FTP functions ----
	
	//---- Generalized functions ----

//---- Private functions ----

private:
	CString EncodeTextBase64(const CString& sText);
	CString ErrorMessage(const int nError);
	CString CreateStandardHeader();

};

////////////////////////////////////////////////////////////////////
