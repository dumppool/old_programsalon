/*
	��Ȩ���У�������
	          http://www.geocities.com/zhoutianshu
			  zhoutianshu@yahoo.com
	��л���Ĳˡ�
*/


#if !defined(AFX_POSTDLG_H__1FAAECC3_B285_11D3_ACBC_00104B0DC2A6__INCLUDED_)
#define AFX_POSTDLG_H__1FAAECC3_B285_11D3_ACBC_00104B0DC2A6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PostDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// PostDlg dialog

class PostDlg : public CDialog
{
// Construction
public:
	void TransformString(CString &s);
	void PostRichwin();
	PostDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(PostDlg)
	enum { IDD = IDD_DIALOG1 };
	CString	m_author;
	CString	m_body;
	CString	m_subject;
	CString	m_urlname;
	CString	m_copyfrom;
	CString	m_pass;
	CString	m_refimg;
	CString	m_refurl;
	int		m_newORreply;
	CString	m_refid;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(PostDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(PostDlg)
	virtual void OnOK();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POSTDLG_H__1FAAECC3_B285_11D3_ACBC_00104B0DC2A6__INCLUDED_)
