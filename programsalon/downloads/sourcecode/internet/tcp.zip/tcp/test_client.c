#include <stdio.h>
#include <stdlib.h>

#include "tcp.h"

void main()
{
	int port =1234;
	int sd;
	
	if((sd =tcp_connect("localhost", 1234, 10)) <0)
	{
		printf("connect localhost port 1234 failed! error:%s\n", tcp_get_error());
		return;
	}
	int buf_len, len;
	char *pbuf ="welcome to www.programsalon.com";
	len =strlen(pbuf);
	buf_len =tcp_htonl(len);
	if(tcp_send(sd, &buf_len, sizeof(buf_len), 10) !=sizeof(buf_len))
	{
		printf("tcp_send buf_len fialed!\n");
		tcp_close(sd);
		return;
	}
	if(tcp_send(sd, pbuf, len, 10) !=len))
	{
		printf("tcp_send pbuf failed!\n");
		tcp_close(sd);
		return;
	}
	printf("send ok!\n");
}

	