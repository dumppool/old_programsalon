/*
* tcp.h last update:1998.09.02
*/

#ifndef _TCP_H
#define _TCP_H

#if defined (__STDC__) || defined (__cplusplus)

int tcp_init(void);
int tcp_connect(char *hostname, int port, int max_wait_seconds);
int tcp_bind(int port);
int tcp_accept(int sd, int max_wait_time);
int tcp_recv(int sd, void *buf, int len, int max_wait_seconds);
int tcp_send(int sd, void *buf, int len, int max_wait_seconds);
int tcp_close(int sd);
int tcp_shut(int sd);
char *tcp_get_error();

unsigned short tcp_htons(unsigned short);
unsigned short tcp_ntohs(unsigned short);
unsigned long int tcp_htonl(unsigned long int);
unsigned long int tcp_ntohl(unsigned long int);
float tcp_htonf(float f);
float tcp_ntohf(float f);
double tcp_htond(double d);
double tcp_ntohd(double d);

char *get_ip(int sd);

#else

int tcp_init();
int tcp_connect();
int tcp_bind();
int tcp_accept();
int tcp_recv();
int tcp_send();
int tcp_close();

unsigned short tcp_htons();
unsigned short tcp_ntohs();
unsigned long int tcp_htonl();
unsigned long int tcp_ntohl();
float tcp_htonf();
float tcp_ntohf();
double tcp_htond();
double tcp_ntohd();

char *get_ip();
#endif

#endif

