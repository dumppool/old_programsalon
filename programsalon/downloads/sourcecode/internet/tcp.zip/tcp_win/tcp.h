#define WM_TCP		WM_APP+100

//extern int sd_connect, sd_bind, sd_accept;

int tcp_init();
int tcp_exit();

int tcp_status(int  sd, char *type, int timeout);
int tcp_bind(HWND hWnd, int port);
int tcp_accept(int sd, int timeout);
int tcp_connect(char *hostname, int port, int timeout, int f_noblock);
void tcp_disconnect(int sd);
void tcp_close(int sd);

int tcp_send(int sd, char *buf, int len, int timeout);
int tcp_recv(int sd, char *buf, int len, int timeout);
int tcp_gethostnamebyip(char *ip, char *name);

unsigned short tcp_htons(unsigned short);
unsigned short tcp_ntohs(unsigned short);
unsigned long int tcp_htonl(unsigned long int);
unsigned long int tcp_ntohl(unsigned long int);
float tcp_htonf(float f);
float tcp_ntohf(float f);
double tcp_htond(double d);
double tcp_ntohd(double d);

char *get_remote_ip(int sd, char *ip);
