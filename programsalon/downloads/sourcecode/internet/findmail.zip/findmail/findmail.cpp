// findmail.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include <stdio.h>
#include <io.h>
#include "resource.h"

BOOL CALLBACK MainDlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, MainDlgProc);
	return 0;
}

int find_file(HWND hDlg);
int get_mail(HWND);
int save_file(HWND);

BOOL CALLBACK MainDlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hDlg, 0);
		break;
		case ID_SEARCH:
			SendDlgItemMessage(hDlg, IDL_SOURCE_FILES, LB_RESETCONTENT, 0, 0L);
			find_file(hDlg);
			break;
		case ID_GET:
			get_mail(hDlg);
			break;
		case ID_SAVE:
			save_file(hDlg);
			break;
		case ID_CLEAR:
			SendDlgItemMessage(hDlg, IDL_EMAIL, LB_RESETCONTENT, 0, 0L);
		}
	}
	return FALSE;
}

int find_file(HWND hDlg)
{
	struct _finddata_t findinfo;
	char temp[128], path[128];
	int hd;
	char *types[] ={"*.html", "*.htm", "*.txt", "*.asp"};

	if(GetDlgItemText(hDlg, IDE_PATH, path, sizeof(path)) ==0)
		return -1;
	for(int i =0; i<sizeof(types)/sizeof(char *); i++)
	{
		wsprintf(temp, "%s\\%s", path, types[i]);
		if((hd =_findfirst(temp, &findinfo)) ==-1)
			continue;
		while(hd !=-1)
		{
			wsprintf(temp, "%s\\%s", path, findinfo.name);
			SendDlgItemMessage(hDlg, IDL_SOURCE_FILES, LB_ADDSTRING, 0, (LPARAM)(LPSTR)temp);
			if(_findnext(hd, &findinfo) !=0) break;
		}
		
		_findclose(hd);
	}

	return 0;
}

int save_file(HWND hDlg)
{
	int count;
	char temp[100];
	FILE *fp;

	if((count =SendDlgItemMessage(hDlg, IDL_EMAIL, LB_GETCOUNT, 0, 0L)) <=0)
		return 0;
	if(GetDlgItemText(hDlg, IDE_OUTPUT_FILE_NAME, temp, sizeof(temp)) ==0)
		return -1;
	if((fp =fopen(temp, "a")) ==NULL)
	{
		MessageBox(hDlg, "open file failed!", temp, MB_OK);
		return -1;
	}
	for(int i =0; i<count; i++)
	{
		if(SendDlgItemMessage(hDlg, IDL_EMAIL, LB_GETTEXT, i, (LPARAM)temp) ==LB_ERR)
			continue;
		fprintf(fp, "%s\n", temp);
	}
	fclose(fp);

	return 0;
}

int get_mail(HWND hDlg)
{
	int count;
	bool is_email, find_a;
	char file_name[128], temp[1024], email[100], *p, *p1;
	FILE *fp;

	if((count =SendDlgItemMessage(hDlg, IDL_SOURCE_FILES, LB_GETCOUNT, 0, 0L)) <=0)
		return 0;
	for(int i =0; i<count; i++)
	{
		if(SendDlgItemMessage(hDlg, IDL_SOURCE_FILES, LB_GETTEXT, i, (LPARAM)file_name) ==LB_ERR)
			continue;
		if((fp =fopen(file_name, "r")) ==NULL)
		{
			MessageBox(hDlg, "open file failed!", file_name, MB_OK);
			return -1;
		}
		while(fgets(temp, sizeof(temp), fp) !=NULL)
		{
			p =temp;
			p1 =p;
			is_email =0;
			find_a =0;
			while(*p !=0)
			{
				if(*p =='@' && p1 !=p)
					find_a =true;
				else if(*p =='.' && p1 !=p)
				{
					if(find_a ==true) is_email =true;
				}
				else if(!isdigit(*p) && !isalpha(*p) && *p !='-' && *p !='.' && *p !='_')
				{
					if(is_email)
					{
						strncpy(email, p1, p-p1);
						email[p-p1] =0;
						//wsprintf(temp, "%d-%s", i, email);
						SendDlgItemMessage(hDlg, IDL_EMAIL, LB_ADDSTRING, 0, (LPARAM)email);
						is_email =false;
					}
					p1 =p+1;
				}
				p++;
			}
		}
		fclose(fp);
	}

	return 0;
}
