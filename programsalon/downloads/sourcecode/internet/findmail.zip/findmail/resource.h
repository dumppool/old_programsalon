//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by findmail.rc
//
#define IDD_MAIN                        101
#define ID_GET                          1000
#define IDE_PATH                        1001
#define IDL_SOURCE_FILES                1002
#define IDC_LIST2                       1004
#define IDL_EMAIL                       1004
#define IDE_OUTPUT_FILE_NAME            1005
#define ID_SAVE                         1006
#define ID_SEARCH                       1007
#define ID_CLEAR                        1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
