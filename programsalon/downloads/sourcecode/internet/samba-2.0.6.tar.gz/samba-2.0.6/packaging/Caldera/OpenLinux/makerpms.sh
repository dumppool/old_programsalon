#!/bin/sh
# Copyright (C) John H Terpstra 1998
#
set -e

SRCDIR=`rpm --showrc | awk '/^sourcedir/ { print $3}'`
USERID=`id -u`
GRPID=`id -g`

( cd ../../../.. ; chown -R ${USERID}.${GRPID} samba-2.0.6 )
( cd ../../../.. ; tar czvf ${SRCDIR}/samba-2.0.6.tar.gz samba-2.0.6 )
rpm -ba -v samba.spec
