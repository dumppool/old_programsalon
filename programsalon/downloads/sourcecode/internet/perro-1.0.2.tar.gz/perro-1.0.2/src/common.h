
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#include "defines.h"
#include "internet.h"

/* note: extern variables are explained where defined, just use grep. */
extern char *perro_hyphen;
extern int flag_dont_resolve;
extern int flag_quiet;
extern int flag_log;
extern int flag_raw;
extern int qty_ignore;
extern char *progname;
extern int socket_fd;

/* Functions Prototypes */

/* common.c */
void perro_init( void);
void init_signals( void);
void gobackground( void);
char *resolve_host_name( unsigned long int addr);
char *get_serv_name( unsigned short port, const char *proto);
int perro_inet_dtoa( char *mask, struct in_addr *inetmask);
void perro_parse_mask( char *mask, struct in_addr *inetmask);
void process_host_and_mask( char *str, struct in_addr *mask, struct in_addr *host);
char *perro_basename( char *name);
void *perro_calloc( int size);
void open_socket( int protocol);
void show_version( char *str);

