THE AUTHOR (Randol Tigrett) DOES NOT UNDERTAKE ANY LIABILITY FOR
 ANY DAMAGE CAUSED BY THIS PROGRAM. THERE IS ALSO NO GUARANTEE OF
 AN ERROR FREE PROGRAM EXECUTION.

Comments, Questions, & Problems:

If you have any Comments (Good & Bad), Questions About or Problems
 with Simple News Reader, send them to me via Email. (rtigrett@wac.com)

If you encounter a problem, please provide as much detail as you can
 about your computer system,  operation you were performing, etc. in
 your description of the problem.


This program is used mainly as a teaching tool to learn about winsock
 programming in VB5 and reading the RFC for NEWS to create the
 application.

Have fun
