// GetFile.h : Declaration of the CGetFile

#ifndef __GETFILE_H_
#define __GETFILE_H_

#include "resource.h"       // main symbols
#include <asptlb.h>         // Active Server Pages Definitions

/////////////////////////////////////////////////////////////////////////////
// CGetFile
class ATL_NO_VTABLE CGetFile : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CGetFile, &CLSID_GetFile>,
	public ISupportErrorInfo,
	public IDispatchImpl<IGetFile, &IID_IGetFile, &LIBID_ASPFILELib>
{
public:
	CGetFile()
	{ 
		m_bOnStartPageCalled = FALSE;
	}

public:

DECLARE_REGISTRY_RESOURCEID(IDR_GETFILE)
DECLARE_NOT_AGGREGATABLE(CGetFile)

BEGIN_COM_MAP(CGetFile)
	COM_INTERFACE_ENTRY(IGetFile)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IGetFile
public:
	STDMETHOD(GetFile)(/*[in]*/ VARIANT vFileName);
	//Active Server Pages Methods
	STDMETHOD(OnStartPage)(IUnknown* IUnk);
	STDMETHOD(OnEndPage)();

private:
	CComPtr<IRequest> m_piRequest;					//Request Object
	CComPtr<IResponse> m_piResponse;				//Response Object
	CComPtr<ISessionObject> m_piSession;			//Session Object
	CComPtr<IServer> m_piServer;					//Server Object
	CComPtr<IApplicationObject> m_piApplication;	//Application Object
	BOOL m_bOnStartPageCalled;						//OnStartPage successful?
};

#endif //__GETFILE_H_
