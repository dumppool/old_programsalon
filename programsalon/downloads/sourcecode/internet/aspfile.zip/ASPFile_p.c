/* this ALWAYS GENERATED file contains the proxy stub code */


/* File created by MIDL compiler version 3.01.75 */
/* at Wed Nov 25 10:53:57 1998
 */
/* Compiler settings for ASPFile.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )

#define USE_STUBLESS_PROXY

#include "rpcproxy.h"
#include "ASPFile.h"

#define TYPE_FORMAT_STRING_SIZE   813                               
#define PROC_FORMAT_STRING_SIZE   67                                

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IDispatch, ver. 0.0,
   GUID={0x00020400,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IGetFile, ver. 0.0,
   GUID={0x21BA32CF,0x8474,0x11D2,{0x8C,0x97,0x00,0xC0,0x4F,0x8B,0x19,0xDE}} */


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IGetFile_ServerInfo;

#pragma code_seg(".orpc")
extern const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[1];

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    0, /* -error bounds_check flag */
    0x20000, /* Ndr library version */
    0,
    0x301004b, /* MIDL Version 3.1.75 */
    0,
    UserMarshalRoutines,
    0,  /* Reserved1 */
    0,  /* Reserved2 */
    0,  /* Reserved3 */
    0,  /* Reserved4 */
    0   /* Reserved5 */
    };

static const unsigned short IGetFile_FormatStringOffsetTable[] = 
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0,
    24,
    42
    };

static const MIDL_SERVER_INFO IGetFile_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &IGetFile_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IGetFile_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &IGetFile_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };

CINTERFACE_PROXY_VTABLE(10) _IGetFileProxyVtbl = 
{
    &IGetFile_ProxyInfo,
    &IID_IGetFile,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *)-1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *)-1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *)-1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *)-1 /* IGetFile::OnStartPage */ ,
    (void *)-1 /* IGetFile::OnEndPage */ ,
    (void *)-1 /* IGetFile::GetFile */
};


static const PRPC_STUB_FUNCTION IGetFile_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _IGetFileStubVtbl =
{
    &IID_IGetFile,
    &IGetFile_ServerInfo,
    10,
    &IGetFile_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};

#pragma data_seg(".rdata")

static const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[1] = 
        {
            
            {
            VARIANT_UserSize
            ,VARIANT_UserMarshal
            ,VARIANT_UserUnmarshal
            ,VARIANT_UserFree
            }

        };


#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT40_OR_LATER)
#error You need a Windows NT 4.0 or later to run this stub because it uses these features:
#error   -Oif or -Oicf, [wire_marshal] or [user_marshal] attribute.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will die there with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure OnStartPage */

			0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/*  2 */	NdrFcShort( 0x7 ),	/* 7 */
#ifndef _ALPHA_
/*  4 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/*  6 */	NdrFcShort( 0x0 ),	/* 0 */
/*  8 */	NdrFcShort( 0x8 ),	/* 8 */
/* 10 */	0x6,		/* 6 */
			0x2,		/* 2 */

	/* Parameter piUnk */

/* 12 */	NdrFcShort( 0xb ),	/* 11 */
#ifndef _ALPHA_
/* 14 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 16 */	NdrFcShort( 0x0 ),	/* Type Offset=0 */

	/* Return value */

/* 18 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 20 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 22 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure OnEndPage */

/* 24 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 26 */	NdrFcShort( 0x8 ),	/* 8 */
#ifndef _ALPHA_
/* 28 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 30 */	NdrFcShort( 0x0 ),	/* 0 */
/* 32 */	NdrFcShort( 0x8 ),	/* 8 */
/* 34 */	0x4,		/* 4 */
			0x1,		/* 1 */

	/* Return value */

/* 36 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 38 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 40 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetFile */

/* 42 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 44 */	NdrFcShort( 0x9 ),	/* 9 */
#ifndef _ALPHA_
#if !defined(_MIPS_) && !defined(_PPC_)
/* 46 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
#else
			NdrFcShort( 0x1c ),	/* MIPS & PPC Stack size/offset = 28 */
#endif
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 48 */	NdrFcShort( 0x0 ),	/* 0 */
/* 50 */	NdrFcShort( 0x8 ),	/* 8 */
/* 52 */	0x6,		/* 6 */
			0x2,		/* 2 */

	/* Parameter vFileName */

/* 54 */	NdrFcShort( 0x8b ),	/* 139 */
#ifndef _ALPHA_
#if !defined(_MIPS_) && !defined(_PPC_)
/* 56 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* MIPS & PPC Stack size/offset = 8 */
#endif
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 58 */	NdrFcShort( 0x322 ),	/* Type Offset=802 */

	/* Return value */

/* 60 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
#if !defined(_MIPS_) && !defined(_PPC_)
/* 62 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
#else
			NdrFcShort( 0x18 ),	/* MIPS & PPC Stack size/offset = 24 */
#endif
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 64 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {
			
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/*  2 */	NdrFcLong( 0x0 ),	/* 0 */
/*  6 */	NdrFcShort( 0x0 ),	/* 0 */
/*  8 */	NdrFcShort( 0x0 ),	/* 0 */
/* 10 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 12 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 14 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 16 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 18 */	
			0x12, 0x0,	/* FC_UP */
/* 20 */	NdrFcShort( 0x2fa ),	/* Offset= 762 (782) */
/* 22 */	
			0x2b,		/* FC_NON_ENCAPSULATED_UNION */
			0x6,		/* FC_SHORT */
/* 24 */	0x6,		/* 6 */
			0x0,		/*  */
/* 26 */	NdrFcShort( 0xfffffff8 ),	/* -8 */
/* 28 */	NdrFcShort( 0x2 ),	/* Offset= 2 (30) */
/* 30 */	NdrFcShort( 0x10 ),	/* 16 */
/* 32 */	NdrFcShort( 0x29 ),	/* 41 */
/* 34 */	NdrFcLong( 0x3 ),	/* 3 */
/* 38 */	NdrFcShort( 0xffff8008 ),	/* Offset= -32760 (-32722) */
/* 40 */	NdrFcLong( 0x11 ),	/* 17 */
/* 44 */	NdrFcShort( 0xffff8002 ),	/* Offset= -32766 (-32722) */
/* 46 */	NdrFcLong( 0x2 ),	/* 2 */
/* 50 */	NdrFcShort( 0xffff8006 ),	/* Offset= -32762 (-32712) */
/* 52 */	NdrFcLong( 0x4 ),	/* 4 */
/* 56 */	NdrFcShort( 0xffff800a ),	/* Offset= -32758 (-32702) */
/* 58 */	NdrFcLong( 0x5 ),	/* 5 */
/* 62 */	NdrFcShort( 0xffff800c ),	/* Offset= -32756 (-32694) */
/* 64 */	NdrFcLong( 0xb ),	/* 11 */
/* 68 */	NdrFcShort( 0xffff8006 ),	/* Offset= -32762 (-32694) */
/* 70 */	NdrFcLong( 0xa ),	/* 10 */
/* 74 */	NdrFcShort( 0xffff8008 ),	/* Offset= -32760 (-32686) */
/* 76 */	NdrFcLong( 0x6 ),	/* 6 */
/* 80 */	NdrFcShort( 0xca ),	/* Offset= 202 (282) */
/* 82 */	NdrFcLong( 0x7 ),	/* 7 */
/* 86 */	NdrFcShort( 0xffff800c ),	/* Offset= -32756 (-32670) */
/* 88 */	NdrFcLong( 0x8 ),	/* 8 */
/* 92 */	NdrFcShort( 0xc4 ),	/* Offset= 196 (288) */
/* 94 */	NdrFcLong( 0xd ),	/* 13 */
/* 98 */	NdrFcShort( 0xffffff9e ),	/* Offset= -98 (0) */
/* 100 */	NdrFcLong( 0x9 ),	/* 9 */
/* 104 */	NdrFcShort( 0xd0 ),	/* Offset= 208 (312) */
/* 106 */	NdrFcLong( 0x2000 ),	/* 8192 */
/* 110 */	NdrFcShort( 0xdc ),	/* Offset= 220 (330) */
/* 112 */	NdrFcLong( 0x4011 ),	/* 16401 */
/* 116 */	NdrFcShort( 0x25a ),	/* Offset= 602 (718) */
/* 118 */	NdrFcLong( 0x4002 ),	/* 16386 */
/* 122 */	NdrFcShort( 0x258 ),	/* Offset= 600 (722) */
/* 124 */	NdrFcLong( 0x4003 ),	/* 16387 */
/* 128 */	NdrFcShort( 0x256 ),	/* Offset= 598 (726) */
/* 130 */	NdrFcLong( 0x4004 ),	/* 16388 */
/* 134 */	NdrFcShort( 0x254 ),	/* Offset= 596 (730) */
/* 136 */	NdrFcLong( 0x4005 ),	/* 16389 */
/* 140 */	NdrFcShort( 0x252 ),	/* Offset= 594 (734) */
/* 142 */	NdrFcLong( 0x400b ),	/* 16395 */
/* 146 */	NdrFcShort( 0x240 ),	/* Offset= 576 (722) */
/* 148 */	NdrFcLong( 0x400a ),	/* 16394 */
/* 152 */	NdrFcShort( 0x23e ),	/* Offset= 574 (726) */
/* 154 */	NdrFcLong( 0x4006 ),	/* 16390 */
/* 158 */	NdrFcShort( 0x244 ),	/* Offset= 580 (738) */
/* 160 */	NdrFcLong( 0x4007 ),	/* 16391 */
/* 164 */	NdrFcShort( 0x23a ),	/* Offset= 570 (734) */
/* 166 */	NdrFcLong( 0x4008 ),	/* 16392 */
/* 170 */	NdrFcShort( 0x23c ),	/* Offset= 572 (742) */
/* 172 */	NdrFcLong( 0x400d ),	/* 16397 */
/* 176 */	NdrFcShort( 0x23a ),	/* Offset= 570 (746) */
/* 178 */	NdrFcLong( 0x4009 ),	/* 16393 */
/* 182 */	NdrFcShort( 0x238 ),	/* Offset= 568 (750) */
/* 184 */	NdrFcLong( 0x6000 ),	/* 24576 */
/* 188 */	NdrFcShort( 0x236 ),	/* Offset= 566 (754) */
/* 190 */	NdrFcLong( 0x400c ),	/* 16396 */
/* 194 */	NdrFcShort( 0x234 ),	/* Offset= 564 (758) */
/* 196 */	NdrFcLong( 0x10 ),	/* 16 */
/* 200 */	NdrFcShort( 0xffff8002 ),	/* Offset= -32766 (-32566) */
/* 202 */	NdrFcLong( 0x12 ),	/* 18 */
/* 206 */	NdrFcShort( 0xffff8006 ),	/* Offset= -32762 (-32556) */
/* 208 */	NdrFcLong( 0x13 ),	/* 19 */
/* 212 */	NdrFcShort( 0xffff8008 ),	/* Offset= -32760 (-32548) */
/* 214 */	NdrFcLong( 0x16 ),	/* 22 */
/* 218 */	NdrFcShort( 0xffff8008 ),	/* Offset= -32760 (-32542) */
/* 220 */	NdrFcLong( 0x17 ),	/* 23 */
/* 224 */	NdrFcShort( 0xffff8008 ),	/* Offset= -32760 (-32536) */
/* 226 */	NdrFcLong( 0xe ),	/* 14 */
/* 230 */	NdrFcShort( 0x218 ),	/* Offset= 536 (766) */
/* 232 */	NdrFcLong( 0x400e ),	/* 16398 */
/* 236 */	NdrFcShort( 0x21e ),	/* Offset= 542 (778) */
/* 238 */	NdrFcLong( 0x4010 ),	/* 16400 */
/* 242 */	NdrFcShort( 0x1dc ),	/* Offset= 476 (718) */
/* 244 */	NdrFcLong( 0x4012 ),	/* 16402 */
/* 248 */	NdrFcShort( 0x1da ),	/* Offset= 474 (722) */
/* 250 */	NdrFcLong( 0x4013 ),	/* 16403 */
/* 254 */	NdrFcShort( 0x1d8 ),	/* Offset= 472 (726) */
/* 256 */	NdrFcLong( 0x4016 ),	/* 16406 */
/* 260 */	NdrFcShort( 0x1d2 ),	/* Offset= 466 (726) */
/* 262 */	NdrFcLong( 0x4017 ),	/* 16407 */
/* 266 */	NdrFcShort( 0x1cc ),	/* Offset= 460 (726) */
/* 268 */	NdrFcLong( 0x0 ),	/* 0 */
/* 272 */	NdrFcShort( 0x0 ),	/* Offset= 0 (272) */
/* 274 */	NdrFcLong( 0x1 ),	/* 1 */
/* 278 */	NdrFcShort( 0x0 ),	/* Offset= 0 (278) */
/* 280 */	NdrFcShort( 0xffffffff ),	/* Offset= -1 (279) */
/* 282 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 284 */	NdrFcShort( 0x8 ),	/* 8 */
/* 286 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 288 */	
			0x12, 0x0,	/* FC_UP */
/* 290 */	NdrFcShort( 0xc ),	/* Offset= 12 (302) */
/* 292 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 294 */	NdrFcShort( 0x2 ),	/* 2 */
/* 296 */	0x9,		/* 9 */
			0x0,		/*  */
/* 298 */	NdrFcShort( 0xfffffffc ),	/* -4 */
/* 300 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 302 */	
			0x17,		/* FC_CSTRUCT */
			0x3,		/* 3 */
/* 304 */	NdrFcShort( 0x8 ),	/* 8 */
/* 306 */	NdrFcShort( 0xfffffff2 ),	/* Offset= -14 (292) */
/* 308 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 310 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 312 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 314 */	NdrFcLong( 0x20400 ),	/* 132096 */
/* 318 */	NdrFcShort( 0x0 ),	/* 0 */
/* 320 */	NdrFcShort( 0x0 ),	/* 0 */
/* 322 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 324 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 326 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 328 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 330 */	
			0x12, 0x0,	/* FC_UP */
/* 332 */	NdrFcShort( 0x170 ),	/* Offset= 368 (700) */
/* 334 */	
			0x2a,		/* FC_ENCAPSULATED_UNION */
			0x48,		/* 72 */
/* 336 */	NdrFcShort( 0x8 ),	/* 8 */
/* 338 */	NdrFcShort( 0x8 ),	/* 8 */
/* 340 */	NdrFcLong( 0x8 ),	/* 8 */
/* 344 */	NdrFcShort( 0x4c ),	/* Offset= 76 (420) */
/* 346 */	NdrFcLong( 0xd ),	/* 13 */
/* 350 */	NdrFcShort( 0x6c ),	/* Offset= 108 (458) */
/* 352 */	NdrFcLong( 0x9 ),	/* 9 */
/* 356 */	NdrFcShort( 0x88 ),	/* Offset= 136 (492) */
/* 358 */	NdrFcLong( 0xc ),	/* 12 */
/* 362 */	NdrFcShort( 0xb0 ),	/* Offset= 176 (538) */
/* 364 */	NdrFcLong( 0x10 ),	/* 16 */
/* 368 */	NdrFcShort( 0xc8 ),	/* Offset= 200 (568) */
/* 370 */	NdrFcLong( 0x2 ),	/* 2 */
/* 374 */	NdrFcShort( 0xe0 ),	/* Offset= 224 (598) */
/* 376 */	NdrFcLong( 0x3 ),	/* 3 */
/* 380 */	NdrFcShort( 0xf8 ),	/* Offset= 248 (628) */
/* 382 */	NdrFcLong( 0x14 ),	/* 20 */
/* 386 */	NdrFcShort( 0x110 ),	/* Offset= 272 (658) */
/* 388 */	NdrFcShort( 0x0 ),	/* Offset= 0 (388) */
/* 390 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 392 */	NdrFcShort( 0x4 ),	/* 4 */
/* 394 */	0x18,		/* 24 */
			0x0,		/*  */
/* 396 */	NdrFcShort( 0x0 ),	/* 0 */
/* 398 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 400 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 402 */	NdrFcShort( 0x4 ),	/* 4 */
/* 404 */	NdrFcShort( 0x0 ),	/* 0 */
/* 406 */	NdrFcShort( 0x1 ),	/* 1 */
/* 408 */	NdrFcShort( 0x0 ),	/* 0 */
/* 410 */	NdrFcShort( 0x0 ),	/* 0 */
/* 412 */	0x12, 0x0,	/* FC_UP */
/* 414 */	NdrFcShort( 0xffffff90 ),	/* Offset= -112 (302) */
/* 416 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 418 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 420 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 422 */	NdrFcShort( 0x8 ),	/* 8 */
/* 424 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 426 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 428 */	NdrFcShort( 0x4 ),	/* 4 */
/* 430 */	NdrFcShort( 0x4 ),	/* 4 */
/* 432 */	0x11, 0x0,	/* FC_RP */
/* 434 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (390) */
/* 436 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 438 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 440 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 442 */	NdrFcShort( 0x0 ),	/* 0 */
/* 444 */	0x18,		/* 24 */
			0x0,		/*  */
/* 446 */	NdrFcShort( 0x0 ),	/* 0 */
/* 448 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 452 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 454 */	NdrFcShort( 0xfffffe3a ),	/* Offset= -454 (0) */
/* 456 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 458 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 460 */	NdrFcShort( 0x8 ),	/* 8 */
/* 462 */	NdrFcShort( 0x0 ),	/* 0 */
/* 464 */	NdrFcShort( 0x6 ),	/* Offset= 6 (470) */
/* 466 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 468 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 470 */	
			0x11, 0x0,	/* FC_RP */
/* 472 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (440) */
/* 474 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 476 */	NdrFcShort( 0x0 ),	/* 0 */
/* 478 */	0x18,		/* 24 */
			0x0,		/*  */
/* 480 */	NdrFcShort( 0x0 ),	/* 0 */
/* 482 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 486 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 488 */	NdrFcShort( 0xffffff50 ),	/* Offset= -176 (312) */
/* 490 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 492 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 494 */	NdrFcShort( 0x8 ),	/* 8 */
/* 496 */	NdrFcShort( 0x0 ),	/* 0 */
/* 498 */	NdrFcShort( 0x6 ),	/* Offset= 6 (504) */
/* 500 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 502 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 504 */	
			0x11, 0x0,	/* FC_RP */
/* 506 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (474) */
/* 508 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 510 */	NdrFcShort( 0x4 ),	/* 4 */
/* 512 */	0x18,		/* 24 */
			0x0,		/*  */
/* 514 */	NdrFcShort( 0x0 ),	/* 0 */
/* 516 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 518 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 520 */	NdrFcShort( 0x4 ),	/* 4 */
/* 522 */	NdrFcShort( 0x0 ),	/* 0 */
/* 524 */	NdrFcShort( 0x1 ),	/* 1 */
/* 526 */	NdrFcShort( 0x0 ),	/* 0 */
/* 528 */	NdrFcShort( 0x0 ),	/* 0 */
/* 530 */	0x12, 0x0,	/* FC_UP */
/* 532 */	NdrFcShort( 0xfa ),	/* Offset= 250 (782) */
/* 534 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 536 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 538 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 540 */	NdrFcShort( 0x8 ),	/* 8 */
/* 542 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 544 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 546 */	NdrFcShort( 0x4 ),	/* 4 */
/* 548 */	NdrFcShort( 0x4 ),	/* 4 */
/* 550 */	0x11, 0x0,	/* FC_RP */
/* 552 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (508) */
/* 554 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 556 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 558 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 560 */	NdrFcShort( 0x1 ),	/* 1 */
/* 562 */	0x19,		/* 25 */
			0x0,		/*  */
/* 564 */	NdrFcShort( 0x0 ),	/* 0 */
/* 566 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 568 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 570 */	NdrFcShort( 0x8 ),	/* 8 */
/* 572 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 574 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 576 */	NdrFcShort( 0x4 ),	/* 4 */
/* 578 */	NdrFcShort( 0x4 ),	/* 4 */
/* 580 */	0x12, 0x0,	/* FC_UP */
/* 582 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (558) */
/* 584 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 586 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 588 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 590 */	NdrFcShort( 0x2 ),	/* 2 */
/* 592 */	0x19,		/* 25 */
			0x0,		/*  */
/* 594 */	NdrFcShort( 0x0 ),	/* 0 */
/* 596 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 598 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 600 */	NdrFcShort( 0x8 ),	/* 8 */
/* 602 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 604 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 606 */	NdrFcShort( 0x4 ),	/* 4 */
/* 608 */	NdrFcShort( 0x4 ),	/* 4 */
/* 610 */	0x12, 0x0,	/* FC_UP */
/* 612 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (588) */
/* 614 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 616 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 618 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 620 */	NdrFcShort( 0x4 ),	/* 4 */
/* 622 */	0x19,		/* 25 */
			0x0,		/*  */
/* 624 */	NdrFcShort( 0x0 ),	/* 0 */
/* 626 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 628 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 630 */	NdrFcShort( 0x8 ),	/* 8 */
/* 632 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 634 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 636 */	NdrFcShort( 0x4 ),	/* 4 */
/* 638 */	NdrFcShort( 0x4 ),	/* 4 */
/* 640 */	0x12, 0x0,	/* FC_UP */
/* 642 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (618) */
/* 644 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 646 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 648 */	
			0x1b,		/* FC_CARRAY */
			0x7,		/* 7 */
/* 650 */	NdrFcShort( 0x8 ),	/* 8 */
/* 652 */	0x19,		/* 25 */
			0x0,		/*  */
/* 654 */	NdrFcShort( 0x0 ),	/* 0 */
/* 656 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 658 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 660 */	NdrFcShort( 0x8 ),	/* 8 */
/* 662 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 664 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 666 */	NdrFcShort( 0x4 ),	/* 4 */
/* 668 */	NdrFcShort( 0x4 ),	/* 4 */
/* 670 */	0x12, 0x0,	/* FC_UP */
/* 672 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (648) */
/* 674 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 676 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 678 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 680 */	NdrFcShort( 0x8 ),	/* 8 */
/* 682 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 684 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 686 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 688 */	NdrFcShort( 0x8 ),	/* 8 */
/* 690 */	0x6,		/* 6 */
			0x0,		/*  */
/* 692 */	NdrFcShort( 0xffffffe8 ),	/* -24 */
/* 694 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 696 */	NdrFcShort( 0xffffffee ),	/* Offset= -18 (678) */
/* 698 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 700 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 702 */	NdrFcShort( 0x18 ),	/* 24 */
/* 704 */	NdrFcShort( 0xffffffee ),	/* Offset= -18 (686) */
/* 706 */	NdrFcShort( 0x0 ),	/* Offset= 0 (706) */
/* 708 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 710 */	0x38,		/* FC_ALIGNM4 */
			0x8,		/* FC_LONG */
/* 712 */	0x8,		/* FC_LONG */
			0x4c,		/* FC_EMBEDDED_COMPLEX */
/* 714 */	0x0,		/* 0 */
			NdrFcShort( 0xfffffe83 ),	/* Offset= -381 (334) */
			0x5b,		/* FC_END */
/* 718 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 720 */	0x2,		/* FC_CHAR */
			0x5c,		/* FC_PAD */
/* 722 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 724 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/* 726 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 728 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 730 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 732 */	0xa,		/* FC_FLOAT */
			0x5c,		/* FC_PAD */
/* 734 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 736 */	0xc,		/* FC_DOUBLE */
			0x5c,		/* FC_PAD */
/* 738 */	
			0x12, 0x0,	/* FC_UP */
/* 740 */	NdrFcShort( 0xfffffe36 ),	/* Offset= -458 (282) */
/* 742 */	
			0x12, 0x10,	/* FC_UP */
/* 744 */	NdrFcShort( 0xfffffe38 ),	/* Offset= -456 (288) */
/* 746 */	
			0x12, 0x10,	/* FC_UP */
/* 748 */	NdrFcShort( 0xfffffd14 ),	/* Offset= -748 (0) */
/* 750 */	
			0x12, 0x10,	/* FC_UP */
/* 752 */	NdrFcShort( 0xfffffe48 ),	/* Offset= -440 (312) */
/* 754 */	
			0x12, 0x10,	/* FC_UP */
/* 756 */	NdrFcShort( 0xfffffe56 ),	/* Offset= -426 (330) */
/* 758 */	
			0x12, 0x10,	/* FC_UP */
/* 760 */	NdrFcShort( 0x2 ),	/* Offset= 2 (762) */
/* 762 */	
			0x12, 0x0,	/* FC_UP */
/* 764 */	NdrFcShort( 0xfffffd04 ),	/* Offset= -764 (0) */
/* 766 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 768 */	NdrFcShort( 0x10 ),	/* 16 */
/* 770 */	0x6,		/* FC_SHORT */
			0x2,		/* FC_CHAR */
/* 772 */	0x2,		/* FC_CHAR */
			0x38,		/* FC_ALIGNM4 */
/* 774 */	0x8,		/* FC_LONG */
			0x39,		/* FC_ALIGNM8 */
/* 776 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 778 */	
			0x12, 0x0,	/* FC_UP */
/* 780 */	NdrFcShort( 0xfffffff2 ),	/* Offset= -14 (766) */
/* 782 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x7,		/* 7 */
/* 784 */	NdrFcShort( 0x20 ),	/* 32 */
/* 786 */	NdrFcShort( 0x0 ),	/* 0 */
/* 788 */	NdrFcShort( 0x0 ),	/* Offset= 0 (788) */
/* 790 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 792 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 794 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 796 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 798 */	NdrFcShort( 0xfffffcf8 ),	/* Offset= -776 (22) */
/* 800 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 802 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 804 */	NdrFcShort( 0x0 ),	/* 0 */
/* 806 */	NdrFcShort( 0x10 ),	/* 16 */
/* 808 */	NdrFcShort( 0x0 ),	/* 0 */
/* 810 */	NdrFcShort( 0xfffffce8 ),	/* Offset= -792 (18) */

			0x0
        }
    };

const CInterfaceProxyVtbl * _ASPFile_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_IGetFileProxyVtbl,
    0
};

const CInterfaceStubVtbl * _ASPFile_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_IGetFileStubVtbl,
    0
};

PCInterfaceName const _ASPFile_InterfaceNamesList[] = 
{
    "IGetFile",
    0
};

const IID *  _ASPFile_BaseIIDList[] = 
{
    &IID_IDispatch,
    0
};


#define _ASPFile_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _ASPFile, pIID, n)

int __stdcall _ASPFile_IID_Lookup( const IID * pIID, int * pIndex )
{
    
    if(!_ASPFile_CHECK_IID(0))
        {
        *pIndex = 0;
        return 1;
        }

    return 0;
}

const ExtendedProxyFileInfo ASPFile_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _ASPFile_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _ASPFile_StubVtblList,
    (const PCInterfaceName * ) & _ASPFile_InterfaceNamesList,
    (const IID ** ) & _ASPFile_BaseIIDList,
    & _ASPFile_IID_Lookup, 
    1,
    2
};
