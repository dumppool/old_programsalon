/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Jul 21 08:39:52 2000
 */
/* Compiler settings for D:\RADAR\InetUtil\INetUtil.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __INetUtil_h__
#define __INetUtil_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IUploader_FWD_DEFINED__
#define __IUploader_FWD_DEFINED__
typedef interface IUploader IUploader;
#endif 	/* __IUploader_FWD_DEFINED__ */


#ifndef __Uploader_FWD_DEFINED__
#define __Uploader_FWD_DEFINED__

#ifdef __cplusplus
typedef class Uploader Uploader;
#else
typedef struct Uploader Uploader;
#endif /* __cplusplus */

#endif 	/* __Uploader_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IUploader_INTERFACE_DEFINED__
#define __IUploader_INTERFACE_DEFINED__

/* interface IUploader */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IUploader;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("765F26CA-DF06-4907-9FBB-512704F9499D")
    IUploader : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE StartUpload( 
            /* [in] */ IUnknown __RPC_FAR *pIUnk) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetDestinationPath( 
            /* [in] */ BSTR bsPath) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetError( 
            /* [in] */ long lError,
            /* [retval][out] */ BSTR __RPC_FAR *psReturn) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetMaxFileSize( 
            /* [in] */ long lSize) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetFormValue( 
            /* [in] */ BSTR bsFieldName,
            /* [retval][out] */ BSTR __RPC_FAR *psReturn) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE UploadFile( 
            /* [in] */ BSTR bsFieldName,
            /* [retval][out] */ long __RPC_FAR *plResult) = 0;
        
        virtual /* [vararg][helpstring][id] */ HRESULT STDMETHODCALLTYPE SetAllowedExtensions( 
            /* [in] */ SAFEARRAY __RPC_FAR * FileExtensions) = 0;
        
        virtual /* [vararg][helpstring][id] */ HRESULT STDMETHODCALLTYPE SetForbiddenExtensions( 
            /* [in] */ SAFEARRAY __RPC_FAR * FileExtensions) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetUploadFilename( 
            /* [in] */ BSTR bsField,
            /* [retval][out] */ BSTR __RPC_FAR *pbsFilename) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUploaderVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IUploader __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IUploader __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IUploader __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IUploader __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IUploader __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IUploader __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IUploader __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *StartUpload )( 
            IUploader __RPC_FAR * This,
            /* [in] */ IUnknown __RPC_FAR *pIUnk);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDestinationPath )( 
            IUploader __RPC_FAR * This,
            /* [in] */ BSTR bsPath);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetError )( 
            IUploader __RPC_FAR * This,
            /* [in] */ long lError,
            /* [retval][out] */ BSTR __RPC_FAR *psReturn);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetMaxFileSize )( 
            IUploader __RPC_FAR * This,
            /* [in] */ long lSize);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetFormValue )( 
            IUploader __RPC_FAR * This,
            /* [in] */ BSTR bsFieldName,
            /* [retval][out] */ BSTR __RPC_FAR *psReturn);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UploadFile )( 
            IUploader __RPC_FAR * This,
            /* [in] */ BSTR bsFieldName,
            /* [retval][out] */ long __RPC_FAR *plResult);
        
        /* [vararg][helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetAllowedExtensions )( 
            IUploader __RPC_FAR * This,
            /* [in] */ SAFEARRAY __RPC_FAR * FileExtensions);
        
        /* [vararg][helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetForbiddenExtensions )( 
            IUploader __RPC_FAR * This,
            /* [in] */ SAFEARRAY __RPC_FAR * FileExtensions);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetUploadFilename )( 
            IUploader __RPC_FAR * This,
            /* [in] */ BSTR bsField,
            /* [retval][out] */ BSTR __RPC_FAR *pbsFilename);
        
        END_INTERFACE
    } IUploaderVtbl;

    interface IUploader
    {
        CONST_VTBL struct IUploaderVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUploader_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IUploader_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IUploader_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IUploader_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IUploader_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IUploader_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IUploader_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IUploader_StartUpload(This,pIUnk)	\
    (This)->lpVtbl -> StartUpload(This,pIUnk)

#define IUploader_SetDestinationPath(This,bsPath)	\
    (This)->lpVtbl -> SetDestinationPath(This,bsPath)

#define IUploader_GetError(This,lError,psReturn)	\
    (This)->lpVtbl -> GetError(This,lError,psReturn)

#define IUploader_SetMaxFileSize(This,lSize)	\
    (This)->lpVtbl -> SetMaxFileSize(This,lSize)

#define IUploader_GetFormValue(This,bsFieldName,psReturn)	\
    (This)->lpVtbl -> GetFormValue(This,bsFieldName,psReturn)

#define IUploader_UploadFile(This,bsFieldName,plResult)	\
    (This)->lpVtbl -> UploadFile(This,bsFieldName,plResult)

#define IUploader_SetAllowedExtensions(This,FileExtensions)	\
    (This)->lpVtbl -> SetAllowedExtensions(This,FileExtensions)

#define IUploader_SetForbiddenExtensions(This,FileExtensions)	\
    (This)->lpVtbl -> SetForbiddenExtensions(This,FileExtensions)

#define IUploader_GetUploadFilename(This,bsField,pbsFilename)	\
    (This)->lpVtbl -> GetUploadFilename(This,bsField,pbsFilename)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUploader_StartUpload_Proxy( 
    IUploader __RPC_FAR * This,
    /* [in] */ IUnknown __RPC_FAR *pIUnk);


void __RPC_STUB IUploader_StartUpload_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUploader_SetDestinationPath_Proxy( 
    IUploader __RPC_FAR * This,
    /* [in] */ BSTR bsPath);


void __RPC_STUB IUploader_SetDestinationPath_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUploader_GetError_Proxy( 
    IUploader __RPC_FAR * This,
    /* [in] */ long lError,
    /* [retval][out] */ BSTR __RPC_FAR *psReturn);


void __RPC_STUB IUploader_GetError_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUploader_SetMaxFileSize_Proxy( 
    IUploader __RPC_FAR * This,
    /* [in] */ long lSize);


void __RPC_STUB IUploader_SetMaxFileSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUploader_GetFormValue_Proxy( 
    IUploader __RPC_FAR * This,
    /* [in] */ BSTR bsFieldName,
    /* [retval][out] */ BSTR __RPC_FAR *psReturn);


void __RPC_STUB IUploader_GetFormValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUploader_UploadFile_Proxy( 
    IUploader __RPC_FAR * This,
    /* [in] */ BSTR bsFieldName,
    /* [retval][out] */ long __RPC_FAR *plResult);


void __RPC_STUB IUploader_UploadFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [vararg][helpstring][id] */ HRESULT STDMETHODCALLTYPE IUploader_SetAllowedExtensions_Proxy( 
    IUploader __RPC_FAR * This,
    /* [in] */ SAFEARRAY __RPC_FAR * FileExtensions);


void __RPC_STUB IUploader_SetAllowedExtensions_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [vararg][helpstring][id] */ HRESULT STDMETHODCALLTYPE IUploader_SetForbiddenExtensions_Proxy( 
    IUploader __RPC_FAR * This,
    /* [in] */ SAFEARRAY __RPC_FAR * FileExtensions);


void __RPC_STUB IUploader_SetForbiddenExtensions_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUploader_GetUploadFilename_Proxy( 
    IUploader __RPC_FAR * This,
    /* [in] */ BSTR bsField,
    /* [retval][out] */ BSTR __RPC_FAR *pbsFilename);


void __RPC_STUB IUploader_GetUploadFilename_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IUploader_INTERFACE_DEFINED__ */



#ifndef __INETUTILLib_LIBRARY_DEFINED__
#define __INETUTILLib_LIBRARY_DEFINED__

/* library INETUTILLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_INETUTILLib;

EXTERN_C const CLSID CLSID_Uploader;

#ifdef __cplusplus

class DECLSPEC_UUID("12EFE37D-15DD-407D-B5C0-9AFA40682363")
Uploader;
#endif
#endif /* __INETUTILLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  LPSAFEARRAY_UserSize(     unsigned long __RPC_FAR *, unsigned long            , LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
void                      __RPC_USER  LPSAFEARRAY_UserFree(     unsigned long __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
