// UploaderBase.h: interface for the CUploaderBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UPLOADERBASE_H__07CCF073_3DEA_11D4_84F6_00A0C9B6FB28__INCLUDED_)
#define AFX_UPLOADERBASE_H__07CCF073_3DEA_11D4_84F6_00A0C9B6FB28__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <asptlb.h>


class CUploaderBase  
{
public:
	CUploaderBase();
	virtual ~CUploaderBase();

	HRESULT StartUpload(IRequest* pIRequest);

	HRESULT SetAllowedExtensions(const SAFEARRAY* psarray);
	HRESULT SetForbiddenExtensions(const SAFEARRAY* psarray);

	HRESULT SetMaxFileSize(long lMaxSize);
	HRESULT SetDestinationPath(BSTR bsDestinationPath);
	HRESULT GetError(long lError, BSTR* pbsReturn);

	HRESULT GetFormValue(CString sFieldName, BSTR* pbsReturn);
	HRESULT UploadFile(CString sFieldName, long* plResult);

	HRESULT GetUploadFilename(CString sFieldName, BSTR* pbsReturn);

protected:	
	BOOL FileExtensionAllowed(LPCTSTR lpszExtension);

	long    m_lMaxSize;
	CString m_sDestPath;
	CStringList m_ExtensionList;
	CStringList m_ForbiddenList;

	LPBYTE  m_lpBytesData; 
	long    m_lDataSize;
	CString m_sHeader;
	CString m_sDelimiter;


};

#endif // !defined(AFX_UPLOADERBASE_H__07CCF073_3DEA_11D4_84F6_00A0C9B6FB28__INCLUDED_)
