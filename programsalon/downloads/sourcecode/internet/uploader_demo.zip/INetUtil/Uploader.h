// Uploader.h : Declaration of the CUploader

#ifndef __UPLOADER_H_
#define __UPLOADER_H_

#include "resource.h"       // main symbols
#include "UploaderBase.h"


/////////////////////////////////////////////////////////////////////////////
// CUploader
class ATL_NO_VTABLE CUploader : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CUploader, &CLSID_Uploader>,
	public IDispatchImpl<IUploader, &IID_IUploader, &LIBID_INETUTILLib>
{
public:
	CUploader()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_UPLOADER)
DECLARE_NOT_AGGREGATABLE(CUploader)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CUploader)
	COM_INTERFACE_ENTRY(IUploader)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

protected:
	CUploaderBase m_uploaderImp;

// IUploader
public:
	STDMETHOD(GetUploadFilename)(/*[in]*/ BSTR bsField, /*[out, retval]*/ BSTR* pbsFilename);
	STDMETHOD(SetAllowedExtensions)(/*[in]*/  SAFEARRAY* psarray);
	STDMETHOD(SetForbiddenExtensions)(/*[in]*/  SAFEARRAY* psarray);
	STDMETHOD(UploadFile)(/*[in]*/ BSTR bsFieldName, /*[out, retval]*/ long* plResult);
	STDMETHOD(GetFormValue)(/*[in]*/ BSTR bsFieldName, /*[out, retval]*/ BSTR* psReturn);
	STDMETHOD(SetMaxFileSize)(/*[in]*/ long lSize);
	STDMETHOD(GetError)(/*[in]*/ long lError, /*[out, retval]*/ BSTR* psReturn);
	STDMETHOD(SetDestinationPath)(/*[in]*/ BSTR bsPath);
	STDMETHOD(StartUpload)(/*[in]*/IUnknown* pIUnk);
};

#endif //__UPLOADER_H_
