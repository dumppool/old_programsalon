// Uploader.cpp : Implementation of CUploader
#include "stdafx.h"
#include "INetUtil.h"
#include "Uploader.h"

/////////////////////////////////////////////////////////////////////////////
// CUploader


STDMETHODIMP CUploader::StartUpload(IUnknown *pIUnk)
{
	// TODO: Add your implementation code here
	IRequest* pIRequest;
	HRESULT hr = pIUnk->QueryInterface(IID_IRequest, 
						reinterpret_cast<LPVOID*>(&pIRequest));

	if (SUCCEEDED(hr))
	{
		hr = m_uploaderImp.StartUpload(pIRequest);

		pIRequest->Release();

		return hr;
	}

	return S_OK;
}

STDMETHODIMP CUploader::SetDestinationPath(BSTR bsPath)
{
	// TODO: Add your implementation code here

	return m_uploaderImp.SetDestinationPath(bsPath);
}

STDMETHODIMP CUploader::GetError(long lError, BSTR *psReturn)
{
	// TODO: Add your implementation code here

	return m_uploaderImp.GetError(lError, psReturn);
}

STDMETHODIMP CUploader::SetMaxFileSize(long lSize)
{
	// TODO: Add your implementation code here

	return m_uploaderImp.SetMaxFileSize(lSize);
}

STDMETHODIMP CUploader::GetFormValue(BSTR bsFieldName, BSTR *pbsReturn)
{
	// TODO: Add your implementation code here

	return m_uploaderImp.GetFormValue(bsFieldName, pbsReturn);
}

STDMETHODIMP CUploader::UploadFile(BSTR bsFieldName, long *plResult)
{
	// TODO: Add your implementation code here

	return m_uploaderImp.UploadFile(bsFieldName, plResult);
}

STDMETHODIMP CUploader::SetAllowedExtensions(SAFEARRAY* psarray)
{
	// TODO: Add your implementation code here

	return m_uploaderImp.SetAllowedExtensions(psarray);
}

STDMETHODIMP CUploader::SetForbiddenExtensions(SAFEARRAY* psarray)
{
	// TODO: Add your implementation code here

	return m_uploaderImp.SetForbiddenExtensions(psarray);
}


STDMETHODIMP CUploader::GetUploadFilename(BSTR bsField, BSTR* pbsFilename)
{
	// TODO: Add your implementation code here

	return m_uploaderImp.GetUploadFilename(bsField, pbsFilename);
}
