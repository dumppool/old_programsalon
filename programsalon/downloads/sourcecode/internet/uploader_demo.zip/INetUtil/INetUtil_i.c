/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Jul 21 08:39:52 2000
 */
/* Compiler settings for D:\RADAR\InetUtil\INetUtil.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IUploader = {0x765F26CA,0xDF06,0x4907,{0x9F,0xBB,0x51,0x27,0x04,0xF9,0x49,0x9D}};


const IID LIBID_INETUTILLib = {0xD9040CA1,0x69BD,0x4A5A,{0x89,0x20,0x07,0xDF,0xAB,0x41,0xF8,0xB0}};


const CLSID CLSID_Uploader = {0x12EFE37D,0x15DD,0x407D,{0xB5,0xC0,0x9A,0xFA,0x40,0x68,0x23,0x63}};


#ifdef __cplusplus
}
#endif

