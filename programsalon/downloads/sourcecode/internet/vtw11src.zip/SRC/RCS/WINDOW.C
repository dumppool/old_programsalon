head	2.3;
access;
symbols;
locks; strict;
comment	@ * @;


2.3
date	96.02.04.23.24.43;	author tsurace;	state Release;
branches;
next	2.2;

2.2
date	95.10.27.20.02.39;	author tsurace;	state Beta;
branches;
next	2.1;

2.1
date	95.10.24.15.46.14;	author tsurace;	state Exp;
branches;
next	1.1;

1.1
date	95.10.12.21.37.13;	author tsurace;	state Beta;
branches;
next	;


desc
@Window management routines.
@


2.3
log
@Removed some optimizations that were causing problems.
Added some somments.
(Note: command-line editor is still partially broken.)
@
text
@/* window.c - Handle I/O to terminal */
/* $Id: window.c 2.2 1995/10/27 20:02:39 tsurace Beta tsurace $ */

#include "vt.h"
#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>

#ifdef __WIN32__
# include "win32/replace.h" /* user i/o routines */
#else /* __WIN32__ */
# include <sys/ioctl.h>
#endif /* __WIN32__ */

#ifdef USE_STDARG
#include <stdarg.h>
#else
#include <varargs.h>
#endif

#ifdef hpux
#include <termio.h>
#else /* not HP-UX */
#ifdef SYSVTTY
#include <termio.h>
#else /* not SYSVTTY */
#ifdef __WIN32__
#else /* not __WIN32__, probably BSD */
# include <sgtty.h>
#endif
#endif
#endif

#ifdef PROTOTYPES
#ifdef TERMCAP
static void chrpt(int, int);
static void get_ospeed(void);
static void output_one(int);
static void getccap(char *, char *);
static void tp(char *, int);
#endif /* TERMCAP */
static void cap_formatted(char *, int, int);
static void clear_end(void);
static void clear_space(int, int);
static void move_left(int, int);
static void init_window(Unode *, int, int);
static void mark(Unode *, int);
static void draw_prompt(void);
static void clear_input_window(void);
static void chrpt(int c, int num);
void draw_Divider(Unode *win);
#else /* not PROTOTYPES */
#ifdef TERMCAP
static void get_ospeed(), output_one(), getccap(), tp();
#endif /* TERMCAP */
static void chrpt(), cap_formatted(), clear_end(), clear_space(), move_left();
static void init_window(), mark(), draw_prompt(), clear_input_window();
#endif /* not PROTOTYPES */

extern int errno;
extern char *sys_errlist[];

/* Global variables and externs for the terminal routines */

/* The termcap library has no length-checking facilities.  We use 32
** bytes for a string that's not pre-compiled with tputs(), and 64
** bytes for one that is.  This is somewhat kludgy, but then, so are
** the termcap routines. */
static char s_cmove[32];		/* Move cursor		 */
static char s_scroll[32];		/* Set scroll area	 */
static char s_scr_rev[32];		/* Scroll region reverse */
char s_clrscr[64];			/* Clear screen		 */
char s_clreol[64];			/* Clear to end of line	 */
char s_bold_on[64];			/* Turn boldface on	 */
char s_bold_off[64];			/* Turn boldface off	 */

#ifdef HARDCODE
#define HC_CMOVE    "\033[%d;%dH"
#define HC_SCROLL   "\033[%d;%dr"
#define HC_SCR_REV  "\033M"
#define HC_CLRSCR   "\033[2J"
#define HC_CLREOL   "\033[K"
#define HC_BOLD_ON  "\033[1m"
#define HC_BOLD_OFF "\033[m"
#define cap_normal(x, y) Bwritea(x)
#endif
#define HC_ROWS 24
#define HC_COLS 80

int rows = 0, cols = 0;			/* Screen size	       */
static int scr_top = -1, scr_bot = -1;	/* Current scroll area */
#ifdef TERMCAP
static char *cptr;
extern char *tgetstr(), *tgoto();
#ifndef AIX
extern short ospeed;
#endif /* not AIX */
#define cap_normal(x, y) tp(x, y)
#endif /* TERMCAP */

/* Global variables for windowing routines */

#define CURS_INPUT	0
#define CURS_WINDOW	1
#define CURS_ELSEWHERE	2

Unode win_ring;				/* Dummy node in windows ring */
Unode *active_win;			/* Keyboard text is sent here */
Unode *cur_win = NULL;			/* Where text is being processed */
int curs_loc = CURS_ELSEWHERE;		/* General idea of where cursor is */
static Unode *curs_win;			/* More info for CURS_WINDOW pos */
extern Unode *cur_rmt;
static String outbuf = { { "", 0 }, 0 };/* Output buffering */

#define Die(s) if (1) { puts(s); exit(1); } else
#define Bwrite(cstr)	s_cat(&outbuf, cstr)
#define Bwritea(s)	s_acat(&outbuf, s)
#define Bwriteal(s, l)	s_cat(&outbuf, cstr_sl(s, l))
#define Bwritem(s, y, z) Bwriteal(s, min(y, z))
#define Bputch(c)	s_add(&outbuf, c)
#define Bflush		if (1) { vtwrite(outbuf.c); s_term(&outbuf, 0); } else
#define BputEOLN()     s_add(&outbuf, '\n')

void bflushfunc() { Bflush; }

/* Global variables for input routines */

int icol;				/* Column of cursor on bottom line */
char *prompt;				/* Text of prompt */
int plen = 0;				/* Length of prompt */
int vtc_mode = 0;			/* Flag: input window in VTC mode */
extern String kbuf;
extern int kpos;
static int echo_mode = 1;
static int ign_echo_mode = 0;

#define Divider (win_ring.prev->Wbot + 1)
#define Margin (cols - 1)
#define Round(x, y) ((x) - (x) % (y))
#define Klen (kbuf.c.l)
#define Kptr (kbuf.c.s)
#define Oplen (vtc_mode ? 0 : plen)
# define Iclear_end  clear_end()
# define Iclear_space(top,bot) clear_space(top,rows-(bot))
# define Icmove(x, y) cmove((x),rows-(y)) // Y is rows up from the bottom
# define Imove_left(count, x) move_left((count), (x))
# define Isize (rows - Itop)
# define Itop (Divider + 1)
# define Iscr_rev if (1) { \
	if (Isize > 1) { scroll(Itop, rows - 1); scr_rev(1); } \
	else { cmove(0, rows - 1); Bwritea(s_clreol); } \
} else
# define Iscr_fwd if (1) { \
	if (Isize > 1) { scroll(Itop, rows - 1); scr_fwd(1); } \
	else { cmove(0, rows - 1); Bwritea(s_clreol); } \
} else
# define IBwrite   Bwrite
# define IBwritea  Bwritea
# define IBwriteal Bwriteal
# define IBwritem  Bwritem
# define IBputch   Bputch
# define IBputEOLN InWin_puts("\n")
# define IBflush   Bflush

/* Low-level I/O */

void vtwrite(cstr)
	Cstr cstr;
{
	int written;
    
#ifdef __WIN32__ 
    /* Send output to "console" window */
    WriteString(cstr.s, cstr.l);
#else
	while (cstr.l > 0) {
		written = write(1, cstr.s, cstr.l);
		if (written == -1) {
			if (errno != EWOULDBLOCK && errno != EINTR) {
				perror("write");
				vterror("Write failed in vtwrite()");
			}
			written = 0;
		}
		cstr = cstr_sl(cstr.s + written, cstr.l - written);
		if (cstr.l)
			sleep(1);
	}
    
#endif /* __WIN32__ */
}

static void chrpt(c, num)
	int c, num;
{
	while (num-- > 0)
		Bputch(c);
}

#ifdef __WIN32__
/* getch() is in replace.cpp */
#else /* not __WIN32__ */
int getch()
{
	char c;
	int rs;

	while ((rs = read(0, &c, 1)) <= 0) {
		if (rs < 0 && errno != EINTR) {
			perror("read");
			vterror("Read failed in getch()");
		}
	}
	return c;
}
#endif /* __WIN32__ */

void tty_mode(state)
	int state;
{
	char * ign_teln_echo;

#ifdef hpux
	struct termio blob;

	if (ioctl(0, TCGETA, &blob) == -1) {
		perror("TCGETA ioctl()");
		exit(1);
	}
	if (state) {
		blob.c_lflag &= ~ECHO;
		blob.c_lflag &= ~ECHOE;
		blob.c_lflag &= ~ICANON;
		blob.c_cc[VMIN] = 0;
		blob.c_cc[VTIME] = 0;
	} else {
		blob.c_lflag |= ECHO;
		blob.c_lflag |= ECHOE;
		blob.c_lflag |= ICANON;
	}
	ioctl(0, TCSETAF, &blob);
#else /* Not HP-UX */
#ifdef SYSVTTY
	struct termio blob;
	static struct termio old_tty_state;
	static int first = 1;

	if (first) {
		ioctl(0, TCGETA, &old_tty_state);
		first = 0;
	}
	if (state) {
		ioctl(0, TCGETA, &blob);
		blob.c_cc[VMIN] = 0;
		blob.c_cc[VTIME] = 0;
		blob.c_iflag = IGNBRK | IGNPAR | ICRNL;
		blob.c_oflag = OPOST | ONLCR;
		blob.c_lflag = ISIG;
		ioctl(0, TCSETA, &blob);
	} else if (!first)
		ioctl(0, TCSETA, &old_tty_state);
#else
#ifdef __WIN32__
        /* If state != 0, disable echo to screen and
           ctrl-c, otherwise enable it */
#else /* BSD */
	struct sgttyb blob;

	if (ioctl(0, TIOCGETP, &blob) == -1) {
		perror("TIOCGETP ioctl()");
		exit(1);
	}
	blob.sg_flags |= state ? CBREAK : ECHO;
	blob.sg_flags &= state ? ~ECHO : ~CBREAK;
	ioctl(0, TIOCSETP, &blob);
#endif
#endif
#endif
	/* Flag to ignore telnet echo_on, echo_off commands */
	ign_teln_echo = getenv("VT_IGN_ECHO");
	if(ign_teln_echo  && !strcmp(ign_teln_echo,"YES") )
		ign_echo_mode = 1;
}

/* Terminal routines */

#ifdef TERMCAP
static void get_ospeed()
{
#ifndef hpux
#ifndef AIX
#ifndef linux
	struct sgttyb sgttyb;

	ioctl(0, TIOCGETP, &sgttyb);
	ospeed = sgttyb.sg_ospeed;
#endif /* linux */
#endif
#endif
}

static void output_one(c)
	int c;
{
	*cptr++ = c;
}

static void gettcap(dest, cap)
	char *dest, *cap;
{
	char buffer[256];
	if (!tgetstr(cap, &dest))
	{
		sprintf(buffer, "Termcap cannot find %s",cap);
		Die(buffer);
	};
}

static void getccap(dest, cap)
	char *dest, *cap;
{
	char temp[64];

	gettcap(temp, cap);
	cptr = dest;
	tputs(temp, 1, output_one);
	*cptr = '\0';
}
#endif /* TERMCAP */

void init_term()
{
#ifdef HARDCODE
	strcpy(s_cmove	  , HC_CMOVE   );
	strcpy(s_scroll	  , HC_SCROLL  );
	strcpy(s_scr_rev  , HC_SCR_REV );
	strcpy(s_clrscr	  , HC_CLRSCR  );
	strcpy(s_clreol	  , HC_CLREOL  );
	strcpy(s_bold_on  , HC_BOLD_ON );
	strcpy(s_bold_off , HC_BOLD_OFF);
	rows = HC_ROWS;
	cols = HC_COLS;
#else /* HARDCODE not defined */
	char tinfo[1024], *termname, *bon, *boff;

	bon = getenv("VTBOLDON");
	if (!bon)
		bon = "so";
	boff = getenv("VTBOLDOFF");
	if (!boff)
		boff = "se";
	termname = getenv("TERM");
	if (!termname)
		Die("TERM not set");
	if (tgetent(tinfo, termname) != 1)
		Die("Terminal type not defined.");
	rows = tgetnum("li");
	if (rows == -1)
		rows = HC_ROWS;
	cols = tgetnum("co");
	if (cols == -1)
		cols = HC_COLS;
	get_ospeed();
	gettcap(s_cmove	   , "cm");
	gettcap(s_scroll   , "cs");
	gettcap(s_scr_rev  , "sr");
	getccap(s_clrscr   , "cl");
	getccap(s_clreol   , "ce");
	getccap(s_bold_on  , bon);
	getccap(s_bold_off , boff);
#endif /* HARDCODE not defined */
#ifdef TIOCGWINSZ
	{
		struct winsize size;

		ioctl(0, TIOCGWINSZ, &size);
		if (size.ws_row && size.ws_col) {
			rows = size.ws_row;
			cols = size.ws_col;
		}
	}
#else /* TIOCGWINSZ */
#ifdef __WIN32__
        rows = 35; /* Default size */
        cols = 80;
#endif /* __WIN32__ */
#endif /* TIOCGWINSZ */
	prompt = vtstrdup("");
}

#ifdef TERMCAP
static void bfuncputch(c) int c; { s_fadd(&outbuf, c); }
static void tp(s, affcnt)
	char *s;
	int affcnt;
{
	tputs(s, affcnt, bfuncputch);
	s_nt(&outbuf);
}
#endif

static void cap_formatted(cbuf, arg1, arg2)
	char *cbuf;
	int arg1, arg2;
{
#ifdef HARDCODE
	static char buffer[24];

	sprintf(buffer, cbuf, arg2 + 1, arg1 + 1);
	Bwritea(buffer);
#else
	tp(tgoto(cbuf, arg1, arg2), 1);
#endif
}

void cmove(col, row)
	int col, row;
{
    assert(col < cols); /* col out of range */
    assert(col >= 0);
    assert(row < rows); /* row out of range */
    assert(row >= 0);
    
    cap_formatted(s_cmove, col, row);
}

/* Set the current scroll area */
void scroll(top, bottom)
	int top, bottom;
{
	if (scr_top == top && scr_bot == bottom)
		return;
	cap_formatted(s_scroll, bottom, top);
	scr_top = top;
	scr_bot = bottom;
}

/* scroll the current area forward */
void scr_fwd(num)
	int num;
{
	cmove(0, scr_bot);
	while (num--)
		BputEOLN();
}

/* Scroll the current scroll area backwards num lines */
void scr_rev(num)
	int num;
{
	cmove(0, scr_top);
	while (num--)
		cap_normal(s_scr_rev, scr_bot - scr_top + 1);
}

/* Slightly higher-level termcap routines */

/* clear_end - clear to end of line
 *
 * Optimization is dangerous.  Putting a space/backspace combo can
 * cause scrolling on the last line of the screen
 */
static void clear_end()
{
    Bwritea(s_clreol);
}


/* Clear horizontally a range of rows  */
static void clear_space(top, bottom)
	int top, bottom;
{
	int i;

	scroll(0, rows - 1);
	cmove(0, top);
	Bwritea(s_clreol);
	for (i = top; i < bottom; i++) {
		BputEOLN();
		Bwritea(s_clreol);
	}
	Bflush;
}

static void move_left(n, new)
	int n, new;
{
	if (n < 7)
		chrpt('\010', n);
	else
		cmove(new, rows - 1);
}

/* Windowing routines */

/* Ensure that cursor and scroll area are in window */
void curs_window(win)
	Unode *win;
{
	if (curs_loc == CURS_WINDOW && curs_win == win)
		return;
	scroll(win->Wtop, win->Wbot);
	cmove(win->Wcol, win->Wbot);
	Bflush;
	curs_loc = CURS_WINDOW;
	curs_win = win;
}

/* Ensure that cursor is in input window */
void curs_input()
{
	if (curs_loc == CURS_INPUT)
		return;
	cmove(icol, rows - 1);
	Bflush;
	curs_loc = CURS_INPUT;
}

static void init_window(win, top, bottom)
	Unode *win;
	int top, bottom;
{
	win->Wtop = top;
	win->Wbot = bottom;
	win->Wcol = win->Wnl = 0;
	win->Wrmt = NULL;
	win->Wtermread = NULL;
	win->Wobj = NULL;
	win->Wghstack = NULL;
	win->Wglstack = NULL;
	win->Wrstack = NULL;
}

void draw_Divider(win)
	Unode *win;
{
	scroll(0, rows - 1);
	cmove(0, win->Wbot + 1);
	Bputch((win == active_win) ? '*' : '_');
	chrpt('_', win->next->dummy ? cols - 6 : cols - 1);
	if (win->next->dummy)
		Bwritea(vtc_mode ? "VTC__" : "Text_");
	Bflush;
	curs_loc = CURS_ELSEWHERE;
}

void toggle_imode()
{
        scroll(0, rows - 1);
	vtc_mode = !vtc_mode;
	cmove(cols - 5, Divider);
	Bwritea(vtc_mode ? "VTC__" : "Text_");
	curs_loc = CURS_ELSEWHERE;
	if (plen) {
		clear_input_window();
		draw_prompt();
		input_draw();
	}
}

static void mark(win, value)
	Unode *win;
	int value;
{
	cmove(0, win->Wbot + 1);
	Bputch(value ? '*' : '_');
	Bflush;
	curs_loc = CURS_ELSEWHERE;
}

void init_screen()
{
	Unode *first_win;
	int w_bottom; /* bottom of initial window */
        w_bottom = rows - 5;

	first_win = unalloc();
	init_window(first_win, 0, w_bottom);
	win_ring.next = win_ring.prev = first_win;
	win_ring.dummy = 1;
	first_win->next = first_win->prev = &win_ring;
	active_win = first_win;
	Bwritea(s_clrscr);
	draw_Divider(first_win);
}

void redraw_screen()
{
	Unode *wp;

	Bwritea(s_clrscr);
	for (wp = win_ring.next; !wp->dummy; wp = wp->next)
		draw_Divider(wp);
	cmove(0, rows - 1);
	draw_prompt();
	input_draw();
}

void auto_redraw()
{
	Func *func;

	func = find_func("redraw_hook");
	if (func && func->cmd)
		run_prog(func->cmd);
	else
		redraw_screen();
}

Unode *split_window(win, loc)
	Unode *win;
	int loc;
{
	Unode *new;

	new = unalloc();
	init_window(new, win->Wtop, loc - 1);
	win->Wtop = loc + 1;
	new->prev = win->prev;
	new->next = win;
	win->prev = win->prev->next = new;
	clear_space(new->Wtop, new->Wbot);
	draw_Divider(new);
	return new;
}

void close_window(win, dir)
	Unode *win;
	int dir;
{
	Unode *into;

	if (dir < 0) {
		into = win->prev;
		scroll(into->Wtop, win->Wbot + 1);
		scr_rev(win->Wbot - into->Wbot);
		into->Wbot = win->Wbot;
		if (win->next->dummy) {
			cmove(cols - 5, Divider);
			Bwritea(vtc_mode ? "VTC__" : "Text_");
		}
		Bflush;
	} else {
		into = win->next;
		clear_space(win->Wtop, win->Wbot + 1);
		into->Wtop = win->Wtop;
	}
	if (win->Wrmt)
		win->Wrmt->Rwin = NULL;
	if (active_win == win) {
		active_win = into;
		mark(into, 1);
	}
	if (cur_win == win)
		cur_win = NULL;
	win->prev->next = win->next;
	win->next->prev = win->prev;
	destroy_pointers(win->frefs);
	break_pipe(win->Wghstack);
	break_pipe(win->Wglstack);
	break_pipe(win->Wrstack);
	discard_unode(win);
	curs_loc = CURS_ELSEWHERE;
}

void resize_window(win, row)
	Unode *win;
	int row;
{
	if (row - 1 > win->Wbot) {
		scroll(win->Wtop, row);
		scr_rev(row - win->Wbot - 1);
	} else if (row - 1 < win->Wbot) {
		scroll(win->Wtop, win->Wbot + 1);
		scr_fwd(win->Wbot - row + 1);
	}
	Bflush;
	win->next->Wtop = row + 1;
	win->Wbot = row - 1;
	curs_loc = CURS_ELSEWHERE;
}

void new_active_win(win)
	Unode *win;
{
	if (win == active_win)
		return;
	mark(active_win, 0);
	mark(win, 1);
	active_win = win;
	curs_loc = CURS_ELSEWHERE;
	update_echo_mode();
}

void resize_screen(new_rows, new_cols)
	int new_rows, new_cols;
{
	int new_Isize, new_ospace, old_ospace, pos = 0, used = 0, overrun;
	int num_wins = 0, size, decr = 0;
	Unode *w;

	if (new_rows < 4 || new_cols < 15)
		vtdie("Screen size too small");
	for (w = win_ring.next; !w->dummy; w = w->next, num_wins++);
	old_ospace = rows - Isize - num_wins;
	while (num_wins > (new_rows - 1) / 3) {
		w = win_ring.prev;
		if (w->Wrmt)
			w->Wrmt->Rwin = NULL;
		if (active_win == w)
			active_win = w->prev;
		if (cur_win == w)
		    cur_win = NULL;
		w->prev->next = &win_ring;
		win_ring.prev = w->prev;
		destroy_pointers(w->frefs);
		destroy_pipe(w->Wghstack);
		destroy_pipe(w->Wglstack);
		destroy_pipe(w->Wrstack);
		discard_unode(w);
		num_wins--;
	}
	new_Isize = min(Isize, new_rows - num_wins * 3);
	new_ospace = new_rows - new_Isize - num_wins;
	for (w = win_ring.next; !w->dummy; w = w->next) {
		size = ((w->Wbot - w->Wtop + 1) * new_ospace
		       + old_ospace / 2) / old_ospace;
		size = max(size, 2);
		w->Wtop = pos;
		w->Wbot = pos + size - 1;
		pos += size + 1;
		used += size;
	}
	overrun = used - new_ospace;
	for (w = win_ring.next; !w->dummy; w = w->next) {
		w->Wtop -= decr;
		w->Wbot -= decr;
		if (overrun > 0 && w->Wbot - w->Wtop > 1) {
			w->Wbot--;
			decr++;
			overrun--;
		}
	}
	rows = new_rows;
	cols = new_cols;
	auto_redraw();
}

/* input routines */

/* draw_prompt - assumes current cursor location is 0. */
static void draw_prompt()
{
    int pos = 0;
    
    if (vtc_mode)               /* No prompt? */
        icol = 0;
    else
    {
        while (pos < plen)
        {
            IBwritem(&prompt[pos], plen - pos, Margin);
            pos += Margin;
            if (pos <= plen)
                Iscr_fwd;
        };
        icol = plen % Margin;
        IBflush;
    };
}

/* clear_input_window - clear input window */
static void clear_input_window()
{
    int len = Oplen;              /* copy of plen */
    if (kpos + Oplen <= Isize * Margin) 
    {
        input_cmove(0);          /* Move to start of edit line */
        while (len > Margin) {   /* Scroll back to first line of prompt */
            Iscr_rev;
            len -= Margin;
        }
        icol = 0;
        Icmove(0, 1);            /* clear line */
        IBwritea(s_clreol);
        IBflush;
    } else                       /* this line fills the window */
        Iclear_space(Itop, 1);
}

/* input_puts - puts a string to the input window
 *
 * Called when the interpreter sends output (usually due to keyboard
 * input).  This apparently does not modify kbuf.  Any input is
 * assumed to be an insertion.
 */
void input_puts(cstr)
	Cstr cstr;
{
	int n;

	if (!echo_mode)
		return;

	while (cstr.l)
        {
		n = min(cstr.l, Margin - icol);
		IBwriteal(cstr.s, n);
                icol = (icol + n) % Margin;
		if (0 == icol)
			Iscr_fwd;
		cstr = cstr_sl(cstr.s + n, cstr.l - n);
	}
        /* Print everything from current pos to eoln */
	n = min(Klen - kpos, Margin - icol);
	IBwriteal(&Kptr[kpos], n);
	Imove_left(n, icol);
	IBflush;
}

/* Move cursor to the new column, updating the screen wrap if necessary
 *
 * Assumes the current value of icol is valid.
 */
void input_cmove(new)
	int new;
{
    int offset = new - kpos, pos, n;
    assert(new >= 0);    /* array bounds error? */
    assert(new <= Klen); /* array bounds error? */

    if (new == kpos || !echo_mode)
        return;
    if (new == kpos - 1 && icol) {
        Imove_left(1, new);
        icol--;
    } else if (new == kpos + 1 && icol < Margin - 1) {
        IBputch(Kptr[kpos]);
        icol++;
    }
    else if (offset > 0)                   /* cursor forward? */
    {
        /* print remainder of this line */
        IBwritem(&Kptr[kpos], Margin - icol, Klen - kpos);
        
        n = (icol + offset) / Margin;      /* Number of times to scroll */
        pos = kpos + Margin - icol;        /* beginning of next line */
        icol = (icol + offset) % Margin;   /* Get future cursor pos */
        while (n --)
        {
            assert(pos <= Klen);            /* my mistake */
            Iscr_fwd;
            if (pos + Margin > Klen)        /* Partial line? */
                IBwriteal(&Kptr[pos], (Klen + Oplen) % Margin); 
            else
                IBwriteal(&Kptr[pos], Margin); /* fill entire line */
            
            pos += Margin;
        };
        Icmove(icol, 1);
    }
    else                                   /* cursor backward. */
    {
        /* Calculate offset into the prompt array corresponding to the first
         * char in the input window.
         */
        pos = (kpos + plen - icol);        /* start of this line */
        pos -= (Isize * Margin);           /* start of first line */
        icol += offset;
        while (icol < 0)                   /* loop to scroll back */
        {
            Iscr_rev;                      /* scroll back */

            if (pos >= 0)                  /* Exposed a line? */
            {
                cmove(0, Itop);
                if (pos < plen)            /* Not past end of prompt? */
                {
                    if (plen - pos < Margin) /* Prompt does not fill line? */
                    {
                        IBwriteal(&prompt[pos], plen - pos);
                        IBwriteal(&Kptr[0], Margin - (plen - pos));
                    }
                    else
                        IBwriteal(&prompt[pos], Margin);
                }
                else                       /* No prompt showing */
                {
                    n = pos - plen;        /* Index into kbuf now */
                    assert(n <= Klen);     /* off end of kbuf array? */
                    IBwritem(&Kptr[n], Klen - n, Margin);
                };
            }
            else                           
                clear_space(Itop, Itop);   /* clear first line */

            pos -= Margin;
            icol += Margin;
        };
        Icmove(icol, 1);
    }
    IBflush;
}

/* input_bdel - Delete previous character
 *
 * Parameters:
 *   num - number of characters to delete.  Must be >= kpos.
 */
void input_bdel(num)
	int num;
{
	int n;
        assert(num <= kpos /* deleting too far */);
        
	if (!num || !echo_mode)
		return;
	input_cmove(kpos - num);
	n = min(Klen - kpos, Margin - icol);
	IBwriteal(&Kptr[kpos], n);
	Iclear_end;
	Imove_left(n, icol);
	IBflush;
}

/* input_fdel - delete character under cursor
 *
 * This also updates text to the end of the line.
 *
 * Parameters:
 *   num - number of chars to delete.  must be >= 0, < kpos
 */
void input_fdel(num)
	int num;
{
	int n;
        assert(num >= 0 /* count may not be negative */);
        assert(num <= (Klen - kpos) /* Delete past end of string */);

	if (!echo_mode)
		return;
	n = min(Klen - kpos - num, Margin - icol);
	IBwriteal(&Kptr[kpos + num], n);
	Iclear_end;
	Imove_left(n, icol);
	IBflush;
}

/* input_clear - clears the input edit line */
void input_clear()
{
	if (!echo_mode)
		return;
	if (kpos <= Isize * Margin) /* fills entire window? */
        {
		input_cmove(0);
		IBwritea(s_clreol);
                icol = Oplen % Margin;
	}
        else
        {
		Iclear_space(Itop, 1);
		draw_prompt();      /* sets icol */
	}
	IBflush;
}

/* input_draw - draws the input edit line (no prompt)
 *
 * Sets icol.
 *
 * Note:
 *  This is not easy to get right, so be careful
 *  to step through every inch of code after modification.
 */
void input_draw()
{
    int pos = 0;                /* offset in kbuf */
    int n, col;

    if (!echo_mode)
        return;
    
    col = Oplen % Margin;       /* initial location */
    if (Klen > 0)
    {
        while (1)                   /* Loop to write input line */
        {
            n = min(Klen - pos, Margin - col);
            assert(n >= 0);         /* Logic error */
            IBwriteal(&Kptr[pos], n);
            pos += n;               /* printed n chars */
            assert(pos <= Klen);    /* off end of array? */
            
            if (pos > kpos || pos >= Klen)         /* Cursor on line? */
                break;
            else                    /* not done, scroll forward */
                Iscr_fwd;
            
            col = 0;                /* beginning of row now */
        };
        if (n == (Margin - col)) /* write ended at last line on screen? */
            Iscr_fwd;
    };
    icol = (Oplen + kpos) % Margin;
    assert(icol >= 0 && icol < cols); /* off screen? */
        
    Iclear_end;
    Icmove(icol, 1);
    IBflush;
}

void input_newline()
{
	input_cmove(Klen);
	Iscr_fwd;
	icol = 0;
	if (plen && !vtc_mode) {
		Discardstring(prompt);
		prompt = vtstrdup("");
		plen = 0;
	}
	IBflush;
}

/* change_prompt - set a new prompt with length l
 *
 * Nonprintable characters are ignored.
 */
void change_prompt(new, l)
	char *new;
	int l;
{
	char *p, *q;
	Discardstring(prompt);
	for (p = new; *p; p++) {       /* Get new prompt length */
		if (!isprint(*p))
			l--;
	}
	q = prompt = Newarray(char, l + 1); /* copy prompt string */
	for (p = new; *p; p++) {
		if (isprint(*p))
			*q++ = *p;
	}
	*q = 0;

        /* clear and redraw input window */
        
	if (!vtc_mode) {                
		curs_input();
		clear_input_window();
	}
	plen = l;                       
	if (!vtc_mode) {                 
		draw_prompt();
		input_draw();
	}
}

void update_echo_mode()
{
	int new_mode;
	
	if(0 != ign_echo_mode)
		return;

	new_mode = (active_win->Wrmt) ? active_win->Wrmt->Recho : 1;

	if (echo_mode != new_mode) {
		echo_mode = 1;
		curs_input();
		if (new_mode)
			input_draw();
		else
			input_clear();
		echo_mode = new_mode;
	}
}

/* Output routines */

void output(win, text)
	Unode *win;
	char *text;
{
	int norm, n;

	if (!win) {
		win = active_win;
		if (win->Wnl)
			output(win, "[background] ");
	}
	curs_window(win);
	if (win->Wnl) {
		BputEOLN();
		win->Wnl = 0;
	}
	while (1) {
		norm = strcspn(text, "\n\b\f\v\t\r");
		n = cols - win->Wcol;
		for (; norm >= n; text += n, norm -= n, n = cols) {
			BputEOLN();
			cmove(win->Wcol, win->Wbot - 1);
			Bwriteal(text, n);
			cmove(0, win->Wbot);
			win->Wcol = 0;
		}
		Bwriteal(text, norm);
		win->Wcol = (win->Wcol + norm) % cols;
		text += norm;
		switch(*text++) {
		    case '\0':
			Bflush;
			return;
		    case '\n':
		    case '\v':
			if (*text)
				BputEOLN();
			else
				win->Wnl = 1;
			win->Wcol = 0;
		    Case '\b':
			if (win->Wcol) {
				Bputch('\b');
				win->Wcol--;
			}
		    Case '\f':
			clear_space(win->Wtop, win->Wbot);
			win->Wcol = 0;
			curs_window(win);
		    Case '\t':
			if (win->Wcol == cols - 1) {
				BputEOLN();
				win->Wcol = 0;
			} else {
				do {
					Bputch(' ');
					win->Wcol++;
				} while (win->Wcol % 8 && 
					 win->Wcol < cols - 1);
			}
		    Case '\r':
			Bputch('\r');
			win->Wcol = 0;
		}
	}
}

#ifdef USE_STDARG
void outputf(char *fmt, ...)
#else
void outputf(va_alist)
	va_dcl
#endif
{
	va_list ap;
	char *ptr, *sval, *intstr;
	String *buf = &wbufs[1];
	int width = 0;
#ifdef USE_STDARG
	va_start(ap, fmt);
#else
	char *fmt;
	va_start(ap);
	fmt = va_arg(ap, char *);
#endif

	s_term(buf, 0);
	ptr = strchr(fmt, '%');
	while (ptr) {
		s_cat(buf, cstr_sl(fmt, ptr - fmt));
		if (isdigit(*++ptr)) {
			width = atoi(ptr);
			while (isdigit(*++ptr));
		}
		if (*ptr == 'd') {
			intstr = ITOA(va_arg(ap, int));
			for (width -= strlen(intstr); width > 0; width--)
				s_fadd(buf, ' ');
			s_acat(buf, intstr);
		} else if (*ptr == 's') {
			sval = va_arg(ap, char *);
			for (width -= strlen(sval); width > 0; width--)
				s_fadd(buf, ' ');
			s_acat(buf, sval);
		} else
			s_fadd(buf, *ptr);
		fmt = ptr + 1;
		ptr = strchr(fmt, '%');
	}
	s_acat(buf, fmt);
	output(Cur_win, buf->c.s);
	va_end(ap);
}

void operror(s, rmt)
	char *s;
	Unode *rmt;
{
	char errbuf[128];
	Unode *win = rmt ? rmt->Rwin : Cur_win;

	strcpy(errbuf, s);
	strcat(errbuf, ": ");
	strcat(errbuf, sys_errlist[errno]);
	strcat(errbuf, "\n");
	output(win, errbuf);
}

@


2.2
log
@Changed comments around #ifdef.
@
text
@d2 1
a2 1
/* $Id: window.c 2.1 1995/10/24 15:46:14 tsurace Exp tsurace $ */
d5 1
d44 1
a44 1
static void clear_end(int);
d144 1
a144 1
# define Iclear_end(n)  clear_end(n)
d420 6
a425 1
	cap_formatted(s_cmove, col, row);
d459 6
a464 2
static void clear_end(len)
	int len;
d466 1
a466 4
	if (len > 1)
		Bwritea(s_clreol);
	else if (len == 1)
		Bwritea(" \010");
d752 1
d755 16
a770 9
	int pos = 0;

	while (pos < Oplen) {
		IBwritem(&prompt[pos], plen - pos, Margin);
		if ((pos += Margin) <= plen)
			Iscr_fwd;
	}
	icol = Oplen % Margin;
	IBflush;
d773 1
d776 22
a797 13
	if (kpos + Oplen <= Isize * Margin) {
		input_cmove(0);
		while (plen > Margin) {
			Iscr_rev;
			plen -= Margin;
		}
                Icmove(0, 1);
		IBwritea(s_clreol);
		IBflush;
	} else
		Iclear_space(Itop, 1);
}

d806 2
a807 1
	while (cstr.l) {
d810 2
a811 1
		if (!(icol = (icol + n) % Margin))
d815 1
d822 4
a825 1
/* Move to the new column, updating the screen wrap if necessary */
d829 82
a910 38
	int offset = new - kpos, pos, n;

	if (new == kpos || !echo_mode)
		return;
	if (new == kpos - 1 && icol) {
                Imove_left(1, new);
		icol--;
	} else if (new == kpos + 1 && icol < Margin - 1) {
		IBputch(Kptr[kpos]);
		icol++;
	} else if (new > kpos) {
		pos = Round(kpos + Oplen, Margin) + Margin - Oplen;
		while (icol + offset >= Margin) {
			Iscr_fwd;
			IBwritem(&Kptr[pos], Klen - pos, Margin);
			pos += Margin;
			offset -= Margin;
		}
		Icmove(icol += offset, 1);
	} else {
		pos = Round(kpos + Oplen, Margin) - Oplen - Isize * Margin;
		while (icol + offset < 0) {
			Iscr_rev;
			if (pos >= 0)
				IBwritem(&Kptr[pos], Klen - pos, Margin);
			else if (pos + Oplen >= 0) {
				n = min(-pos, Margin);
				IBwriteal(&prompt[plen + pos], n);
				IBwritem(Kptr, Klen, Margin - n);
			}
			pos -= Margin;
			offset += Margin;
		}
		Icmove(icol += offset, 1);
	}
	IBflush;
}

d915 2
a916 1

d922 1
a922 1
	Iclear_end(min(num, Margin - icol - n));
d927 7
d938 2
d945 1
a945 1
	Iclear_end(min(num, Margin - icol - n));
d950 1
d955 2
a956 1
	if (kpos <= Isize * Margin) {
d959 4
a962 1
	} else {
d964 1
a964 1
		draw_prompt();
a965 1
	icol = Oplen % Margin;
d969 8
d979 2
a980 1
	int pos = 0, n = 0, col;
d982 30
a1011 13
	if (!echo_mode)
		return;
	col = Oplen % Margin;
	while (pos <= kpos) {
		n = min(Klen - pos, Margin - col);
		IBwriteal(&Kptr[pos], n);
		if ((pos += Margin) <= kpos)
			Iscr_fwd;
		col = 0;
	}
	icol = Oplen + kpos % Margin;
	Imove_left(n - icol, icol);
	IBflush;
d1027 4
a1035 5

	if (!vtc_mode) {
		curs_input();
		clear_input_window();
	}
d1037 1
a1037 1
	for (p = new; *p; p++) {
d1041 1
a1041 1
	q = prompt = Newarray(char, l + 1);
d1047 9
a1055 2
	plen = l;
	if (!vtc_mode) {
@


2.1
log
@Roll.
@
text
@d2 1
a2 1
/* $Id: window.c 1.1 1995/10/12 21:37:13 tsurace Beta tsurace $ */
d200 3
a202 1
#ifndef __WIN32__ /* won't work */
@


1.1
log
@Initial revision
@
text
@d2 1
a2 1
/* $Id$ */
@
