head	2.1;
access;
symbols;
locks; strict;
comment	@ * @;


2.1
date	95.10.24.15.46.14;	author tsurace;	state Release;
branches;
next	1.1;

1.1
date	95.10.12.21.36.07;	author tsurace;	state Beta;
branches;
next	;


desc
@A lexxed version of vtc.y for use with win32 as necessary.
@


2.1
log
@Roll.
@
text
@
# line 2 "vtc.y"
/* vtc.y: VTC compiler and lexical analyzer */

#include "vt.h"

String ptext;
int debug = 0;
extern int iwidth[];
#define ERR_PRMTNAME	"Primitive name used as function name"
#define ERR_RESERVED	"Reserved word used as identifier"
#define ERR_DUPGOTO	"Duplicate goto label"
#define ERR_MISBREAK	"Misplaced break statement"
#define ERR_MISCONT	"Misplaced continue statement"
#define ERR_DUPTAG	"Duplicate parameter or local variable name"
#define ERR_UDGOTO	"One or more goto labels not defined"
#define ERR_TOOMANY	"Too many parameters or local variables"
#define ERR_UNTERMCHAR	"Unterminated character constant"
#define ERR_UNTERMSTR	"Unterminated string constant"
#define ERR_BADBRACE	"Illegal placement of right brace"
#define ERR_ILLFUNC	"Illegal placement of reserved word func"

/* The intermediate program */
#define INIT_CODE 256
static Instr *icode;
static int loc = 0, codesize;
#define Check_code(n) Check(icode, Instr, codesize, loc + (n))

#define Hexdigitvalue(a) (isdigit(a) ? a - '0' : ucase(a) - 'A' + 10)
#define Code(t) if (1) { Check_code(1); icode[loc++].type = t; } else
#define Code2(t, elem, val) if (1) { Check_code(2); icode[loc++].type = t; \
				     icode[loc++].elem = val; } else
#define Code_iconst(val) Code2(I_ICONST, iconst, val)
#define Code_pcall(pn, ac) if (1) { Check_code(2); \
				    icode[loc++].type = I_PCALL; \
				    icode[loc].pc.pnum = pn; \
				    icode[loc++].pc.argc = ac; } else
#define Code_fcall(id, ac) if (1) { Check_code(2); \
				    icode[loc++].type = I_FCALL; \
				    icode[loc++].argc = ac; \
				    icode[loc++].ident = id; } else

typedef struct label {
	char *name;
	int offset;
	struct label *next;
} Label;

#define MAXILEN 32
static Label *lhead = NULL;

#ifdef PROTOTYPES
static void code_var(char *);
static void code_goto(char *, int);
static void free_labels(void);
static void add_tag(char **, int *, char *);
static int find_tag(char **, int, char *);
static char *parse_token(char *);
static int read_char(char **);
static int enter_sconst(Cstr);
static char *read_string(char *);
static char *read_comment(char *);
static void compile(void);
static void scan(void);
static void cleanup_parse();
static void lexerror(char *);
static void yyerror(char *);
static int yylex(void);
#else
static void compile(), scan(), cleanup_parse(), lexerror(), yyerror();
static void code_var(), free_labels(), add_tag(), code_goto();
static char *parse_token(), *read_string(), *read_comment();
#endif

#define INIT_JMP 64
#define INIT_COND 16
int *jmptab, jmpsize, jmppos;
int *condstack, condsize, condpos;
int *loopstack, loopsize, looppos;
#define Incjmp(n)	Check(jmptab, int, jmpsize, jmppos += (n))
#define Pushcond(x)	Push(condstack, int, condsize, condpos, x)
#define Pushloop(x)	Push(loopstack, int, loopsize, looppos, x)
#define Peekloop	(loopstack[looppos - 1])
#define Incloop(n)	if (1) { Pushloop(jmppos); Incjmp(n); } else
#define Decloop		looppos--
#define Ljmp(l, t)	Code2(t, offset, Peekloop + (l))
#define Ldest(l)	(jmptab[Peekloop + (l)] = loc)
#define Break		if (looppos) Code2(I_JMP, offset, Peekloop + 1); \
			else yyerror(ERR_MISBREAK)
#define Continue	if (looppos) Code2(I_JMP, offset, Peekloop); \
			else yyerror(ERR_MISCONT)
#define Jmp(t)		if (1) { Pushcond(jmppos); Code2(t, offset, jmppos); \
				 Incjmp(1); } else
#define Dest		(jmptab[condstack[--condpos]] = loc)
#define Destnext	(jmptab[condstack[--condpos]] = loc + 2)
#define Return		Code2(I_JMP, offset, 0)

/* Local vars and array vars */
#define MAX_TAGS 32
static char *lvars[MAX_TAGS], *avars[MAX_TAGS];
static int lvarc = 0, avarc = 0, reqargs = 0;

static int lexline = -1;		/* Line being analyzed	     */
static int parseline = -1;		/* Line being parsed	     */
static int errflag;			/* Error flag		     */
static char *curfunc = "";		/* Name of current function  */
static char *curfile = "";		/* Name of current file	     */
extern Prmt prmtab[];

#define OP_BOR	     0
#define OP_BXOR	     1
#define OP_BAND	     2
#define OP_EQ	     3
#define OP_NE	     4
#define OP_LT	     5
#define OP_LE	     6
#define OP_GT	     7
#define OP_GE	     8
#define OP_SL	     9
#define OP_SR	    10
#define OP_ADD	    11
#define OP_SUB	    12
#define OP_MULT	    13
#define OP_DIV	    14
#define OP_MOD	    15
#define OP_POSTINC  16
#define OP_POSTDEC  17
#define OP_PREINC   18
#define OP_PREDEC   19
#define OP_NOT	    20
#define OP_COMPL    21
#define OP_NEG	    22
#define OP_ASN	    23
#define PR_LOOKUP   102


# line 136 "vtc.y"
typedef union  {
	int num;
	int index;
	void (*bobj)();
	int str;
	char *s;
} YYSTYPE;
#ifdef __cplusplus
#  include <stdio.h>
#  include <yacc.h>
#endif	/* __cplusplus */ 
# define ICONST 257
# define SCONST 258
# define BOBJ 259
# define IDENT 260
# define FUNC 261
# define FASSIGN 262
# define DO 263
# define WHILE 264
# define IF 265
# define ELSE 266
# define FOR 267
# define GOTO 268
# define BREAK 269
# define CONTINUE 270
# define RETURN 271
# define TA 272
# define DA 273
# define MA 274
# define AA 275
# define SA 276
# define SLA 277
# define SRA 278
# define BAA 279
# define BXA 280
# define BOA 281
# define CONDA 282
# define DEREF 283
# define OR 284
# define AND 285
# define EQ 286
# define NE 287
# define LE 288
# define GE 289
# define SL 290
# define SR 291
# define INC 292
# define DEC 293
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif

/* __YYSCLASS defines the scoping/storage class for global objects
 * that are NOT renamed by the -p option.  By default these names
 * are going to be 'static' so that multi-definition errors
 * will not occur with multiple parsers.
 * If you want (unsupported) access to internal names you need
 * to define this to be null so it implies 'extern' scope.
 * This should not be used in conjunction with -p.
 */
#ifndef __YYSCLASS
# define __YYSCLASS static
#endif
YYSTYPE yylval;
__YYSCLASS YYSTYPE yyval;
typedef int yytabelem;
# define YYERRCODE 256

# line 361 "vtc.y"


/* Auxiliary compiler functions */

static void code_var(ident)
	char *ident;
{
	int tag;

	if ((tag = find_tag(avars, avarc, ident)) != -1)
		Code2(I_AVAR, tnum, tag);
	else if ((tag = find_tag(lvars, lvarc, ident)) != -1)
		Code2(I_LVAR, tnum, tag);
	else
		Code2(I_GVAR, ident, ident);
}

static void code_goto(name, to)
	char *name;
	int to;
{
	Label *label;

	for (label = lhead; label; label = label->next) {
		if (streq(label->name, name)) {
			if (to)
				Code2(I_JMP, offset, label->offset);
			else if (jmptab[label->offset] == -1)
				jmptab[label->offset] = loc;
			else
				yyerror(ERR_DUPGOTO);
			return;
		}
	}
	label = New(Label);
	label->name = name;
	label->offset = jmppos;
	Push(jmptab, int, jmpsize, jmppos, to ? -1 : loc);
	if (to)
		Code2(I_JMP, offset, label->offset);
	label->next = lhead;
	lhead = label;
}

static void free_labels()
{
	Label *label = lhead, *next;

	for (label = lhead; label; label = next) {
		next = label->next;
		if (jmptab[label->offset] == -1)
			yyerror(ERR_UDGOTO);
		Discard(label, Label);
	}
	lhead = NULL;
}

static void add_tag(table, pos, tag)
	char *table[], *tag;
	int *pos;
{
	int i;

	for (i = 0; i < *pos; i++) {
		if (!strcmp(table[i], tag)) {
			yyerror(ERR_DUPTAG);
			return;
		}
	}
	if (*pos == MAX_TAGS)
		yyerror(ERR_TOOMANY);
	else
		table[(*pos)++] = tag;
}

static int find_tag(table, num, ident)
	char *table[], *ident;
	int num;
{
	int i;

	for (i = 0; i < num; i++) {
		if (streq(table[i], ident))
			return i;
	}
	return -1;
}

/* The lexical analyzer */

typedef struct token {
	int type;
	YYSTYPE val;
} Token;

Token *tokbuf;
int tokpos = 0, toksize;
#define INIT_TOKENS 128

#define Textend Checkinc(tokbuf, Token, toksize, tokpos)
#define Add_vtoken(t, elem, v) if (1) { Textend; tokbuf[tokpos].type = (t); \
					tokbuf[tokpos++].val.elem = (v); } else
#define Add_ntoken(t) if (1) { Textend; tokbuf[tokpos++].type = (t); } else

#define INIT_SCONST 32
#define INIT_IDENTS 64
static Cstr *sconsts;			/* Allocated string constants */
static char **idents;			/* Allocated identifiers */
static int sconstpos = 0, identpos = 0, sconstsize, identsize;
static int braces = 0, incomment = 0, instring = 0, infunc = 0, tokindex;
static String sbuf;

static char *ecodes = "ntvbrf\\'\"";
static char *results = "\n\t\v\b\r\f\\'\"";
static int begin[128], end[128];	/* Lookup table for words */
static char transtab[128];		/* Table for escape codes */
/* Table of reserved words and compound operators */
/* These do not need to be in alphabetical order, but words with the
** same first character must be adjacent.  Among compound operators
** with the same first character, longer operators should come first. */
static struct word {
	char *s;
	int val;
} words[] = {
	{ ""		, 0		},
	{ "do"		, DO		},
	{ "while"	, WHILE		},
	{ "if"		, IF		},
	{ "else"	, ELSE		},
	{ "for"		, FOR		},
	{ "func"	, FUNC		},
	{ "goto"	, GOTO		},
	{ "break"	, BREAK		},
	{ "continue"	, CONTINUE	},
	{ "return"	, RETURN	},
	{ "^="		, BXA		},
	{ "*="		, TA		},
	{ "/="		, DA		},
	{ "%="		, MA		},
	{ "+="		, AA		},
	{ "++"		, INC		},
	{ "-="		, SA		},
	{ "-->"		, FASSIGN	},
	{ "--"		, DEC		},
	{ "->"		, DEREF		},
	{ "<<="		, SLA		},
	{ "<<"		, SL		},
	{ "<="		, LE		},
	{ ">>="		, SRA		},
	{ ">>"		, SR		},
	{ ">="		, GE		},
	{ "&="		, BAA		},
	{ "&&"		, AND		},
	{ "|="		, BOA		},
	{ "||"		, OR		},
	{ "=="		, EQ		},
	{ "!="		, NE		},
	{ "?:="		, CONDA		},
	{ ""		, 0		}
};

#define NWORDS (sizeof(words) / sizeof(struct word) - 1)

/* Set up data */
void init_compile()
{
	int i;

	bzero(begin, sizeof(begin));
	bzero(end, sizeof(end));
	for (i = 0; i < NWORDS; i++) {
		begin[*words[i].s] = i;
		while (*words[i + 1].s == *words[i].s)
			i++;
		end[*words[i].s] = i;
	}
	bzero(transtab, sizeof(transtab));
	for (i = 0; ecodes[i]; i++)
		transtab[ecodes[i]] = results[i];
	tokbuf = Newarray(Token, toksize = INIT_TOKENS);
	icode = Newarray(Instr, codesize = INIT_CODE);
	sconsts = Newarray(Cstr, sconstsize = INIT_SCONST);
	idents = Newarray(char *, identsize = INIT_IDENTS);
	jmptab = Newarray(int, jmpsize = INIT_JMP);
	condstack = Newarray(int, condsize = INIT_COND);
	loopstack = Newarray(int, loopsize = INIT_COND);
	sbuf = empty_string;
}

/* Analyze text and place tokens in buffer */

void parse(text)
	char *text;
{
	while (*text) {
		text = parse_token(text);
		if (!text)
			return;
	}
	if (!infunc && !braces && !incomment && !instring && tokpos)
		compile();
}

static char *parse_token(s)
	char *s;
{
	char *ptr, buf[MAXILEN + 1];
	int i;
	void (*bobj)();
	Const *cp;

	if (incomment)
		return read_comment(s);
	if (instring)
		return read_string(s);
	for (; isspace(*s); s++);
	if (!*s || *s == '/' && s[1] == '/')
		return "";
	if (*s == '/' && s[1] == '*')
		return read_comment(s + 2);
	if (*s == '"') {
		s_term(&sbuf, 0);
		return read_string(s + 1);
	}
	if (*s == '\'') {
		s++;
		Add_vtoken(ICONST, num, read_char(&s));
		if (*s++ != '\'')
			lexerror(ERR_UNTERMCHAR);
		return s;
	}
	if (isdigit(*s)) {
		i = 0;
		if (*s == '0' && lcase(s[1]) == 'x' && isxdigit(s[2])) {
			s++;
			while (isxdigit(*++s))
				i = i * 0x10 + Hexdigitvalue(*s);
			Add_vtoken(ICONST, num, i);
			return s;
		}
		if (*s == '0' && s[1] >= '0' && s[1] <= '8') {
			while (*++s >= '0' && *s <= '8')
				i = i * 010 + *s - '0';
			Add_vtoken(ICONST, num, i);
			return s;
		}
		Add_vtoken(ICONST, num, atoi(s));
		while (isdigit(*++s));
		return s;
	}
	if (*s == '\\' && !s[1])
		return NULL;
	if (isalpha(*s) || *s == '_') {
		for (ptr = s; isalnum(*ptr) || *ptr == '_'; ptr++);
		strncpy(buf, s, min(ptr - s, MAXILEN));
		buf[min(ptr - s, MAXILEN)] = '\0';
		if (!(*buf & ~0x7f) && begin[*buf]) {
			for (i = begin[*buf]; i <= end[*buf]; i++) {
				if (streq(buf + 1, words[i].s + 1))
					break;
			}
			if (i <= end[*buf]) {
				if (words[i].val == FUNC) {
					if (tokpos) {
						lexerror(ERR_ILLFUNC);
						braces = 0;
					}
					infunc = 1;
				}
				Add_ntoken(words[i].val);
				return ptr;
			}
		}
		bobj = find_bobj(buf);
		if (bobj) {
			Add_vtoken(BOBJ, bobj, bobj);
			return ptr;
		}
		cp = find_const(buf);
		if (cp) {
			Add_vtoken(ICONST, num, cp->val);
			return ptr;
		}
		Push(idents, char *, identsize, identpos, vtstrdup(buf));
		Add_vtoken(IDENT, s, idents[identpos - 1]);
		return ptr;
	}
	if (!(*s & ~0x7f) && begin[*s]) {
		for (i = begin[*s]; i <= end[*s]; i++) {
			if (!strncmp(s + 1, words[i].s + 1,
				     strlen(words[i].s) - 1))
				break;
		}
		if (i <= end[*s]) {
			Add_ntoken(words[i].val);
			if (words[i].val == FASSIGN)
				infunc = 0;
			return s + strlen(words[i].s);
		}
	}
	Add_ntoken(*s);
	if (*s == '{')
		braces++;
	else if (*s == '}') {
		if (!braces)
			lexerror(ERR_BADBRACE);
		else if (!--braces)
			infunc = 0;
	}
	return s + 1;
}

static int read_char(s)
	char **s;
{
	char c;
	int val = 0, count;

	if (**s != '\\')
		return *(*s)++;
	c = transtab[*++(*s) & 0x7f];
	if (c) {
		(*s)++;
		return c;
	}
	if (**s < '0' || **s > '8')
		return '\\';
	for (count = 0; count < 3 && **s >= '0' && **s <= '8'; (*s)++)
		val = val * 8 + **s - '0';
	return val;
}

static int enter_sconst(c)
	Cstr c;
{
	Push(sconsts, Cstr, sconstsize, sconstpos, cstr_c(c));
	return sconstpos - 1;
}

static char *read_string(s)
	char *s;
{
	while (*s && *s != '"') {
		if (*s == '\\' && !s[1]) {
			instring = 1;
			return "";
		}
		s_fadd(&sbuf, read_char(&s));
	}
	if (!*s) {
		lexerror(ERR_UNTERMSTR);
		return "";
	}
	instring = 0;
	Add_vtoken(SCONST, str, enter_sconst(sbuf.c));
	return s + 1;
}

static char *read_comment(s)
	char *s;
{
	s = strchr(s, '*');
	while (s) {
		if (s[1] == '/') {
			incomment = 0;
			return s + 2;
		}
		s = strchr(s + 1, '*');
	}
	incomment = 1;
	return "";
}

static void compile()
{
	tokindex = 0;
	yyparse();
	if (!errflag) {
		scan();
		return;
	}
	while (yylex());
	condpos = looppos = 0;
	cleanup_parse();
}

static void scan()
{
	Prog *newprog;
	Instr *in, *end;
	char *s;
	Func *func;
	String dtext;

	dtext = empty_string;
	jmptab[0] = loc;
	Code(I_STOP);
	newprog = New(Prog);
	newprog->refs = 0;
	newprog->avarc = avarc;
	newprog->reqargs = reqargs;
	newprog->lvarc = lvarc;
	newprog->code = Newarray(Instr, loc);
	Copy(icode, newprog->code, loc, Instr);
	end = newprog->code + loc;
	for (in = newprog->code; in < end; in += iwidth[in->type]) {
		switch(in->type) {
		    case I_SCONST:
			in[1].sconst = add_sconst(&sconsts[in[1].sindex]);
		    Case I_FCALL:
			s = in[2].ident;
			func = find_func(s);
			if (debug && (!func || !func->cmd)
			    && !strstr(dtext.c.s, s)) {
				s_acat(&dtext, " ");
				s_acat(&dtext, s);
				s_acat(&dtext, "()");
			}
			in[2].func = func ? func : add_func(s, NULL);
		    Case I_FPTR:
			s = in[1].ident;
			func = find_func(s);
			if (debug && (!func || !func->cmd)
			    && !strstr(dtext.c.s, s)) {
				s_acat(&dtext, " .");
				s_acat(&dtext, s);
			}
			in[1].func = func ? func : add_func(s, NULL);
		    Case I_GVAR:
			if (debug && !strstr(dtext.c.s, in[1].ident)) {
				s_acat(&dtext, " ");
				s_acat(&dtext, in[1].ident);
			}
			in[1].tnum = get_vindex(in[1].ident);
		    Case I_JMP:
		    case I_JMPT:
		    case I_JMPF:
		    case I_JMPPT:
		    case I_JMPPF:
			in[1].loc = newprog->code + jmptab[in[1].offset];
		}
	}
	if (debug && *dtext.c.s) {
		if (*curfile)
			outputf("%s ", curfile);
		outputf("%s:%s\n", *curfunc ? curfunc : "Command",
			dtext.c.s);
	}
	s_free(&dtext);
	if (*curfunc) {
		add_func(curfunc, newprog);
		cleanup_parse();
	} else {
		cleanup_parse();
		run_prog(newprog);
	}
}

static void cleanup_parse()
{
	while (identpos--)
		Discardstring(idents[identpos]);
	while (sconstpos--) {
		if (sconsts[sconstpos].s)
			Discardarray(sconsts[sconstpos].s, char,
				     sconsts[sconstpos].l + 1);
	}
	free_labels();
	curfunc = "";
	tokpos = loc = lvarc = avarc = errflag = identpos = sconstpos = 0;
	reqargs = 0;
	jmppos = 1;
}

static void lexerror(s)
	char *s;
{
	if (lexline != -1)
		outputf("%s line %d: ", curfile, lexline);
	outputf("%s\n", s);
	errflag = 1;
}

static void yyerror(msg)
	char *msg;
{
	if (parseline != -1)
		outputf("%s line %d: ", curfile, parseline);
	coutput(msg);
	if (*curfunc)
		outputf(" in function %s", curfunc);
	coutput("\n");
	errflag = 1;
}

static int yylex()
{
	while (tokindex < tokpos && tokbuf[tokindex].type == '\n') {
		tokindex++;
		if (parseline != -1)
			parseline++;
	}
	if (tokindex < tokpos) {
		yylval = tokbuf[tokindex].val;
		return tokbuf[tokindex++].type;
	}
	return 0;
}

int load_file(name)
	char *name;
{
	int olline, opline;
	char *ocfile;
	FILE *fp;
	String freader;

	freader = empty_string;
	fp = fopen(expand(name), "r");
	if (!fp)
		return -1;
	olline = lexline;
	opline = parseline;
	ocfile = curfile;
	lexline = parseline = 1;
	curfile = vtstrdup(name);
	while (s_fget(&freader, fp)) {
		if (freader.c.s[freader.c.l - 1] == '\n')
			freader.c.s[freader.c.l - 1] = '\0';
		parse(freader.c.s);
		if (tokpos)
			Add_ntoken('\n');
		else
			parseline++;
		lexline++;
	}
	lexline = olline;
	parseline = opline;
	Discardstring(curfile);
	curfile = ocfile;
	fclose(fp);
	s_free(&freader);
	return 0;
}

__YYSCLASS yytabelem yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
-1, 8,
	59, 96,
	-2, 3,
-1, 28,
	283, 19,
	91, 19,
	-2, 27,
-1, 30,
	283, 20,
	91, 20,
	-2, 38,
	};
# define YYNPROD 140
# define YYLAST 718
__YYSCLASS yytabelem yyact[]={

    33,   114,   115,   127,   135,    37,   206,    40,     5,    29,
    36,    99,    35,    44,   172,    33,    97,    95,    74,    96,
    37,    98,    40,   139,    29,    36,     5,    35,    44,    99,
    86,    11,    21,   178,    97,    95,   198,    96,    80,    98,
   223,    99,    86,   185,   143,    76,    97,    95,    75,    96,
   209,    98,    89,   144,    91,   100,    67,    80,   134,   177,
   168,    80,   179,    72,    89,   202,    91,   100,   175,   180,
   187,   228,    99,    86,    45,    62,   215,    97,    95,    99,
    96,    73,    98,   199,    97,    95,    85,    96,   101,    98,
    21,   220,   145,    34,    40,    89,    29,    91,    85,   219,
    44,   200,    89,   138,    91,    21,   197,   133,    34,   225,
    33,   186,    80,   136,   130,    37,    84,    40,    72,    29,
    36,    99,    35,    44,    47,    33,    97,   101,    84,    85,
    37,    98,    40,   132,    29,    36,    77,    35,    44,    81,
    71,    99,    86,   179,    10,     3,    97,    95,     7,    96,
   205,    98,    65,    80,   190,    99,    86,    80,   142,    84,
    97,    95,    33,    96,    89,    98,    91,    37,   229,    40,
   226,    29,    36,   207,    35,    44,    99,    86,    89,     6,
    91,    97,    95,    99,    96,   184,    98,    70,    97,    95,
   214,    96,    69,    98,   176,   126,     4,    80,    85,    89,
   182,    91,    12,    34,   181,    79,    89,   216,    91,    99,
   147,   171,    85,   203,    97,    95,   170,    96,    34,    98,
   194,   218,   167,   211,    42,    43,    38,    16,    84,   150,
    14,    13,    23,    27,    15,    17,    18,    19,    20,    42,
    43,    38,    16,   149,    41,    14,    13,    23,    28,    15,
    17,    18,    19,    20,    39,    34,    61,   201,   227,    31,
    32,   212,   131,   116,    93,    94,     8,   121,   122,   123,
   124,     2,   213,     1,    31,    32,    82,    83,    87,    88,
    90,    92,    93,    94,    60,   102,   140,     0,    82,    83,
    87,    88,    90,    92,    93,    94,     0,     0,     0,   104,
   105,   106,   107,   108,   109,   110,   111,   112,   113,   103,
     0,    42,    43,    38,    64,     0,     0,     0,     0,     0,
    83,    87,    88,    90,    92,    93,    94,     0,    87,    88,
    90,    92,    93,    94,    42,    43,    38,    64,   104,   105,
   106,   107,   108,   109,   110,   111,   112,   113,   103,    42,
    43,    38,    64,    59,     0,    48,    46,    54,     0,    49,
    50,    51,    52,    53,    55,    56,    57,    58,     0,    31,
    32,     0,     0,     0,     0,     0,     0,     0,     0,    30,
     0,     0,     0,     0,    31,    32,   174,    43,    38,    64,
    87,    88,    90,    92,    93,    94,     0,     0,     0,     0,
     0,     0,     0,     0,    87,    88,    90,    92,    93,    94,
     9,   119,   119,    24,     0,     0,     0,   119,     0,    66,
     0,    31,    32,    68,     0,    87,    88,    90,    92,    93,
    94,     0,     0,     0,    90,    92,    93,    94,     0,    25,
     0,     0,     0,     0,     0,     0,     0,     0,    59,     0,
    48,    46,    54,     0,    49,    50,    51,    52,    53,    55,
    56,    57,    58,    59,     0,    48,    46,    54,     0,    49,
    50,    51,    52,    53,    55,    56,    57,    58,   117,     0,
     0,   137,    26,     0,     0,    26,   141,    26,     0,     0,
   146,    26,     0,     0,     0,     0,     0,     0,     0,    26,
     0,    22,     0,     0,     0,     0,     0,     0,    63,     0,
   118,   120,     0,     0,     0,   169,   125,     0,     0,   128,
     0,     0,    78,     0,   151,   152,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
     0,     0,   129,     0,     0,     0,     0,     0,     0,    26,
    26,    26,     0,   188,     0,     0,     0,     0,    26,     0,
    26,   189,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    26,     0,     0,   148,   195,   196,     0,     0,     0,   191,
   192,     0,     0,   204,     0,     0,     0,     0,     0,     0,
     0,   208,     0,     0,     0,     0,    26,   193,     0,     0,
     0,     0,     0,   141,     0,    26,     0,     0,     0,     0,
     0,    26,     0,     0,     0,   221,    26,     0,     0,   173,
     0,     0,     0,     0,   210,     0,     0,     0,   183,     0,
   230,     0,     0,     0,     0,     0,     0,     0,     0,    26,
    26,     0,     0,     0,     0,     0,     0,     0,   224,     0,
     0,    26,     0,     0,     0,     0,    26,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,    26,     0,
     0,     0,     0,     0,     0,     0,    26,     0,     0,     0,
     0,     0,     0,    26,    26,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,    26,     0,     0,    26,   217,
     0,     0,     0,     0,     0,     0,     0,   222 };
__YYSCLASS yytabelem yypact[]={

   -65, -3000,   -83,   -18,   206,   191,    92,   -91,   -18, -3000,
 -3000,    -3,   -18, -3000, -3000,   100,    23,  -242,   -11,   -14,
    77, -3000,    17,    99, -3000,     4,    66, -3000,  -291,    92,
 -3000,    54,    54,    92,    92,    92,    92,    54, -3000,   -88,
    92, -3000, -3000, -3000,   206,    93, -3000, -3000, -3000, -3000,
 -3000, -3000, -3000, -3000, -3000, -3000, -3000, -3000, -3000, -3000,
 -3000,    14, -3000,    17,    78, -3000, -3000, -3000,  -262,    73,
   -18,    92,    92, -3000,   -15, -3000, -3000, -3000,    -6,   -33,
 -3000,    92, -3000, -3000,    92,    92,    92,    92,    92,    92,
    92,    92,    92,    92,    92,    92,    92,    92,    92,    92,
     2,    92, -3000, -3000, -3000, -3000, -3000, -3000, -3000, -3000,
 -3000, -3000, -3000, -3000, -3000, -3000, -3000, -3000, -3000, -3000,
 -3000, -3000, -3000, -3000, -3000, -3000,  -246,   129,    27,   153,
 -3000, -3000,    96, -3000,   206, -3000,    92, -3000,   -16,    70,
    26, -3000,   -18, -3000, -3000, -3000, -3000,    92,   113,    92,
    92,   118,   139,    42,   146,   146,   -26,   -26,   -26,   -26,
   172,   172,    84,    84, -3000, -3000, -3000,    92, -3000, -3000,
    92,    92, -3000,    13,   -57,    43, -3000,    60,    21,   206,
 -3000, -3000,   -18,   109,  -258, -3000, -3000,    92, -3000, -3000,
 -3000,    35,   104,    -8,    92, -3000, -3000, -3000, -3000,    92,
 -3000,    15,   206,    21, -3000, -3000,    36,    92, -3000, -3000,
     4,    58,    50, -3000,   -18,    92,   -19,    17,    92, -3000,
 -3000, -3000,    68, -3000,     4, -3000,    92,    30, -3000,   -18,
 -3000 };
__YYSCLASS yytabelem yypgo[]={

     0,   286,    23,   285,    69,   273,   271,   501,   145,   144,
   266,   410,   262,    59,    33,   257,   256,   254,   248,   379,
   478,   233,   244,   439,   243,   229,   222,   221,   220,   413,
   216,   211,   210,    31,   207,   205,   202,   200,   192,   190,
   187,   185,   173,   170,   168,   158,   124 };
__YYSCLASS yytabelem yyr1[]={

     0,     5,     5,     5,    10,    10,     6,    12,    15,    12,
     8,     8,     8,    13,    13,    14,    14,    16,    16,    17,
    17,    18,    18,    18,    18,    18,    18,    20,    20,    22,
    22,    22,    22,    22,    22,    19,    19,    19,    21,    21,
    21,    21,    21,    21,    21,    21,    21,    23,    24,    23,
    25,    23,    23,    23,    23,    23,    23,    23,    23,    23,
    23,    23,    23,    23,    23,    23,    23,    23,    26,    27,
    23,    28,    23,    29,    29,    30,    29,    31,    29,     3,
     3,     3,     3,     3,     3,     3,     3,     3,     3,     7,
    32,     7,     1,     1,     2,     2,    33,    33,    34,    34,
     9,    35,    35,    36,    11,    11,    11,    37,    11,    38,
    39,    11,    40,    41,    11,    42,    43,    44,    11,    45,
    11,    11,    11,    11,    11,    11,     4,     4,    46,    46,
    46,    46,    46,    46,    46,    46,    46,    46,    46,    46 };
__YYSCLASS yytabelem yyr2[]={

     0,     6,     7,     5,     2,     4,     7,     6,     1,    10,
     0,     4,     6,     0,     4,     3,     7,     3,     7,     3,
     2,     3,     3,     7,     9,     9,     6,     2,     4,     3,
     3,     5,     9,    13,     6,     2,     5,     5,     2,     3,
     5,     5,     5,     5,     5,     4,     4,     2,     1,     9,
     1,     9,     7,     7,     7,     7,     7,     7,     7,     7,
     7,     7,     7,     7,     7,     7,     7,     7,     1,     1,
    15,     1,    11,     2,     7,     1,     9,     1,     9,     3,
     3,     3,     3,     3,     3,     3,     3,     3,     3,     2,
     1,     8,     3,     7,     1,     2,     0,     3,     1,     2,
     6,     0,     4,     9,     2,     4,     5,     1,    11,     1,
     1,    15,     1,     1,    17,     1,     1,     1,    25,     1,
     8,     7,     5,     5,     5,     7,     2,     3,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2 };
__YYSCLASS yytabelem yychk[]={

 -3000,    -5,    -6,    -8,   261,    91,   262,    -8,   -10,   -11,
    -9,   -33,   -36,   264,   263,   267,   260,   268,   269,   270,
   271,   123,    -7,   265,   -29,   -23,   -20,   -21,   -18,    42,
   -19,   292,   293,    33,   126,    45,    43,    38,   259,   -17,
    40,   -22,   257,   258,    46,    -4,   260,   -46,   259,   263,
   264,   265,   266,   267,   261,   268,   269,   270,   271,   257,
    93,   -16,    -4,    -7,   260,    -9,   -11,    59,   -11,   -38,
   -40,    40,    40,    58,   260,    59,    59,    59,    -7,   -35,
    44,    40,   284,   285,   124,    94,    38,   286,   287,    60,
   288,    62,   289,   290,   291,    43,    45,    42,    47,    37,
    63,    61,    -3,   282,   272,   273,   274,   275,   276,   277,
   278,   279,   280,   281,   292,   293,   -21,   -20,   -20,   -19,
   -20,   -21,   -21,   -21,   -21,   -20,   283,    91,   -20,    -7,
    -4,   -12,    40,    93,    44,   266,    40,   -11,   -33,    -2,
    -1,   -29,   -45,    59,    59,   125,   -11,   -32,    -7,   -24,
   -25,   -23,   -23,   -23,   -23,   -23,   -23,   -23,   -23,   -23,
   -23,   -23,   -23,   -23,   -23,   -23,   -23,   -26,    58,   -29,
   -30,   -31,   260,    -7,   257,    41,    41,   -13,   -14,    47,
    -4,    -4,   -37,    -7,   -41,    59,    41,    44,   -11,   -29,
    41,   -23,   -23,   -23,   -28,   -29,   -29,    93,    93,    40,
    41,   -15,    44,   -14,   -11,    41,   264,   -42,   -29,    58,
   -23,    -2,   -13,    -4,   -39,    40,   -34,    -7,   -27,    41,
    41,   -11,    -7,    59,   -23,    41,   -43,   -33,    41,   -44,
   -11 };
__YYSCLASS yytabelem yydef[]={

    10,    -2,    10,    96,     0,     0,     0,     0,    -2,     4,
   104,     0,    96,   109,   112,     0,    21,     0,     0,     0,
     0,   101,    97,     0,    89,    73,    39,    47,    -2,     0,
    -2,     0,     0,     0,     0,     0,     0,     0,    22,     0,
     0,    35,    29,    30,     0,     0,   126,   127,   128,   129,
   130,   131,   132,   133,   134,   135,   136,   137,   138,   139,
    11,     0,    17,     1,    21,     2,     5,   105,   106,     0,
    96,    96,    94,   119,     0,   122,   123,   124,     0,    96,
    90,     0,    48,    50,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    68,     0,    75,    77,    79,    80,    81,    82,    83,    84,
    85,    86,    87,    88,    36,    37,    28,    39,    40,    20,
    41,    42,    43,    44,    45,    46,     0,     0,    39,     0,
    31,     6,    13,    12,     0,   107,     0,   113,     0,     0,
    95,    92,    96,   121,   125,   100,   102,     0,     0,     0,
     0,    52,    53,    54,    55,    56,    57,    58,    59,    60,
    61,    62,    63,    64,    65,    66,    67,     0,    71,    74,
     0,     0,    23,     0,    29,    26,    34,     0,     8,     0,
    15,    18,    96,     0,     0,   115,    32,     0,   120,    91,
   103,    49,    51,     0,     0,    76,    78,    24,    25,    94,
     7,    13,     0,    14,   108,   110,     0,    98,    93,    69,
    72,     0,     0,    16,    96,     0,     0,    99,     0,    33,
     9,   111,     0,   116,    70,   114,    96,     0,   117,    96,
   118 };
typedef struct { char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

__YYSCLASS yytoktype yytoks[] =
{
	"ICONST",	257,
	"SCONST",	258,
	"BOBJ",	259,
	"IDENT",	260,
	"FUNC",	261,
	"FASSIGN",	262,
	"DO",	263,
	"WHILE",	264,
	"IF",	265,
	"ELSE",	266,
	"FOR",	267,
	"GOTO",	268,
	"BREAK",	269,
	"CONTINUE",	270,
	"RETURN",	271,
	";",	59,
	",",	44,
	"=",	61,
	"TA",	272,
	"DA",	273,
	"MA",	274,
	"AA",	275,
	"SA",	276,
	"SLA",	277,
	"SRA",	278,
	"BAA",	279,
	"BXA",	280,
	"BOA",	281,
	"CONDA",	282,
	"?",	63,
	":",	58,
	"DEREF",	283,
	"OR",	284,
	"AND",	285,
	"|",	124,
	"^",	94,
	"&",	38,
	"EQ",	286,
	"NE",	287,
	"<",	60,
	"LE",	288,
	">",	62,
	"GE",	289,
	"SL",	290,
	"SR",	291,
	"+",	43,
	"-",	45,
	"*",	42,
	"/",	47,
	"%",	37,
	"!",	33,
	"~",	126,
	"INC",	292,
	"DEC",	293,
	"(",	40,
	")",	41,
	"[",	91,
	"]",	93,
	"-unknown-",	-1	/* ends search */
};

__YYSCLASS char * yyreds[] =
{
	"-no such reduction-",
	"directive : fdecl FASSIGN expr",
	"directive : fdecl tdecl compound",
	"directive : tdecl command",
	"command : stmt",
	"command : command stmt",
	"fdecl : FUNC unreserved adecl",
	"adecl : '(' optargs ')'",
	"adecl : '(' params",
	"adecl : '(' params optargs ')'",
	"tdecl : /* empty */",
	"tdecl : '[' ']'",
	"tdecl : '[' locals ']'",
	"optargs : /* empty */",
	"optargs : '/' params",
	"params : unreserved",
	"params : params ',' unreserved",
	"locals : unreserved",
	"locals : locals ',' unreserved",
	"post : postlval",
	"post : postfix",
	"postlval : IDENT",
	"postlval : BOBJ",
	"postlval : post DEREF IDENT",
	"postlval : post '[' expr ']'",
	"postlval : post '[' ICONST ']'",
	"postlval : '(' lval ')'",
	"lval : postlval",
	"lval : '*' unary",
	"atom : ICONST",
	"atom : SCONST",
	"atom : '.' unreserved",
	"atom : IDENT '(' args ')'",
	"atom : '(' lval ')' '(' args ')'",
	"atom : '(' expr ')'",
	"postfix : atom",
	"postfix : postlval INC",
	"postfix : postlval DEC",
	"unary : postfix",
	"unary : lval",
	"unary : INC lval",
	"unary : DEC lval",
	"unary : '!' unary",
	"unary : '~' unary",
	"unary : '-' unary",
	"unary : '+' unary",
	"unary : '&' lval",
	"binary : unary",
	"binary : binary OR",
	"binary : binary OR binary",
	"binary : binary AND",
	"binary : binary AND binary",
	"binary : binary '|' binary",
	"binary : binary '^' binary",
	"binary : binary '&' binary",
	"binary : binary EQ binary",
	"binary : binary NE binary",
	"binary : binary '<' binary",
	"binary : binary LE binary",
	"binary : binary '>' binary",
	"binary : binary GE binary",
	"binary : binary SL binary",
	"binary : binary SR binary",
	"binary : binary '+' binary",
	"binary : binary '-' binary",
	"binary : binary '*' binary",
	"binary : binary '/' binary",
	"binary : binary '%' binary",
	"binary : binary '?'",
	"binary : binary '?' binary ':'",
	"binary : binary '?' binary ':' binary",
	"binary : binary '?' ':'",
	"binary : binary '?' ':' binary",
	"assign : binary",
	"assign : lval '=' assign",
	"assign : lval asn_op",
	"assign : lval asn_op assign",
	"assign : lval CONDA",
	"assign : lval CONDA assign",
	"asn_op : TA",
	"asn_op : DA",
	"asn_op : MA",
	"asn_op : AA",
	"asn_op : SA",
	"asn_op : SLA",
	"asn_op : SRA",
	"asn_op : BAA",
	"asn_op : BXA",
	"asn_op : BOA",
	"expr : assign",
	"expr : expr ','",
	"expr : expr ',' assign",
	"exprv : assign",
	"exprv : exprv ',' assign",
	"args : /* empty */",
	"args : exprv",
	"oexprn : /* empty */",
	"oexprn : expr",
	"oexprv : /* empty */",
	"oexprv : expr",
	"compound : '{' stmtlist '}'",
	"stmtlist : /* empty */",
	"stmtlist : stmtlist stmt",
	"ifcond : IF '(' expr ')'",
	"stmt : compound",
	"stmt : oexprn ';'",
	"stmt : ifcond stmt",
	"stmt : ifcond stmt ELSE",
	"stmt : ifcond stmt ELSE stmt",
	"stmt : WHILE",
	"stmt : WHILE '(' expr ')'",
	"stmt : WHILE '(' expr ')' stmt",
	"stmt : DO",
	"stmt : DO stmt",
	"stmt : DO stmt WHILE '(' expr ')'",
	"stmt : FOR '(' oexprn ';'",
	"stmt : FOR '(' oexprn ';' oexprv ';'",
	"stmt : FOR '(' oexprn ';' oexprv ';' oexprn ')'",
	"stmt : FOR '(' oexprn ';' oexprv ';' oexprn ')' stmt",
	"stmt : IDENT ':'",
	"stmt : IDENT ':' stmt",
	"stmt : GOTO IDENT ';'",
	"stmt : BREAK ';'",
	"stmt : CONTINUE ';'",
	"stmt : RETURN ';'",
	"stmt : RETURN expr ';'",
	"unreserved : IDENT",
	"unreserved : reserved",
	"reserved : BOBJ",
	"reserved : DO",
	"reserved : WHILE",
	"reserved : IF",
	"reserved : ELSE",
	"reserved : FOR",
	"reserved : FUNC",
	"reserved : GOTO",
	"reserved : BREAK",
	"reserved : CONTINUE",
	"reserved : RETURN",
	"reserved : ICONST",
};
#endif /* YYDEBUG */
#define YYFLAG  (-3000)
/* @@(#) $Revision: 1.1 $ */    

/*
** Skeleton parser driver for yacc output
*/

#if defined(NLS) && !defined(NL_SETN)
#include <msgbuf.h>
#endif

#ifndef nl_msg
#define nl_msg(i,s) (s)
#endif

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab

#ifndef __RUNTIME_YYMAXDEPTH
#define YYACCEPT	return(0)
#define YYABORT		return(1)
#else
#define YYACCEPT	{free_stacks(); return(0);}
#define YYABORT		{free_stacks(); return(1);}
#endif

#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( (nl_msg(30001,"syntax error - cannot backup")) );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!yyerrflag)
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
/* define for YYFLAG now generated by yacc program. */
/*#define YYFLAG		(FLAGVAL)*/

/*
** global variables used by the parser
*/
# ifndef __RUNTIME_YYMAXDEPTH
__YYSCLASS YYSTYPE yyv[ YYMAXDEPTH ];	/* value stack */
__YYSCLASS int yys[ YYMAXDEPTH ];		/* state stack */
# else
__YYSCLASS YYSTYPE *yyv;			/* pointer to malloc'ed value stack */
__YYSCLASS int *yys;			/* pointer to malloc'ed stack stack */

#if defined(__STDC__) || defined (__cplusplus)
#include <stdlib.h>
#else
	extern char *malloc();
	extern char *realloc();
	extern void free();
#endif /* __STDC__ or __cplusplus */


static int allocate_stacks(); 
static void free_stacks();
# ifndef YYINCREMENT
# define YYINCREMENT (YYMAXDEPTH/2) + 10
# endif
# endif	/* __RUNTIME_YYMAXDEPTH */
long  yymaxdepth = YYMAXDEPTH;

__YYSCLASS YYSTYPE *yypv;			/* top of value stack */
__YYSCLASS int *yyps;			/* top of state stack */

__YYSCLASS int yystate;			/* current state */
__YYSCLASS int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */
__YYSCLASS int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */



/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
int
yyparse()
{
	register YYSTYPE *yypvt;	/* top of value stack for $vars */

	/*
	** Initialize externals - yyparse may be called more than once
	*/
# ifdef __RUNTIME_YYMAXDEPTH
	if (allocate_stacks()) YYABORT;
# endif
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

	goto yystack;
	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
# ifndef __RUNTIME_YYMAXDEPTH
			yyerror( (nl_msg(30002,"yacc stack overflow")) );
			YYABORT;
# else
			/* save old stack bases to recalculate pointers */
			YYSTYPE * yyv_old = yyv;
			int * yys_old = yys;
			yymaxdepth += YYINCREMENT;
			yys = (int *) realloc(yys, yymaxdepth * sizeof(int));
			yyv = (YYSTYPE *) realloc(yyv, yymaxdepth * sizeof(YYSTYPE));
			if (yys==0 || yyv==0) {
			    yyerror( (nl_msg(30002,"yacc stack overflow")) );
			    YYABORT;
			    }
			/* Reset pointers into stack */
			yy_ps = (yy_ps - yys_old) + yys;
			yyps = (yyps - yys_old) + yys;
			yy_pv = (yy_pv - yyv_old) + yyv;
			yypv = (yypv - yyv_old) + yyv;
# endif

		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			printf( "Received token " );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = yylex() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				printf( "Received token " );
				if ( yychar == 0 )
					printf( "end-of-file\n" );
				else if ( yychar < 0 )
					printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
				yyerror( (nl_msg(30003,"syntax error")) );
				yynerrs++;
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
				yynerrs++;
			skip_init:
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					printf( "Error recovery discards " );
					if ( yychar == 0 )
						printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 2:
# line 171 "vtc.y"
{ Code(I_NULL); } break;
case 3:
# line 172 "vtc.y"
{ Code(I_NULL); } break;
case 6:
# line 179 "vtc.y"
{ curfunc = yypvt[-1].s;
					  if (find_prmt(yypvt[-1].s) != -1)
						  yyerror(ERR_PRMTNAME); } break;
case 8:
# line 185 "vtc.y"
{ reqargs = avarc; } break;
case 15:
# line 196 "vtc.y"
{ add_tag(avars, &avarc, yypvt[-0].s); } break;
case 16:
# line 197 "vtc.y"
{ add_tag(avars, &avarc, yypvt[-0].s); } break;
case 17:
# line 200 "vtc.y"
{ add_tag(lvars, &lvarc, yypvt[-0].s); } break;
case 18:
# line 201 "vtc.y"
{ add_tag(lvars, &lvarc, yypvt[-0].s); } break;
case 19:
# line 204 "vtc.y"
{ Code(I_EVAL); } break;
case 21:
# line 208 "vtc.y"
{ code_var(yypvt[-0].s); } break;
case 22:
# line 209 "vtc.y"
{ Code2(I_BOBJ, bobj, yypvt[-0].bobj); } break;
case 23:
# line 210 "vtc.y"
{ Code2(I_SCONST, sindex,
						enter_sconst(cstr_s(yypvt[-0].s)));
					  Code_pcall(PR_LOOKUP, 2); } break;
case 24:
# line 213 "vtc.y"
{ Code_pcall(OP_ADD, 2); } break;
case 25:
# line 214 "vtc.y"
{ if (yypvt[-1].num) { Code_iconst(yypvt[-1].num);
						    Code_pcall(OP_ADD, 2); } } break;
case 29:
# line 223 "vtc.y"
{ Code_iconst(yypvt[-0].num); } break;
case 30:
# line 224 "vtc.y"
{ Code2(I_SCONST, sindex, yypvt[-0].str); } break;
case 31:
# line 225 "vtc.y"
{ int ind = find_prmt(yypvt[-0].s);
					  if (ind != -1)
					       Code2(I_PPTR, pnum, ind);
					  else Code2(I_FPTR, ident, yypvt[-0].s); } break;
case 32:
# line 229 "vtc.y"
{ int ind = find_prmt(yypvt[-3].s);
					  if (ind != -1)
					       Code_pcall(ind, yypvt[-1].num);
					  else Code_fcall(yypvt[-3].s, yypvt[-1].num); } break;
case 33:
# line 233 "vtc.y"
{ Code2(I_EXEC, argc, yypvt[-1].num); } break;
case 36:
# line 239 "vtc.y"
{ Code_pcall(OP_POSTINC, 1); } break;
case 37:
# line 240 "vtc.y"
{ Code_pcall(OP_POSTDEC, 1); } break;
case 39:
# line 244 "vtc.y"
{ Code(I_EVAL); } break;
case 40:
# line 245 "vtc.y"
{ Code_pcall(OP_PREINC, 1); } break;
case 41:
# line 246 "vtc.y"
{ Code_pcall(OP_PREDEC, 1); } break;
case 42:
# line 247 "vtc.y"
{ Code_pcall(OP_NOT, 1); } break;
case 43:
# line 248 "vtc.y"
{ Code_pcall(OP_COMPL, 1); } break;
case 44:
# line 249 "vtc.y"
{ Code_pcall(OP_NEG, 1); } break;
case 48:
# line 255 "vtc.y"
{ Code(I_CVTB); Jmp(I_JMPPT); } break;
case 49:
# line 256 "vtc.y"
{ Code(I_CVTB); Dest; } break;
case 50:
# line 257 "vtc.y"
{ Code(I_CVTB); Jmp(I_JMPPF); } break;
case 51:
# line 258 "vtc.y"
{ Code(I_CVTB); Dest; } break;
case 52:
# line 259 "vtc.y"
{ Code_pcall(OP_BOR, 2); } break;
case 53:
# line 260 "vtc.y"
{ Code_pcall(OP_BXOR, 2); } break;
case 54:
# line 261 "vtc.y"
{ Code_pcall(OP_BAND, 2); } break;
case 55:
# line 262 "vtc.y"
{ Code_pcall(OP_EQ, 2); } break;
case 56:
# line 263 "vtc.y"
{ Code_pcall(OP_NE, 2); } break;
case 57:
# line 264 "vtc.y"
{ Code_pcall(OP_LT, 2); } break;
case 58:
# line 265 "vtc.y"
{ Code_pcall(OP_LE, 2); } break;
case 59:
# line 266 "vtc.y"
{ Code_pcall(OP_GT, 2); } break;
case 60:
# line 267 "vtc.y"
{ Code_pcall(OP_GE, 2); } break;
case 61:
# line 268 "vtc.y"
{ Code_pcall(OP_SL, 2); } break;
case 62:
# line 269 "vtc.y"
{ Code_pcall(OP_SR, 2); } break;
case 63:
# line 270 "vtc.y"
{ Code_pcall(OP_ADD, 2); } break;
case 64:
# line 271 "vtc.y"
{ Code_pcall(OP_SUB, 2); } break;
case 65:
# line 272 "vtc.y"
{ Code_pcall(OP_MULT, 2); } break;
case 66:
# line 273 "vtc.y"
{ Code_pcall(OP_DIV, 2); } break;
case 67:
# line 274 "vtc.y"
{ Code_pcall(OP_MOD, 2); } break;
case 68:
# line 275 "vtc.y"
{ Jmp(I_JMPF); } break;
case 69:
# line 276 "vtc.y"
{ Destnext; Jmp(I_JMP); } break;
case 70:
# line 277 "vtc.y"
{ Dest; } break;
case 71:
# line 278 "vtc.y"
{ Jmp(I_JMPPT); } break;
case 72:
# line 278 "vtc.y"
{ Dest; } break;
case 74:
# line 282 "vtc.y"
{ Code_pcall(OP_ASN, 2); } break;
case 75:
# line 283 "vtc.y"
{ Code(I_DUP); Code(I_EVAL); } break;
case 76:
# line 284 "vtc.y"
{ Code_pcall(yypvt[-2].num, 2);
					  Code_pcall(OP_ASN, 2); } break;
case 77:
# line 286 "vtc.y"
{ Code(I_DUP); Code(I_EVAL);
					  Jmp(I_JMPPT); } break;
case 78:
# line 288 "vtc.y"
{ Dest; Code_pcall(OP_ASN, 2); } break;
case 79:
# line 291 "vtc.y"
{ yyval.num = OP_MULT; } break;
case 80:
# line 291 "vtc.y"
{ yyval.num = OP_DIV; } break;
case 81:
# line 292 "vtc.y"
{ yyval.num = OP_MOD; } break;
case 82:
# line 292 "vtc.y"
{ yyval.num = OP_ADD; } break;
case 83:
# line 293 "vtc.y"
{ yyval.num = OP_SUB; } break;
case 84:
# line 293 "vtc.y"
{ yyval.num = OP_SL; } break;
case 85:
# line 294 "vtc.y"
{ yyval.num = OP_SR; } break;
case 86:
# line 294 "vtc.y"
{ yyval.num = OP_BAND; } break;
case 87:
# line 295 "vtc.y"
{ yyval.num = OP_BXOR; } break;
case 88:
# line 295 "vtc.y"
{ yyval.num = OP_BOR; } break;
case 90:
# line 300 "vtc.y"
{ Code(I_POP); } break;
case 92:
# line 304 "vtc.y"
{ yyval.num = 1; } break;
case 93:
# line 305 "vtc.y"
{ yyval.num = yypvt[-2].num + 1; } break;
case 94:
# line 308 "vtc.y"
{ yyval.num = 0; } break;
case 97:
# line 314 "vtc.y"
{ Code(I_POP); } break;
case 98:
# line 318 "vtc.y"
{ Code_iconst(1); } break;
case 103:
# line 328 "vtc.y"
{ Jmp(I_JMPF); } break;
case 106:
# line 332 "vtc.y"
{ Dest; } break;
case 107:
# line 333 "vtc.y"
{ Destnext; Jmp(I_JMP); } break;
case 108:
# line 333 "vtc.y"
{ Dest; } break;
case 109:
# line 334 "vtc.y"
{ Incloop(2); Ldest(0); } break;
case 110:
# line 335 "vtc.y"
{ Ljmp(1, I_JMPF); } break;
case 111:
# line 336 "vtc.y"
{ Ljmp(0, I_JMP); Ldest(1); Decloop; } break;
case 112:
# line 337 "vtc.y"
{ Incloop(3); Ldest(2); } break;
case 113:
# line 338 "vtc.y"
{ Ldest(0); } break;
case 114:
# line 339 "vtc.y"
{ Ljmp(2, I_JMPT); Ldest(1); Decloop; } break;
case 115:
# line 340 "vtc.y"
{ Incloop(4); Ldest(3); } break;
case 116:
# line 341 "vtc.y"
{ Ljmp(1, I_JMPF); Ljmp(2, I_JMP);
					  Ldest(0); } break;
case 117:
# line 343 "vtc.y"
{ Ljmp(3, I_JMP); Ldest(2); } break;
case 118:
# line 344 "vtc.y"
{ Ljmp(0, I_JMP); Ldest(1); Decloop; } break;
case 119:
# line 345 "vtc.y"
{ code_goto(yypvt[-1].s, 0); } break;
case 121:
# line 346 "vtc.y"
{ code_goto(yypvt[-1].s, 1); } break;
case 122:
# line 347 "vtc.y"
{ Break; } break;
case 123:
# line 348 "vtc.y"
{ Continue; } break;
case 124:
# line 349 "vtc.y"
{ Code(I_NULL); Return; } break;
case 125:
# line 350 "vtc.y"
{ Return; } break;
case 127:
# line 355 "vtc.y"
{ yyerror(ERR_RESERVED); yyval.s = ""; } break;
	}
	goto yystack;		/* reset registers in driver code */
}

# ifdef __RUNTIME_YYMAXDEPTH

static int allocate_stacks() {
	/* allocate the yys and yyv stacks */
	yys = (int *) malloc(yymaxdepth * sizeof(int));
	yyv = (YYSTYPE *) malloc(yymaxdepth * sizeof(YYSTYPE));

	if (yys==0 || yyv==0) {
	   yyerror( (nl_msg(30004,"unable to allocate space for yacc stacks")) );
	   return(1);
	   }
	else return(0);

}


static void free_stacks() {
	if (yys!=0) free((char *) yys);
	if (yyv!=0) free((char *) yyv);
}

# endif  /* defined(__RUNTIME_YYMAXDEPTH) */

@


1.1
log
@Initial revision
@
text
@d1179 1
a1179 1
/* @@(#) $Revision: 70.7 $ */    
@
