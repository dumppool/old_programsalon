head	2.2;
access;
symbols;
locks; strict;
comment	@ * @;


2.2
date	95.10.27.20.03.47;	author tsurace;	state Release;
branches;
next	2.1;

2.1
date	95.10.24.15.51.26;	author tsurace;	state Exp;
branches;
next	1.2;

1.2
date	95.10.24.15.42.59;	author tsurace;	state Exp;
branches;
next	1.1;

1.1
date	95.10.12.20.53.47;	author tsurace;	state Beta;
branches;
next	;


desc
@Signal handlers.
@


2.2
log
@Changed comments around #ifdef.
@
text
@/* signal.c: Handle signals in an intelligent manner */
/* $Id: signal.c 2.1 1995/10/24 15:51:26 tsurace Exp tsurace $ */

#include "vt.h"
#include <signal.h>

#ifndef __WIN32__
# include <sys/ioctl.h>
#endif /* __WIN32__ */

int break_pending = 0, console_pending = 0, winresize_pending = 0;
int stop_pending = 0;
extern int console_mode, rows, cols, debug;

#ifndef __WIN32__ /* Handle ctrl-c from main event loop instead */
static void sigint_handler()
{
	char c;

	signal(SIGINT, sigint_handler);
	coutput("[Q]uit [R]esume [B]reak [C]onsole [D]ebug: ");
	do
		c = lcase(getch());
	while (!strchr("qbrcd\033", c));
	switch(c) {
	    case 'q':
		coutput("Quit\n");
		cleanup();
		exit(0);
	    Case 'r':
	    case '\033':
		coutput("Resume\n");
	    Case 'b':
		coutput("Break\n");
		break_pending = 1;
	    Case 'c':
		coutput("Console\n");
		console_pending = !console_mode;
	    Case 'd':
		coutput("Debug\n[+] On [-] Off: ");
		while (!strchr("+-\033", c = getch()));
		switch(c) {
		    case '+':
			coutput("On\n");
			debug = 1;
		    Case '-':
			coutput("Off\n");
			debug = 0;
		}
	}
}
#endif /* __WIN32_ */

#ifdef SIGSTOP /* Windows NT doesn't understand STOPping */
static void sigtstp_handler()
{
	signal(SIGTSTP, sigtstp_handler);
	stop_pending = 1;
}
#endif /* SIGSTOP */

void stop() {
#ifdef SIGSTOP
	scroll(0, rows - 1);
	cmove(0, rows - 1);
	bflushfunc();
	tty_mode(0);
	kill(getpid(), SIGSTOP);
	tty_mode(1);
	auto_redraw();
#endif /* SIGSTOP */
	stop_pending = 0;
}

#ifdef SIGWINCH
static void sigwinch_handler()
{
	signal(SIGWINCH, sigwinch_handler);
	winresize_pending = 1;
}
#endif /* SIGWINCH */

void winresize() {
#ifdef TIOCGWINSZ
	struct winsize size;

	ioctl(0, TIOCGWINSZ, &size);
	if (size.ws_row && size.ws_col) {
		if (size.ws_row != rows)
			resize_screen((int) size.ws_row, (int) size.ws_col);
		else if (size.ws_col != cols) {
			cols = size.ws_col;
			auto_redraw();
		}
	}
#endif /* TIOCGWINSZ */
	winresize_pending = 0;
}

void init_signals()
{
#ifndef __WIN32__
	signal(SIGINT  , sigint_handler	  );
#endif /* __WIN32__ */
#ifdef SIGSTOP
	signal(SIGTSTP , sigtstp_handler  );
#endif /* SIGSTOP */
#ifdef SIGWINCH
	signal(SIGWINCH, sigwinch_handler );
#endif
#ifdef SIGPIPE
	signal(SIGPIPE , SIG_IGN	  );
#endif /* SIGPIPE */
}


@


2.1
log
@Roll.
@
text
@d2 1
a2 1
/* $Id: signal.c 1.2 1995/10/24 15:42:59 tsurace Exp tsurace $ */
d7 1
a7 2
#ifdef __WIN32__
#else
d15 1
a15 6
#ifdef __WIN32__
/*
 * Hide calls to getch() from the linker.  Some functionality will
 * be replaced by installing a Windoze accelerator key.
 */
#else /* not __WIN32 */
d52 1
a52 1
#endif /* Not __WIN32__ */
d104 1
a104 1
#endif /* !__WIN32__ */
@


1.2
log
@No changes.
@
text
@d2 1
a2 1
/* $Id: signal.c 1.1 1995/10/12 20:53:47 tsurace Exp tsurace $ */
@


1.1
log
@Initial revision
@
text
@d2 1
a2 1
/* $Id$ */
@
