head	2.2;
access;
symbols;
locks; strict;
comment	@ * @;


2.2
date	95.10.27.20.03.08;	author tsurace;	state Release;
branches;
next	2.1;

2.1
date	95.10.24.15.46.14;	author tsurace;	state Exp;
branches;
next	1.2;

1.2
date	95.10.16.01.53.56;	author tsurace;	state Beta;
branches;
next	1.1;

1.1
date	95.10.12.21.05.00;	author tsurace;	state Exp;
branches;
next	;


desc
@Misc utility functoins.
@


2.2
log
@Changed comments around #ifdef
@
text
@/* util.c: Miscellaneous utility functions */
/* $Id: util.c 2.1 1995/10/24 15:46:14 tsurace Exp tsurace $ */
 
#include "vt.h"
#include <signal.h>

#ifndef __WIN32__
#include <pwd.h>
#endif
 
extern int rows;
extern void endpwent();


#ifndef __WIN32__ /* These routines are replace by modal dialogs in win32 */
void vterror(s)
	char *s;
{
	char c;
 
	clrscr();
	scroll(0, rows - 1);
	bflushfunc();
	puts(s);
	write(1, "Dump core? ", 12);
	while (!strchr("YyNn", c = getch()));
	tty_mode(0);
	if (c == 'Y' || c == 'y') {
		write(1, "Yes\n", 4);
		abort();
	} else
		write(1, "No\n", 3);
	exit(1);
}

void vtdie(s)
	char *s;
{
	coutput(s);
	cleanup();
	exit(1);
}

void vtexit()
{
    cleanup();
    exit(0);
}
#endif /* Not __WIN32__ */

void regerror(s)
	char *s;
{
	vtc_errmsg = s;
}

char *dmalloc(size)
	size_t size;
{
	char *ret;
 
	if (size <= 0)
		return NULL;
	ret = tmalloc(size);
	if (!ret)
		vterror("malloc() failed");
	return ret;
}
 
char *drealloc(ptr, oldsize, newsize)
	char *ptr;
	size_t oldsize, newsize;
{
	char *ret;
 
	if (!ptr)
		return dmalloc(newsize);
	ret = trealloc(ptr, oldsize, newsize);
	if (!ret)
		vterror("realloc() failed");
	return ret;
}
 
void dfree(ptr, size)
	char *ptr;
	size_t size;
{
	if (ptr)
		tfree(ptr, size);
}
 
void cleanup()
{
	tty_mode(0);
	scroll(0, rows - 1);
	cmove(0, rows - 1);
	bflushfunc();
	cleanup_rmt();
}
 
#ifdef memset
void vtmemset(loc, val, len)
	char *loc;
	int val, len;
{
	while (len--)
		*loc++ = val;
}
#endif
 
/* Credits to Leo Plotkin and Anton Rang */
char *expand(s)
	char *s;
{
	String *buf = &wbufs[0];
	struct passwd *uinfo;
	char *homedir, *rest;
 
	homedir = getenv("HOME");
	if (*s != '~' || !homedir)
		return s;
	if (*++s == '/' || !*s) {
		s_acpy(buf, homedir);
		s_acat(buf, s);
		return buf->c.s;
	}
	rest = strchr(s, '/');
	if (rest)
		*rest = '\0';
	setpwent();
	uinfo = getpwnam(s + 1);
	if (!uinfo)
		return s;
	endpwent();
	if (rest)
		*rest = '/';
	s_acat(buf, uinfo->pw_dir);
	s_acat(buf, rest ? rest : "");
	return buf->c.s;
}

char *vt_itoa(num)
	int num;
{
	static char buf[32];
	char *p = &buf[31];
	int sign = 0;
 
	if (num < 0) {
		sign = 1;
		num = -num;
	}
	if (!num)
		*--p = '0';
	while (num) {
		*--p = num % 10 + '0';
		num /= 10;
	}
	if (sign)
		*--p = '-';
	return p;
}
 
int smatch(p, s)
	char *p, *s;
{
	while (*p) {
		if (*p == '*') {
			while (*++p == '?' || *p == '*') {
				if (*p == '?' && !*s++)
					return 0;
			}
			if (!*p)
				return 1;
			for (; *s; s++) {
				if (lcase(*s) == lcase(*p) && smatch(p, s))
					return 1;
			}
			return 0;
		} else if (*p == '?') {
			if (!*s++)
				return 0;
			p++;
		} else if (lcase(*p++) != lcase(*s++))
			return 0;
	}
	return !*s;
}
 
@


2.1
log
@Roll.
@
text
@d2 1
a2 1
/* $Id: util.c 1.2 1995/10/16 01:53:56 tsurace Beta tsurace $ */
d14 2
a15 5
#ifndef __WIN32__ 
/*
 * These routines are replace by dialogs that pop up a modal
 * dialog.
 */
d49 1
a49 1
#endif /* Not WIN32 */
@


1.2
log
@Changed a comment.
@
text
@d2 1
a2 1
/* $Id: util.c 1.1 1995/10/12 21:05:00 tsurace Exp tsurace $ */
@


1.1
log
@Initial revision
@
text
@d2 1
a2 1
/* $Id$ */
a13 1
/* This is handled by replacement routines that don't call getch() */
d15 4
@
