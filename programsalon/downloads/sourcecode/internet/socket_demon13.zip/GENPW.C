/***
 * genpw.c
 *  - This program will generate encrypted password strings for
 *    use in adding passwords to executable programs.
 *    You must provide a two character salt and a password.
 *    to compile: cc -o genpw genpw.c
 *
 ***/
#include <stdio.h>
main()
{
 char *pwe;
 char pw[15];
 char salt[3];
 char input[80];
 
   fprintf(stderr,"salt?: ");
   gets(input);
   strncpy(salt,input,2);
   fprintf(stderr,"password?: ");
   gets(input);
   strncpy(pw,input,8);
   pwe = (char *) crypt(pw,salt);
   fprintf(stderr,"encrypted: \"%s\"\n",pwe);
}
