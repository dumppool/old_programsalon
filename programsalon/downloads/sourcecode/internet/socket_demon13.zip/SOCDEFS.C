/****
 * socdefs.c
 *  - Contains global variables for Socket Demon
 ****/
#include "socdefs.h"

char    *program_name[PROG_SPEC_LEN];
boolean silent_mode;
boolean debug_mode;
int     port_to_use;
