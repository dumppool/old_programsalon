/*
    Simple wrapper class for checking validity of a URL
*/


#ifndef __INET_H__
#define __INET_H__

#include <wininet.h>

class WinInet
{
    public:
        WinInet();
        ~WinInet();

        BOOL IsConnected() const { return (InternetAttemptConnect(0)==ERROR_SUCCESS); }
        BOOL CheckLink(LPCSTR pcszURL);

    private:
        HINTERNET m_hInternet;
};


#endif