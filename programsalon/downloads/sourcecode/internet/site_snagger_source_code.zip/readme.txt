________________________________________________________________ 

SiteSnagger, Version 1.1
Copyright (c) 1998 Ziff-Davis Publishing Company
Written by Steven E. Sipe
First Published in PC Magazine, US Edition, February 24, 1998
http://www.zdnet.com/pcmag/pctech/content/17/04/ut1704.001.html
________________________________________________________________ 

PLATFORMS:
Windows 95, Windows NT 4.0

DESCRIPTION:
SiteSnagger (Version 1.1) lets you download the contents of a Web site to your PC's hard disk. You can download as much or as little of the site as you wish, and you can browse the information anytime and anywhere. SiteSnagger organizes the site information in a tree display of the pages and multimedia files that you've snagged. In addition, a Table of Contents page provides links to each of the pages you've downloaded, so you can quickly jump to any of them. 

REVISION HISTORY:
Version 1.1
- Fixed problem where links to non-html pages were not treated as multimedia files, and .htm was mistakenly appended to their name).
- Fixed negative length problem that caused a crash during fix-up phase.
- Added code to properly resolve relative paths URLs.
- Added support for Java classes and several new multimedia file types, and added a section to the online help that lists the supported file types.
- Added an option to manually configure proxy servers, and added a section to the online help to describe proxy set-up.
- Changed to a different set of WinInet connection calls to avoid problems with some servers.
- Added code to work around a CGI problem that prevented SiteSnagger from connecting when used with IE 4.x.

INSTALLATION:
To install SiteSnagger, copy its three program files (SiteSnag.exe, SiteSnag.cnt, and SiteSnag.hlp) to a subdirectory on your hard disk. To uninstall SiteSnagger, simply delete its program files. For details on program operation, refer to the program's online help file.

SUPPORT:
Help for PC Magazine's free utilities can be obtained in our online discussion areas, both on the World Wide Web (www.pcmag.com/discuss.htm) and on CompuServe (GO ZNT:TIPS, Section 2). You may find an answer to your question simply by reading the posted messages. The authors of current utilities generally visit these forums daily. If the author is not available and the forum sysops can't answer your question, the Utilities column editor, who also checks the forums each day, will contact the author for you.

LICENSE INFORMATION:
The programs presented in PC Magazine are copyrighted and cannot be copied or distributed or modified for any purpose, except that a single copy may be made for archival purposes only. Use of the programs is subject to the terms and conditions of the license agreement distributed with the programs.

----

Steven E. Sipe, the author of SiteSnagger, is a developer based in Wilmington, North Carolina. Sheryl Canter is the editor of the Utilities column and a contributing editor of PC Magazine. 

