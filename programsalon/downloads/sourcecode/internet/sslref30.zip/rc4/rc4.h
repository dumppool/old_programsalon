
/* WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING
 *
 * Always modify rc4.org since rc4.h is automatically generated from
 * it during SSLeay configuration.
 *
 * WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING 
 */

#ifndef HEADER_RC4_H
#define HEADER_RC4_H

#ifdef  __cplusplus
extern "C" {
#endif

/* using int types make the structure larger but make the code faster
 * on most boxes I have tested - up to %20 faster. */
#define RC4_INT unsigned int

#define MD5_DIGEST_LENGTH 16

typedef struct rc4_key_st
	{
	RC4_INT x,y;
	RC4_INT data[256];
	} RC4_KEY;

#ifndef NOPROTO
 
char *RC4_options(void);
void RC4_set_key(RC4_KEY *key, int len, unsigned char *data);
void RC4(RC4_KEY *key, unsigned long len, unsigned char *indata,
		unsigned char *outdata);

#else

char *RC4_options();
void RC4_set_key();
void RC4();

#endif

#ifdef  __cplusplus
}
#endif

#endif
