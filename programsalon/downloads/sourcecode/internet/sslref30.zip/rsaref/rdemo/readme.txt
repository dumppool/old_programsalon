
The rdemo project is create from rdemo.c and all c files in parent dir.