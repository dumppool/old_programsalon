
All files in this directory at first have move to parent dir.