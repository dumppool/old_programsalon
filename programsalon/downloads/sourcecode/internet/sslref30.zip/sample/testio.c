/*  *********************************************************************
    File: testio.c

    SSLRef 3.0 Final -- 11/19/96

    Copyright (c)1996 by Netscape Communications Corp.

    By retrieving this software you are bound by the licensing terms
    disclosed in the file "LICENSE.txt". Please read it, and if you don't
    accept the terms, delete this software.

    SSLRef 3.0 was developed by Netscape Communications Corp. of Mountain
    View, California <http://home.netscape.com/> and Consensus Development
    Corporation of Berkeley, California <http://www.consensus.com/>.

    *********************************************************************

    File: testio.c     I/O callbacks for sslsampl


    ****************************************************************** */

#include "ssl.h"

#ifdef WIN32
#include <winsock.h>
#include <time.h>
#else
#include <unistd.h>
#endif

SSLErr SocketRead(SSLBuffer buffer, uint32 *processed, void *state);
SSLErr SocketWrite(SSLBuffer buffer, uint32 *processed, void *state);
extern int report(char * s, int option);

/*
SSLErr
SocketRead(SSLBuffer buffer, uint32 *processed, void *state)
{
#ifdef WIN32
    SOCKET      sock = *(SOCKET*)state;
    int         length;
    uint32      done;
    
    *processed = done = 0;

    do
    {   length = recv(sock, (char*)buffer.data + done, buffer.length - done, 0);
    } while   ( (length > 0) && ((done += length) < buffer.length) );

    *processed = done;
    
    if (*processed != buffer.length)
        return SSLIOErr;
    
#else
    int         sock = *(int*)state, length;
    uint32      done;
    
    *processed = done = 0;

    do
        length = read(sock, (char*)buffer.data + done, buffer.length - done);
    while (length > 0 && ((done += length) < buffer.length));
    
    *processed = done;
    
    if (*processed != buffer.length)
        return SSLIOErr;
#endif
    
    return SSLNoErr;
}

SSLErr
SocketWrite(SSLBuffer buffer, uint32 *processed, void *state)
{   
#ifdef WIN32
    SOCKET  sock = *(SOCKET*)state;
#else
    int     sock = *(int*)state;
#endif
    int     length;
    uint32  done;
    
    *processed = done = 0;
#ifdef WIN32
    do
        length = send(sock, (char*)buffer.data + done, buffer.length - done, 0);
    while ((length > 0) && ((done += length) < buffer.length));
#else
    do
        length = write(sock, (char*)buffer.data + done, buffer.length - done);
    while (length > 0 && ((done += length) < buffer.length));
#endif
    
    *processed = done;
    
    if (*processed != buffer.length)
        return SSLIOErr;
    
    return SSLNoErr;
}
*/
#include <stdio.h>

#define Debugdest stdout

SSLErr
SocketRead(SSLBuffer buffer, uint32 *processed, void *state)
{
#ifdef WIN32
    SOCKET      sock = *(SOCKET*)state;
    int         length;
    uint32      done;
	SSLErr		err = SSLNoErr;
    
    *processed = done = 0;

//	report("sock-read\n", 0);
    do
    {
		fprintf(Debugdest, "    receive  %4d    ", buffer.length);
		length = recv(sock, (char*)buffer.data + done, buffer.length - done, 0);
 		fprintf(Debugdest, "    received %4d", length);
        if (length <= 0)
            break;
        done += length;
        if (done >= buffer.length)
            break;
	} while (1); // ( (length > 0) && ((done += length) < buffer.length) );
    
	//++++++
    if (done == buffer.length)
        fprintf(Debugdest, "\n");
 	else if (length==-1)// || (length==0))
	{
        if (done==0)
        {
		    int err2;
		    err2 = WSAGetLastError();
            //WSASetLastError(err2);
		    if (err2==WSAEWOULDBLOCK)
		    {
			    fprintf(Debugdest, "    recv-wldblk\n");
			    err = SSLWouldBlockErr;			
		    }
		    else
            {
			    fprintf(Debugdest, "    recv-errcode %d\n", err2);
                err = SSLIOErr;
            }
        }
        else
            err = SSLWouldBlockErr;			
	}
	else if (length == 0)
    {
		fprintf(Debugdest, "ret = zero %d\n", WSAGetLastError());
        err = SSLIOErr;
        //err = SSLWouldBlockErr;			
    }
    else
    {
        *(int*)0 = 0;
    }

	*processed = done;
    
	//if (*processed != buffer.length)
    //    err = SSLIOErr;
    

#else // not WIN
    int         sock = *(int*)state, length;
    uint32      done;
    
    *processed = done = 0;

    do
        length = read(sock, (char*)buffer.data + done, buffer.length - done);
    while (length > 0 && ((done += length) < buffer.length));    
  
	*processed = done;
	if (*processed != buffer.length)
        err = SSLIOErr;
#endif	
   
	fflush(Debugdest);
    return err; 
}

SSLErr
SocketWrite(SSLBuffer buffer, uint32 *processed, void *state)
{   
#ifdef WIN32
    SOCKET  sock = *(SOCKET*)state;
#else
    int     sock = *(int*)state;
#endif
    int     length;
    uint32  done;
	SSLErr  err = SSLNoErr;
    
    *processed = done = 0;
//	report("sock-write\n", 0);

#ifdef WIN32
    do{
		fprintf(Debugdest, "send %4d    ", buffer.length);
        length = send(sock, (char*)buffer.data + done, buffer.length - done, 0);
		fprintf(Debugdest, "sent %4d", length);
        if (length <= 0)
            break;
        done += length;
        if (done >= buffer.length)
            break;
	}
    while (1); // ((length > 0) && ((done += length) < buffer.length));
	    
	//++++++
    if (done == buffer.length)
        fprintf(Debugdest, "\n");
 	else if (length==-1)
	{
        if (done==0)
        {
            int err2;
            err2 = WSAGetLastError();
            //WSASetLastError(err2);
            if (err2==WSAEWOULDBLOCK)
            {
                fprintf(Debugdest, "send-wldblk\n");
                err = SSLWouldBlockErr;		
            }
            else
            {
                fprintf(Debugdest, "    send-errcode %d\n", err2);
                err = SSLIOErr;
            }
        }
        else
            err = SSLWouldBlockErr;			
	}
    else
    {
        *(int*)0 = 0;
    }

    *processed = done;
    
	//if (*processed != buffer.length)
    //    err = SSLIOErr;
    
#else
    do
        length = write(sock, (char*)buffer.data + done, buffer.length - done);
    while (length > 0 && ((done += length) < buffer.length));

    *processed = done;
	if (*processed != buffer.length)
        err = SSLIOErr;
#endif    
    
	fflush(Debugdest);
    return err;
}
