this project testssl include files:
	1  current dir's c files
	2  ../src's c files
	3  ../rsaref's c files
	4  ../libdes's cbc_enc.c, ecb_enc.c and set_key.c
	5  ../sha's c file

file test.crt and private.key is copyed to here from ../

file SessionDB is a cache file