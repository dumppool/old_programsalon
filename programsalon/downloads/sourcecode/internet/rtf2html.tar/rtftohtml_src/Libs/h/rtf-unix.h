/*
 * Library functions for UNIX versions of translators
 */

FILE	*UnixOpenLibFile ();
void	UnixSetProgPath ();
