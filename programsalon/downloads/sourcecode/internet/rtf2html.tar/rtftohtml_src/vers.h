#define PVers "2.7.5"
#define VCstr "2.7.5, Chris Hector, cjh@cray.com"
#define VDstr "2.7.5, 4 Nov 1994"
