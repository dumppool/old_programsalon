#include <stdio.h>
#include <fcntl.h>

/* Winsock version */
#include <winsock.h>
#include <memory.h>
#include <string.h>
#include <io.h>

int Verbose = 0;

int talk_start(void);
int talk_daemon(void);
int talk_listen(void);
int talk_connect(char *,char *);
int acceptone(SOCKET);
int doit(char *,SOCKET);

#define RCVSIZE 512

void
talk_error(char *msg)
{
	fprintf(stderr,"Error: %s. error=%d\n",msg,WSAGetLastError());
}

int
sock_start(void)
{
	WSADATA WSAData;
	int err;

	/* Even using binmode.obj doesn't set these to BINARY.  Sheesh! */
	_setmode(0,_O_BINARY);
	_setmode(1,_O_BINARY);
	_setmode(2,_O_BINARY);

	if ((err = WSAStartup(MAKEWORD(2,0), &WSAData)) != 0) {
		fprintf(stderr, "WSAStartup error - %d\n", err);
		return 1;
	}
	else {
		fprintf(stderr,"%s\n",WSAData.szDescription,
			WSAData.szSystemStatus, MB_OK);
		return 0;
	}
}
