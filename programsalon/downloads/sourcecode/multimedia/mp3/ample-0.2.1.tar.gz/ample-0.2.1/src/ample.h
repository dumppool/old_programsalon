#define SHOUTSERVMSG "ICY 200 OK\r\n\
icy-notice1:This stream is served using Ample/%s\r\n\
icy-notice2:AMPLE - An MP3 LEnder - http://ample.sf.net/\r\n\
icy-name:Ample\r\n\
icy-genre:Mixed\r\n\
icy-url:http://ample.sf.net/\r\n\
icy-pub:1\r\n\
icy-metaint:%d\r\n\
icy-br:128\r\n\r\n"
#define BASICSERVMSG "HTTP/1.0 200 OK\r\nServer: Ample/%s\r\nContent-Type: audio/x-mpeg\r\n\r\n"
#define HTTPSERVMSG "HTTP/1.0 200 OK\r\nServer: Ample/%s\r\nContent-Type: text/html\r\n\r\n"

#define BUFFSIZE 1024
#define BYTESBETWEENMETA 16000
#define NETBUFFSIZE 4000

#undef TRUE
#define TRUE 1
#undef FALSE
#define FALSE 0
#define DIE(args) do { printf("DIE: "); if(errno < 1) { perror(args); } else { printf(args); printf("\n"); } exit(1); } while(0)
#define IF_DEBUG(tasks) do { if(opt_debug) { tasks } } while(0)
#define DEBUG(args) IF_DEBUG(printf("DBG: "); printf args;)
#define GETCWD(cwd) do {                                    \
                errno = 0;                                  \
                cwd = getcwd(NULL,0);                       \
                if(errno == EACCES) {                       \
	                DIE("---- No access to dir\n");     \
 	        } else if(errno == EINVAL && cwd == NULL) { \
			/* Auto-malloc not supported */     \
			errno = 0;                          \
			cwd = getcwd(NULL,PATH_MAX);        \
		}                                           \
		if(errno)                                   \
			/* That didn't help things */       \
			DIE("getcwd");                      \
         } while(0)

struct config {
	int port;
	int index;
	int order;
	int metadata;
	char * path;
	char * user;
	char * pass;
	char * program_name;
};

extern void playfiles(int conn, struct config *conf);

extern int opt_debug;

