/*
 * $Id: options.c,v 1.10 2001/11/12 16:19:44 alphix Exp $
 *
 * This file is part of Ample.
 *
 * Ample is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Ample is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Ample; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#if HAVE_CONFIG_H
#include <config.h>
#endif
#if HAVE_GETOPT_H
#include <getopt.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "ample.h"
#include "options.h"


static void 
usage(int status, struct config * conf)
{
	if(status) {
		fprintf(stderr, "Try `%s --help' for more information.\n", conf->program_name);
		exit(1);
	} else {
		/* This is several printf's to please ISO C89 */
		printf(USAGE1, conf->program_name);
		printf(NOTE);
		printf(USAGE2, DEF_PORT);
		exit(0);
	}
}


char *
getline(char *buffer, char *beginning) 
{
	char *start = buffer, *tmp;
	int length;
	
	while(TRUE) {
		if(!strncasecmp(start,beginning,strlen(beginning))) {
			if((tmp = index((start + 1), '\n')) == NULL)
				return NULL;
			if(*(tmp - 1) != '\r') {
				printf("---- client seems to ignore HTTP standards\n");
				length = tmp - start + 1;
			} else {
				length = tmp - start;
			}

			tmp = (char *)malloc(length);
			snprintf(tmp, length, "%s", start);
			return tmp;
		}
		
		if((start = index(start, '\n')) == NULL)
			return NULL;
		
		start++;
		continue;
	}
}

/* This function will deal with leading / and also
 * illegal characters according to RFC 1738:
 * ' ',',','<','>','"','#','%','{','}','|','\','^','~','[',']' and '`'
 * These should be (but aren't always) be encoded as %<two character hex code>
 * <hi> would become %3Chi%3E
 */
char *
decodeurl(char *url) 
{
	char *current = url;
	char *ret = (char *)malloc(strlen(url) + 1);
	char *pos = ret;
	int hexval;
	char hexbuf[3];

	hexbuf[2] = '\0';
	if(*current == '/') {
		sprintf(pos, "./");
		current++;
		pos = pos + 2;
	}

	while(*current != '\0') {
		if(*current != '%') {
			*pos = *current;
			pos++;
			current++;
		} else {
			if(((hexbuf[0] = *(current + 1)) == '\0') ||
			   ((hexbuf[1] = *(current + 2)) == '\0')) {
				strncpy(pos, current, 3);
				pos = pos + 2;
				break;
			} else if ((hexval = strtol(hexbuf, NULL, 16)) == 0) {
				strncpy(pos, current, 3);
				pos = pos + 3;
			} else {
				*pos = (char)hexval;
				pos++;
			}
			current = current + 3;
		}
	}
	
	*pos = '\0';
	DEBUG(("decodeurl parses %s as %s\n",url,ret););
	return ret;
}


int 
readrequest (int conn, struct config * conf) 
{
	ssize_t readsize;
	char buffer[BUFFSIZE];
	char *begin, *end, *line, *request;
	
        readsize = read(conn,&buffer,BUFFSIZE-1);
	if(readsize == BUFFSIZE-1) {
		printf("---- invalid reply\n");
		return FALSE;
	} 
	buffer[readsize] = '\0';

	line = getline(buffer, "get");
	DEBUG(("reply:\n%s\n",buffer););
	DEBUG(("parsing reply\n"););
	DEBUG(("GET request was: %s\n",line););
	
	if(line == NULL || strlen(line) < 14) {
		printf("----weird get request (non existent or too short), ignoring\n");
		return FALSE;
	}
	
	begin = index(line,' ');
	end = rindex(line,' ');
	if(begin == NULL || (end - begin) < 2) {
		printf("----weird get request (two spaces not found), ignoring\n");
		free(line);
		return FALSE;
	}
	begin++;
	*end = '\0';
	
	request = decodeurl(begin);
	conf->path = request;
	begin = rindex(request, 'i');

	if(begin && (!strcasecmp(begin,"index.html") || !strcasecmp(begin,"index.htm"))) {
		*begin = '\0';
		conf->index = TRUE;
		printf("INDEX WAS REQUESTED!, path is %s\n",conf->path);
	}
	free(line);

	line = getline(buffer, "Icy-MetaData:");
	if(line != NULL && atoi((line + 13)) > 0)
		conf->metadata = TRUE;
	free(line);
	
	return TRUE;
}


void 
checkopt(int argc, char * argv[], struct config * conf)
{
	int c,i;
#if HAVE_GETOPT_H
	static struct option const longopts[] =
		{
			{"port", required_argument, NULL, 'p'},
			{"order", no_argument, NULL, 'o'},
			{"help", no_argument, NULL, 'h'},
			{"debug", no_argument, NULL, 'd'},
			{"version", no_argument, NULL, 'v'},
			{NULL, 0, NULL, 0}
		};
#endif
	
	memset(conf, 0, sizeof(struct config));
	conf->program_name = argv[0];
	conf->port = DEF_PORT;
	conf->path = DEF_PATH;
	conf->metadata = FALSE;
	
#if HAVE_GETOPT_H	
	while((c = getopt_long(argc, argv, "p:ohdv", longopts, &i)) != -1) {
#else
		while((c = getopt(argc, argv, "p:ohdv")) != -1) {
#endif
			switch(c) {
			case 'p':
				if(atoi(optarg) > 0)
					conf->port = atoi(optarg);
				break;
			case 'o':
				conf->order = TRUE;
				break;
			case 'h':
				usage(FALSE, conf);
				break;
			case 'd':
				opt_debug = TRUE;
				break;
			case 'v':
				printf("Ample version %s\n",AMPLE_VERSION);
				exit(0);
			default:
				usage(TRUE, conf);
			}
		}
		
		if(optind < argc) {
			DEBUG(("user given path %s\n",argv[optind]));
			conf->path = argv[optind];
		}
	}
	
	
	
	
