/*
 * $Id: helper.c,v 1.4 2001/11/12 16:19:44 alphix Exp $
 *
 * This file is part of Ample.
 *
 * Ample is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Ample is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Ample; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <libgen.h>
#include <string.h>

#include "ample.h"
#include "entries.h"
#include "helper.h"

int 
writemetadata(int to, mp3entry *entry, int *metaflag) {
	int msglen;
	int padding;
	int towrite;
	int written;
	char *buf;

	if(*metaflag) {
		*metaflag = FALSE;

		msglen = strlen(entry->title) + 28;
		padding = 16 - msglen % 16;
		towrite = msglen + padding + 1;
		
		buf = malloc(towrite);
		memset(buf, 0, towrite);
		sprintf(buf, "%cStreamTitle='%s';StreamUrl='';", (msglen + padding)/16, entry->title);
	} else {
		towrite = 1;
		buf = malloc(towrite);
		memset(buf, 0, towrite);
	}

	written = write(to, buf, towrite);
	free(buf);
	if(written == towrite)
		return TRUE;
	else
		return FALSE;
}

static void 
stripspaces(char *buffer) {
	int i = 0;
	
	while(*(buffer + i) != '\0')
		i++;
	
	while(i >= 0) {
		if(*(buffer + i) == ' ')
			*(buffer + i) = '\0';
		else if(*(buffer + i) == '\0')
			i--;
		else
			break;
	}
}

static int 
checkid3v1(FILE *file) {
	char buf[4];
	
	if((fseek(file, -128, SEEK_END) == 0) &&
	   (fgets(buf, 4, file) != NULL) &&
	   (strcmp(buf, "TAG") == 0))
		return TRUE;
	else
		return FALSE;
}

static int 
checkid3v2(FILE *file) {
	char buf[4];
	
	if((fseek(file, 0, SEEK_SET) == 0) &&
	   (fgets(buf, 4, file) != NULL) &&
	   (strcmp(buf, "ID3") == 0))
		return TRUE;
	else
		return FALSE;
}

static int 
getid3v1(FILE *file, mp3entry *entry) {
	char buffer[31];
	int offsets[3] = {-95,-65,-125};
	int i;
	char *result;

	result = (char *)malloc(3*30 + 2*3 + 1);
	*result = '\0';
	
	for(i=0;i<3;i++) {
		if(fseek(file, offsets[i], SEEK_END) != 0) {
			free(result);
			return FALSE;
		}
		
		
		fgets(buffer, 31, file);
		stripspaces(buffer);
		if(buffer[0] != '\0' && *result != '\0')
			strcat(result, " - ");
		strcat(result, buffer);
	}

	if(*result == '\0') {
		free(result);
		return FALSE;
	} else {
		entry->title = (char *)realloc(result, strlen(result + 1));
		return TRUE;
	}
}

static int 
getid3v2(FILE *file, mp3entry *entry) {
	return FALSE;
}

int 
checkid3tags(mp3entry *entry) {
	FILE *file;
	int retval;
	char *copy,*title;

	if((file = fopen(entry->path, "r")) == NULL)
		return FALSE;

	entry->hasid3v2 = checkid3v2(file);
	entry->hasid3v1 = checkid3v1(file);

	if(entry->hasid3v2 && getid3v2(file, entry))
		retval = TRUE;		
	else if(entry->hasid3v1 && getid3v1(file, entry))
		retval = TRUE;
	else {
		copy = strdup(entry->path);
		title = basename(copy);
		entry->title = malloc(strlen(title) - 3);
		strncpy(entry->title, title, strlen(title) - 4);
		*(entry->title + strlen(title) - 4) = '\0';
		free(copy);
		retval = FALSE;
	}

	fclose(file);
	return retval;
}

int 
setstartpos(FILE *file, mp3entry *entry, struct config *conf) {
	char sync[4];
	long offset;

	if(!conf->metadata)
		offset = 0;
	else if(!entry->hasid3v2)
		offset = 0;
	else if(fseek(file, 6, SEEK_SET) != 0)
		offset = 0;
	else if(fread(sync, sizeof(char), 4, file) != 4)
		offset = 0;
	else
		offset = UNSYNC(sync[0],sync[1],sync[2],sync[3]) + 10;

	DEBUG(("The ID3v2 length is %ld\n", offset));
	
	if(fseek(file, offset, SEEK_SET) != 0)
		return FALSE;

	return TRUE;
}

static void 
id3v2writesafe(char *buf, int value) {
	sprintf(buf, "%c%c%c%c", SYNCBYTE1(value), SYNCBYTE2(value), SYNCBYTE3(value), SYNCBYTE4(value));
}

static void 
id3v2create(char *buf, char *name) {
	sprintf((buf + 0),"%s%c%c%c", ID3V2_ID, ID3V2_MAJOR_VERS, ID3V2_MINOR_VERS, ID3V2_HEADER_FLAGS);
	id3v2writesafe((buf + 6), 11 + 1 + strlen(name));
	sprintf((buf + 10), "%s", ID3V2_FRAME_ID);
	id3v2writesafe((buf + 14), 1 + 1 + strlen(name));
	sprintf((buf + 18), "%c%c%c", ID3V2_FRAME_FLAGS1, ID3V2_FRAME_FLAGS2, ID3V2_FRAME_ENC);
}

/* FIXME: Remove trailing .mp3 from ID3 tag */
void 
writeid3v2(int fd, mp3entry * entry)
{
	int i;
	char *header;
	char *pathcopy = strdup(entry->path);
	char *filename = basename(pathcopy);
	int length = ID3V2_HEADER_LEN + strlen(filename) + 1;

	header = (char *)malloc(length);
	id3v2create(header, filename);
	sprintf((header + ID3V2_HEADER_LEN), "%s", filename);

	IF_DEBUG(for(i = 0; i < length; i++) { printf("ID3v2 test - char %d is: %X\n", i, header[i]); } );

	write(fd, header, length);
	free(header);
	free(pathcopy);
}
