/*
 * $Id: entries.c,v 1.13 2001/11/12 16:19:44 alphix Exp $
 *
 * This file is part of Ample.
 *
 * Ample is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Ample is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Ample; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#if HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <string.h>
#if HAVE_LIMITS_H
#include <limits.h>
#endif

#include "ample.h"
#include "entries.h"
#include "helper.h"

#define INITIAL_FILES 50
#define INITIAL_DIRS 10

mp3entry * root;


void 
addentry(mp3entry ** rootentry, mp3entry * toadd) 
{
	mp3entry * tmp = NULL;

	if(*rootentry == NULL) {
		toadd->next = toadd;
		*rootentry = toadd;
	} else {
		tmp = *rootentry;
		while(tmp->next != *rootentry)
			tmp = tmp->next;
		tmp->next = toadd;
		toadd->next = *rootentry;
	}
}


void 
removeentry(mp3entry **rootentry, mp3entry *toremove) 
{
	mp3entry *tmp = *rootentry;

	if(*rootentry == NULL)
		return;

	if(toremove->next == toremove) {
		if(*rootentry == toremove)
			*rootentry = NULL;
		else
			DIE("Inconsistent linked list");

	} else {
		while(tmp->next != toremove)
			tmp = tmp->next;
		tmp->next = toremove->next;
		if(*rootentry == toremove)
			*rootentry = toremove->next;
	}
}


void 
cleartree(mp3entry *rootentry) 
{
	mp3entry *tmp;

	while(rootentry != NULL) {
		tmp = rootentry;
		removeentry(&rootentry, rootentry);
		free(tmp->path);
		free(tmp);
	}
}

	
int 
countentries(mp3entry *rootentry) 
{
	mp3entry *tmp = rootentry;
	int i = 0;

	if(tmp != NULL)
		do {
			i++;
			tmp = tmp->next;
		} while(tmp != rootentry);
	
	return i;
}


void 
shuffleentries(void) 
{
	int random;
	int i = countentries(root);
	mp3entry * oldroot = root;
	mp3entry * tmp;
	root = NULL;

	srand(time(NULL));
	while(i) {
		random = 1 + (int)((float)i*rand()/(RAND_MAX+1.0));
		tmp = oldroot;
		i--;

		while(random > 1) {
			tmp = tmp->next;
			random--;
		}

		removeentry(&oldroot, tmp);
		addentry(&root, tmp);
	}	
}


void 
dumpentries() 
{
	int i = 0;
	mp3entry * tmp = root;
	
	if(tmp == NULL)
		return;
	
	do {
		i++;
		printf("%d: %s - ID3V1: %d - ID3V2: %d\n",i,tmp->path,tmp->hasid3v1,tmp->hasid3v2);
		tmp = tmp->next;
	} while (tmp != root);
}


void 
createhtml(FILE *st, char *dirname, int baselen) 
{
	int i = 0;
	mp3entry * tmp = root;
	
	if(tmp == NULL || st == NULL)
		return;
	
	fprintf(st, "<html><body bgcolor=\"#b0c0ff\"><center><p><h1>%s</h1></p><table border=\"1\">\n", dirname);
	do {
		i++;
		fprintf(st, "<tr><td>%d</td><td>%s</td></tr>\n",i,(tmp->path + baselen));
		tmp = tmp->next;
	} while (tmp != root);
	fprintf(st, "</table></center></body></html>\r\n");
}


static int 
psort(const void *arg1, const void *arg2) 
{
        return strcmp(*(char * const *)arg1, *(char * const *)arg2);
}


static void 
resizearray(char ***array, int *size, int *maxsize) 
{
	if(*size + 1 == *maxsize) {
		*maxsize = *maxsize * 2;
		*array = realloc((char *)(*array), *maxsize * sizeof(char *));
		if(*array == NULL)
			DIE("realloc");
	}
}


void 
getfiles(char *path, struct config *conf) 
{
	DIR *dir;
	struct dirent *dirent;
	char *filename;
	int namelen;
	struct stat statbuf;
	char *cwd;
	mp3entry *mp3buf;
	char **filearray;
	char **dirarray;
	int maxfiles = INITIAL_FILES;
	int maxdirs = INITIAL_DIRS;
	int numfiles = 0;
	int numdirs = 0;

	chdir(path);
	GETCWD(cwd);
	if (!(dir = opendir(".")))
		DIE("opendir");

	if (!(filearray = (char **) malloc (maxfiles * sizeof (char *))))
		DIE("malloc");

	if (!(dirarray = (char **) malloc (maxdirs * sizeof(char *))))
		DIE("malloc");

	while((dirent = readdir(dir))) {
		filename = dirent->d_name;
		namelen = strlen(filename);

		/* File/dir shouldn't begin with . */
		if((*(filename)) == '.') {
			DEBUG(("Ignoring %s, starts with .\n",filename));
		}
		/* lstat must work */
		else if(lstat(filename,&statbuf)) {
			DEBUG(("Ignoring %s, lstat doesn't work\n",filename));
		}
		/* Don't follow symlinks */
		else if (S_ISLNK(statbuf.st_mode)) {
			DEBUG(("Ignoring %s, it's a symlink\n",filename));			
		}
		/* Is it a directory? If so add it to the dir array */
		else if(S_ISDIR(statbuf.st_mode)) {
			DEBUG(("Adding dir %s/%s\n",cwd,filename));
			resizearray(&dirarray, &numdirs, &maxdirs);
			dirarray[numdirs] = (char *)malloc(strlen(cwd) + strlen(filename) + 2);
			sprintf(dirarray[numdirs], "%s/%s", cwd, filename);
			numdirs++;
		}
		/* File must be a regular file */
		else if(!S_ISREG(statbuf.st_mode)) {
			DEBUG(("Ignoring %s, not a regular file\n",filename));
		}
		/* Filename must be at least as long as x.mp3 */
		else if(namelen < 5) {
			DEBUG(("Ignoring %s, too short name\n",filename));
		}
		/* Filename must end with .mp3 (case insensitive) */
		else if(strcasecmp((filename + namelen - 4),".mp3")) {
			DEBUG(("Ignoring %s, doesn't end with \".mp3\"\n",filename));
		}
		/* File size must be > 0 */
		else if(statbuf.st_size == 0) {
			DEBUG(("Ignoring %s, zero size\n",filename));
		} 
		/* OK, it's valid, add it to the files array */
		else {
			DEBUG(("Adding %s/%s\n",cwd,filename));
			resizearray(&filearray, &numfiles, &maxfiles);
			filearray[numfiles] = (char *)malloc(strlen(cwd) + strlen(filename) + 2);
			sprintf(filearray[numfiles], "%s/%s", cwd, filename);
			numfiles++;
		}
		errno = 0;
	}
	
	if (errno)
		DIE("readdir");
	
	resizearray(&dirarray, &numdirs, &maxdirs);
	resizearray(&filearray, &numfiles, &maxfiles);
	dirarray[numdirs] = NULL;
	filearray[numfiles] = NULL;
	numdirs = 0;
	numfiles = 0;
	
	if(conf->order) {
		DEBUG(("Sorting dirs\n"));
		qsort(dirarray, numdirs, sizeof(char *), psort);
		DEBUG(("Sorting files\n"));
		qsort(filearray, numfiles, sizeof(char *), psort);
	}

	while(filearray[numfiles] != NULL) {
		mp3buf = (mp3entry *)malloc(sizeof(mp3entry));
		mp3buf->path = filearray[numfiles];
		checkid3tags(mp3buf);
		addentry(&root, mp3buf);
		numfiles++;
	}

	while(dirarray[numdirs] != NULL) {
		printf("---> Directory %s, processing\n", dirarray[numdirs]);
		getfiles(dirarray[numdirs], conf);
		if(chdir(cwd))
			DIE("chdir");
		printf("<--- Directory %s, done\n", dirarray[numdirs]);
		numdirs++;
	}

	free(filearray);
	free(dirarray);
	free(cwd);
	closedir(dir);
}







