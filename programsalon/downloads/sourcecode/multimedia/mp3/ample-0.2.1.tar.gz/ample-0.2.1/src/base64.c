/*
 * $Id: base64.c,v 1.2 2001/11/12 16:19:44 alphix Exp $
 *
 * This file is part of Ample.
 *
 * Ample is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Ample is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Ample; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "base64.h"

#include <stdlib.h>
#include <string.h>

int valof(char c) {
        static char * alphabet =
		"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	char * tmp = alphabet;
	int i = 0;

	if (c == '\0')
		return 0;
	
	while(1) {
		if (*tmp == '\0')
			return 0;
		if (*tmp == c)
			return i;
		i++;
		tmp++;
	}
}

void nextchunk(char ** c, char * chunk) {
	int i;
	int b64val[4];

	for(i=0; i < 4; i++) {
		b64val[i] = valof(**c);
		if(**c != '\0')
			(*c)++;
	}
	
	*(chunk + 0) = CHAR1(b64val[0],b64val[1]);
	*(chunk + 1) = CHAR2(b64val[1],b64val[2]);
	*(chunk + 2) = CHAR3(b64val[2],b64val[3]);
	
}

char * b64dec(char * msg) {
	char * tmp = msg;
	char * buffer;
	char chunk[4];

	if(*tmp == '\0')
		return NULL;
	
	memset(chunk,0,sizeof(chunk));
	buffer = (char *)malloc(strlen(msg) + 1);
	
	while(*tmp != '\0') {
		nextchunk(&tmp,chunk);
		strcat(buffer,chunk);
	}
	
	return buffer;
}


int main(void) {
	char * msg = "ZGF2aWQ6ZGF2aWQ=";
	printf("The answer is %s\n",b64dec(msg));
}
	
