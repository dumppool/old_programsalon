/*
 * Ample - An MP3 lender
 *
 * (c) Copyright - David H�rdeman <david@2gen.com> - 2001
 *
 */

/*
 * $Id: ample.c,v 1.17 2001/11/12 16:19:44 alphix Exp $
 *
 * This file is part of Ample.
 *
 * Ample is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Ample is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Ample; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#if HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <signal.h>
#include <sys/wait.h>

#include "ample.h"
#include "entries.h"
#include "options.h"
#include "helper.h"

/* FIXME: make this nonstatic */
#define MAX_CHILDREN 1

int opt_debug = 0;
volatile int num_children = 0;
int bytestometa = BYTESBETWEENMETA;

static int 
copyamount(int readlimit, struct config *conf) {

	if((conf->metadata && (bytestometa < NETBUFFSIZE)) && (readlimit < NETBUFFSIZE))
		return (readlimit > bytestometa ? bytestometa : readlimit);
	else if(conf->metadata && (bytestometa < NETBUFFSIZE))
		return bytestometa;
	else if(readlimit < NETBUFFSIZE)
		return readlimit;
	else
		return NETBUFFSIZE;
}


static int 
preparedata(char *buf, long end, FILE *from, struct config *conf) {
	long current = ftell(from);
	int diff = (int)(end - current);
	int amount;

	if(current < 0)
		DIE("ftell");
	
	/*DEBUG(("Amount prepared to be sent: %d\n", copyamount(diff, conf)));*/
	amount = fread(buf, sizeof(char), copyamount(diff, conf), from);

	if(ferror(from))
		DIE("read");

	if(feof(from) || current == end)
		return 0;
	
	return amount;
}

static void 
senddata(int to, char *buf, int amount, struct config *conf, int *metaflag) {

	if(write(to,buf,amount) != amount)
		DIE("error writing to client");

	if(conf->metadata) {
		bytestometa = bytestometa - amount;
		if(bytestometa == 0) {
			if(writemetadata(to,root,metaflag))
				bytestometa = BYTESBETWEENMETA;
			else
				DIE("error writing to client");
		}
	}
}

static void 
setoffsets(FILE *stream, long *end, struct config *conf) {
	
	if(fseek(stream,0,SEEK_END) != 0)
		DIE("setoffsets - fseek");
	if((*end = ftell(stream)) < 0)
		DIE("ftell");
	if(root->hasid3v1)
		*end = *end - 128;
	if(!setstartpos(stream, root, conf))
		DIE("setstartpos");
}

void 
playfiles(int conn, struct config *conf) 
{
	FILE *file;
	char buf[NETBUFFSIZE];
	int amount;
	int metaflag;
	long end;

	while((metaflag = TRUE)) {
		printf("---- opening file %s\n",root->path);
		DEBUG(("Info - id3v2:%d - id3v1:%d - Title:%s\n", root->hasid3v2, root->hasid3v1, root->title));

		if ((file = fopen(root->path,"r")) == NULL)
			DIE("fopen failed");
		
		setoffsets(file, &end, conf);

		while((amount = preparedata(buf, end, file, conf)))
			senddata(conn, buf, amount, conf, &metaflag);

		if(!root->hasid3v2 && !conf->metadata)
			writeid3v2(conn, root);
		
		fclose(file);
		root = root->next;
	} 
}

static int openconn(struct sockaddr_in *address, struct config *conf) 
{
	int i = 1;
	int sock;
	
	if ((sock = socket(PF_INET,SOCK_STREAM, 0)) < 0)
		DIE("socket");
	
	i = 1;
	setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &i, sizeof(i));
	address->sin_family = AF_INET;
	address->sin_port = htons(conf->port);
	memset(&address->sin_addr, 0, sizeof(address->sin_addr));
	
	if(bind(sock, (struct sockaddr *)address, sizeof(struct sockaddr_in)))
		DIE("bind");
	
	if (listen(sock,5))
		DIE("listen");
	
	return sock;
}

int handleclient(int conn, struct config *conf) {
	char *basedir;
	char *clientdir;
	FILE *stream;

	DEBUG(("reading request\n"));
	if(!readrequest(conn, conf)) {
		close(conn);
		return -1;
	}
	
	DEBUG(("requested path %s\n", conf->path));
	GETCWD(basedir);
	if(chdir(conf->path))
		DIE("Incorrect dir");
	GETCWD(clientdir);
	
	DEBUG(("doing security checks\n"));
	if(strncmp(basedir, clientdir, strlen(basedir) - 1)) {
		close(conn);
		DEBUG(("basedir %s, clientdir %s\n", basedir, clientdir));
		DIE("Aiee, client tried to break out of base directory");
	}
	
	printf("---- looking for mp3 files in subdirectory %s\n", conf->path);
	getfiles(".", conf);
	
	if(!root)
		DIE("No files");

	if(!conf->index && !conf->order) {
		printf("---- shuffling mp3 files\n");
		shuffleentries();
		DEBUG(("listing mp3 files\n"););
	}

	DEBUG(("listing mp3 files\n"););
	IF_DEBUG(dumpentries(););
	
	stream = fdopen(conn, "a");
	if(conf->index) {
		printf("---- entering HTTP mode\n");
		fprintf(stream, HTTPSERVMSG, AMPLE_VERSION);
		fflush(stream);
		createhtml(stream,(clientdir + strlen(basedir)),(strlen(clientdir) + 1));
	} else if (conf->metadata) {
		printf("---- entering MP3-Metadata mode\n");
		fprintf(stream, SHOUTSERVMSG, AMPLE_VERSION, BYTESBETWEENMETA);
		fflush(stream);
		playfiles(conn, conf);
	} else {
		printf("---- entering MP3-Basic mode\n");
		fprintf(stream, BASICSERVMSG, AMPLE_VERSION);
		fflush(stream);
		playfiles(conn, conf);
	}
	fclose(stream);
		
	cleartree(root);
	return 0;
}

void handlechild(int signal) {
	int status;
	pid_t pid;

	num_children--;
	pid = wait(&status);
	printf("---- child with pid %d exited\n", pid);
	DEBUG(("number of children %d\n",num_children));
}

int main(int argc, char * argv[]) 
{
	struct sockaddr_in address;
	struct config conf;
	int conn,sock;
	pid_t pid;
	socklen_t addrlen = sizeof(struct sockaddr_in);
	char *cwd;
	struct sigaction sa;
	sigset_t chld;

	root = NULL;
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = handlechild;
	sigemptyset(&chld);
	sigaddset(&chld, SIGCHLD);
	if(sigaction(SIGCHLD, &sa, NULL))
		perror("sigaction");

	checkopt(argc, argv, &conf);	
	if(chdir(conf.path))
		DIE("incorrect root for mp3 files specified\n");
	printf("---- using %s as root for mp3 files\n", conf.path);
	GETCWD(cwd);

	printf("---- opening socket, port %d\n",conf.port);
	sock = openconn(&address, &conf);

	while ((conn = accept(sock, (struct sockaddr *) &address, &addrlen))) {

		if(conn < 0) {
			if(errno == EINTR)
				continue;
			else
				DIE("accept");
		}

		IF_DEBUG(printf("---- incoming connection\n"););
		sigprocmask(SIG_BLOCK, &chld, NULL);
		pid = fork();
		
		if(pid < 0) {
			DIE("fork");
		} else if(pid > 0) {
			num_children++;
			DEBUG(("number of children %d\n",num_children));
			printf("---- connection from %s:%d handled by child with pid %d\n", 
			       inet_ntoa(address.sin_addr), address.sin_port, pid);
			sigprocmask(SIG_UNBLOCK, &chld, NULL);
			
			close(conn);
			while(num_children >= MAX_CHILDREN)
				pause();
			continue;			
		} else {
			return(handleclient(conn, &conf));
		}
	}
	
	close(sock);
	free(cwd);
	return 0;
}
