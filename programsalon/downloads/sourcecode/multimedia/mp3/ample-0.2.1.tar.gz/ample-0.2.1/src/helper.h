#define ID3V2_ID "ID3"
#define ID3V2_HEADER_LEN 21
#define ID3V2_MAJOR_VERS 0x04
#define ID3V2_MINOR_VERS 0x00
#define ID3V2_HEADER_FLAGS 0x00

#define ID3V2_FRAME_ID "TIT2"
#define ID3V2_FRAME_FLAGS1 0x00
#define ID3V2_FRAME_FLAGS2 0x00
#define ID3V2_FRAME_ENC 0x00

#define SYNCBYTE1(value) ((value >> (3*7)) & 0x7F)
#define SYNCBYTE2(value) ((value >> (2*7)) & 0x7F)
#define SYNCBYTE3(value) ((value >> (1*7)) & 0x7F)
#define SYNCBYTE4(value) ((value >> (0*7)) & 0x7F)
#define UNSYNC(b1,b2,b3,b4) (((b1 & 0x7F) << (3*7)) + ((b2 & 0x7F) << (2*7)) + ((b3 & 0x7F) << (1*7)) + ((b4 & 0x7F) << (0*7)))

extern void writeid3v2(int fd, mp3entry *entry);
extern int checkid3tags(mp3entry *entry);
extern int writemetadata(int to, mp3entry *entry, int *metaflag);
extern int setstartpos(FILE *file, mp3entry *entry, struct config *conf);

