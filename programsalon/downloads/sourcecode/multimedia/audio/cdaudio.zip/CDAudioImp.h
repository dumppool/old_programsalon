// CDAudio.h: interface for the CCDAudioImp class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __CDAUDIOIMP_H__
#define __CDAUDIOIMP_H__

class CCDAudioImp  
{
public:
	CCDAudioImp();
	virtual ~CCDAudioImp();

	BOOL Open (void);
	void Close (void);
	BOOL Play (void);
	void Stop (void);
	void Pause (void);
	int GetTotalTracks (void);
	int GetCurrentTrack (void);
	void GetTotalLength (int *, int*);
	void GetTrackLength (int, int *, int *);
	int GetMinutes (void);
	int GetSeconds (void);
	int GetFrames (void);
	BOOL IsDriveReady (void);
	BOOL IsPlaying (BOOL *);
	BOOL IsAudioTrack (int);
	BOOL SeekTo (int, int, int, int);
	void OpenDrive (void);
	void CloseDrive (void);
	void SkipForward (int);
	void SkipBack (int);
	
private:
	BOOL m_bOpened, m_bPaused, m_bPlaying;
	WORD m_wDeviceID;
};

#endif //__CDAUDIOIMP_H__
