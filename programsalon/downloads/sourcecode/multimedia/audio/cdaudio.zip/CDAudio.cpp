// CDAudio.cpp : Implementation of CCDAudio

#include "stdafx.h"
#include "CDAudioX.h"
#include "CDAudio.h"

/////////////////////////////////////////////////////////////////////////////
// CCDAudio


STDMETHODIMP CCDAudio::Open()
{
	// TODO: Add your implementation code here
	m_CDAudioImp.Open();
	return S_OK;
}

STDMETHODIMP CCDAudio::Close()
{
	// TODO: Add your implementation code here
	m_CDAudioImp.Close();
	return S_OK;
}

STDMETHODIMP CCDAudio::Play()
{
	// TODO: Add your implementation code here
	if( m_CDAudioImp.IsDriveReady () )
	{
		if( !m_CDAudioImp.Play() )
		{
			Error(_T("This CD cannot be played."));
		}
	}
	else
	{
		Error ( _T("The CD drive or audio CD is not ready."));
	}
	return S_OK;
}

STDMETHODIMP CCDAudio::Stop()
{
	// TODO: Add your implementation code here
	m_CDAudioImp.Stop();
	return S_OK;
}

STDMETHODIMP CCDAudio::Pause()
{
	// TODO: Add your implementation code here
	m_CDAudioImp.Pause();
	return S_OK;
}

STDMETHODIMP CCDAudio::OpenDrive()
{
	// TODO: Add your implementation code here
	m_CDAudioImp.OpenDrive();
	return S_OK;
}

STDMETHODIMP CCDAudio::CloseDrive()
{
	// TODO: Add your implementation code here
	m_CDAudioImp.CloseDrive();
	return S_OK;
}

STDMETHODIMP CCDAudio::get_Playing(BOOL *pVal)
{
	// TODO: Add your implementation code here
	BOOL Paused;
	*pVal = m_CDAudioImp.IsPlaying( &Paused );
	return S_OK;
}

/*STDMETHODIMP CCDAudio::put_Playing(BOOL newVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}*/

STDMETHODIMP CCDAudio::get_TotalTracks(long *pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_CDAudioImp.GetTotalTracks();
	return S_OK;
}

STDMETHODIMP CCDAudio::get_CurrentTrack(long *pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_CDAudioImp.GetCurrentTrack();
	return S_OK;
}

STDMETHODIMP CCDAudio::get_Minutes(long *pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_CDAudioImp.GetMinutes();
	return S_OK;
}

STDMETHODIMP CCDAudio::get_Seconds(long *pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_CDAudioImp.GetSeconds();
	return S_OK;
}

STDMETHODIMP CCDAudio::get_Frames(long *pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_CDAudioImp.GetFrames();
	return S_OK;
}

STDMETHODIMP CCDAudio::GetTotalLength(long *pMinVal, long *pSecVal)
{
	// TODO: Add your implementation code here
	int min , sec;
	m_CDAudioImp.GetTotalLength( &min , &sec );
	*pMinVal = min;
	*pSecVal = sec;
	return S_OK;
}

STDMETHODIMP CCDAudio::GetTrackLength(long Track, long *pMin, long *pSec)
{
	// TODO: Add your implementation code here
	int min , sec;
	m_CDAudioImp.GetTrackLength( Track, &min , &sec );
	*pMin = min;
	*pSec = sec;
	return S_OK;
}

STDMETHODIMP CCDAudio::SkipBack(long seconds)
{
	// TODO: Add your implementation code here
	m_CDAudioImp.SkipBack( seconds );
	return S_OK;
}

STDMETHODIMP CCDAudio::SkipForward(long Seconds)
{
	// TODO: Add your implementation code here
	m_CDAudioImp.SkipForward( Seconds );
	return S_OK;
}

STDMETHODIMP CCDAudio::SeekTo(long track, long minutes, long seconds , long frame)
{
	// TODO: Add your implementation code here
	m_CDAudioImp.SeekTo( track , minutes, seconds , frame );
	return S_OK;
}
