/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed Jun 02 21:58:14 1999
 */
/* Compiler settings for E:\BlueWindMill\CDAudioX\CDAudioX.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __CDAudioX_h__
#define __CDAudioX_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ICDAudio_FWD_DEFINED__
#define __ICDAudio_FWD_DEFINED__
typedef interface ICDAudio ICDAudio;
#endif 	/* __ICDAudio_FWD_DEFINED__ */


#ifndef ___ICDAudioEvents_FWD_DEFINED__
#define ___ICDAudioEvents_FWD_DEFINED__
typedef interface _ICDAudioEvents _ICDAudioEvents;
#endif 	/* ___ICDAudioEvents_FWD_DEFINED__ */


#ifndef __CDAudio_FWD_DEFINED__
#define __CDAudio_FWD_DEFINED__

#ifdef __cplusplus
typedef class CDAudio CDAudio;
#else
typedef struct CDAudio CDAudio;
#endif /* __cplusplus */

#endif 	/* __CDAudio_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ICDAudio_INTERFACE_DEFINED__
#define __ICDAudio_INTERFACE_DEFINED__

/* interface ICDAudio */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICDAudio;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("55492B1E-183F-11D3-B908-00002140A1A4")
    ICDAudio : public IDispatch
    {
    public:
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_Enabled( 
            /* [in] */ VARIANT_BOOL vbool) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_Enabled( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbool) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Open( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Play( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Stop( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Pause( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE OpenDrive( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CloseDrive( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Playing( 
            /* [retval][out] */ BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TotalTracks( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CurrentTrack( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Minutes( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Seconds( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Frames( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetTotalLength( 
            long __RPC_FAR *pMinVal,
            long __RPC_FAR *pSecVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetTrackLength( 
            long Track,
            long __RPC_FAR *pMin,
            long __RPC_FAR *pSec) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SkipBack( 
            long seconds) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SkipForward( 
            long Seconds) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SeekTo( 
            long track,
            long minutes,
            long seconds,
            long frame) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICDAudioVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICDAudio __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICDAudio __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICDAudio __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ICDAudio __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ICDAudio __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ICDAudio __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ICDAudio __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Enabled )( 
            ICDAudio __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL vbool);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Enabled )( 
            ICDAudio __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbool);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Open )( 
            ICDAudio __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Close )( 
            ICDAudio __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Play )( 
            ICDAudio __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Stop )( 
            ICDAudio __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Pause )( 
            ICDAudio __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *OpenDrive )( 
            ICDAudio __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CloseDrive )( 
            ICDAudio __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Playing )( 
            ICDAudio __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TotalTracks )( 
            ICDAudio __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CurrentTrack )( 
            ICDAudio __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Minutes )( 
            ICDAudio __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Seconds )( 
            ICDAudio __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Frames )( 
            ICDAudio __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTotalLength )( 
            ICDAudio __RPC_FAR * This,
            long __RPC_FAR *pMinVal,
            long __RPC_FAR *pSecVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTrackLength )( 
            ICDAudio __RPC_FAR * This,
            long Track,
            long __RPC_FAR *pMin,
            long __RPC_FAR *pSec);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SkipBack )( 
            ICDAudio __RPC_FAR * This,
            long seconds);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SkipForward )( 
            ICDAudio __RPC_FAR * This,
            long Seconds);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SeekTo )( 
            ICDAudio __RPC_FAR * This,
            long track,
            long minutes,
            long seconds,
            long frame);
        
        END_INTERFACE
    } ICDAudioVtbl;

    interface ICDAudio
    {
        CONST_VTBL struct ICDAudioVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICDAudio_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICDAudio_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICDAudio_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICDAudio_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICDAudio_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICDAudio_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICDAudio_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICDAudio_put_Enabled(This,vbool)	\
    (This)->lpVtbl -> put_Enabled(This,vbool)

#define ICDAudio_get_Enabled(This,pbool)	\
    (This)->lpVtbl -> get_Enabled(This,pbool)

#define ICDAudio_Open(This)	\
    (This)->lpVtbl -> Open(This)

#define ICDAudio_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define ICDAudio_Play(This)	\
    (This)->lpVtbl -> Play(This)

#define ICDAudio_Stop(This)	\
    (This)->lpVtbl -> Stop(This)

#define ICDAudio_Pause(This)	\
    (This)->lpVtbl -> Pause(This)

#define ICDAudio_OpenDrive(This)	\
    (This)->lpVtbl -> OpenDrive(This)

#define ICDAudio_CloseDrive(This)	\
    (This)->lpVtbl -> CloseDrive(This)

#define ICDAudio_get_Playing(This,pVal)	\
    (This)->lpVtbl -> get_Playing(This,pVal)

#define ICDAudio_get_TotalTracks(This,pVal)	\
    (This)->lpVtbl -> get_TotalTracks(This,pVal)

#define ICDAudio_get_CurrentTrack(This,pVal)	\
    (This)->lpVtbl -> get_CurrentTrack(This,pVal)

#define ICDAudio_get_Minutes(This,pVal)	\
    (This)->lpVtbl -> get_Minutes(This,pVal)

#define ICDAudio_get_Seconds(This,pVal)	\
    (This)->lpVtbl -> get_Seconds(This,pVal)

#define ICDAudio_get_Frames(This,pVal)	\
    (This)->lpVtbl -> get_Frames(This,pVal)

#define ICDAudio_GetTotalLength(This,pMinVal,pSecVal)	\
    (This)->lpVtbl -> GetTotalLength(This,pMinVal,pSecVal)

#define ICDAudio_GetTrackLength(This,Track,pMin,pSec)	\
    (This)->lpVtbl -> GetTrackLength(This,Track,pMin,pSec)

#define ICDAudio_SkipBack(This,seconds)	\
    (This)->lpVtbl -> SkipBack(This,seconds)

#define ICDAudio_SkipForward(This,Seconds)	\
    (This)->lpVtbl -> SkipForward(This,Seconds)

#define ICDAudio_SeekTo(This,track,minutes,seconds,frame)	\
    (This)->lpVtbl -> SeekTo(This,track,minutes,seconds,frame)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id][propput] */ HRESULT STDMETHODCALLTYPE ICDAudio_put_Enabled_Proxy( 
    ICDAudio __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL vbool);


void __RPC_STUB ICDAudio_put_Enabled_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE ICDAudio_get_Enabled_Proxy( 
    ICDAudio __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbool);


void __RPC_STUB ICDAudio_get_Enabled_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_Open_Proxy( 
    ICDAudio __RPC_FAR * This);


void __RPC_STUB ICDAudio_Open_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_Close_Proxy( 
    ICDAudio __RPC_FAR * This);


void __RPC_STUB ICDAudio_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_Play_Proxy( 
    ICDAudio __RPC_FAR * This);


void __RPC_STUB ICDAudio_Play_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_Stop_Proxy( 
    ICDAudio __RPC_FAR * This);


void __RPC_STUB ICDAudio_Stop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_Pause_Proxy( 
    ICDAudio __RPC_FAR * This);


void __RPC_STUB ICDAudio_Pause_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_OpenDrive_Proxy( 
    ICDAudio __RPC_FAR * This);


void __RPC_STUB ICDAudio_OpenDrive_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_CloseDrive_Proxy( 
    ICDAudio __RPC_FAR * This);


void __RPC_STUB ICDAudio_CloseDrive_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICDAudio_get_Playing_Proxy( 
    ICDAudio __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pVal);


void __RPC_STUB ICDAudio_get_Playing_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICDAudio_get_TotalTracks_Proxy( 
    ICDAudio __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ICDAudio_get_TotalTracks_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICDAudio_get_CurrentTrack_Proxy( 
    ICDAudio __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ICDAudio_get_CurrentTrack_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICDAudio_get_Minutes_Proxy( 
    ICDAudio __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ICDAudio_get_Minutes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICDAudio_get_Seconds_Proxy( 
    ICDAudio __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ICDAudio_get_Seconds_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICDAudio_get_Frames_Proxy( 
    ICDAudio __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ICDAudio_get_Frames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_GetTotalLength_Proxy( 
    ICDAudio __RPC_FAR * This,
    long __RPC_FAR *pMinVal,
    long __RPC_FAR *pSecVal);


void __RPC_STUB ICDAudio_GetTotalLength_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_GetTrackLength_Proxy( 
    ICDAudio __RPC_FAR * This,
    long Track,
    long __RPC_FAR *pMin,
    long __RPC_FAR *pSec);


void __RPC_STUB ICDAudio_GetTrackLength_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_SkipBack_Proxy( 
    ICDAudio __RPC_FAR * This,
    long seconds);


void __RPC_STUB ICDAudio_SkipBack_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_SkipForward_Proxy( 
    ICDAudio __RPC_FAR * This,
    long Seconds);


void __RPC_STUB ICDAudio_SkipForward_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICDAudio_SeekTo_Proxy( 
    ICDAudio __RPC_FAR * This,
    long track,
    long minutes,
    long seconds,
    long frame);


void __RPC_STUB ICDAudio_SeekTo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICDAudio_INTERFACE_DEFINED__ */



#ifndef __CDAUDIOXLib_LIBRARY_DEFINED__
#define __CDAUDIOXLib_LIBRARY_DEFINED__

/* library CDAUDIOXLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_CDAUDIOXLib;

#ifndef ___ICDAudioEvents_DISPINTERFACE_DEFINED__
#define ___ICDAudioEvents_DISPINTERFACE_DEFINED__

/* dispinterface _ICDAudioEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__ICDAudioEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("55492B20-183F-11D3-B908-00002140A1A4")
    _ICDAudioEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _ICDAudioEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _ICDAudioEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _ICDAudioEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _ICDAudioEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _ICDAudioEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _ICDAudioEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _ICDAudioEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _ICDAudioEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _ICDAudioEventsVtbl;

    interface _ICDAudioEvents
    {
        CONST_VTBL struct _ICDAudioEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _ICDAudioEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _ICDAudioEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _ICDAudioEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _ICDAudioEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _ICDAudioEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _ICDAudioEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _ICDAudioEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___ICDAudioEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_CDAudio;

#ifdef __cplusplus

class DECLSPEC_UUID("55492B1F-183F-11D3-B908-00002140A1A4")
CDAudio;
#endif
#endif /* __CDAUDIOXLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
