@BOTTOM@
/* Architecture defines */
#undef __i386__
#undef __alpha__
#undef __ppc__
#undef __sparc__ 
