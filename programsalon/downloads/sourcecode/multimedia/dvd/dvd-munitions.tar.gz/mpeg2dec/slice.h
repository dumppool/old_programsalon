
void slice_init(void);


void slice_new(picture_t *picture);
void slice_reset_dc_pred(slice_t* slice);
void slice_reset_pmv(slice_t* slice);
