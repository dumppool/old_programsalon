#ifndef _CVDVEXT_H_
#define _CVDVEXT_H_

#include <sys/ioctl.h>
#include "cvdvtypes.h"

#define OSD_Draw(file,cmd) ioctl(fileno(file),_IO(CVDV_IOCTL_MAGIC,IOCTL_DRAW),&cmd)
#define DecoderCommand(file,cmd) ioctl(fileno(file),_IO(CVDV_IOCTL_MAGIC,IOCTL_DECODER),&cmd)

#endif  // _CVDVEXT_H_
