#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/mman.h>
#include <errno.h>

void main(int argc,char *argv[]) {
  unsigned char *buf=NULL,*tbuf,*rawbuf=NULL,*trawbuf;
  unsigned char b1,b2;
  unsigned long bytes;
  int p,r,g,b;

  buf = (unsigned char *)malloc(1280);
  if (!buf)
    perror("allocating main buffer"),exit(1);
  rawbuf = (unsigned char *)malloc(3840);
  if (!rawbuf)
    perror("allocating secondary buffer"),exit(1);

  while (bytes = read(STDIN_FILENO,buf,1280)) {
/*    fprintf(stderr,"got %d bytes from read\n",bytes);*/
    tbuf = buf;
    trawbuf = rawbuf;
    for (p=0;p<(bytes/2);p++) {
      b2 = *(tbuf++);
      b1 = *(tbuf++);
      *(trawbuf++) = b1 & 0xf8;
      *(trawbuf++) = ((b1 & 0x07) << 5) | ((b2 & 0xe0) >> 3);
      *(trawbuf++) = (b2 & 0x1f) << 3;
    }
    write(STDOUT_FILENO,rawbuf,((bytes/2)*3));
  }
}
