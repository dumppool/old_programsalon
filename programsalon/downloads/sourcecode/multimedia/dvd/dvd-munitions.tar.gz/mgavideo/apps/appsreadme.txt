README for V4L2 Sample Programs

16-March-1999

--
X Window Programs

xcaptest

This program tests most of the capture capabilities of a device driver.
It captures images in the format of the X Windows frame buffer and
displays them in a window. Edit the file and select the capture size
and other settings by editing the #defines at the beginning.

This program optionally takes the name of the device on the command 
line. The default device is determined by the value of MY_DEVICE.
If you are using a 32-bit-per-pixel X Windows screen use -b on the
command line.

When xcaptest is running you can use vidpanel to select the video 
input and adjust brightness, etc.

If xcaptest halts with an XPutImage error, then it did not correctly
detect your X Windows screen depth, or your screen depth is not a 
supported one. xcaptest does not work on 256 color displays. On 32-bpp
you need to uncomment the line #define X_DEPTH 32. On other screen 
depths it should work with the #define X_DEPTH line commented out.


vidpanel

This is another X Window program. It tests the video tone controls of 
the device, and also lets you select the video input. This program
demonstrates multiple opens on a device, and how to use the non-
capturing open feature of V4L2. It takes the name of the device on
the command line.


--
Command Line Programs

vctrl

vctrl is a command line command to set the width, height, and depth
settings of the capture device. The command line parameters are the
device name, and the width-height-depth settings. If the device name
is not given the default is /dev/video. If width-height-depth settings
are not given, the program will print out the current settings. The
width-height-depth settings can be given with separate switches or
with an argument like 320x240x24. vctrl is useful when you are using
vcat to capture frames from the command line or a shell script.
vctrl now can now also set the video input with the -i switch.

vctrl [-w <width>] [-h <height>] [-b <depth>] [-i <input>] [<device>]
or
vctrl [<width>x<height>x<depth>] [-i <input>] [<device>]

Possible depth values are:
	 15   =   RGB 5-5-5
	 16   =   RGB 5-6-5
	 24   =   B-G-R
	 32   =   B-G-R-x
It is not yet possible to select R-G-B byte order capturing, but vcat
can switch the byte order with the -rgb switch.


vcat

vcat is a command line program for capturing frames from a V4L2 capture
device. The command line arguments are the device name and optionally a
byte-order switch.

vcat [-rgb] [-bgr] [<device>]

If the device is capturing in 24-bit-per-pixel R-G-B mode then -bgr will
swap the bytes to B-G-R order. If the device is capturing in 24-bit-per-
pixel B-G-R mode, then -rgb will swap the bytes to R-G-B order. Otherwise
-bgr and -rgb have no effect.

For example, try
./vcat /dev/video0 | rawtoppm -bgr 704 240 | xv -



freq

Simple utility to use the tv tuner and change the channel.  The simple
syntax is:
    freq [channel]

Do a:
    freq --help

for more info.



preview_off
preview_on

Simple app to control the status of the overlay preview window.  The syntax is:

    preview_on  x  y  width  height  rgb

Where x,y is the upper left corner on your desktop where you want the overlay
window to start, and width and height set the size of the window.  rgb is the
key color for chromakey overlay.  Video will only be overlayed onto the color
you specify here.  For example:

(32-bit desktop)
    xsetroot -solid blue
    preview_on 0 0 1024 768 255

(16-bit desktop)
    xsetroot -solid blue
    preview_on 0 0 1024 768 31

You get the idea...  preview_off turns the overlay window off

Bill. (modified by ryan ;-) )

xbs:
	X Window Backend Scale Tool
