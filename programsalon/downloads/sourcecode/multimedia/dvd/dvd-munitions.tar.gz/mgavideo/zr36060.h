#define	ZR_IDLE_STATE		1
#define ZR_COMPRESS_STATE 	2
#define	ZR_DECOMPRESS_STATE 	3
#define	ZR_WRITE_STATE		4
#define	ZR_LOAD_STATE		5

int	zr36060_interrupt(struct codec *codec);
int	zr36060_compress_image(struct codec *codec);
int	zr36060_attach(struct codec *codec);
int	zr36060_deattach(struct codec *codec);
