/* 
 *  css.h
 *
 *  Released under the version 2 of the GPL.
 *
 *  Copyright 1999 Derek Fawcus / M Roberts
 *
 *  This file contains declarations common to more than one CSS program#
 *	
 */

#ifndef CSS_H
#define CSS_H
typedef unsigned char byte;

/*
	Tables defined in csstable.c
*/
extern byte CSSvarients[32];
extern byte CSSsecret[5];
extern byte CSSmangle0[256], CSSmangle1[256], CSSmangle2[256];

extern byte reverse[256];

/*
	Debug functions defined in cssdebug.c
*/
void print_tab( byte const * b, int len);

#endif
