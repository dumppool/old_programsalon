/*
 * Copyright (C) 1999 
 * Derek Fawcus <derek@spider.com>
 * Mark Roberts <maroberts@dial.pipex.com>
 *
 * This code may be used under the terms of Version 2 of the GPL,
 * read the file COPYING for details.
 *
 */

#include <stdio.h>
#include "css.h"

void print_tab( byte const * b, int len)
{
  for ( ;len > 0; len--) fprintf(stderr, " 0x%02X", *b++);
}



