#ifdef PARSER
#include <stdio.h>
#endif
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include "misc.h"
#include "ifo.h"

void ifo_print_audiosub (u_char *ptr)
{
	ifo_hdr_t *hdr = (ifo_hdr_t *) ptr;
	int i;
	u_int *start_list;

	printf ("\n???\n");
	printf ("---\n");
	printf ("number of units: %d\n", ntohs (hdr->num));
	printf ("length of table: 0x%x\n", ntohl (hdr->len));	

	start_list = (u_int *) calloc (ntohs (hdr->num), sizeof (u_int));

	ptr += IFO_HDR_LEN;

	for (i=0; i<ntohs(hdr->num); i++) {
		start_list[i] = get4bytes (ptr);

		ptr+=4;
	}


	for (i=0; i<ntohs(hdr->num); i++) {
		int s;
		u_int len;
		u_char *start_ptr;

		start_ptr = ptr = (u_char *) hdr + start_list[i];

		len = get4bytes (ptr);
		printf ("length of table: 0x%x\n", len);	
		ptr += 4;

for (s=0; s<32*8+4; s++)
	printf ("%02x ", *ptr++);
	
		ifoPrintAudio (ifoGetAudio (ptr));
		ptr += 4+8*8;

for (s=0; s<12; s++)
	printf ("%02x ", *ptr++);

		ifoPrintSPU (ifoGetSPU (ptr));
		ptr += 4+32*6;

{ int end;

	end =  start_ptr + len - ptr;

	for (s=0; s<end; s++)
		printf ("%02x ", *ptr++);

	printf ("\n");
}
	}
}
