#ifndef __IFO_PGC_H__
#define __IFO_PGC_H__

#include <sys/types.h>

void ifo_print_pgc (u_char *ptr);

#endif
