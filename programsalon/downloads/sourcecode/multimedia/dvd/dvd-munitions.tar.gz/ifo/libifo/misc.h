#ifndef __MISC_H__
#define __MISC_H__

#include <netinet/in.h>
#include <sys/types.h>
#include "ifo.h"

#define __USE_FILE_OFFSET64

#define OFFSET_IFO		0x0000
#define OFFSET_VTS		0x0000
#define OFFSET_LEN		0x00C0
#define IFO_OFFSET_TAT		0x00C0
#define OFFSET_VTSI_MAT		0x0080
#define IFO_OFFSET_VIDEO	0x0100
#define IFO_OFFSET_AUDIO	0x0200
#define IFO_OFFSET_SUBPIC	0x0250

u_int get4bytes (u_char *buf);
u_int get2bytes (u_char *buf);

int ifoReadTBL (ifo_t *ifo, u_int offset, u_int tbl_id);
int ifoReadLB (int fd, __off64_t pos, u_int count, u_char *data);

#endif
