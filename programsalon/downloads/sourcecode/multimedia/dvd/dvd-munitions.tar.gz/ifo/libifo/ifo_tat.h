#ifndef __TBL_PRIV_H__
#define __TBL_PRIV_H__

#include <sys/types.h>

typedef struct {
// start of various tables
	u_int num_menu_vobs;
	u_int num_title_vobs;
	u_int start_ptt;
	u_int start_title_pgci;
	u_int start_menu_pgci;
	u_int start_tmt;
	u_int start_menu_cell_addr;
	u_int start_menu_vobu_addr_map;
	u_int start_title_cell_addr;
	u_int start_title_vobu_addr_map;
} tat_t;

tat_t *ifo_get_tat (u_char *buf);
void ifo_print_tat (tat_t *tat);

#endif
