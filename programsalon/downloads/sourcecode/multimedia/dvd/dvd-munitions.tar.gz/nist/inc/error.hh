/*
   File: error.hh

   Description:

   By: Alex Theo de Jong
   Created: September 1995
*/

#ifndef __error_hh__
#define __error_hh__

#define MAX_LEX_ERR   10

#define msg(s){ printf(s); fflush(stdout); }

#define message(s){ cout << s << "\n"; cout.flush(); }
//  fflush(stdout); }

#define warning(s)  { printf("warning - %s\n", s); }
// fflush(stdout); }

#define error(s) { cerr << s << "\n"; cerr.flush(); }
//  printf("error - %s\n", s); fflush(stdout); }

#endif
