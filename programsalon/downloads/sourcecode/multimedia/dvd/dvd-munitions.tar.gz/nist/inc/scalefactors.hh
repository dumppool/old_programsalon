
#ifndef SCALEFACTORS_H
#define SCALEFACTORS_H

// Scalefactors for layer I and II, Annex 3-B.1 in ISO/IEC DIS 11172:
extern const real scalefactors[63];

#endif
