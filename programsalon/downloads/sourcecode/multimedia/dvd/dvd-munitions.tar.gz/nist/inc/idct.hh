/*
   File: idct.hh

   Description:
   Inverse Discreate Cosine Transformation
*/

class Idct {
 private:
  short iclip[1024]; // clipping table
  short *iclp;
 protected:
  inline void idctrow(short *blk);
  inline void idctcol(short *blk);
 public:
  Idct();
  ~Idct(){ /* delete clipping table */ };
  void conversion(short *block);
};
