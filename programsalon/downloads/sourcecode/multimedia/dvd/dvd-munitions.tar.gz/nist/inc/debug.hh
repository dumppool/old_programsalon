/*
   File: debug.hh

   By: Alex Theo de Jong
   Created: September 1995
*/


#ifdef TRACE
#define TRACER(s)    { cout << s << "\n"; }
#else
#define TRACER(s)    // Nothing
#endif

#ifdef DEBUG
#define DEBUGGER(s)  { cout << s << "\n"; } 
#else
#define DEBUGGER(s)  // Nothing
#endif

#ifdef DEEPDEBUG
#define DDEBUGGER(s) { cout << s << "\n"; } 
#else
#define DDEBUGGER(s) // Nothing
#endif
