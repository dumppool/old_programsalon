/*
  File: main.cc

  Description:
  MPEG 2 Audio Player

*/

#ifdef __GNUG__
#pragma implemetation
#endif

#ifdef IRIX
#include <dmedia/audio.h>
#endif
#ifdef SOLARIS
#include <sys/audioio.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <fstream.h>
#include <sys/errno.h>

#include "athread.hh"

#include "error.hh"
#include "debug.hh"
#include "util.hh"

#include "sync.hh"
#include "mpeg2const.hh"
#include "mpeg2buff.hh"

#include "astream.hh"
#include "crc.hh"
#include "header.hh"
#include "obuffer.hh"
#include "synthesis_filter.hh"
#include "subband.hh"
#include "subband_layer_1.hh"
#include "subband_layer_2.hh"
#include "mpeg2audio.hh"

main(int argc, char** argv){
  Mpeg2Audio mpeg2audio(0, 0, 1, argc, argv);
}
