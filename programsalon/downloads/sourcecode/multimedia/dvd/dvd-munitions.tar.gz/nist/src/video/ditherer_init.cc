#include "ditherer.hh"
#include "ditherer_lk16.hh"
#include "ditherer_lkbw.hh"
#include "ditherer_mmx16.hh"

void Ditherer::loadDefaultModules() {
   addModule(DitherLK16::alloc,"lk16");
   addModule(DitherLK16BW::alloc,"lk16bw");
#ifdef HAVE_MMX
   addModule(Dither_MMX16::alloc,"mmx16");
   addModule(Dither_MMX16B::alloc,"mmx16b");
#endif
}
