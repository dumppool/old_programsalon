#ifndef _dither_LKBW_hh_
#define _dither_LKBW_hh_

#include "ditherer.hh"

class DitherLK16BW : public Ditherer {
public:
   DitherLK16BW();
   virtual ~DitherLK16BW();
   
   virtual void dither(unsigned char * tY,
                       unsigned char * tCr,
                       unsigned char * tCb,
                       unsigned char * dithered_img,
                       int imgWidth,
                       int imgHeight,
                       int viewWidth,
                       int viewHeight,
                       int screenWidth);
   static Ditherer * alloc() {return new DitherLK16BW();}
private:
   static unsigned short * lookUpTable;
};

#endif
