#ifndef _dither_LK16_hh_
#define _dither_LK16_hh_

#include "ditherer.hh"

class DitherLK16 : public Ditherer {
public:
   DitherLK16();
   virtual ~DitherLK16();
   virtual void setBpp(int bpp);
   virtual void dither(unsigned char * tY,
                       unsigned char * tCr,
                       unsigned char * tCb,
                       unsigned char * dithered_img,
                       int imgWidth,
                       int imgHeight,
                       int viewWidth,
                       int viewHeight,
                       int screenWidth);
   static Ditherer * alloc() {return new DitherLK16();}
private:
   unsigned short * lookUpTable;
   static unsigned short * lookUpTable16;
   static unsigned short * lookUpTable15;
};

#endif


