/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Name of package */
#define PACKAGE "ac3dec"

/* Version number of package */
#define VERSION "0.5.3"

