/*
   File: main.cc

   Description:
   Little test to see if function mpeg2video works.
*/

#include "athread.hh"

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <fstream.h>
#include <String.h>
#ifdef USE_OPENPTC
#include <ptc/ptc.h>
#endif
#include "error.hh"
#include "debug.hh"
#include "util.hh"

#include "sync.hh"
#include "mpeg2const.hh"
#include "mpeg2buff.hh"

#include "display.hh"
#include "idct.hh"
#include "vstream.hh"
#include "layerdata.hh"

#include "mpeg2video.hh"

int main(int argc, char* argv[]){
  // create player
  Mpeg2Video* mpeg2video=new Mpeg2Video(0, 0, argc, argv);   
  // delete player which will wait for player to finish
  delete mpeg2video;
  exit(0);
}

void printbits(int, int, int){ return; }






