


void fdct_enc(short *block);
void init_fdct_enc();
void idct_enc(short *block);
void init_idct_enc();


void fdct_mm32(short *blk);
void Fast_IDCT(short int *x);
