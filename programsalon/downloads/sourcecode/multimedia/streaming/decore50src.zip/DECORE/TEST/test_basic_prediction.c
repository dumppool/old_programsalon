/*

 test_basic_prediction.c

 Test program for basic_prediction.  Tests for accuracy and can also be used for
 testing the speed of this module.

 Version 0.1

 John Funnell, 18 March 2001

 (C) 2001 Project Mayo

 */


#include <stdio.h>
#include <stdlib.h>

#include "basic_prediction.h"

/*
 comment out the next line if you know your functions produce the correct 
 results and you are only interested in speed.
 */
#define CHECK_RESULTS

#define WIDTH             640
#define HEIGHT            480

#define ITERATIONS        100




#define INTERPOLATE2(A, B, R) (((int)(A) + (int)(B) + 1 - (R)) >> 1)
#define INTERPOLATE4(A, B, C, D, R) (((int)(A) + (int)(B) + (int)(C) + (int)(D) + 2 - (R)) >> 2)




int main(int argc, char **argv) {
	unsigned char *source, *dest, *Src, *Dst, pel;
	int x, y, i, sx, sy, dx, dy, blocksize, mode, rounding_control;

	/* allocate memory */
	source = malloc(WIDTH * HEIGHT);
	dest   = malloc(WIDTH * HEIGHT);
	if (!source || !dest) return -1;

	/* create random images */
	for(y=0; y<HEIGHT; y++) {
		for(x=0; x<WIDTH; x++) {
			source[WIDTH*y + x] = rand();
			dest  [WIDTH*y + x] = rand();
		}
	}

	printf("testing basic_prediction functions.....\n");
#ifdef CHECK_RESULTS
	printf("[not checking b-frame functions]\n");
#endif

	/* run the test */
	for (i=0; i<ITERATIONS; i++) {

		blocksize = i%2 ? 8 : 16; /* alternate block/macroblock with every frame */
		
		for(y=0; y<HEIGHT; y+=blocksize) {
			for(x=0; x<WIDTH; x+=blocksize) {
				sx = x + (rand() & 0x3f) - 0x20;
				sy = y + (rand() & 0x3f) - 0x20; 
				sx = sx < 0 ? 0 : sx;
				sy = sy < 0 ? 0 : sy;
				sx = sx+blocksize+1 > WIDTH  ? WIDTH- blocksize-1 : sx;
				sy = sy+blocksize+1 > HEIGHT ? HEIGHT-blocksize-1 : sy;
				Src = &(source[WIDTH*sy+sx]);
				Dst = &(  dest[WIDTH* y+ x]);
				mode = (x/blocksize)%8;
				rounding_control = (y/blocksize)%2;
				if (blocksize == 8) {
					if (rounding_control == 0) {
						/* no rounding versions */
						switch(mode) {
						case 0:
							CopyBlock(Src, Dst, WIDTH);
							break;
						case 1:
							CopyBlockHor(Src, Dst, WIDTH);
							break;
						case 2:
							CopyBlockVer(Src, Dst, WIDTH);
							break;
						case 3:
							CopyBlockHorVer(Src, Dst, WIDTH);
							break;
						case 4:
							BCopyBlock(Src, Dst, WIDTH);
							break;
						case 5:
							BCopyBlockHor(Src, Dst, WIDTH);
							break;
						case 6:
							BCopyBlockVer(Src, Dst, WIDTH);
							break;
						case 7:
							BCopyBlockHorVer(Src, Dst, WIDTH);
							break;
						}
					} else {
						/* rounding versions */
						switch(mode) {
						case 0:
							CopyBlock(Src, Dst, WIDTH);
							break;
						case 1:
							CopyBlockHorRound(Src, Dst, WIDTH);
							break;
						case 2:
							CopyBlockVerRound(Src, Dst, WIDTH);
							break;
						case 3:
							CopyBlockHorVerRound(Src, Dst, WIDTH);
							break;
						case 4:
							BCopyBlock(Src, Dst, WIDTH);
							break;
						case 5:
							BCopyBlockHor(Src, Dst, WIDTH);
							break;
						case 6:
							BCopyBlockVer(Src, Dst, WIDTH);
							break;
						case 7:
							BCopyBlockHorVer(Src, Dst, WIDTH);
							break;
						}
					}
				} else { /* blocksize == 16 */
					if (rounding_control == 0) {
						/* no rounding versions */
						switch(mode) {
						case 0:
							CopyMBlock(Src, Dst, WIDTH);
							break;
						case 1:
							CopyMBlockHor(Src, Dst, WIDTH);
							break;
						case 2:
							CopyMBlockVer(Src, Dst, WIDTH);
							break;
						case 3:
							CopyMBlockHorVer(Src, Dst, WIDTH);
							break;
						case 4:
							BCopyMBlock(Src, Dst, WIDTH);
							break;
						case 5:
							BCopyMBlockHor(Src, Dst, WIDTH);
							break;
						case 6:
							BCopyMBlockVer(Src, Dst, WIDTH);
							break;
						case 7:
							BCopyMBlockHorVer(Src, Dst, WIDTH);
							break;
						}
					} else {
						/* rounding versions */
						switch(mode) {
						case 0:
							CopyMBlock(Src, Dst, WIDTH);
							break;
						case 1:
							CopyMBlockHorRound(Src, Dst, WIDTH);
							break;
						case 2:
							CopyMBlockVerRound(Src, Dst, WIDTH);
							break;
						case 3:
							CopyMBlockHorVerRound(Src, Dst, WIDTH);
							break;
						case 4:
							BCopyMBlock(Src, Dst, WIDTH);
							break;
						case 5:
							BCopyMBlockHor(Src, Dst, WIDTH);
							break;
						case 6:
							BCopyMBlockVer(Src, Dst, WIDTH);
							break;
						case 7:
							BCopyMBlockHorVer(Src, Dst, WIDTH);
							break;
						}
					}
				}
			
#ifdef CHECK_RESULTS
				/* check results */
				for(dy=0; dy<blocksize; dy++) {
					for(dx=0; dx<blocksize; dx++) {
						switch (mode) {
						case 0:
							pel = Src[WIDTH*dy+dx];
							break;
						case 1:
							pel = INTERPOLATE2(Src[WIDTH*dy+dx], Src[WIDTH*dy+dx+1], rounding_control);
							break;
						case 2:
							pel = INTERPOLATE2(Src[WIDTH*dy+dx], Src[WIDTH*(dy+1)+dx], rounding_control);
							break;
						case 3:
							pel = INTERPOLATE4(Src[WIDTH*dy+dx], Src[WIDTH*dy+dx+1], Src[WIDTH*(dy+1)+dx], Src[WIDTH*(dy+1)+dx+1], rounding_control);
							break;
						default:
							pel =  Dst[WIDTH*dy+dx];
							/* too fiddly to check the results for B frames */
						}
						if (pel != Dst[WIDTH*dy+dx]) {
							printf("failure: blocksize=%d mode=%d rounding_control=%d\n", blocksize, mode, rounding_control);
							goto getoutofhere;
						}
					}
				}
#endif
			}
		}
	}
	printf("completed sucessfully\n");

getoutofhere:

	fgetc(stdin);
	return 0;
}


