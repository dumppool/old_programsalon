// gen_usetime.h //

#ifndef _GEN_USETIME_H_
#define _GEN_USETIME_H_

#endif // _GEN_USETIME_H_

/*** *** ***/

extern void startTimer();
extern void stopTimer();
extern void displayTimer(int picnum);

