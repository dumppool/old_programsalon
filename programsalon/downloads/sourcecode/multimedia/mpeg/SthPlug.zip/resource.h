//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by STHPLUS.rc
//
#define IDR_MENU                        101
#define IDB_FACEBMP                     102
#define IDB_CLOSE                       106
#define IDB_T0                          107
#define IDB_T9                          108
#define IDB_T10                         109
#define IDB_T2                          110
#define IDB_T3                          111
#define IDB_T4                          112
#define IDB_T5                          113
#define IDB_T6                          114
#define IDB_T7                          115
#define IDB_T8                          116
#define IDB_T1                          117
#define IDC_HAND1                       118
#define IDC_HAND2                       119
#define ID_PLAYVCD                      40001
#define ID_PLAYVCD11                    40002
#define ID_PLAYFILE                     40003
#define ID_PLAY                         40004
#define ID_STOP                         40005
#define ID_FORWARD                      40006
#define ID_BACKWARD                     40007
#define ID_CLOSE                        40008
#define ID_EXIT                         40009
#define ID_SEARCH                       40010
#define ID_STEP                         40011
#define ID_ADVANCE                      40012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        120
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
