#ifndef	__WINDOWS_H
#include <windows.h>
#endif

//Get the Plus DLL Support VIDEO,AUDIO or CD window
INT	APIENTRY	QueryPlusCaps(void);
//Retrun FLAGS
#define	CAPSPLUS_VIDEO	1
#define	CAPSPLUS_AUDIO	2
#define	CAPSPLUS_CD	4
//Create the Plus Window
HWND	APIENTRY	CreatePlusWindow(HANDLE hMainInstance,HWND hwnd,int Flags,FARPROC GetStatusCallBack);
//Return the Plus Window's hwnd or null
typedef	DWORD  (APIENTRY *GETSTHVCDSTATUSPROC)(int Cmd,DWORD wParam,DWORD lParam);
//Get SthVCD Playing status See Cmd defined

//Release the DLL Window
void	APIENTRY	ReleasePlusWindow(void);

//Follow is the Command ID for DLL,WM_COMMAND's wParam=Follow lParam=0
#define STHVCD_OPEN                         40001
#define STHVCD_EXIT                         40002
#define STHVCD_PLAY                         40003
#define STHVCD_STOP                         40004
#define STHVCD_FORWARD                      40005
#define STHVCD_BACKWARD                     40006
#define STHVCD_NOUSE1                       40007
#define STHVCD_NOUSE2                       40008
#define STHVCD_ABOUT                        40009
#define STHVCD_NOUSE3                       40010
#define STHVCD_CLOSE                        40011
#define STHVCD_NOUSE4                       40012
#define STHVCD_MUTE                         40013
#define STHVCD_INCVOLUME                    40014
#define STHVCD_DECVOLUME                    40015
#define STHVCD_SINGLECOLOR                  40016
#define STHVCD_INCU                         40017
#define STHVCD_INCV                         40019
#define STHVCD_NOUSE5                       40020
#define STHVCD_NOUSE6                       40021
#define STHVCD_DECQUALITY                   40022
#define STHVCD_INCQUALITY                   40023
#define STHVCD_44100HZ                      40025
#define STHVCD_22050HZ                      40026
#define STHVCD_NOUSE7                       40027
#define STHVCD_STEREO                       40028
#define STHVCD_LEFTMONO                     40029
#define STHVCD_RIGHTMONO                    40030
#define STHVCD_MIXEDMONO                    40031
#define STHVCD_STEP                         40032
#define STHVCD_LOOP                         40033
#define STHVCD_HELPER                       40037
#define STHVCD_PLAYVCD                      40038
#define STHVCD_DECU                         40039
#define STHVCD_DECV                         40040
#define STHVCD_MODUFYUV                     40041
#define STHVCD_HEAD                         40046
#define STHVCD_END                          40047
#define STHVCD_SEARCH                       40048
#define STHVCD_MODIFYQUALITY                40068
#define STHVCD_ORGSIZE                      40071
#define STHVCD_FULLSCREEN                   40072
#define STHVCD_RESTOREVIDEO                 40073
#define STHVCD_SELECTSTART                  40074
#define STHVCD_SELECTEND                    40075
#define STHVCD_PLAYHIDENVCD                 40094
#define STHVCD_NICETY44100HZ                40096
#define STHVCD_SAVEPIC                      40097
#define STHVCD_INFO                         40098
#define STHVCD_TIP                          40099
#define STHVCD_CONFIG                       40100
#define STHVCD_NEXT                         40101
#define STHVCD_PREV                         40102
#define STHVCD_RETURN                       40103
#define STHVCD_0                            40104
#define STHVCD_1                            40105
#define STHVCD_2                            40106
#define STHVCD_3                            40107
#define STHVCD_4                            40108
#define STHVCD_5                            40109
#define STHVCD_6                            40110
#define STHVCD_7                            40111
#define STHVCD_8                            40112
#define STHVCD_9                            40113
#define STHVCD_00                           40114
#define STHVCD_10                           40115
#define STHVCD_20                           40116
#define STHVCD_30                           40117
#define STHVCD_40                           40118
#define STHVCD_50                           40119
#define STHVCD_60                           40120
#define STHVCD_70                           40121
#define STHVCD_80                           40122
#define STHVCD_90                           40123
#define STHVCD_PLAYMULTIFILES               40124
#define STHVCD_SAVEMPA                      40125
#define STHVCD_PLAYSAVE                     40126
#define STHVCD_SAVESEQUENCE                 40127
#define STHVCD_SHOWTIME                     40128
#define STHVCD_KARAOKE                      40129
#define STHVCD_EJECT                        40130
#define STHVCD_INSERTCD                     40131
#define STHVCD_KARAOKELEFT                  40132
#define STHVCD_TESTSPEED                    40133
#define STHVCD_DISPLAYSETTING               40134
#define STHVCD_WINDOWSETTING                40135
#define STHVCD_PLAYMP3                      40136
#define STHVCD_YUVORDER                     40137
#define STHVCD_BUFFERFRAMES                 40138
#define STHVCD_INCY                         40139
#define STHVCD_DECY                         40140
#define STHVCD_MP3SEARCH                    40141
#define STHVCD_SAVEMPV                      40142
#define STHVCD_MICROPHONE                   40143
#define STHVCD_PLAYNEXTDISC                 40144
#define STHVCD_PLAYVCD11                    40145
#define STHVCD_NOUSE8                       40146
#define STHVCD_INCECHO                      40147
#define STHVCD_DECECHO                      40148
#define STHVCD_PLAYDVB                      40149
#define STHVCD_AUDIOSTRM0                   40150
#define STHVCD_AUDIOSTRM1                   40151
#define STHVCD_D1SIZE                       40152
#define STHVCD_PLAYTRACK                    40153
#define STHVCD_SETEQUALIZE                  40154
#define STHVCD_RANDOM                       40155
#define STHVCD_SELECTFACEBMP                40156
#define STHVCD_CREATEDLL                    40157
#define STHVCD_RELEASEDLL                   40158

//SthVCD Cmd defined
#define MAXCMD			32
#define STATUS_GETSUPPORT				0
#define STATUS_GETVERSION				1
#define STATUS_GETOPENSTATUS			2
#define STATUS_GETFULLSCREEN			3
#define STATUS_GETAUDIOMUTE				4
#define STATUS_GETFILELENGTH			5
#define STATUS_GETBYTERATE				6
#define STATUS_GETTIMELENGTH			7
#define STATUS_GETCURRENTTIME			8
#define STATUS_GETCURRENTFILEPOS		9
#define STATUS_SETCURRENTFILEPOS		10	//wParam=FILE_BEGIN/CURRENT/END lParam=Pos
#define STATUS_SETCURRENTTIMEPOS		11	//wParam=TIME in Second
#define STATUS_GETAUDIOVOLUME			12	//wParam=*lpLeftVolume lParam=*lpRightVolume
#define STATUS_SETAUDIOVOLUME			13	//wParam=LeftVolume lParam=RightVolume
#define STATUS_GETLUMANCEY				14
#define STATUS_SETLUMANCEY				15	//wParam=Y
#define STATUS_GETUV					16	//wParam=*lpUColor lParam=*lpVColor
#define STATUS_SETUV					17	//wParam=UColor lParam=VColor
#define STATUS_GETECHO					18	
#define STATUS_SETECHO					19	//wParam=Echo
#define STATUS_GETSINGLECOLOR			20
#define STATUS_SWITCHSINGLECOLOR		21
#define STATUS_SWITCHFULLSCREEN			22
#define STATUS_SWITCHAUDIOMUTE			23
#define STATUS_SETLEFTMONO				24
#define STATUS_SETRIGHTMONO				25
#define STATUS_SETSTEREO				26
#define STATUS_SETMIXEDMONO				27
#define STATUS_GETLOOPSTATUS			28
#define STATUS_SWITCHLOOP				29
#define STATUS_SETSELECTSTART			30
#define STATUS_SETSELECTEND				31
#define STATUS_SWITCHSHOWTIME			32
#define STATUS_GETPLAYING				33
#define STATUS_GETMICINIT				34
#define STATUS_GETMICMUTE				35
#define STATUS_SETMICMUTE				36
#define STATUS_GETMICVOLUME				37	//wParam=*lpLeftVolume lParam=*lpRightVolume
#define STATUS_SETMICVOLUME				38	//wParam=LeftVolume lParam=RightVolume (0 .. 65535)
//--------------------------------------------------------------------------------------------
#define MAX_BUTTON_COUNT 1  //now, there is only 1 button
#define maxX 628
#define maxY 169

HRGN	hRgns[MAX_BUTTON_COUNT+1]={0,0};  //Rgn handle of every button, hRgns[0] is reserved
HDC		memdc; //Virtual window dc
HDC		hdc;   //PlusWindow dc
HDC		mdc;   //mem temp dc
HBITMAP	hBit;
RECT	winRect;
int		Button = 0;

int		OnButton(LPARAM lParam);
void	SethRgns(void);
void	DelhRgns(void);
void	ShowTime(int hour, int minute, int second, int X, int Y);
void	DrawTime(int number, int x, int y);
void	CALLBACK HandleTimer( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime );
