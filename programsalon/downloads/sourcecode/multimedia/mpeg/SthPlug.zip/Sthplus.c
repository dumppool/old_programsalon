/***************************************************************************\
|				  STHVCD plugins SDK	99.7.22								|
|		All rights reserved					HEROSOFT Co.,Ltd				|
\***************************************************************************/
#include <windows.h>
#include "STHPLUS.H"
#include "resource.h"

HANDLE		hDLLInstance=NULL;
BOOL	APIENTRY	DllMain(HANDLE hInst, DWORD fdwReason, LPVOID lpReserved)
{
	static	int	cProcessesAttached;
	if(fdwReason==DLL_PROCESS_ATTACH)
		{
		if(cProcessesAttached)
			{
			cProcessesAttached++;
			return(TRUE);// Not the first initialization.
			}
		cProcessesAttached++;
		hDLLInstance=hInst;
		}
	if(fdwReason==DLL_PROCESS_DETACH)
		{
		cProcessesAttached--;
		if(cProcessesAttached)
			return	TRUE;
		}
	return	TRUE;
}
/////////////////////// SthVCD Face Plus //////////////////
HWND			hDLLWnd		=NULL;
HWND			hMainWnd	=NULL;
HANDLE			hMainInstance	=NULL;
HMENU			hPopMenu	=NULL;
GETSTHVCDSTATUSPROC	GetSthVCDStatus	=NULL;
char 			szDLLClass[]	="Plus Window";
///////////////////////////////////////////////////////////
INT	Support=CAPSPLUS_VIDEO|CAPSPLUS_AUDIO|CAPSPLUS_CD;
INT	APIENTRY	QueryPlusCaps(void)
{	//This Plus DLL for Video or Audio or CD
	return	Support;
}
long	APIENTRY	WndProc(HWND hwnd,UINT message,UINT wParam,LONG lParam);
HWND	APIENTRY	CreatePlusWindow(HANDLE hMainInstance,HWND hwnd,int Flags,FARPROC GetStatusCallBack)
{	//Success or not
	WNDCLASS 	wndclass;
	HMENU		hMenu;

	if((Flags&Support)==0)	return	0;
	hMainInstance		=hMainInstance;
	hMainWnd		=hwnd;
	(FARPROC)GetSthVCDStatus=GetStatusCallBack;
	hMenu			=LoadMenu(hDLLInstance,MAKEINTRESOURCE(IDR_MENU));
	hPopMenu		=GetSubMenu(hMenu,0);
	//Create Class
	wndclass.style		=CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc	=(WNDPROC)WndProc;
	wndclass.cbClsExtra	=0;
	wndclass.cbWndExtra	=0;
	wndclass.hInstance	=hMainInstance;
	wndclass.hIcon		=NULL;
//	wndclass.hCursor	=LoadCursor(NULL,IDC_ARROW);
	wndclass.hCursor	=LoadCursor(hDLLInstance, MAKEINTRESOURCE(IDC_HAND1));
	wndclass.hbrBackground	=(HBRUSH)COLOR_WINDOW;
	wndclass.lpszMenuName	=NULL;
	wndclass.lpszClassName	=szDLLClass;
	RegisterClass(&wndclass);
	// Create Window
	hDLLWnd=CreateWindow(szDLLClass,"STHVCD Plus",
			WS_POPUP | WS_VISIBLE,
			40,	20,
			352,	240,
			NULL,NULL,hMainInstance,NULL);
	//Hide the Window.
	ShowWindow(hDLLWnd,SW_SHOW);
	UpdateWindow(hDLLWnd);

	return	hDLLWnd;
}
void	APIENTRY	ReleasePlusWindow(void)
{
	if(hDLLWnd==NULL)	return;
	//Destory Window
	DestroyWindow(hDLLWnd);
	//Delete Class
	UnregisterClass(szDLLClass,hMainInstance);
	//Clear
	hDLLWnd=0;
}
void	HandleCommand(UINT wParam,LONG lParam)
{
	switch(wParam)
		{
		case ID_PLAYVCD:
			SendMessage(hMainWnd,WM_COMMAND,STHVCD_PLAYVCD,lParam);
			break;
		case ID_PLAYVCD11:
			SendMessage(hMainWnd,WM_COMMAND,STHVCD_PLAYVCD11,lParam);
			break;
		case ID_PLAYFILE:
			SendMessage(hMainWnd,WM_COMMAND,STHVCD_PLAYMULTIFILES,lParam);
			break;

		case ID_PLAY:
			SendMessage(hMainWnd,WM_COMMAND,STHVCD_PLAY,lParam);
			break;
		case ID_STOP:
			SendMessage(hMainWnd,WM_COMMAND,STHVCD_STOP,lParam);
			break;
		case ID_FORWARD:
			SendMessage(hMainWnd,WM_COMMAND,STHVCD_FORWARD,lParam);
			break;
		case ID_BACKWARD:
			SendMessage(hMainWnd,WM_COMMAND,STHVCD_BACKWARD,lParam);
			break;
		case ID_SEARCH:
			SendMessage(hMainWnd,WM_COMMAND,STHVCD_SEARCH,lParam);
			break;
		case ID_STEP:
			SendMessage(hMainWnd,WM_COMMAND,STHVCD_STEP,lParam);
			break;

		case ID_CLOSE:
			SendMessage(hMainWnd,WM_COMMAND,STHVCD_CLOSE,lParam);
			break;

		case ID_ADVANCE:
			PostMessage(hMainWnd,WM_COMMAND,STHVCD_RELEASEDLL,lParam);
			break;
		case ID_EXIT:
			PostMessage(hMainWnd,WM_CLOSE,wParam,lParam);
			break;
		}
}
#define	POINTNUM	28
static	POINT	Points[POINTNUM]=
{
	{0,22},{0,140},{39,140},{51,150},{63,156},{73,159},{87,162},
	{321,162},{327,160},{329,157},{329,146},{326,143},{321,140},
	{321,23},{323,23},{323,19},{317,15},{308,11},{298,7},{286,4},
	{270,2},{239,0},{166,0},{162,2},{159,7},{159,15},{160,18},{162,22},
};
///////////////////////////////////////////////////////////
BOOL	DrawBitmap( HDC hdc, HBITMAP hbm, int x, int y, int cx, int cy) ;
long	APIENTRY	WndProc(HWND hwnd,UINT message,UINT wParam,LONG lParam)
{
	PAINTSTRUCT 	ps;
	static HBITMAP hbm ;
	static int cx, cy ;

	switch(message)
		{
		case WM_CREATE:
			{
			HRGN	hrgn;
 			BITMAP	bmp ;
			hdc = GetDC(hwnd);
			// loading the bitmap from the resource file
//			hbm = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_FACEBMP)) ;
			hBit = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_FACEBMP)) ;
			// get the object size
			GetObject( hBit, sizeof( bmp), &bmp) ;
			cx=bmp.bmWidth;
			cy=bmp.bmHeight;
			// reduce it to a fourth
			hrgn = CreatePolygonRgn(Points,POINTNUM,ALTERNATE);
			// impose the circular window size
			SetWindowRgn( hwnd, hrgn, TRUE) ;
			// show the window
			SetWindowPos( hwnd, HWND_TOP, 0, 0, cx, cy, SWP_NOMOVE);

			// create a virtual window
			memdc = CreateCompatibleDC(hdc);
			SelectObject(memdc, hBit);
			//release resource
			DeleteObject(hBit);
			ReleaseDC(hwnd, hdc);

			SethRgns();

			//set a timer
			SetTimer(hwnd, 1, 1000, HandleTimer);
			
			}
			break ;
		case WM_PAINT:
			hdc=BeginPaint(hwnd,&ps);
			BitBlt(hdc, 0, 0, maxX, maxY, memdc, 0, 0, SRCCOPY);
			EndPaint(hwnd,&ps);
			return 0;
		case WM_LBUTTONDOWN:
			Button = OnButton(lParam);
			if(Button)
			{
				SetCapture(hwnd);
				SetClassLong(hwnd, GCL_HCURSOR, (long)LoadCursor(hDLLInstance, MAKEINTRESOURCE(IDC_HAND2)));
				SetCursor(LoadCursor(hDLLInstance, MAKEINTRESOURCE(IDC_HAND2)));
				mdc = CreateCompatibleDC(hdc);
				switch (Button)
				{
				case 1: //Close
					hBit = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_CLOSE));
					SelectObject(mdc, hBit);
					BitBlt(hdc, 301, 117, 15, 12, mdc, 0, 0, SRCCOPY);
					DeleteObject(hBit);
					break;
				}
				DeleteDC(mdc);
			}
			break;
		case WM_LBUTTONUP:
			ReleaseCapture();
			SetClassLong(hwnd, GCL_HCURSOR, (long)LoadCursor(hDLLInstance, MAKEINTRESOURCE(IDC_HAND1)));
			SetCursor(LoadCursor(hDLLInstance, MAKEINTRESOURCE(IDC_HAND1)));
			hdc = GetDC(hwnd);
			InvalidateRect(hwnd, NULL, FALSE);
			switch(OnButton(lParam))
			{
			case 1: //Close
				PostMessage(hMainWnd,WM_COMMAND,STHVCD_EXIT,lParam);
				break;
			}
			break;
		case WM_CONTEXTMENU:
			//Create Popup menu
			TrackPopupMenu(	hPopMenu,
					TPM_TOPALIGN,
					LOWORD( lParam),
					HIWORD( lParam),
					0,
					hwnd,
					NULL) ;
			break;
		case WM_NCHITTEST:
			GetWindowRect(hwnd, &winRect);
			lParam-=winRect.left;
			lParam-=(winRect.top<<16);
			if(OnButton(lParam))
				return HTCLIENT;
			else 
				return HTCAPTION;
		case WM_COMMAND:
			HandleCommand(wParam,lParam);
			break;
		case WM_SYSCOMMAND:
			if(wParam==SC_SCREENSAVE)
				return	1;//Off ScreenSave
			if(wParam==SC_MONITORPOWER)
				return	1;//Off Screen Power
			break;
		case WM_CLOSE:
			PostMessage(hMainWnd,WM_CLOSE,wParam,lParam);
			break;
		case WM_DESTROY:
			KillTimer(hwnd, 1);
			DelhRgns();
			break;
		}

	return DefWindowProc(hwnd,message,wParam,lParam);
}
BOOL	DrawBitmap(HDC hdc,HBITMAP hbm,int x,int y,int cx,int cy)
{
	HBITMAP hbmpOld ;
	BITMAP bm ;
	HDC hdcMem ;

	// compatibile dc 
	hdcMem = CreateCompatibleDC( hdc) ;
	GetObject( hbm, sizeof( BITMAP), (LPSTR)&bm) ;

	hbmpOld = SelectObject( hdcMem, hbm) ;

	BitBlt( hdc, x, y, cx, cy, hdcMem, 0, 0, SRCCOPY) ;
//	StretchBlt( hdc, 0, 0, cx, cy, hdcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY) ; 
	SelectObject( hdc, hbmpOld) ;
	return DeleteDC( hdcMem) ;
}
int	OnButton(LPARAM lParam)
{
	int i;
	for(i=1; i<=MAX_BUTTON_COUNT; i++)
		if(PtInRegion(hRgns[i], LOWORD(lParam), HIWORD(lParam)))
			return i;  //on button i
	return 0;  //not on any button
}
void	SethRgns()
{
		hRgns[1]=CreateRectRgn(301, 117, 316, 129);  //button close
}
void	DelhRgns()
{
	int i;
	for(i=1; i<=MAX_BUTTON_COUNT; i++)
		if(hRgns[i])
			DeleteObject(hRgns[i]);
}
void	ShowTime(int hour, int minute, int second, int X, int Y)
{
	DrawTime((int)(hour/10), X, Y);
	DrawTime(hour%10, X+6, Y);
	DrawTime(10, X+12, Y); //show ":"
	DrawTime((int)(minute/10), X+18, Y);
	DrawTime(minute%10, X+24, Y);
	DrawTime(10, X+30, Y);
	DrawTime((int)(second/10), X+36, Y);
	DrawTime(second%10, X+42, Y);
	BitBlt(hdc, X, Y, 48, 9, memdc, X, Y, SRCCOPY); //Refresh Timer
}
void	DrawTime(int number, int x, int y)
{
	HBITMAP hBmp;
	switch (number)
	{
	case 0:
		hBmp = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_T0));
		break;
	case 1:
		hBmp = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_T1));
		break;
	case 2:
		hBmp = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_T2));
		break;
	case 3:
		hBmp = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_T3));
		break;
	case 4:
		hBmp = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_T4));
		break;
	case 5:
		hBmp = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_T5));
		break;
	case 6:
		hBmp = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_T6));
		break;
	case 7:
		hBmp = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_T7));
		break;
	case 8:
		hBmp = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_T8));
		break;
	case 9:
		hBmp = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_T9));
		break;
	case 10:
		hBmp = LoadBitmap(hDLLInstance,MAKEINTRESOURCE(IDB_T10));
	}
	mdc = CreateCompatibleDC( hdc) ;
	SelectObject(mdc, hBmp);
	BitBlt(memdc, x, y, 5, 9, mdc, 0, 0, SRCCOPY);
	DeleteDC(mdc);
	DeleteObject(hBmp);
}
void CALLBACK HandleTimer( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime )
{
	SYSTEMTIME Time;
	
	if( (*GetSthVCDStatus)(STATUS_GETPLAYING, 0, 0) )
	{
		GetLocalTime(&Time);
		ShowTime(Time.wHour, Time.wMinute, Time.wSecond, 240, 55);
	}
	
}