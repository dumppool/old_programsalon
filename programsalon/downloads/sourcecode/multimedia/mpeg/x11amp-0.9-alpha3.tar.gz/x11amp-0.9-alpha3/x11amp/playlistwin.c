/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"

GtkWidget *playlistwin,*playlistwin_add_filesel=NULL,*playlistwin_save_filesel=NULL;
GtkWidget *playlistwin_load_filesel=NULL,*playlistwin_url_window=NULL,*playlistwin_dir_browser;
GtkItemFactory *playlistwin_sort_menu;

GdkPixmap *playlistwin_bg;
GdkGC *playlistwin_gc;
gboolean playlistwin_focus=FALSE,playlistwin_resizing=FALSE,playlistwin_moving=FALSE;
gint playlistwin_resize_x,playlistwin_resize_y,playlistwin_move_x,playlistwin_move_y;

PlayList_List	*playlistwin_list=NULL;
PlaylistSlider  *playlistwin_slider=NULL;
PButton		*playlistwin_close;
TextBox		*playlistwin_time_min,*playlistwin_time_sec,*playlistwin_info=NULL;
extern TButton	*mainwin_pl;

LList 		*playlistwin_wlist;

static gint playlistwin_small_button_pressed=-1;

static GtkTargetEntry drop_types [] = {
	{ "text/plain", 0, 1 }
};


enum { ADD_URL,ADD_DIR,ADD_FILE };
enum { SUB_MISC,SUB_ALL,SUB_CROP,SUB_SELECTED };
enum { SEL_INV,SEL_ZERO,SEL_ALL };
enum { MISC_SORT,MISC_FILEINFO,MISC_MISCOPTS };
enum { PLIST_NEW,PLIST_SAVE,PLIST_LOAD };

#define PLAYLISTWIN_SORT_MENU_ENTRIES 6
	
void playlistwin_sort_menu_callback(gpointer cb_data,guint action,GtkWidget *w);
	
enum { PLAYLISTWIN_SORT_BYTITLE,PLAYLISTWIN_SORT_BYFILENAME,PLAYLISTWIN_SORT_BYPATH,
	PLAYLISTWIN_SORT_RANDOMIZE,PLAYLISTWIN_SORT_REVERSE };
	
GtkItemFactoryEntry playlistwin_sort_menu_entries[]=
{
	"/By Title",		NULL,playlistwin_sort_menu_callback,PLAYLISTWIN_SORT_BYTITLE,"<Item>",
	"/By Filename",		NULL,playlistwin_sort_menu_callback,PLAYLISTWIN_SORT_BYFILENAME,"<Item>",
	"/By Path + Filename",	NULL,playlistwin_sort_menu_callback,PLAYLISTWIN_SORT_BYPATH,"<Item>",
	"/-",			NULL,NULL,0,"<Separator>",
	"/Randomize List",	NULL,playlistwin_sort_menu_callback,PLAYLISTWIN_SORT_RANDOMIZE,"<Item>",
	"/Reverse List",	NULL,playlistwin_sort_menu_callback,PLAYLISTWIN_SORT_REVERSE,"<Item>"
};
	
void playlistwin_draw_frame(void);



static void playlistwin_update_info(void)
{
	GList *list;
	PlaylistEntry *entry;
	gchar *text,*sel_text,*tot_text;
	gint selection=0,total=0;
	gboolean selection_more=FALSE,total_more=FALSE;
	list=get_playlist();
	while(list)
	{
		entry=list->data;
		if(entry->length!=-1)
			total+=entry->length;
		else
			total_more=TRUE;
		if(entry->selected)
		{
			if(entry->length!=-1)
				selection+=entry->length;
			else
				selection_more=TRUE;
		}
		list=g_list_next(list);
	}
	selection/=1000;
	
	if(selection>0||(selection==0&&!selection_more))
	{
	       	if(selection>3600)
			sel_text=g_strdup_printf("%d:%-2.2d:%-2.2d%s",selection/3600,(selection/60)%60,selection%60,(selection_more?"+":""));
		else
			sel_text=g_strdup_printf("%d:%-2.2d%s",selection/60,selection%60,(selection_more?"+":""));
	}
	else
		sel_text=g_strdup("?");
	total/=1000;
	if(total>0||(total==0&&!total_more))
	{
	       	if(total>3600)
			tot_text=g_strdup_printf("%d:%-2.2d:%-2.2d%s",total/3600,(total/60)%60,total%60,total_more?"+":"");
		else
			tot_text=g_strdup_printf("%d:%-2.2d%s",total/60,total%60,total_more?"+":"");
	}
	else
		tot_text=g_strdup("?");
	text=g_strconcat(sel_text,"/",tot_text,NULL);
	textbox_set_text(playlistwin_info,text);
	g_free(text);
	g_free(tot_text);
	g_free(sel_text);
}
	
void playlistwin_update_list(void)
{
	if(playlistwin_list) draw_widget(playlistwin_list);
	if(playlistwin_slider) draw_widget(playlistwin_slider);
	if(playlistwin_info) playlistwin_update_info();
}
	

void playlistwin_raise(void)
{
	if(cfg.playlist_visible)
		gdk_window_raise(playlistwin->window);
}

void playlistwin_move(gint x,gint y)
{
	cfg.playlist_x=x;
	cfg.playlist_y=y;
	if(cfg.playlist_visible) gdk_window_move(playlistwin->window,x,y);
}

void playlistwin_release(GtkWidget *widget,GdkEventButton *event,gpointer callback_data)
{
	gdk_pointer_ungrab(GDK_CURRENT_TIME);
	gdk_flush();
	if(playlistwin_resizing)
	{
		playlistwin_resizing=FALSE;
	}
	else if(playlistwin_moving)
	{
		playlistwin_moving=FALSE;
		
	}
	else
	{
		handle_release_cb(playlistwin_wlist,widget,event);
		playlist_popup_destroy();
		draw_playlist_window(FALSE);
	}
	if(playlistwin_small_button_pressed!=-1 &&
	   event->button==1 && 
	   event->x>=cfg.playlist_width-145 &&
	   event->x<cfg.playlist_width-91 && 
	   event->y>=cfg.playlist_height-15 &&
	   event->y<cfg.playlist_height-8)
	{
		if(playlistwin_small_button_pressed==((gint)event->x-(cfg.playlist_width-145))/9)
		{
			switch(playlistwin_small_button_pressed)
			{
				case	0: /* prev */
					playlist_prev();
					break;
				case	1: /* play */
					mainwin_play_pushed();
					break;
				case	2: /* pause */
					input_pause();
					break;
				case	3: /* stop */
					mainwin_stop_pushed();
					break;
				case	4: /* next */
					playlist_next();
					break;
				case	5: /* eject */
					mainwin_eject_pushed();
					break;
			}
		}

	}
	playlistwin_small_button_pressed=-1;
}

void playlistwin_motion(GtkWidget *widget,GdkEventMotion *event,gpointer callback_data)
{
	gint bx,by,w,h,nw,nh;
	XEvent ev;
	GdkPixmap *oldbg;
	gboolean dummy;
	
	if(playlistwin_resizing)
	{
		w=event->x;
		h=event->y;
		bx=(w-275)/25;
		by=(h-58)/29;
		nw=((bx+1)*25)+275;
		nh=((by+1)*29)+58;
		if(nw<275) nw=275;
		if(nh<116) nh=116;
		if(nw!=cfg.playlist_width||nh!=cfg.playlist_height)
		{
			cfg.playlist_width=nw;
			cfg.playlist_height=nh;
			resize_widget(playlistwin_list,cfg.playlist_width-31,cfg.playlist_height-58);
			move_widget(playlistwin_slider,cfg.playlist_width-15,20);
			move_widget(playlistwin_close,cfg.playlist_width-11,3);
			move_widget(playlistwin_time_min,cfg.playlist_width-82,cfg.playlist_height-15);
			move_widget(playlistwin_time_sec,cfg.playlist_width-64,cfg.playlist_height-15);
			move_widget(playlistwin_info,cfg.playlist_width-143,cfg.playlist_height-28);
			resize_widget(playlistwin_slider,8,cfg.playlist_height-58);
			oldbg=playlistwin_bg;
			playlistwin_bg=gdk_pixmap_new(playlistwin->window,cfg.playlist_width,cfg.playlist_height,gdk_visual_get_best_depth());
			
			widget_list_change_pixmap(playlistwin_wlist,playlistwin_bg);
			
			playlistwin_draw_frame();
			draw_widget_list(playlistwin_wlist,&dummy,TRUE);
			clear_widget_list_redraw(playlistwin_wlist);
			gdk_window_set_back_pixmap(playlistwin->window,playlistwin_bg,0);
			gdk_window_set_hints(playlistwin->window,0,0,cfg.playlist_width,cfg.playlist_height,cfg.playlist_width,cfg.playlist_height,GDK_HINT_MIN_SIZE|GDK_HINT_MAX_SIZE);
			gtk_widget_set_usize(playlistwin,cfg.playlist_width,cfg.playlist_height);
			gdk_window_clear(playlistwin->window);
			gdk_pixmap_unref(oldbg);
		}
			
		
	}
	else if(playlistwin_moving)
	{
		gint mx,my,newx,newy;
		gint sw,sh,w,h;
		gint mwx,mwy,mww,mwh;
		GdkModifierType modmask;
		
		gdk_window_get_pointer(NULL, &mx, &my, &modmask);
		newx=mx-playlistwin_move_x;
		newy=my-playlistwin_move_y;
		sw=gdk_screen_width();
		sh=gdk_screen_height();
		w=cfg.playlist_width;
		h=cfg.playlist_height;
		if(newx>-10&&newx<10) newx=0;
		if((newx+w)>sw-10&&(newx+w)<sw+10) newx=sw-w;
		if(newy>-10&&newy<10) newy=0;
		if((newy+h)>sh-10&&(newy+h)<sh+10) newy=sh-h;
		gdk_window_get_size(mainwin->window,&mww,&mwh);
		dock(&newx,&newy,cfg.playlist_width,cfg.playlist_height,cfg.player_x,cfg.player_y,mww,mwh);
		if(cfg.equalizer_visible)
		{
			if(cfg.doublesize)
				dock(&newx,&newy,cfg.playlist_width,cfg.playlist_height,cfg.equalizer_x,cfg.equalizer_y,550,232);
			else
				dock(&newx,&newy,cfg.playlist_width,cfg.playlist_height,cfg.equalizer_x,cfg.equalizer_y,275,116);
		}
		playlistwin_move(newx,newy);
	}
	else
	{
		handle_motion_cb(playlistwin_wlist,widget,event);
		draw_playlist_window(FALSE);
	}
	gdk_flush();
	while(XCheckMaskEvent(GDK_DISPLAY(),ButtonMotionMask,&ev));
}


void playlistwin_url_ok_clicked(GtkWidget *w,GtkWidget *entry)
{
	gchar *text;
	text=gtk_entry_get_text(GTK_ENTRY(entry));
	if(text&&*text)
	{
		playlist_add(text);
		playlist_generate_shuffle_list();
		playlistwin_update_list();
	}
	gtk_widget_destroy(playlistwin_url_window);
}


void playlistwin_show_add_url_window(void)
{
	GtkWidget *vbox,*bbox,*ok,*cancel,*entry;
	if(!playlistwin_url_window)
	{
		playlistwin_url_window=gtk_window_new(GTK_WINDOW_DIALOG);
		gtk_window_set_transient_for(GTK_WINDOW(playlistwin_url_window),GTK_WINDOW(mainwin));
		gtk_window_set_title(GTK_WINDOW(playlistwin_url_window),"Enter URL to add:");
		gtk_window_set_position(GTK_WINDOW(playlistwin_url_window),GTK_WIN_POS_MOUSE);
		gtk_signal_connect(GTK_OBJECT(playlistwin_url_window),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&playlistwin_url_window);
		gtk_container_set_border_width(GTK_CONTAINER(playlistwin_url_window),10);
		
		vbox=gtk_vbox_new(FALSE,10);
		gtk_container_add(GTK_CONTAINER(playlistwin_url_window),vbox);
		
		entry=gtk_entry_new();
		gtk_signal_connect(GTK_OBJECT(entry),"activate",GTK_SIGNAL_FUNC(playlistwin_url_ok_clicked),entry);
		gtk_box_pack_start(GTK_BOX(vbox),entry,FALSE,FALSE,0);
		gtk_widget_show(entry);
		
		bbox=gtk_hbutton_box_new();
		gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
		gtk_button_box_set_spacing(GTK_BUTTON_BOX(bbox),5);
		
		ok=gtk_button_new_with_label("Ok");
		gtk_signal_connect(GTK_OBJECT(ok),"clicked",GTK_SIGNAL_FUNC(playlistwin_url_ok_clicked),entry);
		GTK_WIDGET_SET_FLAGS(ok,GTK_CAN_DEFAULT);
		gtk_window_set_default(GTK_WINDOW(playlistwin_url_window),ok);
		gtk_box_pack_start(GTK_BOX(bbox),ok,FALSE,FALSE,0);
		gtk_widget_show(ok);
		
		cancel=gtk_button_new_with_label("Cancel");
		gtk_signal_connect_object(GTK_OBJECT(cancel),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(playlistwin_url_window));
		GTK_WIDGET_SET_FLAGS(cancel,GTK_CAN_DEFAULT);
		gtk_box_pack_start(GTK_BOX(bbox),cancel,FALSE,FALSE,0);
		gtk_widget_show(cancel);
		
		gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,0);
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_widget_show(playlistwin_url_window);
	}
	if(!GTK_WIDGET_VISIBLE(playlistwin_url_window))
		gtk_widget_show(playlistwin_url_window);
}
		
void playlistwin_add_dir_handler(gchar *dir)
{
	playlist_add_dir(dir);
	gtk_widget_destroy(playlistwin_dir_browser);
	playlistwin_update_list();
}		
		
void playlistwin_add_filesel_ok(GtkWidget *w,GtkWidget *filesel)
{
	GList *node;
	gchar *text,*text2;
	GList *sel_list=NULL;
	
	/*
	 * This is *REAL* ugly and needs to be fixed
	 */
	
	gtk_widget_hide(filesel);
	
	if(cfg.filesel_path)
		g_free(cfg.filesel_path);
	cfg.filesel_path=g_strdup(gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel)));
	text=strrchr(cfg.filesel_path,'/');
	if(text)
		*(text+1)='\0';
	
	node=GTK_CLIST(GTK_FILE_SELECTION(filesel)->file_list)->selection;
	while(node)
	{
		gtk_clist_get_text(GTK_CLIST(GTK_FILE_SELECTION(filesel)->file_list),(gint)node->data,0,&text);
		text2=g_malloc(strlen(text)+1);
		strcpy(text2,text);
		if(!sel_list)
			sel_list=g_list_append(NULL,text2);
		else
			sel_list=g_list_append(sel_list,text2);



		node=node->next;
	}
	node=sel_list;
	if(node)
	{
		while(node)
		{
			text=(gchar *)node->data;
			gtk_file_selection_set_filename(GTK_FILE_SELECTION(filesel),text);
			playlist_add(gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel)));
			g_free(text);
			node=node->next;
		}
		playlist_generate_shuffle_list();
		g_list_free(sel_list);
	}
	else
	{
		text=gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel));
		if(text[strlen(text)-1]!='/')
			playlist_add(gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel)));
		playlist_generate_shuffle_list();
		g_free(text);
	}
	gtk_widget_destroy(GTK_WIDGET(filesel));
	playlistwin_update_list();
	
}


void playlistwin_add_popup_handler(gint item)
{
	switch(item)
	{
		case	ADD_URL:
			playlistwin_show_add_url_window();
			break;
		case	ADD_DIR:
			if(!playlistwin_dir_browser)
			{
				playlistwin_dir_browser=create_dir_browser("Select directory to add:",playlistwin_add_dir_handler);
				gtk_signal_connect(GTK_OBJECT(playlistwin_dir_browser),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&playlistwin_dir_browser);
				gtk_window_set_transient_for(GTK_WINDOW(playlistwin_dir_browser),GTK_WINDOW(playlistwin));
				gtk_window_set_position(GTK_WINDOW(playlistwin_dir_browser),GTK_WIN_POS_MOUSE);
		
			}
			if(!GTK_WIDGET_VISIBLE(playlistwin_dir_browser))
				gtk_widget_show(playlistwin_dir_browser);	
			break;
		case	ADD_FILE:
			if(!playlistwin_add_filesel)
			{
				playlistwin_add_filesel=gtk_file_selection_new("Add file(s) to playlist");
				gtk_clist_set_selection_mode(GTK_CLIST(GTK_FILE_SELECTION(playlistwin_add_filesel)->file_list),GTK_SELECTION_EXTENDED);
				gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(playlistwin_add_filesel)->ok_button),"clicked",GTK_SIGNAL_FUNC(playlistwin_add_filesel_ok),playlistwin_add_filesel);
				gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(playlistwin_add_filesel)->cancel_button),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(playlistwin_add_filesel));
     				gtk_signal_connect(GTK_OBJECT(playlistwin_add_filesel),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&playlistwin_add_filesel);
				if(cfg.filesel_path)
					gtk_file_selection_set_filename(GTK_FILE_SELECTION(playlistwin_add_filesel),cfg.filesel_path);
				gtk_widget_show(playlistwin_add_filesel);
				
			}
			if(!GTK_WIDGET_VISIBLE(playlistwin_add_filesel))
				gtk_widget_show(playlistwin_add_filesel);
			break;
	}
}

void playlistwin_sub_popup_handler(gint item)
{
	switch(item)
	{
		case	SUB_MISC:
			break;
		case	SUB_ALL:
			playlist_clear();
			playlistwin_update_list();
			mainwin_set_song_info(0,0,0);
			mainwin_set_info_text();
			break;
		case	SUB_CROP:
			playlist_delete(TRUE);
			break;
		case	SUB_SELECTED:
			playlist_delete(FALSE);
			break;
	}
}

void playlistwin_sel_popup_handler(gint item)
{
	switch(item)
	{
		case	SEL_INV:
			playlist_inverse_selection();
			break;
		case	SEL_ZERO:
			playlist_select_none();
			break;
		case	SEL_ALL:
			playlist_select_all();
			break;
	}
}

void playlistwin_misc_popup_handler(gint item)
{
	gint x,y;
	
	switch(item)
	{
		case	MISC_SORT:
			gdk_window_get_pointer(NULL,&x,&y,NULL);
			gtk_item_factory_popup(GTK_ITEM_FACTORY(playlistwin_sort_menu),x,y,1,GDK_CURRENT_TIME);
			break;
		case	MISC_FILEINFO:
			break;
		case	MISC_MISCOPTS:
			break;
		
	}
}


void playlistwin_save_filesel_ok(GtkWidget *w,GtkWidget *filesel)
{
	gchar *filename;
	filename=gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel));
	if(filename&&*filename)
		playlist_save(filename);
	gtk_widget_destroy(GTK_WIDGET(filesel));
}

void playlistwin_load_filesel_ok(GtkWidget *w,GtkWidget *filesel)
{
	gchar *filename;
	filename=gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel));
	if(filename&&*filename)
	{
		playlist_clear();
		playlist_load(filename);
	}
	gtk_widget_destroy(GTK_WIDGET(filesel));
}


void playlistwin_plist_popup_handler(gint item)
{
	switch(item)
	{
		case	PLIST_NEW:
			playlist_clear();
			playlistwin_update_list();
			mainwin_set_song_info(0,0,0);
			mainwin_set_info_text();
			break;
		case	PLIST_SAVE:
			if(!playlistwin_save_filesel)
			{
				playlistwin_save_filesel=gtk_file_selection_new("Save playlist");
				gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(playlistwin_save_filesel)->ok_button),"clicked",GTK_SIGNAL_FUNC(playlistwin_save_filesel_ok),playlistwin_save_filesel);
				gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(playlistwin_save_filesel)->cancel_button),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(playlistwin_save_filesel));
     				gtk_signal_connect(GTK_OBJECT(playlistwin_save_filesel),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&playlistwin_save_filesel);
				gtk_widget_show(playlistwin_save_filesel);
			}
			if(!GTK_WIDGET_VISIBLE(playlistwin_save_filesel))
				gtk_widget_show(playlistwin_save_filesel);

			break;
		case	PLIST_LOAD:
			if(!playlistwin_load_filesel)
			{
				playlistwin_load_filesel=gtk_file_selection_new("Load playlist");
				gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(playlistwin_load_filesel)->ok_button),"clicked",GTK_SIGNAL_FUNC(playlistwin_load_filesel_ok),playlistwin_load_filesel);
				gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(playlistwin_load_filesel)->cancel_button),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(playlistwin_load_filesel));
     				gtk_signal_connect(GTK_OBJECT(playlistwin_load_filesel),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&playlistwin_load_filesel);
				gtk_widget_show(playlistwin_load_filesel);
			}
			if(!GTK_WIDGET_VISIBLE(playlistwin_load_filesel))
				gtk_widget_show(playlistwin_load_filesel);

			break;
	}
}
		
		
void playlistwin_press(GtkWidget *widget,GdkEventButton *event,gpointer callback_data)
{
	gint add_nx[]={0,0,0},add_ny[]={111,130,149},add_sx[]={23,23,23},add_sy[]={111,130,149},add_barx=48,add_bary=111;
	gint sub_nx[]={54,54,54,54},sub_ny[]={168,111,130,149},sub_sx[]={77,77,77,77},sub_sy[]={168,111,130,149},sub_barx=100,sub_bary=111;
	gint sel_nx[]={104,104,104},sel_ny[]={111,130,149},sel_sx[]={127,127,127},sel_sy[]={111,130,149},sel_barx=150,sel_bary=111;
	gint misc_nx[]={154,154,154},misc_ny[]={111,130,149},misc_sx[]={177,177,177},misc_sy[]={111,130,149},misc_barx=200,misc_bary=111;
	gint plist_nx[]={204,204,204},plist_ny[]={111,130,149},plist_sx[]={227,227,227},plist_sy[]={111,130,149},plist_barx=250,plist_bary=111;
	
	gboolean grab=TRUE;
	
	
	if(event->button==1&&event->x>cfg.playlist_width-20&&event->y>cfg.playlist_height-20)
	{
		playlistwin_resizing=TRUE;
		playlistwin_resize_x=cfg.playlist_width-event->x;
		playlistwin_resize_y=cfg.playlist_height-event->y;
	}
	else if(event->button==1&&event->x<cfg.playlist_width-20&&event->y<14)
	{
		playlistwin_moving=TRUE;
		playlistwin_move_x=event->x;
		playlistwin_move_y=event->y;		
		gdk_window_raise(playlistwin->window);
	
	}
	else if(event->button==1&&event->x>=12&&event->x<37&&event->y>=cfg.playlist_height-29&&event->y<cfg.playlist_height-11)	
	{
		playlist_popup(cfg.playlist_x+12,cfg.playlist_y+cfg.playlist_height-(3*18)-11,3,add_nx,add_ny,
				add_sx,add_sy,add_barx,add_bary,playlistwin_add_popup_handler);
		grab=FALSE;
	}
	else if(event->button==1&&event->x>=41&&event->x<66&&event->y>=cfg.playlist_height-29&&event->y<cfg.playlist_height-11)	
	{
		playlist_popup(cfg.playlist_x+41,cfg.playlist_y+cfg.playlist_height-(4*18)-11,4,sub_nx,sub_ny,
				sub_sx,sub_sy,sub_barx,sub_bary,playlistwin_sub_popup_handler);
		grab=FALSE;
	}
	else if(event->button==1&&event->x>=70&&event->x<95&&event->y>=cfg.playlist_height-29&&event->y<cfg.playlist_height-11)	
	{
		playlist_popup(cfg.playlist_x+70,cfg.playlist_y+cfg.playlist_height-(3*18)-11,3,sel_nx,sel_ny,
				sel_sx,sel_sy,sel_barx,sel_bary,playlistwin_sel_popup_handler);
		grab=FALSE;
	}
	else if(event->button==1&&event->x>=99&&event->x<124&&event->y>=cfg.playlist_height-29&&event->y<cfg.playlist_height-11)	
	{
		playlist_popup(cfg.playlist_x+99,cfg.playlist_y+cfg.playlist_height-(3*18)-11,3,misc_nx,misc_ny,
				misc_sx,misc_sy,misc_barx,misc_bary,playlistwin_misc_popup_handler);
		grab=FALSE;
	}
	else if(event->button==1&&event->x>=cfg.playlist_width-46&&event->x<cfg.playlist_width-23&&event->y>=cfg.playlist_height-29&&event->y<cfg.playlist_height-11)	
	{
		playlist_popup(cfg.playlist_x+cfg.playlist_width-46,cfg.playlist_y+cfg.playlist_height-(3*18)-11,3,plist_nx,plist_ny,
				plist_sx,plist_sy,plist_barx,plist_bary,playlistwin_plist_popup_handler);
		grab=FALSE;
	}
	else if(event->button==1&&event->x>=cfg.playlist_width-145&&event->x<cfg.playlist_width-91&&event->y>=cfg.playlist_height-15&&event->y<cfg.playlist_height-8)
	{
		playlistwin_small_button_pressed=((gint)event->x-(cfg.playlist_width-145))/9;
	}
	else if(event->button==1&&event->x>=cfg.playlist_width-82&&event->x<cfg.playlist_width-54&&event->y>=cfg.playlist_height-15&&event->y<cfg.playlist_height-9)
	{
		if(cfg.timer_mode==TIMER_ELAPSED)
			cfg.timer_mode=TIMER_REMAINING;
		else
			cfg.timer_mode=TIMER_ELAPSED;
	}
	else
	{
		handle_press_cb(playlistwin_wlist,widget,event);
		draw_playlist_window(FALSE);
	}
	if(grab)
		gdk_pointer_grab(playlistwin->window,FALSE,GDK_BUTTON_MOTION_MASK|GDK_BUTTON_RELEASE_MASK,GDK_NONE,GDK_NONE,GDK_CURRENT_TIME);
	
}

void playlistwin_focus_in(GtkWidget *widget,GdkEvent *event,gpointer callback_data)
{
	show_widget(playlistwin_close);
	playlistwin_focus=TRUE;
	draw_playlist_window(TRUE);
}

void playlistwin_focus_out(GtkWidget *widget,GdkEventButton *event,gpointer callback_data)
{
	hide_widget(playlistwin_close);
	playlistwin_focus=FALSE;
	draw_playlist_window(TRUE);
}

gint playlistwin_configure(GtkWidget *window)
{
	Window dummy;
	if(!playlistwin_moving&&!mainwin_moving)
		XTranslateCoordinates(GDK_DISPLAY(),GDK_WINDOW_XWINDOW(window->window),GDK_ROOT_WINDOW(),0,0,&cfg.playlist_x,&cfg.playlist_y,&dummy);
	return FALSE;
}


void playlistwin_draw_frame(void)
{
	gint w,h,y,i,c;
	GdkPixmap *src;
	
	w=cfg.playlist_width;
	h=cfg.playlist_height;
	src=get_skin_pixmap(SKIN_PLEDIT);
	
	if(playlistwin_focus || !cfg.dim_titlebar)
		y=0;
	else
		y=21;
	gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,0,y,0,0,25,20);
	c=(w-150)/25;
	for(i=0;i<c/2;i++)
	{
		gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,127,y,(i*25)+25,0,25,20);
		gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,127,y,(i*25)+(w/2)+50,0,25,20);
	}
	if(c&1)
	{
		gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,127,y,((c/2)*25)+25,0,12,20);
		gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,127,y,(w/2)+((c/2)*25)+50,0,13,20);
	}
		
	gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,26,y,(w/2)-50,0,100,20);
	gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,153,y,w-25,0,25,20);
	
	for(i=0;i<(h-58)/29;i++)
	{
		gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,0,42,0,(i*29)+20,12,29);
		gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,32,42,w-19,(i*29)+20,19,29);
	}
	gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,0,72,0,h-38,125,38);
	c=(w-275)/25;
	if(c>=3)
	{
		c-=3;
		gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,205,0,w-225,h-38,75,38);
	}
	for(i=0;i<c;i++)
		gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,179,0,(i*25)+125,h-38,25,38);
	gdk_draw_pixmap(playlistwin_bg,playlistwin_gc,src,126,72,w-150,h-38,150,38);
}


void draw_playlist_window(gboolean force)
{
	gboolean redraw;
	if(force)
	{
		playlistwin_draw_frame();
		draw_widget_list(playlistwin_wlist,&redraw,TRUE);
	}
	else
	{
		draw_widget_list(playlistwin_wlist,&redraw,FALSE);
	}
	if(redraw||force)
	{
		clear_widget_list_redraw(playlistwin_wlist);	
		gdk_window_clear(playlistwin->window);
		gdk_flush();
	}
}

void playlistwin_sort_menu_callback(gpointer cb_data,guint action,GtkWidget *w)
{
	switch(action)
	{
		case	PLAYLISTWIN_SORT_BYTITLE:
			playlist_sort_by_title();
			playlistwin_update_list();
			break;
		case	PLAYLISTWIN_SORT_BYFILENAME:
			playlist_sort_by_filename();
			playlistwin_update_list();
			break;
		case	PLAYLISTWIN_SORT_BYPATH:
			playlist_sort_by_path();
			playlistwin_update_list();
			break;
		case	PLAYLISTWIN_SORT_REVERSE:
			playlist_reverse();
			playlistwin_update_list();
			break;
		case	PLAYLISTWIN_SORT_RANDOMIZE:
			playlist_random();
			playlistwin_update_list();
			break;
	}
}

void playlistwin_hide_timer(void)
{
	textbox_set_text(playlistwin_time_min,"   ");
	textbox_set_text(playlistwin_time_sec,"  ");
}

void playlistwin_set_time(gint time,gint length)
{
	gchar *text;
		
	if(cfg.timer_mode==TIMER_REMAINING&&length!=-1)
	{
		time=length-time;
		time/=1000;
		text=g_strdup_printf("-%-2.2d",time/60);
	}
	else
	{
		time/=1000;
		text=g_strdup_printf(" %-2.2d",time/60);
	}
	textbox_set_text(playlistwin_time_min,text);
	g_free(text);
	text=g_strdup_printf("%-2.2d",time%60);
	textbox_set_text(playlistwin_time_sec,text);
	g_free(text);
}

static void playlistwin_drag_data_received(GtkWidget *widget,
					GdkDragContext   *context,
					gint              x,
					gint              y,
					GtkSelectionData *selection_data,
					guint             info,
					guint             time)
{
	if(selection_data->data)
	{
		playlist_add_url_string((gchar *)selection_data->data);
		playlistwin_update_list();
	}
}

void playlistwin_create(void)
{
#if (GTK_MAJOR_VERSION>=1) && (GTK_MINOR_VERSION>=1) && (GTK_MICRO_VERSION>=5) && (GTK_MICRO_VERSION<=7)
	playlistwin=gtk_draw_window_new(GTK_WINDOW_DIALOG);
#else
	playlistwin=gtk_window_new(GTK_WINDOW_DIALOG);
#ifdef GTK_HAVE_FEATURES_1_1_8
	gtk_widget_set_app_paintable(playlistwin,TRUE);
#endif
#endif
	gtk_window_set_policy(GTK_WINDOW(playlistwin),FALSE,FALSE,TRUE);
	gtk_window_set_title(GTK_WINDOW(playlistwin),"X11Amp - Playlist");
	gtk_window_set_wmclass(GTK_WINDOW(playlistwin),"X11Amp_Playlist","x11amp");
	gtk_window_set_transient_for(GTK_WINDOW(playlistwin),GTK_WINDOW(mainwin));
	gtk_widget_set_usize(playlistwin,cfg.playlist_width,cfg.playlist_height);
	gtk_widget_set_events(playlistwin,GDK_FOCUS_CHANGE_MASK|GDK_BUTTON_MOTION_MASK|GDK_BUTTON_PRESS_MASK|GDK_BUTTON_RELEASE_MASK);
	gtk_widget_realize(playlistwin);
	
	playlistwin_sort_menu=gtk_item_factory_new(GTK_TYPE_MENU,"<Main>",NULL);
	gtk_item_factory_create_items(GTK_ITEM_FACTORY(playlistwin_sort_menu),PLAYLISTWIN_SORT_MENU_ENTRIES,playlistwin_sort_menu_entries,NULL);	
	
	gtk_signal_connect(GTK_OBJECT(playlistwin),"button_press_event",GTK_SIGNAL_FUNC(playlistwin_press),NULL);
	gtk_signal_connect(GTK_OBJECT(playlistwin),"button_release_event",GTK_SIGNAL_FUNC(playlistwin_release),NULL);
	gtk_signal_connect(GTK_OBJECT(playlistwin),"motion_notify_event",GTK_SIGNAL_FUNC(playlistwin_motion),NULL);
	gtk_signal_connect(GTK_OBJECT(playlistwin),"focus_in_event",GTK_SIGNAL_FUNC(playlistwin_focus_in),NULL);
	gtk_signal_connect(GTK_OBJECT(playlistwin),"focus_out_event",GTK_SIGNAL_FUNC(playlistwin_focus_out),NULL);
	gtk_signal_connect(GTK_OBJECT(playlistwin),"configure_event",GTK_SIGNAL_FUNC(playlistwin_configure),NULL);
	gtk_drag_dest_set(playlistwin,GTK_DEST_DEFAULT_ALL,drop_types,1,GDK_ACTION_COPY);
	gtk_signal_connect(GTK_OBJECT(playlistwin),"drag_data_received",GTK_SIGNAL_FUNC(playlistwin_drag_data_received),NULL);
	
	gdk_window_set_decorations(playlistwin->window,0);
	
	playlistwin_bg=gdk_pixmap_new(playlistwin->window,cfg.playlist_width,cfg.playlist_height,gdk_visual_get_best_depth());
	gdk_window_set_back_pixmap(playlistwin->window,playlistwin_bg,0);
	playlistwin_gc=gdk_gc_new(playlistwin->window);
	
	playlistwin_wlist=alloc_list();
	playlistwin_close=create_pbutton(playlistwin_wlist,playlistwin_bg,playlistwin_gc,cfg.playlist_width-11,3,9,9,167,3,52,42,playlistwin_hide,SKIN_PLEDIT);
	playlistwin_list=create_playlist_list(playlistwin_wlist,playlistwin_bg,playlistwin_gc,12,20,cfg.playlist_width-31,cfg.playlist_height-58);
	playlistwin_slider=create_playlistslider(playlistwin_wlist,playlistwin_bg,playlistwin_gc,cfg.playlist_width-15,20,cfg.playlist_height-58,playlistwin_list);
	playlistwin_time_min=create_textbox(playlistwin_wlist,playlistwin_bg,playlistwin_gc,cfg.playlist_width-82,cfg.playlist_height-15,15,FALSE,SKIN_TEXT);
	playlistwin_time_sec=create_textbox(playlistwin_wlist,playlistwin_bg,playlistwin_gc,cfg.playlist_width-64,cfg.playlist_height-15,10,FALSE,SKIN_TEXT);
	playlistwin_info=create_textbox(playlistwin_wlist,playlistwin_bg,playlistwin_gc,cfg.playlist_width-143,cfg.playlist_height-28,85,FALSE,SKIN_TEXT);
	playlistwin_update_info();
}

void playlistwin_show(void)
{
	gtk_widget_show(playlistwin);
	if(cfg.playlist_x!=-1&&cfg.save_window_position)
		/*gtk_widget_set_uposition(playlistwin,cfg.playlist_x,cfg.playlist_y);*/
		gdk_window_move(playlistwin->window,cfg.playlist_x,cfg.playlist_y);
	gdk_flush();
	draw_playlist_window(TRUE);
	tbutton_set_toggled(mainwin_pl,TRUE);
	cfg.playlist_visible=TRUE;
}

void playlistwin_hide(void)
{
	gtk_widget_hide(playlistwin);
	cfg.playlist_visible=FALSE;
	tbutton_set_toggled(mainwin_pl,FALSE);
}
