/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#ifndef SKIN_H
#define SKIN_H

typedef enum	{
	SKIN_MAIN,SKIN_CBUTTONS,SKIN_TITLEBAR,SKIN_SHUFREP,SKIN_TEXT,SKIN_VOLUME,
	SKIN_BALANCE,SKIN_MONOSTEREO,SKIN_PLAYPAUSE,SKIN_NUMBERS,SKIN_POSBAR,SKIN_PLEDIT,SKIN_EQMAIN,
	SKIN_PLEDIT_NORMAL,SKIN_PLEDIT_CURRENT,SKIN_PLEDIT_NORMALBG,SKIN_PLEDIT_SELECTEDBG,
} SkinIndex;		
				
typedef struct
{
	gchar		*path;
	GdkPixmap	*main,*def_main;
	GdkPixmap	*cbuttons,*def_cbuttons;
	GdkPixmap	*titlebar,*def_titlebar;
	GdkPixmap	*shufrep,*def_shufrep;
	GdkPixmap	*text,*def_text;
	GdkPixmap	*volume,*def_volume;
	GdkPixmap	*balance,*def_balance;
	GdkPixmap	*monostereo,*def_monostereo;
	GdkPixmap	*playpause,*def_playpause;
	GdkPixmap	*numbers,*def_numbers;
	GdkPixmap	*posbar,*def_posbar;
	GdkPixmap	*pledit,*def_pledit;
	GdkPixmap	*eqmain,*def_eqmain;
	GdkColor	*pledit_normal,def_pledit_normal;
	GdkColor	*pledit_current,def_pledit_current;
	GdkColor	*pledit_normalbg,def_pledit_normalbg;
	GdkColor	*pledit_selectedbg,def_pledit_selectedbg;
	guchar		vis_color[24][3];
} Skin;


extern Skin *skin;

void init_skins(void);
void load_skin(const gchar *path);
void cleanup_skins(void);
GdkPixmap *get_skin_pixmap(SkinIndex si);
GdkColor *get_skin_color(SkinIndex si);
void get_skin_viscolor(guchar vis_color[24][3]);
gboolean is_new_skin(gchar *old_path);

#endif
