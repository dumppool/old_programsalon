/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"

/*
 * This is just a *quick* implementation, it will change in the future to something more
 * sophisticated
 */


static gint ctrl_fd=0;
static gchar *socket_name;

gboolean setup_ctrlsocket(void)
{
	struct sockaddr_un saddr;
	gboolean retval=FALSE;
	gint i,fd;
	gushort dummy;
    
	if((ctrl_fd=socket(AF_UNIX,SOCK_STREAM,0))!=-1)
	{
		for(i=0;;i++)
		{
			saddr.sun_family=AF_UNIX;
			sprintf(saddr.sun_path,"%s/.x11amp/x11amp_ctrl.%d",g_get_home_dir(),i);
			if(!(fd=connect_to_session(i)))
				unlink(saddr.sun_path);
			else
			{
				dummy=0;
				write(fd,&dummy,sizeof(gushort));
				read(fd,&dummy,sizeof(gushort));
				close(fd);
				if(cfg.allow_multiple_instances)
					continue;
			}
			if(bind(ctrl_fd,(struct sockaddr *)&saddr,sizeof(saddr))!=-1)
			{

				listen(ctrl_fd,100);
				socket_name=g_strdup(saddr.sun_path);
				retval=TRUE;
				break;
			}
			else if(!cfg.allow_multiple_instances||errno!=EADDRINUSE)
				break;
		}
				
	}
	if(!retval)
	{
		close(ctrl_fd);
		ctrl_fd=0;
	}
	return retval;
}

void cleanup_ctrlsocket(void)
{
	if(ctrl_fd)
	{
		close(ctrl_fd);
		unlink(socket_name);
		g_free(socket_name);
		ctrl_fd=0;
	}
}

void check_ctrlsocket(void)
{
	fd_set set;
	struct timeval tv;
	struct sockaddr_un saddr;
	struct stat statbuf;
	gint fd,len;
	gushort cmd,num,length,i;
	gchar *filename,*ext;
	
	FD_ZERO(&set);
	FD_SET(ctrl_fd,&set);
	tv.tv_sec=0;
	tv.tv_usec=0;
	if(select(ctrl_fd+1,&set,NULL,NULL,&tv)>0)
	{
		len=sizeof(saddr);
		if((fd=accept(ctrl_fd,&saddr,&len))!=-1)
		{
			read(fd,&cmd,sizeof(gshort));
			switch(cmd)
			{
				case	CMD_PLAYLIST:
					playlist_clear();
				case	CMD_PLAYLIST_ENQUEUE:
					if(read(fd,&num,sizeof(gushort))!=sizeof(gushort))
						break;
					for(i=0;i<num;i++)
					{
						if(read(fd,&length,sizeof(gushort))!=sizeof(gushort))
							break;
						filename=g_malloc0(length+1);
						if((len=read(fd,filename,length))!=length)
						{
							g_free(filename);
							break;
						}
						if(filename[length-1]!='\0')
							filename[length]='\0';
						if(!stat(filename,&statbuf))
						{
							if(S_ISDIR(statbuf.st_mode))
								playlist_add_dir(filename);
							else
								if(ext=strrchr(filename,'.'))
									if(!strcasecmp(ext,".m3u")||!strcasecmp(ext,".pls"))
										playlist_load(filename);
									else
										playlist_add(filename);
								else
									playlist_add(filename);
						}								
						else
							if(ext=strrchr(filename,'.'))
								if(!strcasecmp(ext,".m3u")||!strcasecmp(ext,".pls"))
									playlist_load(filename);
								else
									playlist_add(filename);
							else
								playlist_add(filename);
						g_free(filename);

					}
					playlist_generate_shuffle_list();
					playlistwin_update_list(); 
					if(cmd==CMD_PLAYLIST)
						mainwin_play_pushed();
					break;
				case	CMD_REW:
					playlist_prev();
					break;
				case	CMD_PLAY:
					mainwin_play_pushed();
					break;
				case	CMD_PAUSE:
					input_pause();
					break;
				case	CMD_STOP:
					mainwin_stop_pushed();
					break;
				case	CMD_FWD:
					playlist_next();
					break;
			}
			cmd=0;
			write(fd,&cmd,sizeof(gushort));
			close(fd);
		}
	}
}

gint connect_to_session(gint session)
{
	gint fd;
	struct sockaddr_un saddr;
	
	if((fd=socket(AF_UNIX,SOCK_STREAM,0))!=-1)
	{
		saddr.sun_family=AF_UNIX;
	    	sprintf(saddr.sun_path,"%s/.x11amp/x11amp_ctrl.%d",g_get_home_dir(),session);
		if(connect(fd,&saddr,sizeof(saddr))!=-1)
			return fd;
	}
	return 0;
}

void remote_playlist(gint fd,gchar **list,gint num,gboolean enqueue)
{
	gushort cmd;
	gushort i,len;
	
	if(enqueue)
		cmd=CMD_PLAYLIST_ENQUEUE;
	else
		cmd=CMD_PLAYLIST;
	write(fd,&cmd,sizeof(gushort));
	len=num;
	write(fd,&len,sizeof(gushort));
	
	for(i=0;i<num;i++)
	{
		len=strlen(list[i])+1;
		write(fd,&len,sizeof(gushort));
		write(fd,list[i],len);
	}
	read(fd,&cmd,sizeof(gushort));
	close(fd);
}

static void remote_cmd(gint fd,gushort cmd)
{
	write(fd,&cmd,sizeof(gushort));
	read(fd,&cmd,sizeof(gushort));
	close(fd);
}

void remote_rew(gint fd)
{
	remote_cmd(fd,CMD_REW);
}

void remote_play(gint fd)
{
	remote_cmd(fd,CMD_PLAY);
}

void remote_pause(gint fd)
{
	remote_cmd(fd,CMD_PAUSE);
}

void remote_stop(gint fd)
{
	remote_cmd(fd,CMD_STOP);
}

void remote_fwd(gint fd)
{
	remote_cmd(fd,CMD_FWD);
}
