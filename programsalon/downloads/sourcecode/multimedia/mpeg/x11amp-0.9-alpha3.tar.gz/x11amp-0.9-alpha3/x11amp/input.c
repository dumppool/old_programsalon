/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"

pthread_mutex_t vis_mutex=PTHREAD_MUTEX_INITIALIZER;

struct InputPluginData
{
	GList 		*input_list;
	InputPlugin	*current_input_plugin;
	gboolean	playing;
	gboolean	paused;
};


typedef struct
{
	gint		time;
	InputVisType	type;
	guchar		vis[75];
} VisEntry;
		
#ifndef fixed
#define fixed short
#endif

static int fix_fft(fixed fr[], fixed fi[], int m, int inverse);
static void fix_loud(fixed loud[], fixed fr[], fixed fi[], int n, int scale_shift);
static void window(fixed fr[], int n);

static gint fft_len=0;
		
struct InputPluginData *ip_data;
GList *vis_list=NULL;
gchar *input_info_text=NULL;
extern PlayStatus *mainwin_playstatus;


void input_add_vis(int time,unsigned char *s,InputVisType type);
void input_add_vis_pcm(int time,AFormat fmt,int nch,int length,void *ptr);
InputVisType input_get_vis_type();
void input_set_info(char *t,int len,int r,int f,int nch);
void input_set_info_text(gchar *text);	

InputPlugin *get_current_input_plugin(void)
{
	return ip_data->current_input_plugin;
}

void set_current_input_plugin(InputPlugin *ip)
{
	ip_data->current_input_plugin=ip;
}

void add_input_plugin(gchar *filename)
{
	void *h;
	InputPlugin *(*gpi)(void);
	InputPlugin *p;
	
	if(h=dlopen(filename,RTLD_NOW))
	{
		gpi=dlsym(h,"get_iplugin_info");
		if(gpi)
		{
			p=gpi();
			p->handle=h;
			p->filename=filename;
			p->add_vis=input_add_vis;
			p->get_vis_type=input_get_vis_type;
			p->add_vis_pcm=input_add_vis_pcm;
			p->set_info=playlist_set_info;
			p->set_info_text=input_set_info_text;

			if(p->init) 
				p->init();
			
			ip_data->input_list=g_list_prepend(ip_data->input_list,p);
		}
	}
	else
		fprintf(stderr,"%s\n",dlerror());
}

void scan_input_plugins(char *dirname)
{
	gchar *filename,*ext;
	DIR *dir;
	struct dirent *ent;
	struct stat statbuf;
	
	dir=opendir(dirname);
	if(dir)
	{
		while(ent=readdir(dir))
		{
			filename=(gchar *)g_malloc(strlen(dirname)+strlen(ent->d_name)+2);
			sprintf(filename,"%s/%s",dirname,ent->d_name);
			if(!stat(filename,&statbuf))
			{
				if(S_ISREG(statbuf.st_mode))
				{
					if(ext=strrchr(ent->d_name,'.'))
					{
						if(!strcmp(ext,".so"))
							add_input_plugin(filename);
						else
							g_free(filename);
					}
					else
						g_free(filename);
				}
				else
					g_free(filename);
			}
			else
				g_free(filename);
		}
	}
}
	
GList *get_input_list(void)
{
	return ip_data->input_list;
}

void input_add_vis(int time,unsigned char *s,InputVisType type)
{
	VisEntry *vis;
	
	pthread_mutex_lock(&vis_mutex);
	vis=g_malloc0(sizeof(VisEntry));
	vis->time=time;
	vis->type=type;
	memcpy(vis->vis,s,75);
	vis_list=g_list_append(vis_list,vis);
	pthread_mutex_unlock(&vis_mutex);
}

void input_add_vis_pcm(int time,AFormat fmt,int nch,int length,void *ptr)
{
	gint16 *left,*right,*ptr16;
	guint16 *ptru16;
	gint8 *ptr8;
	guint8 *ptru8;
	gint i,max,step,pos,spec_len,spec_base;
	gchar vis[75];
	fixed *re,*im,*loud;
	InputVisType type;
	
	if(input_get_vis_type()==INPUT_VIS_OFF)
		return;
	
	max=length/nch;
	if(fmt==FMT_U16_LE||fmt==FMT_U16_BE||fmt==FMT_U16_NE||fmt==FMT_S16_LE||fmt==FMT_S16_BE||fmt==FMT_S16_NE)
		max/=2;
	left=g_malloc(max*sizeof(gint16));
	right=g_malloc(max*sizeof(gint16));
	
	
	switch(fmt)
	{
		case	FMT_U8:
			ptru8=ptr;
			if(nch==1)
				for(i=0;i<max;i++)
					left[i]=((*ptru8++)^128)<<8;
			else
				for(i=0;i<max;i++)
				{
					left[i]=((*ptru8++)^128)<<8;
					right[i]=((*ptru8++)^128)<<8;
				}
			break;
		case	FMT_S8:
			ptru8=ptr;
			if(nch==1)
				for(i=0;i<max;i++)
					left[i]=(*ptru8++)<<8;
			else
				for(i=0;i<max;i++)
				{
					left[i]=(*ptru8++)<<8;
					right[i]=(*ptru8++)<<8;
				}
			break;
		case	FMT_U16_LE:
			ptru16=ptr;
			if(nch==1)
				for(i=0;i<max;i++)
					left[i]=GUINT16_FROM_LE(*ptru16++)^32768;
			else
				for(i=0;i<max;i++)
				{
					left[i]=GUINT16_FROM_LE(*ptru16++)^32768;
					right[i]=GUINT16_FROM_LE(*ptru16++)^32768;
				}
			break;
		case	FMT_U16_BE:
			ptru16=ptr;
			if(nch==1)
				for(i=0;i<max;i++)
					left[i]=GUINT16_FROM_BE(*ptru16++)^32768;
			else
				for(i=0;i<max;i++)
				{
					left[i]=GUINT16_FROM_BE(*ptru16++)^32768;
					right[i]=GUINT16_FROM_BE(*ptru16++)^32768;
				}
			break;
		case	FMT_U16_NE:
			ptru16=ptr;
			if(nch==1)
				for(i=0;i<max;i++)
					left[i]=(*ptru16++)^32768;
			else
				for(i=0;i<max;i++)
				{
					left[i]=(*ptru16++)^32768;
					right[i]=(*ptru16++)^32768;
				}
			break;
		case	FMT_S16_LE:
			ptru16=ptr;
			if(nch==1)
				for(i=0;i<max;i++)
					left[i]=GINT16_FROM_LE(*ptru16++);
			else
				for(i=0;i<max;i++)
				{
					left[i]=GINT16_FROM_LE(*ptru16++);
					right[i]=GINT16_FROM_LE(*ptru16++);
				}
			break;
		case	FMT_S16_BE:
			ptru16=ptr;
			if(nch==1)
				for(i=0;i<max;i++)
					left[i]=GINT16_FROM_BE(*ptru16++);
			else
				for(i=0;i<max;i++)
				{
					left[i]=GINT16_FROM_BE(*ptru16++);
					right[i]=GINT16_FROM_BE(*ptru16++);
				}
			break;
		case	FMT_S16_NE:
			ptru16=ptr;
			if(nch==1)
				for(i=0;i<max;i++)
					left[i]=(*ptru16++);
			else
				for(i=0;i<max;i++)
				{
					left[i]=(*ptru16++);
					right[i]=(*ptru16++);
				}
			break;
	}
	switch(type=input_get_vis_type())
	{
		case	INPUT_VIS_ANALYZER:
			spec_base=(gint)(log(max)/log(2));
			if(spec_base>10)
				spec_base=10;
			spec_len=(gint)pow(2,spec_base);
			
			re=g_malloc(spec_len*sizeof(fixed));
			im=g_malloc(spec_len*sizeof(fixed));
			loud=g_malloc(spec_len*sizeof(fixed));
			
			for(i=0;i<spec_len;i++)
			{
				if(nch==2)
					re[i]=(left[i]+right[i])>>1;
				else
					re[i]=left[i];
				im[i]=0;
			}			
			window(re,spec_len);
			fix_fft(re,im,spec_base,FALSE);
			fix_loud(loud,re,im,spec_len,0);
			step=spec_len/150;
			for(i=0,pos=0;i<75;i++,pos+=step)
			{
				if(loud[pos]>-60)
					vis[i]=(loud[pos]+60)/2;
				else
					vis[i]=0;
				if(vis[i]>15)
					vis[i]=15;
			}
			g_free(re);
			g_free(im);
			g_free(loud);
			break;
		case	INPUT_VIS_SCOPE:
			if(nch==2)
				for(i=0;i<max;i++)
					left[i]=(left[i]+right[i])>>1;
			step=max/75;
			for(i=0,pos=0;i<75;i++,pos+=step)
			{
				vis[i]=((left[pos])/2500)+6;
				if(vis[i]>12)
					vis[i]=12;
				if(vis[i]<0)
					vis[i]=0;
			}
			break;
		case	INPUT_VIS_VU:
			break;
	}
	input_add_vis(time,(guchar *)vis,type);
	g_free(left);
	g_free(right);
}
									
InputVisType input_get_vis_type()
{
	if(cfg.vis_type==VIS_ANALYZER)
		return INPUT_VIS_ANALYZER;
	if(cfg.vis_type==VIS_SCOPE)
		return INPUT_VIS_SCOPE;
	return INPUT_VIS_OFF;
}
	
static int inputlist_compare_func(const void *a, const void *b)
{
	return strcasecmp ((*(InputPlugin **)a)->description, (*(InputPlugin **)b)->description);
}

void init_input_plugins(void)
{
	gchar *dir;

	ip_data=g_malloc0(sizeof(struct InputPluginData));
	dir=g_strconcat(PLUGIN_DIR,"/Input",NULL);
	scan_input_plugins(dir);
	g_free(dir);
	ip_data->input_list=sort_glist(ip_data->input_list,inputlist_compare_func);
	
}

void cleanup_input_plugins(void)
{
	InputPlugin *ip;
	GList *node;
	
	
	if(get_input_playing())
		input_stop();
	
	node=get_input_list();
	while(node)
	{
		ip=(InputPlugin *)node->data;
		dlclose(ip->handle);
		node=node->next;
	}
	
}

gboolean input_check_file(gchar *filename)
{
	GList *node;
	InputPlugin *ip;
	
	node=get_input_list();
	while(node)
	{

		ip=(InputPlugin *)node->data;
		if(ip->is_our_file(filename))
			return TRUE;
		node=node->next;
	}
	return FALSE;
}
		

void input_play(char *filename)
{
	GList *node;
	InputPlugin *ip;
	
	
	node=get_input_list();
	while(node)
	{

		ip=(InputPlugin *)node->data;
		if(ip->is_our_file(filename))
		{
			set_current_input_plugin(ip);
			ip->output=get_current_output_plugin();
			ip->play_file(filename);
			ip_data->playing=TRUE;
			break;

		}
		node=node->next;
	}
}

void input_seek(int time)
{
	GList *node;
	if(ip_data->playing)
	{
		pthread_mutex_lock(&vis_mutex);
		node=vis_list;
		while(node)
		{
			g_free(node->data);
			node=g_list_next(node);
		}
		g_list_free(vis_list);
		vis_list=NULL;
		pthread_mutex_unlock(&vis_mutex);
		get_current_input_plugin()->seek(time);
	}
}

void input_stop(void)
{
	GList *node;
	fflush(stdout);
	if(ip_data->playing)
	{
		if(ip_data->paused)
			input_pause();
		get_current_input_plugin()->stop();
		pthread_mutex_lock(&vis_mutex);
		node=vis_list;
		while(node)
		{
			g_free(node->data);
			node=g_list_next(node);
		}
		g_list_free(vis_list);
		vis_list=NULL;
		pthread_mutex_unlock(&vis_mutex);
		ip_data->playing=FALSE;
		ip_data->paused=FALSE;
		if(input_info_text)
		{
			g_free(input_info_text);
			input_info_text=NULL;
			mainwin_set_info_text();
		}
	}
}

void input_pause(void)
{
	if(get_input_playing())
	{
		ip_data->paused=!ip_data->paused;
		if(ip_data->paused)
			playstatus_set_status(mainwin_playstatus,STATUS_PAUSE);
		else
			playstatus_set_status(mainwin_playstatus,STATUS_PLAY);
		get_current_input_plugin()->pause(ip_data->paused);	
	}
}

gint input_get_time(void)
{
	gint time;
	if(get_input_playing())
		time=get_current_input_plugin()->get_time();
	else
		time=-1;
	return time;
}

void input_set_eq(int on,float preamp,float *bands)
{
	if(ip_data->playing)
		if(get_current_input_plugin()->set_eq)
			get_current_input_plugin()->set_eq(on,preamp,bands);
}

gboolean get_input_playing(void)
{
	return ip_data->playing;
}

gboolean get_input_paused(void)
{
	return ip_data->paused;
}

guchar *input_get_vis(gint time)
{
	GList *node,*prev;
	VisEntry *vis;
	guchar *ret=NULL;
	gboolean found;
	
	pthread_mutex_lock(&vis_mutex);
	node=vis_list;
	found=FALSE;
	while(g_list_next(node)&&!found)
	{
		vis=(VisEntry *)node->data;
		if(((VisEntry *)g_list_next(node)->data)->time>=time&&vis->time<time)
		{
			if((vis->type==INPUT_VIS_ANALYZER&&cfg.vis_type==VIS_ANALYZER)||(vis->type==INPUT_VIS_SCOPE&&cfg.vis_type==VIS_SCOPE))
			{
				ret=g_malloc(75);
				memcpy(ret,vis->vis,75);
			}
			found=TRUE;
			while(node)
			{
				g_free(node->data);
				prev=g_list_previous(node);
				vis_list=g_list_remove_link(vis_list,node);
				g_list_free_1(node);
				node=prev;
			}
		}
		else
			
			node=g_list_next(node);
	}
	pthread_mutex_unlock(&vis_mutex);
	return ret;
}

gchar *input_get_info_text(void)
{
	return input_info_text;
}

void input_set_info_text(gchar *text)
{
	if(input_info_text)
		g_free(input_info_text);
	if(text)
		input_info_text=g_strdup(text);
	else
		input_info_text=NULL;
	mainwin_set_info_text();
}

void input_about(gint index)
{
	InputPlugin *ip;
	
	ip=g_list_nth(ip_data->input_list,index)->data;
	if(ip->about)
		ip->about();
}

void input_configure(gint index)
{
	InputPlugin *ip;
	
	ip=g_list_nth(ip_data->input_list,index)->data;
	if(ip->configure)
		ip->configure();
}


/*      fix_fft.c - Fixed-point Fast Fourier Transform  */
/*
        fix_fft()       perform FFT or inverse FFT
        window()        applies a Hanning window to the (time) input
        fix_loud()      calculates the loudness of the signal, for
                        each freq point. Result is an integer array,
                        units are dB (values will be negative).
        iscale()        scale an integer value by (numer/denom).
        fix_mpy()       perform fixed-point multiplication.
        Sinewave[1024]  sinewave normalized to 32767 (= 1.0).
        Loudampl[100]   Amplitudes for lopudnesses from 0 to -99 dB.
        Low_pass        Low-pass filter, cutoff at sample_freq / 4.


        All data are fixed-point short integers, in which
        -32768 to +32768 represent -1.0 to +1.0. Integer arithmetic
        is used for speed, instead of the more natural floating-point.

        For the forward FFT (time -> freq), fixed scaling is
        performed to prevent arithmetic overflow, and to map a 0dB
        sine/cosine wave (i.e. amplitude = 32767) to two -6dB freq
        coefficients; the one in the lower half is reported as 0dB
        by fix_loud(). The return value is always 0.

        For the inverse FFT (freq -> time), fixed scaling cannot be
        done, as two 0dB coefficients would sum to a peak amplitude of
        64K, overflowing the 32k range of the fixed-point integers.
        Thus, the fix_fft() routine performs variable scaling, and
        returns a value which is the number of bits LEFT by which
        the output must be shifted to get the actual amplitude
        (i.e. if fix_fft() returns 3, each value of fr[] and fi[]
        must be multiplied by 8 (2**3) for proper scaling.
        Clearly, this cannot be done within the fixed-point short
        integers. In practice, if the result is to be used as a
        filter, the scale_shift can usually be ignored, as the
        result will be approximately correctly normalized as is.


        TURBO C, any memory model; uses inline assembly for speed
        and for carefully-scaled arithmetic.

        Written by:  Tom Roberts  11/8/89
        Made portable:  Malcolm Slaney 12/15/94 malcolm@interval.com

                Timing on a Macintosh PowerBook 180.... (using Symantec C6.0)
                        fix_fft (1024 points)             8 ticks
                        fft (1024 points - Using SANE)  112 Ticks
                        fft (1024 points - Using FPU)    11

*/

/* FIX_MPY() - fixed-point multiplication macro.
   This macro is a statement, not an expression (uses asm).
   BEWARE: make sure _DX is not clobbered by evaluating (A) or DEST.
   args are all of type fixed.
   Scaling ensures that 32767*32767 = 32767. */

#define FIX_MPY(DEST,A,B)       DEST = ((long)(A) * (long)(B))>>15

#define N_WAVE          1024    /* dimension of Sinewave[] */
#define LOG2_N_WAVE     10      /* log2(N_WAVE) */
#define N_LOUD          100     /* dimension of Loudampl[] */

extern fixed Sinewave[N_WAVE]; /* placed at end of this file for clarity */
extern  fixed Loudampl[N_LOUD];
static int db_from_ampl(fixed re, fixed im);
static fixed fix_mpy(fixed a, fixed b);

/*
        fix_fft() - perform fast Fourier transform.

        if n>0 FFT is done, if n<0 inverse FFT is done
        fr[n],fi[n] are real,imaginary arrays, INPUT AND RESULT.
        size of data = 2**m
        set inverse to 0=dft, 1=idft
*/
static int fix_fft(fixed fr[], fixed fi[], int m, int inverse)
{
        int mr,nn,i,j,l,k,istep, n, scale, shift;
        fixed qr,qi,tr,ti,wr,wi,t;

                n = 1<<m;

        if(n > N_WAVE)
                return -1;

        mr = 0;
        nn = n - 1;
        scale = 0;

        /* decimation in time - re-order data */
        for(m=1; m<=nn; ++m) {
                l = n;
                do {
                        l >>= 1;
                } while(mr+l > nn);
                mr = (mr & (l-1)) + l;

                if(mr <= m) continue;
                tr = fr[m];
                fr[m] = fr[mr];
                fr[mr] = tr;
                ti = fi[m];
                fi[m] = fi[mr];
                fi[mr] = ti;
        }

        l = 1;
        k = LOG2_N_WAVE-1;
        while(l < n) {
                if(inverse) {
                        /* variable scaling, depending upon data */
                        shift = 0;
                        for(i=0; i<n; ++i) {
                                j = fr[i];
                                if(j < 0)
                                        j = -j;
                                m = fi[i];
                                if(m < 0)
                                        m = -m;
                                if(j > 16383 || m > 16383) {
                                        shift = 1;
                                        break;
                                }
                        }
                        if(shift)
                                ++scale;
                } else {
                        /* fixed scaling, for proper normalization -
                           there will be log2(n) passes, so this
                           results in an overall factor of 1/n,
                           distributed to maximize arithmetic accuracy. */
                        shift = 1;
                }
                /* it may not be obvious, but the shift will be performed
                   on each data point exactly once, during this pass. */
                istep = l << 1;
                for(m=0; m<l; ++m) {
                        j = m << k;
                        /* 0 <= j < N_WAVE/2 */
                        wr =  Sinewave[j+N_WAVE/4];
                        wi = -Sinewave[j];
                        if(inverse)
                                wi = -wi;
                        if(shift) {
                                wr >>= 1;
                                wi >>= 1;
                        }
                        for(i=m; i<n; i+=istep) {
                                j = i + l;
                                        tr = fix_mpy(wr,fr[j]) -
fix_mpy(wi,fi[j]);
                                        ti = fix_mpy(wr,fi[j]) +
fix_mpy(wi,fr[j]);
                                qr = fr[i];
                                qi = fi[i];
                                if(shift) {
                                        qr >>= 1;
                                        qi >>= 1;
                                }
                                fr[j] = qr - tr;
                                fi[j] = qi - ti;
                                fr[i] = qr + tr;
                                fi[i] = qi + ti;
                        }
                }
                --k;
                l = istep;
        }

        return scale;
}


/*      window() - apply a Hanning window       */
static void window(fixed fr[], int n)
{
        int i,j,k;

        j = N_WAVE/n;
        n >>= 1;
        for(i=0,k=N_WAVE/4; i<n; ++i,k+=j)
                FIX_MPY(fr[i],fr[i],16384-(Sinewave[k]>>1));
        n <<= 1;
        for(k-=j; i<n; ++i,k-=j)
                FIX_MPY(fr[i],fr[i],16384-(Sinewave[k]>>1));
}

/*      fix_loud() - compute loudness of freq-vis components.
        n should be ntot/2, where ntot was passed to fix_fft();
        6 dB is added to account for the omitted alias components.
        scale_shift should be the result of fix_fft(), if the time-series
        was obtained from an inverse FFT, 0 otherwise.
        loud[] is the loudness, in dB wrt 32767; will be +10 to -N_LOUD.
*/
static void fix_loud(fixed loud[], fixed fr[], fixed fi[], int n, int scale_shift)
{
        int i, max;

        max = 0;
        if(scale_shift > 0)
                max = 10;
        scale_shift = (scale_shift+1) * 6;

        for(i=0; i<n; ++i) {
                loud[i] = db_from_ampl(fr[i],fi[i]) + scale_shift;
                if(loud[i] > max)
                        loud[i] = max;
        }
}

/*      db_from_ampl() - find loudness (in dB) from
        the complex amplitude.
*/
static int db_from_ampl(fixed re, fixed im)
{
        static long loud2[N_LOUD] = {0};
        long v;
        int i;

        if(loud2[0] == 0) {
                loud2[0] = (long)Loudampl[0] * (long)Loudampl[0];
                for(i=1; i<N_LOUD; ++i) {
                        v = (long)Loudampl[i] * (long)Loudampl[i];
                        loud2[i] = v;
                        loud2[i-1] = (loud2[i-1]+v) / 2;
                }
        }

        v = (long)re * (long)re + (long)im * (long)im;

        for(i=0; i<N_LOUD; ++i)
                if(loud2[i] <= v)
                        break;

        return (-i);
}

/*
        fix_mpy() - fixed-point multiplication
*/
static fixed fix_mpy(fixed a, fixed b)
{
        FIX_MPY(a,a,b);
        return a;
}

/*
        iscale() - scale an integer value by (numer/denom)
*/
static int iscale(int value, int numer, int denom)
{
                return (long) value * (long)numer/(long)denom;
}

/*
        fix_dot() - dot product of two fixed arrays
*/
static fixed fix_dot(fixed *hpa, fixed *pb, int n)
{
        fixed *pa;
        long sum;
        register fixed a,b;
        unsigned int seg,off;

/*      seg = FP_SEG(hpa);
        off = FP_OFF(hpa);
        seg += off>>4;
        off &= 0x000F;
        pa = MK_FP(seg,off);
 */
        sum = 0L;
        while(n--) {
                a = *pa++;
                b = *pb++;
                FIX_MPY(a,a,b);
                sum += a;
        }

        if(sum > 0x7FFF)
                sum = 0x7FFF;
        else if(sum < -0x7FFF)
                sum = -0x7FFF;

        return (fixed)sum;


}


#if N_WAVE != 1024
        ERROR: N_WAVE != 1024
#endif
static fixed Sinewave[1024] = {
      0,    201,    402,    603,    804,   1005,   1206,   1406,
   1607,   1808,   2009,   2209,   2410,   2610,   2811,   3011,
   3211,   3411,   3611,   3811,   4011,   4210,   4409,   4608,
   4807,   5006,   5205,   5403,   5601,   5799,   5997,   6195,
   6392,   6589,   6786,   6982,   7179,   7375,   7571,   7766,
   7961,   8156,   8351,   8545,   8739,   8932,   9126,   9319,
   9511,   9703,   9895,  10087,  10278,  10469,  10659,  10849,
  11038,  11227,  11416,  11604,  11792,  11980,  12166,  12353,
  12539,  12724,  12909,  13094,  13278,  13462,  13645,  13827,
  14009,  14191,  14372,  14552,  14732,  14911,  15090,  15268,
  15446,  15623,  15799,  15975,  16150,  16325,  16499,  16672,
  16845,  17017,  17189,  17360,  17530,  17699,  17868,  18036,
  18204,  18371,  18537,  18702,  18867,  19031,  19194,  19357,
  19519,  19680,  19840,  20000,  20159,  20317,  20474,  20631,
  20787,  20942,  21096,  21249,  21402,  21554,  21705,  21855,
  22004,  22153,  22301,  22448,  22594,  22739,  22883,  23027,
  23169,  23311,  23452,  23592,  23731,  23869,  24006,  24143,
  24278,  24413,  24546,  24679,  24811,  24942,  25072,  25201,
  25329,  25456,  25582,  25707,  25831,  25954,  26077,  26198,
  26318,  26437,  26556,  26673,  26789,  26905,  27019,  27132,
  27244,  27355,  27466,  27575,  27683,  27790,  27896,  28001,
  28105,  28208,  28309,  28410,  28510,  28608,  28706,  28802,
  28897,  28992,  29085,  29177,  29268,  29358,  29446,  29534,
  29621,  29706,  29790,  29873,  29955,  30036,  30116,  30195,
  30272,  30349,  30424,  30498,  30571,  30643,  30713,  30783,
  30851,  30918,  30984,  31049,
  31113,  31175,  31236,  31297,
  31356,  31413,  31470,  31525,  31580,  31633,  31684,  31735,
  31785,  31833,  31880,  31926,  31970,  32014,  32056,  32097,
  32137,  32176,  32213,  32249,  32284,  32318,  32350,  32382,
  32412,  32441,  32468,  32495,  32520,  32544,  32567,  32588,
  32609,  32628,  32646,  32662,  32678,  32692,  32705,  32717,
  32727,  32736,  32744,  32751,  32757,  32761,  32764,  32766,
  32767,  32766,  32764,  32761,  32757,  32751,  32744,  32736,
  32727,  32717,  32705,  32692,  32678,  32662,  32646,  32628,
  32609,  32588,  32567,  32544,  32520,  32495,  32468,  32441,
  32412,  32382,  32350,  32318,  32284,  32249,  32213,  32176,
  32137,  32097,  32056,  32014,  31970,  31926,  31880,  31833,
  31785,  31735,  31684,  31633,  31580,  31525,  31470,  31413,
  31356,  31297,  31236,  31175,  31113,  31049,  30984,  30918,
  30851,  30783,  30713,  30643,  30571,  30498,  30424,  30349,
  30272,  30195,  30116,  30036,  29955,  29873,  29790,  29706,
  29621,  29534,  29446,  29358,  29268,  29177,  29085,  28992,
  28897,  28802,  28706,  28608,  28510,  28410,  28309,  28208,
  28105,  28001,  27896,  27790,  27683,  27575,  27466,  27355,
  27244,  27132,  27019,  26905,  26789,  26673,  26556,  26437,
  26318,  26198,  26077,  25954,  25831,  25707,  25582,  25456,
  25329,  25201,  25072,  24942,  24811,  24679,  24546,  24413,
  24278,  24143,  24006,  23869,  23731,  23592,  23452,  23311,
  23169,  23027,  22883,  22739,  22594,  22448,  22301,  22153,
  22004,  21855,  21705,  21554,  21402,  21249,  21096,  20942,
  20787,  20631,  20474,  20317,  20159,  20000,  19840,  19680,
  19519,  19357,  19194,  19031,  18867,  18702,  18537,  18371,
  18204,  18036,  17868,  17699,  17530,  17360,  17189,  17017,
  16845,  16672,  16499,  16325,  16150,  15975,  15799,  15623,
  15446,  15268,  15090,  14911,  14732,  14552,  14372,  14191,
  14009,  13827,  13645,  13462,  13278,  13094,  12909,  12724,
  12539,  12353,  12166,  11980,  11792,  11604,  11416,  11227,
  11038,  10849,  10659,  10469,  10278,  10087,   9895,   9703,
   9511,   9319,   9126,   8932,   8739,   8545,   8351,   8156,
   7961,   7766,   7571,   7375,   7179,   6982,   6786,   6589,
   6392,   6195,   5997,   5799,   5601,   5403,   5205,   5006,
   4807,   4608,   4409,   4210,   4011,   3811,   3611,   3411,
   3211,   3011,   2811,   2610,   2410,   2209,   2009,   1808,
   1607,   1406,   1206,   1005,    804,    603,    402,    201,
      0,   -201,   -402,   -603,   -804,  -1005,  -1206,  -1406,
  -1607,  -1808,  -2009,  -2209,  -2410,  -2610,  -2811,  -3011,
  -3211,  -3411,  -3611,  -3811,  -4011,  -4210,  -4409,  -4608,
  -4807,  -5006,  -5205,  -5403,  -5601,  -5799,  -5997,  -6195,
  -6392,  -6589,  -6786,  -6982,  -7179,  -7375,  -7571,  -7766,
  -7961,  -8156,  -8351,  -8545,  -8739,  -8932,  -9126,  -9319,
  -9511,  -9703,  -9895, -10087, -10278, -10469, -10659, -10849,
 -11038, -11227, -11416, -11604, -11792, -11980, -12166, -12353,
 -12539, -12724, -12909, -13094, -13278, -13462, -13645, -13827,
 -14009, -14191, -14372, -14552, -14732, -14911, -15090, -15268,
 -15446, -15623, -15799, -15975, -16150, -16325, -16499, -16672,
 -16845, -17017, -17189, -17360, -17530, -17699, -17868, -18036,
 -18204, -18371, -18537, -18702, -18867, -19031, -19194, -19357,
 -19519, -19680, -19840, -20000, -20159, -20317, -20474, -20631,
 -20787, -20942, -21096, -21249, -21402, -21554, -21705, -21855,
 -22004, -22153, -22301, -22448, -22594, -22739, -22883, -23027,
 -23169, -23311, -23452, -23592, -23731, -23869, -24006, -24143,
 -24278, -24413, -24546, -24679, -24811, -24942, -25072, -25201,
 -25329, -25456, -25582, -25707, -25831, -25954, -26077, -26198,
 -26318, -26437, -26556, -26673, -26789, -26905, -27019, -27132,
 -27244, -27355, -27466, -27575, -27683, -27790, -27896, -28001,
 -28105, -28208, -28309, -28410, -28510, -28608, -28706, -28802,
 -28897, -28992, -29085, -29177, -29268, -29358, -29446, -29534,
 -29621, -29706, -29790, -29873, -29955, -30036, -30116, -30195,
 -30272, -30349, -30424, -30498, -30571, -30643, -30713, -30783,
 -30851, -30918, -30984, -31049, -31113, -31175, -31236, -31297,
 -31356, -31413, -31470, -31525, -31580, -31633, -31684, -31735,
 -31785, -31833, -31880, -31926, -31970, -32014, -32056, -32097,
 -32137, -32176, -32213, -32249, -32284, -32318, -32350, -32382,
 -32412, -32441, -32468, -32495, -32520, -32544, -32567, -32588,
 -32609, -32628, -32646, -32662, -32678, -32692, -32705, -32717,
 -32727, -32736, -32744, -32751, -32757, -32761, -32764, -32766,
 -32767, -32766, -32764, -32761, -32757, -32751, -32744, -32736,
 -32727, -32717, -32705, -32692, -32678, -32662, -32646, -32628,
 -32609, -32588, -32567, -32544, -32520, -32495, -32468, -32441,
 -32412, -32382, -32350, -32318, -32284, -32249, -32213, -32176,
 -32137, -32097, -32056, -32014, -31970, -31926, -31880, -31833,
 -31785, -31735, -31684, -31633, -31580, -31525, -31470, -31413,
 -31356, -31297, -31236, -31175, -31113, -31049, -30984, -30918,
 -30851, -30783, -30713, -30643, -30571, -30498, -30424, -30349,
 -30272, -30195, -30116, -30036, -29955, -29873, -29790, -29706,
 -29621, -29534, -29446, -29358, -29268, -29177, -29085, -28992,
 -28897, -28802, -28706, -28608, -28510, -28410, -28309, -28208,
 -28105, -28001, -27896, -27790, -27683, -27575, -27466, -27355,
 -27244, -27132, -27019, -26905, -26789, -26673, -26556, -26437,
 -26318, -26198, -26077, -25954, -25831, -25707, -25582, -25456,
 -25329, -25201, -25072, -24942, -24811, -24679, -24546, -24413,
 -24278, -24143, -24006, -23869, -23731, -23592, -23452, -23311,
 -23169, -23027, -22883, -22739, -22594, -22448, -22301, -22153,
 -22004, -21855, -21705, -21554, -21402, -21249, -21096, -20942,
 -20787, -20631, -20474, -20317, -20159, -20000, -19840, -19680,
 -19519, -19357, -19194, -19031, -18867, -18702, -18537, -18371,
 -18204, -18036, -17868, -17699, -17530, -17360, -17189, -17017,
 -16845, -16672, -16499, -16325, -16150, -15975, -15799, -15623,
 -15446, -15268, -15090, -14911, -14732, -14552, -14372, -14191,
 -14009, -13827, -13645, -13462, -13278, -13094, -12909, -12724,
 -12539, -12353, -12166, -11980, -11792, -11604, -11416, -11227,
 -11038, -10849, -10659, -10469, -10278, -10087,  -9895,  -9703,
  -9511,  -9319,  -9126,  -8932,  -8739,  -8545,  -8351,  -8156,
  -7961,  -7766,  -7571,  -7375,  -7179,  -6982,  -6786,  -6589,
  -6392,  -6195,  -5997,  -5799,  -5601,  -5403,  -5205,  -5006,
  -4807,  -4608,  -4409,  -4210,  -4011,  -3811,  -3611,  -3411,
  -3211,  -3011,  -2811,  -2610,  -2410,  -2209,  -2009,  -1808,
  -1607,  -1406,  -1206,  -1005,   -804,   -603,   -402,   -201,
};

#if N_LOUD != 100
        ERROR: N_LOUD != 100
#endif
static fixed Loudampl[100] = {
  32767,  29203,  26027,  23197,  20674,  18426,  16422,  14636,
  13044,  11626,  10361,   9234,   8230,   7335,   6537,   5826,
   5193,   4628,   4125,   3676,   3276,   2920,   2602,   2319,
   2067,   1842,   1642,   1463,   1304,   1162,   1036,    923,
    823,    733,    653,    582,    519,    462,    412,    367,
    327,    292,    260,    231,    206,    184,    164,    146,
    130,    116,    103,     92,     82,     73,     65,     58,
     51,     46,     41,     36,     32,     29,     26,     23,
     20,     18,     16,     14,     13,     11,     10,      9,
      8,      7,      6,      5,      5,      4,      4,      3,
      3,      2,      2,      2,      2,      1,      1,      1,
      1,      1,      1,      0,      0,      0,      0,      0,
      0,      0,      0,      0,
};

