/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"
	
/*
 * This is just some old stuff from x11amp 0.7 it should be replaced with GList 
 */
 
		
LList *alloc_list(void)
{
	LList *list;
	list=(LList *)malloc(sizeof(LList));
	memset(list,0,sizeof(LList));
	return list;
}

void free_list(LList *list)
{
	Node *node,*next;
	node=list->li_first;
	while(node)
	{
		next=node->no_next;
		free(node);
		node=next;
	}
	free(list);
}	

void add_tail(LList *list,void *node)
{
	Node *n=(Node *)node;
	n->no_next=NULL;
	if(!list->li_first)
		list->li_first=n;
	if(list->li_last)
		list->li_last->no_next=n;
	list->li_last=n;
}

void add_head(LList *list,void *node)
{
	Node *n=(Node *)node;
	n->no_next=list->li_first;
	list->li_first=n;
	if(!list->li_last)
		list->li_last=n;
}
		
