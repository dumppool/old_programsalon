/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"
#include <gdk/gdkprivate.h>
#include <X11/Xlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>		
		
int find_file(char *dest,const char *dirname,const char *file)
{
	DIR *dir;
	struct dirent *dirent;
	
	if(dir=opendir(dirname))
	{
		while(dirent=readdir(dir))
		{
			if(!strcasecmp(dirent->d_name,file))
			{
				sprintf(dest,"%s/%s",dirname,dirent->d_name);
				closedir(dir);
				return 1;
			}
		}
		closedir(dir);
	}
	return 0;
}	

int del_directory(const char *dirname)
{
	DIR *dir;
	struct dirent *dirent;
	char *file;
	
	if(dir=opendir(dirname))
	{	
		while(dirent=readdir(dir))
		{
			if(strcmp(dirent->d_name,".")&&strcmp(dirent->d_name,".."))
			{
				file=(char *)g_malloc(strlen(dirname)+strlen(dirent->d_name)+2);
				sprintf(file,"%s/%s",dirname,dirent->d_name);
				if(unlink(file)==-1) if(errno==EISDIR) del_directory(file);
				g_free(file);
			}
		}
	}
	rmdir(dirname);
}

GdkImage *create_dblsize_image(GdkImage *img)
{
	GdkImage *dblimg;
	register guint x,y;
	
	
	/*
	 * This needs to be optimized
	 */
	
	dblimg=gdk_image_new(GDK_IMAGE_NORMAL,gdk_visual_get_best(),img->width<<1,img->height<<1);
	if(dblimg->bpp==1)
	{
		register guint8	*srcptr,*ptr,*ptr2,pix;
		srcptr=((GdkImagePrivate *)img)->ximage->data;
		ptr=((GdkImagePrivate *)dblimg)->ximage->data;
		ptr2=ptr+dblimg->bpl;
		
		for(y=0;y<img->height;y++)
		{
			for(x=0;x<img->width;x++)
			{
				pix=*srcptr++;
				*ptr++=pix;
				*ptr++=pix;
				*ptr2++=pix;
				*ptr2++=pix;
			}
			srcptr+=img->bpl-img->width;
			ptr+=(dblimg->bpl<<1)-dblimg->width;
			ptr2+=(dblimg->bpl<<1)-dblimg->width;
		}
	}
	if(dblimg->bpp==2)
	{
		guint16	*srcptr,*ptr,*ptr2,pix;
		srcptr=(guint16 *)((GdkImagePrivate *)img)->ximage->data;
		ptr=(guint16 *)((GdkImagePrivate *)dblimg)->ximage->data;
		ptr2=ptr+(dblimg->bpl>>1);
		
		for(y=0;y<img->height;y++)
		{
			for(x=0;x<img->width;x++)
			{
				pix=*srcptr++;
				*ptr++=pix;
				*ptr++=pix;
				*ptr2++=pix;
				*ptr2++=pix;
			}
			srcptr+=(img->bpl>>1)-img->width;
			ptr+=(dblimg->bpl)-dblimg->width;
			ptr2+=(dblimg->bpl)-dblimg->width;
		}
	}
	if(dblimg->bpp==3)
	{
		register guint8	*srcptr,*ptr,*ptr2,pix1,pix2,pix3;
		srcptr=((GdkImagePrivate *)img)->ximage->data;
		ptr=((GdkImagePrivate *)dblimg)->ximage->data;
		ptr2=ptr+dblimg->bpl;
		
		for(y=0;y<img->height;y++)
		{
			for(x=0;x<img->width;x++)
			{
				pix1=*srcptr++;
				pix2=*srcptr++;
				pix3=*srcptr++;
				*ptr++=pix1;
				*ptr++=pix2;
				*ptr++=pix3;
				*ptr++=pix1;
				*ptr++=pix2;
				*ptr++=pix3;
				*ptr2++=pix1;
				*ptr2++=pix2;
				*ptr2++=pix3;
				*ptr2++=pix1;
				*ptr2++=pix2;
				*ptr2++=pix3;
				
			}
			srcptr+=img->bpl-(img->width*3);
			ptr+=(dblimg->bpl<<1)-(dblimg->width*3);
			ptr2+=(dblimg->bpl<<1)-(dblimg->width*3);
		}
	}
	if(dblimg->bpp==4)
	{
		register guint32	*srcptr,*ptr,*ptr2,pix;
		srcptr=(guint32 *)((GdkImagePrivate *)img)->ximage->data;
		ptr=(guint32 *)((GdkImagePrivate *)dblimg)->ximage->data;
		ptr2=ptr+(dblimg->bpl>>2);
		
		for(y=0;y<img->height;y++)
		{
			for(x=0;x<img->width;x++)
			{
				pix=*srcptr++;
				*ptr++=pix;
				*ptr++=pix;
				*ptr2++=pix;
				*ptr2++=pix;
			}
			srcptr+=(img->bpl>>2)-img->width;
			ptr+=(dblimg->bpl>>1)-dblimg->width;
			ptr2+=(dblimg->bpl>>1)-dblimg->width;
		}
	}
	return dblimg;
}

GList *sort_glist(GList *list,int (*list_compare_func)(const void *a, const void *b))
{
	GList *list_t;
	gchar **list_ptrs;
	int list_length;
	int i;

	if (!list) return NULL;

	list_length=g_list_length(list);
	list_ptrs=g_malloc(sizeof(gchar *)*list_length);
	list_t=list;

	for(i=0;i<list_length;i++)
	{
		list_ptrs[i]=list_t->data;
		list_t=list_t->next;
	}

	g_list_free (list);
	list=NULL;

	qsort(list_ptrs,list_length, sizeof(gchar *), list_compare_func);

	while(list_length > 0)
	{
		list_length--;
		list=g_list_prepend(list,list_ptrs[list_length]);
	}
	g_free(list_ptrs);
	return list;
}


char *read_ini_string(const char *filename,const char *section,const char *key)
{
	FILE *file;
	char *buffer,*ret_buffer=NULL;
	int found_section=0,found_key=0,off=0,len=0;
	struct stat statbuf;
	
	if(!filename)
		return	NULL;
	
	if(file=fopen(filename,"r"))
	{
		stat(filename,&statbuf);
		buffer=(char *)g_malloc(statbuf.st_size);
		fread(buffer,1,statbuf.st_size,file);
		while(!found_key&&off<statbuf.st_size)
		{
			while((buffer[off]=='\r'||buffer[off]=='\n'||buffer[off]==' ')&&off<statbuf.st_size) off++;
			if(off>=statbuf.st_size) break;
			if(buffer[off]=='[')
			{
				off++;
				if(off>=statbuf.st_size) break;
				if(off<statbuf.st_size-strlen(section))
				{
					if(!strncasecmp(section,&buffer[off],strlen(section)))
					{
						off+=strlen(section);
						if(off>=statbuf.st_size) break;
						if(buffer[off]==']')
							found_section=1;
						else
							found_section=0;
						off++;
						if(off>=statbuf.st_size) break;
					}
					else
						found_section=0;
				}
				else
					found_section=0;
				
			}
			else if(found_section)
			{
				if(off<statbuf.st_size-strlen(key))
				{
					if(!strncasecmp(key,&buffer[off],strlen(key)))
					{
						off+=strlen(key);
						if(off>=statbuf.st_size) break;
						if(buffer[off]=='=')
						{
							off++;
							if(off>=statbuf.st_size) break;
							len=0;
							while(buffer[off+len]!='\r'&&buffer[off+len]!='\n'&&off+len<statbuf.st_size) len++;
							ret_buffer=(char *)g_malloc(len+1);
							strncpy(ret_buffer,&buffer[off],len);
							ret_buffer[len]='\0';
							off+=len;
							found_key=1;
						}
					}
				}
			}
			while(buffer[off]!='\r'&&buffer[off]!='\n'&&off<statbuf.st_size) off++;
		}
		g_free(buffer);
		fclose(file);
	}
	return ret_buffer;
}

void glist_movedown(GList *list)
{
	gpointer temp;
	if(g_list_next(list))
	{
		temp=list->data;
		list->data=g_list_next(list)->data;
		g_list_next(list)->data=temp;
	}
}

void glist_moveup(GList *list)
{
	gpointer temp;
	if(g_list_previous(list))
	{
		temp=list->data;
		list->data=g_list_previous(list)->data;
		g_list_previous(list)->data=temp;

	}
}
