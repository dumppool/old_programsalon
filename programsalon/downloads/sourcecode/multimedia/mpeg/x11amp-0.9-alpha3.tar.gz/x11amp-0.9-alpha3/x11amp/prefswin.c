/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include	"x11amp.h"

GtkWidget	*prefswin,*prefswin_notebook;
GtkWidget	*prefswin_audio_vbox;
GtkWidget	*prefswin_audio_iframe,*prefswin_audio_ivbox,*prefswin_audio_ilist,*prefswin_audio_ihbox;
GtkWidget	*prefswin_audio_iconfig,*prefswin_audio_iabout;
GtkWidget	*prefswin_audio_oframe,*prefswin_audio_ovbox,*prefswin_audio_olist,*prefswin_audio_ohbox;
GtkWidget	*prefswin_audio_oconfig,*prefswin_audio_oabout;
GtkWidget	*prefswin_options_frame,*prefswin_options_vbox,*prefswin_options_table;
GtkWidget	*prefswin_options_ami,*prefswin_options_asc;
GtkWidget	*prefswin_options_cus,*prefswin_options_cts;
GtkWidget 	*prefswin_options_snp,*prefswin_options_sw;
GtkWidget	*prefswin_options_swp,*prefswin_options_dim;
GtkWidget	*prefswin_options_font_frame,*prefswin_options_font_hbox;
GtkWidget	*prefswin_options_font_entry,*prefswin_options_font_browse;
GtkWidget	*prefswin_options_fontsel;
GtkWidget	*prefswin_vbox,*prefswin_hbox,*prefswin_ok,*prefswin_cancel,*prefswin_apply;

extern MenuRow *mainwin_menurow;

gint prefswin_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
	gtk_widget_hide(prefswin);
	return(TRUE);
}

void prefswin_iconfigure(GtkWidget *w,gpointer data)
{
	if(GTK_CLIST(prefswin_audio_ilist)->selection)
		input_configure((gint)GTK_CLIST(prefswin_audio_ilist)->selection->data);
}

void prefswin_iabout(GtkWidget *w,gpointer data)
{
	if(GTK_CLIST(prefswin_audio_ilist)->selection)
		input_about((gint)GTK_CLIST(prefswin_audio_ilist)->selection->data);
}


void prefswin_oconfigure(GtkWidget *w,gpointer data)
{
	output_configure();
}


void prefswin_oabout(GtkWidget *w,gpointer data)
{
	output_about();
}

void prefswin_apply_changes(void)
{
	g_free(cfg.playlist_font);
	cfg.allow_multiple_instances=GTK_TOGGLE_BUTTON(prefswin_options_ami)->active;
	cfg.always_show_cb=GTK_TOGGLE_BUTTON(prefswin_options_asc)->active;
	cfg.convert_underscore=GTK_TOGGLE_BUTTON(prefswin_options_cus)->active;
	cfg.convert_twenty=GTK_TOGGLE_BUTTON(prefswin_options_cts)->active;
	cfg.show_numbers_in_pl=GTK_TOGGLE_BUTTON(prefswin_options_snp)->active;
	cfg.snap_windows=GTK_TOGGLE_BUTTON(prefswin_options_sw)->active;
	cfg.save_window_position=GTK_TOGGLE_BUTTON(prefswin_options_swp)->active;
	cfg.dim_titlebar=GTK_TOGGLE_BUTTON(prefswin_options_dim)->active;
	cfg.playlist_font=g_strdup(gtk_entry_get_text(GTK_ENTRY(prefswin_options_font_entry)));
	draw_main_window(TRUE);
	draw_playlist_window(TRUE);
	draw_equalizer_window(TRUE);
}

void prefswin_ok_cb(GtkWidget *w,gpointer data)
{
	prefswin_apply_changes();
	gtk_widget_hide(prefswin);
}

void prefswin_cancel_cb(GtkWidget *w,gpointer data)
{
	gtk_widget_hide(prefswin);
}

void prefswin_apply_cb(GtkWidget *w,gpointer data)
{
	prefswin_apply_changes();
}

void prefswin_font_browse_ok(GtkWidget *w,gpointer data)
{
	gtk_entry_set_text(GTK_ENTRY(prefswin_options_font_entry),gtk_font_selection_dialog_get_font_name(GTK_FONT_SELECTION_DIALOG(prefswin_options_fontsel)));
	gtk_widget_destroy(prefswin_options_fontsel);
}

void prefswin_font_browse_cb(GtkWidget *w,gpointer data)
{
	if(!prefswin_options_fontsel)
	{
		prefswin_options_fontsel=gtk_font_selection_dialog_new("Select playlist font:");
		gtk_font_selection_dialog_set_font_name(GTK_FONT_SELECTION_DIALOG(prefswin_options_fontsel),cfg.playlist_font);
		gtk_signal_connect(GTK_OBJECT(GTK_FONT_SELECTION_DIALOG(prefswin_options_fontsel)->ok_button),"clicked",GTK_SIGNAL_FUNC(prefswin_font_browse_ok),NULL);
		gtk_signal_connect_object(GTK_OBJECT(GTK_FONT_SELECTION_DIALOG(prefswin_options_fontsel)->cancel_button),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(prefswin_options_fontsel));		
		gtk_signal_connect(GTK_OBJECT(prefswin_options_fontsel),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&prefswin_options_fontsel);		
		gtk_widget_show(prefswin_options_fontsel);
	}
}

void create_prefs_window(void)
{
	GtkWidget *empty,*scrolled_win;
	gchar *input_titles[]={"Input plugins"};
	
	prefswin=gtk_window_new(GTK_WINDOW_DIALOG);
	gtk_window_set_title(GTK_WINDOW(prefswin),"Preferences");
	gtk_window_set_position(GTK_WINDOW(prefswin),GTK_WIN_POS_CENTER);
	gtk_window_set_policy (GTK_WINDOW(prefswin), FALSE,FALSE,FALSE);
	gtk_window_set_transient_for(GTK_WINDOW(prefswin),GTK_WINDOW(mainwin));
	gtk_widget_set_usize(prefswin,450,350);
	gtk_signal_connect(GTK_OBJECT(prefswin),"delete_event",GTK_SIGNAL_FUNC(prefswin_delete_event), NULL);
	gtk_container_border_width(GTK_CONTAINER(prefswin),10);
	
	prefswin_vbox=gtk_vbox_new(FALSE,10);
	gtk_container_add(GTK_CONTAINER(prefswin),prefswin_vbox);
	prefswin_notebook=gtk_notebook_new();
	gtk_box_pack_start(GTK_BOX(prefswin_vbox),prefswin_notebook,TRUE,TRUE,0);
	
	
	/*
	 * Audio I/O Page
	 */ 
	
	prefswin_audio_vbox=gtk_vbox_new(FALSE,0);
	
	/*
	 * Input plugins
	 */
	
	prefswin_audio_iframe=gtk_frame_new("Input Plugins");
	gtk_container_border_width(GTK_CONTAINER(prefswin_audio_iframe),5);
	gtk_box_pack_start(GTK_BOX(prefswin_audio_vbox),prefswin_audio_iframe,TRUE,TRUE,0);
	
	prefswin_audio_ivbox=gtk_vbox_new(FALSE,5);
	gtk_container_border_width(GTK_CONTAINER(prefswin_audio_ivbox),5);
	gtk_container_add(GTK_CONTAINER(prefswin_audio_iframe),prefswin_audio_ivbox);
	
	prefswin_audio_ilist=gtk_clist_new_with_titles(1,input_titles);
	gtk_clist_column_titles_passive(GTK_CLIST(prefswin_audio_ilist));
	gtk_clist_set_selection_mode(GTK_CLIST(prefswin_audio_ilist),GTK_SELECTION_SINGLE);
	scrolled_win=gtk_scrolled_window_new(NULL,NULL);
	gtk_container_add(GTK_CONTAINER(scrolled_win),prefswin_audio_ilist);
	gtk_container_border_width(GTK_CONTAINER(scrolled_win),5);
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_win),GTK_POLICY_AUTOMATIC,GTK_POLICY_ALWAYS);
	gtk_box_pack_start(GTK_BOX(prefswin_audio_ivbox),scrolled_win,TRUE,TRUE,0);
	
	prefswin_audio_ihbox=gtk_hbutton_box_new();
	gtk_button_box_set_layout(GTK_BUTTON_BOX(prefswin_audio_ihbox),GTK_BUTTONBOX_START);
	gtk_button_box_set_spacing(GTK_BUTTON_BOX(prefswin_audio_ihbox),10);
	gtk_button_box_set_child_size(GTK_BUTTON_BOX(prefswin_audio_ihbox),85,17);
	gtk_box_pack_start(GTK_BOX(prefswin_audio_ivbox),prefswin_audio_ihbox,FALSE,FALSE,5);
	
	prefswin_audio_iconfig=gtk_button_new_with_label("Configure");
	gtk_signal_connect(GTK_OBJECT(prefswin_audio_iconfig),"clicked",GTK_SIGNAL_FUNC(prefswin_iconfigure),NULL);
	gtk_box_pack_start(GTK_BOX(prefswin_audio_ihbox),prefswin_audio_iconfig,TRUE,TRUE,0);
	prefswin_audio_iabout=gtk_button_new_with_label("About");
	gtk_signal_connect(GTK_OBJECT(prefswin_audio_iabout),"clicked",GTK_SIGNAL_FUNC(prefswin_iabout),NULL);
	gtk_box_pack_start(GTK_BOX(prefswin_audio_ihbox),prefswin_audio_iabout,TRUE,TRUE,0);
	
	/* 
	 * Output plugin
	 */ 
	
	prefswin_audio_oframe=gtk_frame_new("Output Plugin");
	gtk_container_border_width(GTK_CONTAINER(prefswin_audio_oframe),5);
	gtk_box_pack_start(GTK_BOX(prefswin_audio_vbox),prefswin_audio_oframe,FALSE,FALSE,0);
	
	prefswin_audio_ovbox=gtk_vbox_new(FALSE,10);
	gtk_container_border_width(GTK_CONTAINER(prefswin_audio_ovbox),5);
	gtk_container_add(GTK_CONTAINER(prefswin_audio_oframe),prefswin_audio_ovbox);
	
	prefswin_audio_olist=gtk_option_menu_new();
	gtk_box_pack_start(GTK_BOX(prefswin_audio_ovbox),prefswin_audio_olist,TRUE,TRUE,0);
	
	
	
	prefswin_audio_ohbox=gtk_hbutton_box_new();
	gtk_button_box_set_layout(GTK_BUTTON_BOX(prefswin_audio_ohbox),GTK_BUTTONBOX_START);
	gtk_button_box_set_spacing(GTK_BUTTON_BOX(prefswin_audio_ohbox),10);
	gtk_button_box_set_child_size(GTK_BUTTON_BOX(prefswin_audio_ohbox),85,17);
	gtk_box_pack_start(GTK_BOX(prefswin_audio_ovbox),prefswin_audio_ohbox,FALSE,FALSE,0);
	
	prefswin_audio_oconfig=gtk_button_new_with_label("Configure");
	gtk_signal_connect(GTK_OBJECT(prefswin_audio_oconfig),"clicked",GTK_SIGNAL_FUNC(prefswin_oconfigure),NULL);
	gtk_box_pack_start(GTK_BOX(prefswin_audio_ohbox),prefswin_audio_oconfig,TRUE,TRUE,0);
	
	prefswin_audio_oabout=gtk_button_new_with_label("About");
	gtk_signal_connect(GTK_OBJECT(prefswin_audio_oabout),"clicked",GTK_SIGNAL_FUNC(prefswin_oabout),NULL);
	gtk_box_pack_start(GTK_BOX(prefswin_audio_ohbox),prefswin_audio_oabout,TRUE,TRUE,0);
	
	gtk_notebook_append_page(GTK_NOTEBOOK(prefswin_notebook),prefswin_audio_vbox,gtk_label_new("Audio I/O"));
	
	/*
	 * Options page
	 */
	
	prefswin_options_vbox=gtk_vbox_new(FALSE,0);
	prefswin_options_frame=gtk_frame_new("Options");
	gtk_box_pack_start(GTK_BOX(prefswin_options_vbox),prefswin_options_frame,FALSE,FALSE,0);
	gtk_container_border_width(GTK_CONTAINER(prefswin_options_frame),5);
	prefswin_options_table=gtk_table_new(2,4,FALSE);
	gtk_container_add(GTK_CONTAINER(prefswin_options_frame),prefswin_options_table);
	gtk_container_border_width(GTK_CONTAINER(prefswin_options_table),5);
	
	
	
	prefswin_options_ami=gtk_check_button_new_with_label("Allow multiple instances");
	gtk_table_attach_defaults(GTK_TABLE(prefswin_options_table),prefswin_options_ami,0,1,0,1);
	prefswin_options_asc=gtk_check_button_new_with_label("Always show clutterbar");
	gtk_table_attach_defaults(GTK_TABLE(prefswin_options_table),prefswin_options_asc,1,2,0,1);
	
	prefswin_options_cus=gtk_check_button_new_with_label("Convert underscore to space");
	gtk_table_attach_defaults(GTK_TABLE(prefswin_options_table),prefswin_options_cus,0,1,1,2);
	prefswin_options_cts=gtk_check_button_new_with_label("Convert %20 to space");
	gtk_table_attach_defaults(GTK_TABLE(prefswin_options_table),prefswin_options_cts,1,2,1,2);
	
	prefswin_options_snp=gtk_check_button_new_with_label("Show numbers in playlist");
	gtk_table_attach_defaults(GTK_TABLE(prefswin_options_table),prefswin_options_snp,0,1,2,3);
	prefswin_options_sw=gtk_check_button_new_with_label("Snap windows");
	gtk_table_attach_defaults(GTK_TABLE(prefswin_options_table),prefswin_options_sw,1,2,2,3);
	
	prefswin_options_swp=gtk_check_button_new_with_label("Save window positions");
	gtk_table_attach_defaults(GTK_TABLE(prefswin_options_table),prefswin_options_swp,0,1,3,4);
	prefswin_options_dim=gtk_check_button_new_with_label("Dim titlebar when inactive");
	gtk_table_attach_defaults(GTK_TABLE(prefswin_options_table),prefswin_options_dim,1,2,3,4);
	
	prefswin_options_font_frame=gtk_frame_new("Playlist font");
	gtk_container_set_border_width(GTK_CONTAINER(prefswin_options_font_frame),5);
	gtk_box_pack_start(GTK_BOX(prefswin_options_vbox),prefswin_options_font_frame,FALSE,FALSE,0);
	prefswin_options_font_hbox=gtk_hbox_new(FALSE,5);
	gtk_container_border_width(GTK_CONTAINER(prefswin_options_font_hbox),5);
	gtk_container_add(GTK_CONTAINER(prefswin_options_font_frame),prefswin_options_font_hbox);
	prefswin_options_font_entry=gtk_entry_new();
	gtk_box_pack_start(GTK_BOX(prefswin_options_font_hbox),prefswin_options_font_entry,TRUE,TRUE,0);
	prefswin_options_font_browse=gtk_button_new_with_label("Browse");
	gtk_signal_connect(GTK_OBJECT(prefswin_options_font_browse),"clicked",GTK_SIGNAL_FUNC(prefswin_font_browse_cb),NULL);
	gtk_widget_set_usize(prefswin_options_font_browse,85,17);
	gtk_box_pack_start(GTK_BOX(prefswin_options_font_hbox),prefswin_options_font_browse,FALSE,TRUE,0);
	
	gtk_notebook_append_page(GTK_NOTEBOOK(prefswin_notebook),prefswin_options_vbox,gtk_label_new("Options"));
	
	
	/* 
	 *Ok, Cancel & Apply 
	 */
	
	prefswin_hbox=gtk_hbutton_box_new();
	gtk_button_box_set_layout(GTK_BUTTON_BOX(prefswin_hbox),GTK_BUTTONBOX_END);
	gtk_button_box_set_spacing(GTK_BUTTON_BOX(prefswin_hbox),5);
	gtk_box_pack_start(GTK_BOX(prefswin_vbox),prefswin_hbox,FALSE,FALSE,0);
		
	prefswin_ok=gtk_button_new_with_label("Ok");
	gtk_signal_connect(GTK_OBJECT(prefswin_ok),"clicked",GTK_SIGNAL_FUNC(prefswin_ok_cb),NULL);
	GTK_WIDGET_SET_FLAGS(prefswin_ok,GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(prefswin_hbox),prefswin_ok,TRUE,TRUE,0);
	prefswin_cancel=gtk_button_new_with_label("Cancel");
	gtk_signal_connect(GTK_OBJECT(prefswin_cancel),"clicked",GTK_SIGNAL_FUNC(prefswin_cancel_cb),NULL);
	GTK_WIDGET_SET_FLAGS(prefswin_cancel,GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(prefswin_hbox),prefswin_cancel,TRUE,TRUE,0);
	prefswin_apply=gtk_button_new_with_label("Apply");
	gtk_signal_connect(GTK_OBJECT(prefswin_apply),"clicked",GTK_SIGNAL_FUNC(prefswin_apply_cb),NULL);
	GTK_WIDGET_SET_FLAGS(prefswin_apply,GTK_CAN_DEFAULT);
	gtk_box_pack_start(GTK_BOX(prefswin_hbox),prefswin_apply,TRUE,TRUE,0);
}

void prefswin_output_cb(GtkWidget *w,gint item)
{
	set_current_output_plugin(item);
}


void add_output_plugins(void)
{
	GList *olist=get_output_list();
	GtkWidget *menu,*item;
	OutputPlugin *cp=get_current_output_plugin();
	gint i=0,history=0;
	
	menu=gtk_menu_new();
	while(olist)
	{
		if(olist->data==cp) history=i;
		item=gtk_menu_item_new_with_label(((OutputPlugin *)olist->data)->description);
		gtk_signal_connect(GTK_OBJECT(item),"activate",GTK_SIGNAL_FUNC(prefswin_output_cb),(gpointer)i);
		gtk_widget_show(item);
		gtk_menu_append(GTK_MENU(menu),item);
		olist=olist->next;
		i++;
	}
	gtk_option_menu_remove_menu(GTK_OPTION_MENU(prefswin_audio_olist));
	gtk_option_menu_set_menu(GTK_OPTION_MENU(prefswin_audio_olist),menu);
	gtk_option_menu_set_history(GTK_OPTION_MENU(prefswin_audio_olist),history);
	
}

void add_input_plugins(void)
{
	GList *ilist=get_input_list();
	
	gtk_clist_clear(GTK_CLIST(prefswin_audio_ilist));
	while(ilist)
	{
		gtk_clist_append(GTK_CLIST(prefswin_audio_ilist),(gchar **)&(((InputPlugin *)ilist->data)->description));
		ilist=ilist->next;
	}
}

void toggle_button_set_state(GtkToggleButton *tb,gboolean state)
{
	
	/*
	 * Why can't they make up their minds :)
	 */
	
#if (GTK_MAJOR_VERSION==1) && (GTK_MINOR_VERSION==1) && (GTK_MICRO_VERSION<=12)
	gtk_toggle_button_set_state(tb,state);
#else
	gtk_toggle_button_set_active(tb,state);
#endif
}

void show_prefs_window(void)
{
	add_output_plugins();
	add_input_plugins();
	
	gtk_entry_set_text(GTK_ENTRY(prefswin_options_font_entry),cfg.playlist_font);
	toggle_button_set_state(GTK_TOGGLE_BUTTON(prefswin_options_ami),cfg.allow_multiple_instances);
	toggle_button_set_state(GTK_TOGGLE_BUTTON(prefswin_options_asc),cfg.always_show_cb);
	toggle_button_set_state(GTK_TOGGLE_BUTTON(prefswin_options_cus),cfg.convert_underscore);
	toggle_button_set_state(GTK_TOGGLE_BUTTON(prefswin_options_cts),cfg.convert_twenty);
	toggle_button_set_state(GTK_TOGGLE_BUTTON(prefswin_options_snp),cfg.show_numbers_in_pl);
	toggle_button_set_state(GTK_TOGGLE_BUTTON(prefswin_options_sw),cfg.snap_windows);
	toggle_button_set_state(GTK_TOGGLE_BUTTON(prefswin_options_swp),cfg.save_window_position);
	toggle_button_set_state(GTK_TOGGLE_BUTTON(prefswin_options_dim),cfg.dim_titlebar);
	
	gtk_widget_show_all(prefswin);
	gtk_widget_grab_default(prefswin_ok);
	
}
	
	

