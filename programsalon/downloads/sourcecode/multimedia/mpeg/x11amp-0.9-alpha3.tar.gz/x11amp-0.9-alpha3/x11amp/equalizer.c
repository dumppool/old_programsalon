/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"

GtkWidget *equalizerwin;
GdkPixmap *equalizerwin_bg,*equalizerwin_bg_dblsize;
GdkGC *equalizerwin_gc;

LList *equalizerwin_wlist;

TButton	*equalizerwin_on,*equalizerwin_auto;
extern TButton *mainwin_eq;
PButton *equalizerwin_presets,*equalizerwin_close;
EqGraph *equalizerwin_graph;
EqSlider *equalizerwin_preamp,*equalizerwin_bands[10];

static gboolean equalizerwin_focus=FALSE,equalizerwin_moving=FALSE;
static gint equalizerwin_move_x,equalizerwin_move_y;

void equalizerwin_set_doublesize(gboolean ds)
{
	gint ox,oy;
	if(ds)
	{
		gdk_window_set_hints(equalizerwin->window,0,0,550,232,550,232,GDK_HINT_MIN_SIZE|GDK_HINT_MAX_SIZE);
		gdk_window_resize(equalizerwin->window,550,232);
		gdk_window_set_back_pixmap(equalizerwin->window,equalizerwin_bg_dblsize,0);
		draw_equalizer_window(TRUE);
		
	}
	else
	{
		gdk_window_set_hints(equalizerwin->window,0,0,275,116,275,116,GDK_HINT_MIN_SIZE|GDK_HINT_MAX_SIZE);
		gdk_window_resize(equalizerwin->window,275,116);
		gdk_window_set_back_pixmap(equalizerwin->window,equalizerwin_bg,0);
		gdk_window_clear(equalizerwin->window);
	}
}

void equalizerwin_raise(void)
{
	if(cfg.equalizer_visible)
		gdk_window_raise(equalizerwin->window);
}

void equalizerwin_move(gint x,gint y)
{
	cfg.equalizer_x=x;
	cfg.equalizer_y=y;
	if(cfg.equalizer_visible) gdk_window_move(equalizerwin->window,x,y);
}
	
void equalizerwin_eq_changed(void)
{
	int i;
	
	cfg.equalizer_preamp=eqslider_get_position(equalizerwin_preamp);
	for(i=0;i<10;i++)
		cfg.equalizer_bands[i]=eqslider_get_position(equalizerwin_bands[i]);
	input_set_eq(cfg.equalizer_active,cfg.equalizer_preamp,cfg.equalizer_bands);
	draw_widget(equalizerwin_graph);
}

void equalizerwin_on_pushed(gboolean toggled)
{
	cfg.equalizer_active=toggled;
	equalizerwin_eq_changed();
}

void draw_equalizer_window(gboolean force)
{
	GdkImage *img,*img2;
	WidgetNode *wn;
	Widget *w;
	gboolean redraw;
	
	if(force)
	{
		gdk_draw_pixmap(equalizerwin_bg,equalizerwin_gc,get_skin_pixmap(SKIN_EQMAIN),0,0,0,0,275,116);
		if(equalizerwin_focus || !cfg.dim_titlebar)
			gdk_draw_pixmap(equalizerwin_bg,equalizerwin_gc,get_skin_pixmap(SKIN_EQMAIN),0,134,0,0,275,14);
		else
			gdk_draw_pixmap(equalizerwin_bg,equalizerwin_gc,get_skin_pixmap(SKIN_EQMAIN),0,149,0,0,275,14);
		draw_widget_list(equalizerwin_wlist,&redraw,TRUE);
	}
	else
		draw_widget_list(equalizerwin_wlist,&redraw,FALSE);
	if(force||redraw)
	{
		if(cfg.doublesize)
		{
			if(force)
			{
				img=gdk_image_get(equalizerwin_bg,0,0,275,116);
				img2=create_dblsize_image(img);
				gdk_draw_image(equalizerwin_bg_dblsize,equalizerwin_gc,img2,0,0,0,0,550,232);
				gdk_image_destroy(img2);
				gdk_image_destroy(img);
			}
			else
			{
				wn=(WidgetNode *)equalizerwin_wlist->li_first;
				while(wn)
				{
					w=wn->wn_widget;
					if(w->redraw&&w->visible)
					{
						img=gdk_image_get(equalizerwin_bg,w->x,w->y,w->width,w->height);
						img2=create_dblsize_image(img);
						gdk_draw_image(equalizerwin_bg_dblsize,equalizerwin_gc,img2,0,0,w->x<<1,w->y<<1,w->width<<1,w->height<<1);
						gdk_image_destroy(img2);
						gdk_image_destroy(img);
						w->redraw=FALSE;
					}
					wn=(WidgetNode *)wn->wn_node.no_next;
				}
			}
		}
		else
			clear_widget_list_redraw(equalizerwin_wlist);
		gdk_window_clear(equalizerwin->window);
		gdk_flush();
	}
}	

void equalizerwin_press(GtkWidget *widget,GdkEventButton *event,gpointer callback_data)
{
	gboolean redraw;
	gint mx,my;
	
	mx=event->x;
	my=event->y;
	if(cfg.doublesize)
	{
		event->x/=2;
		event->y/=2;
	}
	
	if(event->y<14&&event->x<265&&event->button==1)
	{
		equalizerwin_moving=TRUE;
		equalizerwin_move_x=mx;
		equalizerwin_move_y=my;	
		equalizerwin_raise();	
	}
	else
	{
		handle_press_cb(equalizerwin_wlist,widget,event);
		draw_equalizer_window(FALSE);
	}
	gdk_pointer_grab(equalizerwin->window,FALSE,GDK_BUTTON_MOTION_MASK|GDK_BUTTON_RELEASE_MASK,GDK_NONE,GDK_NONE,GDK_CURRENT_TIME);
}	
	
void equalizerwin_motion(GtkWidget *widget,GdkEventMotion *event,gpointer callback_data)
{
	XEvent ev;
	
	
	if(cfg.doublesize)
	{
		event->x/=2;
		event->y/=2;
	}
	if(equalizerwin_moving)
	{
		gint mx,my,mww,mwh,newx,newy;
		gint sw,sh,w,h;
		GdkModifierType modmask;
		
		gdk_window_get_pointer(NULL, &mx, &my, &modmask);
		newx=mx-equalizerwin_move_x;
		newy=my-equalizerwin_move_y;
		sw=gdk_screen_width();
		sh=gdk_screen_height();
		gdk_window_get_size(equalizerwin->window,&w,&h);
		
		if(newx>-10&&newx<10) newx=0;
		if(newx+w>sw-10&&newx+w<sw+10) newx=sw-w;
		if(newy>-10&&newy<10) newy=0;
		if(newy+h>sh-10&&newy+h<sh+10) newy=sh-h;
		
		gdk_window_get_size(mainwin->window,&mww,&mwh);
		dock(&newx,&newy,w,h,cfg.player_x,cfg.player_y,mww,mwh);
		if(cfg.playlist_visible) dock(&newx,&newy,w,h,cfg.playlist_x,cfg.playlist_y,cfg.playlist_width,cfg.playlist_height);

		equalizerwin_move(newx,newy);
		gdk_flush();
	}
	else
	{
		handle_motion_cb(equalizerwin_wlist,widget,event);
		draw_main_window(FALSE);
	}
	gdk_flush();
	while(XCheckMaskEvent(GDK_DISPLAY(),ButtonMotionMask,&ev));

}

void equalizerwin_release(GtkWidget *widget,GdkEventButton *event,gpointer callback_data)
{
	if(equalizerwin_moving)
	{
		equalizerwin_moving=FALSE;
	}
	else
	{
		handle_release_cb(equalizerwin_wlist,widget,event);
		draw_equalizer_window(FALSE);
	}
	gdk_pointer_ungrab(GDK_CURRENT_TIME);
}
	

void equalizerwin_focus_in(GtkWidget *widget,GdkEvent *event,gpointer callback_data)
{
	show_widget(equalizerwin_close);
	equalizerwin_focus=TRUE;
	draw_equalizer_window(TRUE);
}

void equalizerwin_focus_out(GtkWidget *widget,GdkEventButton *event,gpointer callback_data)
{
	hide_widget(equalizerwin_close);
	equalizerwin_focus=FALSE;
	draw_equalizer_window(TRUE);
}

gint equalizerwin_configure(GtkWidget *window)
{
	Window dummy;
	
	if(!equalizerwin_moving&&!mainwin_moving)
		XTranslateCoordinates(GDK_DISPLAY(),GDK_WINDOW_XWINDOW(window->window),GDK_ROOT_WINDOW(),0,0,&cfg.equalizer_x,&cfg.equalizer_y,&dummy);
	return FALSE;
}


void equalizerwin_create(void)
{
	int i;
#if (GTK_MAJOR_VERSION>=1) && (GTK_MINOR_VERSION>=1) && (GTK_MICRO_VERSION>=5) && (GTK_MICRO_VERSION<=7)
	equalizerwin=gtk_draw_window_new(GTK_WINDOW_DIALOG);
#else
	equalizerwin=gtk_window_new(GTK_WINDOW_DIALOG);
#ifdef GTK_HAVE_FEATURES_1_1_8
	gtk_widget_set_app_paintable(equalizerwin,TRUE);
#endif
#endif
	gtk_window_set_policy(GTK_WINDOW(equalizerwin),FALSE,FALSE,TRUE);
	gtk_window_set_title(GTK_WINDOW(equalizerwin),"X11Amp Equalizer");
	gtk_window_set_wmclass(GTK_WINDOW(equalizerwin),"X11Amp_Equalizer","x11amp");
	gtk_window_set_transient_for(GTK_WINDOW(equalizerwin),GTK_WINDOW(mainwin));
	if(cfg.doublesize)
		gtk_widget_set_usize(equalizerwin,550,232);
	else
		gtk_widget_set_usize(equalizerwin,275,116);
	
	gtk_widget_set_events(equalizerwin,GDK_FOCUS_CHANGE_MASK|GDK_BUTTON_MOTION_MASK|GDK_BUTTON_PRESS_MASK|GDK_BUTTON_RELEASE_MASK);
	gtk_widget_realize(equalizerwin);
	gdk_window_set_decorations(equalizerwin->window,0);
	
	equalizerwin_gc=gdk_gc_new(equalizerwin->window);
	equalizerwin_bg=gdk_pixmap_new(equalizerwin->window,275,116,gdk_visual_get_best_depth());
	equalizerwin_bg_dblsize=gdk_pixmap_new(equalizerwin->window,550,232,gdk_visual_get_best_depth());
	if(cfg.doublesize)
		gdk_window_set_back_pixmap(equalizerwin->window,equalizerwin_bg_dblsize,0);
	else
		gdk_window_set_back_pixmap(equalizerwin->window,equalizerwin_bg,0);
	
	gtk_signal_connect(GTK_OBJECT(equalizerwin),"button_press_event",GTK_SIGNAL_FUNC(equalizerwin_press),NULL);
	gtk_signal_connect(GTK_OBJECT(equalizerwin),"button_release_event",GTK_SIGNAL_FUNC(equalizerwin_release),NULL);
	gtk_signal_connect(GTK_OBJECT(equalizerwin),"motion_notify_event",GTK_SIGNAL_FUNC(equalizerwin_motion),NULL);
	gtk_signal_connect(GTK_OBJECT(equalizerwin),"focus_in_event",GTK_SIGNAL_FUNC(equalizerwin_focus_in),NULL);
	gtk_signal_connect(GTK_OBJECT(equalizerwin),"focus_out_event",GTK_SIGNAL_FUNC(equalizerwin_focus_out),NULL);
	gtk_signal_connect(GTK_OBJECT(equalizerwin),"configure_event",GTK_SIGNAL_FUNC(equalizerwin_configure),NULL);
	
	
	equalizerwin_wlist=alloc_list();
	
	equalizerwin_on=create_tbutton(equalizerwin_wlist,equalizerwin_bg,equalizerwin_gc,14,18,25,12,10,119,128,119,69,119,187,119,equalizerwin_on_pushed,SKIN_EQMAIN);
	tbutton_set_toggled(equalizerwin_on,cfg.equalizer_active);
	equalizerwin_auto=create_tbutton(equalizerwin_wlist,equalizerwin_bg,equalizerwin_gc,39,18,33,12,35,119,153,119,94,119,212,119,NULL,SKIN_EQMAIN);
	equalizerwin_presets=create_pbutton(equalizerwin_wlist,equalizerwin_bg,equalizerwin_gc,217,18,44,12,224,164,224,176,NULL,SKIN_EQMAIN);
	equalizerwin_close=create_pbutton(equalizerwin_wlist,equalizerwin_bg,equalizerwin_gc,264,3,9,9,0,116,0,125,equalizerwin_hide,SKIN_EQMAIN);
	
	equalizerwin_graph=create_eqgraph(equalizerwin_wlist,equalizerwin_bg,equalizerwin_gc,86,17);
	equalizerwin_preamp=create_eqslider(equalizerwin_wlist,equalizerwin_bg,equalizerwin_gc,21,38);
	eqslider_set_position(equalizerwin_preamp,cfg.equalizer_preamp);
	for(i=0;i<10;i++)
	{
		equalizerwin_bands[i]=create_eqslider(equalizerwin_wlist,equalizerwin_bg,equalizerwin_gc,78+(i*18),38);
		eqslider_set_position(equalizerwin_bands[i],cfg.equalizer_bands[i]);
	}
}

void equalizerwin_show(void)
{
	if(cfg.doublesize)
		gtk_widget_set_usize(equalizerwin,550,232);
	else
		gtk_widget_set_usize(equalizerwin,275,116);
	gtk_widget_show(equalizerwin);
	if(cfg.equalizer_x!=-1&&cfg.save_window_position)
		/*gtk_widget_set_uposition(equalizerwin,cfg.equalizer_x,cfg.equalizer_y);*/
		gdk_window_move(equalizerwin->window,cfg.equalizer_x,cfg.equalizer_y);
	gdk_flush();
	draw_equalizer_window(TRUE);
	cfg.equalizer_visible=TRUE;
	tbutton_set_toggled(mainwin_eq,TRUE);
}

void equalizerwin_hide(void)
{
	gtk_widget_hide(equalizerwin);
	cfg.equalizer_visible=FALSE;
	tbutton_set_toggled(mainwin_eq,FALSE);
}
