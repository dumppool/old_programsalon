/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#ifndef MAIN_H
#define MAIN_H

typedef enum
{
	TIMER_ELAPSED,TIMER_REMAINING
} TimerMode;

typedef struct
{
	gint		player_x,player_y;
	gint		playlist_x,playlist_y,playlist_width,playlist_height;
	gint		equalizer_x,equalizer_y;
	gboolean	shuffle,repeat,doublesize,autoscroll,playlist_visible,equalizer_visible,equalizer_active,analyzer_peaks;
	gboolean	allow_multiple_instances,always_show_cb;
	gboolean	convert_underscore,convert_twenty;
	gboolean	show_numbers_in_pl,snap_windows,save_window_position;
	gboolean	dim_titlebar;
	gfloat		equalizer_preamp,equalizer_bands[10];
	gchar		*skin,*outputplugin,*filesel_path,*playlist_font;
	gint		timer_mode,vis_type,analyzer_mode,analyzer_type,scope_mode,vu_mode,vis_refresh;
	gint		analyzer_falloff,peaks_falloff;
} Config;

extern Config cfg;

extern GtkWidget *mainwin;
extern GdkGC	*mainwin_gc;
extern GdkWindow *root_window;		
extern gboolean mainwin_moving;

gboolean is_docked(gint x,gint y,gint w,gint h,gint ox,gint oy,gint ow,gint oh);
void dock(gint *x,gint *y,gint w,gint h,gint ox,gint oy,gint ow,gint oh);
void draw_main_window(gboolean);
void set_timer_mode(TimerMode mode);
void mainwin_lock_info_text(gchar *text);
void mainwin_release_info_text(void);
		
#endif
