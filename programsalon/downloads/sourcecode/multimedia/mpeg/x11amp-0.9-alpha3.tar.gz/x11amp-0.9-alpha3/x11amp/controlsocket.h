/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#ifndef CONTROLSOCKET_H
#define CONTROLSOCKET_H

gboolean setup_ctrlsocket(void);
void cleanup_ctrlsocket(void);
void check_ctrlsocket(void);
gint connect_to_session(gint session);
void remote_playlist(gint fd,gchar **list,gint num,gboolean enqueue);
void remote_rew(gint fd);
void remote_play(gint fd);
void remote_pause(gint fd);
void remote_stop(gint fd);

#define CMD_PLAYLIST		1
#define CMD_PLAYLIST_ENQUEUE	2
#define	CMD_REW			3
#define	CMD_PLAY		4
#define	CMD_PAUSE		5
#define	CMD_STOP		6
#define	CMD_FWD			7

#endif
