/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"
		
int inside_widget(gint x,gint y,void *p)
{
	Widget *w=(Widget *)p;
	if(x>=w->x && x<w->x+w->width && y>=w->y && y<w->y+w->height&&w->visible) return 1;
	return 0;
}

void show_widget(void *w)
{
	((Widget *)w)->visible=1;
	draw_widget(w);
}

void hide_widget(void *w)
{
	((Widget *)w)->visible=0;
}

void resize_widget(void *w,gint width,gint height)
{
	((Widget *)w)->width=width;
	((Widget *)w)->height=height;
	draw_widget(w);
}

void move_widget(void *w,gint x,gint y)
{
	((Widget *)w)->x=x;
	((Widget *)w)->y=y;
	draw_widget(w);
}


void draw_widget(void *p)
{
	Widget *w=(Widget *)p;
	w->redraw=TRUE;
	
}

void add_widget(LList *list,void *w)
{
	WidgetNode *n;
	n=(WidgetNode *)malloc(sizeof(WidgetNode));
	n->wn_widget=w;
	add_tail(list,n);
}

void handle_press_cb(LList *wlist,GtkWidget *widget,GdkEventButton *event)
{
	WidgetNode *wn;
	wn=(WidgetNode *)wlist->li_first;
	while(wn)
	{
		if(wn->wn_widget->button_press_cb) wn->wn_widget->button_press_cb(widget,event,wn->wn_widget);
		wn=(WidgetNode *)wn->wn_node.no_next;
	}	
}

void handle_release_cb(LList *wlist,GtkWidget *widget,GdkEventButton *event)
{
	WidgetNode *wn;
	wn=(WidgetNode *)wlist->li_first;
	while(wn)
	{
		if(wn->wn_widget->button_release_cb) wn->wn_widget->button_release_cb(widget,event,wn->wn_widget);
		wn=(WidgetNode *)wn->wn_node.no_next;
	}	
}

void handle_motion_cb(LList *wlist,GtkWidget *widget,GdkEventMotion *event)
{
	WidgetNode *wn;
	wn=(WidgetNode *)wlist->li_first;
	while(wn)
	{
		if(wn->wn_widget->motion_cb) wn->wn_widget->motion_cb(widget,event,wn->wn_widget);
		wn=(WidgetNode *)wn->wn_node.no_next;
	}	
}

void draw_widget_list(LList *wlist,gboolean *redraw,gboolean force)
{
	WidgetNode *wn;
	Widget *w;
	*redraw=FALSE;
	wn=(WidgetNode *)wlist->li_first;
	while(wn)
	{
		w=wn->wn_widget;
		if((w->redraw||force)&&w->visible&&w->draw)
		{
			w->draw(w);
			/*w->redraw=FALSE;*/
			*redraw=TRUE;
		}
		wn=(WidgetNode *)wn->wn_node.no_next;
	}	
}

void widget_list_change_pixmap(LList *wlist,GdkPixmap *pixmap)
{
	WidgetNode *wn;
	
	wn=(WidgetNode *)wlist->li_first;
	while(wn)
	{
		wn->wn_widget->parent=pixmap;
		wn=(WidgetNode *)wn->wn_node.no_next;
	}
}

void clear_widget_list_redraw(LList *wlist)
{
	WidgetNode *wn;
	Widget *w;
	wn=(WidgetNode *)wlist->li_first;
	while(wn)
	{
		w=wn->wn_widget;
		w->redraw=FALSE;
		wn=(WidgetNode *)wn->wn_node.no_next;
	}
}
