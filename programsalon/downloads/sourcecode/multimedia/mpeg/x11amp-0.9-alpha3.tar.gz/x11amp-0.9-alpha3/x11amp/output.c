/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"

struct OutputPluginData
{
	GList *output_list;
	OutputPlugin *current_output_plugin;
};

struct OutputPluginData *op_data;

OutputPlugin *get_current_output_plugin(void)
{
	return op_data->current_output_plugin;
}

void set_current_output_plugin(int i)
{
	op_data->current_output_plugin=(OutputPlugin *)g_list_nth(op_data->output_list,i)->data;
}

void add_output_plugin(gchar *filename)
{
	void *h;
	OutputPlugin *(*gpi)(void);
	OutputPlugin *p;
	
	if(h=dlopen(filename,RTLD_NOW))
	{
		gpi=dlsym(h,"get_oplugin_info");
		if(gpi)
		{
			p=gpi();
			p->handle=h;
			p->filename=filename;
			if(p->init)
				p->init();
			op_data->output_list=g_list_prepend(op_data->output_list,p);
			if(!strcmp(cfg.outputplugin,filename))
				op_data->current_output_plugin=p;
		}
	}
	else
		fprintf(stderr,"%s\n",dlerror());
}

void scan_output_plugins(char *dirname)
{
	gchar *filename,*ext;
	DIR *dir;
	struct dirent *ent;
	struct stat statbuf;
	
	dir=opendir(dirname);
	if(dir)
	{
		while(ent=readdir(dir))
		{
			filename=(gchar *)g_malloc(strlen(dirname)+strlen(ent->d_name)+2);
			sprintf(filename,"%s/%s",dirname,ent->d_name);
			if(!stat(filename,&statbuf))
			{
				if(S_ISREG(statbuf.st_mode))
				{
					if(ext=strrchr(ent->d_name,'.'))
					{
						if(!strcmp(ext,".so"))
							add_output_plugin(filename);
						else
							g_free(filename);
					}
					else
						g_free(filename);
				}
				else
					g_free(filename);
			}
			else
				g_free(filename);
		}
	}
	else 
	{
		perror ("opendir");
	}
}


static int outputlist_compare_func(const void *a, const void *b)
{
	return strcasecmp ((*(OutputPlugin **)a)->description, (*(OutputPlugin **)b)->description);
}

void init_output_plugins(void)
{
	gchar *dir;
	op_data=g_malloc0(sizeof(struct OutputPluginData));
	dir=g_strconcat(PLUGIN_DIR,"/Output",NULL);
	scan_output_plugins(dir);
	g_free(dir);
	op_data->output_list=sort_glist(op_data->output_list,outputlist_compare_func);
	if(!op_data->current_output_plugin) op_data->current_output_plugin=(OutputPlugin *)op_data->output_list->data;
}

void cleanup_output_plugins(void)
{
	GList *node;
	OutputPlugin *op;
	
	node=get_output_list();
	while(node)
	{
		op=(OutputPlugin *)node->data;
		dlclose(op->handle);
		node=node->next;
	}
	g_free(op_data);
}

GList *get_output_list(void)
{
	return op_data->output_list;
}

void output_about(void)
{
	if(op_data->current_output_plugin->about) 
		op_data->current_output_plugin->about();
}

void output_configure(void)
{
	if(op_data->current_output_plugin->configure)
		op_data->current_output_plugin->configure();
}

void output_get_volume(int *l,int *r)
{
	if(op_data->current_output_plugin->get_volume) 
		op_data->current_output_plugin->get_volume(l,r);
}

void output_set_volume(int l,int r)
{
	if(op_data->current_output_plugin->set_volume) 
		op_data->current_output_plugin->set_volume(l,r);
}

