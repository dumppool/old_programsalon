aclocal
autoheader
automake --add-missing
autoconf
cd libx11amp
aclocal
autoheader
automake --add-missing
autoconf
cd ..
./configure $@
