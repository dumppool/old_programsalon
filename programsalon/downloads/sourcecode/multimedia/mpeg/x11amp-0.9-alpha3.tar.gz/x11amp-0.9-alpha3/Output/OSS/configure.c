/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "OSS.h"



static GtkWidget *configure_win=NULL,*vbox,*notebook;
static GtkWidget *dev_vbox,*adevice_frame,*adevice_box,*adevice,*mdevice_frame,*mdevice_box,*mdevice;
static GtkWidget *buffer_frame,*buffer_vbox,*buffer_table;
static GtkWidget *buffer_size_box,*buffer_size_label,*buffer_size_spin;
static GtkObject *buffer_size_adj;
static GtkWidget *buffer_pre_box,*buffer_pre_label,*buffer_pre_spin;
static GtkObject *buffer_pre_adj;
static GtkWidget *bbox,*ok,*cancel;
static gint audio_device,mixer_device;

void configure_win_ok_cb(GtkWidget *w,gpointer data)
{
	ConfigFile *cfgfile;
	gchar *filename;
	
	oss_cfg.audio_device=audio_device;
	oss_cfg.mixer_device=mixer_device;
	oss_cfg.buffer_size=(gint)GTK_ADJUSTMENT(buffer_size_adj)->value;
	oss_cfg.prebuffer=(gint)GTK_ADJUSTMENT(buffer_pre_adj)->value;
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/config",NULL);
	cfgfile=x11amp_cfg_open_file(filename);
	if(!cfgfile)
		cfgfile=x11amp_cfg_new();
	
	x11amp_cfg_write_int(cfgfile,"OSS","audio_device",oss_cfg.audio_device);
	x11amp_cfg_write_int(cfgfile,"OSS","mixer_device",oss_cfg.mixer_device);
	x11amp_cfg_write_int(cfgfile,"OSS","buffer_size",oss_cfg.buffer_size);
	x11amp_cfg_write_int(cfgfile,"OSS","prebuffer",oss_cfg.prebuffer);
	x11amp_cfg_write_file(cfgfile,filename);
	x11amp_cfg_free(cfgfile);
	
	g_free(filename);
	
	gtk_widget_destroy(configure_win);
}

void configure_win_audio_dev_cb(GtkWidget *widget,gint device)
{
	audio_device=device;
}

void configure_win_mixer_dev_cb(GtkWidget *widget,gint device)
{
	mixer_device=device;
}

static void scan_devices(gchar *type,GtkWidget *option_menu,GtkSignalFunc sigfunc)
{
	GtkWidget *menu,*item;
	FILE *file;
	gchar buffer[256];
	gboolean found=FALSE;
	gint index=0;
	
	menu=gtk_menu_new();
	item=gtk_menu_item_new_with_label("Default");
	gtk_signal_connect(GTK_OBJECT(item),"activate",sigfunc,(gpointer)-1);
	gtk_widget_show(item);
	gtk_menu_append(GTK_MENU(menu),item);
	
	if(file=fopen("/dev/sndstat","r"))
	{
		while(fgets(buffer,255,file))
		{
			if(found&&buffer[0]=='\n')
				break;
			if(buffer[strlen(buffer)-1]=='\n')
				buffer[strlen(buffer)-1]='\0';
			if(found)
			{
				item=gtk_menu_item_new_with_label(buffer);
				gtk_signal_connect(GTK_OBJECT(item),"activate",sigfunc,(gpointer)index++);
				gtk_widget_show(item);
				gtk_menu_append(GTK_MENU(menu),item);
			}
			if(!strcasecmp(buffer,type))
				found=1;

		}
		fclose(file);
	}
	gtk_option_menu_set_menu(GTK_OPTION_MENU(option_menu),menu);
}


void configure(void)
{
	if(!configure_win)
	{
		configure_win=gtk_window_new(GTK_WINDOW_DIALOG);
		gtk_signal_connect(GTK_OBJECT(configure_win),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&configure_win);
		gtk_window_set_title(GTK_WINDOW(configure_win),"OSS Driver configuration");
		gtk_window_set_policy(GTK_WINDOW(configure_win), FALSE,FALSE,FALSE);
		gtk_window_set_position(GTK_WINDOW(configure_win),GTK_WIN_POS_MOUSE);
		gtk_container_border_width(GTK_CONTAINER(configure_win),10);

		vbox=gtk_vbox_new(FALSE,10);
		gtk_container_add(GTK_CONTAINER(configure_win),vbox);

		notebook=gtk_notebook_new();
		gtk_box_pack_start(GTK_BOX(vbox),notebook,TRUE,TRUE,0);

		dev_vbox=gtk_vbox_new(FALSE,5);
		gtk_container_set_border_width(GTK_CONTAINER(dev_vbox),5);

		adevice_frame=gtk_frame_new("Audio device:");
		gtk_box_pack_start(GTK_BOX(dev_vbox),adevice_frame,FALSE,FALSE,0);

		adevice_box=gtk_hbox_new(FALSE,0);
		gtk_container_set_border_width(GTK_CONTAINER(adevice_box),5);
		gtk_container_add(GTK_CONTAINER(adevice_frame),adevice_box);

		adevice=gtk_option_menu_new();
		gtk_box_pack_start(GTK_BOX(adevice_box),adevice,TRUE,TRUE,0);
		scan_devices("Audio devices:",adevice,configure_win_audio_dev_cb);
		audio_device=oss_cfg.audio_device;
		gtk_option_menu_set_history(GTK_OPTION_MENU(adevice),oss_cfg.audio_device+1);

		gtk_widget_show(adevice);
		gtk_widget_show(adevice_box);
		gtk_widget_show(adevice_frame);

		mdevice_frame=gtk_frame_new("Mixer device:");
		gtk_box_pack_start(GTK_BOX(dev_vbox),mdevice_frame,FALSE,FALSE,0);

		mdevice_box=gtk_hbox_new(FALSE,0);
		gtk_container_set_border_width(GTK_CONTAINER(mdevice_box),5);
		gtk_container_add(GTK_CONTAINER(mdevice_frame),mdevice_box);

		mdevice=gtk_option_menu_new();
		gtk_box_pack_start(GTK_BOX(mdevice_box),mdevice,TRUE,TRUE,0);
		scan_devices("Mixers:",mdevice,configure_win_mixer_dev_cb);
		mixer_device=oss_cfg.mixer_device;
		gtk_option_menu_set_history(GTK_OPTION_MENU(mdevice),oss_cfg.mixer_device+1);

		gtk_widget_show(mdevice);
		gtk_widget_show(mdevice_box);
		gtk_widget_show(mdevice_frame);
		gtk_widget_show(dev_vbox);
		gtk_notebook_append_page(GTK_NOTEBOOK(notebook),dev_vbox,gtk_label_new("Devices"));

		buffer_frame=gtk_frame_new("Buffering:");
		gtk_container_set_border_width(GTK_CONTAINER(buffer_frame),5);

		buffer_vbox=gtk_vbox_new(FALSE,0);
		gtk_container_add(GTK_CONTAINER(buffer_frame),buffer_vbox);

		buffer_table=gtk_table_new(2,1,TRUE);
		gtk_container_set_border_width(GTK_CONTAINER(buffer_table),5);
		gtk_box_pack_start(GTK_BOX(buffer_vbox),buffer_table,FALSE,FALSE,0);

		buffer_size_box=gtk_hbox_new(FALSE,5);
		gtk_table_attach_defaults(GTK_TABLE(buffer_table),buffer_size_box,0,1,0,1);
		buffer_size_label=gtk_label_new("Buffer size (ms):");
		gtk_box_pack_start(GTK_BOX(buffer_size_box),buffer_size_label,FALSE,FALSE,0);
		gtk_widget_show(buffer_size_label);
		buffer_size_adj=gtk_adjustment_new(oss_cfg.buffer_size,200,10000,100,100,100);
		buffer_size_spin=gtk_spin_button_new(GTK_ADJUSTMENT(buffer_size_adj),8,0);
		gtk_widget_set_usize(buffer_size_spin,60,-1);
		gtk_box_pack_start(GTK_BOX(buffer_size_box),buffer_size_spin,FALSE,FALSE,0);
		gtk_widget_show(buffer_size_spin);
		gtk_widget_show(buffer_size_box);

		buffer_pre_box=gtk_hbox_new(FALSE,5);
		gtk_table_attach_defaults(GTK_TABLE(buffer_table),buffer_pre_box,1,2,0,1);
		buffer_pre_label=gtk_label_new("Pre-buffer (percent):");
		gtk_box_pack_start(GTK_BOX(buffer_pre_box),buffer_pre_label,FALSE,FALSE,0);
		gtk_widget_show(buffer_pre_label);
		buffer_pre_adj=gtk_adjustment_new(oss_cfg.prebuffer,0,90,1,1,1);
		buffer_pre_spin=gtk_spin_button_new(GTK_ADJUSTMENT(buffer_pre_adj),1,0);
		gtk_widget_set_usize(buffer_pre_spin,60,-1);
		gtk_box_pack_start(GTK_BOX(buffer_pre_box),buffer_pre_spin,FALSE,FALSE,0);
		gtk_widget_show(buffer_pre_spin);
		gtk_widget_show(buffer_pre_box);


		gtk_widget_show(buffer_table);
		gtk_widget_show(buffer_vbox);
		gtk_widget_show(buffer_frame);
		gtk_notebook_append_page(GTK_NOTEBOOK(notebook),buffer_frame,gtk_label_new("Buffering"));

		gtk_widget_show(notebook);

		bbox=gtk_hbutton_box_new();
		gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
		gtk_button_box_set_spacing(GTK_BUTTON_BOX(bbox),5);
		gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,0);

		ok=gtk_button_new_with_label("Ok");
        	gtk_signal_connect(GTK_OBJECT(ok),"clicked",GTK_SIGNAL_FUNC(configure_win_ok_cb),NULL);
		GTK_WIDGET_SET_FLAGS(ok,GTK_CAN_DEFAULT);
		gtk_box_pack_start(GTK_BOX(bbox),ok,TRUE,TRUE,0);
		gtk_widget_show(ok);
		gtk_widget_grab_default(ok);

		cancel=gtk_button_new_with_label("Cancel");
        	gtk_signal_connect_object(GTK_OBJECT(cancel),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(configure_win));
		GTK_WIDGET_SET_FLAGS(cancel,GTK_CAN_DEFAULT);
		gtk_box_pack_start(GTK_BOX(bbox),cancel,TRUE,TRUE,0);
		gtk_widget_show(cancel);

		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_widget_show(configure_win);
	}
	else
		gdk_window_raise(configure_win->window);
}

