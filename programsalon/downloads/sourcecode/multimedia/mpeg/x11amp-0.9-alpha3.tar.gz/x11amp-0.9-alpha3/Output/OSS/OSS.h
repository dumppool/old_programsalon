/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#ifndef OSS_H
#define OSS_H

#include <gtk/gtk.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#ifdef __FreeBSD__
#include <machine/soundcard.h>
#else
#include <sys/soundcard.h>
#endif

#include <fcntl.h>
#include <pthread.h>

#include <stdlib.h>
#include <stdio.h>

#include "x11amp/plugin.h"
#include "libx11amp/configfile.h"

extern OutputPlugin op;

typedef struct
{
	gint	audio_device;
	gint	mixer_device;
	gint	buffer_size;
	gint	prebuffer;
} OSSConfig;

extern OSSConfig oss_cfg;

void init(void);
void about(void);
void configure(void);

void get_volume(int *l,int *r);
void set_volume(int l,int r);

int abuffer_playing(void);
int abuffer_free(void);
void abuffer_write(void *ptr,int length);
void abuffer_close(void);
void abuffer_flush(int time);
void abuffer_pause(short p);
int abuffer_open(AFormat fmt,int rate,int nch);
int abuffer_get_output_time(void);
int abuffer_get_written_time(void);
void abuffer_set_audio_params(void);
			
#endif
