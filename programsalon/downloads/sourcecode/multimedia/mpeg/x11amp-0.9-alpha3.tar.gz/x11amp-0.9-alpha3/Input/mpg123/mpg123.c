#include "mpg123.h"
#include "libx11amp/configfile.h"
#include <string.h>
#include <pthread.h>



long outscale  = 32768;

static struct frame fr;

PlayerInfo *info=NULL;
pthread_t decode_thread;

gboolean pos=TRUE;

extern int tabsel_123[2][3][16];

static double compute_tpf(struct frame *fr)
{
	static int bs[4] = { 0,384,1152,1152 };
	double tpf;

	tpf = (double) bs[fr->lay];
	tpf /= freqs[fr->sampling_frequency] << (fr->lsf);
	return tpf;
}

	

void set_synth_functions(struct frame *fr)
{
	typedef int (*func)(real *,int,unsigned char *,int *);
	typedef int (*func_mono)(real *,unsigned char *,int *);
	int ds = fr->down_sample;
	int p8=0;

	static func funcs[2][4] = { 
		{ synth_1to1,
		  synth_2to1,
		  synth_4to1,
		  synth_ntom } ,
		{ synth_1to1_8bit,
		  synth_2to1_8bit,
		  synth_4to1_8bit,
		  synth_ntom_8bit } 
	};

	static func_mono funcs_mono[2][2][4] = {    
		{ { synth_1to1_mono2stereo ,
		    synth_2to1_mono2stereo ,
		    synth_4to1_mono2stereo ,
		    synth_ntom_mono2stereo } ,
		  { synth_1to1_8bit_mono2stereo ,
		    synth_2to1_8bit_mono2stereo ,
		    synth_4to1_8bit_mono2stereo ,
		    synth_ntom_8bit_mono2stereo } } ,
		{ { synth_1to1_mono ,
		    synth_2to1_mono ,
		    synth_4to1_mono ,
		    synth_ntom_mono } ,
		  { synth_1to1_8bit_mono ,
		    synth_2to1_8bit_mono ,
		    synth_4to1_8bit_mono ,
		    synth_ntom_8bit_mono } }
	};

	if(mpg123_cfg.resolution == 8)
		p8 = 1;
	fr->synth = funcs[p8][ds];
	fr->synth_mono = funcs_mono[1][p8][ds];

	if(p8) {
		make_conv16to8_table();
	}
}

void init(void)
{
	ConfigFile *cfg;
	gchar *filename;
	
	make_decode_tables(outscale);
	
	mpg123_cfg.resolution=16;
	mpg123_cfg.channels=2;
	mpg123_cfg.downsample=0;
	mpg123_cfg.downsample_custom=44100;
	mpg123_cfg.http_buffer_size=128;
	mpg123_cfg.http_prebuffer=25;
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/config",NULL);
	if(cfg=x11amp_cfg_open_file(filename))
	{
		x11amp_cfg_read_int(cfg,"MPG123","resolution",&mpg123_cfg.resolution);
		x11amp_cfg_read_int(cfg,"MPG123","channels",&mpg123_cfg.channels);
		x11amp_cfg_read_int(cfg,"MPG123","downsample",&mpg123_cfg.downsample);
		/*x11amp_cfg_read_int(cfg,"MPG123","downsample_custom",&mpg123_cfg.downsample_custom);*/
		x11amp_cfg_read_int(cfg,"MPG123","http_buffer_size",&mpg123_cfg.http_buffer_size);
		x11amp_cfg_read_int(cfg,"MPG123","http_prebuffer",&mpg123_cfg.http_prebuffer);
		x11amp_cfg_free(cfg);
	}	
}

int is_our_file(char *filename)
{
	char *ext;
	ext=strrchr(filename,'.');
	if(ext)
		if(!strncasecmp(ext,".mpg",4)||!strncasecmp(ext,".mp2",4)||!strncasecmp(ext,".mp3",4))
			return 1;
	if(!strncasecmp(filename,"http://",7))
		return 1;
	return 0;
}

void play_frame(struct frame *fr)
{
	if (fr->error_protection) 
	{
		getbits(16); /* skip crc */
	}		
	fr->do_layer(fr);
}

struct id3tag {
		char tag[3];
		char title[30];
		char artist[30];
		char album[30];
		char year[4];
		char comment[30];
		unsigned char genre;
	};

char *get_song_title(char *filename)
{
	FILE *file;
	struct id3tag tag;
	char title[31]={0,};
	char artist[31]={0,};
	char album[31]={0,};
	char year[5]={0,};
	char comment[31]={0,};
	char *ret=NULL,*ext;
	
	if(!strncasecmp(filename,"http://",7))
	{
		ret=g_strdup(http_get_title(filename));
	}
	else
	{
		if(file=fopen(filename,"rb"))
		{
			fseek(file,-128,SEEK_END);
			fread(&tag,sizeof(struct id3tag),1,file);
			fclose(file);
			if(!strncmp(tag.tag,"TAG",3))
			{
				strncpy(title,tag.title,30);
				ext=title+strlen(title)-1;
				while(*ext==' ') *(ext--)='\0';
				strncpy(artist,tag.artist,30);
				ext=artist+strlen(artist)-1;
				while(*ext==' ') *(ext--)='\0';
				strncpy(album,tag.album,30);
				ext=album+strlen(album)-1;
				while(*ext==' ') *(ext--)='\0';
				strncpy(year,tag.year,4);
				ext=year+strlen(year)-1;
				while(*ext==' ') *(ext--)='\0';
				strncpy(comment,tag.comment,30);
				ext=comment+strlen(comment)-1;
				while(*ext==' ') *(ext--)='\0';

				ret=(char *)g_malloc(strlen(title)+strlen(artist)+4);
				sprintf(ret,"%s - %s",artist,title);
			}
			else
			{
				ext=strrchr(filename,'/');
				if(!ext) ext=filename;
				else ext++;
				ret=(char *)g_malloc(strlen(ext)+1);
				strcpy(ret,ext);
				ext=strrchr(ret,'.');
				if(ext)
					*ext='\0';
			}
		}
		else
		{
			ext=strrchr(filename,'/');
			if(!ext) ext=filename;
			else ext++;
			ret=(char *)g_malloc(strlen(ext)+1);
			strcpy(ret,ext);
			ext=strrchr(ret,'.');
			if(ext)
				*ext='\0';
		}
	}
	return ret;
}

void *decode_loop(void *arg)
{
	int read_ok;
	char *title,*filename=arg;
	gboolean vbr_set=FALSE;
	gint bitrate;
	pcm_sample=(unsigned char *)g_malloc0(32768);
	pcm_point=0;

	
	info->going=1;
	read_frame_init();
	
	open_stream(filename,-1);
	if(info->eof)
	{
		g_free(info);
		info=NULL;
		return;
	}
	
	if(!read_frame(&fr))
	{
		stream_close();
		g_free(info);
		info=NULL;
		return;
	}
	if(mpg123_cfg.channels==2)
		fr.single=-1;
	else
		fr.single=3;
	
	fr.down_sample=mpg123_cfg.downsample;
	fr.down_sample_sblimit=SBLIMIT>>mpg123_cfg.downsample;
	set_synth_functions(&fr);
	init_layer3(fr.down_sample_sblimit);
	
	
	info->frame_num=1;
	info->tpf=compute_tpf(&fr);
	if(strncasecmp(filename,"http://",7))
		info->num_frames=calc_numframes(&fr);
	else
		info->num_frames=-1;
	info->jump_to_frame=-1;
	title=get_song_title(filename);
	if(strncasecmp(filename,"http://",7))
		ip.set_info(title,info->num_frames*info->tpf*1000,tabsel_123[fr.lsf][fr.lay-1][fr.bitrate_index]*1000,freqs[fr.sampling_frequency],fr.stereo);
	else
		ip.set_info(title,-1,tabsel_123[fr.lsf][fr.lay-1][fr.bitrate_index]*1000,freqs[fr.sampling_frequency],fr.stereo);

	bitrate=tabsel_123[fr.lsf][fr.lay-1][fr.bitrate_index];
	
	
	if(!ip.output->open_audio(mpg123_cfg.resolution==16?FMT_S16_NE:FMT_U8,
			          freqs[fr.sampling_frequency]>>mpg123_cfg.downsample,
			          mpg123_cfg.channels==2?fr.stereo:1))
	{
		fprintf(stderr,"Couldn't open audio!\n");
		info->eof=TRUE;
	}
	else
		play_frame(&fr);
	
	/*
	 * We don't want to output the first frame since it will be fucked up if the previous
	 * mp3 file didn't play to finish and I don't have the time to fix it properly
	 */
	
	info->output_audio=TRUE;
	
	while(info->going)
	{
		if(info->jump_to_frame!=-1)
		{
			stream_jump_to_frame(&fr,info->jump_to_frame);
			info->frame_num=info->jump_to_frame;
			ip.output->flush(info->frame_num*info->tpf*1000);
			info->jump_to_frame=-1;
		}
		if(!info->eof)
		{
			if(read_ok=read_frame(&fr))
			{
				if(bitrate!=tabsel_123[fr.lsf][fr.lay-1][fr.bitrate_index]&&!vbr_set)
				{
					ip.set_info(title,-1,-1,freqs[fr.sampling_frequency],fr.stereo);
					vbr_set=TRUE;
				}
				play_frame(&fr);		
				info->output_audio=TRUE;
				info->frame_num++;
			}
			else
				usleep(10000);
		}
		else
			usleep(10000);
		if(!ip.output->buffer_playing()&&!read_ok)
			info->eof=1;

	}
	g_free(title);
	stream_close();
	ip.output->close_audio();
	g_free(pcm_sample);
	pthread_exit(NULL);
}

void play_file(char *filename)
{
	memset(&fr,0,sizeof(struct frame));
	
	
		
	info=g_malloc0(sizeof(PlayerInfo));
	info->going=1;
	
	pos=TRUE;	
	pthread_create(&decode_thread,NULL,decode_loop,filename);
}

void stop(void)
{
	if(info)
	{
		if(info->going)
		{
			info->going=0;
			pthread_join(decode_thread,NULL);
			g_free(info);
			info=NULL;
		}
	}
}

void seek(int time)
{
	info->output_audio=FALSE;
	info->jump_to_frame=(int)(time/info->tpf),info->num_frames;
	while(info->jump_to_frame!=-1) usleep(10000);
}

void do_pause(short p)
{
	ip.output->pause(p);
}

int get_time(void)
{
	if(!info)
		return -1;
	if(!info->going||info->eof)
		return -1;
	return ip.output->output_time();
}

InputPlugin ip=
{
	NULL,
	NULL,
	"MPEG Layer 1/2/3 Player",
	init,
	NULL,
	configure,
	is_our_file,
	play_file,
	stop,
	do_pause,
	seek,
	set_eq,
	get_time,
	NULL,NULL,NULL,NULL,NULL,
	NULL
};		

InputPlugin *get_iplugin_info(void)
{
	return &ip;
}
