/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <netdb.h>
#include <glib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>

#include <pthread.h>

#include "mpg123.h"
#define min(x,y) (x)<(y)?(x):(y)
#define min3(x,y,z) min(x,y)<(z)?min(x,y):(z)

gchar *icy_name=NULL;

static gboolean prebuffering,going,eof=FALSE;
static gint sock,rd_index,wr_index,buffer_length,prebuffer_length,buffer_used;
static gchar *buffer;
static pthread_t thread;


static void parse_url(gchar *url,gchar **user,gchar **pass,gchar **host,int *port,gchar **filename)
{
	gchar *h,*p,*pt,*f;
	if(!strncasecmp("http://",url,7))
		url+=7;
	if(h=strchr(url,'@'))
	{
		*h='\0';
		if(p=strchr(url,':'))
		{
			*p='\0';
			p++;
			*pass=g_strdup(p);
		}
		else
			*pass=NULL;
		*user=g_strdup(url);
		h++;
		url=h;
	}
	else
		h=url;
	if(pt=strchr(url,':'))
	{
		*pt='\0';
		pt++;
		if(f=strchr(pt,'/'))
		{
			*f='\0';
			f++;
		}
		else
			f=NULL;
		*port=atoi(pt);
	}
	else
	{
		*port=80;
		if(f=strchr(h,'/'))
		{
			*f='\0';
			f++;
		}
		else
			f=NULL;
	}
	*host=g_strdup(h);
	if(f)
		*filename=g_strdup(f);
	else
		*filename=NULL;
}

void http_close(void)
{
	going=FALSE;
	pthread_join(thread,NULL);
	if(icy_name)
		g_free(icy_name);
	icy_name=NULL;
	
}

int http_read(gpointer data,gint length)
{
	gint len,cnt,off=0;
	while((prebuffering||buffer_used<length)&&!eof&&info->going)
	{
		if(!prebuffering&&!ip.output->buffer_playing())
			prebuffering=TRUE;
		usleep(10000);
	}
	if(!info->going)
		return 0;
	len=length;

	while(len&&buffer_used)
	{
		cnt=min3(len,buffer_length-rd_index,buffer_used);
		memcpy(data+off,buffer+rd_index,cnt);
		rd_index=(rd_index+cnt)%buffer_length;
		buffer_used-=cnt;
		len-=cnt;
		off+=cnt;
	}
	return off;
}

gint http_read_line(gchar *buf,gint size)
{
	gint i=0;
	
	while(going&&i<size-1)
	{
		if(http_check_for_data())
		{
			if(read(sock,buf+i,1)<=0)
				return -1;
			if(buf[i]=='\n')
				break;
			if(buf[i]!='\r')
				i++;
		}
	}
	if(!going)
		return -1;
	buf[i]='\0';
	return i;	
}

gboolean http_check_for_data(void)
{
	
	fd_set set;
	struct timeval tv;
	gint ret;
	
	tv.tv_sec=0;
	tv.tv_usec=10000;
	FD_ZERO(&set);
	FD_SET(sock,&set);
	ret=select(sock+1,&set,NULL,NULL,&tv);
	if(ret>0)
		return TRUE;
	return FALSE;
}


void *http_buffer_loop(void *arg)
{
	gchar line[1024],*user,*pass,*host,*filename,*status,*url=arg;
	gint cnt,length,written,off=0,error,err_len;
	fd_set set;
	gint port,len;
	struct hostent *hp;
	struct sockaddr_in address;
	struct timeval tv;
	
	parse_url(url,&user,&pass,&host,&port,&filename);
	sock=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	fcntl(sock,F_SETFL,O_NONBLOCK);
	address.sin_family=AF_INET;
	g_free(url);
	
	status=g_malloc(strlen(host)+12);
	sprintf(status,"LOOKING UP %s",host);
	ip.set_info_text(status);
	g_free(status);
	
	if(!(hp=gethostbyname(host)))
	{
		ip.set_info_text(NULL);
		eof=TRUE;
	}
	
	if(!eof)
	{
		memcpy(&address.sin_addr.s_addr,*(hp->h_addr_list),sizeof(address.sin_addr.s_addr));
		address.sin_port=htons(port);

		status=g_malloc(strlen(host)+50);
		g_snprintf(status,strlen(host)+50,"CONNECTING TO %s:%d",host,port);
		ip.set_info_text(status);
		g_free(status);
		if(connect(sock,(struct sockaddr *)&address,sizeof(struct sockaddr_in))==-1)
		{
			if(errno!=EINPROGRESS)
			{
				ip.set_info_text(NULL);
				eof=TRUE;
			}
		}
		while(going)
		{
			tv.tv_sec=0;
			tv.tv_usec=10000;
			FD_ZERO(&set);
			FD_SET(sock,&set);
			if(select(sock+1,NULL,&set,NULL,&tv)>0)
			{
				err_len=sizeof(error);
				getsockopt(sock,SOL_SOCKET,SO_ERROR,&error,&err_len);
				if(error)
				{
					ip.set_info_text(NULL);
					eof=TRUE;
				}
				break;
			}
		}
		if(!eof)
		{
			write(sock,"GET ",4);
			write(sock,"/",1);
			if(filename)
				write(sock,filename,strlen(filename));
			write(sock," HTTP/1.0\n\n",11);
			ip.set_info_text("CONNECTED: WAITING FOR REPLY");
			while(going&&!eof)
			{
				if(http_check_for_data())
				{
					if(http_read_line(line,1024))
					{
						status=strchr(line,' ');
						if(status)
						{
							if(status[1]=='2')
								break;
							else
							{
								eof=TRUE;
								ip.set_info_text(NULL);
								break;
							}
						}
					}
					else
					{
						eof=TRUE;
						ip.set_info_text(NULL);
					}
				}
			}
								
			while(going)
			{
				if(http_check_for_data())
				{
					if((cnt=http_read_line(line,1024))!=-1)
					{
						if(!cnt)
							break;
						if(!strncmp(line,"icy-name:",9))
							icy_name=g_strdup(line+9);
					}
					else
					{
						eof=TRUE;
						ip.set_info_text(NULL);
						break;
					}
				}
			}
		}
	}
	while(going)	
	{
				
		if((buffer_length-buffer_used)>0&&!eof)
		{
			if(http_check_for_data())
			{
				cnt=min(buffer_length-buffer_used,buffer_length-wr_index);
				if(cnt>1024)
					cnt=1024;
				written=read(sock,buffer+wr_index,cnt);
				if(written<=0)
				{
					eof=TRUE;
					if(prebuffering)
					{
						prebuffering=FALSE;
						ip.set_info_text(NULL);
					}
				}
				else
				{
					wr_index=(wr_index+written)%buffer_length;
					buffer_used+=written;
				}
				
			}
			
			
			if(prebuffering)
			{
				if(buffer_used>prebuffer_length)
				{
					prebuffering=FALSE;
					ip.set_info_text(NULL);
				}
				else
				{
					g_snprintf(line,1024,"PRE-BUFFERING: %dKB/%dKB",buffer_used/1024,prebuffer_length/1024);
					ip.set_info_text(line);
				}
					
			}
		}
		else
			usleep(10000);
		
	}
	close(sock);
	g_free(buffer);
	pthread_exit(NULL);
}

		
		
		
	
int http_open(gchar *_url)
{
	gchar *url;
	
	url=g_strdup(_url);
	
	rd_index=0;
	wr_index=0;
	buffer_length=mpg123_cfg.http_buffer_size*1024;
	prebuffer_length=(buffer_length*mpg123_cfg.http_prebuffer)/100;
	buffer_used=0;
	prebuffering=TRUE;
	going=TRUE;
	eof=FALSE;
	buffer=g_malloc(buffer_length);
	
	pthread_create(&thread,NULL,http_buffer_loop,url);
	
	
	return 0;
}

gchar *http_get_title(gchar *url)
{
	if(icy_name)
		return icy_name;
	return url;
}
