/*      MikMod sound library
   (c) 1998 Miodrag Vallat and others - see file AUTHORS for complete list

   This library is free software; you can redistribute it and/or modify
   it under the terms of the GNU Library General Public License as
   published by the Free Software Foundation; either version 2 of
   the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*==============================================================================

  $Id: mmerror.c,v 1.2 1999/02/09 00:19:58 x11amp Exp $

  Error handling functions for use with the MMIO and MikMod libraries.
  Register an error handler with _mm_RegisterErrorHandler() and you're all set.

==============================================================================*/

/*

   The global variables _mm_errno, and _mm_critical are set before the error
   handler in called.  See below for the values of these variables.

 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <mikmod_internals.h>

CHAR *_mm_errmsg[MMERR_MAX + 1] =
{
/* No error */

  "No error",

/* Generic errors */

  "Could not open requested file",
  "Out of memory",

/* Sample errors */

  "Out of memory to load sample",
  "Out of sample handles to load sample",
  "Sample format not recognized",

/* Module errors */

  "Failure loading module pattern",
  "Failure loading module track",
  "Failure loading module header",
  "Failure loading sampleinfo",
  "Module format not recognized",
  "Module sample format not recognized",
  "Synthsounds not supported in MED files",
  "Compressed sample is invalid",

/* Driver errors: */

  "Sound device not detected",
  "Device number out of range",
  "Software mixer failure",
  "Could not open sound device",
  "This driver supports 16 bit linear output only",
  "Unable to set non-blocking mode for audio device",

/* AudioFile driver errors  */

  "Cannot find suitable AudioFile audio port",

/* AIX driver errors */

  "Configuration (init step)of audio device failed",
  "Configuration (control step) of audio device failed",
  "Configuration (start step) of audio device failed",

/* ALSA driver errors */

/* EsounD driver errors */

/* HP driver errors  */

  "Unable to select 16bit-linear sample format",
  "Could not select requested sample-rate",
  "Could not select requested number of channels",
  "Unable to select audio output",
  "Unable to get audio description",
  "Unable to get gain values",
  "Unable to set gain values",
  "Could not set transmission buffer size",

/* Open Sound System driver errors */

  "Could not set fragment size",
  "Could not set sample size",
  "Could not set mono/stereo setting",
  "Could not set sample rate",

/* SGI driver errors */

  "Unsupported sample rate",
  "Hardware does not support 16 bit sound",
  "Hardware does not support 8 bit sound",
  "Hardware does not support stereo sound",
  "Hardware does not support mono sound",

/* Sun driver errors */

  "Sound device initialization failed",
  "16 bit sound is not supported with uLaw encoding",

/* OS/2 drivers errors */

  "Could not set mixing parameters",
  "Could not create playback semaphores",
  "Could not create playback timer",
  "Could not create playback thread",

/* Invalid error */

  "Invalid error code"
};

char *
MikMod_strerror (int code)
{
  if ((code < 0) || (code > MMERR_MAX))
    code = MMERR_MAX + 1;
  return _mm_errmsg[code];
}

/* User installed error callback */
MikMod_handler_t _mm_errorhandler = NULL;
int _mm_errno = 0;
BOOL _mm_critical = 0;

MikMod_handler_t 
MikMod_RegisterErrorHandler (MikMod_handler_t proc)
{
  MikMod_handler_t oldproc = _mm_errorhandler;

  _mm_errorhandler = proc;
  return oldproc;
}
