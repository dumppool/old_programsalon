#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include <pthread.h>
#include <gtk/gtk.h>
#include "x11amp/plugin.h"
#include "mikmod.h"
#include "mikmod_internals.h"
#include "mikmod.xpm"
#ifdef __EMX__
#define PATH_MAX _POSIX_PATH_MAX
#endif

#define FREQ_SAMPLE_44 0
#define FREQ_SAMPLE_22 1
#define FREQ_SAMPLE_11 2

static void init (void);
static int is_our_file (char *filename);
extern InputPlugin mikmod_ip;
static void play_file (char *filename);
static int get_time (void);
static void stop (void);
void about_ok (GtkWidget * widget, gpointer data);
static void *play_loop (void *arg);
static void mod_pause (short p);
static void seek (int time);
static void aboutbox (void);

typedef struct
  {
    gint mixing_freq;
    gint volumefadeout;
    gint surround;
    gint force8bit;
    gint hidden_pattrens;
    gint force_mono;
  }
MIKMODConfig;

extern MIKMODConfig mikmod_cfg;

static void configure ();
void config_ok (GtkWidget * widget, gpointer data);
void tb_set_state (GtkToggleButton * tb, gboolean state);
