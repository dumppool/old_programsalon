#include "mpg123.h"
#include "libx11amp/configfile.h"

static GtkWidget *configurewin=NULL;
static GtkWidget *vbox,*notebook;
static GtkWidget *decode_vbox,*decode_hbox1;
static GtkWidget *decode_res_frame,*decode_res_vbox,*decode_res_16,*decode_res_8;
static GtkWidget *decode_ch_frame,*decode_ch_vbox,*decode_ch_stereo,*decode_ch_mono;
static GtkWidget *decode_freq_frame,*decode_freq_vbox,*decode_freq_1to1,*decode_freq_1to2,*decode_freq_1to4,*decode_freq_custom;
static GtkWidget *decode_freq_custom_hbox,*decode_freq_custom_spin,*decode_freq_custom_label;
static GtkObject *decode_freq_custom_adj;
static GtkWidget *streaming_frame,*streaming_vbox,*streaming_table;
static GtkWidget *streaming_size_box,*streaming_size_label,*streaming_size_spin;
static GtkObject *streaming_size_adj;
static GtkWidget *streaming_pre_box,*streaming_pre_label,*streaming_pre_spin;
static GtkObject *streaming_pre_adj;
static GtkWidget *bbox,*ok,*cancel;

MPG123Config mpg123_cfg;

void configurewin_ok(GtkWidget *widget,gpointer data)
{
	ConfigFile *cfg;
	gchar *filename;
	
	if(GTK_TOGGLE_BUTTON(decode_res_16)->active)
		mpg123_cfg.resolution=16;
	else if(GTK_TOGGLE_BUTTON(decode_res_8)->active)
		mpg123_cfg.resolution=8;
	
	if(GTK_TOGGLE_BUTTON(decode_ch_stereo)->active)
		mpg123_cfg.channels=2;
	else if(GTK_TOGGLE_BUTTON(decode_ch_mono)->active)
		mpg123_cfg.channels=1;
	
	if(GTK_TOGGLE_BUTTON(decode_freq_1to1)->active)
		mpg123_cfg.downsample=0;
	else if(GTK_TOGGLE_BUTTON(decode_freq_1to2)->active)
		mpg123_cfg.downsample=1;
	if(GTK_TOGGLE_BUTTON(decode_freq_1to4)->active)
		mpg123_cfg.downsample=2;
/*	if(GTK_TOGGLE_BUTTON(decode_freq_custom)->active)
		mpg123_cfg.downsample=3;
	mpg123_cfg.downsample_custom=(gint)GTK_ADJUSTMENT(decode_freq_custom_adj)->value;*/
	
	mpg123_cfg.http_buffer_size=(gint)GTK_ADJUSTMENT(streaming_size_adj)->value;
	mpg123_cfg.http_prebuffer=(gint)GTK_ADJUSTMENT(streaming_pre_adj)->value;
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/config",NULL);
	cfg=x11amp_cfg_open_file(filename);
	if(!cfg)
		cfg=x11amp_cfg_new();
	x11amp_cfg_write_int(cfg,"MPG123","resolution",mpg123_cfg.resolution);
	x11amp_cfg_write_int(cfg,"MPG123","channels",mpg123_cfg.channels);
	x11amp_cfg_write_int(cfg,"MPG123","downsample",mpg123_cfg.downsample);
/*	x11amp_cfg_write_int(cfg,"MPG123","downsample_custom",mpg123_cfg.downsample_custom);*/
	x11amp_cfg_write_int(cfg,"MPG123","http_buffer_size",mpg123_cfg.http_buffer_size);
	x11amp_cfg_write_int(cfg,"MPG123","http_prebuffer",mpg123_cfg.http_prebuffer);
	x11amp_cfg_write_file(cfg,filename);
	x11amp_cfg_free(cfg);
	g_free(filename);
	gtk_widget_destroy(configurewin);
}

void tb_set_state(GtkToggleButton *tb,gboolean state)
{
#if (GTK_MAJOR_VERSION==1) && (GTK_MINOR_VERSION==1) && (GTK_MICRO_VERSION<=12)
	gtk_toggle_button_set_state(tb,state);
#else
	gtk_toggle_button_set_active(tb,state);
#endif
}

void configure(void)
{
	if(!configurewin)
	{
		configurewin=gtk_window_new(GTK_WINDOW_DIALOG);
		gtk_signal_connect(GTK_OBJECT(configurewin),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&configurewin);
		gtk_window_set_title(GTK_WINDOW(configurewin),"MPG123 Configuration");
		gtk_window_set_policy(GTK_WINDOW(configurewin), FALSE,FALSE,FALSE);
		gtk_window_set_position(GTK_WINDOW(configurewin),GTK_WIN_POS_MOUSE);
		gtk_container_border_width(GTK_CONTAINER(configurewin),10);
		
		vbox=gtk_vbox_new(FALSE,10);
		gtk_container_add(GTK_CONTAINER(configurewin),vbox);
		
		notebook=gtk_notebook_new();
		gtk_box_pack_start(GTK_BOX(vbox),notebook,TRUE,TRUE,0);
		
		decode_vbox=gtk_vbox_new(FALSE,5);
		gtk_container_set_border_width(GTK_CONTAINER(decode_vbox),5);
		
		decode_hbox1=gtk_hbox_new(TRUE,5);
		gtk_box_pack_start(GTK_BOX(decode_vbox),decode_hbox1,FALSE,FALSE,0);
		
		decode_res_frame=gtk_frame_new("Resolution:");
		gtk_box_pack_start(GTK_BOX(decode_hbox1),decode_res_frame,TRUE,TRUE,0);
		
		decode_res_vbox=gtk_vbox_new(FALSE,5);
		gtk_container_set_border_width(GTK_CONTAINER(decode_res_vbox),5);
		gtk_container_add(GTK_CONTAINER(decode_res_frame),decode_res_vbox);
		
		decode_res_16=gtk_radio_button_new_with_label(NULL,"16 bit");
		if(mpg123_cfg.resolution==16)
			tb_set_state(GTK_TOGGLE_BUTTON(decode_res_16),TRUE);
		gtk_box_pack_start(GTK_BOX(decode_res_vbox),decode_res_16,FALSE,FALSE,0);
		gtk_widget_show(decode_res_16);
		
		decode_res_8=gtk_radio_button_new_with_label(gtk_radio_button_group(GTK_RADIO_BUTTON(decode_res_16)),"8 bit");
		if(mpg123_cfg.resolution==8)
			tb_set_state(GTK_TOGGLE_BUTTON(decode_res_8),TRUE);

		gtk_box_pack_start(GTK_BOX(decode_res_vbox),decode_res_8,FALSE,FALSE,0);
		gtk_widget_show(decode_res_8);
		gtk_widget_show(decode_res_vbox);
		gtk_widget_show(decode_res_frame);
		
		decode_ch_frame=gtk_frame_new("Channels:");
		gtk_box_pack_start(GTK_BOX(decode_hbox1),decode_ch_frame,TRUE,TRUE,0);
		
		decode_ch_vbox=gtk_vbox_new(FALSE,5);
		gtk_container_set_border_width(GTK_CONTAINER(decode_ch_vbox),5);
		gtk_container_add(GTK_CONTAINER(decode_ch_frame),decode_ch_vbox);
		
		decode_ch_stereo=gtk_radio_button_new_with_label(NULL,"Stereo (if available)");
		if(mpg123_cfg.channels==2)
			tb_set_state(GTK_TOGGLE_BUTTON(decode_ch_stereo),TRUE);

		gtk_box_pack_start(GTK_BOX(decode_ch_vbox),decode_ch_stereo,FALSE,FALSE,0);
		gtk_widget_show(decode_ch_stereo);
		
		decode_ch_mono=gtk_radio_button_new_with_label(gtk_radio_button_group(GTK_RADIO_BUTTON(decode_ch_stereo)),"Mono");
		if(mpg123_cfg.channels==1)
			tb_set_state(GTK_TOGGLE_BUTTON(decode_ch_mono),TRUE);

		gtk_box_pack_start(GTK_BOX(decode_ch_vbox),decode_ch_mono,FALSE,FALSE,0);
		gtk_widget_show(decode_ch_mono);
		
		gtk_widget_show(decode_ch_vbox);
		gtk_widget_show(decode_ch_frame);
		gtk_widget_show(decode_hbox1);
		
		decode_freq_frame=gtk_frame_new("Down sample:");
		gtk_box_pack_start(GTK_BOX(decode_vbox),decode_freq_frame,FALSE,FALSE,0);
		
		decode_freq_vbox=gtk_vbox_new(FALSE,5);
		gtk_container_set_border_width(GTK_CONTAINER(decode_freq_vbox),5);
		gtk_container_add(GTK_CONTAINER(decode_freq_frame),decode_freq_vbox);
		
		decode_freq_1to1=gtk_radio_button_new_with_label(NULL,"1:1 (44 kHz)");
		if(mpg123_cfg.downsample==0)
			tb_set_state(GTK_TOGGLE_BUTTON(decode_freq_1to1),TRUE);
		gtk_box_pack_start(GTK_BOX(decode_freq_vbox),decode_freq_1to1,FALSE,FALSE,0);
		gtk_widget_show(decode_freq_1to1);
		
		decode_freq_1to2=gtk_radio_button_new_with_label(gtk_radio_button_group(GTK_RADIO_BUTTON(decode_freq_1to1)),"1:2 (22 kHz)");
		if(mpg123_cfg.downsample==1)
			tb_set_state(GTK_TOGGLE_BUTTON(decode_freq_1to2),TRUE);
		gtk_box_pack_start(GTK_BOX(decode_freq_vbox),decode_freq_1to2,FALSE,FALSE,0);
		gtk_widget_show(decode_freq_1to2);
		
		decode_freq_1to4=gtk_radio_button_new_with_label(gtk_radio_button_group(GTK_RADIO_BUTTON(decode_freq_1to1)),"1:4 (11 kHz)");
		if(mpg123_cfg.downsample==2)
			tb_set_state(GTK_TOGGLE_BUTTON(decode_freq_1to4),TRUE);

		gtk_box_pack_start(GTK_BOX(decode_freq_vbox),decode_freq_1to4,FALSE,FALSE,0);
		gtk_widget_show(decode_freq_1to4);
		
		/*decode_freq_custom_hbox=gtk_hbox_new(FALSE,5);
		gtk_box_pack_start(GTK_BOX(decode_freq_vbox),decode_freq_custom_hbox,FALSE,FALSE,0);
		
		decode_freq_custom=gtk_radio_button_new_with_label(gtk_radio_button_group(GTK_RADIO_BUTTON(decode_freq_1to1)),"Custom");
		if(mpg123_cfg.downsample==3)
			tb_set_state(GTK_TOGGLE_BUTTON(decode_freq_custom),TRUE);
		gtk_box_pack_start(GTK_BOX(decode_freq_custom_hbox),decode_freq_custom,FALSE,FALSE,0);
		gtk_widget_show(decode_freq_custom);
		
		
		decode_freq_custom_adj=gtk_adjustment_new(mpg123_cfg.downsample_custom,8000,48000,25,25,25);
		decode_freq_custom_spin=gtk_spin_button_new(GTK_ADJUSTMENT(decode_freq_custom_adj),25,0);
		gtk_widget_set_usize(decode_freq_custom_spin,60,-1);
		gtk_box_pack_start(GTK_BOX(decode_freq_custom_hbox),decode_freq_custom_spin,FALSE,FALSE,0);
		gtk_widget_show(decode_freq_custom_spin);
		
		decode_freq_custom_label=gtk_label_new("Hz");
		gtk_box_pack_start(GTK_BOX(decode_freq_custom_hbox),decode_freq_custom_label,FALSE,FALSE,0);
		gtk_widget_show(decode_freq_custom_label);
		
		gtk_widget_show(decode_freq_custom_hbox);*/
		
		
		gtk_widget_show(decode_freq_vbox);
		gtk_widget_show(decode_freq_frame);

		

		gtk_widget_show(decode_vbox);
		gtk_notebook_append_page(GTK_NOTEBOOK(notebook),decode_vbox,gtk_label_new("Decoder"));	
		
		streaming_frame=gtk_frame_new("Buffering:");
		gtk_container_set_border_width(GTK_CONTAINER(streaming_frame),5);

		streaming_vbox=gtk_vbox_new(FALSE,0);
		gtk_container_add(GTK_CONTAINER(streaming_frame),streaming_vbox);

		streaming_table=gtk_table_new(2,1,TRUE);
		gtk_container_set_border_width(GTK_CONTAINER(streaming_table),5);
		gtk_box_pack_start(GTK_BOX(streaming_vbox),streaming_table,FALSE,FALSE,0);

		streaming_size_box=gtk_hbox_new(FALSE,5);
		gtk_table_attach_defaults(GTK_TABLE(streaming_table),streaming_size_box,0,1,0,1);
		streaming_size_label=gtk_label_new("Buffer size (kb):");
		gtk_box_pack_start(GTK_BOX(streaming_size_box),streaming_size_label,FALSE,FALSE,0);
		gtk_widget_show(streaming_size_label);
		streaming_size_adj=gtk_adjustment_new(mpg123_cfg.http_buffer_size,4,4096,4,4,4);
		streaming_size_spin=gtk_spin_button_new(GTK_ADJUSTMENT(streaming_size_adj),8,0);
		gtk_widget_set_usize(streaming_size_spin,60,-1);
		gtk_box_pack_start(GTK_BOX(streaming_size_box),streaming_size_spin,FALSE,FALSE,0);
		gtk_widget_show(streaming_size_spin);
		gtk_widget_show(streaming_size_box);

		streaming_pre_box=gtk_hbox_new(FALSE,5);
		gtk_table_attach_defaults(GTK_TABLE(streaming_table),streaming_pre_box,1,2,0,1);
		streaming_pre_label=gtk_label_new("Pre-buffer (percent):");
		gtk_box_pack_start(GTK_BOX(streaming_pre_box),streaming_pre_label,FALSE,FALSE,0);
		gtk_widget_show(streaming_pre_label);
		streaming_pre_adj=gtk_adjustment_new(mpg123_cfg.http_prebuffer,0,90,1,1,1);
		streaming_pre_spin=gtk_spin_button_new(GTK_ADJUSTMENT(streaming_pre_adj),1,0);
		gtk_widget_set_usize(streaming_pre_spin,60,-1);
		gtk_box_pack_start(GTK_BOX(streaming_pre_box),streaming_pre_spin,FALSE,FALSE,0);
		gtk_widget_show(streaming_pre_spin);
		gtk_widget_show(streaming_pre_box);


		gtk_widget_show(streaming_table);
		gtk_widget_show(streaming_vbox);
		gtk_widget_show(streaming_frame);
		gtk_notebook_append_page(GTK_NOTEBOOK(notebook),streaming_frame,gtk_label_new("Streaming"));

			
		gtk_widget_show(notebook);
		
		bbox=gtk_hbutton_box_new();
		gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
		gtk_button_box_set_spacing(GTK_BUTTON_BOX(bbox),5);
		gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,0);
		
		ok=gtk_button_new_with_label("Ok");
		gtk_signal_connect(GTK_OBJECT(ok),"clicked",GTK_SIGNAL_FUNC(configurewin_ok),NULL);
		GTK_WIDGET_SET_FLAGS(ok,GTK_CAN_DEFAULT);
		gtk_box_pack_start(GTK_BOX(bbox),ok,TRUE,TRUE,0);
		gtk_widget_show(ok);
		gtk_widget_grab_default(ok);
		
		cancel=gtk_button_new_with_label("Cancel");
		gtk_signal_connect_object(GTK_OBJECT(cancel),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(configurewin));
		GTK_WIDGET_SET_FLAGS(cancel,GTK_CAN_DEFAULT);
		gtk_box_pack_start(GTK_BOX(bbox),cancel,TRUE,TRUE,0);
		gtk_widget_show(cancel);
		
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_widget_show(configurewin);
	}
	else
		gdk_window_raise(configurewin->window);
}
