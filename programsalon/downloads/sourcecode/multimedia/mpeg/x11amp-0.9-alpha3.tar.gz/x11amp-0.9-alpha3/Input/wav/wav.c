/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "wav.h"

InputPlugin wav_ip=
{
	NULL,
	NULL,
	"Wave Player 0.9",
	wav_init,
	NULL,
	NULL,
	is_our_file,
	play_file,
	stop,
	wav_pause,
	seek,
	NULL,
	get_time,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
};
	
WaveFile *wav_file=NULL;
pthread_t decode_thread;
	
InputPlugin *get_iplugin_info(void)
{
	return &wav_ip;
}

void wav_init(void)
{
}

static int is_our_file(char *filename)
{
	char *ext;
	ext=strrchr(filename,'.');
	if(ext)
	{
		if(!strcasecmp(ext,".wav"))
			return 1;
	}
	return 0;
}

static int read_le_long(FILE *file,long *ret)
{
	unsigned char buf[4];
	
	if(fread(buf,1,4,file)!=4)
		return 0;
	
	*ret=(buf[3]<<24)|(buf[2]<<16)|(buf[1]<<8)|buf[0];
}
	
static int read_le_short(FILE *file,short *ret)
{
	unsigned char buf[2];
	
	if(fread(buf,1,2,file)!=2)
		return 0;
	
	*ret=(buf[1]<<8)|buf[0];
}

static void *play_loop(void *arg)
{
	char data[2048];
	int bytes,blk_size,rate;
	
	
	blk_size=512*(wav_file->bits_per_sample/8)*wav_file->channels;
	rate=wav_file->samples_per_sec*wav_file->channels*(wav_file->bits_per_sample/8);
	while(wav_file->going)
	{
		bytes=blk_size;
		if(wav_file->length-wav_file->position<bytes) 
			bytes=wav_file->length-wav_file->position;
		if(wav_ip.output->buffer_free()>=bytes&&bytes)
		{

			fread(data,1,bytes,wav_file->file);
			wav_ip.add_vis_pcm(wav_ip.output->written_time(),(wav_file->bits_per_sample==16)?FMT_S16_LE:FMT_U8,
				       wav_file->channels,bytes,data);
			wav_ip.output->write_audio(data,bytes);
			wav_file->position+=bytes;
		}
		else
			usleep(10000);
		if(wav_file->seek_to!=-1)
		{
			wav_file->position=wav_file->seek_to*rate;
			fseek(wav_file->file,wav_file->position+wav_file->data_offset,SEEK_SET);
			wav_ip.output->flush(wav_file->seek_to*1000);
			wav_file->seek_to=-1;
		}

		if(!wav_ip.output->buffer_playing()&&wav_file->position==wav_file->length)
			wav_file->eof=1;
	}
	fclose(wav_file->file);
	pthread_exit(NULL);
}

static void play_file(char *filename)
{
	char magic[4],*name,*temp;
	unsigned long len;
	int rate;
	
	wav_file=malloc(sizeof(WaveFile));
	memset(wav_file,0,sizeof(WaveFile));
	if(wav_file->file=fopen(filename,"rb"))
	{
		fread(magic,1,4,wav_file->file);
		if(strncmp(magic,"RIFF",4))
		{
			fclose(wav_file->file);
			free(wav_file);
			wav_file=NULL;
			return;
		}
		read_le_long(wav_file->file,&len);
		fread(magic,1,4,wav_file->file);
		if(strncmp(magic,"WAVE",4))
		{
			fclose(wav_file->file);
			free(wav_file);
			wav_file=NULL;
			return;
		}
		for(;;)
		{
			fread(magic,1,4,wav_file->file);
			if(!read_le_long(wav_file->file,&len))
			{
				fclose(wav_file->file);
				free(wav_file);
				wav_file=NULL;
				return;
			}
			if(!strncmp("fmt ",magic,4))
				break;
			fseek(wav_file->file,len,SEEK_CUR);
		}
		if(len<16)
		{
			fclose(wav_file->file);
			free(wav_file);
			wav_file=NULL;
			return;
		}
		read_le_short(wav_file->file,&wav_file->format_tag);
		switch(wav_file->format_tag)
		{
			case	WAVE_FORMAT_UNKNOWN:
			case	WAVE_FORMAT_ALAW:
			case	WAVE_FORMAT_MULAW:
			case	WAVE_FORMAT_ADPCM:
			case	WAVE_FORMAT_OKI_ADPCM:
			case	WAVE_FORMAT_DIGISTD:
			case	WAVE_FORMAT_DIGIFIX:
			case	IBM_FORMAT_MULAW:
			case	IBM_FORMAT_ALAW:
			case	IBM_FORMAT_ADPCM:
				fclose(wav_file->file);
				free(wav_file);
				wav_file=NULL;	
				return;
		}
		read_le_short(wav_file->file,&wav_file->channels);	
		read_le_long(wav_file->file,&wav_file->samples_per_sec);
		read_le_long(wav_file->file,&wav_file->avg_bytes_per_sec);
		read_le_short(wav_file->file,&wav_file->block_align);
		read_le_short(wav_file->file,&wav_file->bits_per_sample);
		if(wav_file->bits_per_sample!=8&&wav_file->bits_per_sample!=16)
		{
			free(wav_file);
			wav_file=NULL;	
			fclose(wav_file->file);
			return;
		}
		len-=16;
		if(len) fseek(wav_file->file,len,SEEK_CUR);
		
		for(;;)
		{
			fread(magic,4,1,wav_file->file);
			
			if(!read_le_long(wav_file->file,&len))
			{
				fclose(wav_file->file);
				free(wav_file);
				wav_file=NULL;
				return;
			}
			if(!strncmp("data",magic,4))
				break;
			fseek(wav_file->file,len,SEEK_CUR);
		}	
		wav_file->data_offset=ftell(wav_file->file);
		wav_file->length=len;
		
		
		
		wav_file->position=0;
		wav_file->going=1;
			
		if(wav_ip.output->open_audio((wav_file->bits_per_sample==16)?FMT_S16_LE:FMT_U8,wav_file->samples_per_sec,wav_file->channels)==0)
		{
			fprintf(stderr,"Couldn't open audio!\n");
			fclose(wav_file->file);
			free(wav_file);
			wav_file=NULL;
			return;
		}
		temp=strrchr(filename,'/');
		if(!temp) temp=filename;
		else temp++;
		name=malloc(strlen(temp)+1);
		strcpy(name,temp);
		*strrchr(name,'.')='\0';
		rate=wav_file->samples_per_sec*wav_file->channels*(wav_file->bits_per_sample/8);
		wav_ip.set_info(name,(wav_file->length*10)/(rate/100),8*rate,wav_file->samples_per_sec,wav_file->channels);
		free(name);
		wav_file->seek_to=-1;
		pthread_create(&decode_thread,NULL,play_loop,NULL);
	
	}
}

static void stop(void)
{
	if(wav_file)
	{
		if(wav_file->going)
		{
			wav_file->going=0;
			pthread_join(decode_thread,NULL);
			wav_ip.output->close_audio();
			free(wav_file);
			wav_file=NULL;
			
			
		}
	}
}

static void wav_pause(short p)
{
	wav_ip.output->pause(p);
}

static void seek(int time)
{
	wav_file->seek_to=time;
	while(wav_file->seek_to!=-1) usleep(10000);
}

static int get_time(void)
{
	if(!wav_file)
		return -1;
	if(!wav_file->going||wav_file->eof)
		return -1;
	else 
	{
		return wav_ip.output->output_time();
	}
}


	
