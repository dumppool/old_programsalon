/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/


#ifndef AUDIO_CODEC_H
#define AUDIO_CODEC_H

#include "AviDecaps.h"

#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <memory.h>
#include <stdlib.h>
#include <stdio.h>
#include <mmreg.h>
#include <msacm.h>

#include "mpglib.h"
#include "ring.h"

#include <mmreg.h>
#include <msacm.h>

#define INPUT_BUFFER_SIZE 16384

/*
 * The codec class
 */

class AudioCodec {

private:

	/*
	 * ACM Codec
	 *
	 */

	HACMSTREAM      hacm;
	ACMSTREAMHEADER acmHeader;
	DWORD           acm;
	DWORD           acmLeft;
	DWORD           acmInLeft;

	/*
	 * MPEG only codec
	 *
	 */

	struct mpstr    mp;
	int             last_result;
	int             mpeg;
	int             real_size;
	WAVEFORMATEX   *oFormat;
	AviDecaps      *decaps;
	char           *in_buffer;
	char           *out_buffer;

	int             DecompressMp3(char *outmemory, int outmemsize, int *done);

public:

	AudioCodec(AviDecaps *decaps, WAVEFORMATEX *lpWave);
	~AudioCodec();

	BOOL          IsOK();
	WAVEFORMATEX *GetFormat();

	int           EmptyBuffers();

	char         *GetCodecName();

	int           Decompress(void *buffer, int size);
	int           Close();

};

#endif