/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/

#include "SkinFile.h"

/*
 * Skin config file class
 */

SkinFile::SkinFile(char *directory) {

	this->configFile = NULL;

	if(directory != NULL) {

		char *filename;

		filename = (char *) malloc(strlen(directory) + 12);
		strcpy(filename, directory);

		this->configFile = fopen(strcat(filename, "\\config.txt"), "rt");

		free(filename);
	}

}

SkinFile::~SkinFile() {

}

int SkinFile::getColor(char *section) {

	if(this->configFile) {

		int r = 0, g = 0, b = 0;
		char *buffer;

		buffer    = (char *) malloc(strlen(section) + 6);
		buffer[0] = '[';

		strcat(buffer + 1, section);
		strcat(buffer, "]\n");

		fscanf(this->configFile, buffer);

		fread(buffer, 1, strlen(section) + 2, configFile);
		fscanf(this->configFile, "%d, %d, %d", &r, &g, &b);

		//free(buffer);

		return r + 256*g + 65536*b;
	}

	return 0;
}

void SkinFile::Close() {

	if(this->configFile) {

		fclose(this->configFile);
	}
}
