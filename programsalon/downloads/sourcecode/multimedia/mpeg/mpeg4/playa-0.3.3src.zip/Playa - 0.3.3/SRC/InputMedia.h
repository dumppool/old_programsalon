/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/


#ifndef INPUT_MEDIA_H
#define INPUT_MEDIA_H

/*
 * Includes
 */

#include <windows.h>
#include <wininet.h>
#include <fcntl.h>
#include <stdio.h>
#include <io.h>
#include <crtdbg.h>
#include <mmsystem.h>

#include "debug.h"

#define HTTP_BUFFER_SIZE 556000

/*
 * Media source enum
 */

enum {

	INPUT_TYPE_FILE,
	INPUT_TYPE_HTTP,
};

/*
 * File mode enum
 */

enum {

	INPUT_OPEN_ASCII,
	INPUT_OPEN_BINARY
};

/*
 * Seek Enum
 */

enum {

	INPUT_SEEK_SET,
	INPUT_SEEK_CUR,
	INPUT_SEEK_END
};

/*
 * Input Class
 */

class InputMedia {

public:

	DWORD mode;

	FILE *file;
	FILE *dnld;
	char *buffer;

	char *filename;
	DWORD file_size;

	/*
 	 * HTTP/FTP stuff 
	 */

	HINTERNET hInternet;
	HINTERNET http;
	HANDLE    httpThread;
	DWORD     httpId;
	DWORD     running;
	DWORD     buffering;
	DWORD     downloaded;
	DWORD     eof;

	HANDLE    ioMutex;
	DWORD     lastReadPos;

	InputMedia();
	~InputMedia();

	int Open(char *lpFilename, int mode, int type);
	int isOK();

	char *getFilename();
	DWORD getSize();

	int getBufferState();

	int Read(char *data, unsigned int size);
	int Seek(int   size, unsigned int method);

	int ScanF(const char *format, void *data);

	int Close();
};

#endif
