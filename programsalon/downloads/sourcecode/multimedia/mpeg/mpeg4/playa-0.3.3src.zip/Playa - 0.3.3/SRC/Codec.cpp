/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/


#include "Codec.h"

/*
 * Functions
 *
 */

/*
 * Constructor : tries to open the stream
 *
 */

Codec::Codec(BITMAPINFOHEADER *bih)
{
	HRESULT h;

	this->hic       = 0;
	this->divx      = 0;
	this->videoMode = VIDEO_MODE_ERROR;

	if(bih) {
		
		if(bih->biCompression == 4) {
			
		    bih->biCompression = mmioFOURCC('D', 'I', 'V', 'X');
		}

		if(bih->biCompression == mmioFOURCC('D', 'I', 'V', 'X')) {

			/*
			 * Here we can use decore directly
			 */

			this->dec_param.x_dim = bih->biWidth;
			this->dec_param.y_dim = bih->biHeight;

			this->dec_param.color_depth = 24;
			this->videoMode = VIDEO_MODE_RGB24;

			decore(0x8001, DEC_OPT_INIT, &this->dec_param, NULL);

			/*
			 * We set the use of prosprocessing or not
			 */

			this->dec_set.postproc_level = 0;
		
			decore(0x8001, DEC_OPT_SETPP, &dec_set, NULL);

			this->divx = 1;

		}
		else {
			
			this->hic = ICOpen(mmioFOURCC('V', 'I', 'D', 'C'), 
							             bih->biCompression,
							             ICMODE_FASTDECOMPRESS);

			if(this->hic != 0) {

				ZeroMemory(&this->in_bih, sizeof(BITMAPINFO));
				ZeroMemory(&this->out_bih, sizeof(BITMAPINFO));

			    memcpy(&this->in_bih.bmiHeader, bih, sizeof(BITMAPINFOHEADER));
			
				out_bih.bmiHeader.biSize     = sizeof(BITMAPINFOHEADER);
				out_bih.bmiHeader.biBitCount = 16;

				h = ICDecompressGetFormat( this->hic, &this->in_bih, &this->out_bih ); 

				if(h == ICERR_OK) {

					h = ICDecompressQuery(this->hic, &this->in_bih, &this->out_bih);
				    
					this->out_bih.bmiHeader.biSizeImage = out_bih.bmiHeader.biWidth*out_bih.bmiHeader.biHeight*out_bih.bmiHeader.biBitCount/8;

					h = ICDecompressBegin(this->hic, &this->in_bih, &this->out_bih);  
			
					this->videoMode = VIDEO_MODE_RGB24;

					if(h != ICERR_OK) {
						MessageBox(NULL, "Can't Begin Decompression", "", MB_OK);
						this->hic = 0;
					}
				}
				else {

					MessageBox(NULL, "Codec not working!", "", MB_OK);
					this->hic = 0;
				}
			}
			else {

				MessageBox(NULL, "Can't find any appropriate Codec!", "", MB_OK);
				this->hic = 0;
			}
		}
	}
	else {
		
		MessageBox(NULL, "Codec : wrong input parameters!", "Error", MB_OK);
	}
}

/* 
 * Destructor : Cleanup.
 *
 */

Codec::~Codec()
{

}

/*
 * Returns TRUE if codec is
 * ready to decode data.
 */

int Codec::IsOK()
{
	return (this->hic != 0 || this->divx != 0);
}

/*
 * Set/Get the video Mode
 */

int Codec::GetVideoMode() {

	return this->videoMode;
}

int Codec::SetVideoMode(int depth) {

	if(this->divx) {

		switch(depth) {

		case VIDEO_MODE_RGB16:

			this->dec_param.color_depth = 16;
			this->videoMode = VIDEO_MODE_RGB16;

			decore(0x8001, DEC_OPT_INIT, &this->dec_param, NULL);
			break;

		case VIDEO_MODE_RGB24:

			this->dec_param.color_depth = 24;
			this->videoMode = VIDEO_MODE_RGB24;

			decore(0x8001, DEC_OPT_INIT, &this->dec_param, NULL);
			break;

		case VIDEO_MODE_RGB32:

			this->dec_param.color_depth = 32;
			this->videoMode = VIDEO_MODE_RGB32;

			decore(0x8001, DEC_OPT_INIT, &this->dec_param, NULL);
			break;
	
		default:
			return 0;
			break;

		}

	}
	else {
	
		if(this->hic) {


		}
	}

	return 0;
}


/*
 * Decompress on frame
 *
 */

int Codec::Decompress(char *in, long in_size, char *out)
{
	HRESULT h;

	if(this->divx) {

		dec_frame.length      = in_size;
		dec_frame.bitstream   = in;
		dec_frame.bmp         = out;
		dec_frame.render_flag = 1;
  
	    decore(0x8001, 0, &dec_frame, NULL);
	}
	else {
	
		if(this->hic) {
		
			this->in_bih.bmiHeader.biSizeImage = in_size;

			if(in_size == 0) {
		
			h = ICDecompress(this->hic, ICDECOMPRESS_NULLFRAME,
							 &this->in_bih.bmiHeader, (void *) in,
							 &this->out_bih.bmiHeader, (void *) out);

			}
			else {

			h = ICDecompress(this->hic, ICDECOMPRESS_NOTKEYFRAME,
							 &this->in_bih.bmiHeader, (void *) in,
							 &this->out_bih.bmiHeader, (void *) out);
			}
		}
	}

	return 1;
}

/*
 * Drops one frame.
 *
 */

int Codec::Drop(char *in, long in_size, char *out) 
{
	
	if(this->divx) {
	
		dec_frame.length      = in_size;
		dec_frame.bitstream   = in;
		dec_frame.bmp         = out;
		dec_frame.render_flag = 0;
  
	    decore(0x8001, 0, &dec_frame, NULL);
	}
	else {
		if(this->hic) {
	
			this->in_bih.bmiHeader.biSizeImage = in_size;

			ICDecompress(this->hic, ICDECOMPRESS_HURRYUP,
						 &this->in_bih.bmiHeader, (void *) in,
						 &this->out_bih.bmiHeader, (void *) out);
		}
	}

	return 1;
}

/*
 * return a name for the
 * codec in use...
 *
 */

char *Codec::GetCodecName()
{

	if(this->divx) {

		return "OpenDivX video codec";
	}
	else {

		if(this->hic) {

			ICINFO icInfo;
			char *name;
			int i;
			
			ICGetInfo(this->hic, &icInfo, sizeof(ICINFO));

			name = (char *) malloc(128);

			for(i=0; i < 128; i++) { 
				name[i] = icInfo.szDescription[i] & 255;
			}
	
			return name;
		}
	}

	return NULL;
}


/*
 * Closes the decoder.
 *
 */

int Codec::Close()
{
	if(this->divx) {
	
		decore(0x8001, DEC_OPT_RELEASE, NULL, NULL);
	}
	else {
		if(this->hic) {

			ICDecompressEnd(this->hic);
			ICClose(this->hic);
		}
	}

	return 1;
}
