/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/

#ifndef AVI_DECAPS_H
#define AVI_DECAPS_H

/*
 * includes
 */

#include "InputMedia.h"
#include <windows.h>
#include <windowsx.h>
#include <malloc.h>
#include <stdlib.h>

/*
 * SOME USEFUL MACROS
 */

#define AVI_MAX_LEN 2000000000
#define HEADERBYTES 2048
#define PAD_EVEN(x) ( ((x)+1) & ~1 )
#define AVIIF_KEYFRAME	0x00000010L

/*
 * INDEX TYPES
 */

typedef struct
{
  long pos;
  long len;
  long flags;

} video_index_entry;

typedef struct
{
   long pos;
   long len;
   long tot;

} audio_index_entry;

/*
 * Main Class
 */

class AviDecaps {

public:
   
	BITMAPINFOHEADER   bitmapinfoheader;
	WAVEFORMATEX       waveformatex;
    long               width;             
    long               height;            
    double             fps;               
    char               compressor[8];     
    long               video_strn;        
    long               video_frames;      
    char               video_tag[4];      
    long               video_pos;         
    long               a_fmt;             
    long               a_chans;           
    long               a_rate;            
    long               a_bits;            
    long               audio_strn;        
    long               audio_bytes;       
    long               audio_chunks;      
    char               audio_tag[4];      
    long               audio_posc;        
    long               audio_posb;        
    long               pos;               
    long               n_idx;             
    long               max_idx;           
    char               (*idx)[16]; 
    video_index_entry *video_index;
    audio_index_entry *audio_index;
    long               last_pos;          
    long               last_len;          
    int                must_use_index;    
    long               movi_start;

	HANDLE             hIOMutex;

	int IsAVI();
	int FillHeader(int getIndex);
	int AddIndexEntry(char *tag, 
			          long flags, 
			          long pos, 
			          long len);
	BOOL isKeyframe(long frame);

	InputMedia        *input;

	AviDecaps();
	~AviDecaps();

	int               Open(char *lpFilename, int type);
	int               VideoStreams();
	int               AudioStreams();

	int               Width();
	int               Height();
	BITMAPINFOHEADER *BitmapInfoHeader();
	int               FrameSize(unsigned long frame_number);
	double            FrameRate();
	long              TotalFrames();
	int               NextVideoFrame(char *buffer);

	int               VideoSeek(long frame);
	int               AudioSeek(long bytes);

	int               NextKeyFrame();
	int				  PreviousKeyFrame();

	int               Seek(int percent);
	int               ReSeekAudio();

	int               SampleSize();
	WAVEFORMATEX     *WaveFormatEx();
	int               ReadAudio(char *buffer, int size);

	int Rewind();

	double GetProgress();
	int GetBufferingState();

	int Close();

};

#endif