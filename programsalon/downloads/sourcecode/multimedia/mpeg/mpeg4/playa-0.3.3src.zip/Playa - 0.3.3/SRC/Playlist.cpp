/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/


#include "Playlist.h"

Playlist::Playlist()
{
	this->list             = NULL;
	this->nbr_items        = 0;
	this->current_position = -1;
}

Playlist::~Playlist()
{

}

int Playlist::Clear()
{
	this->nbr_items        = 0;
	this->current_position = -1;
	this->list             = NULL;

	return 1;
}

int Playlist::Reset() 
{

	if(this->list != NULL) {
		this->current_position = 0;
	}

	return 1;
}

char *Playlist::GetItemAt(int i)
{
	int index, j;
	list_t *node;

	if(this->list != NULL) {
		
		if( i < 0)
			return list->filename;

		if(i > this->nbr_items - 1)
			index = this->nbr_items - 1;
		else 
			index = i;

		node = this->list;

		for(j=0; j<index; j++) {
			node = node->next;
		}

		return node->filename;
	}

	return NULL;
}

int Playlist::Add(char *filename)
{
	list_t *item;

	item = (list_t *) malloc(sizeof(list_t));

	item->filename = filename;
	item->next = this->list;

	this->list = item;
	this->nbr_items++;
		
	return 1;
}

char *Playlist::Previous()
{
	if(this->list != NULL) {

		if(this->current_position == 0)
			return list->filename;

		this->current_position--;

		return GetItemAt(this->current_position);
	}

	return NULL;
}

char *Playlist::Next()
{

	if(this->list != NULL) {

		if(this->current_position == this->nbr_items - 1)
			return GetItemAt(this->current_position);

		this->current_position++;

		return GetItemAt(this->current_position);
	}

	return NULL;
}

