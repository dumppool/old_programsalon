/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/

#ifndef _RESIZER_H
#define _RESIZER_H

#include <windows.h>
#include "Skin.h"

/*
 * The class used to draw
 * the resize frame...
 *
 */

class Resizer {

private:

	POINT lastPt;
	POINT startPt;
	DWORD maintainAspect;

public:

	Resizer();
	~Resizer();

	void Start(POINT *pt);
	void Draw(HWND hwnd, POINT *pt);
	void Stop();
};

#endif