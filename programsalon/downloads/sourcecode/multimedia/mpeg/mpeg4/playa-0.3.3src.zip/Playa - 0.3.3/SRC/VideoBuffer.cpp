/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/

#include "VideoBuffer.h"

/*
 * Class functions
 */

/*
 * Constructor
 */

VideoBuffer::VideoBuffer(AviDecaps *decaps, Codec *codec)
{
	unsigned int i;

	this->input_buffer = NULL;

	if(decaps != NULL || codec != NULL) {

		this->decaps = decaps;
		this->codec  = codec;

		this->input_buffer = (char *) malloc(VIDEO_BUFFER_SIZE);

		for(i=0; i < 1/*BUFFER_SIZE*/; i++) {
	
			this->frames[i] = (char *) malloc(decaps->Width()*decaps->Height()*4);
			memset(this->frames[i], 0, decaps->Width()*decaps->Height()*4);
		}

		this->frame_size = decaps->Width()*decaps->Height()*3;
		this->free_slots = BUFFER_SIZE;

		//this->mutex = CreateMutex (NULL, FALSE, NULL);

		this->running = 0;
		this->mode    = VIDEO_BUFFER_INACTIVE;
	}
}

VideoBuffer::~VideoBuffer()
{
}

DWORD WINAPI FillThread(LPVOID lpData)
{
	VideoBuffer *videoBuffer;

	videoBuffer = (VideoBuffer *) lpData;

	if(videoBuffer == NULL)
		return 0;

	while(videoBuffer->running) {

		Sleep(2);
	
		if(videoBuffer->free_slots > 0) {

			long frame_size = 0;

			WaitForSingleObject(videoBuffer->mutex, INFINITE);

			if( (BUFFER_SIZE - videoBuffer->free_slots - 1) > 0) {

				memcpy(videoBuffer->frames[BUFFER_SIZE - videoBuffer->free_slots],
					   videoBuffer->frames[BUFFER_SIZE - videoBuffer->free_slots - 1],
					   videoBuffer->frame_size);
			}

			/*
			 * Do Decomp here
			 */
			
			frame_size = videoBuffer->decaps->NextVideoFrame(videoBuffer->input_buffer);
				
			if(frame_size == -2) {

				/*
				 * We're at the end of the file
				 */
					
			    ReleaseMutex(videoBuffer->mutex);
				return 0;
			}

			videoBuffer->codec->Decompress(videoBuffer->input_buffer, 
										   frame_size, 
										   videoBuffer->frames[BUFFER_SIZE - videoBuffer->free_slots]);

			videoBuffer->free_slots--;

			ReleaseMutex(videoBuffer->mutex);
		}
	}

	return 0;
}

void VideoBuffer::Start()
{
	/*
	 * First fill our buffer
	 *
	 */

	this->free_slots = BUFFER_SIZE;
	this->running    = 1;

	if(mode == VIDEO_BUFFER_ACTIVE) {
		
		//this->fillThread = CreateThread( NULL, 0, FillThread, (LPVOID) this, 0, &this->id );
		//SetThreadPriority(this->fillThread, THREAD_PRIORITY_ABOVE_NORMAL);
	}
}

void VideoBuffer::Stop()
{
	this->running = 0;
	//TerminateThread(this->fillThread, 0);

	unsigned int i;

	if(this->input_buffer != NULL)
		free(this->input_buffer);

	for(i=0; i < 1/*BUFFER_SIZE*/; i++) {
	
		if(this->frames[i] != NULL)
			free(this->frames[i]);
	}
}

char *VideoBuffer::GiveMeAFrame()
{
	unsigned int i;

	switch(this->mode) {

	case VIDEO_BUFFER_ACTIVE:

		if(this->input_buffer && this->free_slots < BUFFER_SIZE) {

			long frame_size = 0;
			char *temp;

			temp = this->frames[0];

			//WaitForSingleObject(this->mutex, INFINITE);

			for(i=0; i < BUFFER_SIZE - 1; i++) {
			
				this->frames[i] = this->frames[i+1];
			}
			this->frames[BUFFER_SIZE - 1] = temp;

			this->free_slots++;
			//ReleaseMutex(this->mutex);

			return this->frames[0];
		}
		else {
			
			
		
			/*
			 * Shouldn't happen
			 */

			return NULL; //this->frames[0];
		}

		break;

	case VIDEO_BUFFER_INACTIVE:

		long frame_size = 0;

		/*
		 * Do Decomp here
		 */
			
		frame_size = this->decaps->NextVideoFrame(this->input_buffer);
				
		if(frame_size == -2) {

			/*
			 * We're at the end of the file
			 */
					
			return NULL;
		}

		this->codec->Decompress(this->input_buffer, 
			 				    frame_size, 
							    this->frames[0]);
		break;
	}

	return this->frames[0];
}


void VideoBuffer::Drop()
{
	unsigned int i;
	long frame_size = 0;

	switch(this->mode) {

	case VIDEO_BUFFER_INACTIVE:

		/*
		 * Do Decomp here
		 */
			
		frame_size = this->decaps->NextVideoFrame(this->input_buffer);
				
		if(frame_size == -2) {

			/*
			 * We're at the end of the file
			 */
				
			return;
		}

		this->codec->Drop(this->input_buffer, 
			 			  frame_size, 
						  this->frames[0]);

		break;

	case VIDEO_BUFFER_ACTIVE:

		break;
	}
}
