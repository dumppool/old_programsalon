/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/


#ifndef _VIDEO_BUFFER_H
#define _VIDEO_BUFFER_H

#include "AviDecaps.h"
#include "Codec.h"

#define BUFFER_SIZE            5
#define VIDEO_BUFFER_SIZE 100000

enum {

	VIDEO_BUFFER_ACTIVE,
	VIDEO_BUFFER_INACTIVE,
};

class VideoBuffer {

public:

	AviDecaps *decaps;
	Codec     *codec;
	char      *frames[BUFFER_SIZE];
	char      *input_buffer;
	int        free_slots;
	int        frame_size;
	int        running;
	HANDLE     fillThread;
	DWORD      id;
	HANDLE     mutex;
	DWORD      mode;

	VideoBuffer(AviDecaps *decaps, Codec *codec);
	~VideoBuffer();

	void Start();
	void Stop();

	char *GiveMeAFrame();
	void  Drop();
};

#endif