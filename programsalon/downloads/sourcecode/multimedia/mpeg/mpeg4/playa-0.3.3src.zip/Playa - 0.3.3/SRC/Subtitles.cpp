/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/


#include "Subtitles.h"

/*
 * Subtitles class
 */

Subtitles::Subtitles() {

	this->input  = NULL;
	this->format = -1;
}

Subtitles::~Subtitles() {

}

int Subtitles::Open(char *aviFilename) {

	this->input = NULL;

	if(aviFilename) {

		char *subFilename;

		subFilename = (char *) malloc(strlen(aviFilename) - 2);
		
		strncpy(subFilename, aviFilename, strlen(aviFilename) - 3);
		subFilename[strlen(aviFilename) - 3]= '\0';
		strncat(subFilename, "sub", 3);

		/*
		 * only local subtitles are supported now
		 */

		this->input = new InputMedia();

		this->input->Open(subFilename, INPUT_OPEN_ASCII, INPUT_TYPE_FILE);
		if(!this->input->isOK())
			return 0;

		/*
		 * Now check the subtitles type
		 */

		char firstByte;

		this->input->Read(&firstByte, 1);
		this->input->Seek(0, INPUT_SEEK_SET);

		switch(firstByte) {

		case '[':

			/*
			 * SubViewer format (likely)
			 */

			return 0;
			break;

		case '{':

			/*
			 * Micro DVD format (likely)
			 */

			this->format = SUBTITLES_FORMAT_SUBVIEWER;

			break;

		default:
			return 0;

		}

		getNextSubtitle();

		return 1;
	}

	return 0;
}

int Subtitles::getNextSubtitle() {

	if(this->input->isOK()) {

		switch(this->format) {

		case SUBTITLES_FORMAT_SUBVIEWER:

			/*
			 * Find the corresponding string
			 * and get the text to display
			 */

			/*
			 * Seek to the next '{'
			 * and look at frame number
			 *
			 */

			char  dummy;
			DWORD frame;
			DWORD i;

			this->input->Read(&dummy, 1);

			while(dummy != '{') {

				this->input->Read(&dummy, 1);
			};

			/*
			 * Now we can get the frame number
			 */

			this->input->ScanF("%d", &this->firstFrame);
			
			this->input->ScanF("%c%c", &text);
			this->input->ScanF("%d", &this->lastFrame);

			this->input->ScanF("%c", &text);
			
			/*
			 * now read until the end of line
			 */

			memset(text, 0, 255);

			i=0;

			while(text[i-1] != '\n' && i < 255) {

				this->input->Read(&text[i], 1);
				i++;
			}

			return 1;

			break;

		default:
			this->firstFrame = 0x100000000;
			return 0;
		}
	}

	return 0;
}

int Subtitles::Apply(HWND hwnd, long frameNumber, double frameRate, int fullscreen) {

	if(this->input->isOK()) {

		if(frameNumber > this->lastFrame) {
		
			do {
				
				this->getNextSubtitle();
			}
			while(this->firstFrame < frameNumber);
		}

		HDC    hdc;
		HBRUSH brush;
		char  *secondLine;
		RECT   rect;
	
		hdc = GetDC(hwnd);
		SetBkMode(hdc, TRANSPARENT);

		GetClientRect( hwnd, &rect );

		/*
		 * squeeze rect so that
		 * we have space for controls
		 */

		rect.left   += 7;
		rect.right  -= 8;

		rect.top     = rect.bottom - 115 - 50;
		rect.bottom -= 115;

		if(fullscreen) {
			return 0;
		}

		brush = CreateSolidBrush(0); 
		SelectObject(hdc, brush);
		Rectangle(hdc, rect.left, rect.top, rect.right, rect.bottom); 

		if(frameNumber >= this->firstFrame && frameNumber <= this->lastFrame) {

			/*
			 * We can draw it
			 *
			 */

			SetTextColor(hdc, 0x00FFFFFF);

			secondLine = strchr(this->text, '|');

			if(secondLine == NULL) {

				TextOut(hdc, rect.left + ((rect.right - rect.left)/2) - 3*strlen(text), 
					    rect.top + (rect.bottom - rect.top)/2 - 6, this->text, strlen(this->text) - 1);
			}
			else {

				TextOut(hdc, rect.left + ((rect.right - rect.left)/2) - 3*(strlen(this->text) - strlen(secondLine)), 
					    rect.top + (rect.bottom - rect.top)/2 - 15, this->text, strlen(this->text) - strlen(secondLine));
				TextOut(hdc, rect.left + ((rect.right - rect.left)/2) - 3*(strlen(secondLine) - 2), 
					    rect.top + (rect.bottom - rect.top)/2, secondLine + 1, strlen(secondLine) - 2);
			}
		}

		DeleteDC(hdc);
	}

	return 0;
}

int Subtitles::Close() {

	if(this->input) {
		this->input->Close();
		delete this->input;
	}

	return 0;
}
