/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <darc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/

#ifndef PM_DEBUG_H
#define PM_DEBUG_H

#include <windows.h>
#include <stdio.h>

#ifdef _DEBUG__

extern FILE *debug_file;

#endif

/*
 * Version
 */

#define VERSION "0.3.3"

/*
 * DEBUG MACRO
 */

#ifdef _DEBUG__

#define PM_DEBUG(X, arg) { \
  \
  fprintf(debug_file, X, arg); \
}

#else

#define PM_DEBUG(X, arg) {}

#endif

/*
 * Type For options 
 *
 *
 */

typedef struct _options_t {

	DWORD loop;
	DWORD on_top;
	DWORD maintain_aspect_ratio;
	DWORD use_bilinear;
	DWORD change_fullscreen_res;

} options_t;

#endif