/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/


#ifndef VIDEO_H
#define VIDEO_H

#include "codec.h"

#include <windows.h>
 
#define D3D_OVERLOADS

#include <d3d.h> 
#include <ddraw.h>
#include <d3dtypes.h> 
#include <vfw.h>
#include <stdio.h>

class VideoRenderer {
	
private:

	int codecDepth;

	/*
	 * Switch
	 */

	int use_bilinear;
	int fullscreen;
	int change_fullscreen_res;

	/*
	 * Fullscreen Variables
	 */

	int screen_size_x;
	int screen_size_y;
	int video_width;
	int video_height;

	/*
	 * bilinear FIltering Stuff
	 */

	LPDIRECTDRAW7        lpDD;
	LPDIRECTDRAWSURFACE7 lpDDSPrimary;
	LPDIRECTDRAWSURFACE7 lpDDSBack;
	LPDIRECTDRAWSURFACE7 lpDDSImage;
	LPDIRECT3D7          lpD3D;
	LPDIRECT3DDEVICE7    lpDevice;
	LPDIRECTDRAWCLIPPER  lpDDClipper;
	DDSURFACEDESC2       ddsd;
	DDSCAPS              ddscaps;

	/*
	 * Normal Stuff
	 *
	 */

	LPDIRECTDRAWCLIPPER lpDDClipper1;

	HRESULT              ddrval;
	HWND                 hwnd;
	BITMAPINFOHEADER    *bih;

	BOOL restoreAll(void);
	int  copyPixels(void *src, void *dst, int in_depth, 
				    int out_depth, int width, int height, int pitch);

public:

	VideoRenderer();
	~VideoRenderer();

	int SetBilinear(int use_bilinear);
	int SetChangeFullscreenRes(int change_full);

	int Fullscreen(int onOff);

	int Open(HWND hwnd, BITMAPINFOHEADER *bih);
	int OpenFullscreen(HWND hwnd, BITMAPINFOHEADER *bih);

	int GetVideoMode();
	int SetCodecVideoMode(int depth);

	int Draw(char *buffer, int has_subtitles);
	int DrawFullscreen(char *buffer);

	int Close();

};

#endif