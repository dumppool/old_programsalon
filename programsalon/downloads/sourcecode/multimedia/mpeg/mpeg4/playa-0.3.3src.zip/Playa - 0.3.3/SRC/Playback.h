/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/

#ifndef PLAYBACK_H
#define PLAYBACK_H

#include "debug.h"

#include "AviDecaps.h"
#include "Codec.h"
#include "VideoRenderer.h"
#include "AudioCodec.h"
#include "AudioRenderer.h"
#include "VideoBuffer.h"
#include "Subtitles.h"

#include <windows.h>
#include <winbase.h>
#include <windowsx.h>

/*
 * Main Class
 */


class Playback {

public:

	int            ok;
	int            playing;
	int            paused;
	int            volume;
	int            use_bilinear;
	int            fullscreen;
	int            fast_forward;
	int            rewind;
	int            has_subtitles;
	int            use_subtitles;
	int            loop;
	DWORD          baseTime;
	DWORD          stopTime;

	HANDLE         playbackMutex;
	HANDLE         videoThread;
	DWORD          id;
	HWND           hwnd;

	AviDecaps     *decaps;
	Codec         *codec;
	VideoRenderer *videoRenderer;
	AudioCodec    *audioCodec;
	AudioRenderer *audioRenderer;
	VideoBuffer   *videoBuffer;
	Subtitles     *subtitles;

	unsigned long video_frames;
	unsigned long displayed_frames;
	unsigned long audio_bytes;


	Playback();
	~Playback();

	int Open(char *lpFilename, int type, HWND hwnd);

	int OK();

	int  Width();
	int  Height();

	unsigned long VideoTime();
	unsigned long AudioTime();

	BOOL   isPaused();
	BOOL   isPlaying();

	int    Play();
	int    Pause();
	int    NextFrame();
	int    Stop(int redraw);
	int    Close();

	int    FastForward();
	int    Rewind();

	int    Seek(int percent);
	int    SetVolume(int volume);
	int    SetLoop(int loop);

	double    GetProgress();
	int    GetTime();
	int    GetTotalTime();
	double GetCurrentFps();
	int    GetBufferingState();

	int    SetBilinear(int use_bilinear);
	int    SetChangeFullscreenRes(int change);
	int    SetUseSubtitles(int useSubtitles);

	int    Fullscreen(int active);
	int    isInFullscreen();
};

#endif