/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/

#ifndef CODEC_H
#define CODEC_H

#include <stdio.h>
#include <io.h>
#include <windows.h>
#include <vfw.h>

#include "debug.h"
#include "decore.h"

/*
 * Video modes enum
 */

enum {

	VIDEO_MODE_ERROR,
	VIDEO_MODE_RGB16,
	VIDEO_MODE_RGB24,
	VIDEO_MODE_RGB32,

	/*
	 * Add YUV modes here
	 */

};

class Codec {

private:

	/*
	 * for VFW codecs
	 */

	HIC        hic;
	BITMAPINFO in_bih;
	BITMAPINFO out_bih;

	/*
	 * for the DIVX codec
	 */

	DEC_SET   dec_set;
	DEC_PARAM dec_param;
	DEC_FRAME dec_frame;

	/*
	 * Video Mode  
	 */

	int   videoMode;
	DWORD divx;

public:

	Codec(BITMAPINFOHEADER *bih);
	~Codec();

	int IsOK();

	int Decompress(char *in, long in_size, char *out);
	int Drop(char *in, long in_size, char *out);

	int GetVideoMode();
	int SetVideoMode(int depth);

	char *GetCodecName();

	int Close();

};

#endif
