/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/


#include "VideoRenderer.h"

/*
 * Functions
 */

VideoRenderer::VideoRenderer()
{
	/*
	 * By default, no filtering
	 */

	this->use_bilinear          = 0;
	this->fullscreen            = 0;
	this->change_fullscreen_res = 0;

	/*
	 * init DX pointers
	 */

	lpDD         = NULL;
	lpDDSPrimary = NULL;
	lpDDSBack    = NULL;
	lpDDSImage   = NULL;
	lpD3D        = NULL;
	lpDevice     = NULL;
	lpDDClipper  = NULL;
}

/*
 * Sets the use of bilinear
 * filtering
 */

int VideoRenderer::SetBilinear(int use_bilinear)
{
	this->use_bilinear = use_bilinear;
	return 1;
}

/*
 * Set Force of Fullscreen Resolution
 *
 */

int VideoRenderer::SetChangeFullscreenRes(int change_full)
{
	this->change_fullscreen_res = change_full;
	return 1;
}


/*
 * Open the device
 *
 */

int VideoRenderer::Open(HWND hwnd, BITMAPINFOHEADER *bih)
{

	if(hwnd && bih) {

		this->hwnd = hwnd;
		this->bih  = bih;

		if(this->use_bilinear) {

			this->ddrval = DirectDrawCreateEx(NULL, (void **) &this->lpDD, IID_IDirectDraw7, NULL);

			if(ddrval != DD_OK) {

				MessageBox(NULL, "This version of the \"Playah\" requires DirectX 7.0", "Fatal Error", MB_OK);
				return 0;
			}

			ddrval = lpDD->SetCooperativeLevel(hwnd, DDSCL_NORMAL);

		    if(ddrval != DD_OK) {

			    MessageBox(hwnd, "Error intializing Cooperative Level", "Fatal Error", MB_OK); 
				return 0;
			}

		    memset( &ddsd, 0, sizeof(ddsd) );

			ddsd.dwSize = sizeof( ddsd );

		    ddsd.dwFlags           = DDSD_CAPS;
			ddsd.ddsCaps.dwCaps    = DDSCAPS_PRIMARYSURFACE;

		    ddrval = lpDD->CreateSurface(&ddsd, &lpDDSPrimary, NULL);

		    if(ddrval != DD_OK) {

				return 0;
			}

		    /*
			 * Now set Clipping
			 */

		    ddrval = lpDD->CreateClipper(0, &lpDDClipper, NULL);

			if(ddrval != DD_OK) {

				MessageBox(hwnd, "Error Creating Clipper", "Fatal Error", MB_OK); 
				return 0;
			}
	
		    ddrval = lpDDClipper->SetHWnd(0, hwnd);

			if(ddrval != DD_OK) {

				MessageBox(hwnd, "Error Assigning Clipper", "Fatal Error", MB_OK); 
				return 0;
			}
	
		   ddrval = lpDDSPrimary->SetClipper(lpDDClipper);

			if(ddrval != DD_OK) {

				MessageBox(hwnd, "Error Assigning Clipper to Surface", "Fatal Error", MB_OK); 
				return 0;
			}

           /*
			* Finally Create Back Surface
			*/
    
			ZeroMemory(&ddsd, sizeof(ddsd));
    
			ddsd.dwSize   = sizeof(ddsd);
			ddsd.dwFlags  = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH; 
			ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_3DDEVICE;
			ddsd.dwWidth  = 1920;
			ddsd.dwHeight = 1440;

			if (lpDD->CreateSurface(&ddsd, &lpDDSBack, NULL) != DD_OK) {
    
				MessageBox(NULL, "Problem with back surface", "", MB_OK);
				return 0;
			}

			/*
		     * Now the 3D part
	  		 */

			ddrval = lpDD->QueryInterface(IID_IDirect3D7, (LPVOID *) &this->lpD3D);

			if(ddrval != DD_OK) {

				MessageBox(NULL, "Cannot init Direct3D", "", MB_OK);
			}

			if (lpD3D->CreateDevice(IID_IDirect3DTnLHalDevice, lpDDSBack, &lpDevice) != D3D_OK) {
				if (lpD3D->CreateDevice(IID_IDirect3DHALDevice, lpDDSBack, &lpDevice) != D3D_OK) {
					if (lpD3D->CreateDevice(IID_IDirect3DMMXDevice, lpDDSBack, &lpDevice) != D3D_OK) {
						if (lpD3D->CreateDevice(IID_IDirect3DRGBDevice, lpDDSBack, &lpDevice) != D3D_OK) {
					
							MessageBox(NULL, "Could not create any 3D device", "Error", MB_OK);
							return 0;
						}
					}	
				}
			}

			D3DVIEWPORT7 view;

			view.dwX=0;
			view.dwY=0; 
			view.dwWidth=1920;
			view.dwHeight=1440; 
			view.dvMinZ=0.0f;
			view.dvMaxZ=1.0f;

			lpDevice->SetViewport(& view);

			/*
			 * AND request filtering
			*/

			lpDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTFG_LINEAR);
			lpDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTFG_LINEAR);

			/*
			 * Create the texture surface
			 *
			 */

			ZeroMemory(&ddsd, sizeof(ddsd));
    
			ddsd.dwSize = sizeof(ddsd);
			ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH; 
			ddsd.ddsCaps.dwCaps = DDSCAPS_TEXTURE;
			ddsd.dwWidth = bih->biWidth;
			ddsd.dwHeight = bih->biHeight;

			if (lpDD->CreateSurface(&ddsd, &lpDDSImage, NULL) != DD_OK) {
    
				MessageBox(NULL, "Problem with image surface", "", MB_OK);
				return 0;
			}
			
			/*
			 * Check for capabilities
			 */

			D3DDEVICEDESC7 ddDesc;
			lpDevice->GetCaps(&ddDesc);

			if (ddDesc.deviceGUID==IID_IDirect3DHALDevice || ddDesc.deviceGUID==IID_IDirect3DTnLHalDevice) {
	
				ddsd.ddsCaps.dwCaps2=DDSCAPS2_TEXTUREMANAGE;
			}
			else {
	
				ddsd.ddsCaps.dwCaps |= DDSCAPS_SYSTEMMEMORY;
			}

			/*
			 * Check for old cards problems
			*/

			if (ddDesc.dpcTriCaps.dwTextureCaps & D3DPTEXTURECAPS_POW2 ) {

				for (ddsd.dwWidth=1; bih->biWidth > ddsd.dwWidth; ddsd.dwWidth <<= 1);
				for (ddsd.dwHeight=1; bih->biHeight > ddsd.dwHeight; ddsd.dwHeight <<= 1);
			}

			if (ddDesc.dpcTriCaps.dwTextureCaps & D3DPTEXTURECAPS_SQUAREONLY) {

				if (ddsd.dwWidth > ddsd.dwHeight )
					ddsd.dwHeight=ddsd.dwWidth;
				else
					ddsd.dwWidth=ddsd.dwHeight;
			}	
	
			if (lpDD->CreateSurface(&ddsd, &lpDDSImage, NULL) != DD_OK) {
    
				MessageBox(NULL, "Problem with back surface", "", MB_OK);
				return 0;
			}
	
			lpDDSImage->Restore();			

			lpDevice->SetTexture(0, lpDDSImage);

		}
		else {

			/*
			 * No 3D/filtering here!
			 */

			this->ddrval = DirectDrawCreateEx(NULL, (void **) &this->lpDD, IID_IDirectDraw7, NULL);

			if(ddrval != DD_OK) {

				MessageBox(NULL, "Couldn't initialize DirectDraw", "", MB_OK);
				return 0;
			}

			ddrval = lpDD->SetCooperativeLevel(hwnd, DDSCL_NORMAL);

		    if(ddrval != DD_OK) {

		        MessageBox(hwnd, "Error intializing Cooperative Level", "Fatal Error", MB_OK); 
				return 0;
			}
	
			memset( &ddsd, 0, sizeof(ddsd) );

		    ddsd.dwSize = sizeof( ddsd );

		    ddsd.dwFlags           = DDSD_CAPS;
			ddsd.ddsCaps.dwCaps    = DDSCAPS_PRIMARYSURFACE | DDSCAPS_VIDEOMEMORY;

		    ddrval = lpDD->CreateSurface(&ddsd, &lpDDSPrimary, NULL);

		    if(ddrval != DD_OK ) {

				return 0;
			}

		    /*
			 * Now set Clipping
			 */

		    ddrval = lpDD->CreateClipper(0, &lpDDClipper, NULL);

		    if(ddrval != DD_OK) {

		        MessageBox(hwnd, "Error Creating Clipper", "Fatal Error", MB_OK); 
			   return 0;
			}

		    ddrval = lpDDClipper->SetHWnd(0, hwnd);

		    if(ddrval != DD_OK) {

		        MessageBox(hwnd, "Error Assigning Clipper", "Fatal Error", MB_OK); 
			    return 0;
			}

		    ddrval = lpDDSPrimary->SetClipper(lpDDClipper);

		    if(ddrval != DD_OK) {

			  MessageBox(hwnd, "Error Assigning Clipper to Surface", "Fatal Error", MB_OK); 
			  return 0;
			}
	
			/*
			 * Finally Create Back Surface and BITMAP
			*/
	
			ZeroMemory(&ddsd, sizeof(ddsd));
    
			ddsd.dwSize = sizeof(ddsd);
			ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
			ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
		    ddsd.dwWidth  = bih->biWidth;
			ddsd.dwHeight = bih->biHeight;

			if (lpDD->CreateSurface(&ddsd, &lpDDSBack, NULL) != DD_OK) {
			
				MessageBox(NULL, "Cannot create back buffer!", "", MB_OK);
				return 0;
			}
		}
	}


	return 1;
}

VideoRenderer::~VideoRenderer()
{

}

/*
 * Setup the two modes in fullscreen
 *
 */

int VideoRenderer::OpenFullscreen(HWND hwnd, BITMAPINFOHEADER *bih)
{

	this->hwnd = hwnd;
	this->bih  = bih;

	if(this->use_bilinear) {

		this->ddrval = DirectDrawCreateEx(NULL, (void **) &this->lpDD, IID_IDirectDraw7, NULL);

		if(ddrval != DD_OK) {
			return 0;
		}

		ddrval = lpDD->SetCooperativeLevel(this->hwnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN );
	
		if(ddrval != DD_OK) {

			MessageBox(NULL, "cannot get exclusive mode!", "", MB_OK);
			return 0;
		}

		/*
		 * Check if display mode has been forced
		 *
		 */

		if(this->change_fullscreen_res == 0) {

			DDSURFACEDESC2 ddDesc;

			memset(&ddDesc, 0, sizeof(DDSURFACEDESC2));
			ddDesc.dwSize = sizeof(DDSURFACEDESC2);

			/*
			 * We need to know witch resolution
			 * we are in...
			 */

			ddrval = lpDD->GetDisplayMode(&ddDesc);

			if(ddrval != DD_OK) {

				MessageBox(hwnd, "DirectDraw: Cannot get Display Resolution", "", MB_OK);
				return 0;
			}

			ddrval = lpDD->SetDisplayMode( ddDesc.dwWidth, ddDesc.dwHeight, ddDesc.ddpfPixelFormat.dwRGBBitCount, 0, 0 );

			if(ddrval == DD_OK) {

				screen_size_x = ddDesc.dwWidth;
				screen_size_y = ddDesc.dwHeight;
				goto done;
			}

			return 0;

		}
		else {

			/*
			 * We need to find the best display mode
	 		 *
			 */

			screen_size_x = 320;
			screen_size_y = 200;

			if(bih->biWidth <= 320 && bih->biHeight <= 200) {

				ddrval = lpDD->SetDisplayMode( 320, 200, 16, 0, 0 );

				if(ddrval == DD_OK) {

					goto done;
				}
				else {

					ddrval = lpDD->SetDisplayMode( 320, 200, 32, 0, 0 );
			
					if(ddrval == DD_OK) {

						goto done;
					}
				}
			}

			if(bih->biWidth <= 400 && bih->biHeight <= 300) {

				ddrval = lpDD->SetDisplayMode( 400, 300, 16, 0, 0 );

				if(ddrval == DD_OK) {

					screen_size_x = 400;
					screen_size_y = 300;
					goto done;
				}
				else {

					ddrval = lpDD->SetDisplayMode( 400, 300, 32, 0, 0 );
			
					if(ddrval == DD_OK) {

						screen_size_x = 400;
						screen_size_y = 300;
						goto done;
					}
				}
			}

			if(bih->biWidth <= 640 && bih->biHeight <= 480) {

				ddrval = lpDD->SetDisplayMode( 640, 480, 16, 0, 0 );

				if(ddrval == DD_OK) {

					screen_size_x = 640;
					screen_size_y = 480;
					goto done;
				}
				else {

				ddrval = lpDD->SetDisplayMode( 640, 480, 32, 0, 0 );
				
					if(ddrval == DD_OK) {

						screen_size_x = 640;
						screen_size_y = 480;
						goto done;
					}
				}
			}

			if(bih->biWidth <= 800 && bih->biHeight <= 600) {

				ddrval = lpDD->SetDisplayMode( 800, 600, 16, 0, 0 );

				if(ddrval == DD_OK) {

					screen_size_x = 800;
					screen_size_y = 600;
					goto done;
				}
				else {

					ddrval = lpDD->SetDisplayMode( 800, 600, 32, 0, 0 );
			
					if(ddrval == DD_OK) {

						screen_size_x = 800;
						screen_size_y = 600;
						goto done;
					}
				}
			}

			if(bih->biWidth <= 1024 && bih->biHeight <= 768) {

				ddrval = lpDD->SetDisplayMode( 1024, 768, 16, 0, 0 );

				if(ddrval == DD_OK) {

					screen_size_x = 1024;
					screen_size_y = 768;
					goto done;
				}
				else {

					ddrval = lpDD->SetDisplayMode( 1024, 768, 32, 0, 0 );
			
					if(ddrval == DD_OK) {

						screen_size_x = 1024;
						screen_size_y = 768;
						goto done;
					}
				}
			}
		}
done:

		if(ddrval != DD_OK) {

			   MessageBox(hwnd, "Error intializing Cooperative Level", "Fatal Error", MB_OK); 
				return 0;
		}
	
		memset( &ddsd, 0, sizeof(ddsd) );

		ddsd.dwSize = sizeof( ddsd );

		ddsd.dwFlags           = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
		ddsd.ddsCaps.dwCaps    = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX | DDSCAPS_3DDEVICE;
		ddsd.dwBackBufferCount = 1;

	    ddrval = lpDD->CreateSurface(&ddsd, &lpDDSPrimary, NULL);

	    if(ddrval != DD_OK) {

		    MessageBox(hwnd, "Error Creating Surface 3", "Fatal Error", MB_OK); 
			return 0;
		}

		DDSCAPS2 ddscaps;

		ZeroMemory(&ddscaps, sizeof(ddscaps));

		ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
		ddrval         = lpDDSPrimary->GetAttachedSurface(&ddscaps, &lpDDSBack);


	/*
	 * Now the 3D part
	 */

	ddrval = lpDD->QueryInterface(IID_IDirect3D7, (LPVOID *) &this->lpD3D);

	if(ddrval != DD_OK) {

		MessageBox(NULL, "Cannot init Direct3D", "", MB_OK);
	}

	if (lpD3D->CreateDevice(IID_IDirect3DTnLHalDevice, lpDDSBack, &lpDevice) != D3D_OK) {
		if (lpD3D->CreateDevice(IID_IDirect3DHALDevice, lpDDSBack, &lpDevice) != D3D_OK) {
			if (lpD3D->CreateDevice(IID_IDirect3DMMXDevice, lpDDSBack, &lpDevice) != D3D_OK) {
				if (lpD3D->CreateDevice(IID_IDirect3DRGBDevice, lpDDSBack, &lpDevice) != D3D_OK) {
					
					MessageBox(NULL, "Could not create any 3D device", "Error", MB_OK);
					return 0;
				}
			}	
		}
	}

	D3DVIEWPORT7 view;

	view.dwX=0;
	view.dwY=0; 
	view.dwWidth=screen_size_x;
	view.dwHeight=screen_size_y; 
	view.dvMinZ=0.0f;
	view.dvMaxZ=1.0f;

	lpDevice->SetViewport(& view);

	/*
	 * AND request filtering
	 */

	lpDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTFG_LINEAR);
	lpDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTFG_LINEAR);

	/*
	 * now create the image surface
	 *
	 */

	ZeroMemory(&ddsd, sizeof(ddsd));
    
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps = DDSCAPS_TEXTURE;
	ddsd.dwWidth  = bih->biWidth;
	ddsd.dwHeight = bih->biHeight;

	D3DDEVICEDESC7 ddDesc;
	lpDevice->GetCaps(&ddDesc);

	if (ddDesc.deviceGUID==IID_IDirect3DHALDevice || ddDesc.deviceGUID==IID_IDirect3DTnLHalDevice) {
	
		ddsd.ddsCaps.dwCaps2=DDSCAPS2_TEXTUREMANAGE;
	}
	else {
	
		ddsd.ddsCaps.dwCaps |= DDSCAPS_SYSTEMMEMORY;
	}

	/*
	 * Check for old cards problems
	 */

	if (ddDesc.dpcTriCaps.dwTextureCaps & D3DPTEXTURECAPS_POW2 ) {

		for (ddsd.dwWidth=1; bih->biWidth > ddsd.dwWidth; ddsd.dwWidth <<= 1);
		for (ddsd.dwHeight=1; bih->biHeight > ddsd.dwHeight; ddsd.dwHeight <<= 1);
	}

	if (ddDesc.dpcTriCaps.dwTextureCaps & D3DPTEXTURECAPS_SQUAREONLY) {

		if (ddsd.dwWidth > ddsd.dwHeight )
			ddsd.dwHeight=ddsd.dwWidth;
		else
			ddsd.dwWidth=ddsd.dwHeight;
	}	

	if (lpDD->CreateSurface(&ddsd, &lpDDSImage, NULL) != DD_OK) {
			
		MessageBox(NULL, "Cannot create back buffer!", "", MB_OK);
		return 0;
	}

	/*
	 * and the pixels
	 *
	 */

	video_width   = screen_size_x;
	video_height  = bih->biHeight*screen_size_x/bih->biWidth;

	lpDevice->SetTexture(0, lpDDSImage);

	}
	else {

	/*
	 * No 3D here!
	 */

	this->hwnd = hwnd;
	this->bih  = bih;

	this->ddrval = DirectDrawCreateEx(NULL, (void **) &this->lpDD, IID_IDirectDraw7, NULL);

	if(ddrval != DD_OK) {
		return 0;
	}

	ddrval = lpDD->SetCooperativeLevel(this->hwnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN );
	
	if(ddrval != DD_OK) {

		MessageBox(NULL, "cannot get exclusive mode!", "", MB_OK);
		return 0;
	}

	if(this->change_fullscreen_res == 0) {

			DDSURFACEDESC2 ddDesc;

			memset(&ddDesc, 0, sizeof(DDSURFACEDESC2));
			ddDesc.dwSize = sizeof(DDSURFACEDESC2);

			/*
			 * We need to know witch resolution
			 * we are in...
			 */

			ddrval = lpDD->GetDisplayMode(&ddDesc);

			if(ddrval != DD_OK) {

				MessageBox(hwnd, "DirectDraw: Cannot get Display Resolution", "", MB_OK);
				return 0;
			}

			ddrval = lpDD->SetDisplayMode( ddDesc.dwWidth, ddDesc.dwHeight, ddDesc.ddpfPixelFormat.dwRGBBitCount, 0, 0 );

			if(ddrval == DD_OK) {

				screen_size_x = ddDesc.dwWidth;
				screen_size_y = ddDesc.dwHeight;
				goto done;
			}

			return 0;

	}
	else {

	   /*
		 * We need to find the best display mode
	 	 *
		 */

		screen_size_x = 320;
		screen_size_y = 200;

		if(bih->biWidth <= 320 && bih->biHeight <= 200) {

			ddrval = lpDD->SetDisplayMode( 320, 200, 16, 0, 0 );

			if(ddrval == DD_OK) {

				goto done2;
			}
			else {

				ddrval = lpDD->SetDisplayMode( 320, 200, 32, 0, 0 );
			
				if(ddrval == DD_OK) {

					goto done2;
				}
			}
		}

		if(bih->biWidth <= 400 && bih->biHeight <= 300) {

			ddrval = lpDD->SetDisplayMode( 400, 300, 16, 0, 0 );

			if(ddrval == DD_OK) {

				screen_size_x = 400;
				screen_size_y = 300;
				goto done2;
			}
			else {

				ddrval = lpDD->SetDisplayMode( 400, 300, 32, 0, 0 );
			
				if(ddrval == DD_OK) {

					screen_size_x = 400;
					screen_size_y = 300;
					goto done2;
				}
			}
		}

		if(bih->biWidth <= 640 && bih->biHeight <= 480) {

			ddrval = lpDD->SetDisplayMode( 640, 480, 16, 0, 0 );

			if(ddrval == DD_OK) {

				screen_size_x = 640;
				screen_size_y = 480;
				goto done2;
			}
			else {

				ddrval = lpDD->SetDisplayMode( 640, 480, 32, 0, 0 );
			
				if(ddrval == DD_OK) {

					screen_size_x = 640;
					screen_size_y = 480;
					goto done2;
				}
			}
		}

		if(bih->biWidth <= 800 && bih->biHeight <= 600) {

			ddrval = lpDD->SetDisplayMode( 800, 600, 16, 0, 0 );

			if(ddrval == DD_OK) {

				screen_size_x = 800;
				screen_size_y = 600;
				goto done2;
			}
			else {

				ddrval = lpDD->SetDisplayMode( 800, 600, 32, 0, 0 );
			
				if(ddrval == DD_OK) {

					screen_size_x = 800;
					screen_size_y = 600;
					goto done2;
				}
			}
		}

		if(bih->biWidth <= 1024 && bih->biHeight <= 768) {

			ddrval = lpDD->SetDisplayMode( 1024, 768, 16, 0, 0 );

			if(ddrval == DD_OK) {

				screen_size_x = 1024;
				screen_size_y = 768;
				goto done2;
			}
			else {

				ddrval = lpDD->SetDisplayMode( 1024, 768, 32, 0, 0 );
			
				if(ddrval == DD_OK) {

					screen_size_x = 1024;
					screen_size_y = 768;
					goto done2;
				}
			}
		}
    }

done2:

	if(ddrval != DD_OK) {

		   MessageBox(hwnd, "Error intializing Cooperative Level", "Fatal Error", MB_OK); 
			return 0;
	}
	
	memset( &ddsd, 0, sizeof(ddsd) );

	ddsd.dwSize = sizeof( ddsd );

	ddsd.dwFlags           = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
	ddsd.ddsCaps.dwCaps    = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;
	ddsd.dwBackBufferCount = 1;

    ddrval = lpDD->CreateSurface(&ddsd, &lpDDSPrimary, NULL);

    if(ddrval != DD_OK) {

	    MessageBox(hwnd, "Error Creating Surface 4", "Fatal Error", MB_OK); 
		return 0;
	}

	DDSCAPS2 ddscaps;

	ZeroMemory(&ddscaps, sizeof(ddscaps));

	ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
	ddrval         = lpDDSPrimary->GetAttachedSurface(&ddscaps, &lpDDSBack);

	/*
	 * now create the image surface
	 *
	 */

	ZeroMemory(&ddsd, sizeof(ddsd));
    
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
	ddsd.dwWidth  = bih->biWidth;
	ddsd.dwHeight = bih->biHeight;

	if (lpDD->CreateSurface(&ddsd, &lpDDSImage, NULL) != DD_OK) {
			
		MessageBox(NULL, "Cannot create back buffer!", "", MB_OK);
		return 0;
	}

	/*
	 * and the pixels
	 *
	 */

	video_width   = screen_size_x;
	video_height  = bih->biHeight*screen_size_x/bih->biWidth;
	
	}

	return 1;
}


BOOL VideoRenderer::restoreAll( void )
{
    return lpDDSPrimary->Restore() == DD_OK &&
           lpDDSBack->Restore() == DD_OK;

}

int VideoRenderer::Fullscreen(int onOff)
{
	if(!this->fullscreen && onOff) {

		/*
		 * we're going to fullscreen
		 */

		this->Close();
		this->OpenFullscreen(this->hwnd, this->bih);
		this->fullscreen = TRUE;

	}
	else {
	
		if(this->fullscreen && !onOff) {

			this->Close();
			this->Open(this->hwnd, this->bih);
			this->fullscreen = FALSE;
		}

	}

	return 1;
}

/*
 * Set/Get the video modes
 */

int VideoRenderer::GetVideoMode() {

	DDSURFACEDESC2  desc;
	int mode = 0, result = VIDEO_MODE_ERROR;

	if(this->use_bilinear ) {

		/*
		 * Lock the surface
		 */

		ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
		desc.dwSize = sizeof(DDSURFACEDESC2);
		
		this->lpDDSImage->Lock(NULL, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY, NULL);

		mode = desc.ddpfPixelFormat.dwRGBBitCount;

		this->lpDDSImage->Unlock(NULL);
	}
	else {

		ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
		desc.dwSize = sizeof(DDSURFACEDESC2);

		this->lpDDSBack->Lock(NULL, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY, NULL);

		mode = desc.ddpfPixelFormat.dwRGBBitCount;

		this->lpDDSBack->Unlock(NULL);
	}

	switch(mode) {

	case 16:
		result = VIDEO_MODE_RGB16;
		break;

	case 24:
		result = VIDEO_MODE_RGB24;
		break;

	case 32:
		result = VIDEO_MODE_RGB32;
		break;

	default:
		break;
	}

	return result;
}

int VideoRenderer::SetCodecVideoMode(int depth) {

	this->codecDepth = depth;
	return 1;
}


/*
 * Performs all needed 
 * video conversions
 *
 */

int VideoRenderer::copyPixels(void *src, void *dst, int in_depth, int out_depth, int width, int height, int pitch) {

	int i, j, line;

	switch(out_depth) {

	case 16:

		switch(in_depth) {

		case VIDEO_MODE_RGB16:

			line = 2*width;

			for(i=0; i < height; i++) {

				memcpy((void *) ((char *) dst + pitch*(height - i - 1)), 
					   (void *) ((char *) src + i*line), line);
			}
			break;

		default:

			char  *_src = (char  *) src;
			short *_dst = (short *) dst;
	
			for(j = 0; j < height; j++) {
			
				for(i = 0; i < width; i++) {

			      char r = *_src++;
		          char g = *_src++;
				  char b = *_src++;

	              *(_dst + pitch/2*(height - j - 1) + i) = ( (r & 0xF8) >> 3)  |
				           ( (g & 0xFC) << 3 ) |
						   ( (b & 0xF8) << 8 );
				}
			}
			break;
		}

		break;

	case 24:

		/*
		 * in_depth will always be 24
		 */

		line = 3*width;

		for(j = 0; j < height; j++) {

			memcpy((char *) dst + pitch*(height - j - 1),
				   (char *) src + line*j, line);
		}
		break;

	case 32:

		switch(in_depth) {

		case VIDEO_MODE_RGB24:

			for(j = 0; j < height; j++) {
				for(i = 0; i < width; i++) {
			
					memcpy((char *) dst + pitch*(height - j - 1) + 4*i,
						   (char *) src + 3*width*j + (3*i),
						   3);
				}
			}
			break;

		case VIDEO_MODE_RGB32:

			line = 4*width;

			for(j = 0; j < height; j++) {

				memcpy((char *) dst + pitch*(height - j - 1),
					   (char *) src + line*j, line);
			}
			break;

		}

		break;

	default:
		break;
	}

	return 0;
}


/*
 * Draws in Fullscreen
 *
 */

int VideoRenderer::DrawFullscreen(char *buffer)
{
	DDSURFACEDESC2  desc;
	long i, j;

	if(buffer != NULL) {

	if(this->use_bilinear ) {

		/*
		 * Lock the surface
		 */

		ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
		desc.dwSize = sizeof(DDSURFACEDESC2);
		this->lpDDSImage->Lock(NULL, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY, NULL);

		/*
		 * Copy the pixels
		 */

		this->copyPixels(buffer, desc.lpSurface, this->codecDepth, desc.ddpfPixelFormat.dwRGBBitCount, bih->biWidth, bih->biHeight, desc.lPitch);

		this->lpDDSImage->Unlock(NULL);

		/*
		 * Now Blit to the window
		 */

		DDBLTFX bltfx;

		ZeroMemory(&bltfx, sizeof(bltfx)); // Sets dwFillColor to 0 as well
		
		bltfx.dwSize = sizeof(bltfx);
		lpDDSBack->Blt(NULL, NULL, NULL, DDBLT_WAIT | DDBLT_COLORFILL, &bltfx);

		if(this->hwnd) {

			D3DTLVERTEX square1[4];

			square1[0] = D3DTLVERTEX(D3DVECTOR(0, (screen_size_y - video_height)/2, 0), 1.0, RGBA_MAKE(255,255,255,255),0, 0.0, 0.0);
			square1[1] = D3DTLVERTEX(D3DVECTOR(screen_size_x, (screen_size_y - video_height)/2, 0), 1.0, RGBA_MAKE(255,255,255,255),0, (float)bih->biWidth/(float)desc.dwWidth, 0.0);
			square1[2] = D3DTLVERTEX(D3DVECTOR(0,  (screen_size_y - video_height)/2 + video_height, 0.0), 1.0, RGBA_MAKE(255,255,255,255),0, 0.0, (float)bih->biHeight/(float)desc.dwHeight);
			square1[3] = D3DTLVERTEX(D3DVECTOR(screen_size_x, (screen_size_y - video_height)/2 + video_height, 0.0), 1.0, RGBA_MAKE(255,255,255,255),0, (float)bih->biWidth/(float)desc.dwWidth, (float)bih->biHeight/(float)desc.dwHeight);
	
			if( SUCCEEDED( lpDevice->BeginScene() ) ) {

				lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, D3DFVF_TLVERTEX, square1, 4, 0);
				lpDevice->EndScene();
			}
		}

	}
	else {

		ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
		desc.dwSize = sizeof(DDSURFACEDESC2);

		this->lpDDSImage->Lock(NULL, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY, NULL);

		/*
		 * Copy the pixels
		 */

		this->copyPixels(buffer, desc.lpSurface, this->codecDepth, desc.ddpfPixelFormat.dwRGBBitCount, bih->biWidth, bih->biHeight, desc.lPitch);

		this->lpDDSImage->Unlock(NULL);

		/*
		 * Clear the back buffer
		 *
		 */

		DDBLTFX bltfx;

		ZeroMemory(&bltfx, sizeof(bltfx)); // Sets dwFillColor to 0 as well
		
		bltfx.dwSize = sizeof(bltfx);
		lpDDSBack->Blt(NULL, NULL, NULL, DDBLT_WAIT | DDBLT_COLORFILL, &bltfx);

		/*
		 * Now Blit to the Back Buffer
		 */

		RECT rcRect, dst;

		rcRect.left   = 0;
		rcRect.top    = 0;
		rcRect.right  = this->bih->biWidth;
		rcRect.bottom = this->bih->biHeight;

		dst.left   = 0;
		dst.top    = (screen_size_y - video_height)/2;
		dst.right  = screen_size_x;
		dst.bottom = (screen_size_y - video_height)/2 + video_height;

		ddrval = lpDDSBack->Blt( &dst, lpDDSImage, &rcRect, DDBLT_ASYNC, NULL);
	}

	this->lpDDSPrimary->Flip(0, DDFLIP_WAIT);
  }

  return 1;
}

/*
 * Draw NOT in fullscreen
 *
 */

int VideoRenderer::Draw(char *buffer, int has_subtitles)
{
	DDSURFACEDESC2 desc;
	long i, j;

	/*
	 * Get a pointer to pixels 
	 * and memcopy them
	 */

	if(buffer != NULL && this->lpDDSPrimary != NULL) {

	if(this->use_bilinear) {

		ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
		desc.dwSize = sizeof(DDSURFACEDESC2);

			if(this->lpDDSImage != NULL) {

				ddrval = this->lpDDSImage->Lock(NULL, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY, NULL);
			}

		if(ddrval != DD_OK) {

			if( ddrval == DDERR_SURFACEBUSY ) {
		
				this->lpDDSImage->Unlock(NULL);
				
				ddrval = this->lpDDSImage->Lock(NULL, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY, NULL);

				if(ddrval != DD_OK) {
				
					MessageBox(NULL, "Couldn't lock either", "Error", MB_OK);
					return 0;
				}
			}
		}

		/*
		 * Copy the pixels
		 */


		this->copyPixels(buffer, desc.lpSurface, this->codecDepth, desc.ddpfPixelFormat.dwRGBBitCount, bih->biWidth, bih->biHeight, desc.lPitch);


		this->lpDDSImage->Unlock(NULL);


		/*
		 * Now Blit to the window
		 */


		if(this->hwnd) {

			RECT                rcRect;
			RECT                destRect;
			POINT               pt;

			GetClientRect( hwnd, &destRect );

			/*
			 * squeeze rect so that
			 * we have space for controls
			 */

			destRect.left   += 7;
			destRect.right  -= 8;

			destRect.top    += 22;
			destRect.bottom -= 115;

			destRect.bottom -= has_subtitles ? 50 : 0;

			pt.x = pt.y = 0;
			ClientToScreen( hwnd, &pt );
			OffsetRect(&destRect, pt.x, pt.y);

			D3DTLVERTEX square1[4];

			square1[0] = D3DTLVERTEX(D3DVECTOR(0, 0, 0.0), 1.0, RGBA_MAKE(255,255,255,255),0, 0.0, 0.0);
			square1[1] = D3DTLVERTEX(D3DVECTOR(destRect.right - destRect.left, 0,    0.0), 1.0, RGBA_MAKE(255,255,255,255),0, (float)bih->biWidth/(float)desc.dwWidth, 0.0);
			square1[2] = D3DTLVERTEX(D3DVECTOR(0,  destRect.bottom - destRect.top, 0.0), 1.0, RGBA_MAKE(255,255,255,255),0, 0.0, (float)bih->biHeight/(float)desc.dwHeight);
			square1[3] = D3DTLVERTEX(D3DVECTOR(destRect.right - destRect.left, destRect.bottom - destRect.top, 0.0), 1.0, RGBA_MAKE(255,255,255,255),0, (float)bih->biWidth/(float)desc.dwWidth, (float)bih->biHeight/(float)desc.dwHeight);

			rcRect.left   = 0;
			rcRect.top    = 0;
			rcRect.right  = destRect.right - destRect.left;
			rcRect.bottom = destRect.bottom - destRect.top;

			
			if( SUCCEEDED( lpDevice->BeginScene() ) ) {

				lpDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, D3DFVF_TLVERTEX, square1, 4, 0);
				lpDevice->EndScene();
			}

			while( 1 )
			{
				ddrval = lpDDSPrimary->Blt( &destRect, lpDDSBack, &rcRect, DDBLT_ASYNC, NULL );

				if( ddrval == DD_OK )
				{
					break;
				}

				if( ddrval == DDERR_SURFACELOST )
				{
					if(!this->restoreAll())
					{
						return 0;
					}	
				}	

				if( ddrval != DDERR_WASSTILLDRAWING )
				{
					return 0;
				}
			}

		}
	}
	else {

		/*
		 * Get a pointer to pixels 
		 * and memcopy them
		 */

		ZeroMemory(&desc, sizeof(DDSURFACEDESC2));
		desc.dwSize = sizeof(DDSURFACEDESC2);

		this->lpDDSBack->Lock(NULL, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY, NULL);

		/*
		 * Copy the pixels
		 */

		this->copyPixels(buffer, desc.lpSurface, this->codecDepth, desc.ddpfPixelFormat.dwRGBBitCount, bih->biWidth, bih->biHeight, desc.lPitch);

		this->lpDDSBack->Unlock(NULL);

		/*
		 * Now Blit to the window
		 */

		if(this->hwnd) {

			RECT                rcRect;
			RECT                destRect;
			POINT               pt;

	        rcRect.left   = 0;
		    rcRect.top    = 0;
			rcRect.right  = this->bih->biWidth;
			rcRect.bottom = this->bih->biHeight;

			GetClientRect( hwnd, &destRect );

			/*
			 * squeeze rect so that
			 * we have space for controls
			*/

			destRect.left   += 7;
			destRect.right  -= 8;

			destRect.top    += 22;
			destRect.bottom -= 115;
			
			destRect.bottom -= has_subtitles ? 50 : 0;

			pt.x = pt.y = 0;
				
			ClientToScreen( hwnd, &pt );
		
			OffsetRect(&destRect, pt.x, pt.y);

			while( 1 )
			{
				ddrval = lpDDSPrimary->Blt( &destRect, lpDDSBack, &rcRect, DDBLT_ASYNC, NULL );

				if( ddrval == DD_OK )
				{
					break;
				}

				if( ddrval == DDERR_SURFACELOST )
				{
					if(!this->restoreAll())
					{
						return 0;
					}	
				}	

				if( ddrval != DDERR_WASSTILLDRAWING )
				{
					return 0;
				}
			}

			if(ddrval != DD_OK)
			{
				return 0;
			}
		}

	}
  }

  return 1;
}


int VideoRenderer::Close()
{
	if(this->lpDD) {

		if(this->fullscreen) {
		
			lpDD->RestoreDisplayMode();
			lpDD->SetCooperativeLevel(this->hwnd, DDSCL_NORMAL);
		}

		lpDD->Release();
		lpDD = NULL;

		if(this->use_bilinear) {

			if( this->lpDDSImage != NULL )
				{
					lpDDSImage->Release();
				    lpDDSImage = NULL;
			   }
		}

		if( this->lpDDSBack != NULL )
			{
	            lpDDSBack->Release();
                lpDDSBack = NULL;
            }

		if( this->lpDDSPrimary != NULL )
			{
	            lpDDSPrimary->Release();
                lpDDSPrimary = NULL;
            }

	}

	if(this->lpD3D) {
	
		this->lpD3D->Release();
		this->lpD3D = NULL;
	}

	return 1;
}