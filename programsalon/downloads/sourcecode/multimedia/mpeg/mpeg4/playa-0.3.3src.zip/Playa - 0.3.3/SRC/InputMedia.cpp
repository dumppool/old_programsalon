/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/


#include "InputMedia.h"

/*
 * HTTP filling thread
 */

DWORD WINAPI httpThreadFunc( LPVOID lpData)
{
	InputMedia *input = (InputMedia *) lpData;
	DWORD read;
	char  buffer[4096];

	while(input->running) {

		Sleep(5);

		if(input->buffering) {

			read = 0;
					
			InternetReadFile(input->http, (void *) buffer, 4096, &read);

			fwrite(buffer, 1, read, input->dnld);

			input->downloaded += read;
		}
	}

	return 0;
}

/*
 * The main class
 */

InputMedia::InputMedia() 
{
	this->file       = NULL;
	this->dnld       = NULL;
	this->hInternet  = NULL;		
	this->http       = NULL;
	this->buffering  = 0;
	this->mode       = -1;
	this->downloaded = 0;
}

int InputMedia::Open(char *lpFilename, int mode, int type) 
{
	if(lpFilename) {
	
		this->file       = NULL;
		this->dnld       = NULL;
		this->hInternet  = NULL;		
		this->http       = NULL;
		this->buffering  = 0;
		this->mode       = -1;
		this->downloaded = 0;

		switch(type) {

		case INPUT_TYPE_FILE:

			switch(mode) {

			case INPUT_OPEN_BINARY:

				this->file = fopen(lpFilename, "rb");
				break;

			case INPUT_OPEN_ASCII:

				this->file = fopen(lpFilename, "rt");
				break;

			default:
			
				this->file = fopen(lpFilename, "rb");
				break;
			}

			if(this->file == NULL) {

				return 0;
			}

			this->mode = INPUT_TYPE_FILE;

			this->filename  = lpFilename;
			
			fseek(this->file, 0, SEEK_END);
			this->file_size = ftell(this->file);
			fseek(this->file, 0, SEEK_SET);
			
			return 1;

			break;

		case INPUT_TYPE_HTTP:

			this->hInternet = InternetOpen("The Playa - OpenDivX Viewer",
										   INTERNET_OPEN_TYPE_DIRECT,
										   NULL, NULL, 0);

			if(this->hInternet == NULL) {
				
				MessageBox(NULL, "Couldn't open an Internet connection", "", MB_OK);
				return 0;
			}

			this->http = InternetOpenUrl(this->hInternet, lpFilename, NULL, -1, 0, 0);
			
			if(this->http == NULL) {

				return 0;
			}

			/*
			 * Here we can create the temp file 
			 * and start the filling thread
			 */

			this->dnld = fopen("c:\\temp.avi", "w+b");

			if(this->dnld == NULL) {

				MessageBox(NULL, "Could not create temp file, check your settings.", "Error", MB_OK);
				this->file = NULL;
				return 0;
			}

			this->downloaded  = 0;
			this->lastReadPos = 0;

			this->ioMutex = CreateMutex (NULL, FALSE, NULL);

			this->buffering     = 1;
			this->running       = 1;
			this->eof           = 0;

			this->mode = INPUT_TYPE_HTTP;

			this->httpThread    = CreateThread(NULL, 0, httpThreadFunc, (LPVOID) this, 0, &this->httpId);

			while(this->downloaded < HTTP_BUFFER_SIZE && !this->eof) {
		
				Sleep(5);
			}

			this->file = fopen("c:\\temp.avi", "rb");

	
			if(this->file == NULL) {
			
				MessageBox(NULL, "Could not read temp file, check your settings.", "Error", MB_OK);
				return 0;
			}

			return 1;

			break;

			default:
				break;
		}
	}

	return 0;
}

InputMedia::~InputMedia() 
{
	if(this->file) {

		fclose(this->file);
	}
}

int InputMedia::isOK() {

	return (this->file != NULL);
}

int InputMedia::getBufferState() {

	switch(this->mode) {

	case INPUT_TYPE_HTTP:

		if(this->http) {

			if(this->downloaded <= HTTP_BUFFER_SIZE) {

				return ((this->downloaded * 100) / HTTP_BUFFER_SIZE);
			}
			else 
				return 100;
		}

		break;

	default:
		break;
	}

	return 0;
}

char *InputMedia::getFilename()
{
	return this->filename;
	return NULL;
}

DWORD InputMedia::getSize()
{
	if(this->file) {

		return this->file_size;
	}

	return 0;
}

int InputMedia::Read(char *data, unsigned int size)
{
	switch(this->mode) {

	case INPUT_TYPE_FILE:

		if(this->file) {

			return fread( (void *) data, 1, size, this->file);
		}

		MessageBox(NULL, "Problem reading from source!", "", MB_OK);
		break;

	case INPUT_TYPE_HTTP:
		
		if(this->http) {

			if(this->file) {

				return fread( (void *) data, 1, size, this->file);
			}
	
			MessageBox(NULL, "Problem reading from source!", "", MB_OK);
		}
		break;

	default:
		break;
	}

	MessageBox(NULL, "Problem reading from source!", "", MB_OK);
	return 0;
}

int InputMedia::ScanF(const char *format, void *data) {

	switch(mode) {

	case INPUT_TYPE_FILE:
	case INPUT_TYPE_HTTP:

		if(this->file) {
	
			fscanf(this->file, format, data);

			return 1;
		}
		break;

	default:
		break;
	}

	return 0;
}


int InputMedia::Seek(int size, unsigned int method)
{

	switch(mode) {

	case INPUT_TYPE_FILE:
	case INPUT_TYPE_HTTP:

		if(this->file) {

			switch(method)
			{
			case INPUT_SEEK_SET:

				return fseek( this->file, size, SEEK_SET);
				break;

			
			case INPUT_SEEK_CUR:

				if(size == 0) {
					return ftell(this->file);	
				}
				else {
					return fseek( this->file, size, SEEK_CUR);
				}
				break;

			case INPUT_SEEK_END:

				return fseek( this->file, size, SEEK_END);
				break;
			}
		}
		break;

	default:
		break;
	}

	return 0;
}

int InputMedia::Close()
{
	if(this->file) {

		fclose(this->file);
	}

	if(this->http) {

		InternetCloseHandle(this->http);
	}

	if(this->hInternet) {

		InternetCloseHandle(this->hInternet);
	}

	return 1;
}