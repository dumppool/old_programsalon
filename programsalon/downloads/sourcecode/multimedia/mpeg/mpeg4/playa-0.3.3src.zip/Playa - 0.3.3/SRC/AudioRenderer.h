/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/


#ifndef AUDIO_RENDERER_H
#define AUDIO_RENDERER_H

#include <dsound.h>
#include <windows.h>
#include <stdio.h>
#include <math.h>

/*
 * Audio Callback Type
 *
 */

typedef void (*AudioCallback)(void *lpData, void *buffer, unsigned int size);

/*
 * Audio Renderer Class
 */

class AudioRenderer {

public:

	LPDIRECTSOUND       lpDirectSound;
	LPDIRECTSOUNDBUFFER lpBuffer;
	WAVEFORMATEX       *ourFormat;
    DWORD               dwBufferSize;     
    DWORD               dwNextWriteOffset; 
    DWORD               dwProgress;
	unsigned long       dwPlayed;
	DWORD               dwLastPlayPos;
	HANDLE              audioThread;
	UINT                uTimerID;
	LONG                lInTimer;
	DWORD               id;
	AudioCallback       callback;
	void               *lpData;
	int                 paused;

	AudioRenderer(WAVEFORMATEX *inFormat, HWND hwnd);
	~AudioRenderer();

	int SetCallback(void *lpData, AudioCallback callback);
	int SetVolume(int volume);

	unsigned long AudioTime();

	int Bufferize();

	int Start();
	int Pause();
	int Stop();

	int Close();

};

#endif