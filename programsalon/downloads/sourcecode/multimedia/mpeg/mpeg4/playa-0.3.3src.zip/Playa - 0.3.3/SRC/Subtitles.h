/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/


#ifndef _SUBTITLES_H
#define _SUBTITLES_H

#include "debug.h"
#include "InputMedia.h"

#include <string.h>
#include <windows.h>

/*
 * Recognized formats
 */

enum {

	SUBTITLES_FORMAT_SUBVIEWER,
	SUBTITLES_FORMAT_MICRODVD
};

/*
 * Subtitles Class
 */

class Subtitles {

private:

	int         format;
	InputMedia *input;

	int         firstFrame;
	int         lastFrame;
	char        text[255];

	int         getNextSubtitle();

public:

	Subtitles();
	~Subtitles();

	int Open(char *aviFilename);
	int Apply(HWND hwnd, long frameNumber, double frameRate, int fullscreen);
	int Close();

};

#endif