/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/

#include "debug.h"

#include "Skin.h"
#include "Playback.h"
#include "Playlist.h"
#include "DirDialog.h"
#include "SkinList.h"
#include "Resizer.h"

#ifdef WIN32
#include "../build/win32/ressources.h"
#include "../build/win32/resource.h"
#endif

#include <math.h>
#include <commctrl.h>
#include <windows.h>
#include <windowsx.h>

/*
 * Intervals for the timers
 */

#define TIMER_ID     1
#define TIMER_RATE 100

/*
 * Variables
 *
 * Please regroup that in a struct...
 *
 *
 */

DWORD anonymous;
HWND  hwndDisplay;

#ifdef _DEBUG__
FILE *debug_file;
#endif

int       action  = ACTION_NONE;
DWORD     count = 0;
DWORD     use_subtitles         = 1;
DWORD     no_resize             = 0;
char      skinPath[256];
UINT      uTimerID;
RECT      clientRect;
RECT      windowRect, fullwindowRect;
int       moveX = 0, moveY = 0;
Skin     *skin;
Playback *playback;
Playlist *playlist;
CDirDialog *dirChooser;
SkinList   *skinList;
Resizer   *resizer;
char      Name[] = "The \"Playa\"";
char     *RecentFiles[5];
HWND      hwnd, about, urlW = NULL;
HMENU     popupMenu;
HACCEL    hAccel;
POINT     pt2;
POINT     oldPt;
HINSTANCE hInstance;
int showing_cursor;

options_t options, tmpOptions;

/*
 * needed definitions
 */

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void OpenFileForPlaying(HWND hwnd, char *filename, int type);

/*
 * Save and load options
 */

void LoadOptions() {

	HKEY     key;
	DWORD created, size;
	LONG     result;
	DWORD  type, i;
	char      file[256], name[5];
	
	/*
	 * Put the default options
	 *
	 */

	options.change_fullscreen_res = 0;
	options.loop                  = 1;
	options.maintain_aspect_ratio = 1;
	options.on_top                = 1;
	options.use_bilinear          = 0;

	/*
	 * Init the recent file list 
	 */

	for(i=0; i < 5; i++) {

		RecentFiles[i] = NULL;
	}

	/*
	 * Open the registry key
	 */

	result = RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\DivXNetworks\\ThePlaya",
 			                0, "CONFIG", REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, 
							NULL, &key, &created);

	if(result != ERROR_SUCCESS) {

		MessageBox(NULL, "Couldn't load options", "", MB_OK);
		return;
	}

	switch(created) {

	case REG_CREATED_NEW_KEY:

		/*
		 * First time launch (we keep the default)
		 * 
		 */

		break;

	case REG_OPENED_EXISTING_KEY:

		/*
		 * We can read the values
 		 */

		size = 4;
		result = RegQueryValueEx(key, "UseBilinear", 0, &type, (BYTE *)&options.use_bilinear, &size);
		size = 4;
		result = RegQueryValueEx(key, "MaintainAspectRatio", 0, &type, (BYTE *)&options.maintain_aspect_ratio, &size);
		size = 4;
		result = RegQueryValueEx(key, "ChangeFullscreenRes", 0, &type, (BYTE *)&options.change_fullscreen_res, &size);
		size = 4;
		result = RegQueryValueEx(key, "UseSubtitles", 0, &type, (BYTE *)&use_subtitles, &size);
		
		size = 4;
		result = RegQueryValueEx(key, "Loop", 0, &type, (BYTE *)&options.loop, &size);
		size = 4;
		result = RegQueryValueEx(key, "OnTop", 0, &type, (BYTE *)&options.on_top, &size);

		size = 256;
		result = RegQueryValueEx(key, "SkinPath", 0, &type, (BYTE *)skinPath, &size);

		/*
		 * And the recent files
		 */

		for(i=0; i < 5; i++) {

			sprintf(name, "File%d", i+1);

			size = 256;
			result = RegQueryValueEx(key, name, 0, &type, (BYTE *)&file, &size);

			if(result == ERROR_SUCCESS) {
			
				RecentFiles[i] = (char *) malloc(size);
				strncpy(RecentFiles[i], file, size);
			}
		}

		break;

	default:
		break;
	}

	RegCloseKey(key);

}

void SaveOptions() {

	HKEY     key;
	LONG     result;
	DWORD created, i;
	char      name[5];

	/*
	 * Try to open the registry key
	 */

	result = RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\DivXNetworks\\ThePlaya",
							              0, "CONFIG", REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, 
							              NULL, &key, &created);

	if(result != ERROR_SUCCESS) {

		MessageBox(NULL, "Couldn't save options", "", MB_OK);
		
		RegCloseKey(key);
		return;
	}

	RegSetValueEx(key, "UseBilinear", 0, REG_DWORD, (BYTE *) &options.use_bilinear, 4);
	RegSetValueEx(key, "MaintainAspectRatio", 0, REG_DWORD, (BYTE *) &options.maintain_aspect_ratio, 4);
	RegSetValueEx(key, "ChangeFullscreenRes", 0, REG_DWORD, (BYTE *) &options.change_fullscreen_res, 4);
	RegSetValueEx(key, "UseSubtitles", 0, REG_DWORD, (BYTE *) &use_subtitles, 4);
	RegSetValueEx(key, "Loop", 0, REG_DWORD, (BYTE *) &options.loop, 4);
	RegSetValueEx(key, "OnTop", 0, REG_DWORD, (BYTE *) &options.on_top, 4);

	if(strcmp(skinPath, "Default") != 0)
		RegSetValueEx(key, "SkinPath", 0, REG_SZ, (BYTE *) skinPath, strlen(skinPath));
	else 
		RegSetValueEx(key, "SkinPath", 0, REG_SZ, (BYTE *) "Default", strlen("Default"));
	
	/*
	 * The recent file list
	 */

	for(i=0; i < 5; i++) {
		
		if(RecentFiles[i] != NULL) {
		
			sprintf(name, "File%d\0", i+1);
			RegSetValueEx(key, name, 0, REG_SZ, 
							      (BYTE *) RecentFiles[i], strlen(RecentFiles[i]));
		}
	}

	RegCloseKey(key);
}

void Cleanup()
{
	DWORD i;

	for(i=0; i < 5; i++) {
		
		if(RecentFiles[i] != NULL) {

			free(RecentFiles[i]);
		}
	}

	DestroyMenu(popupMenu);

	delete playback;
	delete skinList;
	delete resizer;
	delete playlist;

}


/*******************************************************************************************/


static BOOL APIENTRY PreferencesGeneralDlgProc( HWND hDlg, UINT message, UINT wParam, LONG lParam) {

	switch(message) {
		case WM_INITDIALOG:

			SetWindowPos(hDlg, HWND_TOP, 15, 35, 0, 0, SWP_NOSIZE);

		    CheckDlgButton(hDlg, IDC_CHECK_LOOP, tmpOptions.loop);
		    CheckDlgButton(hDlg, IDC_CHECK_ON_TOP, tmpOptions.on_top);

			return TRUE;

	  case WM_COMMAND:

        switch (wParam)
		{
			case IDC_CHECK_LOOP:

				tmpOptions.loop = tmpOptions.loop ? 0 : 1;
				break;

			case IDC_CHECK_ON_TOP:

				tmpOptions.on_top = tmpOptions.on_top ? 0 : 1;
				break;
		}

		case WM_DESTROY:
			return TRUE;
	}

	return FALSE;
}

static BOOL APIENTRY PreferencesVideoDlgProc( HWND hDlg, UINT message, UINT wParam, LONG lParam) {

	switch(message) {
		case WM_INITDIALOG:

			SetWindowPos(hDlg, HWND_TOP, 15, 35, 0, 0, SWP_NOSIZE);

			CheckDlgButton(hDlg, IDC_CHECK_MAINTAIN, tmpOptions.maintain_aspect_ratio);
		    CheckDlgButton(hDlg, IDC_CHECK_BILINEAR, tmpOptions.use_bilinear);
			
		    CheckDlgButton(hDlg, IDC_CHECK_CHANGE_RES, !tmpOptions.change_fullscreen_res);

			return TRUE;

		case WM_COMMAND:

			switch (wParam)
			{
				case IDC_CHECK_MAINTAIN:

					tmpOptions.maintain_aspect_ratio = tmpOptions.maintain_aspect_ratio ? 0 : 1;
					break;

				case IDC_CHECK_BILINEAR:

					tmpOptions.use_bilinear = tmpOptions.use_bilinear ? 0 : 1;
					break;

				case IDC_CHECK_CHANGE_RES:

					tmpOptions.change_fullscreen_res = tmpOptions.change_fullscreen_res ? 0 : 1;
					break;
			}

		case WM_DESTROY:
			return TRUE;
	}

	return FALSE;
}

/*
 * List of the preferences tab
 *
 */

static struct prefsTabs {
	LPTSTR	rsrc;
	char	*name;
	DLGPROC	dProc;
} tabs[]={
	{	MAKEINTRESOURCE(IDD_PREFS_GENERAL),	"General",	PreferencesGeneralDlgProc},
	{	MAKEINTRESOURCE(IDD_PREFS_VIDEO),	"Video",	PreferencesVideoDlgProc },
};

/*
 * Main preferences DlgProc
 *
 */

static BOOL APIENTRY PreferencesDlgProc( HWND hDlg, UINT message, UINT wParam, LONG lParam) {

	DWORD i;

	switch(message) {
		case WM_INITDIALOG:
			{
				HWND tab = GetDlgItem(hDlg, IDC_TAB);

				memcpy(&tmpOptions, &options, sizeof(options_t));

				for(i = 0; i < (sizeof tabs/sizeof tabs[0]); i++) {
					
					TC_ITEM ti;

					ti.mask		= TCIF_TEXT;
					ti.pszText	= tabs[i].name;

					TabCtrl_InsertItem(tab, i, &ti);
				}

				hwndDisplay = CreateDialogParam(hInstance, tabs[0].rsrc, hDlg, tabs[0].dProc, (LPARAM)NULL);
				ShowWindow(hwndDisplay, SW_SHOW);

				return TRUE;
			}
		
		case WM_NOTIFY: {
			NMHDR *nm = (LPNMHDR)lParam;

			switch(nm->code) {
			case TCN_SELCHANGE:
				{
					int iTab = TabCtrl_GetCurSel(nm->hwndFrom);

					if (iTab>=0) {
						if (hwndDisplay) DestroyWindow(hwndDisplay);
							hwndDisplay = CreateDialogParam(hInstance, tabs[iTab].rsrc, hDlg, tabs[iTab].dProc, NULL);
					}

					ShowWindow(hwndDisplay, SW_SHOW);
				}
				return TRUE;
			}
			}break;


	  case WM_COMMAND:

        switch (wParam)
		{
		  case IDC_PREFS_OK:
		
			  /*
			   * Save the options changes
			   */
				
			  memcpy(&options, &tmpOptions, sizeof(options_t));

			  /*
			   * And apply them
			   */

			  CheckMenuItem(popupMenu, (UINT)ID_BILINEAR,     options.use_bilinear ? MF_CHECKED : MF_UNCHECKED);
			  CheckMenuItem(popupMenu, (UINT)ID_ASPECT_RATIO, options.maintain_aspect_ratio ? MF_CHECKED : MF_UNCHECKED);
			  CheckMenuItem(popupMenu, (UINT)ID_LOOP, options.loop ? MF_CHECKED : MF_UNCHECKED);
		  	  CheckMenuItem(popupMenu, (UINT)ID_ON_TOP, options.on_top ? MF_CHECKED : MF_UNCHECKED);

			  playback->SetBilinear(options.use_bilinear);
			  playback->SetChangeFullscreenRes(options.change_fullscreen_res);
			  playback->SetLoop(options.loop);

			  /*
			   * And end the dialog
			   */
			  
			  EndDialog(hDlg, TRUE);
			  return TRUE;
			  break;

		  case IDC_PREFS_CANCEL:

			  EndDialog(hDlg, TRUE);
			  break;

		  default:
			  return 0;
		}
		break;


		case WM_DESTROY:
			return TRUE;
	}

	return FALSE;
}

/*******************************************************************************************/

/*
 * Properties dialog box message function
 *
 */

int APIENTRY PropDlgProc (HWND hDlg, WORD wMsg, LONG wParam, LONG lParam)
{
  switch (wMsg)
    {
      case WM_INITDIALOG:

		  char freq[20];
		  char channels[2];
		  char video_size[20];
		  char duration[20];
		  char total_size[50];
		  DWORD time, hours, minutes, seconds;

		  _ultoa(playback->audioCodec->GetFormat()->nSamplesPerSec, freq, 10);
		  _ultoa(playback->audioCodec->GetFormat()->nChannels, channels, 10);

		  sprintf(video_size, "%dx%d", playback->decaps->Width(), playback->decaps->Height());
		  sprintf(total_size, "%d bytes", playback->decaps->input->getSize());

		  time = playback->decaps->TotalFrames()/playback->decaps->FrameRate();

		  hours   = time/3600;
		  minutes = (time - hours*3600)/60;
		  seconds = (time - hours*3600 - minutes*60)/60;

		  sprintf(duration, "%.2d:%.2d:%.2d", hours, minutes, seconds);

		  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_FILENAME), playback->decaps->input->getFilename());
		  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_FILE_TYPE), playback->decaps->input->http ? "HTTP Download" : "Local File.");
		  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_FILE_SIZE), total_size);
		  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_DURATION), duration);

		  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_VIDEO_CODEC), playback->videoBuffer->codec->GetCodecName());
		  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_VIDEO_SIZE), video_size);

		  switch(playback->videoBuffer->codec->GetVideoMode()) {

			  case VIDEO_MODE_RGB16:
				  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_VIDEO_MODE), "16 bpp");
				  break;

			  case VIDEO_MODE_RGB24:
				  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_VIDEO_MODE), "24 bpp");
				  break;

			  case VIDEO_MODE_RGB32:
				  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_VIDEO_MODE), "32 bpp");
				  break;
		  }

		  if(playback->audioRenderer != NULL) {
			  		  
			  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_AUDIO_CODEC), playback->audioCodec->GetCodecName());
			  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_AUDIO_FREQUENCY), freq);
			  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_AUDIO_CHANNELS), channels);
		  }
		  else {

			  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_AUDIO_CODEC),     "Not Available");
			  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_AUDIO_FREQUENCY), "Not Available");
			  SetWindowText(GetDlgItem(hDlg, IDC_STATIC_AUDIO_CHANNELS),  "Not Available");
		  }

		  return (0);
		break;

      case WM_SYSCOMMAND:
        if (wParam == SC_CLOSE)
          {
          EndDialog (hDlg, TRUE);
          return (TRUE);
          }
        break;

	  case WM_COMMAND:

        switch (wParam)
		{
		  case IDB_PROPERTIES_OK:
			
			  EndDialog(hDlg, TRUE);
			  return TRUE;
			  break;

		  default:
			  return 0;
		}
		break;
	}

  return FALSE;
}

/*
 * About dialog box message function
 *
 */

int APIENTRY AboutDlgProc (HWND hDlg, WORD wMsg, LONG wParam, LONG lParam)
{
  int first = 0;

  switch (wMsg)
    {
      case WM_INITDIALOG:
        return (0);
		break;

      case WM_SYSCOMMAND:
        if (wParam == SC_CLOSE)
          {
          EndDialog (hDlg, TRUE);
          return (TRUE);
          }
        break;

	  case WM_COMMAND:

        switch (wParam)
		{
		  case IDB_ABOUT_OK:
			
			  EndDialog(hDlg, TRUE);
			  return TRUE;
			  break;

		  default:
			  return 0;
		}
		break;
	}

  return FALSE;
}

/*
 * Buffering dialog box message function
 *
 */

DWORD WINAPI OpenHTTPThreadFunc( LPVOID lpData)
{
	char *url;

	url = (char *) lpData;
	OpenFileForPlaying(hwnd, url, INPUT_TYPE_HTTP);

	return 0;
}

int APIENTRY BuffDlgProc (HWND hDlg, WORD wMsg, LONG wParam, LONG lParam)
{
  DWORD id = 0;

  switch (wMsg)
    {
      case WM_INITDIALOG:

		  SetTimer(hDlg, 0xF8, 100, NULL);

		  urlW = hDlg;

		  return (0);
		break;

      case WM_SYSCOMMAND:
        if (wParam == SC_CLOSE)
          {

			urlW = NULL;

            EndDialog (hDlg, TRUE);
            return (TRUE);
          }
        break;

	  case WM_COMMAND:

        switch (wParam)
		{
		  case IDB_ABOUT_OK:
			
			  EndDialog(hDlg, TRUE);
			  return TRUE;
			  break;

		  default:
			  return 0;
		}
		break;

	  case WM_TIMER:

		  if(playback) {

			  DWORD progress = playback->GetBufferingState();

			  SendMessage(GetDlgItem(hDlg, IDC_PROGRESS), PBM_SETPOS, (WPARAM) progress, 0);

			  if(progress == 100) {

				  EndDialog(hDlg, TRUE);
				  return TRUE;
			  }
		  }

		  break;
	}

  return FALSE;
}


/*
 * Skin Browser Message Function
 *
 */

int APIENTRY SkinBrowserDlgProc (HWND hDlg, WORD wMsg, LONG wParam, LONG lParam)
{
  int first = 0;

  switch (wMsg)
    {
      case WM_INITDIALOG:

		  int nItem, i;
		  
		  /*
		   * Init the list of skins
		   */
			

		  SendMessage(GetDlgItem(hDlg, IDC_SKIN_LIST), LB_ADDSTRING, 0, (LONG) "[Default Skin]");
		  SendMessage(GetDlgItem(hDlg, IDC_SKIN_LIST), LB_SETCURSEL, 0, 0); 
		  
		  if(skinList->skinsDir != NULL) {

			  SendMessage(GetDlgItem(hDlg, IDC_COMBO_DIR), CB_ADDSTRING, 0, (LONG)skinList->skinsDir);
		      SendMessage(GetDlgItem(hDlg, IDC_COMBO_DIR), CB_SETCURSEL, 0, 0);
		  }

		  skinList->Scan();

		  for(i=0; i < skinList->getNumberOfSkins(); i++) {
		  
			  SendMessage(GetDlgItem(hDlg, IDC_SKIN_LIST), LB_ADDSTRING, 0, (LONG) skinList->getSkinInfo(i)->name);

			  if(strcmp(skinList->getSkinInfo(i)->directory, skinPath) == 0) {

				  SendMessage(GetDlgItem(hDlg, IDC_SKIN_LIST), LB_SETCURSEL, 0, 0); 
			  }
		  }

		  return (0);
		break;

      case WM_SYSCOMMAND:
        if (wParam == SC_CLOSE)
          {
          EndDialog (hDlg, TRUE);
          return (TRUE);
          }
        break;

	  case WM_COMMAND:

	    switch (LOWORD(wParam))  {
		  
          case IDC_SKIN_LIST: 
              
			  switch (HIWORD(wParam)) { 
                  
			  case LBN_SELCHANGE:
				  
				  int nItem;

				  nItem = SendMessage(GetDlgItem(hDlg, IDC_SKIN_LIST), LB_GETCURSEL, 0, 0); 

				  if(nItem < skinList->getNumberOfSkins()) {
					  
					  RECT rect;

					  skin->Load(skinList->getSkinInfo(nItem)->directory, hwnd);

					  strcpy(skinPath, skinList->getSkinInfo(nItem)->directory);

					  GetClientRect(hwnd, &rect);
					  InvalidateRect(hwnd, &rect, TRUE); 
 					  UpdateWindow(hwnd);
				  }
				  else {
					  
					  RECT rect;

					  skin->LoadDefault(hInstance, hwnd);

					  strcpy(skinPath, "Default");

					  GetClientRect(hwnd, &rect);
					  InvalidateRect(hwnd, &rect, TRUE); 
 					  UpdateWindow(hwnd);

				  }

				  break;
			  }
		}

        switch (wParam)
		{
		  case IDB_SKINS_OK:
			
			  EndDialog(hDlg, TRUE);
			  return TRUE;
			  break;
		  
		  case ID_SKINS_CANCEL:
			
			  EndDialog(hDlg, TRUE);
			  return TRUE;
			  break;

		  case IDC_CHANGE_DIR:

			  dirChooser = new CDirDialog();

			  if(dirChooser->DoBrowse()) {
				
				skinList->SetDir(dirChooser->m_strPath);

				SendMessage(GetDlgItem(hDlg, IDC_COMBO_DIR), CB_RESETCONTENT, 0, 0);
				SendMessage(GetDlgItem(hDlg, IDC_SKIN_LIST), LB_RESETCONTENT, 0, 0);

				SendMessage(GetDlgItem(hDlg, IDC_SKIN_LIST), LB_ADDSTRING, 0, (LONG) "[Default Skin]");
				SendMessage(GetDlgItem(hDlg, IDC_SKIN_LIST), LB_SETCURSEL, 0, 0); 
			
				if(skinList->skinsDir != NULL) {
	
				  SendMessage(GetDlgItem(hDlg, IDC_COMBO_DIR), CB_ADDSTRING, 0, (LONG)skinList->skinsDir);
			      SendMessage(GetDlgItem(hDlg, IDC_COMBO_DIR), CB_SETCURSEL, 0, 0);
			  }

			  skinList->Scan();

			  for(i=0; i < skinList->getNumberOfSkins(); i++) {
			  
				  SendMessage(GetDlgItem(hDlg, IDC_SKIN_LIST), LB_ADDSTRING, 0, (LONG) skinList->getSkinInfo(i)->name);

				  if(strcmp(skinList->getSkinInfo(i)->directory, skinPath) == 0) {
	
					  SendMessage(GetDlgItem(hDlg, IDC_SKIN_LIST), LB_SETCURSEL, 0, 0); 
				  }
			  }	
			
			  }
			  break;

		  default:
			  return 0;
		}
		break;
	}

  return FALSE;
}

/*
 * Open URL dialog box message function
 *
 */

int APIENTRY UrlDlgProc (HWND hDlg, WORD wMsg, LONG wParam, LONG lParam)
{

  switch (wMsg)
    {
      case WM_INITDIALOG:

		  SendMessage(GetDlgItem(hDlg, IDC_RADIO_HTTP), BM_SETCHECK, BST_CHECKED, 0);

		  EnableWindow(GetDlgItem(hDlg, IDC_STATIC_FTP_USERNAME), FALSE);
		  EnableWindow(GetDlgItem(hDlg, IDC_STATIC_FTP_PASSWORD), FALSE);
		  EnableWindow(GetDlgItem(hDlg, IDC_CHECK_ANONYMOUS),     FALSE);
		  EnableWindow(GetDlgItem(hDlg, IDC_STATIC_FTP_SERVER),   FALSE);
		  EnableWindow(GetDlgItem(hDlg, IDC_COMBO_FTP),           FALSE);
		  EnableWindow(GetDlgItem(hDlg, IDC_EDIT_USERNAME),       FALSE);
		  EnableWindow(GetDlgItem(hDlg, IDC_EDIT_PASSWORD),       FALSE);

		  return (0);
		break;

      case WM_SYSCOMMAND:

        if (wParam == SC_CLOSE) {

            EndDialog (hDlg, TRUE);
            return (TRUE);
        }
        break;

	  case WM_COMMAND:

        switch (wParam)
		{

		case IDC_RADIO_HTTP:

		    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_FTP_USERNAME), FALSE);
		    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_FTP_PASSWORD), FALSE);
		    EnableWindow(GetDlgItem(hDlg, IDC_CHECK_ANONYMOUS),     FALSE);
		    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_FTP_SERVER),   FALSE);
		    EnableWindow(GetDlgItem(hDlg, IDC_COMBO_FTP),           FALSE);
		    EnableWindow(GetDlgItem(hDlg, IDC_EDIT_USERNAME),       FALSE);
		    EnableWindow(GetDlgItem(hDlg, IDC_EDIT_PASSWORD),       FALSE);
			
		    EnableWindow(GetDlgItem(hDlg, IDC_COMBO_HTTP),  TRUE);
		    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_HTTP), TRUE);
			break;

		case IDC_RADIO_FTP:

		    EnableWindow(GetDlgItem(hDlg, IDC_CHECK_ANONYMOUS),     TRUE);
		    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_FTP_SERVER),   TRUE);
		    EnableWindow(GetDlgItem(hDlg, IDC_COMBO_FTP),    TRUE);
			
		    EnableWindow(GetDlgItem(hDlg, IDC_COMBO_HTTP),  FALSE);
		    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_HTTP), FALSE);

			anonymous = 1;
		    CheckDlgButton(hDlg, IDC_CHECK_ANONYMOUS, TRUE);
			break;

		case IDC_CHECK_ANONYMOUS:

			anonymous = anonymous ? 0 : 1;

			if(anonymous) {

			    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_FTP_USERNAME), FALSE);
			    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_FTP_PASSWORD), FALSE);
			    EnableWindow(GetDlgItem(hDlg, IDC_EDIT_USERNAME),       FALSE);
			    EnableWindow(GetDlgItem(hDlg, IDC_EDIT_PASSWORD),       FALSE);
			}
			else {

			    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_FTP_USERNAME), TRUE);
			    EnableWindow(GetDlgItem(hDlg, IDC_STATIC_FTP_PASSWORD), TRUE);
			    EnableWindow(GetDlgItem(hDlg, IDC_EDIT_USERNAME),       TRUE);
			    EnableWindow(GetDlgItem(hDlg, IDC_EDIT_PASSWORD),       TRUE);
			}

			break;

		case IDB_URL_OK:
			
			DWORD http;
			EndDialog(hDlg, TRUE);

			if(SendMessage(GetDlgItem(hDlg, IDC_RADIO_HTTP), BM_GETCHECK, 0, 0) == BST_CHECKED) {

				char  *url;
				DWORD id, size;

				/*
				 * HTTP
				 */

				url = (char *) malloc(256);

				size = SendMessage(GetDlgItem(hDlg, IDC_COMBO_HTTP), EM_GETLINE, 0, (LONG)(LPVOID)url);
				*(url + size) = '\0';

				if(strstr(url, "http://") != NULL) {

					CreateThread( NULL, 0, OpenHTTPThreadFunc, (LPVOID) url, 0, &id );

					DialogBox (hInstance, (LPCSTR)MAKEINTRESOURCE(IDD_BUFFERING),
						  	   hwnd, (DLGPROC)BuffDlgProc);

					return 0;
				}
			}
			else {

				char  *url;
				DWORD id, size;

				/*
				 * FTP
				 */

				url = (char *) malloc(256);

				size = SendMessage(GetDlgItem(hDlg, IDC_COMBO_FTP), EM_GETLINE, 0, (LONG)(LPVOID)url);
				*(url + size) = '\0';

				if(strstr(url, "ftp://") != NULL) {

					if(anonymous) {
						
						CreateThread( NULL, 0, OpenHTTPThreadFunc, (LPVOID) url, 0, &id );

						DialogBox (hInstance, (LPCSTR)MAKEINTRESOURCE(IDD_BUFFERING),
							  	   hwnd, (DLGPROC)BuffDlgProc);
					
						return 0;
					}
					else {

						/*
						 * Not implemented yet.
						 *
						 */

					}
				}
			}
			  
			return TRUE;
			break;

		case IDB_URL_CANCEL:
			
			EndDialog(hDlg, TRUE);
			return TRUE;
			break;

		default:
		  return 0;
		}
		break;
	}

  return FALSE;
}

/*
 * Main function
 */

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{ 
	POINT pt;
    MSG Msg;
    WNDCLASS W;
	DWORD i;

	hInstance = hInst;

	oldPt.x = 0;
	oldPt.y = 0;
	showing_cursor = 1;

	/*
	 * Open the log file
	 */

#ifdef _DEBUG_

	debug_file = fopen("c:\\playa.txt", "wt");

#endif

	/*
	 * Load the options
	 *
	 */

    strcpy(skinPath, "Default");
	LoadOptions();

	/*
     * init the video subsystem 
     *
     */

   playback = new Playback();
   playlist = new Playlist();
   skinList = new SkinList();
   resizer  = new Resizer();

   playback->SetLoop(options.loop);

   clientRect.left   = 0;
   clientRect.right  = DEFAULT_SKIN_WIDTH;
   clientRect.top    = 0;
   clientRect.bottom = DEFAULT_SKIN_HEIGHT;
   
   windowRect.left   = 0;
   windowRect.right  = DEFAULT_SKIN_WIDTH;
   windowRect.top    = 0;
   windowRect.bottom = DEFAULT_SKIN_HEIGHT;

   AdjustWindowRect(&windowRect, WS_OVERLAPPEDWINDOW, 0);


   /*
    * Window Class
    */

   memset(&W, 0, sizeof(WNDCLASS));
   
   W.style         = CS_HREDRAW | CS_VREDRAW | CS_PARENTDC;
   W.lpfnWndProc   = WndProc;
   W.hInstance     = hInst;
   W.hbrBackground = (HBRUSH)(0);
   W.hCursor       = LoadCursor(hInst, MAKEINTRESOURCE(IDC_CURSOR1));
   W.hIcon         = LoadIcon(hInst, MAKEINTRESOURCE(IDB_ICON));
   W.lpszClassName = Name;
   W.lpszMenuName  = NULL;


   RegisterClass(&W);

   /*
    * Load the menu and change 
	* it for recent file list
    */

   HMENU             menu;
   MENUITEMINFO itemInfo;

   popupMenu = LoadMenu(hInst, MAKEINTRESOURCE(IDR_MENU1));

   menu = GetSubMenu(popupMenu, 0);
   menu = GetSubMenu(menu, 5);
   
   if(RecentFiles[0] != NULL) {

	   RemoveMenu(menu, 0, MF_BYPOSITION);
   
		/*
		 * Now add the files
		 */
   
	   for(i=0; i < 5; i++) {
	   
		   if(RecentFiles[i] != NULL) {

			   itemInfo.cbSize = sizeof(MENUITEMINFO);
			   itemInfo.fMask  = MIIM_DATA | MIIM_TYPE | MIIM_ID;
			   itemInfo.fType  = MFT_STRING;
			   itemInfo.dwTypeData = RecentFiles[i];
			   itemInfo.cch = strlen(RecentFiles[i]);
			   itemInfo.wID = ID_RECENT_FILE1 + i;
		   
			   InsertMenuItem(menu, GetMenuItemCount(menu), TRUE, &itemInfo);
			}
	   }
   }


   /*
    * Create the main window
    *
    */

   hwnd = CreateWindow( Name, Name, WS_OVERLAPPEDWINDOW, 100, 30, 
						windowRect.right - windowRect.left, 
						windowRect.bottom - windowRect.top, 
						NULL, NULL, hInst, NULL);
   
   /*
    * Set the window Rgn
    *
    */

		GetClientRect(hwnd, &clientRect);
		GetWindowRect(hwnd, &windowRect);

		pt.x = clientRect.left;
		pt.y = clientRect.top;

		ClientToScreen(hwnd, &pt);

		pt2.x = clientRect.right;
		pt2.y = clientRect.bottom;

		ClientToScreen(hwnd, &pt2);

		SetWindowRgn(hwnd, CreateRectRgn( pt.x  - windowRect.left, 
			  							  pt.y  - windowRect.top,
										  (windowRect.right - windowRect.left) - (windowRect.right - pt2.x),
										  (windowRect.bottom - windowRect.top) - (windowRect.bottom - pt2.y)), TRUE); 
   /*
    * Register for Drag n' Drop
    */

   DragAcceptFiles(hwnd, TRUE);

   /*
    * And Start TIMER
    *
    */

	SetTimer(hwnd, TIMER_ID, TIMER_RATE, NULL);

	/*
	 * Load Accelerators
	 */

	hAccel = LoadAccelerators(hInst, MAKEINTRESOURCE(IDR_ACCELERATOR));	

	/*
	 * Set the icon
	 */

	SetClassLong(hwnd, GCL_HICON, (LONG) LoadIcon(hInst, MAKEINTRESOURCE(IDB_ICON))); 
 
	/*
	 * Menu items 
	 */

	CheckMenuItem(popupMenu, (UINT)ID_BILINEAR,     options.use_bilinear ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem(popupMenu, (UINT)ID_ASPECT_RATIO, options.maintain_aspect_ratio ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem(popupMenu, (UINT)ID_LOOP, options.loop ? MF_CHECKED : MF_UNCHECKED);
	CheckMenuItem(popupMenu, (UINT)ID_ON_TOP, options.on_top ? MF_CHECKED : MF_UNCHECKED);

   /*
    * Loads the skin
    *
    */

   skin = new Skin(hInst, hwnd);

   if(strcmp(skinPath, "Default") == 0) {

	   skin->LoadDefault(hInst, hwnd);
   }
   else {
	
	   skin->Load(skinPath, hwnd);
   }

   /*
    * now The buttons
    */

	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);

	GetWindowRect(hwnd, &windowRect);

	if(options.on_top)
		SetWindowPos(hwnd, (HWND) -1,  windowRect.left, windowRect.top, windowRect.right - windowRect.left, windowRect.bottom - windowRect.top, TRUE);

   while (TRUE)
    {

	   /*
		* Get the messages
		*/

	   if (!GetMessage(&Msg, NULL, 0, 0))
		return (int) Msg.wParam;

		if (!TranslateAccelerator(hwnd, hAccel, &Msg)) {
				
			TranslateMessage(&Msg); 
			DispatchMessage(&Msg); 
		} 
		else {
	           
			TranslateMessage(&Msg);
		       DispatchMessage(&Msg);
		}
   }

   return Msg.wParam;
}

/*
 * Opens a specified file for playing
 */

void OpenFileForPlaying(HWND hwnd, char *filename, int type) {

	skin->Display(hwnd, playback);

	RECT rect, windowrect;

	playback->Close();
	
	if(playback->Open(filename, type, hwnd)) {

	/*
	 * First resize the window
	 */

					
	if(playback->OK()) {

		DWORD i;

		GetWindowRect(hwnd, &windowrect); 
		rect.left   = windowrect.left;
		rect.top    = windowrect.top;
		rect.right  = playback->Width() + 15;
		rect.bottom = playback->Height() + 115 + 22 + (playback->has_subtitles && use_subtitles ? 50 : 0);

		MoveWindow( hwnd, rect.left, rect.top, rect.right, rect.bottom, TRUE);

		/*
		 * Update flags
		 */

		playback->SetBilinear(options.use_bilinear);
		playback->SetChangeFullscreenRes(options.change_fullscreen_res);
		playback->SetUseSubtitles(use_subtitles);

		/*
		 * Update recent file list
		 */

		DWORD insert = 1;

		for(i=0; i < 5; i++) {
				
		if(RecentFiles[i] != NULL && strcmp(RecentFiles[i], filename) == 0) {
				insert = 0;
			}
		}

		if(insert && strstr(filename, "http://") == NULL && strstr(filename, "ftp://") == NULL) {
		
			for(i=4; i > 0; i--) {
				
				RecentFiles[i] = RecentFiles[i - 1];
			}

			RecentFiles[0] = (char *) malloc(strlen(filename) + 1);
			strncpy(RecentFiles[0], filename, strlen(filename));
			RecentFiles[0][strlen(filename)] = '\0';
		}

		/*
		 * And update the menu
		 */

		HMENU menu, sub;

		menu = GetSubMenu(popupMenu, 0);
		
		/*
		 * The subtitles and Properties menus
		 */

		EnableMenuItem(menu, (UINT)ID_PROPERTIES, MF_ENABLED);

		if(playback->has_subtitles) {

			sub = GetSubMenu(menu, 17);
			RemoveMenu(sub, 0, MF_BYPOSITION);				
		
			MENUITEMINFO subitemInfo;

		    subitemInfo.cbSize = sizeof(MENUITEMINFO);
			subitemInfo.fMask  = MIIM_DATA | MIIM_TYPE | MIIM_ID;
			subitemInfo.fType  = MFT_STRING;
			subitemInfo.dwTypeData = "Use Subtitles";
			subitemInfo.cch = 13;
			subitemInfo.wID = ID_SUBTITLES;
		   
		    InsertMenuItem(sub, 0, TRUE, &subitemInfo);
		    CheckMenuItem(sub, (UINT)ID_SUBTITLES, use_subtitles ? MF_CHECKED : MF_UNCHECKED);
		}
		else {

			sub = GetSubMenu(menu, 17);
			RemoveMenu(sub, 0, MF_BYPOSITION);				
		
			MENUITEMINFO subitemInfo;

		    subitemInfo.cbSize = sizeof(MENUITEMINFO);
			subitemInfo.fMask  = MIIM_DATA | MIIM_TYPE | MIIM_ID;
			subitemInfo.fType  = MFT_STRING;
			subitemInfo.dwTypeData = "None Available";
			subitemInfo.cch = 14;
			subitemInfo.wID = ID_NONE_SUB;
		   
		    InsertMenuItem(sub, 0, TRUE, &subitemInfo);
			EnableMenuItem(sub, (UINT)ID_NONE_SUB, MF_GRAYED);
		}


		/*
		 * And the recent file list
		 */
		
		menu = GetSubMenu(menu, 5);

		if(RecentFiles[0] != NULL) {

			DWORD count;
			MENUITEMINFO itemInfo;

			count = GetMenuItemCount(menu);

			for(i=0; i < count; i++) {
						
				RemoveMenu(menu, 0, MF_BYPOSITION);				
			}

			/*
			 * Now add the files
			 */
   
		    for(i=0; i < 5; i++) {
	   
			   if(RecentFiles[i] != NULL) {

				  itemInfo.cbSize = sizeof(MENUITEMINFO);
				  itemInfo.fMask  = MIIM_DATA | MIIM_TYPE | MIIM_ID;
				  itemInfo.fType  = MFT_STRING;
				  itemInfo.dwTypeData = RecentFiles[i];
				  itemInfo.cch = strlen(RecentFiles[i]);
				  itemInfo.wID = ID_RECENT_FILE1 + i;
		   
				  InsertMenuItem(menu, GetMenuItemCount(menu), TRUE, &itemInfo);
			   }
		   }
		}

		/*
	 	 * Then play
		 */
		
		playback->Play();
	}
	}
	else {

		/*
		 * File couldn't be opened
		 * so we may have to close the
		 * buffering window...
		 */

		if(urlW != NULL) {
			EndDialog(urlW, 0);
			urlW = NULL;
		}

		MessageBox(NULL, "The location you selected could not be opened", "Error", MB_OK);
	}
}

/*
 * Opens a file:
 */

void fileOpen(HWND hwnd)
{
	OPENFILENAME ofn;
	char szFile[260];
				
	/*
	 * shows a file selector
	 */

	ZeroMemory(&ofn, sizeof(OPENFILENAME));
    ZeroMemory(szFile, 260);

	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hwnd;
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = sizeof(szFile);

	ofn.lpstrFilter = "All\0*.*\0AVI Files\0*.AVI\0\0";
	ofn.nFilterIndex = 2;
	ofn.lpstrFileTitle = "";
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = NULL;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
				
	if (GetOpenFileName(&ofn) == TRUE) {
		
		OpenFileForPlaying(hwnd, ofn.lpstrFile, INPUT_TYPE_FILE);
	}
}

/*
 * Handles events
 */

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{ 
	int xPos, yPos;

	switch(Message) {

	case WM_DESTROY:

#ifdef _DEBUG__
		fclose(debug_file);
#endif
		SaveOptions();
		playback->Close();

		Cleanup();

		PostQuitMessage(0);
		return TRUE;
		break;

	case WM_SYSCOMMAND:
        
		if (wParam == SC_CLOSE)
          {
#ifdef _DEBUG__
			fclose(debug_file);
#endif
			SaveOptions();
			playback->Close();

			Cleanup();

			PostQuitMessage(0);
			return (TRUE);
          }
        break;

	case WM_COMMAND	:
    
		switch(LOWORD(wParam)) {

		case ID_SUBTITLES:

			RECT  wrect;
			HMENU menu;

			menu = GetSubMenu(popupMenu, 0);
			menu = GetSubMenu(menu, 17);

			if(playback != NULL) {

				GetWindowRect(hwnd, &wrect);

				if(use_subtitles) {

					use_subtitles = 0;
					wrect.bottom -= 50;

					MoveWindow(hwnd, wrect.left, wrect.top, wrect.right - wrect.left, wrect.bottom - wrect.top, TRUE);
					CheckMenuItem(menu, (UINT)ID_SUBTITLES, MF_UNCHECKED);

					playback->SetUseSubtitles(use_subtitles);
				}
				else {

					use_subtitles = 1;
					wrect.bottom += 50;

					CheckMenuItem(menu, (UINT)ID_SUBTITLES, MF_CHECKED);
					MoveWindow(hwnd, wrect.left, wrect.top, wrect.right - wrect.left, wrect.bottom - wrect.top, TRUE);

					playback->SetUseSubtitles(use_subtitles);
				}
			}

			break;

		case ID_RECENT_FILE1:

			OpenFileForPlaying(hwnd, RecentFiles[0], INPUT_TYPE_FILE);
			break;

		case ID_RECENT_FILE2:

			OpenFileForPlaying(hwnd, RecentFiles[1], INPUT_TYPE_FILE);
			break;

		case ID_RECENT_FILE3:

			OpenFileForPlaying(hwnd, RecentFiles[2], INPUT_TYPE_FILE);
			break;

		case ID_RECENT_FILE4:

			OpenFileForPlaying(hwnd, RecentFiles[3], INPUT_TYPE_FILE);
			break;

		case ID_RECENT_FILE5:

			OpenFileForPlaying(hwnd, RecentFiles[4], INPUT_TYPE_FILE);
			break;

		case ID_MENU_ABOUT:

            DialogBox (hInstance, (LPCSTR)MAKEINTRESOURCE(IDD_ABOUT_DIALOG),
                        hwnd, (DLGPROC)AboutDlgProc);
						
			break;

		case ID_SKIN_BROWSER:

            DialogBox (hInstance, (LPCSTR)MAKEINTRESOURCE(IDD_SKIN_BROWSER),
                             hwnd, (DLGPROC)SkinBrowserDlgProc);
						
			break;

		case ID_MENU_OPTIONS:

            DialogBox (hInstance, (LPCSTR)MAKEINTRESOURCE(IDD_PREFS),
                             hwnd, (DLGPROC)PreferencesDlgProc);
			break;

		case ID_OPEN_URL:

            DialogBox (hInstance, (LPCSTR)MAKEINTRESOURCE(IDD_URL_DIALOG),
                             hwnd, (DLGPROC)UrlDlgProc);
			break;

		case ID_PROPERTIES:

			DialogBox (hInstance, (LPCSTR)MAKEINTRESOURCE(IDD_PROPERTIES),
                       hwnd, (DLGPROC)PropDlgProc);
			break;

		case ID_OPEN_FILE:
			fileOpen(hwnd);
			break;

		case ID_ON_TOP:

			RECT r;

			options.on_top = options.on_top == 1 ? 0 : 1;				
			CheckMenuItem(popupMenu, (UINT)wParam, options.on_top ? MF_CHECKED : MF_UNCHECKED);
			
			GetWindowRect(hwnd, &r);
			
			SetWindowPos(hwnd, options.on_top ? (HWND) -1 : (HWND) 1,  r.left, r.top, r.right - r.left, r.bottom - r.top, TRUE);

			if(!options.on_top)
				SetWindowPos(hwnd, HWND_TOP,  r.left, r.top, r.right - r.left, r.bottom - r.top, TRUE);
			
			break;

		case ID_LOOP:

			options.loop = options.loop == 1 ? 0 : 1;				
			CheckMenuItem(popupMenu, (UINT)wParam, options.loop ? MF_CHECKED : MF_UNCHECKED);
			
			playback->SetLoop(options.loop);
			
			break;

		case ID_PREVIOUS:

			playback->Rewind();
			break;

		case ID_STOP:

			playback->Stop(TRUE);
			break;
		
		case ID_PLAY:

			if(playback->OK()) {
				
				if(playback->isPaused()) {
					playback->Pause();
				}
				else {
					playback->Play();
				}
			}
			else {

				/*
				 * Load files
				 */
			
				fileOpen(hwnd);
			}

			break;
		
		case ID_PAUSE:

			if(playback->OK()) {

				playback->Pause();
			}

			break;

		case ID_NEXT:

			playback->FastForward();
			break;

			
		case ID_EXIT:

			SaveOptions();
		    DestroyWindow(hwnd);
			break;

		case ID_FULLSCREEN:

			GetWindowRect(hwnd, &fullwindowRect);

			count          = 0;
			showing_cursor = 1;

			playback->SetChangeFullscreenRes(options.change_fullscreen_res);
			playback->Fullscreen(TRUE);
			break;

		case ID_ORIGINAL_SIZE:

			if(playback->isPlaying()) {

				RECT src;

				GetWindowRect(hwnd, &windowRect);

				src.left    = 0;
				src.right   = playback->Width() + 7;
				src.top     = 0;
				src.bottom  = playback->Height() + 110;

				AdjustWindowRect(&src, WS_OVERLAPPEDWINDOW, 0);

				MoveWindow( hwnd, windowRect.left, 
							windowRect.top, 
							src.right - src.left, 
							src.bottom - src.top, TRUE);
			}
			break;

			case ID_HALF_SIZE:

			if(playback->isPlaying()) {

				RECT src;

				GetWindowRect(hwnd, &windowRect);

				src.left    = 0;
				src.right   = playback->Width()/2 + 7;
				src.top     = 0;
				src.bottom  = playback->Height()/2 + 110;

				AdjustWindowRect(&src, WS_OVERLAPPEDWINDOW, 0);

				MoveWindow( hwnd, windowRect.left, 
							windowRect.top, 
							src.right - src.left, 
							src.bottom - src.top, TRUE);
			}
			break;

			case ID_DOUBLE_SIZE:

			if(playback->isPlaying()) {

				RECT src;

				GetWindowRect(hwnd, &windowRect);

				src.left    = 0;
				src.right   = playback->Width()*2 + 7;
				src.top     = 0;
				src.bottom  = playback->Height()*2 + 110;

				AdjustWindowRect(&src, WS_OVERLAPPEDWINDOW, 0);

				MoveWindow( hwnd, windowRect.left, 
							windowRect.top, 
							src.right - src.left, 
							src.bottom - src.top, TRUE);
			}
			break;

			case ID_BILINEAR:

				options.use_bilinear = options.use_bilinear == 1 ? 0 : 1;				
				CheckMenuItem(popupMenu, (UINT)wParam, options.use_bilinear ? MF_CHECKED : MF_UNCHECKED);

				playback->SetBilinear(options.use_bilinear);

				break;

			case ID_ASPECT_RATIO:

				options.maintain_aspect_ratio = options.maintain_aspect_ratio == 1 ? 0 : 1;				
				CheckMenuItem(popupMenu, (UINT)wParam, options.maintain_aspect_ratio ? MF_CHECKED : MF_UNCHECKED);
				break;
		}
	break;

	/*
	 * Timer
	 *
	 */

	case WM_TIMER:

		if(playback && playback->isPlaying() && !playback->fullscreen) {

			if(action != ACTION_PROGRESS_CURSOR) {
				skin->SetProgressValue(hwnd, playback->GetProgress());
			}

			/*
			 * Do time display here
			 */
		}

		if(playback->isInFullscreen() && showing_cursor) {

			count++;

			/*
			 * We wait for 2 secs
			 */ 

			if(count >= 20) {

				ShowCursor(0);
				showing_cursor = 0;
			}
		}


		break;

	/*
	 * Key Press
	 *
	 */

	case WM_KEYUP:

		switch(wParam) {
			
			case VK_ESCAPE:

				if(playback->fullscreen) {

					RECT rect;

					playback->Fullscreen(FALSE);
					ShowCursor(1);

					/*
					 * We need to resize the window to it's original size
					 */

					MoveWindow(hwnd, fullwindowRect.left, fullwindowRect.top, fullwindowRect.right - fullwindowRect.left, 
							   fullwindowRect.bottom - fullwindowRect.top, TRUE);

					GetClientRect(hwnd, &rect);
					InvalidateRect(hwnd, &rect, TRUE); 
 					UpdateWindow(hwnd);

					Sleep(100);

					GetClientRect(hwnd, &rect);
					InvalidateRect(hwnd, &rect, TRUE); 
 					UpdateWindow(hwnd);
				}
				break;

			default:
				break;
		}
		break;

	case WM_LBUTTONDOWN:

		xPos = LOWORD(lParam); 
		yPos = HIWORD(lParam);

		action = skin->GetAction(xPos, yPos);
		skin->SetActionStart(hwnd, action);

		if(action == ACTION_RESIZE) {

			POINT pt;

			pt.x = xPos;
			pt.y = yPos;

			ClientToScreen(hwnd, &pt);

			moveX = pt.x;
			moveY = pt.y;

			GetWindowRect(hwnd, &windowRect);

			SetCapture(hwnd);

			resizer->Start(&pt);
		}

		if(action == ACTION_NONE) {

			/*
			 * We are moving the window
			 */

			action = ACTION_MOVING;

			moveX = xPos;
			moveY = yPos;

			GetWindowRect(hwnd, &windowRect);

			SetCapture(hwnd);
			
			if(!playback->isPaused())
				playback->Pause();
		}

		if(action == ACTION_VOLUME_CURSOR || action == ACTION_PROGRESS_CURSOR) {

			moveX = xPos;
		}

		break;

	case WM_LBUTTONUP:

		skin->SetActionEnd(hwnd, action);

		switch(action) {

		case ACTION_MENU:

			HMENU menu;

			POINT pt;

			pt.x = pt.y = 0;
			ClientToScreen(hwnd, &pt);

			xPos = pt.x + LOWORD(lParam); 
			yPos = pt.y + HIWORD(lParam);

			menu = GetSubMenu(popupMenu, 0);

			TrackPopupMenu( menu, 0, xPos, yPos, 0, hwnd, NULL);
			break;

		case ACTION_CLOSE:

			SaveOptions();

			PostQuitMessage(0);
			break;

		case ACTION_MINIMIZE:

			ShowWindow(hwnd, SW_MINIMIZE);
			break;

		case ACTION_STOP:

			playback->Stop(TRUE);
			break;

		case ACTION_PLAY:

			if(playback->OK()) {
				
				if(playback->isPaused()) {
					playback->Pause();
				}
				else {
					playback->Play();
				}
			}
			else {

				/*
				 * Load files
				 */
			
				fileOpen(hwnd);
			}
			break;

		case ACTION_PAUSE:

			if(playback->OK()) {

				if(playback->isPaused()) {
				
					playback->NextFrame();
				}
				else {
					playback->Pause();
				}
			}
			break;

		case ACTION_FORWARD:

			playback->FastForward();
			break;

		case ACTION_REWIND:

			playback->Rewind();
			break;

		case ACTION_LOAD:
			{
				fileOpen(hwnd);
			}
			break;

		case ACTION_PROGRESS_CURSOR:

			playback->Seek(skin->GetProgress());
			break;

		case ACTION_VOLUME_CURSOR:

			playback->SetVolume(skin->GetVolume());
			break;

		case ACTION_VOLUME_BAR:

			moveX = LOWORD(lParam); 
			skin->SetVolumeCursorX(hwnd, moveX);

			playback->SetVolume(skin->GetVolume());
		
			break;

		case ACTION_PROGRESS_BAR:

			moveX = LOWORD(lParam); 
			skin->SetProgressCursorX(hwnd, moveX);
			playback->Seek(skin->GetProgress());
			break;

		case ACTION_NONE:
		default:
			break;
		}

		if(action == ACTION_MOVING) {

			ReleaseCapture();
			RECT rect;

			GetWindowRect(hwnd, &rect);

			SetWindowPos(hwnd, HWND_TOPMOST, rect.left, rect.top, 
						 rect.right - rect.left, rect.bottom - rect.top, 
						 SWP_SHOWWINDOW | SWP_NOZORDER | SWP_NOACTIVATE);

			if(playback->isPaused())
				playback->Pause();			

			if(playback->isPlaying()) {
			
				GetClientRect(hwnd, &rect);
				InvalidateRect(hwnd, &rect, TRUE); 
 				UpdateWindow(hwnd);
			}
		}

		if(action == ACTION_RESIZE) {

			POINT pt;

			ReleaseCapture();
			resizer->Stop();

			xPos = LOWORD(lParam);
			yPos = HIWORD(lParam);

			pt.x = xPos;
			pt.y = yPos;

			if(xPos > 32768 || yPos > 32768)
				return 0;

			ClientToScreen(hwnd, &pt);

				if(windowRect.right + (pt.x - moveX) - windowRect.left >= skin->DefaultWidth() &&
				   windowRect.bottom + (pt.y - moveY) - windowRect.top >= skin->DefaultHeight()) {

					MoveWindow( hwnd, windowRect.left, 
								windowRect.top, 
								windowRect.right + (pt.x - moveX) - windowRect.left, 
								windowRect.bottom + (pt.y - moveY) - windowRect.top, TRUE);

				}
				else {

					RECT r;

					r.left   = 0;
					r.right  = DEFAULT_SKIN_WIDTH;
					r.top    = 0;
					r.bottom = DEFAULT_SKIN_HEIGHT;

					AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);

					if(windowRect.right + (pt.x - moveX) - windowRect.left >= skin->DefaultWidth()) {

						MoveWindow( hwnd, windowRect.left, 
									windowRect.top, 
									windowRect.right + (pt.x - moveX) - windowRect.left, 
									r.bottom - r.top + 2, TRUE);

					}
					else {

						if(windowRect.bottom + (pt.y - moveY) - windowRect.top >= skin->DefaultHeight()) {
							
							MoveWindow( hwnd, windowRect.left, 
										windowRect.top, 
										r.right - r.left + 2, 
										windowRect.bottom + (pt.y - moveY) - windowRect.top, TRUE);
						}
						else {

							MoveWindow( hwnd, windowRect.left, 
										windowRect.top, 
										r.right - r.left + 2, 
										r.bottom - r.top + 2, TRUE);
						}
					}
				}

				moveX = pt.x;
				moveY = pt.y;
			}

		action = ACTION_NONE;

		break;

	case WM_MOUSEMOVE:

		count = 0;

		if(playback->isInFullscreen() && !showing_cursor) {
		
			ShowCursor(1);
			showing_cursor = 1;
		}

		if(action == ACTION_MOVING) {

			RECT   r;
			POINT pt;

			xPos = LOWORD(lParam); 
			yPos = HIWORD(lParam);

			GetClientRect(hwnd, &r);

			if(xPos > 16768) {

				xPos = 1;
			}
			else {
				if(xPos >= (r.right - r.left))
					xPos = r.right - r.left - 1;
			}

			if(yPos > 16768) {

				yPos = 1;	
			}
			else {

				if(yPos >= (r.bottom - r.top))
					yPos = r.bottom - r.top - 1;
			}

			pt.x = xPos;
			pt.y = yPos;

			ClientToScreen(hwnd, &pt);

			MoveWindow( hwnd, pt.x - moveX, 
						pt.y - moveY - 22, 
						windowRect.right - windowRect.left, 
						windowRect.bottom - windowRect.top, TRUE);
		}

		if(action == ACTION_RESIZE) {

			POINT pt;

			pt.x = LOWORD(lParam);
			pt.y = HIWORD(lParam);
	
			resizer->Draw(hwnd, &pt);

  
		}

		if(action == ACTION_VOLUME_CURSOR) {

			moveX = LOWORD(lParam); 
			skin->SetVolumeCursorX(hwnd, moveX);

			playback->SetVolume(skin->GetVolume());
		}

		if(action == ACTION_PROGRESS_CURSOR) {

			moveX = LOWORD(lParam); 
			skin->SetProgressCursorX(hwnd, moveX);
		}

		break;

	case WM_RBUTTONDOWN:

		if(!playback->fullscreen) {

			HMENU menu;
			POINT pt1;
			int   x, y;

			pt1.x = pt1.y = 0;
			ClientToScreen(hwnd, &pt1);

			x = pt1.x + LOWORD(lParam); 
			y = pt1.y + HIWORD(lParam);

			menu = GetSubMenu(popupMenu, 0);

			TrackPopupMenu( menu, 0, x, y, 0, hwnd, NULL);
		}
		break;

	case WM_SIZE:

		RECT  clientRect, windowRect;
		POINT other_pt;

		GetClientRect(hwnd, &clientRect);
		GetWindowRect(hwnd, &windowRect);

		other_pt.x = clientRect.left;
		other_pt.y = clientRect.top;

		ClientToScreen(hwnd, &other_pt);

		pt2.x = clientRect.right;
		pt2.y = clientRect.bottom;

		ClientToScreen(hwnd, &pt2);

	    SetWindowRgn(hwnd, CreateRectRgn( other_pt.x  - windowRect.left, 
			  							  other_pt.y  - windowRect.top,
										  (windowRect.right - windowRect.left) - (windowRect.right - pt2.x),
										  (windowRect.bottom - windowRect.top) - (windowRect.bottom - pt2.y)), TRUE); 

		break;

	case WM_PAINT:

		skin->UpdateSize(hwnd);
		skin->Display(hwnd, playback);
		return 0;
		break;

	case WM_DROPFILES:

		char lpFilename[256];

		if(DragQueryFile( (HDROP) wParam, 0, lpFilename, 256) > 0)  {

			OpenFileForPlaying(hwnd, lpFilename, INPUT_TYPE_FILE);
		}
		break;

	}

  return DefWindowProc(hwnd, Message, wParam, lParam);
}
