/**************************************************************************************
 *                                                                                    *
 * This application contains code from OpenDivX and is released as a "Larger Work"    *
 * under that license. Consistant with that license, this application is released     *
 * under the GNU General Public License.                                              *
 *                                                                                    *
 * The OpenDivX license can be found at: http://www.projectmayo.com/opendivx/docs.php *
 * The GPL can be found at: http://www.gnu.org/copyleft/gpl.html                      *
 *                                                                                    *
 * Copyright (c) 2001 - Project Mayo                                                  *
 *                                                                                    *
 * Authors: Damien Chavarria <adrc at projectmayo.com>                                *
 *                                                                                    *
 **************************************************************************************/

#include <stdio.h>
#include <stdlib.h>

typedef struct _list_t {


	char *filename;
	struct _list_t *next;

} list_t;

/*
 * The playlist class
 */

class Playlist {

private:

	int     nbr_items;
	int     current_position;
	list_t *list;

	char *GetItemAt(int i);

public:

	Playlist();
	~Playlist();

	int   Clear();
	int   Reset();
	int   Add(char *filename);
	char *Previous();
	char *Next();

};