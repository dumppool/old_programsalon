Since I am clumsy at English writing, I put it briefly.

- The development of DVD2AVI is based on MSSG MPEG2Decode
  http://www.mpeg.org/MPEG/MSSG/ and adds features as follows:

  1. GUI interface (gui.cpp)
  2. VFAPI support (vfapi.c vfapidec.c)
  3. AC3/MPA/LPCM demux (getbit.c)
  4. Auto-split AVI output through RGB24/YUY2 (store.c)
  5. YUY2 DirectDraw Overlay (store.c gui.cpp)
  6. revised I/O routine (getbit.c getbic.h)
  7. MMX-optimized motion compensation (recon.c getpic.c)
  8. MMX-optimized color space conversion (store.c)
  9. audio normalization (norm.c)

- The author of TMPGEnc, Hiroyuki Hori, defines the spec of VFAPI (Video File API).
  You can find the Delphi-based VFAPI SDK on his page.
  http://www.yks.ne.jp/~hori/VFAPI.html

- The development of VFAPI Plug-In refers to MPEG-2 VIDEO VFAPI Plug-In
  developed by Kazuhiro Mogi. It's helpful to C programmers.
  http://www.isc.meiji.ac.jp/~ee69011/mpeg2/

- MMX 32-bit iDCT is implanted from Royce Liao's MPEG2AVI 0.16B34.
  http://members.tripod.com/~liaor/

- Floating Point and Reference iDCT are implanted from Miha's hand-tuned iDCT.
  http://miha.peternel.homepage.com/idct.html

- Dolby Digital decoding (AC3Dec) is implanted from LiViD Project developed by
  Aaron Holtzman. http://linuxvideo.org/

- 48->44.1KHz downsampling (wavefs44.c) is implanted from WAVEFS44 developed by WTC.
  http://www.asahi-net.or.jp/~mp4m-truc/SOUND/WTC/WAVECONV.HTM

* Known Bugs *

1. DVD2AVI only aligns the start point of A/V streams.
   If the movie is not encoded at once that PTS restarts (such as bonus track or
   different episodes) It's possible to lose synchronization from the break point. 

2. DVD2AVI treats all Linear PCM as 16bit/48KHz/Stereo without header identification.

                             2000/01/31 by Chia-chen Kuo, jackei@arbor.ee.ntu.edu.tw