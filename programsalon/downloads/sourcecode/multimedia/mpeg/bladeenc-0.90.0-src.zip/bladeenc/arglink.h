/*
			(c) Copyright 1999 - Tord Jansson
			=================================

		This file is part of the BladeEnc MP3 Encoder, based on
		ISO's reference code for MPEG Layer 3 compression.

		This file doesn't contain any of the ISO reference code and
		is copyright Tord Jansson (tord.jansson@swipnet.se).

	BladeEnc is free software; you can redistribute this file
	and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.

*/


typedef struct argLinkDef	argLink;

struct argLinkDef
{
	argLink	* psNext;
	char		* pString;
};


argLink * findStrInArgLink( argLink * pLink, char * pString );
argLink * argv2ArgLink( int argc, char * argv[] );
argLink * insertStringInArgLink( argLink ** wpPrev, char * pString );
argLink * linkStringToArgLink( argLink ** wpPrev, char * pString );
int		  addFileContentToArgLink( argLink ** wpPrev , char * pFilename );
void	  deleteArgLink( argLink * pLink );

