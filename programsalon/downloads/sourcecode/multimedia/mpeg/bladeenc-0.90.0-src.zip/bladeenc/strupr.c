/* Function: strupr
   Input:    char *     - String to convert
   Output:   char *     - Converted string
   Converts the string to uppercase.
   Added by Trevor Phillips, 25/6/98, for Solaris port. */
char *mystrupr(char * strng)
{
	unsigned int i;

	for ( i = 0 ; strng[i] != 0 ; i++ )
		if (strng[i]>='a' && strng[i]<='z')
			strng[i]+='A'-'a';

	return strng;
}
