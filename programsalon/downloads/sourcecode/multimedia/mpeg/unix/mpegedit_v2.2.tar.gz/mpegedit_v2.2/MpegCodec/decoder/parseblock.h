/* function prototypes for parseblock.c */
#ifndef __PARSEBLOCK__
#define  __PARSEBLOCK__
#include "decls.h"
__BEGIN_DECLS
extern void ParseReconBlock(int n);
extern void ParseAwayBlock(int n);
__END_DECLS
#endif
