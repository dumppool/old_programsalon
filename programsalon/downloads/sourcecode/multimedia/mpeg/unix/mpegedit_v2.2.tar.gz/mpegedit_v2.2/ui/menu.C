/*********************************************************/
/* MENU                                                  */
/*   This class provides a popup menu system, which      */
/*   consists of a menu bar at the top of the parent     */
/*   window.  When an option is selected from this bar   */
/*   another window pops up, giving a list of the        */
/*   options for this menu.  The respective callback     */
/*   is called if one of the options is selected.  If    */
/*   the user clicks in any other window, the popup is   */
/*   closed.                                             */
/*                                                       */
/*                      (c)1994 Alexis 'Milamber' Ashley */
/*********************************************************/
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "menu.H"
#include <assert.h>
#include <string.h>

char Menu::Foreground[80]     = "Midnight Blue";
char Menu::Background[80]     = "Ivory";
char Menu::DisabledColour[80] = "gray55";
char Menu::FontName[80]       = "*-helvetica-bold-*-140-*";
const unsigned int Menu::BorderWidth = 2;


Menu::Menu(MainWindow *parent,const char * const names[20])
: UI_Globals(parent)
{
  XColor tmp_col;
  XGCValues xgcv;
  Window win_id;
  unsigned long mask;
  unsigned int label_x,height,width;
  opt_list resources[] =
    {
      { "menu.foreground" , Foreground     },
      { "menu.background" , Background     },
      { "menu.disabled"   , DisabledColour },
      { "menu.font"       , FontName       },
      { "" , NULL }
    };

// Check for X resources
  CheckResources(resources);

// Blank the menu item structure

  for(int n=0; n<20; n++)
    {
      m_item[n].name = NULL;
      m_item[n].x1_pos = 0;
      m_item[n].x2_pos = 0;
      m_item[n].first_option = NULL;
    }

// Load the font FontName into memory

  Menu_Font = XLoadQueryFont(DispPointer(),FontName);
  assert(Menu_Font!=NULL);

// Build the menu font structure, now that we can work out how wide each
// option is

  label_x = x_spacing();
  int i=0;
  while(names[i+1]!=NULL)
    {
      m_item[i].name = new char[strlen(names[i])+1];
      assert(m_item[i].name != NULL);
      strcpy(m_item[i].name,names[i]);
      m_item[i].x1_pos=label_x;
      label_x += XTextWidth(Menu_Font,names[i],strlen(names[i]));
      m_item[i].x2_pos=label_x;
      label_x += x_spacing();
      m_item[i].first_option = NULL;
      i++;
    }

// The width of the menu is the width of the parent window minus borders

  width = parent->width()-2*BorderWidth;

// height of menu = height of the tallest piece of text + spacing

  height=Menu_Font->max_bounds.ascent+Menu_Font->max_bounds.descent
         +y_spacing();

// Now put the last option on the far right hand side of the window

  m_item[i].name = new char[strlen(names[i])+1];
  assert(m_item[i].name != NULL);
  strcpy(m_item[i].name,names[i]);
  m_item[i].x1_pos=width-x_spacing()-
                  XTextWidth(Menu_Font,names[i],strlen(names[i]));
  m_item[i].x2_pos=parent->width()-x_spacing();
  m_item[i].first_option = NULL;

// Try to allocate the foreground, background & disabled option colours from X
// If this fails, use black & white

  if(XParseColor(DispPointer(),Colourmap,Foreground ,&tmp_col)==0 ||
     XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
     fg_colour = Black;
  else
     fg_colour = tmp_col.pixel;
  if(XParseColor(DispPointer(),Colourmap,Background,&tmp_col)==0 ||
     XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
     bg_colour = White;
  else
     bg_colour = tmp_col.pixel;
  if(XParseColor(DispPointer(),Colourmap,DisabledColour ,&tmp_col)==0 ||
     XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
     off_colour = Black;
  else
     off_colour = tmp_col.pixel;

// Create the window

  win_id=XCreateSimpleWindow(DispPointer(),parent->WinId(),0,0,width,height,
			     BorderWidth,Black,bg_colour);

// Register this window with UI_Globals, so that it will receive events

  RegisterWindow(this,win_id,height,width);

// Set that there is no menu opt currently active

  active_option = -1;

// Build the GCs that will be used for this window

  xgcv.foreground = fg_colour;
  xgcv.background = bg_colour;
  xgcv.font = Menu_Font->fid;
  mask = GCForeground | GCBackground | GCFont;
  GraphicsContext = XCreateGC(DispPointer(),win_id,mask,&xgcv);
  xgcv.foreground = off_colour;
  OffGraphicsContext = XCreateGC(DispPointer(),win_id,mask,&xgcv);

// Tell X what events we want reported to us

  XSelectInput(DispPointer(),win_id,ExposureMask | ButtonPressMask |
	       ButtonReleaseMask);

// Map the window

  XMapWindow(DispPointer(),win_id);

// Finished....
}

Menu::~Menu(void)
{
  colour cols[]={fg_colour,bg_colour,off_colour};
  int i;

// Free the colours that were allocated by the menu window, being careful 
// not to try to de-allocate black or white, as they are read-only colours

  for(i=0; i<3; i++)
    if(cols[i]!=White && cols[i]!=Black)
      XFreeColors(DispPointer(),Colourmap,&cols[i],1,0);

// Free the font that was loaded

  XFreeFont(DispPointer(),Menu_Font);

// Destroy the graphics contexts that were created for this window

  XFreeGC(DispPointer(),GraphicsContext);
  XFreeGC(DispPointer(),OffGraphicsContext);

// Destory all the data that was allocated in the constructor function

  for(i=0; i<20; i++)
    {
      delete m_item[i].name;
      if(m_item[i].first_option != NULL)
	{
	  option *ptr1=m_item[i].first_option;
	  option *ptr2;
	  while(ptr1!= NULL)
	    {
	      ptr2 = ptr1;
	      ptr1 = ptr1->next;
	      delete ptr2;
	    }
	}
    }
}

Menu::MenuID *Menu::attach(int position,const char * const label, char hotkey,
	 status (*callback)(byte *), byte *callback_data,bool enabled)
{
  MenuID *retval;
  int depth = 0;

  retval = new MenuID;
  assert(retval!=NULL);
  retval->position = -1;
  retval->depth = -1;
  if(position<0 || position>19 || m_item[position].name==NULL)
    return(retval);
  option *ptr=m_item[position].first_option;
  if(ptr!=NULL)
    {
      depth++;
      while(ptr->next!=NULL)
	{
	  ptr = ptr->next;
	  depth++;
	}
      ptr->next = new option;
      ptr=ptr->next;
    }
  else
    {
      ptr = new option;
      m_item[position].first_option = ptr;
    }
  ptr->name = new char[strlen(label)+1];
  assert(ptr->name!=NULL);
  strcpy(ptr->name,label);
  ptr->hotkey = hotkey;
  ptr->enabled = enabled;
  ptr->callback = callback;
  ptr->callback_data = callback_data;
  ptr->next = NULL;
  retval->position = position;
  retval->depth = depth;
  return(retval);
}

int Menu::Enable_Option(const MenuID * const id)
{
  int i;

  if(id->position<0 || id->position>19)
    return(-1);
  option *ptr=m_item[id->position].first_option;
  for(i=0; i<(id->depth) && ptr!=NULL; i++)
    ptr = ptr->next;
  if(i==id->depth)
    {
      ptr->enabled = true;
      return(0);
    }
  return(1);    
}

int Menu::Disable_Option(const MenuID * const id)
{
  int i;

  if(id->position<0 || id->position>19)
    return(-1);
  option *ptr=m_item[id->position].first_option;
  for(i=0; i<(id->depth) && ptr!=NULL; i++)
    ptr = ptr->next;
  if(i==id->depth)
    {
      ptr->enabled = false;
      return(0);
    }
  return(1);    
}

Menu::status Menu::event_handler(XEvent *Event)
{
  if(active_option!=-1)
    return(SubMenu_event_handler(Event));
  return(MainMenu_event_handler(Event));
}

Menu::status Menu::MainMenu_event_handler(XEvent *Event)
{
  status retval=okay;

  switch(Event->type)
    {
    case Expose:
      if(Event->xexpose.count ==0)
	{
	  int i=0;
	  XClearWindow(DispPointer(),WinId());
	  while(m_item[i].name != NULL)
	    {
	      XDrawString(DispPointer(),WinId(),GraphicsContext,
			  m_item[i].x1_pos,height()-y_spacing(),
			  m_item[i].name,strlen(m_item[i].name));
	      i++;
	    }
	}
      break;
    case ButtonPress:
      {
	int i=0;
	int abs_x, abs_y, x, y;
	Window root,child;
	unsigned int buttons;

	if(XQueryPointer(DispPointer(),WinId(),&root,&child,&abs_x,
			  &abs_y,&x,&y,&buttons)==True)
	  {
	    while(m_item[i].name != NULL && i<20)
	      {
		if(x>m_item[i].x1_pos && x<m_item[i].x2_pos)
		  retval=SubMenu_handler(i);
		i++;
	      }
	  }
      }
      break;
    }
  return(retval);
}

Menu::status Menu::SubMenu_handler(int pos)
{
  if(m_item[pos].first_option!=NULL)
    {
      int win_height=0;
      int win_width=0;
      int win_x;
      int temp_width;
      XSetWindowAttributes xswa;

/* The following code works out how big the sub menu window needs to be */

      option *ptr=m_item[pos].first_option;
      while(ptr!=NULL)
	{
	  temp_width = XTextWidth(Menu_Font,ptr->name,strlen(ptr->name));
	  if(temp_width>win_width)
	    win_width = temp_width;
	  win_height += height();
	  ptr = ptr->next;
	}
      win_width += 2*x_spacing();

/* Now that the window's size has been calculated, we have to calculate its */
/* position.  This is with the left hand of the window in line with the */
/* menu item's left hand side, unless this would cause the window to fall */
/* off the edge of the main window, when it is move left so that its right */
/* hand side is at the edge of the main window */

      win_x = m_item[pos].x1_pos;
      if(win_x+win_width>width())
	win_x=width()-win_width;

/* Now create the sub window + fill in the context structure for this window */

      PopupContext.Parent = Parent();
      popup_win_id=XCreateSimpleWindow(DispPointer(),
				       PopupContext.Parent->WinId(),
				       win_x,height(),win_width,win_height,1,
				       Black,bg_colour);
      xswa.save_under = True;
      XChangeWindowAttributes(DispPointer(),popup_win_id,CWSaveUnder,&xswa);
      PopupContext.This = this;
      int temp = XSaveContext(DispPointer(),popup_win_id,
			      Contexts,XPointer(&PopupContext));
      assert(temp==0);
      XSelectInput(DispPointer(),popup_win_id,ExposureMask|ButtonPressMask);
      XMapWindow(DispPointer(),popup_win_id);
      active_option = pos;
      RestrictEvents(&popup_win_id,1);
      submenu_exit_var=0;
      EventHandler();
      UnrestrictedEvents();
      active_option = -1;
/* Destroy the context data that was used for the expose & press events */
      temp = XDeleteContext(DispPointer(),popup_win_id,Contexts);
      assert(temp==0);
/* Destroy the actual window itself */
      XDestroyWindow(DispPointer(),popup_win_id);
/* If submenu_exit_var>1, then an option was chosen from a menu. Therefore we*/
/* need to call its callback function.  This code finds its callback, then   */
/* calls it.                                                                 */
      if(submenu_exit_var>1)
	{
	  submenu_exit_var -= 2;
	  ptr=m_item[pos].first_option;
	  for(int i=0; i<submenu_exit_var; i++)
	    {
	      ptr = ptr->next;
	      assert(ptr!=NULL);
	    }
	  if(ptr->enabled)
	    {
	      XFlush(DispPointer());
	      return((*(ptr->callback))(ptr->callback_data));
	    }
	}
    }
  return(okay);
}

Menu::status Menu::SubMenu_event_handler(XEvent *Event)
{
  status ret_val=okay;

  if(Event->xany.window!=popup_win_id && Event->type!=ButtonRelease)
    {
      return(EXIT);
    }
  switch(Event->type)
    {
    case Expose:
      if(Event->xexpose.count==0)
	{
	  option *ptr=m_item[active_option].first_option;
	  XClearWindow(DispPointer(),popup_win_id);
	  int y=height()-y_spacing();
	  while(ptr!=NULL)
	    {
	      if(ptr->enabled)
		XDrawString(DispPointer(),popup_win_id,GraphicsContext,
			    x_spacing(),y,ptr->name,strlen(ptr->name));
	      else
		XDrawString(DispPointer(),popup_win_id,OffGraphicsContext,
			    x_spacing(),y,ptr->name,strlen(ptr->name));
	      y+=height();
	      ptr = ptr->next;
	    }
	}
      break;
    case ButtonPress:
      {
	int abs_x, abs_y, x, y;
	Window root,child;
	unsigned int buttons;
	
	if(XQueryPointer(DispPointer(),popup_win_id,&root,&child,&abs_x,
			 &abs_y,&x,&y,&buttons)==True)
	  {
	    option *ptr=m_item[active_option].first_option;
	    int temp_y=y_spacing();
	    int depth=0;
	    ret_val = EXIT;
	    submenu_exit_var=1;       // This is set to 1, in case the pointer
                                      // isn't on an item.
	    while(ptr!=NULL)
	      {
		if(y>=temp_y && y<(temp_y+height()))
		  submenu_exit_var=2+depth;
		temp_y+=height();
		ptr = ptr->next;
		depth++;
	      }
	  }
      }
      break;
    case ButtonRelease:
      {
	int abs_x, abs_y, x, y;
	Window root,child;
	unsigned int buttons;
	
	if(XQueryPointer(DispPointer(),popup_win_id,&root,&child,&abs_x,
			 &abs_y,&x,&y,&buttons)==True)
	  {
	    option *ptr=m_item[active_option].first_option;
	    int temp_y=y_spacing();
	    int depth=0;

	    while(ptr!=NULL)
	      {
		if(y>=temp_y && y<(temp_y+height()))
		  {
		    submenu_exit_var=2+depth;
		    ret_val = EXIT;
		  }
		temp_y+=height();
		ptr = ptr->next;
		depth++;
	      }
	  }
      }
      break;
    }
  return(ret_val);
}

void Menu::ResizeWindow(void)
{
  UI_Globals *parent = Parent();

// The width of the menu is the width of the parent window minus borders

  unsigned int w = parent->width()-2*BorderWidth;

// Let UI_Globals resize the window

  UI_Globals::ResizeWindow(height(),w);

// Find the last option on the menu bar

  int i=0;
  while(m_item[i+1].name != NULL)
    i++;
  
// Now put the last option on the far right hand side of the window
  
  m_item[i].x1_pos=w-x_spacing()-
             XTextWidth(Menu_Font,m_item[i].name,strlen(m_item[i].name));
  m_item[i].x2_pos=parent->width()-x_spacing();

}
