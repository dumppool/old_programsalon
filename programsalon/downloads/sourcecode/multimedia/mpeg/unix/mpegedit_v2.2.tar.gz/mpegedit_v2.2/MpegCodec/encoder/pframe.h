/*===========================================================================*
 * pframe.h								     *
 *									     *
 *	Procedures concerned with the P-frame encoding			     *
 *									     *
 * EXPORTED PROCEDURES:							     *
 *	GenPFrame							     *
 *	ResetPFrameStats						     *
 *	ShowPFrameSummary						     *
 *	EstimateSecondsPerPFrame					     *
 *      ComputeHalfPixelData                                                 *
 *	SetPQScale							     *
 *      GetPQScale                                                           *
 *									     *
 *===========================================================================*/

/*
 * Copyright (c) 1993 The Regents of the University of California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef __PFRAME__
#define __PFRAME__

#include "ansi.h"
#include "bitio.h"

__BEGIN_DECLS

extern void GenPFrame _ANSI_ARGS_((BitBucket *bb,EncoderMpegFrame *current,
				   EncoderMpegFrame *prev));
extern void ResetPFrameStats _ANSI_ARGS_((void));
extern void ShowPFrameSummary _ANSI_ARGS_((int inputFrameBits,int32 totalBits,
					   FILE *fpointer));
extern float EstimateSecondsPerPFrame _ANSI_ARGS_((void));
extern void ComputeHalfPixelData _ANSI_ARGS_((EncoderMpegFrame *frame));
extern void SetPQScale _ANSI_ARGS_((int qP));
extern int GetPQScale _ANSI_ARGS_((void));

__END_DECLS

#endif






