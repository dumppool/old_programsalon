/*===========================================================================*
 * bitio.h								     *
 *									     *
 *	bitwise input/output						     *
 *									     *
 *===========================================================================*/

/*
 * Copyright (c) 1993 The Regents of the University of California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef __BIT_IO__
#define __BIT_IO__


/*==============*
 * HEADER FILES *
 *==============*/

#include "general.h"
#include "ansi.h"


/*===========*
 * CONSTANTS *
 *===========*/

#define WORDS_PER_BUCKET 256
#define MAXBITS_PER_BUCKET	(WORDS_PER_BUCKET * 32)
#define	MAX_BUCKETS	128
#define MAX_BITS	MAX_BUCKETS*MAXBITS_PER_BUCKET


/*=======================*
 * STRUCTURE DEFINITIONS *
 *=======================*/

typedef struct bitBucket {
    struct bitBucket *nextPtr;
    uint32 bits[WORDS_PER_BUCKET];
    int bitsleft, bitsleftcur, currword;
} ActualBucket;

typedef struct _BitBucket {
    int totalbits;
    int	cumulativeBits;
    int	bitsWritten;
    ActualBucket *firstPtr;
    ActualBucket *lastPtr;
} BitBucket;

/*=============*
 * Global Vars *
 *=============*/

extern uint32 lower_mask[33];

/*========*
 * MACROS *
 *========*/

#define	SET_ITH_BIT(bits, i)	(bits |= (1 << (i)))
#define	GET_ITH_BIT(bits, i)	(bits & (1 << (i)))


/*===============================*
 * EXTERNAL PROCEDURE prototypes *
 *===============================*/

__BEGIN_DECLS

extern void Bitio_Free _ANSI_ARGS_((BitBucket *bbPtr));
extern void Bitio_Write _ANSI_ARGS_((BitBucket *bbPtr,uint32 bits,int nbits));
extern void Bitio_BytePad _ANSI_ARGS_((BitBucket *bbPtr));
extern BitBucket *Bitio_New _ANSI_ARGS_((void));

__END_DECLS

#endif
