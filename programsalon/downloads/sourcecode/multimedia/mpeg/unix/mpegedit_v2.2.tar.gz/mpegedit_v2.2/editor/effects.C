/****************************************************************/
/*  This header file (and its associated C file) handle all the */
/*  effects for the mpeg_edit programme.                        */
/*    (c)1995 Alexis Ashley          milamber@dcs.warwick.ac.uk */
/****************************************************************/

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "effects.H"
#include "text_win.H"
#include "dialogues.H"
#include <string.h>
#include <math.h>

#ifndef PI
#define PI 3.14159265358979323846
#endif

struct ParseCallbackStruct 
{
  TextWindow *msg_box;
  long old_text;
};

static byte * Convolve(frame *Frame,const int *filter,int f_height,
		       int f_width, int offset=0);

static void ParseCallback(byte *,Codec::abs_addr);  // This function is called
                                              // as each frame is parsed
static void do_rotation(frame *temp_frame, frame *temp_frame2, float theta);

/*
 *------------------------------------------------------------------
 *
 * effects_blank --
 *
 *  This procedure is called when a user selects blank frame from the 
 *  effects menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
Menu::status effects_blank(MainWindow *MainWin, Codec *Codec_stream,
			   long start, long end)
{
// Make a blank frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width(),0,128,128);

// Write this frame(s) to the file

  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
    }

// Return

  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * effects_invert --
 *
 *  This procedure is called when a user selects invert frame(s) from
 *  from the effects menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
Menu::status effects_invert(MainWindow *MainWin, Codec *Codec_stream,
			    long start, long end)
{
  int l;
  byte *ptr;

// Make a blank frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

// Compute the length of the area to edit

  int lum_length = Codec_stream->Height()*Codec_stream->Width();
  int chroma_length = lum_length/4;

// Read the frame, invert the colour signals & re-write frame.

  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);

      ptr = temp_frame.lum_ptr();
      for(l=0; l<lum_length; l++)
	ptr[l] = 255 - ptr[l];

      ptr = temp_frame.Cr_ptr();
      for(l=0; l<chroma_length; l++)
	ptr[l] = 255 - ptr[l];

      ptr = temp_frame.Cb_ptr();
      for(l=0; l<chroma_length; l++)
	ptr[l] = 255 - ptr[l];

      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
    }

// Return

  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * effects_supress_colour --
 *
 *  This procedure is called when a user selects supress colour frame
 *  from the effects menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
Menu::status effects_supress_colour(MainWindow *MainWin, Codec *Codec_stream,
				    long start, long end)
{
// Make a blank frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

// Make a blank area to replace the Cr & Cb planes with

  int length = Codec_stream->Height()*Codec_stream->Width()/4;

  byte *blank = new byte[length];
  if(blank==NULL)
    return(Menu::out_of_memory);
  memset(blank,128,length);

// Read the frame, kill the colour signals & re-write frame.

  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      temp_frame.set_Cr(blank);
      temp_frame.set_Cb(blank);
      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
    }

// Return

  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * effects_invert_colour --
 *
 *  This procedure is called when a user selects invert colour from
 *  from the effects menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
Menu::status effects_invert_colour(MainWindow *MainWin, Codec *Codec_stream,
				   long start, long end)
{
  int l;
  byte *ptr;

// Make a blank frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

// Compute the length of the area to edit

  int length = Codec_stream->Height()*Codec_stream->Width()/4;

// Read the frame, invert the colour signals & re-write frame.

  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      ptr = temp_frame.Cr_ptr();
      for(l=0; l<length; l++)
	ptr[l] = 255 - ptr[l];
      ptr = temp_frame.Cb_ptr();
      for(l=0; l<length; l++)
	ptr[l] = 255 - ptr[l];
      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
    }

// Return

  return(Menu::okay);
}

Menu::status effects_fade_to_black(MainWindow *MainWin, Codec *Codec_stream, 
				   long start, long end)
{
  int x,y;
  int height = Codec_stream->Height();
  int width = Codec_stream->Width();
  int temp;

// Return if the user tries to do a fade with only one frame selected

  if(start==end)
    {
      MainWin->NormalCursor();
      notice(MainWin,
	     "This effects requires more than one frame to be selected");
      return(Menu::okay);
    }

// Make a blank frame

  frame temp_frame(height,width);

  int current_factor = 100;         // Current factor to multiply each frame
                                    // by (in percent)

  int fade_speed = 100/(end-start); // How much to change current_factor after
                                    // each frame
  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      for(y=0; y<height; y+=2)
	for(x=0; x<width; x+=2)
	{
	    temp_frame.Lum(x,y) = byte( int(temp_frame.Lum(x,y))*
				       current_factor/100 );

	    temp_frame.Lum(x+1,y) = byte( int(temp_frame.Lum(x+1,y))*
					 current_factor/100 );
	    
	    temp_frame.Lum(x,y+1) = byte( int(temp_frame.Lum(x,y+1))*
					 current_factor/100 );
	    
	    temp_frame.Lum(x+1,y+1) = byte( int(temp_frame.Lum(x+1,y+1))*
					   current_factor/100 );

	    temp = (int(temp_frame.Cr(x/2,y/2)-128) * current_factor) / 100;
	    temp_frame.Cr(x/2,y/2) = byte(temp+128);

	    temp = (int(temp_frame.Cb(x/2,y/2)-128) * current_factor) / 100;
	    temp_frame.Cb(x/2,y/2) = byte(temp+128);
	}
      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
      current_factor -= fade_speed;
    }
// Return

  return(Menu::okay);
}


Menu::status effects_fade_from_black(MainWindow *MainWin, Codec *Codec_stream,
				     long start, long end)
{
  int x,y,temp;
  int height = Codec_stream->Height();
  int width = Codec_stream->Width();

// Return if the user tries to do a fade with only one frame selected

  if(start==end)
    {
      MainWin->NormalCursor();
      notice(MainWin,
	     "This effects requires more than one frame to be selected");      
      return(Menu::okay);
    }

// Make a blank frame

  frame temp_frame(height,width);

  int current_factor = 0;           // Current factor to multiply each frame
                                    // by (in percent)

  int fade_speed = 100/(end-start); // How much to change current_factor after
                                    // each frame
  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      for(y=0; y<height; y+=2)
	for(x=0; x<width; x+=2)
	{
	    temp_frame.Lum(x,y) = byte( int(temp_frame.Lum(x,y))*
				       current_factor/100 );

	    temp_frame.Lum(x+1,y) = byte( int(temp_frame.Lum(x+1,y))*
					 current_factor/100 );
	    
	    temp_frame.Lum(x,y+1) = byte( int(temp_frame.Lum(x,y+1))*
					 current_factor/100 );
	    
	    temp_frame.Lum(x+1,y+1) = byte( int(temp_frame.Lum(x+1,y+1))*
					   current_factor/100 );

	    temp = (int(temp_frame.Cr(x/2,y/2)-128) * current_factor) / 100;
	    temp_frame.Cr(x/2,y/2) = byte(temp+128);

	    temp = (int(temp_frame.Cb(x/2,y/2)-128) * current_factor) / 100;
	    temp_frame.Cb(x/2,y/2) = byte(temp+128);
	}
      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
      current_factor += fade_speed;
    }
// Return

  return(Menu::okay);
}

Menu::status effects_cross_fade_in(MainWindow *MainWin, Codec *Codec_stream,
				   long start, long end)
{
  Codec new_stream;
  long msg_pos;
  Codec::status ret_stat;
  char *filename;
  TextWindow *msg_box;
  ParseCallbackStruct cb_data;
  int x,y,temp;
  int height = Codec_stream->Height();
  int width = Codec_stream->Width();
  frame temp_frame1(Codec_stream->Height(),Codec_stream->Width());
  frame temp_frame2(Codec_stream->Height(),Codec_stream->Width());

  MainWin->NormalCursor();

// Return if the user tries to wipe with only one frame selected

  if(start==end)
    {
      notice(MainWin,
	     "This effects requires more than one frame to be selected");
      return(Menu::okay);
    }

  filename = load_file(MainWin,"Select Mpeg to Cross-Fade with");
  if(filename==NULL)
    return(Menu::okay);
  MainWin->BusyCursor();
  MainWin->FlushEvents();
  ret_stat = new_stream.Open(filename);
  if(ret_stat!=Codec::okay)
    {
      MainWin->NormalCursor();
      switch(ret_stat)
        {
        case Codec::file_not_found:
          notice(MainWin,"The file could not be found!");
          break;
        case Codec::invalid_file:
          notice(MainWin,"The file is not a valid file!");
          break;
        default:          // All the cases should have been dealt with, so
          return(Menu::ABORT); //this is an error, so we'd best do an abort.
        }
      return(Menu::okay);
    }
  msg_box = new TextWindow(MainWin,250.0,550.0,200.0,500.0);
  world_c w = msg_box->TextWidth(MainWin,"Please wait, parsing file");
  msg_box->ResizeWindow(150.0,w+40.0);
  msg_box->CenterWindow();
  msg_pos = msg_box->AddText(20.0,600.0,"Please wait, parsing file");
  cb_data.msg_box = msg_box;
  cb_data.old_text = msg_box->AddText(200.0,150.0,"Frame : 0");
  new_stream.RegisterCallback(ParseCallback,(byte *)&cb_data);
  MainWin->FlushEvents();
  if(new_stream.ParseFile()!=Codec::okay)
    {
      new_stream.RegisterCallback(NULL,NULL);
      delete msg_box;
      new_stream.Close();
      MainWin->NormalCursor();
      notice(MainWin,"Error parsing file.");
      return(Menu::okay);
    }
  new_stream.RegisterCallback(NULL,NULL);
  delete msg_box;
  new_stream.Seek(Codec::abs_addr(0));
  ret_stat=Codec::okay;

  int current_factor = 0;           // Current factor to multiply each frame
                                    // from original file by (in percent)

  int opposite_factor = 100;        // Current factor to multiply each frame
                                    // from new file by (in percent)

  int fade_speed = 100/(end-start); // How much to change current_factor after
                                    // each frame
  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame1);
      new_stream.Read(temp_frame2);
      for(y=0; y<height; y+=2)
	for(x=0; x<width; x+=2)
	  {
	    temp_frame1.Lum(x,y) = byte( int(temp_frame1.Lum(x,y))*
					current_factor/100 );
	    temp_frame1.Lum(x,y) += byte( int(temp_frame2.Lum(x,y))*
					 opposite_factor/100 );
	    
	    temp_frame1.Lum(x+1,y) = byte( int(temp_frame1.Lum(x+1,y))*
					  current_factor/100 );
	    temp_frame1.Lum(x+1,y) += byte( int(temp_frame2.Lum(x+1,y))*
					   opposite_factor/100 );
	    
	    temp_frame1.Lum(x,y+1) = byte( int(temp_frame1.Lum(x,y+1))*
					  current_factor/100 );
	    temp_frame1.Lum(x,y+1) += byte( int(temp_frame2.Lum(x,y+1))*
					   opposite_factor/100 );
	    
	    temp_frame1.Lum(x+1,y+1) = byte( int(temp_frame1.Lum(x+1,y+1))*
					    current_factor/100 );
	    temp_frame1.Lum(x+1,y+1) += byte( int(temp_frame2.Lum(x+1,y+1))*
					     opposite_factor/100 );

	    temp = (int(temp_frame1.Cr(x/2,y/2)-128) * current_factor) / 100;
	    temp += (int(temp_frame2.Cr(x/2,y/2)-128) * opposite_factor) / 100;
	    temp_frame1.Cr(x/2,y/2) = byte(temp+128);

	    temp = (int(temp_frame1.Cb(x/2,y/2)-128) * current_factor) / 100;
	    temp += (int(temp_frame2.Cb(x/2,y/2)-128) * opposite_factor) / 100;
	    temp_frame1.Cb(x/2,y/2) = byte(temp+128);
	}
      Codec_stream->Write(temp_frame1);
      Codec_stream->NextFrame();
      new_stream.NextFrame();
      current_factor += fade_speed;
      opposite_factor = 100 - current_factor;
    }
  new_stream.Close();
  return(Menu::okay);
}

Menu::status effects_cross_fade_out(MainWindow *MainWin, Codec *Codec_stream,
				    long start, long end)
{
  Codec new_stream;
  long msg_pos;
  Codec::status ret_stat;
  char *filename;
  TextWindow *msg_box;
  ParseCallbackStruct cb_data;
  int x,y,temp;
  int height = Codec_stream->Height();
  int width = Codec_stream->Width();
  frame temp_frame1(Codec_stream->Height(),Codec_stream->Width());
  frame temp_frame2(Codec_stream->Height(),Codec_stream->Width());

  MainWin->NormalCursor(); 

// Return if the user tries to wipe with only one frame selected

  if(start==end)
    {
      notice(MainWin,
	     "This effects requires more than one frame to be selected");
      return(Menu::okay);
    }

  filename = load_file(MainWin,"Select Mpeg to Cross-Fade with");
  if(filename==NULL)
    return(Menu::okay);
  MainWin->BusyCursor();
  MainWin->FlushEvents();
  ret_stat = new_stream.Open(filename);
  if(ret_stat!=Codec::okay)
    {
      MainWin->NormalCursor();
      switch(ret_stat)
        {
        case Codec::file_not_found:
          notice(MainWin,"The file could not be found!");
          break;
        case Codec::invalid_file:
          notice(MainWin,"The file is not a valid file!");
          break;
        default:          // All the cases should have been dealt with, so
          return(Menu::ABORT); //this is an error, so we'd best do an abort.
        }
      return(Menu::okay);
    }
  msg_box = new TextWindow(MainWin,250.0,550.0,200.0,500.0);
  world_c w = msg_box->TextWidth(MainWin,"Please wait, parsing file");
  msg_box->ResizeWindow(150.0,w+40.0);
  msg_box->CenterWindow();
  msg_pos = msg_box->AddText(20.0,600.0,"Please wait, parsing file");
  cb_data.msg_box = msg_box;
  cb_data.old_text = msg_box->AddText(200.0,150.0,"Frame : 0");
  new_stream.RegisterCallback(ParseCallback,(byte *)&cb_data);
  MainWin->FlushEvents();
  if(new_stream.ParseFile()!=Codec::okay)
    {
      new_stream.RegisterCallback(NULL,NULL);
      delete msg_box;
      new_stream.Close();
      MainWin->NormalCursor();
      notice(MainWin,"Error parsing file.");
      return(Menu::okay);
    }
  new_stream.RegisterCallback(NULL,NULL);
  delete msg_box;
  new_stream.Seek(Codec::abs_addr(0));
  ret_stat=Codec::okay;

  int current_factor = 100;         // Current factor to multiply each frame
                                    // from original file by (in percent)

  int opposite_factor = 0;          // Current factor to multiply each frame
                                    // from new file by (in percent)

  int fade_speed = 100/(end-start); // How much to change current_factor after
                                    // each frame
  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame1);
      new_stream.Read(temp_frame2);
      for(y=0; y<height; y+=2)
	for(x=0; x<width; x+=2)
	  {
	    temp_frame1.Lum(x,y) = byte( int(temp_frame1.Lum(x,y))*
					current_factor/100 );
	    temp_frame1.Lum(x,y) += byte( int(temp_frame2.Lum(x,y))*
					 opposite_factor/100 );
	    
	    temp_frame1.Lum(x+1,y) = byte( int(temp_frame1.Lum(x+1,y))*
					  current_factor/100 );
	    temp_frame1.Lum(x+1,y) += byte( int(temp_frame2.Lum(x+1,y))*
					   opposite_factor/100 );
	    
	    temp_frame1.Lum(x,y+1) = byte( int(temp_frame1.Lum(x,y+1))*
					  current_factor/100 );
	    temp_frame1.Lum(x,y+1) += byte( int(temp_frame2.Lum(x,y+1))*
					   opposite_factor/100 );
	    
	    temp_frame1.Lum(x+1,y+1) = byte( int(temp_frame1.Lum(x+1,y+1))*
					    current_factor/100 );
	    temp_frame1.Lum(x+1,y+1) += byte( int(temp_frame2.Lum(x+1,y+1))*
					     opposite_factor/100 );

	    temp = (int(temp_frame1.Cr(x/2,y/2)-128) * current_factor) / 100;
	    temp += (int(temp_frame2.Cr(x/2,y/2)-128) * opposite_factor) / 100;
	    temp_frame1.Cr(x/2,y/2) = byte(temp+128);

	    temp = (int(temp_frame1.Cb(x/2,y/2)-128) * current_factor) / 100;
	    temp += (int(temp_frame2.Cb(x/2,y/2)-128) * opposite_factor) / 100;
	    temp_frame1.Cb(x/2,y/2) = byte(temp+128);
	}
      Codec_stream->Write(temp_frame1);
      Codec_stream->NextFrame();
      new_stream.NextFrame();
      current_factor -= fade_speed;
      opposite_factor = 100 - current_factor;
    }
  new_stream.Close();
  return(Menu::okay);
}

Menu::status effects_edge_trace(MainWindow *MainWin, Codec *Codec_stream,
				long start, long end)
{
  byte *conv;
  byte *blank;
  int edge_filter[9]={ -1,-1,-1,  -1,8,-1,  -1,-1,-1 };

// Make a blank frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

// Make a blank area to replace the Cr & Cb planes with

  int length = Codec_stream->Height()*Codec_stream->Width()/4;

  blank = new byte[length];
  if(blank==NULL)
    return(Menu::out_of_memory);
  memset(blank,128,length);

  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      conv = Convolve(&temp_frame,edge_filter,3,3);
      temp_frame.set_lum(conv);
      temp_frame.set_Cr(blank);
      temp_frame.set_Cb(blank);
      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
    }

// Return

  return(Menu::okay);
}

Menu::status effects_boost_brightness(MainWindow *MainWin,Codec *Codec_stream,
				      long start, long end)
{
  int x,y;
  int height = Codec_stream->Height();
  int width = Codec_stream->Width();
  float level;
  float ftemp;
  byte factor[256];

// Ask the user to select brightness level

  MainWin->NormalCursor();
  level = select_number(MainWin,"Please select a brightness level",1.0,0.0,
			2.0,0.1);
  if(level<0.0)                         // Return if the user selected cancel
    return(Menu::okay);
  MainWin->BusyCursor();
  MainWin->FlushEvents();

// Build a table of all possible values of luminance, after corection

  for(x=0; x<256; x++)
    {
      ftemp = float(x)*level;
      if(ftemp>255.0)
	ftemp=255.0;
      factor[x] = byte(ftemp);
    }

// Make a blank frame

  frame temp_frame(height,width);

// Do the correction

  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      for(y=0; y<height; y++)
	for(x=0; x<width; x++)
	  {
	    temp_frame.Lum(x,y) = factor[temp_frame.Lum(x,y)];
	  }
      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
    }

// Return

  return(Menu::okay);
}

Menu::status effects_boost_colour(MainWindow *MainWin,Codec *Codec_stream,
				   long start, long end)
{
  int x,y;
  int height = Codec_stream->Height() / 2;
  int width = Codec_stream->Width() / 2;
  float level;
  float ftemp;
  byte factor[256];

// Ask the user to select a colour level

  MainWin->NormalCursor();
  level = select_number(MainWin,"Please select a colour level",1.0,0.0,2.0,
			0.1);
  if(level<0.0)                         // Return if the user selected cancel
    return(Menu::okay);
  MainWin->BusyCursor();
  MainWin->FlushEvents();

// Build a table of all possible values of chromiance, after corection

  for(x=1; x<256; x++)
    {
      ftemp = float(x-128)*level;
      if(ftemp>127.0)
	ftemp=127.0;
      else if(ftemp<-128.0)
	ftemp=-128.0;
      factor[x] = byte(ftemp+128);
    }

// Make a blank frame

  frame temp_frame(height,width);

  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      for(y=0; y<height; y++)
	for(x=0; x<width; x++)
	  {
	    temp_frame.Cr(x,y) = factor[temp_frame.Cr(x,y)];
	    temp_frame.Cb(x,y) = factor[temp_frame.Cb(x,y)];
	  }
      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
    }

// Return

  return(Menu::okay);
}

Menu::status effects_gamma_correct(MainWindow *MainWin,Codec *Codec_stream,
				   long start, long end)
{
  int x,y;
  int height = Codec_stream->Height();
  int width = Codec_stream->Width();
  float level;
  float ftemp;
  byte factor[256];

// Ask the user to select a gamma correction level

  MainWin->NormalCursor();
  level = select_number(MainWin,"Please select a gamma correction level",
			0.8,0.1,2.0,0.1);
  if(level<0.1)                         // Return if the user selected cancel
    return(Menu::okay);
  MainWin->BusyCursor();
  MainWin->FlushEvents();

  level = 1.0/level;

// Build a table of all possible values of luminance, after gamma corection

  factor[0] = 0;
  for(x=1; x<256; x++)
    {
      ftemp = pow(float(x)/255.0,level);
      factor[x] = byte(ftemp*255.0);
    }

// Make a blank frame

  frame temp_frame(height,width);

  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      for(y=0; y<height; y++)
	for(x=0; x<width; x++)
	  {
	    temp_frame.Lum(x,y) = factor[temp_frame.Lum(x,y)];
	  }
      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
    }

// Return

  return(Menu::okay);
}

Menu::status effects_rotate(MainWindow *MainWin,Codec *Codec_stream,
			    long start, long end)
{
  int height = Codec_stream->Height();
  int width = Codec_stream->Width();
  float theta;

  MainWin->NormalCursor();

// Ask the user to select the angle to rotate by

  theta = select_number(MainWin,"Please select an angle",45.0,5.0,360.0,5.0);
  if(theta<5.0 || theta>360.0)        // Return if the user selected cancel,
    return(Menu::okay);               // or typed in an invalid value

  MainWin->BusyCursor();
  MainWin->FlushEvents();

  theta *= PI/180;             // Convert theta into radians

// Make two blank frames

  frame temp_frame(height,width);
  frame temp_frame2(height,width,0,128,128);

// Move code_stream to the start of the section to be rotated

  Codec_stream->Seek(start);

// Do the rotate

  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      do_rotation(&temp_frame,&temp_frame2,theta);
      Codec_stream->Write(temp_frame2);
      Codec_stream->NextFrame();
    }

// Return

  return(Menu::okay);
}

Menu::status effects_variable_rotate(MainWindow *MainWin,Codec *Codec_stream,
				     long start, long end)
{
  int height = Codec_stream->Height();
  int width = Codec_stream->Width();
  float start_angle;
  float end_angle;
  float inc_angle;
  float theta;

  MainWin->NormalCursor();

// Return if the user tries to wipe with only one frame selected

  if(start==end)
    {
      notice(MainWin,
	     "This effects requires more than one frame to be selected");
      return(Menu::okay);
    }

// Ask the user to select the start angle

  start_angle = select_number(MainWin,"Please select the start angle",45.0,5.0,
			      360.0,5.0);
  if(start_angle<5.0 || start_angle>360.0)
    return(Menu::okay);                // Return if the user selected cancel

// Ask the user to select the end angle

  end_angle = select_number(MainWin,"Please select the end angle",45.0,5.0,
			      360.0,5.0);
  if(end_angle<5.0 || end_angle>360.0)
    return(Menu::okay);                // Return if the user selected cancel

  MainWin->BusyCursor();
  MainWin->FlushEvents();

  start_angle *= PI/180.0;             // Convert angle into radians
  end_angle *= PI/180.0;               // Convert angle into radians
  inc_angle = (end_angle - start_angle)/float(end-start);
  theta = start_angle;

// Make two blank frames

  frame temp_frame(height,width);
  frame temp_frame2(height,width,0,128,128);

// Move code_stream to the start of the section to be rotated

  Codec_stream->Seek(start);

// Do the rotations

  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      do_rotation(&temp_frame,&temp_frame2,theta);
      theta += inc_angle;
      Codec_stream->Write(temp_frame2);
      Codec_stream->NextFrame();
    }

// Return

  return(Menu::okay);
}

Menu::status effects_emboss(MainWindow *MainWin, Codec *Codec_stream, 
			    long start, long end)
{
  byte *conv;
  byte *blank;

  int emboss_filter[9]={ -1,0,0,  0,0,0,  0,0,1 };

// Make a blank frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

// Make a blank area to replace the Cr & Cb planes with

  int length = Codec_stream->Height()*Codec_stream->Width()/4;

  blank = new byte[length];
  if(blank==NULL)
    return(Menu::out_of_memory);
  memset(blank,128,length);

  Codec_stream->Seek(start);
  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      conv = Convolve(&temp_frame,emboss_filter,3,3,127);
      temp_frame.set_lum(conv);
      temp_frame.set_Cr(blank);
      temp_frame.set_Cb(blank);
      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
    }
// Return

  return(Menu::okay);
}

Menu::status effects_wipe(MainWindow *MainWin, Codec *Codec_stream, 
			  long start, long end)
{
  int x,y;
  int start_x;
  int start_y;
  int end_x;
  int end_y;
  int increment;
  int height = Codec_stream->Height();
  int width = Codec_stream->Width();
  char *direction;
  List <char *> directions;

// Return if the user tries to wipe with only one frame selected

  if(start==end)
    {
      MainWin->NormalCursor();
      notice(MainWin,
	     "This effects requires more than one frame to be selected");
      return(Menu::okay);
    }

  MainWin->NormalCursor();

// Ask the user what direction to wipe in

  directions.Write("From top to bottom in black");
  directions.Advance();
  directions.Write("From bottom to top in black");
  directions.Advance();
  directions.Write("From left to right in black");
  directions.Advance();
  directions.Write("From right to left in black");
  directions.Advance();
  directions.Write("From top to bottom in picture");
  directions.Advance();
  directions.Write("From bottom to top in picture");
  directions.Advance();
  directions.Write("From left to right in picture");
  directions.Advance();
  directions.Write("From right to left in picture");

  direction=selection_box(MainWin,"Please selection a direction",&directions);
  if(direction==NULL)
    return(Menu::okay);      // Return if user selected cancel

  MainWin->BusyCursor();
  MainWin->FlushEvents();

  if(strcmp(direction,"From top to bottom in black")==0)
    {
      start_x=0;
      start_y=0;
      end_x=width-1;
      end_y=1;
      increment = 2*(height/(2*(end-start)));
    }
  else if(strcmp(direction,"From bottom to top in black")==0)
    {
      start_x=0;
      start_y=height-2;
      end_x=width-1;
      end_y=height-1;
      increment = 2*(height/(2*(end-start)));
    }
  else if(strcmp(direction,"From left to right in black")==0)
    {
      start_x=0;
      start_y=0;
      end_x=1;
      end_y=height-1;
      increment = 2*(width/(2*(end-start)));
    }
  else if(strcmp(direction,"From right to left in black")==0)
    {
      start_x=width-2;
      start_y=0;
      end_x=width-1;
      end_y=height-1;
      increment = 2*(width/(2*(end-start)));
    }
  else if(strcmp(direction,"From top to bottom in picture")==0)
    {
      start_x=0;
      start_y=0;
      end_x=width-1;
      end_y=height-1;
      increment = 2*(height/(2*(end-start)));
    }
  else if(strcmp(direction,"From bottom to top in picture")==0)
    {
      start_x=0;
      start_y=0;
      end_x=width-1;
      end_y=height-1;
      increment = 2*(height/(2*(end-start)));
    }
  else if(strcmp(direction,"From left to right in picture")==0)
    {
      start_x=0;
      start_y=0;
      end_x=width-1;
      end_y=height-1;
      increment = 2*(width/(2*(end-start)));
    }
  else // "From right to left in picture"
    {
      start_x=0;
      start_y=0;
      end_x=width-1;
      end_y=height-1;
      increment = 2*(width/(2*(end-start)));
    }

// Make a blank frame

  frame temp_frame(height,width);

  Codec_stream->Seek(start);

// Do the wipe

  for(long i=start; i<=end; i++)
    {
      Codec_stream->Read(temp_frame);
      for(y=start_y; y<end_y; y+=2)
	for(x=start_x; x<end_x; x+=2)
	  {
	    temp_frame.Lum(x,y) = 0;
	    temp_frame.Lum(x+1,y) = 0;
	    temp_frame.Lum(x,y+1) = 0;
	    temp_frame.Lum(x+1,y+1) = 0;
	    temp_frame.Cr(x/2,y/2) = 128;
	    temp_frame.Cb(x/2,y/2) = 128;
	  }
      Codec_stream->Write(temp_frame);
      Codec_stream->NextFrame();
      if(strcmp(direction,"From top to bottom in black")==0)
	{
	  end_y += increment;
	  if(end_y+1>=height)
	    end_y=height-1;
	}
      else if(strcmp(direction,"From bottom to top in black")==0)
	{
	  start_y -= increment;
	  if(start_y<0)
	    start_y=0;
	}
      else if(strcmp(direction,"From left to right in black")==0)
	{
	  end_x += increment;
	  if(end_x+1>=width)
	    end_x=width-1;
	}
      else if(strcmp(direction,"From right to left in black")==0)
	{
	  start_x -= increment;
	  if(start_x<0)
	    start_x=0;
	}
      else if(strcmp(direction,"From top to bottom in picture")==0)
	{
	  start_y += increment;
	  if(start_y+1>=height)
	    start_y=height-1;
	}
      else if(strcmp(direction,"From bottom to top in picture")==0)
	{
	  end_y -= increment;
	  if(end_y<0)
	    end_y=0;
	}
      else if(strcmp(direction,"From left to right in picture")==0)
	{
	  start_x += increment;
	  if(start_x+1>=width)
	    start_x=width-1;
	}
      else      // "From right to left in picture"
	{
	  end_x -= increment;
	  if(end_x<0)
	    end_x=0;
	}
    }

// Return

  return(Menu::okay);
}


static byte * Convolve(frame *Frame,const int *filter,int f_height,int f_width,
		       int offset)
{
  int x,y,x2,y2;
  const int *ptr;
  int ans;
  byte *retval, *r_ptr;
  int h = f_height/2;
  int w = f_width/2;
  int height = Frame->height();
  int width = Frame->width();

  retval = new byte[height*width];
  if(retval==NULL)
    return NULL;
  r_ptr = retval;
  for(y=0; y<height; y++)
    {
      for(x=0; x<width; x++)
	{
	  ptr = filter;
	  ans = offset;
	  for(y2=-h; y2<=h; y2++)
	    {
	      if(y-y2>=0 && y-y2<height)
		for(x2=-w; x2<=w; x2++)
		  {
		    if(x-x2>=0 && x-x2<width)
		      ans += (*ptr)*int(Frame->Lum(x-x2,y-y2));
		    ptr++;
		  }
	      else
		ptr += 1+w+w;
	    }
	  if(ans<0)
	    ans=0;
	  else if(ans>255)
	    ans=255;
	  *r_ptr=byte(ans);
	  r_ptr++;
	}
    }
  return retval;
}

/*
 *------------------------------------------------------------------
 *
 * ParseCallback --
 *
 *	This callback is called while the new codec file is being parsed
 *
 * Results:
 *     Updates the frame number display every third frame
 *
 * Side effects:
 *           None
 *
 *-------------------------------------------------------------------
 */
static void ParseCallback(byte *b,Codec::abs_addr frame_num)
{
  if(frame_num%3==0)
    {
      ParseCallbackStruct *pcs = (ParseCallbackStruct *)b;
      char str[20];
      
      sprintf(str,"Frame : %d",frame_num);
      pcs->msg_box->DeleteText(pcs->old_text);
      pcs->old_text = pcs->msg_box->AddText(200.0,150.0,str);
      pcs->msg_box->FlushEvents();
    }
}

static void do_rotation(frame *temp_frame, frame *temp_frame2, float theta)
{
  int x,y;
  int x2,y2;
  int i_temp;
  double fx2,fy2;
  double x_temp;
  double y_temp;
  float x_prime;
  float y_prime;
  float f_temp;
  float f_temp2;
  int height = temp_frame->height();
  int width = temp_frame->width();
  int h2 = height/2;
  int w2 = width/2;
  float cos_theta = cos(theta);
  float sin_theta = sin(theta);

// First, do the Lum plane

  for(y=0; y<height; y++)
    for(x=0; x<width; x++)
      {
	x_prime = w2 + float(x-w2)*cos_theta + float(y-h2)*sin_theta;
	y_prime = h2 - float(x-w2)*sin_theta + float(y-h2)*cos_theta;
	x_temp = modf(x_prime,&fx2);        // Split x_prime into integer
	                                    // + fraction
	y_temp = modf(y_prime,&fy2);        // Split y_prime into integer
	                                    // + fraction
	x2 = int(fx2);
	y2 = int(fy2);
	if(x2>0 && x2<width-1 && y2>0 && y2<height-1)
	  {
	    f_temp = (1.0-y_temp)*(1.0-x_temp)*float(temp_frame->Lum(x2,y2));

	    if(x_temp<0.5)
	      x2--;
	    else
	      x2++;
	    
	    f_temp += (1.0-y_temp) * x_temp * float(temp_frame->Lum(x2,y2));
	    
	    if(y_temp<0.5)
	      y2--;
	    else
	      y2++;
	    
	    f_temp += y_temp * x_temp * float(temp_frame->Lum(x2,y2));
	    
	    if(x_temp<0.5)
	      x2++;
	    else
	      x2--;
	    
	    f_temp += y_temp * (1.0-x_temp) * float(temp_frame->Lum(x2,y2));
	  }
	else
	  {
	    f_temp = 0.0;
	  }
	i_temp = int(f_temp);
	if(i_temp>255)
	  i_temp=255;
	temp_frame2->Lum(x,y) = i_temp;
      }
  
// Now do the Cr & Cb planes

  height /= 2;
  width /= 2;
  h2 /= 2;
  w2 /= 2;
  for(y=0; y<height; y++)
    for(x=0; x<width; x++)
      {
	x_prime = w2 + float(x-w2)*cos_theta + float(y-h2)*sin_theta;
	y_prime = h2 - float(x-w2)*sin_theta + float(y-h2)*cos_theta;
	x_temp = modf(x_prime,&fx2);        // Split x_prime into integer
	                                    // + fraction
	y_temp = modf(y_prime,&fy2);        // Split y_prime into integer
	                                    // + fraction
	x2 = int(fx2);
	y2 = int(fy2);
	if(x2>0 && x2<width-1 && y2>0 && y2<height-1)
	  {
	    f_temp = (1.0-y_temp)*(1.0-x_temp)*float(temp_frame->Cr(x2,y2));
	    f_temp2 =(1.0-y_temp)*(1.0-x_temp)*float(temp_frame->Cb(x2,y2));

	    if(x_temp<0.5)
	      x2--;
	    else
	      x2++;
	    
	    f_temp += (1-y_temp) * x_temp * float(temp_frame->Cr(x2,y2));
	    f_temp2 += (1-y_temp) * x_temp * float(temp_frame->Cb(x2,y2));
	    
	    if(y_temp<0.5)
	      y2--;
	    else
	      y2++;
	    
	    f_temp += y_temp * x_temp * float(temp_frame->Cr(x2,y2));
	    f_temp2 += y_temp * x_temp * float(temp_frame->Cb(x2,y2));
	    
	    if(x_temp<0.5)
	      x2++;
	    else
	      x2--;
	    
	    f_temp += y_temp * (1-x_temp) * float(temp_frame->Cr(x2,y2));
	    f_temp2 += y_temp * (1-x_temp) * float(temp_frame->Cb(x2,y2));
	  }
	else
	  {
	    f_temp = 128.0;
	    f_temp2 = 128.0;
	  }
	i_temp = int(f_temp);
	if(i_temp>255)
	  i_temp=255;
	temp_frame2->Cr(x,y) = i_temp;
	i_temp = int(f_temp2);
	if(i_temp>255)
	  i_temp=255;
	temp_frame2->Cb(x,y) = i_temp;
      }
}

