/*****************************************************************************/
/* This is the source file for the simple sub window class.  It provides the */
/* bear minimum functions for a sub window.  It is designed to be inherited  */
/* by other classes, which build on the functions provided here.             */
/*                                                                           */
/*                                (c)1994 Alexis 'Milamber' Ashley           */
/*****************************************************************************/
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "sub_win.H"
#include <assert.h>

char SimpleSubWindow::Foreground[80] = "Black";
char SimpleSubWindow::Background[80] = "Light Gray";
unsigned int SimpleSubWindow::BorderWidth=2;

SimpleSubWindow::SimpleSubWindow(UI_Globals *parent,unsigned int x,
				 unsigned int y, unsigned int height,
				 unsigned int width,
				 UI_Globals *class_ptr,long event_mask, 
				 const char * const fgcolour,
				 const char * const bgcolour,
				 unsigned int Border_Width)
: UI_Globals(parent)
{
  Constructor(parent,x,y,height,width,class_ptr,event_mask,fgcolour,bgcolour,
	      Border_Width);
}

SimpleSubWindow::SimpleSubWindow(UI_Globals *parent,world_c x,world_c y,
				 unsigned int height,unsigned int width,
				 UI_Globals *class_ptr,long event_mask, 
				 corner relative_to,
				 const char * const fgcolour,
				 const char * const bgcolour,
				 unsigned int Border_Width)
: UI_Globals(parent)
{
  unsigned int px,py;             // Used in calculating x,y pos for window
 
  px = parent->wc2pix_x(x);
  py = parent->wc2pix_y(y);

// This switch is used to set which corner the x and y world coords referred
// to, and to adjust px & py accordingly, so that they are correct.

  switch(relative_to)
    {
    case topleft: 
      break;
    case topright:
      px -= width;
      break;
    case bottomleft:
      py -= height;
      break;
    case bottomright:
      px -= width;
      py -= height;
      break;
    }
  Constructor(parent,px,py,height,width,class_ptr,event_mask,fgcolour,
	      bgcolour,Border_Width);
}

SimpleSubWindow::SimpleSubWindow(UI_Globals *parent,world_c x,world_c y,
				 world_c height,world_c width,
				 UI_Globals *class_ptr,long event_mask, 
				 const char * const fgcolour,
				 const char * const bgcolour,
				 unsigned int Border_Width)
: UI_Globals(parent)
{
  unsigned int px,py;         // Used in calculating x,y pos for window
  unsigned int ph,pw;         // Used in calculating height & width for window

  px = parent->wc2pix_x(x);
  py = parent->wc2pix_y(y);
  pw = parent->wc2pix_x( (x+width<0) ? 0 : x+width );
  ph = parent->wc2pix_y( (y+height<0) ? 0: y+height );

  if(px>pw)         // If width was negetive, swap px & pw
    {
      unsigned int pt = px;
      px = pw;
      pw = pt;
    }
  pw -= px;
  if(py>ph)         // If height was negetive, swap py & ph
    {
      unsigned int pt = py;
      py = ph;
      ph = pt;
    }
  ph -= py;
  Constructor(parent,px,py,ph,pw,class_ptr,event_mask,fgcolour,
	      bgcolour,Border_Width);
}

SimpleSubWindow::~SimpleSubWindow(void)
{
  colour cols[2];

// Free the colours that were allocated by the sub window, being careful not
// to try to deallocate black or white, which is a read-only colour

  cols[0] = fg_colour;
  cols[1] = bg_colour;
  for(int i=0; i<2; i++)
    if(cols[i]!=White && cols[i]!=Black)
      XFreeColors(DispPointer(),Colourmap,&cols[i],1,0);
}

void SimpleSubWindow::Constructor(UI_Globals *parent,unsigned int x,
				  unsigned int y,
				  unsigned int height,unsigned int width,
				  UI_Globals *class_ptr,long event_mask, 
				  const char * const fgcolour,
				  const char * const bgcolour,
				  unsigned int Border_Width)
{
  XColor tmp_col;       // This is used during colour unsigned int allocation
  Window win_id;        // The window id for this window
  opt_list resources[] =
    {
      { "SubWindow.foreground" , Foreground },
      { "SubWindow.background" , Background },
      { "" , NULL }
    };

// Check for X resources

  CheckResources(resources);

// Allocate the foreground & background colours.
// If any colour is unavailable, use black or white instead

  if(XParseColor(DispPointer(),Colourmap,fgcolour,&tmp_col)==0 ||
                              XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
    fg_colour = Black;
  else
    fg_colour = tmp_col.pixel;
  if(XParseColor(DispPointer(),Colourmap,bgcolour,&tmp_col)==0 ||
                              XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
    bg_colour = White;
  else
    bg_colour = tmp_col.pixel;

// Create the window

  win_id = XCreateSimpleWindow(DispPointer(),parent->WinId(),x,y,width,height,
				   Border_Width,fg_colour,bg_colour);

// Register the window with UI_Globals, so that UI_Globals can report events
// to the class specified in class_ptr

  RegisterWindow(class_ptr,win_id,height,width);

// Select the events that X should report to this window

  XSelectInput(DispPointer(),win_id,event_mask | ExposureMask);

// Map the window

  XMapWindow(DispPointer(),win_id);

// Store x & y pos of window

  x_pos = parent->pix_x2wc(x);
  y_pos = parent->pix_y2wc(y);

// Finished
}

void SimpleSubWindow::MoveWindow(world_c x, world_c y)
{
  unsigned int px,py;

// Get the pointer to the parent window

  UI_Globals *parent = Parent();

// Convert x into a pixel value, relative to the parent window

  px = parent->wc2pix_x(x);

// Convert y into a pixel value, relative to the parent window

  py = parent->wc2pix_y(y);

// Move the window

  XMoveWindow(DispPointer(),WinId(),px,py);
}

void SimpleSubWindow::ResizeWindow(world_c new_height, world_c new_width)
{
// Get the pointer to the parent window

  UI_Globals *parent = Parent();

// Convert new_height into a pixel value, relative to the parent window

  unsigned int ph = parent->wc2pix_h(new_height);

// Convert new_width into a pixel value, relative to the parent window

  unsigned int pw = parent->wc2pix_w(new_width);

// Let UI_Globals do the resize

  UI_Globals::ResizeWindow(ph,pw);
}

world_c SimpleSubWindow::X_Pos(void)
{
  return x_pos;
}

world_c SimpleSubWindow::Y_Pos(void)
{
  return y_pos;
}

void SimpleSubWindow::CenterWindow(void)
{
  world_c X = ( UI_Globals::MAX_WORLD_C_VAL-Width() ) / 2;
  world_c Y = ( UI_Globals::MAX_WORLD_C_VAL-Height() ) / 2 + Height();
  MoveWindow(X,Y);
}
