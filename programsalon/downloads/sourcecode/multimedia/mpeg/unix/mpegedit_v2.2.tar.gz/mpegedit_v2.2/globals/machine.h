/* This file (should) contain all the defines needed for specific machines */

#ifndef MACHINE_HEADER
#define MACHINE_HEADER

#ifdef __sun
  #define NO_INET
#endif

#ifdef __linux__
#define NO_BOOL
#endif


#endif
