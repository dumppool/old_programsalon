/*********************************************************/
/* UI_GLOBALS                                            */
/*   This base class is inherited by the button, menu,   */
/*   sub_window etc classes, and provides a way of       */
/*   safely accessing variables that need to be global   */
/*   to the entire user interface.                       */
/*                                                       */
/*                      (c)1994 Alexis 'Milamber' Ashley */
/*********************************************************/
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "global.H"
#include <assert.h>
#include <iostream.h>
#include <stdlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>

unsigned int UI_Globals::_x_spacing=5;
unsigned int UI_Globals::_y_spacing=5;
Display *UI_Globals::DisplayPointer=NULL;
XContext UI_Globals::Contexts;
int UI_Globals::count=0;
const float UI_Globals::MAX_WORLD_C_VAL = 1000.0;
char *UI_Globals::app_name=NULL;
int UI_Globals::argc=0;
char **UI_Globals::argv=NULL;
Colormap UI_Globals::Colourmap;
colour UI_Globals::White;
colour UI_Globals::Black;
XErrorEvent Xerr;            // Holds the last X error

int myXErrorHandler(Display *, XErrorEvent *);  // Handles all X errors

UI_Globals::UI_Globals(UI_Globals *parent)
{
  assert(count!=0);
  count++;
  a_w_count = 0;
  This_Context.Parent = parent;
  registered=false;
}

UI_Globals::UI_Globals(const char *const AppName, int _argc, char **_argv)
{
  if(count++==0)
    {
      bool private_cols=false;
      char *DisplayName = NULL;
      app_name = new char[strlen(AppName)+1];
      assert(app_name!=NULL);
      strcpy(app_name,AppName);
      argc = _argc;
      argv = _argv;
      for(int i=1; i<argc; i++)
	{
	  if(strcmp("-display",argv[i])==0)
	    DisplayName = argv[i+1];
	  if(strcmp("-d",argv[i])==0)
	    DisplayName = argv[i+1];
	  if(strcmp("-private",argv[i])==0)
	    private_cols=true;
	}
      DisplayPointer=XOpenDisplay(DisplayName);
      if(DisplayPointer==NULL)
	{
	  cerr << AppName << ": Unable to open display " 
	    << XDisplayName(DisplayName) << endl;
	  exit(1);
	}
      Contexts=XUniqueContext();
      Xerr.display=NULL;
      Xerr.serial=0;
      Xerr.error_code=Success;
      Xerr.request_code=0;
      Xerr.minor_code=0;
      XSetErrorHandler(myXErrorHandler);
      Colourmap=DefaultColormap(DisplayPointer,DefaultScreen(DisplayPointer));
      if(private_cols)
	{
	  XColor tmp_col;

	  Colourmap=XCopyColormapAndFree(DisplayPointer,Colourmap);

	  if(XParseColor(DisplayPointer,Colourmap,"Black",&tmp_col)==0 ||
	     XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
	    {
	      cerr << AppName << ": Unable to allocate the colour black\n";
	      exit(1);
	    }
	  else
	    Black = tmp_col.pixel;

	  if(XParseColor(DisplayPointer,Colourmap,"White",&tmp_col)==0 ||
	     XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
	    {
	      cerr << AppName << ": Unable to allocate the colour white\n";
	      exit(1);
	    }
	  else
	    White = tmp_col.pixel;
	}
      else
	{
	  Black = BlackPixel(DisplayPointer,DefaultScreen(DisplayPointer));
	  White = WhitePixel(DisplayPointer,DefaultScreen(DisplayPointer));
	}
    }
  a_w_count = 0;
  This_Context.Parent = this;
  registered = false;
}

UI_Globals::~UI_Globals(void)
{
  if(registered)     // Destroy the context data for this window & the window
    { 
      int temp = XDeleteContext(DisplayPointer,_win_id,Contexts);
      if(temp!=0)
	{
#ifdef DEBUG
	  cout << "Error deleting XContext structure.  Count = " << count
	    << endl;
#endif
	}
      XDestroyWindow(DisplayPointer,_win_id);
    }
  else
#ifdef DEBUG
    cout << "An unregistered window has been deleted!\n";
#endif

  if(a_w_count!=0)
    delete accept_wins;

  if(--count==0)
    {
      XSetErrorHandler(NULL);
#ifdef DEBUG
      cout << "Flushing X buffers...\n";
#endif
      XSync(DisplayPointer,False);
#ifdef DEBUG
      cout << "Closing X connection...\n";
#endif
      XCloseDisplay(DisplayPointer);
      delete app_name;
    }
}

int myXErrorHandler(Display *d, XErrorEvent *err)
{
  char err_msg[80];        // This will hold the error description

  Xerr = *err;             // Copy the error structure to a private var
  XGetErrorText(d,err->error_code,err_msg,80);    // Get the error description
  cerr << "X error detected!\n" << err_msg << endl;
  cerr << "Protocol request : " << int(err->request_code) << "    ";
  cerr << "minor " << int(err->minor_code) << endl;
  cerr << "Resource ID : 0x" << hex << int(err->resourceid) << dec ;
  cerr << "Serial number : " << err->serial << endl;
  return(0);
}

XErrorEvent UI_Globals::GetLastError(void)
{
  return Xerr;
}

void UI_Globals::RegisterWindow(UI_Globals *class_ptr, Window win, unsigned int h, 
				unsigned int w)
{
  _win_id = win;
  _width=w;
  _height=h;
  x_multiplier = float(_width) / MAX_WORLD_C_VAL;
  y_multiplier = float(_height) / MAX_WORLD_C_VAL;
  This_Context.This = class_ptr;
  int temp=XSaveContext(DisplayPointer,win,Contexts,XPointer(&This_Context));
  assert(temp==0);
  registered = true;
}

void UI_Globals::CheckResources(opt_list *rl)
{
  char *tmpstr;

  for(int i=0; rl[i].value!=NULL; i++)
    {
      if( (tmpstr = XGetDefault(DisplayPointer,app_name,rl[i].name)) != NULL)
	strcpy(rl[i].value,tmpstr);
    }
}

void UI_Globals::CheckCommandLine(opt_list *cl)
{
  int i,j;

  for(i=1; i<argc; i++)
    for(j=0; cl[j].value!=NULL; j++)
      {
	if(strcmp(cl[j].name,argv[i])==0)
	  strcpy(cl[j].value,argv[i+1]);
      }
}

/*              ************ EVENT HANDLER **************** 
 This member function is the function that handles all the XEvents in the 
 user interface.  Any window that wants to receive events (and all windows
 want at least expose events) must call RegisterWindow.

 When an event is received, the virtual member function event_handler is 
 called for the class pointed to by This in the X_Context structure.

 If the programme calls the RestrictEvents function, events are passed
 unfiltered only to the windows listed in the array passed to Restrict events.
 If a window isn't listed in the array, button press and button release events
 are filtered from this window. If an event is filtered out, it isn't ignored,
 instead it is passed to the first window in the array, whose job it is to
 decide what to do with the event (it can just ignore it if it wants to).   */

 
UI_Globals::status UI_Globals::EventHandler(void)
{
  XEvent Event;
  int exit_flag = 0;

  do           // Start of a do-while loop, which is until exit_flag != 0
    {
      XNextEvent(DisplayPointer,&Event);     // Get an event from the X server,
                                             // then try to find the context
                                             // data for the window the event
                                             // belongs to.
      switch(FindEvent(&Event))
	{
	case okay:
	  break;
	case out_of_memory:
#ifdef DEBUG
	  cout << "UI_Globals::EventHandler - Out of memory error received"
	       << " from callback function\n";
#endif
	  return(out_of_memory);
	case bad_parameter:
#ifdef DEBUG
	  cout << "UI_Globals::EventHandler - Bad parameter error received"
	    << " from callback function\n";
#endif
	  return(bad_parameter);
	case unknown_error:
#ifdef DEBUG
	  cout << "UI_Globals::EventHandler - Unknown error received from"
	       << " callback function\n";
#endif
	  return(unknown_error);
	case EXIT:
	  exit_flag=1;
	  break;
	case ABORT:
#ifdef DEBUG
	  cout << "UI_Globals::EventHandler - ABORT!!\n";
#endif
	  return(ABORT);
	default:
#ifdef DEBUG
	  cout << "UI_Globals::EventHandler - Invalid value returned by "
	    << "callback function\n";
#endif
	  return(ABORT);
	}
    } while(exit_flag==0);
  return(okay);
}

UI_Globals::status UI_Globals::FlushEvents(void)
{
  XEvent Event;
  status retval=okay;

  XFlush(DisplayPointer);
  int count=XPending(DisplayPointer);
  for(int i=0; i<count; i++)
    {
      XNextEvent(DisplayPointer,&Event);     // Get an event from the X server,
                                             // then try to find the context
                                             // data for the window the event
                                             // belongs to.
      switch(FindEvent(&Event))
	{
	case okay:
	  break;
	case out_of_memory:
#ifdef DEBUG
	  cout << "UI_Globals::EventHandler - Out of memory error received"
	       << " from callback function\n";
#endif
	  return(out_of_memory);
	case bad_parameter:
#ifdef DEBUG
	  cout << "UI_Globals::EventHandler - Bad parameter error received"
	       << " from callback function\n";
#endif
	  return(bad_parameter);
	case unknown_error:
#ifdef DEBUG
	  cout << "UI_Globals::EventHandler - Unknown error received from"
	       << " callback function\n";
#endif
	  return(unknown_error);
	case EXIT:
	  retval=EXIT;
	  break;
	case ABORT:
#ifdef DEBUG
	  cout << "UI_Globals::EventHandler - ABORT!!\n";
#endif
	  return(ABORT);
	default:
#ifdef DEBUG
	  cout << "UI_Globals::EventHandler - Invalid value returned by "
	       << "callback function\n";
#endif
	  return(ABORT);
	}
    }
  XFlush(DisplayPointer);
  return(retval);
}

UI_Globals::status UI_Globals::FindEvent(XEvent *Event)
{
  X_Context *which_win;
  int i;
  Bool found;
  
  if(XFindContext(DisplayPointer,Event->xany.window,Contexts,
		  (XPointer *)&which_win)==0)
    {
      if(a_w_count!=0 && (Event->type==ButtonPress || 
			  Event->type==ButtonRelease)) // Check if events are
	{                                           // restricted. If they are,
	  found=False;                              // search the array of
	  for(i=0; i<a_w_count; i++)                // unresitricted windows
	    if(accept_wins[i]==Event->xany.window)
	      found=True;
	  if(found)
	    return(which_win->This->event_handler(Event));
                           // The window wasn't in the list to allow, so send
	                   // this event to the first window in the array
	  if(XFindContext(DisplayPointer,accept_wins[0],Contexts,
			  (XPointer *)&which_win)==0)
	    return(which_win->This->event_handler(Event));
	}
      else            // This is used if events are unrestricted
	return(which_win->This->event_handler(Event));
    }
#ifdef DEBUG2
  else
    {
      cout << "UI_Globals::EventHandler - Unable to find the window that " 
	   << "the event belongs to\n";
      cout << "Event type = " << Event->type << "   Window = "
	   << Event->xany.window << "   Serial no. = " << Event->xany.serial;
      if(Event->xany.send_event==True)
	cout << " a send event";
      cout << endl;
    }
#endif
  return(okay);
}

void UI_Globals::RestrictEvents(Window valid_wins[], int win_count)
{
  if(a_w_count!=0)
    delete accept_wins;
  accept_wins = new Window[win_count];
  for(int i=0; i<win_count; i++)
    accept_wins[i] = valid_wins[i];
  a_w_count = win_count;
}

void UI_Globals::UnrestrictedEvents(void)
{
  if(a_w_count!=0)
    delete accept_wins;
  a_w_count = 0;
}

// ************* All the functions from here down cannot be *************
// ************* called until the window has been registered ************
// ************ failure to comply will cause an assert trap! ************

unsigned int UI_Globals::wc2pix_x(world_c w)
{
  unsigned int r;

  assert(registered==true);
  if(w>MAX_WORLD_C_VAL)
    w=MAX_WORLD_C_VAL;
  r = (unsigned int)(w*x_multiplier);
  if(r>_width)
    r=_width;
  return(r);
}

unsigned int UI_Globals::wc2pix_h(world_c w)
{
  assert(registered==true);
  return (unsigned int)(w*y_multiplier);
}

unsigned int UI_Globals::wc2pix_w(world_c w)
{
  assert(registered==true);
  return (unsigned int)(w*x_multiplier);
}

unsigned int UI_Globals::wc2pix_y(world_c w)
{
  unsigned int r;

  assert(registered==true);
  if(w>MAX_WORLD_C_VAL)
    w=MAX_WORLD_C_VAL;
  r = (unsigned int)(w*y_multiplier);
  if(r>_height)
    r=_height;
  return(_height-r);
}

world_c UI_Globals::pix_x2wc(unsigned int p)
{
  assert(registered==true);
  float w = float(p)/x_multiplier;
  if(w>MAX_WORLD_C_VAL)
    w=MAX_WORLD_C_VAL;
  return(w);
}

world_c UI_Globals::pix_y2wc(unsigned int p)
{
  assert(registered==true);
  float w = float(p)/y_multiplier;
  if(w>MAX_WORLD_C_VAL)
    w=MAX_WORLD_C_VAL;
  return(MAX_WORLD_C_VAL-w);
}

world_c UI_Globals::pix_h2wc(unsigned int p)
{
  assert(registered==true);
  return float(p)/y_multiplier;
}

world_c UI_Globals::pix_w2wc(unsigned int p)
{
  assert(registered==true);
  return float(p)/x_multiplier;
}

world_c UI_Globals::Height(void)
{
  assert(registered==true);
  return MAX_WORLD_C_VAL*float(_height) / float(This_Context.Parent->height());
}

world_c UI_Globals::Width(void)
{
  assert(registered==true);
  return MAX_WORLD_C_VAL*float(_width) / float(This_Context.Parent->width());
}

void UI_Globals::ResizeWindow(unsigned int new_h, unsigned int new_w)
{
  assert(registered==true);
  _height = new_h;
  _width = new_w;
  x_multiplier = float(_width) / MAX_WORLD_C_VAL;
  y_multiplier = float(_height) / MAX_WORLD_C_VAL;
  XResizeWindow(DisplayPointer,_win_id,_width,_height);
}
