/* Function prototypes for motionvector.c */
#ifndef __MOTIONVECTOR__
#define __MOTIONVECTOR__

#include "decls.h"
__BEGIN_DECLS
extern void ComputeForwVector(int *recon_right_for_ptr ,
			      int *recon_down_for_ptr);
extern void ComputeBackVector(int *recon_right_back_ptr ,
			       int *recon_down_back_ptr);
__END_DECLS
#endif
