/* This is the source file for my text window class */
/* (c)1994 Alexis 'Milamber' Ashley */
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "time_win.H"
#include <assert.h>
#include <stdio.h>

char TimeWindow::DefaultFont[80] = "*-helvetica-bold-r-*-18-*";
                                            // The name of the default font
                                            // used for time windows
char TimeWindow::high_name[80] = "grey90";  // The name of the colour used for
                                            // the bright 3D lines
char TimeWindow::low_name[80] = "grey56";   // The name of the colour used for
                                            // the dark 3D lines
UI_Globals::opt_list TimeWindow::resources[] =
{                                           // The resource list for this class
  { "timewindow.highlight"  , high_name   },
  { "timewindow.lowlight"   , low_name    },
  { "" , NULL }
};

unsigned int TimeWindow::BorderWidth=1;
XFontStruct *TimeWindow::Default_Font=NULL; //Default font for all time windows
colour TimeWindow::high_colour; // Colour value for bright lines
colour TimeWindow::low_colour;  // Colour value for dark lines
GC TimeWindow::highlight;       // GC for bright lines
GC TimeWindow::lowlight;        // GC for dark lines
int TimeWindow::count=0;        // Count of how many time windows there are

TimeWindow::TimeWindow(UI_Globals *parent,world_c x,world_c y, corner relto,
		       const char * const fgcolour,
		       const char * const bgcolour,
		       const char * const font,
		       unsigned int Border_Width)
:SimpleSubWindow(parent,x,y,calc_height(font),calc_width(font),this,0,relto,
		 fgcolour,bgcolour,Border_Width)
{
  XColor tmp_col;  //This is used during allocation of high_colour & low_colour
  XGCValues xgcv;  //This structure is used in creating this window's
                   //graphics context

// Check for X resources

  CheckResources(resources);

// Load the font into memory

  if(strcmp(DefaultFont,font)==0)
    xfs = Default_Font;
  else
    {
      xfs = XLoadQueryFont(DispPointer(),font);
      if(xfs==NULL)
	xfs = Default_Font;
    }
  if(Default_Font==NULL && xfs==NULL)
    xfs = Default_Font = XLoadQueryFont(DispPointer(),DefaultFont);
  assert(xfs!=NULL);

// Create the GC

  xgcv.foreground = fg_colour;
  xgcv.background = bg_colour;
  xgcv.font = xfs->fid;
  GraphicsContext = XCreateGC(DispPointer(),WinId(),(GCForeground |
			      GCBackground | GCFont),&xgcv);

// If it's the first initiation of the class, then the colours for the bright
// and dark lines need to be allocated & the GCs need creating

  if(count++==0)
    {
      if(XParseColor(DispPointer(),Colourmap,high_name,&tmp_col)==0 ||
	 XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
	high_colour = White;
      else
	high_colour = tmp_col.pixel;
      if(XParseColor(DispPointer(),Colourmap,low_name,&tmp_col)==0 ||
	 XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
	low_colour = Black;
      else
	low_colour = tmp_col.pixel;
      long mask = GCForeground | GCBackground;
      xgcv.background = bg_colour;
      xgcv.foreground = high_colour;
      highlight = XCreateGC(DispPointer(),WinId(),mask,&xgcv);
      xgcv.foreground = low_colour;
      lowlight = XCreateGC(DispPointer(),WinId(),mask,&xgcv);
    }

// Now calculate where the bright & dark lines have to be draw to make the
// button look 3D

  high_seg[0].x1=0;                    high_seg[0].y1=0;
  high_seg[0].x2=width();              high_seg[0].y2=0;
  high_seg[1].x1=1;                    high_seg[1].y1=1;
  high_seg[1].x2=width()-1;            high_seg[1].y2=1;
  high_seg[2].x1=0;                    high_seg[2].y1=1;
  high_seg[2].x2=0;                    high_seg[2].y2=height();
  high_seg[3].x1=1;                    high_seg[3].y1=2;
  high_seg[3].x2=1;                    high_seg[3].y2=height()-1;

  low_seg[0].x1=1;                     low_seg[0].y1=height()-BorderWidth;
  low_seg[0].x2=width();               low_seg[0].y2=height()-BorderWidth;
  low_seg[1].x1=2;                     low_seg[1].y1=height()-1-BorderWidth;
  low_seg[1].x2=width()-1;             low_seg[1].y2=height()-1-BorderWidth;
  low_seg[2].x1=width()-BorderWidth;   low_seg[2].y1=1;
  low_seg[2].x2=width()-BorderWidth;   low_seg[2].y2=height()-1;
  low_seg[3].x1=width()-1-BorderWidth; low_seg[3].y1=2;
  low_seg[3].x2=width()-1-BorderWidth; low_seg[3].y2=height()-2;

// Clear the SendEvent flag

  SendEventFlag=0;

// Set xpos, ypos and string

  xpos = 5;
  ypos = height()-7;
  strcpy(string,"XXh XXm XX.XXs");

// Finished
}

TimeWindow::~TimeWindow(void)
{
// Free the colours that were allocated by the class, being careful not
// to try to deallocate black or white, which is a read-only colours

// If a font was loaded specifically for this window, free this font

  if(xfs!=Default_Font)
    XFreeFont(DispPointer(),xfs);

// Free the graphics contexts that were created for this window

  XFreeGC(DispPointer(),GraphicsContext);

// If this is the last time window, free the default font, if it has been
// loaded, and free the bright and dark 3D colours

  if(--count==0)
    {       
      colour cols[2];
      cols[0] = high_colour;
      cols[1] = low_colour;
      for(int i=0; i<2; i++)
	if(cols[i]!=White && cols[i]!=Black)
	  {
	    XFreeColors(DispPointer(),Colourmap,&cols[i],1,0);
	  }
      if(Default_Font!=NULL)
	{
	  XFreeFont(DispPointer(),Default_Font);
	  Default_Font = NULL;
	}
    }
}

void TimeWindow::SetTime(Codec::hms_addr value, bool nicely)
{
  XEvent Event;

  sprintf(string,"%.2dh %.2dm %.2d.%.2ds ",value.hours,value.mins,
	  value.secs,value.hsecs);
  if(nicely==false)
    {
	  XDrawImageString(DispPointer(),WinId(),GraphicsContext,xpos,ypos,
			   string,strlen(string));
	  return;
    }
  if(!SendEventFlag)
    {
      Event.type = Expose;
      Event.xexpose.window = WinId();
      Event.xexpose.display = DispPointer();
      Event.xexpose.x=0;
      Event.xexpose.y=0;
      Event.xexpose.width = width();
      Event.xexpose.height = height();
      Event.xexpose.count = 0;
      XSendEvent(DispPointer(),WinId(),False,0,&Event);
      SendEventFlag=1;
    }
}

UI_Globals::status TimeWindow::event_handler(XEvent *Event)
{
  switch(Event->type)
    {
    case Expose:
      if(Event->xexpose.count==0)
	{
	  if(Event->xexpose.send_event==False)
	    {
	      XClearWindow(DispPointer(),WinId());
	      XDrawSegments(DispPointer(),WinId(),highlight,high_seg,4);
	      XDrawSegments(DispPointer(),WinId(),lowlight,low_seg,4);
	    }
	  XDrawImageString(DispPointer(),WinId(),GraphicsContext,xpos,ypos,
			   string,strlen(string));
	  SendEventFlag=0;
	}
      break;
    default:
      break;
    }
	
  return(okay);
}

unsigned int TimeWindow::calc_height(const char * const font)
{
  XFontStruct *Font;

// Load the font into memory

  if(strcmp(DefaultFont,font)==0)
    Font = Default_Font;
  else
    {
      Font = XLoadQueryFont(DispPointer(),font);
      if(Font==NULL)
	Font = Default_Font;
    }
  if(Font==NULL)
    Font = XLoadQueryFont(DispPointer(),DefaultFont);
  assert(Font!=NULL);

// Calculate the window height

  unsigned int retval = Font->max_bounds.ascent + Font->max_bounds.descent+10;

// Unload the font

  XFreeFont(DispPointer(),Font);

// Return

  return(retval);
}

unsigned int TimeWindow::calc_width(const char * const font)
{
  XFontStruct *Font;

// Load the font into memory

  if(strcmp(DefaultFont,font)==0)
    Font = Default_Font;
  else
    {
      Font = XLoadQueryFont(DispPointer(),font);
      if(Font==NULL)
	Font = Default_Font;
    }
  if(Font==NULL)
    Font = XLoadQueryFont(DispPointer(),DefaultFont);
  assert(Font!=NULL);

  unsigned int retval = XTextWidth(Font,"XXh XXm XX.XXs",
				   strlen("XXh XXm XX.XXs"))+10;

// Unload the font

  XFreeFont(DispPointer(),Font);

// Return

  return retval;
}

