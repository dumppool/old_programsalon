/* Function prototypes for jrevdct.c */
#ifndef __JREVDCT__
#define  __JREVDCT__
#include "decls.h"
__BEGIN_DECLS
extern void init_pre_idct(void);
extern void j_rev_dct_sparse(DCTBLOCK data , int pos);
extern void j_rev_dct(DCTBLOCK data);
extern void j_rev_dct_sparse(DCTBLOCK data , int pos);
extern void j_rev_dct(DCTBLOCK data);
__END_DECLS
#endif
