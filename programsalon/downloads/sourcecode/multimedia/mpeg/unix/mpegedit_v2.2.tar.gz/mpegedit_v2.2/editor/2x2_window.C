/*********************************************************/
/* This class controls access to the large colour window */
/*                                                       */
/*         (c)1994 Alexis 'Milamber' Ashley              */
/*********************************************************/
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "2x2_window.H"
#include "yuv.H"
#include <assert.h>
#include <iostream.h>
#include <stdlib.h>

DblWindow::DblWindow(UI_Globals *parent, world_c x, world_c y, 
			 unsigned int height, unsigned int width, void (*cb)(void) )
: YUV_Window(parent,x,y,height*2,width*2,this, ButtonPressMask | 
	     ButtonReleaseMask)
{

#ifdef SH_MEM
  cout << "Starting Shared memory ";
  if( !XShmQueryExtension(DispPointer()) )
    {
      cout << endl;
      using_shm = false;
      cerr << "Shared memory not supported\n";
      cerr << "Reverting to normal Xlib.\n";
    }
  else
    {
      cout << '.';
      using_shm=true;
      CompletionType=XShmGetEventBase(DispPointer())+ShmCompletion;
    }
#endif

  status stat = InitColours();
  if(stat!=okay)
    {
      abort();
    }
  stat = InitDitherArray();
  if(stat!=okay)
    {
      abort();
    }

#ifdef SH_MEM
  if(using_shm)
    {
      cout << '.';
      ximage = XShmCreateImage(DispPointer(), None, 8, ZPixmap, NULL,
			       &shminfo, width * 2, height * 2);
      if (ximage == NULL)
	{
	  using_shm = false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
    }
  if(using_shm)
    {
      cout << '.';
      shminfo.shmid = shmget(IPC_PRIVATE, (ximage->bytes_per_line * 
					   ximage->height),
			     IPC_CREAT | 0777);

      if (shminfo.shmid < 0)
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
    }
  if(using_shm)
    {
      cout << '.';
      shminfo.shmaddr = (char *) shmat(shminfo.shmid, 0, 0);
      if (shminfo.shmaddr == ((char *) -1))
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
      ximage->data = shminfo.shmaddr;
      shminfo.readOnly = False;
      
      XShmAttach(DispPointer(), &shminfo);
      XSync(DispPointer(), False);
    }
  if(using_shm)
    {
      cout << '.';
      FlushEvents();
      XErrorEvent Xerr = GetLastError();
      if (Xerr.error_code==BadAccess && Xerr.request_code==129 &&
	  Xerr.minor_code==1)
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
      else
	{
	  shmctl(shminfo.shmid, IPC_RMID, 0);
	  cout << "  shared memory fully operational\n";
	}
    }
  if(!using_shm)
    {

#endif

      char dummy;
      
      ximage = XCreateImage(DispPointer(),None,8,ZPixmap,0,&dummy,width*2,
			    height*2,8,0);
      ximage->data = new byte[ximage->bytes_per_line*height*2];
      assert(ximage->data!=NULL);

#ifdef SH_MEM
    }
#endif

  image_available = false;
  callback = cb;
}

DblWindow::~DblWindow(void)
{
  long tmp_pixel;
  int ncolors = LUM_RANGE*CB_RANGE*CR_RANGE;

  FlushEvents();

  for(int j = 0; j < ncolors; j ++)
    {
      tmp_pixel = col_array[j];
      XFreeColors(DispPointer(), Colourmap, &tmp_pixel, 1, 0);
    }

#ifdef SH_MEM

  if(using_shm)
    {
      XShmDetach(DispPointer(), &shminfo);
      XDestroyImage(ximage);
      shmdt(shminfo.shmaddr);
    }
  else
    {
#endif

      delete ximage->data;
      XFree(ximage); 

#ifdef SH_MEM
    }
#endif

  XFreeGC(DispPointer(),gc);
  delete lum_values;
  delete cr_values;
  delete cb_values;
  delete dith_a;
}

/* The following code based on code in the files 2x2.c and gdith.c, both
 * from the University of California's mpeg_play programme.
 *
 * Copyright (c) 1992 The Regents of the University of California.
 * All rights reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

UI_Globals::status DblWindow::InitColours(void)
{
  int ncolors = LUM_RANGE*CB_RANGE*CR_RANGE;
  XColor xcolor;
  int i,lum_num, cr_num, cb_num;
  unsigned char r, g, b;

  lum_values = new int[LUM_RANGE];
  if(lum_values==NULL)
    return(out_of_memory);
  cr_values = new int[CR_RANGE];
  if(cr_values==NULL)
    return(out_of_memory);
  cb_values = new int[CB_RANGE];
  if(cb_values==NULL)
    return(out_of_memory);

  for (i=0; i<LUM_RANGE; i++)
    lum_values[i] = ((i * 256) / (LUM_RANGE)) + (256/(LUM_RANGE*2));

  for (i=0; i<CR_RANGE; i++)
    cr_values[i] = ((i * 256) / (CR_RANGE)) + (256/(CR_RANGE*2));

  for (i=0; i<CB_RANGE; i++)
    cb_values[i] = ((i * 256) / (CB_RANGE)) + (256/(CB_RANGE*2));

  gc = XCreateGC(DispPointer(), WinId(), 0, 0);

  xcolor.flags = DoRed | DoGreen | DoBlue;

  for (i=0; i<ncolors; i++)
    {
      lum_num = (i / (CR_RANGE*CB_RANGE))%LUM_RANGE;
      cr_num = (i / CB_RANGE)%CR_RANGE;
      cb_num = i % CB_RANGE;
      yuv2rgb(lum_values[lum_num], cr_values[cr_num], cb_values[cb_num],
	      &r, &g, &b);
      xcolor.red = r * 256;
      xcolor.green = g * 256;
      xcolor.blue = b * 256;
      if(XAllocColor(DispPointer(),Colourmap, &xcolor) == 0)
	{                    // If we were unable to allocate a colour, free
	  long tmp_pixel;    // the colours we've already allocated, and quit.
	  
	  for(int j = 0; j < i; j ++)
	    {
	      tmp_pixel = col_array[j];
	      XFreeColors(DispPointer(), Colourmap, &tmp_pixel, 1, 0);
	    }
	  cerr << "Unable to allocate the colours required to make the\n"
	    << "colour window.  Please re-run with the option -private cols\n";
	  return(out_of_memory);
	}
      col_array[i] = xcolor.pixel;
    }
  return(okay);
}

UI_Globals::status DblWindow::InitDitherArray(void)
{
  unsigned char *dith_ca;
  int numcodes;
  int l_range, cr_range, cb_range;
  int p1, p2, p3, p4;
  int l_dith, cr_dith, cb_dith;
  int big_part, small_part;
  int i;


  l_range = (LUM_RANGE-1)*4+1;
  cr_range = (CR_RANGE-1)*4+1;
  cb_range = (CB_RANGE-1)*4+1;

  numcodes =  l_range * cr_range * cb_range;

  dith_ca = dith_a = new unsigned char[numcodes*4];
  assert(dith_a!=NULL);

  for (i=0; i<numcodes; i++)
    {
      l_dith = i  % l_range;
      
      big_part = l_dith / 4;
      small_part = l_dith % 4;

      p1 = big_part + ((small_part > 0) ? 1 : 0);
      p2 = big_part + ((small_part > 2) ? 1 : 0);
      p3 = big_part;
      p4 = big_part + ((small_part > 1) ? 1 : 0);
      
      p1 *= CR_RANGE * CB_RANGE;
      p2 *= CR_RANGE * CB_RANGE;
      p3 *= CR_RANGE * CB_RANGE;
      p4 *= CR_RANGE * CB_RANGE;
      
      cr_dith = (i/l_range) % cr_range;
      
      big_part = cr_dith / 4;
      small_part = cr_dith % 4;
      
      p1 += (big_part + ((small_part > 0) ? 1 : 0))*CB_RANGE;
      p2 += (big_part + ((small_part > 2) ? 1 : 0))*CB_RANGE;
      p3 += (big_part)*CB_RANGE;
      p4 += (big_part + ((small_part > 1) ? 1 : 0))*CB_RANGE;
      
      cb_dith = (i/(cr_range*l_range)) % cb_range;
      
      big_part = cb_dith / 4;
      small_part = cb_dith % 4;
      
      p1 += (big_part + ((small_part > 0) ? 1 : 0));
      p2 += (big_part + ((small_part > 2) ? 1 : 0));
      p3 += (big_part);
      p4 += (big_part + ((small_part > 1) ? 1 : 0));
      
      *dith_ca++ = p1;
      *dith_ca++ = p2;
      *dith_ca++ = p3;
      *dith_ca++ = p4;
    }
  
  for (i=0; i<256; i++)
    {
      lval_a[i] = (i * l_range)/256;
      rval_a[i] = (i * cr_range)/256;
      bval_a[i] = (i * cb_range)/256;
      bval_a[i] *= cr_range * l_range * 4;
      rval_a[i] *= l_range * 4;
      lval_a[i] *= 4;
    }
  
  dith_ca = dith_a;
  
  for (i=0; i < (l_range * cr_range * cb_range); i++) {
    
    *dith_ca = col_array[*dith_ca];
    dith_ca++;
    *dith_ca = col_array[*dith_ca];
    dith_ca++;
    *dith_ca = col_array[*dith_ca];
    dith_ca++;
    *dith_ca = col_array[*dith_ca];
    dith_ca++;
  }
  return(okay);
}

UI_Globals::status DblWindow::DisplayFrame(frame &Frame, bool nicely)
{
  assert(Frame.width()==ximage->width/2);
  assert(Frame.height()==ximage->height/2);
  DitherImage(Frame.lum_ptr(),Frame.Cr_ptr(),Frame.Cb_ptr(),ximage->data,
	      Frame.width(),Frame.height());
  if(nicely)
    {
      XEvent Event;
      Event.type = Expose;
      Event.xexpose.window = WinId();
      Event.xexpose.display = DispPointer();
      Event.xexpose.x=0;
      Event.xexpose.y=0;
      Event.xexpose.width = width();
      Event.xexpose.height = height();
      Event.xexpose.count = 0;
      XSendEvent(DispPointer(),WinId(),False,0,&Event);
    }
  else
    {
#ifdef SH_MEM
      if(using_shm)
	{
	  XShmPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		       ximage->height,True);
	}
      else
#endif
	XPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		  ximage->height);
      XFlush(DispPointer());
    }
  image_available = true;
  return(okay);
}

/*
 *--------------------------------------------------------------
 *
 * DitherImage --
 *
 *	Dithers lum, cr, and cb channels togethor using predefined
 *      and computed 2x2 dither patterns. Each possible combination of
 *      lum, cr, and cb values combines to point to a particular dither
 *      pattern (2x2) which is used to represent the pixel. This assumes
 *      That the display plane is 4 times larger than the lumianance 
 *      plane. 
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *--------------------------------------------------------------
 */

void DblWindow::DitherImage(unsigned char *lum,unsigned char *cr,
				  unsigned char *cb,unsigned char *out,
				  int w,int h)
{
  int i, j;
  unsigned short *o1, *o2, *o3, *o4;
  unsigned char *l1, *l2, *base;
  unsigned char B, R;
  unsigned short *dith_ca;
  int big_adv = 3*w;
  int b_val, r_val, l_val;

  o1 = (unsigned short *)out;
  o2 = (unsigned short *)(out+(2*w));
  o3 = (unsigned short *)(out+(4*w));
  o4 = (unsigned short *)(out+(6*w));
  l1 = lum;
  l2 = lum+w;

  for (i=0; i<h; i+=2) {
    for(j=0; j<w; j+= 4) {
 
      B = cb[0];
      b_val = bval_a[B];
      R = cr[0];
      r_val = rval_a[R];
      base = dith_a + b_val + r_val;

      l_val = lval_a[l1[0]];
      dith_ca = (unsigned short *)(base + l_val);
      o1[0] = dith_ca[0];
      o2[0] = dith_ca[1];

      l_val = lval_a[l1[1]];
      dith_ca = (unsigned short *)(base + l_val);
      o1[1] = dith_ca[0];
      o2[1] = dith_ca[1];

      l_val = lval_a[l2[0]];
      dith_ca = (unsigned short *)(base + l_val);
      o3[0] = dith_ca[0];
      o4[0] = dith_ca[1];

      l_val = lval_a[l2[1]];
      dith_ca = (unsigned short *)(base + l_val);
      o3[1] = dith_ca[0];
      o4[1] = dith_ca[1];

      B = cb[1];
      b_val = bval_a[B];
      R = cr[1];
      r_val = rval_a[R];
      base = dith_a + b_val + r_val;

      l_val = lval_a[l1[2]];
      dith_ca = (unsigned short *)(base + l_val);
      o1[2] = dith_ca[0];
      o2[2] = dith_ca[1];

      l_val = lval_a[l1[3]];
      dith_ca = (unsigned short *)(base + l_val);
      o1[3] = dith_ca[0];
      o2[3] = dith_ca[1];

      l_val = lval_a[l2[2]];
      dith_ca = (unsigned short *)(base + l_val);
      o3[2] = dith_ca[0];
      o4[2] = dith_ca[1];

      l_val = lval_a[l2[3]];
      dith_ca = (unsigned short *)(base + l_val);
      o3[3] = dith_ca[0];
      o4[3] = dith_ca[1];

      o1 += 4;
      o2 += 4;
      o3 += 4;
      o4 += 4;
      l1 += 4;
      l2 += 4;
      cb += 2;
      cr += 2;
    }    

    l1 += w;
    l2 += w;
    o1 += big_adv;
    o2 += big_adv;
    o3 += big_adv;
    o4 += big_adv;
  }
}

UI_Globals::status DblWindow::event_handler(XEvent *Event)
{
  if(Event->type==Expose && Event->xexpose.count==0 && image_available)
    {
#ifdef SH_MEM
      if(using_shm)
	{
	  XShmPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		       ximage->height,True);
	}
      else
#endif
	XPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		  ximage->height);
      XSync(DispPointer(),False);
    }
  else if(Event->type==ButtonPress && callback!=NULL)
    {
      (*callback)();
    }
  return(UI_Globals::okay);
}
