#ifndef __DECODER__
#define __DECODER__

#include "decls.h"
#include "dmpeg.h"

/* Declarations of functions. */
__BEGIN_DECLS
extern void ReconIMBlock(VidStream *vid_stream,int bnum);
extern void ReconPMBlock(VidStream *vid_stream,int bnum,int recon_right_for,
			 int recon_down_for,int zflag);
extern void ReconBMBlock(VidStream *vid_stream,int bnum,int recon_right_back,
			 int recon_down_back,int zflag);
extern void ReconBiMBlock(VidStream *vid_stream,int bnum,int recon_right_for,
			  int recon_down_for,int recon_right_back,
			  int recon_down_back,int zflag);
extern void ReconSkippedBlock(unsigned char *source,unsigned char *dest,
			      int row,int col,int row_size,int right,int down,
			      int right_half,int down_half,int width);
extern int ParseSeqHead(VidStream *vid_stream);
extern int ParseGOP(VidStream *vid_stream);
extern int ParsePicture(VidStream *vid_stream);
extern int ParseSlice(VidStream *vid_stream);
extern int ParseMacroBlock(VidStream *vid_stream);
extern void ProcessSkippedPFrameMBlocks(VidStream *vid_stream);
extern void ProcessSkippedBFrameMBlocks(VidStream *vid_stream);
extern void init_stats(void);
extern void PrintAllStats(void);
extern double ReadSysClock(void);
extern void PrintTimeInfo(void);
extern VidStream *NewVidStream(int bufLength);
extern void DestroyVidStream(VidStream *astream );
extern int ParseHeader(VidStream *vid_stream);
extern PictImage *NewPictImage(unsigned int width , unsigned int height);
extern void DestroyPictImage(PictImage *apictimage);
extern PictImage *GetPictImage(VidStream *vid_stream);
extern void UpdateVidStream(VidStream *vid_stream);
extern void ReadHeaderOnly(VidStream *vid_stream);
extern void ToggleBFlag(void);
extern void TogglePFlag(void);
__END_DECLS

extern int zigzag[64][2];

#endif
