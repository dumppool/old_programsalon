/*******************************************************/
/* This class controls access to a small colour window */
/*                                                     */
/*           (c)1994 Alexis 'Milamber' Ashley          */
/*******************************************************/
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "colour_window.H"
#include "yuv.H"
#include <assert.h>
#include <stdlib.h>

ColourWindow::ColourWindow(UI_Globals *parent,world_c x,world_c y,
		       unsigned int height,unsigned int width,
		       void (*cb)(void) )
: YUV_Window(parent,x,y,height,width,this, ButtonPressMask | 
	     ButtonReleaseMask)
{
#ifdef SH_MEM
  cout << "Starting Shared memory ";
  if( !XShmQueryExtension(DispPointer()) )
    {
      cout << endl;
      using_shm = false;
      cerr << "Shared memory not supported\n";
      cerr << "Reverting to normal Xlib.\n";
    }
  else
    {
      cout << '.';
      using_shm=true;
      CompletionType=XShmGetEventBase(DispPointer())+ShmCompletion;
    }
#endif

  status stat = InitColours();
  if(stat!=okay)
    {
      abort();
    }
  stat = InitDitherArray();
  if(stat!=okay)
    {
      abort();
    }

#ifdef SH_MEM
  if(using_shm)
    {
      cout << '.';
      ximage = XShmCreateImage(DispPointer(), None, 8, ZPixmap, NULL,
			       &shminfo, width , height);
      if (ximage == NULL)
	{
	  using_shm = false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
    }
  if(using_shm)
    {
      cout << '.';
      shminfo.shmid = shmget(IPC_PRIVATE, (ximage->bytes_per_line * 
					   ximage->height),
			     IPC_CREAT | 0777);

      if (shminfo.shmid < 0)
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
    }
  if(using_shm)
    {
      cout << '.';
      shminfo.shmaddr = (char *) shmat(shminfo.shmid, 0, 0);
      if (shminfo.shmaddr == ((char *) -1))
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
      ximage->data = shminfo.shmaddr;
      shminfo.readOnly = False;
      
      XShmAttach(DispPointer(), &shminfo);
      XSync(DispPointer(), False);
    }
  if(using_shm)
    {
      cout << '.';
      FlushEvents();
      XErrorEvent Xerr = GetLastError();
      if (Xerr.error_code==BadAccess && Xerr.request_code==129 &&
	  Xerr.minor_code==1)
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
      else
	{
	  shmctl(shminfo.shmid, IPC_RMID, 0);
	  cout << "  shared memory fully operational\n";
	}
    }
  if(!using_shm)
    {

#endif
      char dummy;
      
      ximage=XCreateImage(DispPointer(),None,8,ZPixmap,0,&dummy,
			  width,height,8,0);
      ximage->data = new byte[ximage->bytes_per_line*height];
      assert(ximage->data!=NULL);
#ifdef SH_MEM
    }
#endif
  image_available=false;
  callback = cb;
}

ColourWindow::~ColourWindow(void)
{
  int ncolors = LUM_RANGE*CB_RANGE*CR_RANGE;
  long tmp_pixel;
  int j;

  FlushEvents();


  for(j = 0; j < ncolors; j ++)
    {
      tmp_pixel = col_array[j];
      XFreeColors(DispPointer(), Colourmap, &tmp_pixel, 1, 0);
    }

  XFreeGC(DispPointer(),gc);

#ifdef SH_MEM

  if(using_shm)
    {
      XShmDetach(DispPointer(), &shminfo);
      XDestroyImage(ximage);
      shmdt(shminfo.shmaddr);
    }
  else
    {
#endif

      delete ximage->data;
      XFree(ximage);

#ifdef SH_MEM
    }
#endif
}

/* The following code based on code in the files ordered.c and gdith.c, both
 * from the University of California's mpeg_play programme.
 *
 * Copyright (c) 1992 The Regents of the University of California.
 * All rights reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

UI_Globals::status ColourWindow::InitColours(void)
{
  int ncolors = LUM_RANGE*CB_RANGE*CR_RANGE;
  XColor xcolor;
  int i,lum_num, cr_num, cb_num;
  unsigned char r, g, b;

  lum_values = new int[LUM_RANGE];
  if(lum_values==NULL)
    return(out_of_memory);
  cr_values = new int[CR_RANGE];
  if(cr_values==NULL)
    return(out_of_memory);
  cb_values = new int[CB_RANGE];
  if(cb_values==NULL)
    return(out_of_memory);

  for (i=0; i<LUM_RANGE; i++)
    lum_values[i] = ((i * 256) / (LUM_RANGE)) + (256/(LUM_RANGE*2));

  for (i=0; i<CR_RANGE; i++)
    cr_values[i] = ((i * 256) / (CR_RANGE)) + (256/(CR_RANGE*2));

  for (i=0; i<CB_RANGE; i++)
    cb_values[i] = ((i * 256) / (CB_RANGE)) + (256/(CB_RANGE*2));

  gc = XCreateGC(DispPointer(), WinId(), 0, 0);

  xcolor.flags = DoRed | DoGreen | DoBlue;

  for (i=0; i<ncolors; i++)
    {
      lum_num = (i / (CR_RANGE*CB_RANGE))%LUM_RANGE;
      cr_num = (i / CB_RANGE)%CR_RANGE;
      cb_num = i % CB_RANGE;
      yuv2rgb(lum_values[lum_num], cr_values[cr_num], cb_values[cb_num],
	      &r, &g, &b);
      xcolor.red = r * 256;
      xcolor.green = g * 256;
      xcolor.blue = b * 256;
      if(XAllocColor(DispPointer(),Colourmap, &xcolor) == 0)
	{                    // If we were unable to allocate a colour, free
	  long tmp_pixel;    // the colours we've already allocated, and quit.
	  
	  for(int j = 0; j < i; j ++)
	    {
	      tmp_pixel = col_array[j];
	      XFreeColors(DispPointer(), Colourmap, &tmp_pixel, 1, 0);
	    }
	  cerr << "Unable to allocate the colours required to make the\n"
	    << "colour window.  Please re-run with the option -private cols\n";
	  return(out_of_memory);
	}
      col_array[i] = xcolor.pixel;
    }
  return(okay);
}


/*
 *--------------------------------------------------------------
 *
 *  InitDitherArray--
 *
 *	Structures intialized for ordered dithering. 
 *
 * Results:
 *	None.
 *
 * Side effects:
 *      None.
 *
 *--------------------------------------------------------------
 */

UI_Globals::status ColourWindow::InitDitherArray(void)
{
  int i, j, k, err_range, threshval;
  unsigned char *lmark, *cmark;

  for (i=0; i<DITH_SIZE; i++) {
    lmark = l_darrays[i];

    for (j=0; j<lum_values[0]; j++) {
      *lmark++ = 0;
    }

    for (j=0; j<(LUM_RANGE-1); j++) {
      err_range = lum_values[j+1] - lum_values[j];
      threshval = ((i * err_range) / DITH_SIZE)+lum_values[j];

      for (k=lum_values[j]; k<lum_values[j+1]; k++) {
	if (k > threshval) *lmark++ = ((j+1) * (CR_RANGE * CB_RANGE));
	else *lmark++ = (j * (CR_RANGE * CB_RANGE));
      }
    }

    for (j=lum_values[LUM_RANGE-1]; j<256; j++) {
      *lmark++ = (LUM_RANGE-1)*(CR_RANGE * CB_RANGE);
    }
  }

  for (i=0; i<DITH_SIZE; i++) {
    cmark = cr_darrays[i];

    for (j=0; j<cr_values[0]; j++) {
      *cmark++ = 0;
    }

    for (j=0; j<(CR_RANGE-1); j++) {
      err_range = cr_values[j+1] - cr_values[j];
      threshval = ((i * err_range) / DITH_SIZE)+cr_values[j];

      for (k=cr_values[j]; k<cr_values[j+1]; k++) {
	if (k > threshval) *cmark++ = ((j+1) * CB_RANGE);
	else *cmark++ = (j * CB_RANGE);
      }
    }

    for (j=cr_values[CR_RANGE-1]; j<256; j++) {
      *cmark++ = (CR_RANGE-1)*(CB_RANGE);
    }
  }

  for (i=0; i<DITH_SIZE; i++) {
    cmark = cb_darrays[i];

    for (j=0; j<cb_values[0]; j++) {
      *cmark++ = 0;
    }

    for (j=0; j<(CB_RANGE-1); j++) {
      err_range = cb_values[j+1] - cb_values[j];
      threshval = ((i * err_range) / DITH_SIZE)+cb_values[j];

      for (k=cb_values[j]; k<cb_values[j+1]; k++) {
	if (k > threshval) *cmark++ = j+1;
	else *cmark++ = j;
      }
    }

    for (j=cb_values[CB_RANGE-1]; j<256; j++) {
      *cmark++ = CB_RANGE-1;
    }
  }

  return(okay);
}

UI_Globals::status ColourWindow::DisplayFrame(frame &Frame, bool nicely)
{
  assert(Frame.width()==ximage->width);
  assert(Frame.height()==ximage->height);
  DitherImage(Frame.lum_ptr(),Frame.Cr_ptr(),Frame.Cb_ptr(),ximage->data,
	      Frame.width(),Frame.height());
  if(nicely)
    {
      XEvent Event;
      Event.type = Expose;
      Event.xexpose.window = WinId();
      Event.xexpose.display = DispPointer();
      Event.xexpose.x=0;
      Event.xexpose.y=0;
      Event.xexpose.width = width();
      Event.xexpose.height = height();
      Event.xexpose.count = 0;
      XSendEvent(DispPointer(),WinId(),False,0,&Event);
    }
  else
    {
#ifdef SH_MEM
      if(using_shm)
	{
	  XShmPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		       ximage->height,True);
	}
      else
#endif
	XPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		  ximage->height);
      XFlush(DispPointer());
    }
  image_available = true;
  return(okay);
}


/*
 *--------------------------------------------------------------
 *
 * DitherImage --
 *
 *      Dithers an image using an ordered dither.
 *      Assumptions made:
 *        1) The color space is allocated y:cr:cb = 8:4:4
 *        2) The spatial resolution of y:cr:cb is 4:1:1
 *      The channels are dithered based on the standard
 *      ordered dither pattern for a 4x4 area. 
 *
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *--------------------------------------------------------------
 */

void ColourWindow::DitherImage(unsigned char *lum,unsigned char *cr,
				  unsigned char *cb,unsigned char *out,
				  int w,int h)
{
  unsigned char *l, *r, *b, *o1, *o2;
  unsigned char *l2;
  unsigned char L, R, B;
  int i, j;

  l = lum;
  l2 = lum+w;
  r = cr;
  b = cb;
  o1 = out;
  o2 = out+w;

  for (i=0; i<h; i+=4) {

    for (j=0; j<w; j+=8) {

      R = r[0]; B = b[0];

      L = l[0];
      o1[0] = col_array[(l_darrays[0][L]+cr_darrays[0][R]+cb_darrays[0][B])];
      L = l[1];
      o1[1] = col_array[(l_darrays[8][L]+cr_darrays[8][R]+cb_darrays[8][B])];
      L = l2[0];
      o2[0]=col_array[(l_darrays[12][L]+cr_darrays[12][R]+cb_darrays[12][B])];
      L = l2[1];
      o2[1]=col_array[(l_darrays[4][L]+cr_darrays[4][R]+cb_darrays[4][B])];

      R = r[1]; B = b[1];

      L = l[2];
      o1[2] = col_array[(l_darrays[2][L]+cr_darrays[2][R]+cb_darrays[2][B])];
      L = l[3];
      o1[3]=col_array[(l_darrays[10][L]+cr_darrays[10][R]+cb_darrays[10][B])];
      L = l2[2];
      o2[2]=col_array[(l_darrays[14][L]+cr_darrays[14][R]+cb_darrays[14][B])];
      L = l2[3];
      o2[3] = col_array[(l_darrays[6][L]+cr_darrays[6][R]+cb_darrays[6][B])];

      R = r[2]; B = b[2];
      L = l[4];
      o1[4] = col_array[(l_darrays[0][L]+cr_darrays[0][R]+cb_darrays[0][B])];
      L = l[5];
      o1[5] = col_array[(l_darrays[8][L]+cr_darrays[8][R]+cb_darrays[8][B])];
      L = l2[4];
      o2[4]=col_array[(l_darrays[12][L]+cr_darrays[12][R]+cb_darrays[12][B])];
      L = l2[5];
      o2[5] = col_array[(l_darrays[4][L]+cr_darrays[4][R]+cb_darrays[4][B])];

      R = r[3]; B = b[3];

      L = l[6];
      o1[6] = col_array[(l_darrays[2][L]+cr_darrays[2][R]+cb_darrays[2][B])];
      L = l[7];
      o1[7]=col_array[(l_darrays[10][L]+cr_darrays[10][R]+cb_darrays[10][B])];
      L = l2[6];
      o2[6]=col_array[(l_darrays[14][L]+cr_darrays[14][R]+cb_darrays[14][B])];
      L = l2[7];
      o2[7] = col_array[(l_darrays[6][L]+cr_darrays[6][R]+cb_darrays[6][B])];
      l += 8;
      l2 += 8;
      r += 4;
      b += 4;
      o1 += 8;
      o2 += 8;
    }

    l += w; l2 += w;
    o1 += w; o2 += w;

    for (j=0; j<w; j+=8) {

      R = r[0]; B = b[0];

      L = l[0];
      o1[0] = col_array[(l_darrays[3][L]+cr_darrays[3][R]+cb_darrays[3][B])];
      L = l[1];
      o1[1]=col_array[(l_darrays[11][L]+cr_darrays[11][R]+cb_darrays[11][B])];
      L = l2[0];
      o2[0]=col_array[(l_darrays[15][L]+cr_darrays[15][R]+cb_darrays[15][B])];
      L = l2[1];
      o2[1] = col_array[(l_darrays[7][L]+cr_darrays[7][R]+cb_darrays[7][B])];

      R = r[1]; B = b[1];

      L = l[2];
      o1[2] = col_array[(l_darrays[1][L]+cr_darrays[1][R]+cb_darrays[1][B])];
      L = l[3];
      o1[3] = col_array[(l_darrays[9][L]+cr_darrays[9][R]+cb_darrays[9][B])];
      L = l2[2];
      o2[2]=col_array[(l_darrays[13][L]+cr_darrays[13][R]+cb_darrays[13][B])];
      L = l2[3];
      o2[3] = col_array[(l_darrays[5][L]+cr_darrays[5][R]+cb_darrays[5][B])];

      R = r[2]; B = b[2];

      L = l[4];
      o1[4] = col_array[(l_darrays[3][L] + cr_darrays[3][R] + cb_darrays[3][B])];
      L = l[5];
      o1[5] = col_array[(l_darrays[11][L] + cr_darrays[11][R] + cb_darrays[11][B])];
      L = l2[4];
      o2[4] = col_array[(l_darrays[15][L] + cr_darrays[15][R] + cb_darrays[15][B])];
      L = l2[5];
      o2[5] = col_array[(l_darrays[7][L] + cr_darrays[7][R] + cb_darrays[7][B])];

      R = r[3]; B = b[3];

      L = l[6];
      o1[6] = col_array[(l_darrays[1][L] + cr_darrays[1][R] + cb_darrays[1][B])];
      L = l[7];
      o1[7] = col_array[(l_darrays[9][L] + cr_darrays[9][R] + cb_darrays[9][B])];
      L = l2[6];
      o2[6] = col_array[(l_darrays[13][L] + cr_darrays[13][R] + cb_darrays[13][B])];
      L = l2[7];
      o2[7] = col_array[(l_darrays[5][L] + cr_darrays[5][R] + cb_darrays[5][B])];

      l += 8;
      l2 += 8;
      r += 4;
      b += 4;
      o1 += 8;
      o2 += 8;
    }

    l += w; l2 += w;
    o1 += w; o2 += w;
  }
}

UI_Globals::status ColourWindow::event_handler(XEvent *Event)
{
  if(Event->type==Expose && Event->xexpose.count==0 && image_available)
    {
#ifdef SH_MEM
      if(using_shm)
	{
	  XShmPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		       ximage->height,True);
	}
      else
#endif
	XPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		  ximage->height);
      XSync(DispPointer(),False);
    }
  else if(Event->type==ButtonPress)
    {
      (*callback)();
    }
  return(UI_Globals::okay);
}
