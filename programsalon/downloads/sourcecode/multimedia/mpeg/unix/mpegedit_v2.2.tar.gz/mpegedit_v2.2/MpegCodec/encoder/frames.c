#include "frames.h"
#include "all.h"

void ComputeSNR(origData, newData, ySize, xSize, snr, psnr)
     register uint8 **origData;
     register uint8 **newData;
     int ySize;
     int xSize;
     float *snr;
     float *psnr;
{
    register int32	tempInt;
    register int y, x;
    int32	varOrig = 0;
    int32	varDiff = 0;

    /* compute Y-plane SNR */
    for ( y = 0; y < ySize; y++ ) {
	for ( x = 0; x < xSize; x++ ) {
	    tempInt = origData[y][x];
	    varOrig += (tempInt*tempInt);
	}
    }

    for ( y = 0; y < ySize; y++ ) {
	for ( x = 0; x < xSize; x++ ) {
	    tempInt = (origData[y][x]-newData[y][x]);
	    varDiff += (tempInt*tempInt);
	}
    }

    *snr = 10.0*log10((double)varOrig/(double)varDiff);
    *psnr = 20.0*log10(255.0/sqrt((double)varDiff/(double)(ySize*xSize)));
}
