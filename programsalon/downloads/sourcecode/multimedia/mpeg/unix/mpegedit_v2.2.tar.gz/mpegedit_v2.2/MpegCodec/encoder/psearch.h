/*===========================================================================*
 * psearch.h								     *
 *									     *
 *	Procedures concerned with the P-frame motion search		     *
 *									     *
 * EXPORTED PROCEDURES:							     *
 *	SetPixelSearch							     *
 *	SetPSearchAlg							     *
 *	SetSearchRange							     *
 *	MotionSearchPreComputation					     *
 *	PMotionSearch							     *
 *	PSearchName							     *
 *	PSubSampleSearch						     *
 *	PLogarithmicSearch						     *
 *									     *
 *===========================================================================*/

/*
 * Copyright (c) 1993 The Regents of the University of California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef __PSEARCH__
#define __PSEARCH__

#include "ansi.h"

__BEGIN_DECLS

extern boolean PMotionSearch _ANSI_ARGS_((LumBlock currentBlock,
					  EncoderMpegFrame *prev, int by,
					  int bx, int *motionY, int *motionX));

extern void SetPixelSearch _ANSI_ARGS_((char *searchType));

extern void SetPSearchAlg _ANSI_ARGS_((char *alg));

extern char *PSearchName _ANSI_ARGS_((void));

extern void SetSearchRange _ANSI_ARGS_((int pixels));

extern void MotionSearchPreComputation _ANSI_ARGS_((EncoderMpegFrame *frame));

extern int32 PSubSampleSearch _ANSI_ARGS_((LumBlock currentBlock,
					   EncoderMpegFrame *prev,
					   int by, int bx, int *motionY,
					   int *motionX));

extern int32 PLogarithmicSearch _ANSI_ARGS_((LumBlock currentBlock,
					     EncoderMpegFrame *prev,
					     int by, int bx, int *motionY,
					     int *motionX));

__END_DECLS

#endif
