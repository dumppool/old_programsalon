/* ************* BSTREAM.C   Bitstream file i/o class ***********
 * ****************** By Alexis 'Milamber' Ashley *************** 
 *
 * Copyright (C) 1995 Alexis Ashley          milamber@dcs.warwick.ac.uk
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "bstream.H"
#include <assert.h>

void ibstream::open(const char *name, int mode,int prot)
{
  ifstream::open(name,mode,prot);
  if(good())
    _is_open=true;
  reset_count();
}

ibstream& ibstream::BitRead(long int &value,int bits)
{
  assert(bits>0 && bits<33);
  value=0;
  for(int i=0; i<bits; i++)
    {
      value <<= 1;
      if(power==0)
	{
	  ifstream::read(&val,1);
	  power=128;
	}
      if((val & power)!=0)
	{
	  value |= 1;
	}
      power >>= 1;
    }
  return *this;
}

ibstream& ibstream::FlushRead(void)
{
  reset_count();
  return *this;
}

ibstream& ibstream::seekg(streampos pos)
{
  reset_count();
  ifstream::seekg(pos);
}

ibstream& ibstream::seekg(streamoff pos, seek_dir sd)
{
  reset_count();
  ifstream::seekg(pos,sd);
}

ibstream& ibstream::BitSeekg(long int pos, int bitpos)
{
  long val;

  assert(bitpos>=0);
  reset_count();
  pos += bitpos / 8;
  bitpos %= 8;
  ifstream::seekg(pos);
  if(bitpos)
    BitRead(val,bitpos);
  return *this;
}

void obstream::open(const char *name, int mode,int prot)
{
  ofstream::open(name,mode,prot);
  if(good())
    _is_open=true;
  reset_count();
}

obstream& obstream::BitWrite(long int value, int bits)
{
  assert(bits>0 && bits<33);
  value = value << 32-bits;
  for(int i=0; i<bits; i++)
    {
      if((value & 0x80000000)!=0)
	val += power;
      value = (value & 0x7FFFFFFF) << 1;
      power >>= 1;
      if(power==0)
	{
	  ofstream::write((unsigned char *)&val,1);
	  reset_count();
	}
    }
  return *this;
}

obstream& obstream::FlushWrite(void)
{
  if(power!=128)
    {
      ofstream::write(&val,1);
      reset_count();
    }
  return *this;
}

obstream& obstream::seekp(streampos pos)
{
  assert(pos>0);
  FlushWrite();
  ofstream::seekp(pos);
  reset_count();
  return *this;
}

obstream& obstream::seekp(streamoff pos, seek_dir sd)
{
  FlushWrite();
  ofstream::seekp(pos,sd);
  reset_count();
  return *this;
}

void bstream::open(const char *name, int mode,int prot)
{
  ibstream::open(name,mode,prot);
  obstream::open(name,mode,prot);
}
