/* Class to provide scrolling boxes       (c)1995 Alexis 'Milamber' Ashley */
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "scroll_box.H"

char ScrollBox::DefaultFont[80] = "*-helvetica-bold-r-*-140-*";
                                            // The name of the default font
                                            // used for text windows
unsigned int ScrollBox::BorderWidth=2;

ScrollBox::ScrollBox(UI_Globals *parent, world_c x, world_c y, world_c height,
	    world_c width,
	    const char * const fgcolour,
	    const char * const bgcolour,
	    const char * const font,
	    unsigned int Border_Width)
: TextWindow(parent,x,y,height,width,true,fgcolour,bgcolour,font,Border_Width)
{
  font_height = TextHeight(this);
  Spacing = TextWidth(this,"n");
  win_height = int(height/TextHeight(parent));
  textlength = 0;
  curr_pos = 0;
}

ScrollBox::~ScrollBox(void)
{
  char *ptr;

  textlist.Rewind();
  while(textlist.At_End()==false)
    {
      ptr = textlist.Read();
      delete ptr;
      textlist.Advance();
    }
}

void ScrollBox::AddText(char *string)
{
  char *ptr;
  int i;

  while(textlist.At_End()==false)
    textlist.Advance();
  ptr = new char[strlen(string)+1];
  strcpy(ptr,string);
  textlist.Write(ptr);
  textlength++;
  world_c y = MAX_WORLD_C_VAL - font_height;
  TextWindow::ClearAllText();
  textlist.Set_Pos(curr_pos);
  for(i=0; i<win_height && (i+curr_pos)<textlength; i++)
    {
      TextWindow::AddText(Spacing,y,textlist.Read());
      y -= font_height;
      textlist.Advance();
    }
}

void ScrollBox::ClearAllText(void)
{
  char *ptr;

  textlist.Rewind();
  while(textlist.At_End()==false)
    {
      ptr = textlist.Read();
      delete ptr;
      textlist.Delete();
    }
  TextWindow::ClearAllText();
  textlength=0;
  curr_pos=0;
}

void ScrollBox::ScrollUp(int amount)
{
  int i;

  if(curr_pos==0)
    return;
  if(amount>curr_pos)
    curr_pos=0;
  else
    curr_pos -= amount;
  world_c y = MAX_WORLD_C_VAL - font_height;
  TextWindow::ClearAllText();
  textlist.Set_Pos(curr_pos);
  for(i=0; i<win_height && (i+curr_pos)<textlength; i++)
    {
      TextWindow::AddText(Spacing,y,textlist.Read());
      y -= font_height;
      textlist.Advance();
    }
}

void ScrollBox::ScrollDown(int amount)
{
  int i;

  if(curr_pos>(textlength-win_height-1))
    return;
  if(amount+curr_pos>textlength)
    curr_pos=textlength;
  else
    curr_pos += amount;
  world_c y = MAX_WORLD_C_VAL - font_height;
  TextWindow::ClearAllText();
  textlist.Set_Pos(curr_pos);
  for(i=0; i<win_height && (i+curr_pos)<textlength; i++)
    {
      TextWindow::AddText(Spacing,y,textlist.Read());
      y -= font_height;
      textlist.Advance();
    }
}
