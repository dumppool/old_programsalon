/************************************************************/
/* This class controls access to a small black&white window */
/*                                                          */
/*           (c)1994 Alexis 'Milamber' Ashley               */
/************************************************************/
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bw_window.H"
#include "yuv.H"
#include <assert.h>
#include <stdlib.h>

BwWindow::BwWindow(UI_Globals *parent,world_c x,world_c y,unsigned int height,
		   unsigned int width, void (*cb)(void) )
: YUV_Window(parent,x,y,height,width,this, ButtonPressMask |
	     ButtonReleaseMask)
{
#ifdef SH_MEM
  cout << "Starting Shared memory ";
  if( !XShmQueryExtension(DispPointer()) )
    {
      cout << endl;
      using_shm = false;
      cerr << "Shared memory not supported\n";
      cerr << "Reverting to normal Xlib.\n";
    }
  else
    {
      cout << '.';
      using_shm=true;
      CompletionType=XShmGetEventBase(DispPointer())+ShmCompletion;
    }
#endif

  status stat = InitColours();
  if(stat!=okay)
    {
      abort();
    }
  stat = InitDitherArray();
  if(stat!=okay)
    {
      abort();
    }

#ifdef SH_MEM
  if(using_shm)
    {
      cout << '.';
      ximage = XShmCreateImage(DispPointer(), None, 1, XYBitmap, NULL,
			       &shminfo, width, height);
      if (ximage == NULL)
	{
	  using_shm = false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
      else
	{
	  ximage->byte_order = MSBFirst;
	  ximage->bitmap_bit_order = MSBFirst;
	}
    }
  if(using_shm)
    {
      cout << '.';
      shminfo.shmid = shmget(IPC_PRIVATE, (ximage->bytes_per_line * 
					   ximage->height),
			     IPC_CREAT | 0777);

      if (shminfo.shmid < 0)
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
    }
  if(using_shm)
    {
      cout << '.';
      shminfo.shmaddr = (char *) shmat(shminfo.shmid, 0, 0);
      if (shminfo.shmaddr == ((char *) -1))
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
      ximage->data = shminfo.shmaddr;
      shminfo.readOnly = False;
      
      XShmAttach(DispPointer(), &shminfo);
      XSync(DispPointer(), False);
    }
  if(using_shm)
    {
      cout << '.';
      FlushEvents();
      XErrorEvent Xerr = GetLastError();
      if (Xerr.error_code==BadAccess && Xerr.request_code==129 &&
	  Xerr.minor_code==1)
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
      else
	{
	  shmctl(shminfo.shmid, IPC_RMID, 0);
	  cout << "  shared memory fully operational\n";
	}
    }
  if(!using_shm)
    {
#endif

      char dummy;
      
      ximage=XCreateImage(DispPointer(),None,1,XYBitmap,0,&dummy,width,
			  height,8,0);
      ximage->byte_order = MSBFirst;
      ximage->bitmap_bit_order = MSBFirst;
      ximage->data = new byte[ximage->bytes_per_line*height];
      assert(ximage->data!=NULL);
#ifdef SH_MEM
    }
#endif
  image_available=false;
  callback = cb;
}

BwWindow::~BwWindow(void)
{
  FlushEvents();
  XFreeGC(DispPointer(),gc);

#ifdef SH_MEM
  if(using_shm)
    {
      XShmDetach(DispPointer(), &shminfo);
      XDestroyImage(ximage);
      shmdt(shminfo.shmaddr);
    }
  else
    {
#endif
      delete ximage->data;
      XFree(ximage);                // Note: This fn DOESN'T destroy the data!
#ifdef SH_MEM
    }
#endif
}

UI_Globals::status BwWindow::InitColours(void)
{
  XGCValues xgcv;

  xgcv.foreground = UI_Globals::Black;
  xgcv.background = UI_Globals::White;

  gc = XCreateGC(DispPointer(), WinId(), GCForeground | GCBackground, &xgcv);

  return(okay);
}

UI_Globals::status BwWindow::InitDitherArray(void)
{
  int i;

  for(i=0; i<4; i++)
    {
      dith_array[i][0] = 3<<((3-i)*2);
      dith_array[i][1] = 1<<((3-i)*2);
      dith_array[i][2] = 0;
      dith_array[i+4][0] = 3<<((3-i)*2);
      dith_array[i+4][1] = 2<<((3-i)*2);
      dith_array[i+4][2] = 0;
    }
  for(i=0; i<85; i++)
    lum_array[i]=0;
  for(i=85; i<171; i++)
    lum_array[i]=1;
  for(i=171; i<256; i++)
    lum_array[i]=2;
   
  return(okay);
}

UI_Globals::status BwWindow::DisplayFrame(frame &Frame, bool nicely)
{
  assert(Frame.width()==ximage->width);
  assert(Frame.height()==ximage->height);
  DitherImage(Frame.lum_ptr(),ximage->data,ximage->height,ximage->width);
  if(nicely)
    {
      XEvent Event;
      Event.type = Expose;
      Event.xexpose.window = WinId();
      Event.xexpose.display = DispPointer();
      Event.xexpose.x=0;
      Event.xexpose.y=0;
      Event.xexpose.width = width();
      Event.xexpose.height = height();
      Event.xexpose.count = 0;
      XSendEvent(DispPointer(),WinId(),False,0,&Event);
    }
  else
    {
#ifdef SH_MEM
      if(using_shm)
	{
	  XShmPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		       ximage->height,True);
	}
      else
#endif
	XPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		  ximage->height);
      XFlush(DispPointer());
    }
  image_available = true;
  return(okay);
}


/*
 *--------------------------------------------------------------
 *
 * DitherImage --
 *
 *	Dithers image into black and white. Maps average of two luminance
 *      sample onto 1 of 3 two bit dither patterns
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	None.
 *
 *--------------------------------------------------------------
 */

void BwWindow::DitherImage(unsigned char *lum, unsigned char *out,int height,
			   int width)
{
  int i=0;
  int j=0;
  int h,w,offset,val;
  byte ans;

  for(h=0; h<height; h++)
    {
      offset = (h & 1) << 2;
      for(w=0; w<width; w+=8)
	{
	  val = lum_array[lum[i++]] + lum_array[lum[i++]];
	  ans = dith_array[offset][val/2];

	  val = lum_array[lum[i++]] + lum_array[lum[i++]];
	  ans |= dith_array[offset+1][val/2];

	  val = lum_array[lum[i++]] + lum_array[lum[i++]];
	  ans |= dith_array[offset+2][val/2];

	  val = lum_array[lum[i++]] + lum_array[lum[i++]];
	  ans |= dith_array[offset+3][val/2];
	  out[j++] = ans;
	}
    }
}

UI_Globals::status BwWindow::event_handler(XEvent *Event)
{
  if(Event->type==Expose && Event->xexpose.count==0 && image_available)
    {
#ifdef SH_MEM
      if(using_shm)
	{
	  XShmPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		       ximage->height,True);
	}
      else
#endif
	XPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		  ximage->height);
      XSync(DispPointer(),False);
    }
  else if(Event->type==ButtonPress)
    {
      (*callback)();
    }
  return(UI_Globals::okay);
}
