/*********************************************************/
/*   This is the source file that contains the code to   */
/*   setup & run the mpeg editor.                        */
/*                                                       */
/*         (c)1994 Alexis 'Milamber' Ashley              */
/*********************************************************/
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "editor.H"
#include "codec.H"
#include "2x2_window.H"
#include "colour_window.H"
#include "mono_window.H"
#include "tiny_window.H"
#include "bw_window.H"
#include "effects.H"
#include "help.H"
#include "yuv.H"
#include "time_win.H"
#include "menu.H"
#include "button.H"
#include "text_win.H"
#include "dialogues.H"
#include "version.h"

#include <assert.h>
#include <iostream.h>
#include <math.h>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "pbmplus.h"
#include "pnm.h"

#define del(x) delete x; x = NULL;

/************ Global structures which are private to editor.C ******** */

struct WinStruct
{
  long num;
  YUV_Window *win;
};

struct EffectsStruct
{
  char *name;
  char hotkey;
  Menu::status (*function)(MainWindow *, Codec *, long start, long end);
};

struct MenuStruct
{
  char *name;                       // Name of menu option
  char hotkey;                      // Hotkey for menu option
  Menu::status (*callback)(byte *); // callback to use for menu option
  bool needs_file;                  // true if option only usable if file open
  bool needs_clipboard;             // true if option only usable if clipboard
                                    // has something in it.
};

struct ParseCallbackStruct 
{
  TextWindow *msg_box;
  long old_text;
};

struct SaveCallbackStruct 
{
  TextWindow *msg_box;
  long old_text;
  float scale;
};

struct EffectsCallbackStruct 
{
  TextWindow *msg_box;
  long old_text;
  long end_frame;
};

struct BookMark
{
  char description[30];
  Codec::abs_addr pos;
};

/******* function prototypes for functions private to editor.C ****/

static void ChooseWindows(void);        // Chooses which YUV windows to create
static void int_handler(void);          // Handles Ctrl-C
static void abort_handler(void);        // Handles abort() function calls
static void ABORT(void);                // Aborts mpeg_edit as cleanly as poss

/***** Callback functions' prototypes *********/

static void resize_callback(void);            // This function is called when
                                              // the main window is re-sized.
static void ParseCallback(byte *,Codec::abs_addr);  // This function is called
                                              // as each frame is parsed
static void SaveCallback(byte *,Codec::abs_addr);  // This function is called
                                              // as each frame is saved
static void EffectsCallback(byte *,Codec::abs_addr);  // This function is 
                                             // called as each frame is edited

static Menu::status file_open(byte *);     // "Open" from "File" menu
static Menu::status file_save_as(byte *);  // "Save As" from "File" menu
static Menu::status file_close(byte *);    // "Close" from "File" menu
static Menu::status file_import_picture(byte *);//"Import picture", "File" menu
static Menu::status file_export_picture(byte *);//"Export picture", "File" menu
static Menu::status file_import_mpeg(byte *);   //"Import mpeg", "File" menu
static Menu::status file_exit(byte *);     // "Exit" from "File" menu

static Menu::status edit_undo(byte *);     // "Undo" from "Edit" menu
static Menu::status edit_cut(byte *);      // "Cut" from "Edit" menu
static Menu::status edit_copy(byte *);     // "Copy" from "Edit" menu
static Menu::status edit_paste(byte *);    // "Paste" from "Edit" menu
static Menu::status edit_delete(byte *);   // "Delete" from "Edit" menu
static Menu::status edit_insert(byte *);   // "Insert" from "Edit" menu
static Menu::status edit_play(byte *);     // "Play" from "Edit" menu

static Menu::status goto_hmsc(byte *);     // "Goto hmsc pos" from goto menu
static Menu::status goto_abs(byte *);      // "Goto abs pos" from goto menu
static Menu::status add_bookmark(byte *);  // "Add bookmark" from goto menu
static Menu::status goto_bookmark(byte *); // "Goto bookmark" from goto menu
static Menu::status clear_bookmark(byte *); // "Clear bookmark" from goto menu

static Menu::status effects_callback(byte *);  // Any option from effects menu

static Button::status btn_exit(byte *);         // "Exit" button
static Button::status btn_fnext_frame(byte *);  // ">>" button
static Button::status btn_next_frame(byte *);   // ">" button
static Button::status btn_play(byte *);         // "Play" button
static Button::status btn_prior_frame(byte *);  // "<" button
static Button::status btn_fprior_frame(byte *); // "<<" button
static Button::status btn_first_frame(byte *);  // "|<" button

static void PPMtoYUV(int height, int width, pixel **picture,frame *Frame);
                                   // Converts a PPM file to a YUV frame

static void YUVtoPPM(int height, int width, pixel **picture,frame *Frame);
                                   // Converts a YUV frame to a PPM file
static void clip_frame(frame *dest, frame *source);  // Clips source into dest

static void start_select(void);    // Callback when start frame is selected
static void end_select(void);      // Callback when end frame is selected
static void de_select(void);       // Callback when selections are stopped

/************ Global variables which are private to editor.C ******** */

static MainWindow *MainWin=NULL;
static Menu *menu=NULL;

static const int file_menu_size = 7;
static Menu::MenuID *file_menu[file_menu_size];
static MenuStruct file_list[file_menu_size] =
{
  { "Open "         , 'O' , file_open           , false , false },
  { "Save As"       , 'A' , file_save_as        , true  , false },
  { "Close"         , 'C' , file_close          , true  , false },
  { "Import Picture", 'P' , file_import_picture , true  , false },
  { "Export Picture", 'E' , file_export_picture , true  , false },
  { "Import Mpeg"   , 'I' , file_import_mpeg    , true  , false },
  { "Exit"          , 'X' , file_exit           , false , false }
};

static const int edit_menu_size = 7;
static Menu::MenuID *edit_menu[edit_menu_size];
static MenuStruct edit_list[edit_menu_size] = 
{
  { "Undo"  ,  'U' , edit_undo  , true  , false },
  { "Cut"   ,  'T' , edit_cut   , true  , false },
  { "Copy"  ,  'C' , edit_copy  , true  , false },
  { "Paste" ,  'P' , edit_paste , true  , true  },
  { "Delete",  'D' , edit_delete, true  , false },
  { "Insert",  'I' , edit_insert, true  , true  },
  { "Play"  ,  'Y' , edit_play  , true  , true  }
};

static const int goto_menu_size = 5;
static Menu::MenuID *goto_menu[edit_menu_size];
static MenuStruct goto_list[edit_menu_size] = 
{
  { "Goto hmsc Position"     ,  'H' , goto_hmsc     , true  , false },
  { "Goto absolute position" ,  'A' , goto_abs      , true  , false },
  { "Add bookmark"           ,  'A' , add_bookmark  , true  , false },
  { "Goto bookmark"          ,  'G' , goto_bookmark , true  , false },
  { "Clear bookmark"         ,  'C' , clear_bookmark, true  , false },
};

static const int colour_menu_size = 7;
static Menu::MenuID *colour_menu[colour_menu_size];
static EffectsStruct colour_list[colour_menu_size] = 
{
  { "Blank"                , 'L' , effects_blank            },
  { "Invert"               , 'I' , effects_invert           },
  { "Supress Colour"       , 'S' , effects_supress_colour   },
  { "Invert Colour"        , 'V' , effects_invert_colour    },
  { "Brightness boost/cut" , 'B' , effects_boost_brightness },
  { "Colour boost/cut"     , 'C' , effects_boost_colour     },
  { "Gamma Correct"        , 'G' , effects_gamma_correct    }
};

static const int effects_menu_size = 9;
static Menu::MenuID *effects_menu[effects_menu_size];
static EffectsStruct effects_list[effects_menu_size] = 
{
  { "Fade from Black" , 'M' , effects_fade_from_black  },
  { "Fade to Black"   , 'F' , effects_fade_to_black    },
  { "Cross Fade In"   , 'I' , effects_cross_fade_in    },
  { "Cross Fade Out"  , 'O' , effects_cross_fade_out   },
  { "Rotate"          , 'R' , effects_rotate           },
  { "Variable Rotate" , 'V' , effects_variable_rotate  },
  { "Edge Trace"      , 'T' , effects_edge_trace       },
  { "Emboss"          , 'E' , effects_emboss           },
  { "Wipe"            , 'W' , effects_wipe             }
};

static const int help_menu_size = 5;
static Menu::MenuID *help_menu[help_menu_size];
static MenuStruct help_list[help_menu_size] =
{
  { "Getting Started"  , 'G' , help_getting_started , false , false },
  { "License Agreement", 'L' , help_licensing       , false , false },
  { "Tutorial"         , 'T' , help_tutorial        , false , false },
  { "Known Bugs"       , 'B' , help_known_bugs      , false , false },
  { "About"            , 'A' , help_about           , false , false }
};

static Button *exit_btn=NULL;
static Button *fforward_btn=NULL;
static Button *forward_btn=NULL;
static Button *play_btn=NULL;
static Button *backward_btn=NULL;
static Button *fbackward_btn=NULL;
static Button *start_btn=NULL;

static TimeWindow *time_win=NULL;

static Codec *Codec_stream=NULL;
static WinStruct MajorWin={0,NULL};
static WinStruct MinorWin[2]={ {0,NULL} , {0,NULL} };
static fstream clipboard;        // this is the temp file used for "clipboard"
static char clip_name[80];       // Name of temp file
static long clip_size;           // how many frames there are in clipboard
static bool fileopen = false;    // true if a file is open
static bool file_changed = false; // true if the file has been changed
static List <BookMark> BookList;  // holds all the bookmark

/*
 *--------------------------------------------------------------------
 *
 * init --
 *
 *  Sets up the callbacks required for the mpeg_edit user interface
 *  Creates the Codec class Codec_stream
 *
 * Results:
 *
 * Side effects:
 *
 *--------------------------------------------------------------
 */
MainWindow::status Init(MainWindow *mw)
{
  MainWin = mw;           // Copy mw, so that we can access it later on
  signal(SIGINT,(void (*)(int))&int_handler);  // Install the ctrl-c handler
  signal(SIGABRT,(void (*)(int))&abort_handler); // Install the abort handler

// **** Register a function to be called when the main window is re-sized ****

  MainWin->RegisterConfigureFunction(resize_callback);

// **** Make the menu bar options ****

  char *menu_options[]= { "File", " Edit ", "Goto", "Colour", "Effects" , 
			  "Help" , NULL };
  menu = new Menu(MainWin,menu_options);

// **** Attach the various commands to the file menu *****

  int i;

  for(i=0; i<file_menu_size; i++)
    {
      if(file_list[i].needs_file)
	file_menu[i] = menu->attach(0,file_list[i].name,file_list[i].hotkey,
				    file_list[i].callback,NULL,false);
      else
	file_menu[i] = menu->attach(0,file_list[i].name,file_list[i].hotkey,
				    file_list[i].callback,NULL,true);
    }

// **** Attach the various commands to the edit menu *****

  bool enable_it;
  for(i=0; i<edit_menu_size; i++)
    {
      if(edit_list[i].needs_file)
	enable_it = false;
      else
	enable_it = true;
      edit_menu[i] = menu->attach(1,edit_list[i].name,edit_list[i].hotkey,
				  edit_list[i].callback,NULL,enable_it);
    }

// **** Attach the various commands to the goto menu *****

  for(i=0; i<goto_menu_size; i++)
    {
      goto_menu[i] = menu->attach(2,goto_list[i].name,goto_list[i].hotkey,
				    goto_list[i].callback,NULL,false);
    }

// **** Attach the various commands to the colour edit menu *****

  for(i=0; i<colour_menu_size; i++)
    {
      colour_menu[i] = menu->attach(3,colour_list[i].name,
				    colour_list[i].hotkey,effects_callback,
				    (byte *)&colour_list[i],false);
    }

// **** Attach the various commands to the effects menu *****

  for(i=0; i<effects_menu_size; i++)
    {
      effects_menu[i] = menu->attach(4,effects_list[i].name,
				     effects_list[i].hotkey,
				     effects_callback,
				     (byte *)&effects_list[i],false);
    }

// **** Attach the various commands to the help menu *****

  for(i=0; i<help_menu_size; i++)
    {
      help_menu[i] = menu->attach(5,help_list[i].name,help_list[i].hotkey,
				  help_list[i].callback,(byte *)MainWin,true);
    }

// **** Make the exit button ****

  exit_btn = new Button(MainWin,950.0,50.0,"Exit",btn_exit,NULL,bottomright);

// **** Make the Codec stream class ****

  Codec_stream = new Codec;

// **** Open a temp file for the edit buffer "clipboard" ****

  tmpnam(clip_name);                 // Get stdio to make me a temp file name
  clipboard.open(clip_name,ios::in | ios::out | ios::noreplace);
  clip_size=0;

  return(MainWindow::okay);
}

/*
 *------------------------------------------------------------------
 *
 * openfile --
 *
 *  This is called to open a file
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
Menu::status openfile(const char *filename)
{
  TextWindow *msg_box;
  ParseCallbackStruct cb_data;
  int i;
  char title[100];

  if(fileopen)
    {
      file_close(NULL);
    }
  MainWin->BusyCursor();
  MainWin->FlushEvents();
  Codec::status Codec_stat = Codec_stream->Open(filename);
  if(Codec_stat!=Codec::okay)
    {
      MainWin->NormalCursor();
      switch(Codec_stat)
	{
	case Codec::file_not_found:
	  notice(MainWin,"The file could not be found!");
	  break;
	case Codec::invalid_file:
	  notice(MainWin,"The file is not a valid file!");
	  break;
	default:          // All the cases should have been dealt with, so
	  return(Menu::ABORT); //this is an error, so we'd best do an abort.
	}
      return(Menu::okay);
    }
  msg_box = new TextWindow(MainWin,250.0,550.0,200.0,500.0);
  world_c w = msg_box->TextWidth(MainWin,"Please wait, parsing file");
  msg_box->ResizeWindow(150.0,w+40.0);
  msg_box->CenterWindow();
  msg_box->AddText(20.0,600.0,"Please wait, parsing file");
  cb_data.msg_box = msg_box;
  cb_data.old_text = msg_box->AddText(200.0,150.0,"Frame : 0");
  Codec_stream->RegisterCallback(ParseCallback,(byte *)&cb_data);
  MainWin->FlushEvents();
  if(Codec_stream->ParseFile()!=Codec::okay)
    {
      Codec_stream->RegisterCallback(NULL,NULL);
      delete msg_box;
      Codec_stream->Close();
      MainWin->NormalCursor();
      notice(MainWin,"Error parsing file.");
      return(Menu::okay);
    }
  Codec_stream->RegisterCallback(NULL,NULL);
  delete msg_box;
  MainWin->FlushEvents();

  ChooseWindows();

// Read a frame from Codec_stream

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width(),255,128,128);

  if(MinorWin[0].win!=NULL)
    MinorWin[0].win->DisplayFrame(temp_frame);
  if(MinorWin[1].win!=NULL)
    MinorWin[1].win->DisplayFrame(temp_frame);
  Codec_stream->Seek( Codec::abs_addr(0) );
  Codec_stat = Codec_stream->Read(temp_frame);
  if(Codec_stat==Codec::okay)
    {
      MajorWin.num = Codec_stream->GetPos_abs();
      MajorWin.win->DisplayFrame(temp_frame);
      time_win->SetTime(Codec_stream->GetPos_hms(),false);
    }
  else
    {
      Codec_stream->Close();
      MainWin->NormalCursor();
      notice(MainWin,"Error reading from file.");
      return(Menu::okay);
    }

// Set that there are no currently selected frames

  MinorWin[0].num = MinorWin[1].num = -1;

// Create the forward & backward buttons, at the same height as the exit
// button, horizontally centered around the major window

  world_c ypos = exit_btn->Y_Pos();
  world_c xpos = MajorWin.win->Width() / 2.0 + MajorWin.win->X_Pos();

  play_btn =  new Button(MainWin,xpos-20.0,ypos,"Play",btn_play,NULL,topleft);

  xpos = play_btn->X_Pos()+play_btn->Width()+40.0;

  forward_btn = new Button(MainWin,xpos,ypos,">",btn_next_frame,NULL,topleft);

  xpos += forward_btn->Width()+40.0;

  fforward_btn = new Button(MainWin,xpos,ypos,">>",btn_fnext_frame,
			    NULL,topleft);

  xpos = play_btn->X_Pos()-40.0;

  backward_btn = new Button(MainWin,xpos,ypos,"<",btn_prior_frame,
			    NULL,topright);

  xpos -= backward_btn->Width()+40.0;

  fbackward_btn = new Button(MainWin,xpos,ypos,"<<",btn_fprior_frame,
			     NULL,topright);

  xpos -= fbackward_btn->Width()+40.0;

  start_btn = new Button(MainWin,xpos,ypos,"|<",btn_first_frame,
			 NULL,topright);

  for(i=0; i<file_menu_size; i++)
    {
      if(file_list[i].needs_file)
	menu->Enable_Option(file_menu[i]);
    }
      
// Enable the relavent edit options

  for(i=0; i<edit_menu_size; i++)
    {
      if(edit_list[i].needs_file)
	if(!edit_list[i].needs_clipboard || clip_size>0)
	  menu->Enable_Option(edit_menu[i]);
    }

// Enable all the of the goto menu

  for(i=0; i<goto_menu_size; i++)
    {
      menu->Enable_Option(goto_menu[i]);
    }

// Enable all the of the colour menu

  for(i=0; i<colour_menu_size; i++)
    {
      menu->Enable_Option(colour_menu[i]);
    }

// Enable all the of the effects menu

  for(i=0; i<effects_menu_size; i++)
    {
      menu->Enable_Option(effects_menu[i]);
    }

// Tell the exit command that there's an open file, that needs closing
// before it deletes anything

  fileopen=true;

// Tell the exit command that there have been no changes to the file
  file_changed = false;


// Set the window title to "Mpeg Edit" followed by the filename

  strcpy(title,"Mpeg Edit - ");
  strcat(title,filename);
  MainWin->SetName(title);

// Put the cursor back to normal, and return

  MainWin->NormalCursor();
  return(Menu::okay);
}

/*
 *--------------------------------------------------------------
 *
 * ChooseWindows  --
 *
 *	Chooses the most appropriate YUV windows, based on the
 *      size of the screen, and its colour depth.
 *
 * Results:
 *
 * Side effects:
 *    Creates three YUV windows, MinorWin[0], MajorWin & MinorWin[1]
 *
 *--------------------------------------------------------------
 */
static void ChooseWindows(void)
{
  enum win_types { none, bw_win, tiny_win, mono_win, colour_win, Dbl_win };

  win_types main_win = none;           // Type used for the main window
  win_types minor_wins = none;         // Type used for the minor windows
  unsigned int resize_width;           // Size to resize window to
  unsigned int major_width;            // HSize of major window
  unsigned int major_height;           // VSize of major window
  unsigned int minor_width;            // HSize of minor windows
  unsigned int minor_height;           // VSize of minor windows

  unsigned int scr_width = MainWin->ScreenWidth();
  if(scr_width>(Codec_stream->Width()*6+100))
    {
      main_win = minor_wins = Dbl_win;
      resize_width = Codec_stream->Width()*6+100;
      major_width = Codec_stream->Width()*2;
      major_height = Codec_stream->Height()*2;
      minor_width = Codec_stream->Width()*2;
      minor_height = Codec_stream->Height()*2;
    }
  if(scr_width>(Codec_stream->Width()*4+100))
    {
      main_win = Dbl_win;
      minor_wins = colour_win;
      resize_width = Codec_stream->Width()*4+100;
      major_width = Codec_stream->Width()*2;
      major_height = Codec_stream->Height()*2;
      minor_width = Codec_stream->Width();
      minor_height = Codec_stream->Height();
    }
  else if(scr_width>(Codec_stream->Width()*3+100))
    {
      main_win = minor_wins = colour_win;
      resize_width = Codec_stream->Width()*3+100;
      major_width = Codec_stream->Width();
      major_height = Codec_stream->Height();
      minor_width = Codec_stream->Width();
      minor_height = Codec_stream->Height();
    }
  else if(scr_width>(Codec_stream->Width()*2+100))
    {
      main_win = colour_win;
      minor_wins = tiny_win;
      resize_width = Codec_stream->Width()*2+100;
      major_width = Codec_stream->Width();
      major_height = Codec_stream->Height();
      minor_width = Codec_stream->Width()/2;
      minor_height = Codec_stream->Height()/2;
    }
  else if(scr_width>(Codec_stream->Width()+Codec_stream->Width()/2+100))
    {
      main_win = minor_wins = tiny_win;
      resize_width = Codec_stream->Width()+Codec_stream->Width()/2+100;
      major_width = Codec_stream->Width()/2;
      major_height = Codec_stream->Height()/2;
      minor_width = Codec_stream->Width()/2;
      minor_height = Codec_stream->Height()/2;
    }
  else
    {
      main_win = colour_win;
      minor_wins = none;
      resize_width = Codec_stream->Width()+50;
      major_width = Codec_stream->Width();
      major_height = Codec_stream->Height();
      minor_width = 0;
      minor_height = 0;
    }

  int col_depth = MainWin->ColourDepth();
  if(col_depth==1)
    {
      main_win = bw_win;
      major_width = Codec_stream->Width();
      major_height = Codec_stream->Height();
      if(minor_wins!=none)
	{
	  minor_wins=bw_win;
	  minor_width = Codec_stream->Width();
	  minor_height = Codec_stream->Height();
	}
    }

// Resize the main window, so that it is big enough for the major window
// and two minor windows

  MainWin->ResizeWindow(major_height+200,resize_width);

// Create the major window, horizontally & vertically centered

  world_c xpos = MainWin->pix_w2wc(major_width);
  xpos = (UI_Globals::MAX_WORLD_C_VAL-xpos)/2.0;
  world_c ypos = MainWin->pix_h2wc(major_height);
  ypos = UI_Globals::MAX_WORLD_C_VAL-((UI_Globals::MAX_WORLD_C_VAL-ypos)/2.0);
  switch(main_win)
    {
    case Dbl_win:
      MajorWin.win = new DblWindow(MainWin,xpos,ypos,Codec_stream->Height(),
				   Codec_stream->Width(),de_select);
      break;
    case colour_win:
      MajorWin.win = new ColourWindow(MainWin,xpos,ypos,Codec_stream->Height(),
				      Codec_stream->Width(),de_select);
      break;
    case mono_win:
      MajorWin.win = new MonoWindow(MainWin,xpos,ypos,Codec_stream->Height(),
				    Codec_stream->Width(),de_select);
      break;
    case tiny_win:
      MajorWin.win = new TinyWindow(MainWin,xpos,ypos,Codec_stream->Height(),
				    Codec_stream->Width(),de_select);
      break;
    case bw_win:
      MajorWin.win = new BwWindow(MainWin,xpos,ypos,Codec_stream->Height(),
				  Codec_stream->Width(),de_select);
      break;
    default:
      cerr << "Unable to find a suitable dither for the main window!" << endl;
      ABORT();
    }

// Make the minor windows, in the middle of the gaps between the major
// window and the main window edge

  world_c xpos2 = ( xpos - MainWin->pix_w2wc(minor_width) ) / 2.0;
  ypos = MainWin->pix_h2wc(minor_height);
  ypos = UI_Globals::MAX_WORLD_C_VAL-((UI_Globals::MAX_WORLD_C_VAL-ypos)/2.0);
  switch(minor_wins)
    {
    case Dbl_win:
      MinorWin[0].win = new DblWindow(MainWin,xpos2,ypos,
				      Codec_stream->Height(),
				      Codec_stream->Width(),start_select);
      MinorWin[1].win = new DblWindow(MainWin,xpos+MajorWin.win->Width()+
				      xpos2,ypos,Codec_stream->Height(),
				      Codec_stream->Width(),end_select);
      break;
    case colour_win:
      MinorWin[0].win = new ColourWindow(MainWin,xpos2,ypos,
					 Codec_stream->Height(),
					 Codec_stream->Width(),start_select);
      MinorWin[1].win = new ColourWindow(MainWin,xpos+MajorWin.win->Width()+
					 xpos2,ypos,Codec_stream->Height(),
					 Codec_stream->Width(),end_select);
      break;
    case mono_win:
      MinorWin[0].win = new MonoWindow(MainWin,xpos2,ypos,
				       Codec_stream->Height(),
				       Codec_stream->Width(),start_select);
      MinorWin[1].win = new MonoWindow(MainWin,xpos+MajorWin.win->Width()+
				       xpos2,ypos,Codec_stream->Height(),
				       Codec_stream->Width(),end_select);
      break;
    case tiny_win:
      MinorWin[0].win = new TinyWindow(MainWin,xpos2,ypos,
				       Codec_stream->Height(),
				       Codec_stream->Width(),start_select);
      MinorWin[1].win = new TinyWindow(MainWin,xpos+MajorWin.win->Width()+
				       xpos2,ypos,Codec_stream->Height(),
				       Codec_stream->Width(),end_select);
      break;
    case bw_win:
      MinorWin[0].win = new BwWindow(MainWin,xpos2,ypos,
				     Codec_stream->Height(),
				     Codec_stream->Width(),start_select);
      MinorWin[1].win = new BwWindow(MainWin,xpos+MajorWin.win->Width()+
				     xpos2,ypos,Codec_stream->Height(),
				     Codec_stream->Width(),end_select);
      break;
    default:
      break;
    }

  ypos = MajorWin.win->Y_Pos();
  ypos = UI_Globals::MAX_WORLD_C_VAL-(UI_Globals::MAX_WORLD_C_VAL-ypos)/2.0;
  time_win = new TimeWindow(MainWin,400.0,ypos);

}

/*
 *--------------------------------------------------------------
 *
 * Exit
 *
 *	Cleans up prior to returning to a shell prompt
 *
 * Results:
 *
 * Side effects:
 *    Closes any open file, does a lot of deletes, to remove
 *    the UI widgets that were created by init.
 *
 *--------------------------------------------------------------
 */
void Exit(void)
{
// Check to see if any help proccess has ended, this stops zombie processes
// from building up

  while(waitpid(0,NULL,WNOHANG)>0)
    ;

// **** de-Install the ctrl-c handler, in case there's  ****
// **** 'life after the Editor finishes'                ****
  signal(SIGINT,SIG_DFL);

// Delete the "clipboard" temp file
  clipboard.close();
  remove(clip_name);

// Close the file, if there's one open

  if(fileopen)
    file_close(NULL);

// Delete all the classes created by the call to the init procedure

  del(Codec_stream);
  del(exit_btn);
  del(menu);
}

/*
 *--------------------------------------------------------------
 *
 * int_handler --
 *
 *	Handles Ctrl-C interupts..
 *
 * Results:
 *	N/A  -  Exit is used to return to a prompt
 *
 * Side effects:
 *    Calls ABORT to tell Editor that it's time to go...
 *
 *--------------------------------------------------------------
 */
static void int_handler(void)
{
  cerr << "Ctrl-C pressed, cleaning up...\n";
  ABORT();
  cerr << ".... finished!\n";
  exit(1);
}

/*
 *--------------------------------------------------------------
 *
 * abort_handler --
 *
 *	Called when abort() function is called
 *
 * Results:
 *	N/A  -  Exit is used to return to a prompt
 *
 * Side effects:
 *    Calls ABORT to tell Editor that it's time to go...
 *
 *--------------------------------------------------------------
 */
static void abort_handler(void)
{
  cerr << "ABORT!   Cleaning up...\n";
  ABORT();
  cerr << ".... finished!\n";
  exit(1);
}

/*
 *--------------------------------------------------------------
 *
 * ABORT
 *
 *	Tries to clean up as much as possible before quitting
 *      This function doesn't write any pending updates, as it
 *      should only be called in an emergency (ie Ctrl-C pressed,
 *      we're about to core dump etc)
 *
 * Results:
 *	none
 *
 * Side effects:
 *	Tells Editor and any class it can to get the hell out
 *      of here, as she's gonna blow!
 *
 *--------------------------------------------------------------
 */

static void ABORT(void)
{
  clipboard.close();
  remove(clip_name);
  del(Codec_stream);
  del(exit_btn);
  del(menu);

// Check to see if any help proccess has ended, this stops zombie processes
// from building up

  while(waitpid(0,NULL,WNOHANG)>0)
    ;
}

/*
 *------------------------------------------------------------------
 *
 * resize_callback --
 *
 *	This callback is called when the main window is resized
 *
 * Results:
 *        N/A
 *
 * Side effects:
 *           None
 *
 *-------------------------------------------------------------------
 */
static void resize_callback(void)
{
// Resize the menu bar

  menu->ResizeWindow();

// Resize the major & minor windows

  if(MajorWin.win!=NULL)
    MajorWin.win->MoveWindow(MajorWin.win->X_Pos(),MajorWin.win->Y_Pos());

  if(MinorWin[0].win!=NULL)
    MinorWin[0].win->MoveWindow(MinorWin[0].win->X_Pos(),
				MinorWin[0].win->Y_Pos());

  if(MinorWin[1].win!=NULL)
    MinorWin[1].win->MoveWindow(MinorWin[1].win->X_Pos(),
				MinorWin[1].win->Y_Pos());

// Resize the time display window

  if(time_win!=NULL)
    time_win->MoveWindow(time_win->X_Pos(),time_win->Y_Pos());

// Resize the buttons

  Button *btn_list[] = { fforward_btn, forward_btn, backward_btn,
			 fbackward_btn, exit_btn, play_btn, start_btn};

  for(int i=0; i<7; i++)
    {
      if(btn_list[i]!=NULL)
	btn_list[i]->MoveWindow(btn_list[i]->X_Pos(),btn_list[i]->Y_Pos());
    }
}

/*
 *------------------------------------------------------------------
 *
 * ParseCallback --
 *
 *	This callback is called while the codec file is being parsed
 *
 * Results:
 *     Updates the frame number display every third frame
 *
 * Side effects:
 *           None
 *
 *-------------------------------------------------------------------
 */
static void ParseCallback(byte *b,Codec::abs_addr frame_num)
{
  if(frame_num%3==0)
    {
      ParseCallbackStruct *pcs = (ParseCallbackStruct *)b;
      char str[20];
      
      sprintf(str,"Frame : %d  ",frame_num);
      pcs->msg_box->DeleteText(pcs->old_text);
      pcs->old_text = pcs->msg_box->AddText(200.0,150.0,str);
      pcs->msg_box->FlushEvents();
    }
}

/*
 *------------------------------------------------------------------
 *
 * SaveCallback --
 *
 *	This callback is called while a codec file is being created
 *
 * Results:
 *     Updates the frame number display every frame
 *
 * Side effects:
 *           None
 *
 *-------------------------------------------------------------------
 */
static void SaveCallback(byte *b,Codec::abs_addr frame_num)
{
  char str[20];
  SaveCallbackStruct *scs = (SaveCallbackStruct *)b;
  
  sprintf(str,"Frame : %d  %3.1f%%",frame_num, float(frame_num)*scs->scale);
  scs->msg_box->DeleteText(scs->old_text);
  scs->old_text = scs->msg_box->AddText(150.0,120.0,str);
  scs->msg_box->FlushEvents();
}

/*
 *------------------------------------------------------------------
 *
 * EffectsCallback --
 *
 *	This callback is called while an effect is being applied
 *
 * Results:
 *     Updates the frame number display every frame
 *
 * Side effects:
 *           None
 *
 *-------------------------------------------------------------------
 */
static void EffectsCallback(byte *b,Codec::abs_addr frame_num)
{
  char str[20];
  EffectsCallbackStruct *ecs = (EffectsCallbackStruct *)b;
  
  sprintf(str,"%5d ",ecs->end_frame-frame_num+1);
  ecs->msg_box->DeleteText(ecs->old_text);
  ecs->old_text = ecs->msg_box->AddText(400.0,120.0,str);
  ecs->msg_box->FlushEvents();
}

/*
 *------------------------------------------------------------------
 *
 * file_open --
 *
 *  This callback is called when a user selects open from the file menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status file_open(byte *data)
{
  if(fileopen && file_changed)
    {
      if(!question(MainWin,"Are you sure you want to loose your edits?"))
	return(Menu::okay);
    }
  file_changed = false;
  char *filename = load_file(MainWin,"Open File ?");
  if(filename==NULL)
    return(Menu::okay);
  Menu::status ret_stat=openfile(filename);
  delete filename;
  return ret_stat;
}

/*
 *------------------------------------------------------------------
 *
 * file_save_as --
 *
 *  This callback is called when a user selects open from the file menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status file_save_as(byte *data)
{
  SaveCallbackStruct cb_data;
  Codec::status stat;

  char *filename = save_file(MainWin,"Save As File ?");  // Ask for filename
  if(filename==NULL)                    // Return if they hit cancel
    return(Menu::okay);
  TextWindow *msg_box = new TextWindow(MainWin,250.0,550.0,150.0,500.0);
  world_c w = msg_box->TextWidth(MainWin,"Please wait, creating new file");
  msg_box->ResizeWindow(150.0,w+40.0);
  msg_box->CenterWindow();
  msg_box->AddText(20.0,600.0,"Please wait, creating new file");
  cb_data.msg_box = msg_box;
  cb_data.old_text = msg_box->AddText(150.0,120.0,"Frame : 0  00.0%");
  cb_data.scale = 100.0/float(Codec_stream->Length());
  Codec_stream->RegisterCallback(SaveCallback,(byte *)&cb_data);
  MainWin->BusyCursor();      // Tell the user that this may take a while...
  MainWin->FlushEvents();     // Flush any pending window events
  stat = Codec_stream->MakeNewFile(filename);  // Make the new file
  Codec_stream->RegisterCallback(NULL,NULL);
  delete msg_box;
  MainWin->NormalCursor();              // Return the cursor to normal
  delete filename;                      // Deletes filename array
  if(stat==Codec::invalid_file)
    notice(MainWin,"Unable to create new file");
  else
    file_changed = false;      // Set there have been no changes to the file
  return(Menu::okay);                   // Return
}

/*
 *------------------------------------------------------------------
 *
 * file_close --
 *
 *  This callback is called when a user selects close from the file menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status file_close(byte *data)
{
  int i;

  if(file_changed)
    {
      if(!question(MainWin,"Are you sure you want to loose your edits?"))
	return(Menu::okay);
    }
  file_changed=false;

// Change the titlebar

  MainWin->SetName("Mpeg Edit");

// Disable the relavent file options

  for(i=0; i<file_menu_size; i++)
    {
      if(file_list[i].needs_file)
	menu->Disable_Option(file_menu[i]);
    }

// Disable all of the edit menu

  for(i=0; i<edit_menu_size; i++)
    {
      menu->Disable_Option(edit_menu[i]);
    }

// Disable all of the goto menu

  for(i=0; i<goto_menu_size; i++)
    {
      menu->Disable_Option(goto_menu[i]);
    }

// Disable all of the colour menu

  for(i=0; i<colour_menu_size; i++)
    {
      menu->Disable_Option(colour_menu[i]);
    }

// Disable all of the effects menu

  for(i=0; i<effects_menu_size; i++)
    {
      menu->Disable_Option(effects_menu[i]);
    }

// Tell Exit that it doesn't need to call file_close

  fileopen = false;

// Delete the buttons

  del(fforward_btn);
  del(forward_btn);
  del(play_btn);
  del(backward_btn);
  del(fbackward_btn);
  del(start_btn);

// Delete the major & minor windows

  del(MinorWin[0].win);
  del(MajorWin.win);
  del(MinorWin[1].win);

// Delete time display window

  del(time_win);

// Close the Codec stream

  if(Codec_stream->Close()==Codec::okay)
    return(Menu::okay);
  notice(MainWin,"Unable to close file!");
  return(Menu::EXIT);
}

/*
 *------------------------------------------------------------------
 *
 * file_import_picture --
 *
 *  This callback is called when a user selects import picture from
 *  the file menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status file_import_picture(byte *data)
{
  char *filename;
  char *filetype;
  List <char *> file_types;
  int i,found;
  int height=Codec_stream->Height();
  int width=Codec_stream->Width();
  frame temp_frame(height,width,0,128,128);
  Codec::status ret_stat;
  struct conversion
    {
      char *name;
      char *command;
      enum filetype { YUV, PNM } type;
    };
  const int ft_size=13;
  conversion f_types[ft_size] =
    {
      { "Encapsulated Postcript file"  , "psidtopgm $"   , conversion::PNM },
      { "GEM .IMG image"               , "gemtopbm $"    , conversion::PNM },
      { "Compuserve GIF image"         , "giftoppm $"    , conversion::PNM },
      { "Jpeg image"                   , "djpeg -pnm $"  , conversion::PNM },
      { "PCX image"                    , "pcxtoppm $"    , conversion::PNM },
      { "Photo CD image"               , "hpcdtoppm -2 $", conversion::PNM },
      { "PPM image"                    , "cat $"         , conversion::PNM },
      { "Sun raster image"             , "rasttoppm $"   , conversion::PNM },
      { "TIFF image"                   , "tifftopnm $"   , conversion::PNM },
      { "Targa image"                  , "tgatoppm $"    , conversion::PNM },
      { "XBitmap image"                , "xbmtopbm $"    , conversion::PNM },
      { "Windows or OS/2 Bitmap image" , "bmptoppm $"    , conversion::PNM },
      { "YCrCb image"                  , ""              , conversion::YUV }
    };

  filename = load_file(MainWin,"Import Picture ?");
  if(filename==NULL)
      return(Menu::okay);

  for(i=0; i<ft_size; i++)
  {
      file_types.Write(f_types[i].name);
      file_types.Advance();
  }
		   
  filetype = selection_box(MainWin,"Please select file type",&file_types);
  if(filetype==NULL)
    return(Menu::okay);
  MainWin->BusyCursor();
  MainWin->FlushEvents();
  for(found=-1, i=0; i<ft_size; i++)
    {
      if( strcmp(f_types[i].name,filetype)==0)
	{
	  found=i;
	  break;
	}
    }
  if(found<0)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Internal Error! __FILE__ :  __LINE__ ");
      return(Menu::okay);
    }
  if(f_types[found].type==conversion::YUV)
    {
      fstream fs;

      fs.open(filename,ios::in);
      fs.read( (char *)temp_frame.lum_ptr() , height*width   );
      fs.read( (char *)temp_frame.Cr_ptr()  , height*width/4 );
      fs.read( (char *)temp_frame.Cb_ptr()  , height*width/4 );
      fs.close();
    }
  else
    {
      FILE *in_pipe;
      pixel **picture;
      int rows,cols,format;
      xelval maxval;
      char *cmd;
      char *ptr;
      int cmd_len = strlen(f_types[found].command);

      cmd = new char[cmd_len+strlen(filename)+50];
      assert(cmd!=NULL);
      ptr = cmd;
      for(int a=0; a<cmd_len; a++)
	{
	  if(f_types[found].command[a]=='$')
	    {
	      strcpy(ptr,filename);
	      ptr += strlen(filename);
	    }
	  else
	    *ptr = f_types[found].command[a];
	  ptr++;
	}
      sprintf(--ptr," | pnmscale -height %d -width %d",Codec_stream->Height(),
	      Codec_stream->Width());
      cout << "Executing command : " << cmd << endl;
      in_pipe = popen(cmd,"r");
      if(in_pipe==NULL)
	{
	  notice(MainWin,"Unable to execute convertor");
	  return(Menu::okay);
	}
      if(feof(in_pipe))
	{
	  notice(MainWin,"Unable to execute convertor");
	  return(Menu::okay);
	}
      picture = pnm_readpnm(in_pipe,&cols,&rows,&maxval,&format);
      if(picture==NULL)
	{
	  MainWin->NormalCursor();
	  notice(MainWin,"Unable to read file");
	  return(Menu::okay);
	}
      if (format != PPM_FORMAT)
	{
	  if (maxval < 255)
	    {
	      pnm_promoteformat(picture, cols, rows, maxval, format, 255,
				PPM_FORMAT);
	      maxval = 255;
	    } 
	  else 
	    {
	      pnm_promoteformat(picture, cols, rows, maxval, format, maxval,
				PPM_FORMAT);
	    }
	}
      if (maxval < 255)
	{
	  pnm_promoteformat(picture, cols, rows, maxval, format, 255, format);
	  maxval = 255;
	}
      pclose(in_pipe);
      PPMtoYUV(rows,cols,picture,&temp_frame);
      pnm_freearray(picture,rows);
    }
  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
  ret_stat = Codec_stream->Write(temp_frame);
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Tell the exit command that there have been changes to the file
  file_changed = true;

  MainWin->NormalCursor();
  return(Menu::okay);
}

/*===========================================================================*
 *
 * PPMtoYUV
 *
 *	convert PPM data into YUV data
 *
 * RETURNS:	nothing
 *
 * SIDE EFFECTS:    none
 *
 *===========================================================================*/
static void PPMtoYUV(int height, int width, pixel **picture,frame *Frame)
{
  byte r,g,b;
  byte l;
  byte cr[4];
  byte cb[4];
  int x,y;
  int cr_avg, cb_avg;
  register pixel *ptr;
  register pixel *ptr2;
  int h = Frame->height();
  int w = Frame->width();

  if(height<h)
    h = height;
  if(width<w)
    w = width;

  for(y=0; y<h; y+=2)
    {
      ptr = picture[y];
      ptr2 = picture[y+1];
      for(x=0; x<w; x+=2)
	{
	  r = (byte) PPM_GETR( *ptr );           // Top left pixel
	  g = (byte) PPM_GETG( *ptr );
	  b = (byte) PPM_GETB( *ptr );
	  ptr++;
	  rgb2yuv(r,g,b,&l,&cr[0],&cb[0]);
	  Frame->Lum(x,y) = l;
	  
	  r = (byte) PPM_GETR( *ptr );           // Top right pixel
	  g = (byte) PPM_GETG( *ptr );
	  b = (byte) PPM_GETB( *ptr );
	  ptr++;
	  rgb2yuv(r,g,b,&l,&cr[1],&cb[1]);
	  Frame->Lum(x+1,y) = l;
	  
	  r = (byte) PPM_GETR( *ptr2 );           // Bottom left pixel
	  g = (byte) PPM_GETG( *ptr2 );
	  b = (byte) PPM_GETB( *ptr2 );
	  ptr2++;
	  rgb2yuv(r,g,b,&l,&cr[2],&cb[2]);
	  Frame->Lum(x,y+1) = l;
	  
	  r = (byte) PPM_GETR( *ptr2 );           // Bottom right pixel
	  g = (byte) PPM_GETG( *ptr2 );
	  b = (byte) PPM_GETB( *ptr2 );
	  ptr2++;
	  rgb2yuv(r,g,b,&l,&cr[3],&cb[3]);
	  Frame->Lum(x+1,y+1) = l;
	  
	  cr_avg = (cr[0] + cr[1] + cr[2] + cr[3]) >> 2;
	  cb_avg = (cb[0] + cb[1] + cb[2] + cb[3]) >> 2;
	  Frame->Cr(x>>1,y>>1) = byte(cr_avg);
	  Frame->Cb(x>>1,y>>1) = byte(cb_avg);
	}
    }
}

/*
 *------------------------------------------------------------------
 *
 * file_export_picture --
 *
 *  This callback is called when a user selects export picture from
 *  the file menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status file_export_picture(byte *data)
{
  char *filename;
  char *filetype;
  List <char *> file_types;
  int i,found;
  int height=Codec_stream->Height();
  int width=Codec_stream->Width();
  frame temp_frame(height,width,0,128,128);
  Codec::status ret_stat;
  struct conversion
    {
      char *name;
      char *command;
      enum filetype { YUV, PNM } type;
    };
  const int ft_size=8;
  conversion f_types[ft_size] =
    {
      { "Compuserve GIF image","ppmquant 256 | ppmtogif >$", conversion::PNM },
      { "Jpeg image"          ,"cjpeg >$"                  , conversion::PNM },
      { "PCX image"           ,"ppmquant 256 | ppmtopcx >$", conversion::PNM },
      { "PPM image"           ,"cat >$"                    , conversion::PNM },
      { "Sun raster image"    ,"ppmquant 256 | pnmtorast >$",conversion::PNM },
      { "TIFF image"          ,"pnmtotiff >$"              , conversion::PNM },
      { "Targa image"         ,"ppmtotga >$"               , conversion::PNM },
      { "YCrCb image"         ,""                          , conversion::YUV }
    };

  for(i=0; i<ft_size; i++)
  {
      file_types.Write(f_types[i].name);
      file_types.Advance();
  }
		   
  filetype = selection_box(MainWin,"Please select a file type",&file_types);
  if(filetype==NULL)
    return(Menu::okay);
  for(found=-1, i=0; i<ft_size; i++)
    {
      if( strcmp(f_types[i].name,filetype)==0)
	{
	  found=i;
	  break;
	}
    }
  if(found<0)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Internal Error! __FILE__ :  __LINE__ ");
      return(Menu::okay);
    }

  filename = save_file(MainWin,"Please enter a filename to export to");
  if(filename==NULL)
      return(Menu::okay);

  MainWin->BusyCursor();
  MainWin->FlushEvents();

  if(f_types[found].type==conversion::YUV)
    {
      fstream fs;

      fs.open(filename,ios::out);
      fs.write( (char *)temp_frame.lum_ptr() , height*width   );
      fs.write( (char *)temp_frame.Cr_ptr()  , height*width/4 );
      fs.write( (char *)temp_frame.Cb_ptr()  , height*width/4 );
      fs.close();
    }
  else
    {
      FILE *out_pipe;
      pixel **picture;
      int rows = Codec_stream->Height();
      int cols = Codec_stream->Width();
      char *cmd;
      char *ptr;
      int cmd_len = strlen(f_types[found].command);

      cmd = new char[cmd_len+strlen(filename)+50];
      assert(cmd!=NULL);
      ptr = cmd;
      for(int a=0; a<cmd_len; a++)
	{
	  if(f_types[found].command[a]=='$')
	    {
	      strcpy(ptr,filename);
	      ptr += strlen(filename);
	    }
	  else
	    *ptr = f_types[found].command[a];
	  ptr++;
	}
      *ptr = '\0';

      picture = ppm_allocarray(cols,rows);
      if(picture==NULL)
	{
	  MainWin->NormalCursor();
	  notice(MainWin,"Unable to allocate picture");
	  return(Menu::okay);
	}
      Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
      ret_stat = Codec_stream->Read(temp_frame);
      YUVtoPPM(rows,cols,picture,&temp_frame);
      cout << "Executing command : " << cmd << endl;
      out_pipe = popen(cmd,"w");
      if(out_pipe==NULL)
	{
	  notice(MainWin,"Unable to execute conversion programme");
	  return(Menu::okay);
	}
      ppm_writeppm(out_pipe,picture,cols,rows,255,0);
      pclose(out_pipe);
      pnm_freearray(picture,rows);
    }

  MainWin->NormalCursor();
  return(Menu::okay);
}

/*===========================================================================*
 *
 * YUVtoPPM
 *
 *	convert YUV data into PPM data
 *
 * RETURNS:	nothing
 *
 * SIDE EFFECTS:    picture now contains the same picture as Frame
 *
 *===========================================================================*/
static void YUVtoPPM(int height, int width, pixel **picture,frame *Frame)
{
  byte r,g,b;
  byte l;
  byte cr;
  byte cb;
  int x,y;
  register pixel *ptr;
  register pixel *ptr2;
  int h = Frame->height();
  int w = Frame->width();

  if(height<h)
    h = height;
  if(width<w)
    w = width;

  for(y=0; y<h; y+=2)
    {
      ptr = picture[y];
      ptr2 = picture[y+1];
      for(x=0; x<w; x+=2)
	{
	  cr = Frame->Cr(x>>1,y>>1);
	  cb = Frame->Cb(x>>1,y>>1);

	  l = Frame->Lum(x,y);                   // Top left pixel
	  yuv2rgb(l,cr,cb,&r,&g,&b);
	  PPM_ASSIGN(*ptr,r,g,b);
	  ptr++;

	  l = Frame->Lum(x+1,y);                 // Top right pixel
	  yuv2rgb(l,cr,cb,&r,&g,&b);
	  PPM_ASSIGN(*ptr,r,g,b);
	  ptr++;

	  l = Frame->Lum(x,y+1);                 // Bottom left pixel
	  yuv2rgb(l,cr,cb,&r,&g,&b);
	  PPM_ASSIGN(*ptr2,r,g,b);
	  ptr2++;

	  l = Frame->Lum(x+1,y+1);               // Bottom right pixel
	  yuv2rgb(l,cr,cb,&r,&g,&b);
	  PPM_ASSIGN(*ptr2,r,g,b);
	  ptr2++;
	}
    }
}

/*
 *------------------------------------------------------------------
 *
 * file_import_mpeg --
 *
 *  This callback is called when a user selects import mpeg from the file menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status file_import_mpeg(byte *data)
{
  Codec new_stream;
  long msg_pos;
  Codec::status ret_stat;
  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());
  frame *insert_buf;
  char *filename;
  TextWindow *msg_box;
  ParseCallbackStruct cb_data;

  filename = load_file(MainWin,"Import Mpeg ?");
  if(filename==NULL)
    return(Menu::okay);
  MainWin->BusyCursor();
  MainWin->FlushEvents();
  ret_stat = new_stream.Open(filename);
  if(ret_stat!=Codec::okay)
    {
      MainWin->NormalCursor();
      switch(ret_stat)
        {
        case Codec::file_not_found:
          notice(MainWin,"The file could not be found!");
          break;
        case Codec::invalid_file:
          notice(MainWin,"The file is not a valid file!");
          break;
        default:          // All the cases should have been dealt with, so
          return(Menu::ABORT); //this is an error, so we'd best do an abort.
        }
      return(Menu::okay);
    }
  msg_box = new TextWindow(MainWin,250.0,550.0,200.0,500.0);
  world_c w = msg_box->TextWidth(MainWin,"Please wait, parsing file");
  msg_box->ResizeWindow(150.0,w+40.0);
  msg_box->CenterWindow();
  msg_pos = msg_box->AddText(20.0,600.0,"Please wait, parsing file");
  cb_data.msg_box = msg_box;
  cb_data.old_text = msg_box->AddText(200.0,150.0,"Frame : 0");
  new_stream.RegisterCallback(ParseCallback,(byte *)&cb_data);
  MainWin->FlushEvents();
  if(new_stream.ParseFile()!=Codec::okay)
    {
      new_stream.RegisterCallback(NULL,NULL);
      delete msg_box;
      new_stream.Close();
      MainWin->NormalCursor();
      notice(MainWin,"Error parsing file.");
      return(Menu::okay);
    }
  new_stream.RegisterCallback(NULL,NULL);
  Codec_stream->RegisterCallback(ParseCallback,(byte *)&cb_data);
  msg_box->DeleteText(msg_pos);
  msg_box->AddText(20.0,600.0,"Please wait, reading file");
  new_stream.Seek(Codec::abs_addr(0));
  ret_stat=Codec::okay;
  while(ret_stat==Codec::okay)
    {
      ret_stat = new_stream.Read(temp_frame);
      if(ret_stat==Codec::okay)
	{
          insert_buf=&temp_frame;
          ret_stat = Codec_stream->Insert(1,&insert_buf);
	  Codec_stream->NextFrame();
	}
      new_stream.NextFrame();
      MajorWin.win->DisplayFrame(temp_frame,false);
      time_win->SetTime(Codec_stream->GetPos_hms(),false);
    }
  Codec_stream->RegisterCallback(NULL,NULL);
  delete msg_box;

// Display the new current frame

  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
  ret_stat = Codec_stream->Read(temp_frame);
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Tell the exit command that there have been changes to the file
  file_changed = true;

  MainWin->NormalCursor();
  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * file_exit --
 *
 *  This callback is called when a user selects exit from the file menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status file_exit(byte *data)
{
  if(file_changed)
    {
      if(!question(MainWin,"Are you sure you want to loose your edits?"))
	return(Menu::okay);
    }
  file_changed=false;

  return(Menu::EXIT);
}

/*
 *------------------------------------------------------------------
 *
 * edit_copy --
 *
 *  This callback is called when a user selects copy from the edit menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */

static Menu::status edit_copy(byte *data)
{
  long start,end;
  Codec::status stat=Codec::okay;

// Tell the user that this may take a while...

  MainWin->BusyCursor();

// Calculate the frames to copy

  if(MinorWin[0].num!=-1 && MinorWin[1].num!=-1)
    {
      start = MinorWin[0].num;
      end = MinorWin[1].num;
    }
  else if(MinorWin[0].num!=-1)
    {
      start = end = MinorWin[0].num;
    }
  else if(MinorWin[1].num!=-1)
    {
      start = end = MinorWin[1].num;
    }
  else
    {
      start = end = MajorWin.num;
    }

// Read the frame(s) from start to end, putting them in the clipboard file

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());
  Codec_stream->Seek( Codec::abs_addr(start) );
  clipboard.seekp(0,ios::beg);
  clip_size=0;
  for(long i=start; i<=end && stat==Codec::okay; i++)
    {
      stat = Codec_stream->Read(temp_frame);
      if(stat==Codec::okay || stat==Codec::end_of_file)
	{
	  Codec_stream->NextFrame();
	  clipboard << temp_frame;
	  clip_size ++;
	}
    }
  if(stat!=Codec::okay && stat!=Codec::end_of_file)
    {
      MainWin->NormalCursor();
      if(start==end)
	notice(MainWin,"Error copying frame to the clipboard!");
      else
	notice(MainWin,"Error copying frames to the clipboard!");
      return(Menu::okay);
    }

  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );

// Enable the other edit options, now that there's something in the clipboard

  for(int index=0; index<edit_menu_size; index++)
    {
      if(edit_list[index].needs_clipboard)
	menu->Enable_Option(edit_menu[index]);
    }

// Return the cursor to normal

  MainWin->NormalCursor();

// Return 

  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * edit_undo --
 *
 *  This callback is called when a user selects undo from the edit menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */

static Menu::status edit_undo(byte *data)
{
  long start,end;
  Codec::status stat=Codec::okay;

// Tell the user that this may take a while...

  MainWin->BusyCursor();

// Calculate the frames to undo

  if(MinorWin[0].num!=-1 && MinorWin[1].num!=-1)
    {
      start = MinorWin[0].num;
      end = MinorWin[1].num;
    }
  else if(MinorWin[0].num!=-1)
    {
      start = end = MinorWin[0].num;
    }
  else if(MinorWin[1].num!=-1)
    {
      start = end = MinorWin[1].num;
    }
  else
    {
      start = end = MajorWin.num;
    }
  
// Undo the frame(s) from start to end

  Codec_stream->Seek( Codec::abs_addr(start) );
  for(long i=start; i<=end && stat==Codec::okay; i++)
    {
      stat = Codec_stream->Undo();
      Codec_stream->NextFrame();
    }
  if(stat!=Codec::okay)
    {
      MainWin->NormalCursor();
      if(stat==Codec::bad_frame)
	notice(MainWin,"Nothing to Undo!");
      else
	notice(MainWin,"Error during undo!");
      return(Menu::okay);
    }


// Display the new current frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());
  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
  stat = Codec_stream->Read(temp_frame);
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);


// Tell the exit command that there have been changes to the file

  file_changed = true;

// Return the cursor to normal

  MainWin->NormalCursor();
  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * edit_cut --
 *
 *  This callback is called when a user selects cut from the edit menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */

static Menu::status edit_cut(byte *data)
{
  long start,end;
  BookMark bm;
  Codec::status stat=Codec::okay;

// Ask the user if they are sure they want to cut this text

  if(confirm(MainWin,"Are you sure you that want to cut these frames?")==false)
    return(Menu::okay);

// Tell the user that this may take a while...

  MainWin->BusyCursor();

// Calculate the frames to copy

  if(MinorWin[0].num!=-1 && MinorWin[1].num!=-1)
    {
      start = MinorWin[0].num;
      end = MinorWin[1].num;
    }
  else if(MinorWin[0].num!=-1)
    {
      start = end = MinorWin[0].num;
    }
  else if(MinorWin[1].num!=-1)
    {
      start = end = MinorWin[1].num;
    }
  else
    {
      start = end = MajorWin.num;
    }
  
// Read the frame(s) from start to end, putting them in the clipboard file

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());
  Codec_stream->Seek( Codec::abs_addr(start) );
  clipboard.seekp(0,ios::beg);
  clip_size=0;
  for(long i=start; i<=end && stat==Codec::okay; i++)
    {
      stat = Codec_stream->Read(temp_frame);
      if(stat==Codec::okay || stat==Codec::end_of_file)
	{
	  stat = Codec_stream->Delete();
	  clipboard << temp_frame;
	  clip_size ++;
	}
    }
  if(stat!=Codec::okay && stat!=Codec::end_of_file)
    {
      MainWin->NormalCursor();
      if(start==end)
	notice(MainWin,"Error deleting frame from file!");
      else
	notice(MainWin,"Error deleting frames from file!");
      return(Menu::okay);
    }

// Update the bookmark list

  BookList.Rewind();
  while(BookList.At_End()==false)
    {
      bm = BookList.Read();
      if((bm.pos>=start) && (bm.pos<=end))
	{
	  BookList.Delete();
	}
      else if(bm.pos>end)
	{
	  bm.pos -= 1+end-start;
	  BookList.Write(bm);
	  BookList.Advance();
	}
      else
	BookList.Advance();
    }

// Display the new current frame

  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
  stat = Codec_stream->Read(temp_frame);
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);


// Enable the other edit options, now that there's something in the clipboard

  for(int index=0; index<edit_menu_size; index++)
    {
      if(edit_list[index].needs_clipboard)
	menu->Enable_Option(edit_menu[index]);
    }

// Tell the exit command that there have been changes to the file

  file_changed = true;

// Return the cursor to normal

  MainWin->NormalCursor();
  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * edit_paste --
 *
 *  This callback is called when a user selects paste from the edit menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status edit_paste(byte *data)
{
  Codec::status stat=Codec::okay;
  frame *insert_buf;

// This option shouln't have been enabled if clip_size is zero

  assert(clip_size>0);

// Ask the user if they are sure they want to paste over these frames

  if(confirm(MainWin,"Are you sure that you want to paste over these frames?")
     ==false)
    return(Menu::okay);

// Tell the user that this may take a while....

  MainWin->BusyCursor();
  MainWin->FlushEvents();

// Make two temp frames

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());
  frame temp_frame2(Codec_stream->Height(),Codec_stream->Width());

// Move to the start of the clipboard file

  clipboard.seekg(0,ios::beg);
  clipboard.clear();

// Write clipboard to codec file, using Codec_stream->Insert if at end of file

  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
  for(long i=0; i<clip_size && stat==Codec::okay; i++)
    {
      clipboard >> temp_frame;
      if(temp_frame.height()!=temp_frame2.height() ||
	 temp_frame.width()!=temp_frame2.width())
	{
	  clip_frame(&temp_frame2,&temp_frame);
	  MajorWin.win->DisplayFrame(temp_frame2,false);
	  time_win->SetTime(Codec_stream->GetPos_hms(),false);
	  stat = Codec_stream->Write(temp_frame2);
	}
      else
	{
	  MajorWin.win->DisplayFrame(temp_frame,false);
	  time_win->SetTime(Codec_stream->GetPos_hms(),false);
	  stat = Codec_stream->Write(temp_frame);
	}
      if(stat==Codec::end_of_file)
	{
	  insert_buf=&temp_frame;
	  stat = Codec_stream->Insert(1,&insert_buf);
	  Codec_stream->NextFrame();
	}
      Codec_stream->NextFrame();
    }
  if(stat!=Codec::okay)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Error writing to file.");
    }

// Display the MajorWin frame

  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
  stat = Codec_stream->Read(temp_frame);
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Tell the exit command that there have been changes to the file

  file_changed = true;

// Return the cursor to normal

  MainWin->NormalCursor();

// Return

  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * edit_insert --
 *
 *  This callback is called when a user selects insert from the edit menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status edit_insert(byte *data)
{
  frame *insert_buf;
  Codec::abs_addr start;
  BookMark bm;
  Codec::status stat=Codec::okay;

// This option shouln't have been enabled if clip_size is zero

  assert(clip_size>0);

// Ask the user if they are sure they want to insert these frames

  if(confirm(MainWin,
	     "Are you sure that you want to insert these frames?")==false)
    return(Menu::okay);

// Tell the user that this may take a while....

  MainWin->BusyCursor();
  MainWin->FlushEvents();

// Make two temp frames

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());
  frame temp_frame2(Codec_stream->Height(),Codec_stream->Width());

// Move to the start of the clipboard file

  clipboard.seekg(0,ios::beg);
  clipboard.clear();

// Write clipboard to codec file, using Codec_stream->Insert

  start=Codec::abs_addr(MajorWin.num);
  Codec_stream->Seek(start);
  for(long i=0; i<clip_size && stat==Codec::okay; i++)
    {
      clipboard >> temp_frame;
      if(temp_frame.height()!=temp_frame2.height() ||
	 temp_frame.width()!=temp_frame2.width())
	{
	  clip_frame(&temp_frame2,&temp_frame);
	  MajorWin.win->DisplayFrame(temp_frame2,false);
	  time_win->SetTime(Codec_stream->GetPos_hms(),false);
	  insert_buf=&temp_frame2;
	}
      else
	{
	  MajorWin.win->DisplayFrame(temp_frame,false);
	  time_win->SetTime(Codec_stream->GetPos_hms(),false);
	  insert_buf=&temp_frame;
	}
      stat = Codec_stream->Insert(1,&insert_buf);
      Codec_stream->NextFrame();
    }
  if(stat!=Codec::okay)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Error writing to file.");
    }

// Update the bookmark list

  BookList.Rewind();
  while(BookList.At_End()==false)
    {
      bm = BookList.Read();
      if(bm.pos>start)
	{
	  bm.pos += clip_size;
	  BookList.Write(bm);
	}
      BookList.Advance();
    }

// Display the MajorWin frame

  Codec_stream->Seek(start);
  stat = Codec_stream->Read(temp_frame);
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Tell the exit command that there have been changes to the file

  file_changed = true;

// Return the cursor to normal

  MainWin->NormalCursor();

// Return

  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * edit_delete --
 *
 *  This callback is called when a user selects delete from the edit menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */

static Menu::status edit_delete(byte *data)
{
  long start,end;
  BookMark bm;
  Codec::status stat=Codec::okay;

// Ask the user if they are sure they want to delete these frames

  if(confirm(MainWin,
	     "Are you sure you that want to delete these frames?")==false)
    return(Menu::okay);

// Tell the user that this may take a while...

  MainWin->BusyCursor();

// Calculate the frames to delete

  if(MinorWin[0].num!=-1 && MinorWin[1].num!=-1)
    {
      start = MinorWin[0].num;
      end = MinorWin[1].num;
    }
  else if(MinorWin[0].num!=-1)
    {
      start = end = MinorWin[0].num;
    }
  else if(MinorWin[1].num!=-1)
    {
      start = end = MinorWin[1].num;
    }
  else
    {
      start = end = MajorWin.num;
    }
  
// Delete the frame(s) from start to end

  Codec_stream->Seek( Codec::abs_addr(start) );
  for(long i=start; i<=end && stat==Codec::okay; i++)
    {
      stat = Codec_stream->Delete();
    }
  if(stat!=Codec::okay && stat!=Codec::end_of_file)
    {
      MainWin->NormalCursor();
      if(start==end)
	notice(MainWin,"Error deleting frame from file!");
      else
	notice(MainWin,"Error deleting frames from file!");
      return(Menu::okay);
    }

// Update the bookmark list

  BookList.Rewind();
  while(BookList.At_End()==false)
    {
      bm = BookList.Read();
      if((bm.pos>=start) && (bm.pos<=end))
	{
	  BookList.Delete();
	}
      else if(bm.pos>end)
	{
	  bm.pos -= 1+end-start;
	  BookList.Write(bm);
	  BookList.Advance();
	}
      else
	BookList.Advance();
    }

// Display the new current frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());
  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
  stat = Codec_stream->Read(temp_frame);
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Tell the exit command that there have been changes to the file

  file_changed = true;

// Return the cursor to normal

  MainWin->NormalCursor();
  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * clip_frame --
 *
 * Results:
 *
 * This callback is called to 'clip' a frame that is too small/too large.
 * It is used by edit_insert and edit_paste when frames are of differening
 * sizes.
 *
 * Side effects:
 *      None
 *
 *-------------------------------------------------------------------
 */
static void clip_frame(frame *dest, frame *source)
{
  int x,y;
  int x_offset=0;
  int y_offset=0;
  int dh = dest->height()-1;
  int dw = dest->width()-1;
  int sh = source->height()-1;
  int sw = source->width()-1;

  if(sh<dh)
    {
      y_offset = (dh-sh)/2;
    }
  if(sw<dw)
    {
      x_offset = (dw-sw)/2;
    }

  for(y=0; y<dh; y+=2)
    {
      if(y>=y_offset && y<sh)
	{
	  for(x=0; x<dw; x+=2)
	    {
	      if(x>=x_offset && x<sw)
		{
		  dest->Lum(x  ,y  ) = source->Lum(x  ,y  );
		  dest->Lum(x+1,y  ) = source->Lum(x+1,y  );
		  dest->Lum(x  ,y+1) = source->Lum(x  ,y+1);
		  dest->Lum(x+1,y+1) = source->Lum(x+1,y+1);
		  dest->Cr(x>>1,y>>1) = source->Cr(x>>1,y>>1);
		  dest->Cb(x>>1,y>>1) = source->Cb(x>>1,y>>1);
		}
	      else
		{
		  dest->Lum(x  ,y  ) = 0;
		  dest->Lum(x+1,y  ) = 0;
		  dest->Lum(x  ,y+1) = 0;
		  dest->Lum(x+1,y+1) = 0;
		  dest->Cr(x>>1,y>>1) = 128;
		  dest->Cb(x>>1,y>>1) = 128;
		}
	    }
	}
      else
	{
	  for(x=0; x<dw; x+=2)
	    {
	      dest->Lum(x  ,y  ) = 0;
	      dest->Lum(x+1,y  ) = 0;
	      dest->Lum(x  ,y+1) = 0;
	      dest->Lum(x+1,y+1) = 0;
	      dest->Cr(x>>1,y>>1) = 128;
	      dest->Cb(x>>1,y>>1) = 128;
	    }
	}
    }
}

/*
 *------------------------------------------------------------------
 *
 * edit_play --
 *
 * This callback is called when a user selects play from the edit menu
 * It will play all the frames currently in the clipboard
 *
 * Results:
 *      Always returns okay
 *
 * Side effects:
 *      None
 *
 *-------------------------------------------------------------------
 */
static Button::status edit_play(byte *b)
{
  MainWin->BusyCursor();
  MainWin->FlushEvents();
  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());
  clipboard.seekg(0,ios::beg);
  clipboard.clear();
  while(clipboard.good())
    {
      clipboard >> temp_frame;
      MajorWin.win->DisplayFrame(temp_frame,false);
      time_win->SetTime(Codec_stream->GetPos_hms(),false);
    }

// Read the MajorWin frame from the file
  
  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
  Codec::status stat = Codec_stream->Read(temp_frame);
  if(stat!=Codec::okay && stat!=Codec::end_of_file)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Error reading from file.");
      return(Button::okay);
    }
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);
  MainWin->NormalCursor();
  return(Button::okay);
}

/*
 *------------------------------------------------------------------
 *
 * goto_hmsc  --
 *
 *  This callback is called when a user selects goto hmsc position
 *  from the goto menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status goto_hmsc(byte *data)
{
  char *hrs;
  char *mins=NULL;
  char *secs=NULL;
  double h,m,s,hs;
  Codec::hms_addr ans;
  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

  char *pos = typein_text(MainWin,"Please type position required as h:m:s");
  if(pos!=NULL)
    {
      hrs=pos;
      while(*pos!='\0')
	{
	  if(*pos==':')
	    {
	      *pos='\0';
	      if(mins==NULL)
		mins = pos+1;
	      else
		secs = pos+1;
	    }
	  pos++;
	}
      h = atof(hrs);
      m = atof(mins);
      s = atof(secs);
      delete hrs;
      ans.hours = ((unsigned short int) h) % 60;
      ans.mins = ((unsigned short int) m) % 60;
      hs = 100.0*modf(s,&s);                  // Split s in secs & hsecs
      ans.secs = ((unsigned short int) s) % 60;
      ans.hsecs = ((unsigned short int) hs) % 100;
      Codec_stream->Seek(ans);
      MajorWin.num = Codec_stream->GetPos_abs();
      Codec::status stat = Codec_stream->Read(temp_frame);
      if(stat!=Codec::okay && stat!=Codec::end_of_file)
	{
	  MainWin->NormalCursor();
	  notice(MainWin,"Error reading from file.");
	  return(Button::okay);
	}
      MajorWin.win->DisplayFrame(temp_frame);
      time_win->SetTime(Codec_stream->GetPos_hms(),false);
    }
  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * goto_abs  --
 *
 *  This callback is called when a user selects goto absolute position
 *  from the goto menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status goto_abs(byte *data)
{
  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

  float pos = select_number(MainWin,"Please select absolute position required",
			    MajorWin.num,0,Codec_stream->Length(),10);
  if(pos>=0)
    {
      MajorWin.num = Codec::abs_addr(pos);
      Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
      Codec::status stat = Codec_stream->Read(temp_frame);
      if(stat!=Codec::okay && stat!=Codec::end_of_file)
	{
	  MainWin->NormalCursor();
	  notice(MainWin,"Error reading from file.");
	  return(Button::okay);
	}
      MajorWin.win->DisplayFrame(temp_frame);
      time_win->SetTime(Codec_stream->GetPos_hms(),false);
    }
  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * add_bookmark
 *
 *  This callback is called when a user selects add bookmark from
 *  the goto menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status add_bookmark(byte *data)
{
  BookMark new_mark;
  char *description = typein_text(MainWin,
			 "Please enter a description for this bookmark");
  if(description!=NULL)
    {
      while(BookList.Advance())   // Move to the end of BookList
	;
      strncpy(new_mark.description,description,28);
      new_mark.description[29]='\0';
      new_mark.pos = Codec_stream->GetPos_abs();
      BookList.Write(new_mark);
    }
  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * goto_bookmark
 *
 *  This callback is called when a user selects goto bookmark from
 *  the goto menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status goto_bookmark(byte *data)
{
  BookMark book;
  List <char *> marks;
  char *bm;
  char *ptr;
  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

  BookList.Rewind();
  if(BookList.At_End()==true)        // If the booklist is empty, return
    {
      notice(MainWin,"No bookmarks have been defined!");
      return(Menu::okay);
    }
  while(BookList.At_End()==false)
  {
    book = BookList.Read();
    BookList.Advance();
    ptr = new char[strlen(book.description)+1];
    strcpy(ptr,book.description);
    marks.Write(ptr);
    marks.Advance();
  }
		   
  bm = selection_box(MainWin,"Please select a bookmark",&marks);
  if(bm!=NULL)
    {
      BookList.Rewind();
      while(BookList.At_End()==false)
      {
	book = BookList.Read();
	if(strcmp(book.description,bm)==0)
	  Codec_stream->Seek(book.pos);
	BookList.Advance();
      }
      delete bm;
    }
  while(marks.At_End()==false)
  {
    delete marks.Read();                 // Delete the text allocated earlier
    marks.Advance();
  }


// Update the main window

  MajorWin.num = Codec_stream->GetPos_abs();
  Codec::status stat = Codec_stream->Read(temp_frame);
  if(stat!=Codec::okay && stat!=Codec::end_of_file)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Error reading from file.");
      return(Button::okay);
    }
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Return

  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * clear_bookmark
 *
 *  This callback is called when a user selects clear bookmark
 *  from the goto menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status clear_bookmark(byte *data)
{
  BookMark book;
  List <char *> marks;
  char *bm;
  char *ptr;

  BookList.Rewind();
  if(BookList.At_End()==true)        // If the booklist is empty, return
    {
      notice(MainWin,"No bookmarks have been defined!");
      return(Menu::okay);
    }
  while(BookList.At_End()==false)
  {
    book = BookList.Read();
    ptr = new char[strlen(book.description)+1];
    strcpy(ptr,book.description);
    marks.Write(ptr);
    marks.Advance();
    BookList.Advance();
  }
		   
  bm = selection_box(MainWin,"Please select a bookmark to clear",&marks);
  if(bm!=NULL)
    {
      BookList.Rewind();
      while(BookList.At_End()==false)
      {
	book = BookList.Read();
	if(strcmp(book.description,bm)==0)
	  BookList.Delete();
	else
	  BookList.Advance();
      }
      delete bm;
    }
  while(marks.At_End()==false)
  {
    delete marks.Read();                 // Delete the text allocated earlier
    marks.Advance();
  }

// Return

  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * effects_callback --
 *
 *  This callback is called when a user selects anything from the 
 *  effects menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
static Menu::status effects_callback(byte *data)
{
  EffectsStruct *efs = (EffectsStruct *)data;
  EffectsCallbackStruct cb_data;
  Menu::status retval=Menu::okay;
  long start,end;
  char str[10];
  char *msg;

// Check to see if any help proccess has ended, this stops zombie processes
// from building up

  while(waitpid(0,NULL,WNOHANG)>0)
    ;

// Ask the user if they are sure they want to apply the effect
  msg = new char[strlen("Are you sure you want to apply the effect ")+
		 strlen(efs->name)+3];
  if(msg==NULL)
    return(Menu::out_of_memory);
  sprintf(msg,"Are you sure you want to apply the effect %s ?",efs->name);
  if(confirm(MainWin,msg)==false)
    return(Menu::okay);

// Calculate the start & end values

  if(MinorWin[0].num!=-1 && MinorWin[1].num!=-1)
    {
      start = MinorWin[0].num;
      end = MinorWin[1].num;
    }
  else if(MinorWin[0].num!=-1)
    {
      start = end = MinorWin[0].num;
    }
  else if(MinorWin[1].num!=-1)
    {
      start = end = MinorWin[1].num;
    }
  else
    {
      start = end = MajorWin.num;
    }

// Tell the user this may take a while

  TextWindow *msg_box = new TextWindow(MainWin,250.0,550.0,150.0,500.0);
  world_c w = msg_box->TextWidth(MainWin,"Please wait, applying effect");
  msg_box->ResizeWindow(150.0,w+40.0);
  msg_box->CenterWindow();
  msg_box->AddText(20.0,600.0,"Please wait, applying effect");
  cb_data.msg_box = msg_box;
  sprintf(str,"%5d ",end-start+1);
  cb_data.old_text = msg_box->AddText(400.0,120.0,str);
  cb_data.end_frame = end;
  Codec_stream->RegisterCallback(EffectsCallback,(byte *)&cb_data);

  MainWin->BusyCursor();
  MainWin->FlushEvents();

// Do the actual effect

  (*(efs->function))(MainWin,Codec_stream,start,end);

  Codec_stream->RegisterCallback(NULL,NULL);
  delete msg_box;

// Make a temp frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

// Read the MajorWin frame from the file
  
  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
  Codec::status stat = Codec_stream->Read(temp_frame);
  if(stat!=Codec::okay && stat!=Codec::end_of_file)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Error reading from file.");
      return(Button::okay);
    }
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Read the MinorWin[0] frame from the file

  if(MinorWin[0].num>=0)
    {
      Codec_stream->Seek( Codec::abs_addr(MinorWin[0].num) );
      stat = Codec_stream->Read(temp_frame);
      if(stat!=Codec::okay && stat!=Codec::end_of_file)
	{
	  MainWin->NormalCursor();
	  notice(MainWin,"Error reading from file.");
	  return(Button::okay);
	}
      MinorWin[0].win->DisplayFrame(temp_frame);
      time_win->SetTime(Codec_stream->GetPos_hms(),false);
    }

// Read the MinorWin[1] frame from the file
  
  if(MinorWin[1].num>=0)
    {
      Codec_stream->Seek( Codec::abs_addr(MinorWin[1].num) );
      stat = Codec_stream->Read(temp_frame);
      if(stat!=Codec::okay && stat!=Codec::end_of_file)
	{
	  MainWin->NormalCursor();
	  notice(MainWin,"Error reading from file.");
	  return(Button::okay);
	}
      MinorWin[1].win->DisplayFrame(temp_frame);
      time_win->SetTime(Codec_stream->GetPos_hms(),false);
    }

// Tell the exit command that there have been changes to the file
  file_changed = true;

  MainWin->NormalCursor();
  return(retval);
}

/*
 *------------------------------------------------------------------
 *
 * btn_exit --
 *
 *	This callback is called when a user presses the exit button
 *
 * Results:
 *	Returns EXIT
 *
 * Side effects:
 *	None
 *
 *-------------------------------------------------------------------
 */
static Button::status btn_exit(byte *data)
{
  if(file_changed)
    {
      if(!question(MainWin,"Are you sure you want to loose your edits?"))
	return(Button::okay);
    }
  file_changed=false;

  return(Button::EXIT);
}

/*
 *------------------------------------------------------------------
 *
 * btn_next_frame --
 *
 *	This callback is called when a user presses the ">" button
 *
 * Results:
 *           Always returns okay
 *
 * Side effects:
 *           None
 *
 *-------------------------------------------------------------------
 */
static Button::status btn_next_frame(byte *data)
{
// Check if we're at the end of the file, if so, return straight away

  if(MajorWin.num>=Codec_stream->Length())
    return(Button::okay);

// Display busy cursor

  MainWin->BusyCursor();
  MainWin->FlushEvents();

// Make a temp frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

// Read the frame from the file
  
  Codec_stream->Seek( Codec::abs_addr(MajorWin.num+1) );
  Codec::status stat=Codec_stream->Read(temp_frame);
  if(stat!=Codec::okay && stat!=Codec::end_of_file)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Error reading from file.");
      return(Button::okay);
    }

// Update MajorWin

  MajorWin.num++;
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Return cursor to normal

  MainWin->NormalCursor();

// Return

  return(Button::okay);
}

/*
 *------------------------------------------------------------------
 *
 * btn_fnext_frame --
 *
 *	This callback is called when a user presses the ">>" button
 *
 * Results:
 *           Always returns okay
 *
 * Side effects:
 *           None
 *
 *-------------------------------------------------------------------
 */
static Button::status btn_fnext_frame(byte *b)
{
  Codec::abs_addr new_pos;

// Check if we're at the end of the file, if so, return straight away

  if(MajorWin.num==Codec_stream->Length())
    return(Button::okay);

// If there is less than 9 frames left, move to end of file

  if(MajorWin.num+9>Codec_stream->Length())
    new_pos=Codec_stream->Length();
  else
    new_pos=MajorWin.num+9;

// Tell the user that we may be some time...

  MainWin->BusyCursor();
  MainWin->FlushEvents();

// Make a temp frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

// Seek to the new file position

  Codec_stream->Seek(new_pos);
  assert(new_pos==Codec_stream->GetPos_abs());

// Read from stream

  Codec::status stat = Codec_stream->Read(temp_frame);
  if(stat!=Codec::okay && stat!=Codec::end_of_file)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Error reading from file.");
      return(Button::okay);
    }

// Update MajorWin

  MajorWin.num=new_pos;
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Return the cursor to normal

  MainWin->NormalCursor();

// Return 

  return(Button::okay);
}

/*
 *------------------------------------------------------------------
 *
 * btn_prior_frame --
 *
 *	This callback is called when a user presses the "<" button
 *
 * Results:
 *           Always returns okay
 *
 * Side effects:
 *           None
 *
 *-------------------------------------------------------------------
 */
static Button::status btn_prior_frame(byte *data)
{
// Check if we're at the start of the file, if so, return straight away

  if(MajorWin.num==0)
    return(Button::okay);

// Tell the user that we may be some time...
  MainWin->BusyCursor();
  MainWin->FlushEvents();

// Seek to the new file position

  Codec_stream->Seek(MajorWin.num-1);

// Make a temp frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

// Read a frame from the file

  if(Codec_stream->Read(temp_frame)!=Codec::okay)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Error reading from file.");
      return(Button::okay);
    }

// Update MajorWin

  MajorWin.num--;
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Return the cursor to normal

  MainWin->NormalCursor();

// Return

  return(Button::okay);
}

/*
 *------------------------------------------------------------------
 *
 * btn_fprior_frame --
 *
 *	This callback is called when a user presses the "<<" button
 *
 * Results:
 *           Always returns okay
 *
 * Side effects:
 *           None
 *
 *-------------------------------------------------------------------
 */
static Button::status btn_fprior_frame(byte *b)
{
  Codec::abs_addr new_pos;

// Check if we're at the start of the file, if so, return straight away

  if(MajorWin.num==0)
    return(Button::okay);

// If we are less than 9 frames from the start, move to the start of the file

  if(MajorWin.num<9)
    new_pos=0;
  else
    new_pos=MajorWin.num-9;

// Tell the user that we may be some time...

  MainWin->BusyCursor();
  MainWin->FlushEvents();


// Seek to the new file pos

  Codec_stream->Seek(new_pos);

// Make a temp frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

// Read a frame from the file

  if(Codec_stream->Read(temp_frame)!=Codec::okay)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Error reading from file.");
      return(Button::okay);
    }

// Update MajorWin

  MajorWin.num = new_pos;
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Return the cursor to normal

  MainWin->NormalCursor();

// Return

  return(Button::okay);
}

/*
 *------------------------------------------------------------------
 *
 * btn_first_frame --
 *
 *	This callback is called when a user presses the "|<" button
 *
 * Results:
 *           Always returns okay
 *
 * Side effects:
 *           None
 *
 *-------------------------------------------------------------------
 */
static Button::status btn_first_frame(byte *b)
{
// Check if we're at the start of the file, if so, return straight away

  if(MajorWin.num==0)
    return(Button::okay);

// Tell the user that we may be some time...

  MainWin->BusyCursor();
  MainWin->FlushEvents();

// Seek to the start of the file

  Codec_stream->Seek( Codec::abs_addr(0) );

// Make a temp frame

  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

// Read a frame from the file

  if(Codec_stream->Read(temp_frame)!=Codec::okay)
    {
      MainWin->NormalCursor();
      notice(MainWin,"Error reading from file.");
      return(Button::okay);
    }

// Update MajorWin

  MajorWin.num = 0;
  MajorWin.win->DisplayFrame(temp_frame);
  time_win->SetTime(Codec_stream->GetPos_hms(),false);

// Return the cursor to normal

  MainWin->NormalCursor();

// Return

  return(Button::okay);
}

/*
 *------------------------------------------------------------------
 *
 * btn_play --
 *
 *	This callback is called when a user presses the "Play" button
 *
 * Results:
 *
 *      Always returns okay
 *
 * Side effects:
 *
 *      None
 *
 *-------------------------------------------------------------------
 */
static Button::status btn_play(byte *b)
{
  static int recursion_count=0;
  Codec::status ret_stat=Codec::okay;

  if(recursion_count++==0)
    {
      timeval target;
      timeval clk;
      long decode_delay;
      long dither_delay;
      long usleep_delay;
      long diff;
      Window wins[1];
      bool skipped=false;
      int skips=0;
      int slept=0;
      int total=0;
      long usec_per_frame=1000000/Codec_stream->FrameRate();
      frame temp_frame(Codec_stream->Height(),Codec_stream->Width());

      Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
      wins[0] = play_btn->WinId();
      play_btn->RestrictEvents(wins,1);

      gettimeofday(&target,(timezone *)NULL);         // Time a read, to
      ret_stat = Codec_stream->Read(temp_frame);      // find out how long
      gettimeofday(&clk,(timezone *)NULL);            // it takes

      decode_delay = clk.tv_usec + 1000000*clk.tv_sec;
      decode_delay -= target.tv_usec + 1000000*target.tv_sec;

      gettimeofday(&target,(timezone *)NULL);         // Time a dither, to
      MajorWin.win->DisplayFrame(temp_frame,false);   // find out how long
      time_win->SetTime(Codec_stream->GetPos_hms(),false);  // it takes
      gettimeofday(&clk,(timezone *)NULL);

      dither_delay = clk.tv_usec + 1000000*clk.tv_sec;
      dither_delay -= target.tv_usec + 1000000*target.tv_sec;

      usleep_delay = 0;

      for(int a=0; a<5; a++)
	{
	  gettimeofday(&target,(timezone *)NULL);         // Time usleep, to
	  usleep(10000);                                  // find out how long
	  gettimeofday(&clk,(timezone *)NULL);            // it takes

	  usleep_delay += clk.tv_usec + 1000000*clk.tv_sec - 10000;
	  usleep_delay -= target.tv_usec + 1000000*target.tv_sec;
	}

      usleep_delay /= 5;            // This is the average of all the tests

      while(recursion_count==1 && ret_stat==Codec::okay)
	{

// Calculate when the frame _should_ finish

	  gettimeofday(&target,(timezone *)NULL);
	  target.tv_usec += usec_per_frame - dither_delay - decode_delay;
	  if(target.tv_usec >= 1000000)
	    {
	      target.tv_usec -= 1000000;
	      target.tv_sec++;
	    }

// Read the frame

	  ret_stat = Codec_stream->Read(temp_frame);
	  Codec_stream->NextFrame();
	  MajorWin.num++;

// See if we're ahead by more than a decode delay (for the next frame)

	  gettimeofday(&clk,(timezone *)NULL);
	  diff = target.tv_usec - clk.tv_usec;
	  diff += 1000000*(target.tv_sec - clk.tv_sec);
	  if(diff>usleep_delay)        // If we are ahead, sleep for a while
	    {
	      usleep(diff);
	      slept++;
	    }
	  else if(diff>0)
	    {
	      usleep(1);
	    }
	  if(!skipped && diff<-(decode_delay+dither_delay))
	    {                    // If we are very behind, and didn't skip
	      skips++;           // the previous frame, skip this frame
	      skipped=true;
	    }
	  else
	    {
	      MajorWin.win->DisplayFrame(temp_frame,false);
	      time_win->SetTime(Codec_stream->GetPos_hms(),false);
	      skipped = false;
	      play_btn->FlushEvents();
	    }
	  total++;
      }
//      cout << "Frame rate : " << Codec_stream->FrameRate() << " frames/sec.";
//      cout << "  Read takes " << decode_delay << " usecs, dither takes ";
//      cout << dither_delay << " usecs\n";
//      cout << "usleep takes " << usleep_delay << " usecs.  ";
//      cout << "Played " << total << " frames,  Slept during " << slept;
//      cout << ", skipped " << skips << endl;
      play_btn->UnrestrictedEvents();
      recursion_count=0;
      if(ret_stat!=Codec::okay && ret_stat!=Codec::end_of_file)
	{
	  MainWin->NormalCursor();
	  notice(MainWin,"Error reading from file.");
	  return(Button::okay);
	}
    }
  return(Button::okay);
}

/*
 *------------------------------------------------------------------
 *
 * start_select --
 *
 *	This callback is called when a user clicks on the left hand window
 *
 * Results:
 *
 *      Always returns okay
 *
 * Side effects:
 *
 *      None
 *
 *-------------------------------------------------------------------
 */
static void start_select(void)
{
  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());
  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
  Codec::status stat = Codec_stream->Read(temp_frame);
  if(stat==Codec::okay || stat==Codec::end_of_file)
    {
      MinorWin[0].num = Codec_stream->GetPos_abs();
      MinorWin[0].win->DisplayFrame(temp_frame);
    }
  else
    {
      notice(MainWin,"Error reading from file.");
      return;
    }
  if(MinorWin[0].num>MinorWin[1].num && MinorWin[1].num!=-1)
    {
      MinorWin[0].num = MinorWin[1].num;
      MinorWin[1].num = MajorWin.num;
      MinorWin[1].win->DisplayFrame(temp_frame);
      Codec_stream->Seek( Codec::abs_addr(MinorWin[0].num) );
      stat = Codec_stream->Read(temp_frame);
      if(stat==Codec::okay || stat==Codec::end_of_file)
	{
	  MinorWin[0].win->DisplayFrame(temp_frame);
	}
      else
	{
	  notice(MainWin,"Error reading from file.");
	}
    }
}

/*
 *------------------------------------------------------------------
 *
 * end_select --
 *
 * This callback is called when a user clicks on the right hand window
 *
 * Results:
 *
 *      Always returns okay
 *
 * Side effects:
 *
 *      None
 *
 *-------------------------------------------------------------------
 */
static void end_select(void)
{
  frame temp_frame(Codec_stream->Height(),Codec_stream->Width());
  Codec_stream->Seek( Codec::abs_addr(MajorWin.num) );
  Codec::status stat = Codec_stream->Read(temp_frame);
  if(stat==Codec::okay || stat==Codec::end_of_file)
    {
      MinorWin[1].num = Codec_stream->GetPos_abs();
      MinorWin[1].win->DisplayFrame(temp_frame);
    }
  else
    {
      notice(MainWin,"Error reading from file.");
    }
  if(MinorWin[0].num>MinorWin[1].num)
    {
      MinorWin[1].num = MinorWin[0].num;
      MinorWin[0].num = MajorWin.num;
      MinorWin[0].win->DisplayFrame(temp_frame);
      Codec_stream->Seek( Codec::abs_addr(MinorWin[1].num) );
      stat = Codec_stream->Read(temp_frame);
      if(stat==Codec::okay || stat==Codec::end_of_file)
	{
	  MinorWin[1].win->DisplayFrame(temp_frame);
	}
      else
	{
	  notice(MainWin,"Error reading from file.");
	}
    }
}

/*
 *------------------------------------------------------------------
 *
 * de_select --
 *
 * This callback is called when a user clicks on the middle window
 *
 * Results:
 *
 *      Always returns okay
 *
 * Side effects:
 *
 *      None
 *
 *-------------------------------------------------------------------
 */
static void de_select(void)
{
  MinorWin[0].num = -1;
  MinorWin[1].num = -1;
  frame temp_frame(Codec_stream->Height(),Codec_stream->Width(),255,128,128);
  MinorWin[0].win->DisplayFrame(temp_frame);
  MinorWin[1].win->DisplayFrame(temp_frame);
}
