#ifndef _VERSION_
#define _VERSION_

extern float VERSION;

#endif
