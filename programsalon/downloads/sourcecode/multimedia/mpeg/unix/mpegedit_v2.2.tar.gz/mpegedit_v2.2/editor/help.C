/* This C++ file handles the help menu */
/* (c)1995 Alexis Ashley             milamber@dcs.warwick.ac.uk */

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "help.H"

#include "text_win.H"
#include "button.H"
#include "version.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

static Button::status btn_exit(byte *);
static Menu::status fork_viewer_for(MainWindow *, char *name);

/*
 *------------------------------------------------------------------
 *
 * help_about --
 *
 *  This callback is called when a user selects about from the help menu
 *
 * Results:
 *
 * Side effects:
 *
 *-------------------------------------------------------------------
 */
Menu::status help_about(byte *data)
{
  MainWindow *MainWin = (MainWindow *)data;
  TextWindow *tw;
  Button *okay;
  Window wins[2];
  char ver[80];

  tw = new TextWindow(MainWin,400.0,450.0,400.0,500.0);
  tw->ResizeWindow(300.0,40.0+
		   tw->TextWidth(MainWin,"Mpeg Edit  (c)1995 Alexis Ashley"));
  tw->CenterWindow();
  tw->AddText(20.0,700.0,"Mpeg Edit  (c)1995 Alexis Ashley");
  sprintf(ver,"Version %1.3f %s",VERSION,__DATE__);
  tw->AddText(150.0,450.0,ver);
  okay = new Button(tw,400.0,100.0,"Okay",btn_exit,NULL,bottomleft);
  wins[0] = tw->WinId();
  wins[1] = okay->WinId();
  tw->RestrictEvents(wins,2);
  tw->EventHandler();
  tw->UnrestrictedEvents();
  delete okay;
  delete tw;

// Check to see if any help proccess has ended

  while(waitpid(0,NULL,WNOHANG)>0)
    ;

// Return
  return(Menu::okay);
}

Menu::status help_licensing(byte *data)
{
  MainWindow *MainWin = (MainWindow *)data;

  return fork_viewer_for(MainWin,"licensing.help");
}

Menu::status help_getting_started(byte *data)
{
  MainWindow *MainWin = (MainWindow *)data;

  return fork_viewer_for(MainWin,"getting_started.help");
}

Menu::status help_tutorial(byte *data)
{
  MainWindow *MainWin = (MainWindow *)data;

  return fork_viewer_for(MainWin,"tutorial.help");
}

Menu::status help_known_bugs(byte *data)
{
  MainWindow *MainWin = (MainWindow *)data;

  return fork_viewer_for(MainWin,"known_bugs.help");
}

static Menu::status fork_viewer_for(MainWindow *MainWin, char *name)
{
  char path[80]="doc";
  UI_Globals::opt_list resources[] =
    {
      { "helppath"      , path  },
      { ""              , NULL  }
    };
  char old_path[200];

// Check to see if any help proccess has ended

  while(waitpid(0,NULL,WNOHANG)>0)
    ;

  MainWin->CheckResources(resources);

  if(getcwd(old_path,200)==NULL)
    return(Menu::out_of_memory);

  chdir(path);
  if(fork()==0)
    {
      execl("xuseless","xuseless",name,NULL);
    }
  chdir(old_path);

  return(Menu::okay);
}

/*
 *------------------------------------------------------------------
 *
 * btn_exit --
 *
 *	This callback is called when a user presses the exit button
 *
 * Results:
 *	Returns EXIT
 *
 * Side effects:
 *	None
 *
 *-------------------------------------------------------------------
 */
static Button::status btn_exit(byte *data)
{
  return(Button::EXIT);
}

