/* This is the source file for my text window class */
/* (c)1994 Alexis 'Milamber' Ashley */
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "text_win.H"
#include <assert.h>
#include <stdlib.h>

char TextWindow::DefaultFont[80] = "*-helvetica-bold-r-*-18-*";
                                            // The name of the default font
                                            // used for text windows
char TextWindow::high_name[80] = "grey90";  // The name of the colour used for
                                            // the bright 3D lines
char TextWindow::low_name[80] = "grey56";   // The name of the colour used for
                                            // the dark 3D lines
char TextWindow::click_speed[80] = "100";   // Default click speed = 1 second

UI_Globals::opt_list TextWindow::resources[] =
{                                           // The resource list for this class
  { "textwindow.font"         , DefaultFont },
  { "textwindow.highlight"    , high_name   },
  { "textwindow.lowlight"     , low_name    },
  { "textwindow.click_speed"  , click_speed },
  { "" , NULL }
};

unsigned int TextWindow::BorderWidth=1;
XFontStruct *TextWindow::Default_Font=NULL; //Default font for all text windows
colour TextWindow::high_colour; // Colour value for bright lines
colour TextWindow::low_colour;  // Colour value for dark lines
GC TextWindow::highlight;       // GC for bright lines
GC TextWindow::lowlight;        // GC for dark lines
int TextWindow::count=0;        // Count of how many text windows there are

TextWindow::TextWindow(UI_Globals *parent,world_c x,world_c y,world_c h,
		       world_c w, bool select,
		       const char * const fgcolour,
		       const char * const bgcolour,
		       const char * const font,
		       unsigned int Border_Width)
:SimpleSubWindow(parent,x,y,h,w,this,
		 (select) ? (ButtonPressMask|ButtonReleaseMask) : 0,
		 fgcolour,bgcolour,Border_Width)
{
  XColor tmp_col;  //This is used during allocation of high_colour & low_colour
  XGCValues xgcv;  //This structure is used in creating this window's
                   //graphics context

// Check for X resources

  CheckResources(resources);

// Copy the names of the foreground colour, so that we can use this later on,
// to try to minimise creating new GCs when AddText is used.

  fg_col = new char[strlen(fgcolour)+1];
  assert(fg_col!=NULL);
  strcpy(fg_col,fgcolour);

// Load the font into memory

  if(strcmp(DefaultFont,font)==0)
    xfs = Default_Font;
  else
    {
      xfs = XLoadQueryFont(DispPointer(),font);
      if(xfs==NULL)
	xfs = Default_Font;
    }
  if(Default_Font==NULL && xfs==NULL)
    xfs = Default_Font = XLoadQueryFont(DispPointer(),DefaultFont);
  assert(xfs!=NULL);

// Create the GC

  xgcv.foreground = fg_colour;
  xgcv.background = bg_colour;
  xgcv.font = xfs->fid;
  GraphicsContext = XCreateGC(DispPointer(),WinId(),(GCForeground |
			      GCBackground | GCFont),&xgcv);

// Create the GC for selected text

  xgcv.foreground = bg_colour;
  xgcv.background = fg_colour;
  InverseGC = XCreateGC(DispPointer(),WinId(),(GCForeground |
					       GCBackground | GCFont),&xgcv);

// If it's the first initiation of the class, then the colours for the bright
// and dark lines need to be allocated & the GCs need creating

  if(count++==0)
    {
      if(XParseColor(DispPointer(),Colourmap,high_name,&tmp_col)==0 ||
	 XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
	high_colour = White;
      else
	high_colour = tmp_col.pixel;
      if(XParseColor(DispPointer(),Colourmap,low_name,&tmp_col)==0 ||
	 XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
	low_colour = Black;
      else
	low_colour = tmp_col.pixel;
      long mask = GCForeground | GCBackground;
      xgcv.background = bg_colour;
      xgcv.foreground = high_colour;
      highlight = XCreateGC(DispPointer(),WinId(),mask,&xgcv);
      xgcv.foreground = low_colour;
      lowlight = XCreateGC(DispPointer(),WinId(),mask,&xgcv);
    }

// Now calculate where the bright & dark lines have to be draw to make the
// button look 3D

  high_seg[0].x1=0;                    high_seg[0].y1=0;
  high_seg[0].x2=width();              high_seg[0].y2=0;
  high_seg[1].x1=1;                    high_seg[1].y1=1;
  high_seg[1].x2=width()-1;            high_seg[1].y2=1;
  high_seg[2].x1=0;                    high_seg[2].y1=1;
  high_seg[2].x2=0;                    high_seg[2].y2=height();
  high_seg[3].x1=1;                    high_seg[3].y1=2;
  high_seg[3].x2=1;                    high_seg[3].y2=height()-1;

  low_seg[0].x1=1;                     low_seg[0].y1=height()-BorderWidth;
  low_seg[0].x2=width();               low_seg[0].y2=height()-BorderWidth;
  low_seg[1].x1=2;                     low_seg[1].y1=height()-1-BorderWidth;
  low_seg[1].x2=width()-1;             low_seg[1].y2=height()-1-BorderWidth;
  low_seg[2].x1=width()-BorderWidth;   low_seg[2].y1=1;
  low_seg[2].x2=width()-BorderWidth;   low_seg[2].y2=height()-1;
  low_seg[3].x1=width()-1-BorderWidth; low_seg[3].y1=2;
  low_seg[3].x2=width()-1-BorderWidth; low_seg[3].y2=height()-2;

// Clear the SendEvent flag

  SendEventFlag=0;

// Store the select flag

  selectable = select;

// Set that there's no callback (yet)

  callback=NULL;
  callback_data=NULL;

// Finished
}

TextWindow::~TextWindow(void)
{
  Text text;
  XGCValues xgcv;

// Free the colours that were allocated by the text window, being careful not
// to try to deallocate black or white, which is a read-only colour

  TList.Rewind();
  while(TList.At_End()==false)
    {
      text = TList.Read();
      if(text.gc!=GraphicsContext)
	{
	  XGetGCValues(DispPointer(),text.gc,GCForeground,&xgcv);
	  if(xgcv.foreground!=White && xgcv.foreground!=Black)
	    {
	      XFreeColors(DispPointer(),Colourmap,&xgcv.foreground,1,0);
	    }
	}
      TList.Advance();
    }

// If a font was loaded specifically for this window, free this font

  if(xfs!=Default_Font)
    XFreeFont(DispPointer(),xfs);

// Free the graphics contexts that were created for this window

  XFreeGC(DispPointer(),GraphicsContext);
  XFreeGC(DispPointer(),InverseGC);

// If this is the last text window, free the default font, if it has been
// loaded, and free the bright and dark 3D colours

  if(--count==0)
    {       
      colour cols[2];
      cols[0] = high_colour;
      cols[1] = low_colour;
      for(int i=0; i<2; i++)
	if(cols[i]!=White && cols[i]!=Black)
	  {
	    XFreeColors(DispPointer(),Colourmap,&cols[i],1,0);
	  }
      if(Default_Font!=NULL)
	{
	  XFreeFont(DispPointer(),Default_Font);
	  Default_Font = NULL;
	}
    }
}

long int TextWindow::AddText(world_c x, world_c y, const char *const str,
			     const char * const fgcolour)
{
  XEvent Event;
  Text text;

  while(TList.Advance()==true)       // Move to the end of TList
    ;
  text.x = wc2pix_x(x);
  text.y = wc2pix_y(y);
  if(strcmp(fgcolour,fg_col)==0)
    text.gc = GraphicsContext;
  else
    {
      XColor tmp_col;
      XGCValues xgcv;
      unsigned long int mask = GCForeground | GCBackground | GCFont;

      XGetGCValues(DispPointer(),GraphicsContext,mask,&xgcv);
      if(XParseColor(DispPointer(),Colourmap,fgcolour,&tmp_col)==0 ||
	 XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
	{
	  tmp_col.pixel=Black;
	}
      xgcv.foreground = tmp_col.pixel;
      text.gc = XCreateGC(DispPointer(),WinId(),mask,&xgcv);
    }
  text.string = new char[strlen(str)+1];
  assert(text.string!=NULL);
  strcpy(text.string,str);
  text.inverse=false;
  TList.Write(text);
  long ret_val = TList.Get_Pos();
  if(!SendEventFlag)
    {
      Event.type = Expose;
      Event.xexpose.window = WinId();
      Event.xexpose.display = DispPointer();
      Event.xexpose.x=0;
      Event.xexpose.y=0;
      Event.xexpose.width = width();
      Event.xexpose.height = height();
      Event.xexpose.count = 0;
      XSendEvent(DispPointer(),WinId(),False,0,&Event);
      SendEventFlag=1;
    }
  return(ret_val);
}

void TextWindow::DeleteText(long int pos)
{
  XEvent Event;

  if(TList.Set_Pos(pos)==false || TList.At_End()==true)
    return;
  TList.Delete();
  if(!SendEventFlag)
    {
      Event.type = Expose;
      Event.xexpose.window = WinId();
      Event.xexpose.display = DispPointer();
      Event.xexpose.x=0;
      Event.xexpose.y=0;
      Event.xexpose.width = width();
      Event.xexpose.height = height();
      Event.xexpose.count = 0;
      XSendEvent(DispPointer(),WinId(),False,0,&Event);
      SendEventFlag=1;
    }
}

void TextWindow::MoveText(long int pos, world_c x, world_c y)
{
  XEvent Event;
  Text text;

  if(TList.Set_Pos(pos)==false || TList.At_End()==true)
    return;
  text = TList.Read();
  text.x = wc2pix_x(x);
  text.y = wc2pix_y(y);
  TList.Write(text);
  if(!SendEventFlag)
    {
      Event.type = Expose;
      Event.xexpose.window = WinId();
      Event.xexpose.display = DispPointer();
      Event.xexpose.x=0;
      Event.xexpose.y=0;
      Event.xexpose.width = width();
      Event.xexpose.height = height();
      Event.xexpose.count = 0;
      XSendEvent(DispPointer(),WinId(),False,0,&Event);
      SendEventFlag=1;
    }
}

void TextWindow::ClearAllText(void)
{
  XEvent Event;

  TList.Rewind();
  while(TList.At_End()==false)
    TList.Delete();
  if(!SendEventFlag)
    {
      Event.type = Expose;
      Event.xexpose.window = WinId();
      Event.xexpose.display = DispPointer();
      Event.xexpose.x=0;
      Event.xexpose.y=0;
      Event.xexpose.width = width();
      Event.xexpose.height = height();
      Event.xexpose.count = 0;
      XSendEvent(DispPointer(),WinId(),False,0,&Event);
      SendEventFlag=1;
    }
}

char *TextWindow::CurrentSelection(void)
{
  Text text;
  char *retval=NULL;

  TList.Rewind();
  while(TList.At_End()==false)
    {
      text = TList.Read();
      if(text.inverse && retval==NULL)
	{
	  retval = new char[strlen(text.string)+1];
	  strcpy(retval,text.string);
	}
      TList.Advance();
    }
  return retval;
}

UI_Globals::status TextWindow::event_handler(XEvent *Event)
{
  status retval=okay;

  switch(Event->type)
    {
    case Expose:
      if(Event->xexpose.count==0)
	{
	  Text text;

	  XClearWindow(DispPointer(),WinId());
	  XDrawSegments(DispPointer(),WinId(),highlight,high_seg,4);
	  XDrawSegments(DispPointer(),WinId(),lowlight,low_seg,4);
	  TList.Rewind();
	  while(TList.At_End()==false)
	    {
	      text = TList.Read();
	      if(text.inverse)
		  XDrawImageString(DispPointer(),WinId(),InverseGC,text.x,
				   text.y,text.string,strlen(text.string));
	      else
		  XDrawImageString(DispPointer(),WinId(),text.gc,text.x,text.y,
				   text.string,strlen(text.string));
	      TList.Advance();
	    }
	  SendEventFlag=0;
	}
      break;
    case ButtonPress:
      if(selectable)
      {
	int abs_x, abs_y, x, y;
	Window root,child;
	unsigned int buttons;
	Text text;
	unsigned int text_height;
	XEvent Event;

	if(XQueryPointer(DispPointer(),WinId(),&root,&child,&abs_x,&abs_y,
			 &x,&y,&buttons)==True)
	  {
	    text_height = xfs->max_bounds.ascent+xfs->max_bounds.descent;
	    TList.Rewind();
	    while(TList.At_End()==false)
	      {
		text = TList.Read();
		if(y>=(text.y-text_height) && y<=text.y)
		  {
		    if(text.inverse==true)
		      {
			timeval clk;
			long time_elapsed;
			long speed;

			gettimeofday(&clk,(timezone *)NULL);
			time_elapsed = (clk.tv_sec - last_click.tv_sec)*100;
			time_elapsed+=(clk.tv_usec - last_click.tv_usec)/10000;
			speed = atol(click_speed);
			if((time_elapsed<speed) && (callback!=NULL))
			  retval = (*(callback))(callback_data);
		      }
		    gettimeofday(&last_click,(timezone *)NULL);
		    text.inverse=true;
		    TList.Write(text);
		    if(!SendEventFlag)
		      {
			Event.type = Expose;
			Event.xexpose.window = WinId();
			Event.xexpose.display = DispPointer();
			Event.xexpose.x=0;
			Event.xexpose.y=0;
			Event.xexpose.width = width();
			Event.xexpose.height = height();
			Event.xexpose.count = 0;
			XSendEvent(DispPointer(),WinId(),False,0,&Event);
			SendEventFlag=1;
		      }
		  }
		else if(text.inverse==true)
		  {
		    text.inverse=false;
		    TList.Write(text);
		    if(!SendEventFlag)
		      {
			Event.type = Expose;
			Event.xexpose.window = WinId();
			Event.xexpose.display = DispPointer();
			Event.xexpose.x=0;
			Event.xexpose.y=0;
			Event.xexpose.width = width();
			Event.xexpose.height = height();
			Event.xexpose.count = 0;
			XSendEvent(DispPointer(),WinId(),False,0,&Event);
			SendEventFlag=1;
		      }
		  }
		TList.Advance();
	      }
	  }
      }
      break;
    default:
      break;
    }
	
  return(retval);
}

void TextWindow::ResizeWindow(world_c new_height, world_c new_width)
{
// Do the resize

  SimpleSubWindow::ResizeWindow(new_height,new_width);

// Recalculate where the bright & dark lines have to be draw to make the
// window look 3D

  high_seg[0].x1=0;                    high_seg[0].y1=0;
  high_seg[0].x2=width();              high_seg[0].y2=0;
  high_seg[1].x1=1;                    high_seg[1].y1=1;
  high_seg[1].x2=width()-1;            high_seg[1].y2=1;
  high_seg[2].x1=0;                    high_seg[2].y1=1;
  high_seg[2].x2=0;                    high_seg[2].y2=height();
  high_seg[3].x1=1;                    high_seg[3].y1=2;
  high_seg[3].x2=1;                    high_seg[3].y2=height()-1;

  low_seg[0].x1=1;                     low_seg[0].y1=height()-BorderWidth;
  low_seg[0].x2=width();               low_seg[0].y2=height()-BorderWidth;
  low_seg[1].x1=2;                     low_seg[1].y1=height()-1-BorderWidth;
  low_seg[1].x2=width()-1;             low_seg[1].y2=height()-1-BorderWidth;
  low_seg[2].x1=width()-BorderWidth;   low_seg[2].y1=1;
  low_seg[2].x2=width()-BorderWidth;   low_seg[2].y2=height()-1;
  low_seg[3].x1=width()-1-BorderWidth; low_seg[3].y1=2;
  low_seg[3].x2=width()-1-BorderWidth; low_seg[3].y2=height()-2;
}

world_c TextWindow::TextWidth(UI_Globals *relative_to,char *text)
{
  unsigned int p = XTextWidth(xfs,text,strlen(text));
  return(relative_to->pix_w2wc(p));
}

world_c TextWindow::TextHeight(UI_Globals *relative_to)
{
  unsigned int h = xfs->max_bounds.ascent+xfs->max_bounds.descent+y_spacing();
  return relative_to->pix_h2wc(h);
}

void TextWindow::RegisterCallback(status (*call_back)(byte *),
				  byte *call_back_data)
{
  callback = call_back;
  callback_data = call_back_data;
}
