/*  ***********************************************************
    *   "main" procedure file for my mpeg editor programme.   *
    *                                                         *
    * (c)1995 Alexis Ashley    milamber@dcs.warwick.ac.uk     *
    ***********************************************************

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/


#include "editor/editor.H"
#include "editor/colour_window.H"
#include "editor/mono_window.H"
#include "editor/bw_window.H"
#include "ui/main_win.H"
#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>

void splash(int argc,char **argv);
frame *ReadPicture(fstream *fs);

MainWindow *mw;

int main(int argc,char **argv)
{

// **** Display the startup screen

  splash(argc,argv);

// **** Initialise the editor ****

  Init(mw);

  if((argc%2)==0)      // Only check for a filename on the command line if
    {                  // argc is even (ie there's an odd no of params)
      fstream fs;
      fs.open(argv[argc-1],ios::in);
      if(fs.good())
	openfile(argv[argc-1]);
      else
      {
	  mw->FlushEvents();
	  mw->ResizeWindow(400,500);
      }
      fs.close();
    }
  else
    {
      mw->FlushEvents();
      mw->ResizeWindow(400,500);
    }

// **** Call the event handler, which will start the show ****

  mw->EventHandler();

// **** Call the editor's Exit function, so that it can clean up ****

  Exit();

// **** Delete the main window

  delete mw;

// **** That's all folks! ****

  cout << "Done" << endl;
  return(0);
}


void splash(int argc,char **argv)
{
  YUV_Window *yuv_win;
  frame *Title;
  fstream fs;
  char path[80]=".";
  UI_Globals::opt_list resources[] =
    {
      { "overlaypath"   , path  },
      { ""              , NULL  }
    };

// **** Make the main window

  mw = new MainWindow("Mpeg Edit",50,50,argc,argv);

  mw->CheckResources(resources);
  strcat(path,"/title_page.dat");
  fs.open(path,ios::in);
  if(fs.good())
    {
      Title=ReadPicture(&fs);
      mw->FlushEvents();
      mw->ResizeWindow(Title->height()+4,Title->width()+4);
      if(mw->ColourDepth()==1)
	{
	  yuv_win = new BwWindow(mw,0.0,UI_Globals::MAX_WORLD_C_VAL,
				 Title->height(),Title->width(),NULL);
	}
      else
	yuv_win = new ColourWindow(mw,0.0,UI_Globals::MAX_WORLD_C_VAL,
				   Title->height(),Title->width(),NULL);

      yuv_win->DisplayFrame( *Title ,false);
      for(int s=0; s<12; s++)
	{
	  mw->FlushEvents();
	  usleep(250000);
	}
      delete Title;
      delete yuv_win;
    }
  mw->FlushEvents();
  mw->ResizeWindow(400,500);
  fs.close();
}

frame *ReadPicture(fstream *fs)
{
  short int si;
  unsigned char temp;
  unsigned char temp2;
  unsigned char  *outptr, *endpt;
  frame *retval;
  int h,w,leng;

  fs->read(&si,sizeof(si));
  h = ntohs(si);
  fs->read(&si,sizeof(si));
  w = ntohs(si);
  retval = new frame(h,w);
  leng = h*w;

  outptr = retval->lum_ptr();
  endpt=outptr+leng;

  while(outptr<endpt)
    {
      fs->read(&temp,1);
      if( (temp & 0xC0) != 0xC0)
	*(outptr++)=temp;
      else
	{
	  temp &= 0x3F;
	  fs->read(&temp2,1);
	  while(temp--)
	    *(outptr++)=temp2;
	}
    }
  
  leng >>= 2;
  outptr = retval->Cr_ptr();
  endpt=outptr+leng;

  while(outptr<endpt)
    {
      fs->read(&temp,1);
      if( (temp &0xC0) != 0xC0)
	*(outptr++)=temp;
      else
	{
	  temp &= 0x3F;
	  fs->read(&temp2,1);
	  while(temp--)
	    *(outptr++)=temp2;
	}
    }

  outptr = retval->Cb_ptr();
  endpt=outptr+leng;

  while(outptr<endpt)
    {
      fs->read(&temp,1);
      if( (temp &0xC0) != 0xC0)
	*(outptr++)=temp;
      else
	{
	  temp &= 0x3F;
	  fs->read(&temp2,1);
	  while(temp--)
	    *(outptr++)=temp2;
	}
    }

  return retval;
}

