/****************************************************************/
/*  This header file (and its associated C file) handle all the */
/*  dialogues for the user interface.                           */
/*    (c)1995 Alexis Ashley          milamber@dcs.warwick.ac.uk */
/****************************************************************/

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "dialogues.H"
#include "text_win.H"
#include "button.H"
#include "type_in_box.H"
#include "scroll_box.H"
#include <iostream.h>
#include <unistd.h>
#include <stdlib.h>
#include <dirent.h>
#include <stdio.h>
#include <sys/stat.h>

struct num_struct
{
  float minval;
  float maxval;
  float increment;
  TypeInBox *typein;
};

static Button::status btn_yes(byte *);
static Button::status btn_ask(byte *);
static Button::status btn_no(byte *);
static Button::status btn_cancel(byte *);
static Button::status btn_exit(byte *);
static Button::status btn_up(byte *);
static Button::status btn_down(byte *);
static Button::status btn_inc(byte *);
static Button::status btn_dec(byte *);
static TypeInBox::status typein_fn(char *);
static void scan_dir(ScrollBox *scroll);

void notice(MainWindow *mw,char *text)
{
  TextWindow *tw;
  Button *okay;
  Window wins[2];

  tw = new TextWindow(mw,400.0,450.0,200.0,500.0);
  tw->ResizeWindow(200.0,40.0+tw->TextWidth(mw,text));
  tw->CenterWindow();
  (void) tw->AddText(20.0,700.0,text);
  okay = new Button(tw,400.0,100.0,"Okay",btn_exit,NULL,bottomleft);
  wins[0] = tw->WinId();
  wins[1] = okay->WinId();
  tw->RestrictEvents(wins,2);
  tw->EventHandler();
  tw->UnrestrictedEvents();
  delete okay;
  delete tw;
}

bool question(MainWindow *mw,char *text)
{
  TextWindow *tw;
  Button *yes;
  Button *no;
  Window wins[3];
  byte ans=3;

  tw = new TextWindow(mw,400.0,450.0,200.0,500.0);
  tw->ResizeWindow(200.0,40.0+tw->TextWidth(mw,text));
  tw->CenterWindow();
  (void) tw->AddText(20.0,700.0,text);
  yes = new Button(tw,200.0,100.0,"Yes",btn_yes,&ans,bottomleft);
  no = new Button(tw,800.0,100.0,"No",btn_no,&ans,bottomright);
  wins[0] = tw->WinId();
  wins[1] = yes->WinId();
  wins[2] = no->WinId();
  tw->RestrictEvents(wins,3);
  tw->EventHandler();
  tw->UnrestrictedEvents();
  delete yes;
  delete no;
  delete tw;
  if(ans==1)
    return(true);
  return(false);
}

bool confirm(MainWindow *mw,char *text)
{
  TextWindow *tw;
  Button *yes;
  Button *no;
  Button *no_ask;
  Window wins[4];
  world_c w;
  byte ans=3;
  static bool dont_ask=false;

  if(dont_ask)
    return true;

  tw = new TextWindow(mw,400.0,450.0,200.0,500.0);
  tw->ResizeWindow(200.0,40.0+tw->TextWidth(mw,text));
  tw->CenterWindow();
  (void) tw->AddText(20.0,700.0,text);

  w = 950.0;
  no = new Button(tw,w,100.0,"No",btn_no,&ans,bottomright);
  w -= no->Width()+20.0;
  no_ask = new Button(tw,w,100.0,"Yes, don't ask again",
		      btn_ask,&ans,bottomright);
  w -= no_ask->Width()+20.0;
  yes = new Button(tw,w,100.0,"Yes",btn_yes,&ans,bottomright);
  wins[0] = tw->WinId();
  wins[1] = yes->WinId();
  wins[2] = no_ask->WinId();
  wins[3] = no->WinId();
  tw->RestrictEvents(wins,4);
  tw->EventHandler();
  tw->UnrestrictedEvents();
  if(ans==2)
    dont_ask=true;
  delete yes;
  delete no;
  delete no_ask;
  delete tw;
  if(ans>0)
    return(true);
  return(false);
}

char *load_file(MainWindow *mw,char *title)
{
  TextWindow *tw;
  Button *okay, *cancel, *up, *down;
  ScrollBox *scroll;
  TypeInBox *typein;
  char *retval;
  Window wins[7];
  world_c w;
  struct stat stat_buf;
  byte cancel_flag;
  bool done=false;

// Make the main window to put the load file dialogue in

  tw = new TextWindow(mw,150.0,150.0,700.0,700.0);
  typein = new TypeInBox(tw,25.0,850.0,mw,typein_fn,50);
  w = 50.0+700.0*(typein->Width()/1000.0);
  tw->ResizeWindow(800.0,w);
  tw->CenterWindow();

// Make the scrolling file select dialogue box

  scroll = new ScrollBox(tw,200.0,200.0,560.0,600.0);

// Add the scroll up, scroll down, okay and cancel buttons

  w = UI_Globals::MAX_WORLD_C_VAL-tw->TextWidth(tw,title);
  tw->AddText(w/2.0,900.0,title);
  w = 950.0;
  cancel = new Button(tw,w,70.0,"Cancel",btn_cancel,&cancel_flag,bottomright);
  w -= cancel->Width()+20.0;
  okay = new Button(tw,w,70.0,"Okay",btn_exit,&cancel_flag,bottomright);
  w -= okay->Width()+20.0;
  up = new Button(tw,w,70.0,"^",btn_up,(byte *)scroll,bottomright);
  w -= up->Width()+20.0;
  down = new Button(tw,w,70.0,"v",btn_down,(byte *)scroll,bottomright);

  scroll->RegisterCallback(btn_exit,&cancel_flag);

// Build the list of files

  scan_dir(scroll);

// Restrict the user to the dialogue box

  wins[0]=tw->WinId();
  wins[1]=typein->WinId();
  wins[2]=scroll->WinId();
  wins[3]=okay->WinId();
  wins[4]=cancel->WinId();
  wins[5]=up->WinId();
  wins[6]=down->WinId();
  tw->RestrictEvents(wins,7);

  while(!done)
    {
      cancel_flag=0;
      done=true;
      typein->ClearText();                 // Clear the typein box

      tw->EventHandler();                  // Start the event handler

                                           // We have to work out if they used
	                                   // the typein box, or the selection
                                           // box.
      retval = typein->CurrentValue();     // Get the current typein box value
      if(retval==NULL)
	{                              // Get the current scroll box value
	  retval = scroll->CurrentSelection();
	}


      // If its a directory, change to this directory
      
      if(retval!=NULL && !cancel_flag)
	{
	  if(stat(retval,&stat_buf)!=0)     // If file not found, don't
	    {                               // finish
	      done = false;
	    }
	  else
	    if(S_ISDIR(stat_buf.st_mode))
	      {
		chdir(retval);
		scroll->ClearAllText();
		scan_dir(scroll);
		done = false;
	      }
	}
    }
  
// Restore events to all windows
  
  tw->UnrestrictedEvents();

// Delete all the windows & return

  scroll->RegisterCallback(NULL);
  delete up;
  delete down;
  delete okay;
  delete cancel;
  delete scroll;
  delete typein;
  delete tw;
  if(cancel_flag)
    {
      delete retval;
      retval=NULL;
    }
  return(retval);
}

char *save_file(MainWindow *mw,char *title)
{
  TextWindow *tw;
  Button *okay, *cancel, *up, *down;
  ScrollBox *scroll;
  TypeInBox *typein;
  char *retval;
  Window wins[7];
  world_c w;
  struct stat stat_buf;
  byte cancel_flag;
  bool done=false;

// Make the main window to put the load file dialogue in

  tw = new TextWindow(mw,150.0,150.0,700.0,700.0);
  typein = new TypeInBox(tw,25.0,850.0,mw,typein_fn,50);
  w = 50.0+700.0*(typein->Width()/1000.0);
  tw->ResizeWindow(800.0,w);
  tw->CenterWindow();

// Make the scrolling file select dialogue box

  scroll = new ScrollBox(tw,200.0,200.0,560.0,600.0);

// Add the scroll up, scroll down, okay and cancel buttons

  w = UI_Globals::MAX_WORLD_C_VAL-tw->TextWidth(tw,title);
  tw->AddText(w/2.0,900.0,title);
  w = 950.0;
  cancel = new Button(tw,w,70.0,"Cancel",btn_cancel,&cancel_flag,bottomright);
  w -= cancel->Width()+20.0;
  okay = new Button(tw,w,70.0,"Okay",btn_exit,&cancel_flag,bottomright);
  w -= okay->Width()+20.0;
  up = new Button(tw,w,70.0,"^",btn_up,(byte *)scroll,bottomright);
  w -= up->Width()+20.0;
  down = new Button(tw,w,70.0,"v",btn_down,(byte *)scroll,bottomright);

// Build the list of files

  scan_dir(scroll);

// Restrict the user to the dialogue box

  wins[0]=tw->WinId();
  wins[1]=typein->WinId();
  wins[2]=scroll->WinId();
  wins[3]=okay->WinId();
  wins[4]=cancel->WinId();
  wins[5]=up->WinId();
  wins[6]=down->WinId();

  while(!done)
    {
      cancel_flag=0;
      done=true;
      typein->ClearText();                 // Clear the typein box

      tw->RestrictEvents(wins,7);          // Restrict user to dialogue box
      tw->EventHandler();                  // Call the event handler
      tw->UnrestrictedEvents();            // Remove restriction

                                           // We have to work out if they used
	                                   // the typein box, or the selection
                                           // box.
      retval = typein->CurrentValue();     // Get the current typein box value
      if(retval==NULL)
	{                                  // Get the current scroll box value
	  retval = scroll->CurrentSelection();
	}

      if(retval!=NULL && !cancel_flag)
	{
	  if(stat(retval,&stat_buf)==0)     // If file already exists, check
	    {                               // if it is a directory.  If not,
	      if(S_ISDIR(stat_buf.st_mode)) // ask for confirmation before
		{                           // overwriting file.  If it is a
		  chdir(retval);            // directory, move into this
		  scroll->ClearAllText();   // directory.
		  scan_dir(scroll);
		  done = false;
		}
	      else if(!question(mw,
				"Are you sure you want to replace this file?"))
		done=false;
	    }
	}
    }
  
// Delete all the windows & return

  delete up;
  delete down;
  delete okay;
  delete cancel;
  delete scroll;
  delete typein;
  delete tw;
  if(cancel_flag)
    {
      delete retval;
      retval=NULL;
    }
  return(retval);
}

char *typein_text(MainWindow *mw,char *title)
{
  TextWindow *tw;
  Button *okay, *cancel;
  TypeInBox *typein;
  char *retval;
  Window wins[4];
  byte cancel_flag = 0;

  tw = new TextWindow(mw,200.0,400.0,300.0,400.0);
  typein = new TypeInBox(tw,50.0,600.0,mw,typein_fn,50);
  world_c w = 50.0+400.0*(typein->Width()/1000.0);
  tw->ResizeWindow(300.0,w);
  tw->CenterWindow();
  w = UI_Globals::MAX_WORLD_C_VAL-tw->TextWidth(tw,title);
  tw->AddText(w/2.0,850.0,title);
  okay = new Button(tw,300.0,70.0,"Okay",btn_exit,&cancel_flag,bottomleft);
  cancel = new Button(tw,okay->Width()+350.0,70.0,"Cancel",btn_cancel,
		      &cancel_flag,bottomleft);
  wins[0]=tw->WinId();
  wins[1]=okay->WinId();
  wins[2]=cancel->WinId();
  wins[3]=typein->WinId();
  tw->RestrictEvents(wins,4);
  tw->EventHandler();
  tw->UnrestrictedEvents();
  retval = typein->CurrentValue();
  delete typein;
  delete okay;
  delete cancel;
  delete tw;
  if(cancel_flag)
    {
      delete retval;
      retval=NULL;
    }
  return(retval);
}

char *selection_box(MainWindow *mw,char *title, List <char *>*selections)
{
  TextWindow *tw;
  Button *okay, *cancel, *up, *down;
  ScrollBox *scroll;
  char *retval;
  Window wins[6];
  world_c w;
  byte cancel_flag = 0;

// Make the main window to put the select filetype dialogue in

  tw = new TextWindow(mw,150.0,150.0,700.0,700.0);

// Make the scrolling file select dialogue box

  scroll = new ScrollBox(tw,200.0,250.0,560.0,600.0);

// Add the scroll up, scroll down, okay and cancel buttons

  w = UI_Globals::MAX_WORLD_C_VAL-tw->TextWidth(tw,title);
  tw->AddText(w/2.0,850.0,title);
  w = 950.0;
  cancel = new Button(tw,w,70.0,"Cancel",btn_cancel,&cancel_flag,bottomright);
  w -= cancel->Width()+20.0;
  okay = new Button(tw,w,70.0,"Okay",btn_exit,&cancel_flag,bottomright);
  w -= okay->Width()+20.0;
  up = new Button(tw,w,70.0,"^",btn_up,(byte *)scroll,bottomright);
  w -= up->Width()+20.0;
  down = new Button(tw,w,70.0,"v",btn_down,(byte *)scroll,bottomright);
  selections->Rewind();
  while(selections->At_End()==false)
    {
	scroll->AddText(selections->Read());
	selections->Advance();
    }
  scroll->RegisterCallback(btn_exit,&cancel_flag);
  
  wins[0]=tw->WinId();
  wins[1]=scroll->WinId();
  wins[2]=okay->WinId();
  wins[3]=cancel->WinId();
  wins[4]=up->WinId();
  wins[5]=down->WinId();
  tw->RestrictEvents(wins,6);

// Hand control over to the event handler

  tw->EventHandler();

// Allow events to all windows

  tw->UnrestrictedEvents();
  scroll->RegisterCallback(NULL);

  retval = scroll->CurrentSelection(); // Get the current scroll box value
  delete up;
  delete down;
  delete okay;
  delete cancel;
  delete scroll;
  delete tw;
  if(cancel_flag)
    {
      delete retval;
      retval=NULL;
    }
  return(retval);
}

float select_number(MainWindow *mw,char *title, float start, float minval,
		    float maxval, float increment)
{
  TextWindow *tw;
  Button *okay, *cancel, *up, *down;
  TypeInBox *typein;
  Window wins[6];
  world_c w;
  num_struct number;
  char temp_text[20];
  float retval;
  char *cur_val;
  byte cancel_flag = 0;

// Check to see if minval and maxval are valid.  If not, return straight away

  if(minval<-999 || minval>999 || maxval<-999 || maxval>999 || minval>maxval)
    return(minval-1);

// Make the main window to put the select number dialogue in

  tw = new TextWindow(mw,250.0,375.0,250.0,500.0);
  w = UI_Globals::MAX_WORLD_C_VAL-tw->TextWidth(tw,title);
  tw->AddText(w/2.0,800.0,title);

// Make the select number dialogue box

  typein = new TypeInBox(tw,100.0,350.0,mw,typein_fn,10);
  if(increment==float(int(increment)))
    sprintf(temp_text,"%3.0f",start);
  else
    sprintf(temp_text,"%3.3f",start);
  typein->SetText(temp_text);

// Setup the number structure for the inc and dec buttons

  number.minval = minval;
  number.maxval = maxval;
  number.increment = increment;
  number.typein = typein;

// Add the scroll up, scroll down, okay and cancel buttons

  w = 150.0 + typein->Width();
  down = new Button(tw,w,350.0,"v",btn_dec,(byte *)&number,topleft);
  w += down->Width()+20.0;
  up = new Button(tw,w,350.0,"^",btn_inc,(byte *)&number,topleft);
  w += up->Width()+20.0;
  okay = new Button(tw,w,350.0,"Okay",btn_exit,&cancel_flag,topleft);
  w += okay->Width()+20.0;
  cancel = new Button(tw,w,350.0,"Cancel",btn_cancel,&cancel_flag,topleft);
  wins[0]=tw->WinId();
  wins[1]=typein->WinId();
  wins[2]=okay->WinId();
  wins[3]=cancel->WinId();
  wins[4]=up->WinId();
  wins[5]=down->WinId();
  tw->RestrictEvents(wins,6);
  tw->EventHandler();
  tw->UnrestrictedEvents();
  cur_val = typein->CurrentValue();
  retval = atof(cur_val);
  if(retval<minval || retval>maxval)
    retval = minval-1;
  delete cur_val;
  delete up;
  delete down;
  delete okay;
  delete cancel;
  delete typein;
  delete tw;
  if(cancel_flag)
    {
      retval = minval-1;
    }
  return(retval);
}

static TypeInBox::status typein_fn(char *c)
{
  return(TypeInBox::EXIT);
}

static Button::status btn_exit(byte *b)
{
  if(b!=NULL)
    *b=0;
  return(Button::EXIT);
}

static Button::status btn_yes(byte *b)
{
  if(b!=NULL)
    *b=1;
  return(Button::EXIT);
}

static Button::status btn_ask(byte *b)
{
  if(b!=NULL)
    *b=2;
  return(Button::EXIT);
}

static Button::status btn_no(byte *b)
{
  if(b!=NULL)
    *b=0;
  return(Button::EXIT);
}

static Button::status btn_cancel(byte *b)
{
  *b=1;
  return(Button::EXIT);
}

static Button::status btn_up(byte *b)
{
  ScrollBox *scroll = (ScrollBox *)b;
  scroll->ScrollUp(1);
  return(Button::okay);
}

static Button::status btn_down(byte *b)
{
  ScrollBox *scroll = (ScrollBox *)b;
  scroll->ScrollDown(1);
  return(Button::okay);
}

static Button::status btn_inc(byte *b)
{
  num_struct *ns = (num_struct *)b;
  char temp_text[10];
  char *cur_val;
  float value;

  cur_val = ns->typein->CurrentValue();
  value = atof(cur_val);
  delete cur_val;
  if(value<ns->minval)
    value = ns->minval;

  if(value+ns->increment<=ns->maxval)
    {
      value += ns->increment;
      if(ns->increment==float(int(ns->increment)))
	sprintf(temp_text,"%3.0f",value);
      else
	sprintf(temp_text,"%3.3f",value);
      ns->typein->SetText(temp_text);
    }
  return(Button::okay);
}

static Button::status btn_dec(byte *b)
{
  num_struct *ns = (num_struct *)b;
  char temp_text[10];
  char *cur_val;
  float value;

  cur_val = ns->typein->CurrentValue();
  value = atof(cur_val);
  delete cur_val;
  if(value<ns->minval)
    value = ns->minval;

  if(value-ns->increment>=ns->minval)
    {
      value -= ns->increment;
      if(ns->increment==float(int(ns->increment)))
	sprintf(temp_text,"%3.0f",value);
      else
	sprintf(temp_text,"%3.3f",value);
      ns->typein->SetText(temp_text);
    }
  return(Button::okay);
}

static void scan_dir(ScrollBox *scroll)
{
  DIR *directory;
  dirent *entry;
  struct stat stat_buf;

  directory = opendir(".");
  rewinddir(directory);
  while( (entry = readdir(directory)) != NULL)
    {
      stat(entry->d_name,&stat_buf);
      if(S_ISDIR(stat_buf.st_mode) && strcmp(entry->d_name,".")!=0)
        {
          scroll->AddText(entry->d_name);
        }
      else if(S_ISREG(stat_buf.st_mode) && entry->d_name[0]!='.')
        {
          scroll->AddText(entry->d_name);
        }
    }
  closedir(directory);
}
