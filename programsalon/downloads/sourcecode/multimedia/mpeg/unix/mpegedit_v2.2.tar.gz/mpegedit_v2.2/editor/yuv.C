/****************************************************************/
/* Functions to convert between RGB and YUV colourspace         */
/*                                                              */
/* (c)1995  Alexis Ashley       milamber@dcs.warwick.ac.uk      */
/****************************************************************/
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
 *--------------------------------------------------------------
 *
 * yuv2rgb --
 *
 *	Given a l, cr, cb tuple, converts it to r,g,b.
 *
 * Results:
 *	r,g,b values returned in pointers passed as parameters.
 *
 * Side effects:
 *      None.
 *
 *--------------------------------------------------------------
 */

void yuv2rgb(unsigned char l,unsigned char cr,unsigned char cb,
	     unsigned char *r,unsigned char *g,unsigned char *b)
{
  float fl, fcr, fcb, fr, fg, fb;

  fl = float(l);
  fcr =  float(cr) - 128.0;
  fcb =  float(cb) - 128.0;


  fr = fl + (1.40200 * fcb);
  fg = fl - (0.71414 * fcb) - (0.34414 * fcr);
  fb = fl + (1.77200 * fcr);

  if (fr < 0.0) fr = 0.0;
  else if (fr > 255.0) fr = 255.0;

  if (fg < 0.0) fg = 0.0;
  else if (fg > 255.0) fg = 255.0;

  if (fb < 0.0) fb = 0.0;
  else if (fb > 255.0) fb = 255.0;

  *r = (unsigned char) fr;
  *g = (unsigned char) fg;
  *b = (unsigned char) fb;

}
/*
 *--------------------------------------------------------------
 *
 * rgb2yuv --
 *
 *	Given an R, G, B tuple, converts it to Y,Cr,Cb
 *
 * Results:
 *	l,cr,cb values returned in pointers passed as parameters.
 *
 * Side effects:
 *      None.
 *
 *--------------------------------------------------------------
 */

void rgb2yuv(unsigned char r,unsigned char g,unsigned char b,
	     unsigned char *l,unsigned char *cr,unsigned char *cb)
{
  long il, icr, icb, ir, ig, ib;

  ir = long(r);
  ig = long(g);
  ib = long(b);

//  fl  =  0.32*fr + 0.62*fg + 0.06*fb;
//  fcr = -0.16*fr - 0.33*fg + 0.51*fb + 128.0;
//  fcb =  0.50*fr - 0.45*fg - 0.05*fb + 128.0;

  il  =           2990*ir + 5870*ig + 1140*ib;
  icr = 1280000 - 1687*ir - 3313*ig + 5000*ib;
  icb = 1280000 + 5000*ir - 4187*ig -  813*ib;

  il /= 10000;
  icr /= 10000;
  icb /= 10000;

  if (il < 0) il = 0;
  else if (il > 255) il = 255;

  if (icr < 0) icr = 0;
  else if (icr > 255) icr = 255;

  if (icb < 0) icb = 0;
  else if (icb > 255) icb = 255;

  *l = (unsigned char) il;
  *cr = (unsigned char) icr;
  *cb = (unsigned char) icb;

}
