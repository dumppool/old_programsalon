/*===========================================================================*
 * noparallel.c								     *
 *									     *
 *	would be procedures to make encoder to run in parallel -- except     *
 *	this machine doesn't have sockets, so we can only run sequentially   *
 *	so this file has dummy procedures which lets it compile		     *
 *									     *
 * EXPORTED PROCEDURES:							     *
 *	StartInputServer						     *
 *	StartOutputServer						     *
 *	SendRemoteFrame							     *
 *	GetRemoteFrame							     *
 *	StartParallelServer						     *
 *	NotifyMasterDone						     *
 *									     *
 *===========================================================================*/

/*
 * Copyright (c) 1993 The Regents of the University of California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

/*  
 *  $Header: /home/zeno/milamber/project/MpegCodec/encoder/RCS/noparallel.c,v 1.1 1995/01/09 20:10:01 milamber Exp milamber $
 *  $Log: noparallel.c,v $
 * Revision 1.1  1995/01/09  20:10:01  milamber
 * Initial revision
 *
 * Revision 1.1  1994/11/20  08:18:32  milamber
 * Initial revision
 *
 * Revision 1.1  1993/07/22  22:23:43  keving
 * nothing
 *
 * Revision 1.1  1993/06/30  20:06:09  keving
 * nothing
 *
 */


/*==============*
 * HEADER FILES *
 *==============*/

#include "all.h"
#include "mtypes.h"
#include "noparallel.h"
#include "basic_frame.h"


/*==================*
 * GLOBAL VARIABLES *
 *==================*/

int parallelTestFrames = 10;
int parallelTimeChunks = 60;
char *IOhostName;
int IOportNumber;
int outputPortNumber;
boolean	niceProcesses;


/*=====================*
 * EXPORTED PROCEDURES *
 *=====================*/

			/*=================*
			 * IO SERVER STUFF *
			 *=================*/


void
SetIOConvert(separate)
    boolean separate;
{
    /* do nothing -- this may be called during non-parallel execution */
}


void
SetRemoteShell(shell)
    char *shell;
{
    /* do nothing -- this may be called during non-parallel execution */
}


/* StartIOServer
 */ 
void
StartInputServer(numInputFiles, parallelHostName, portNum)
    int numInputFiles;
    char *parallelHostName;
    int portNum;
{
    fprintf(stdout, "ERROR:  (StartInputServer) This machine can NOT run parallel version\n");
    exit(1);
}


void
StartOutputServer(numInputFiles, outputFileName, parallelHostName, portNum)
    int numInputFiles;
    char *outputFileName;
    char *parallelHostName;
    int portNum;
{
    fprintf(stdout, "ERROR:  (StartOutputServer) This machine can NOT run parallel version\n");
    exit(1);
}


void
NoteFrameDone(frameStart, frameEnd)
    int frameStart;
    int frameEnd;
{
    fprintf(stdout, "ERROR:  (NoteFrameDone) This machine can NOT run parallel version\n");
    exit(1);
}

/* SendRemoteFrame
 */
void
SendRemoteFrame(frameNumber, bb)
    int frameNumber;
    BitBucket *bb;
{
    fprintf(stdout, "ERROR:  (SendRemoteFrame) This machine can NOT run parallel version\n");
    exit(1);
}


/* GetRemoteFrame
 */
void
GetRemoteFrame(frame, frameNumber)
    EncoderMpegFrame *frame;
    int frameNumber;
{
    fprintf(stdout, "ERROR:  (GetRemoteFrame) This machine can NOT run parallel version\n");
    exit(1);
}


void
WaitForOutputFile(number)
    int number;
{
    fprintf(stdout, "ERROR:  (WaitForOutputFile) This machine can NOT run parallel version\n");
    exit(1);
}


			/*=======================*
			 * PARALLEL SERVER STUFF *
			 *=======================*/


/* StartParallelServer
 */
void
StartParallelServer(numInputFiles, paramFile, outputFileName)
    int numInputFiles;
    char *paramFile;
    char *outputFileName;
{
    fprintf(stdout, "ERROR:  (StartParallelServer) This machine can NOT run parallel version\n");
    exit(1);
}


/* NotifyMasterDone
 */
boolean
NotifyMasterDone(hostName, portNum, machineNumber, seconds, frameStart,
		 frameEnd)
    char *hostName;
    int portNum;
    int machineNumber;
    int seconds;
    int *frameStart;
    int *frameEnd;
{
    fprintf(stdout, "ERROR:  (NotifyMasterDone) This machine can NOT run parallel version\n");
    exit(1);
}
