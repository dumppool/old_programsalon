/* This is the header file for the top level user interface class UI */
/* (c)1994 Alexis 'Milamber' Ashley */
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "main_win.H"
#include "sands_o_time.h"
#include "sands_mask.h"
#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <X11/cursorfont.h>
#include <X11/Xatom.h>

char MainWindow::Foreground[80]   = "Black";
char MainWindow::Background[80]   = "Light Grey";
char MainWindow::CursorColour[80] = "Midnight Blue";
unsigned int MainWindow::BorderWidth = 6;

static void default_configure_fn(void);

MainWindow::MainWindow(const char * const _name, unsigned int height, unsigned int width,
		       int argc, char **argv)
: UI_Globals(_name,argc,argv)
{
  XColor tmp_col;       // This is used during colour pixel allocation
  XSizeHints xsh;       // This structure is used for creating the geometry
                        // for the window.  It is filled in, then passed to
                        // XWMGeometry, which returns the actual size & 
                        // location for the window
  XWMHints xwmh;        // This structure is filled in to give 'hints' to
                        // the window manager about how this window should
                        // be created.
  XClassHint xch;       // This does the same job as xwmh
  XTextProperty win_name; // This is filled in to be the window's name
  char def_geom[80];    // The "640x480+20+20" style geometry string is
                        // created in this string, and then passed to 
                        // XWMGeometry
  char _geom[80];       // This will hold the user specified geometry.
  char *geom = _geom;   // This points to _geom.
  Window win_id;        // This will hold the window id of this window
  unsigned int main_width,main_height;
  geom[0]='\0';         // Blank the user specified geometry string

  char *name = new char[strlen(_name)+1];
  assert(name!=NULL);
  strcpy(name,_name);

  opt_list resources[] =   // List of resources that mainwindow uses
    {
      { "foreground"  , Foreground   },
      { "background"  , Background   },
      { "geometry"    , geom         },
      { "cursor"      , CursorColour },
      { "title"       , name         },
      { ""            , NULL         }
    };
  opt_list cmdline[] =    // List of command line options that
    {                     // mainwindow understands
      { "-geometry"   , geom         },
      { "-g"          , geom         },
      { "-foreground" , Foreground   },
      { "-fg"         , Foreground   },
      { "-background" , Background   },
      { "-bg"         , Background   },
      { "-cursor"     , CursorColour },
      { "-cr"         , CursorColour },
      { "-title"      , name         },
      { "-t"          , name         },
      { ""            , NULL         }
    };

// Check for X resources

  CheckResources(resources);

// Check for command line options

  CheckCommandLine(cmdline);

// Allocate foreground colour.  If colour is unavailable, use black

  if(XParseColor(DispPointer(),Colourmap,Foreground,&tmp_col)==0 ||
     XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
    fg_colour = Black;
  else
    fg_colour = tmp_col.pixel;

// Allocate background colour.  If colour is unavailable, use white

  if(XParseColor(DispPointer(),Colourmap,Background,&tmp_col)==0 ||
     XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
    bg_colour = White;
  else
    bg_colour = tmp_col.pixel;

// Build an XSizeHints structure, so that we can tell the window manager what
// size of window we would like, and where we would like to placed

  xsh.flags = (PPosition | PSize | PMinSize | PMaxSize);
  xsh.min_height = height;
  xsh.min_width = width;
  xsh.max_width = DisplayWidth(DispPointer(),DefaultScreen(DispPointer()));
  xsh.max_height = DisplayHeight(DispPointer(),DefaultScreen(DispPointer()));
  xsh.height = height+(height/4);
  xsh.width = width+(width/4);
  xsh.x = (DisplayWidth(DispPointer(),DefaultScreen(DispPointer()))-
	   xsh.width)/2;
  xsh.y = (DisplayHeight(DispPointer(),DefaultScreen(DispPointer()))-
	   xsh.height)/2;

// Build a default geometry string.  This + a user specified geometry string
// will be passed to XWMGeometry

  sprintf(def_geom,"%dx%d+%d+%d",xsh.width,xsh.height,xsh.x,xsh.y);

// If a geometry setting wasn't found in the Xresources, or on the command
// line, set geom to NULL

  if(strlen(geom)==0)
    geom = NULL;

// Call XWMGeometry.  It will decide the actual geometry of the window

  int bitmask = XWMGeometry(DispPointer(),DefaultScreen(DispPointer()), geom,
			    def_geom,BorderWidth,&xsh,&main_x,&main_y,
			    &main_width,&main_height,&main_gravity);

// bitmask will hold the values that need to be changed to reflect the
// suggestions made by XWMGeometry.  This will be done by the window
// manager when we call XSetWMProperties

  if(bitmask & (XValue | YValue))
    xsh.flags |= USPosition;
  if(bitmask & (WidthValue | HeightValue))
    xsh.flags |= USSize;

// Clip the values returned by XWMGeometry if it wants me to make a window
// that is more than 200% of what was asked for.

  if(main_height>2*height)
    xsh.height = main_height = 2*height;

  if(main_width>2*width)
    xsh.width = main_width = 2*width;

// Make the window

  win_id = XCreateSimpleWindow(DispPointer(),
				    DefaultRootWindow(DispPointer()),main_x,
				    main_y,main_width,main_height,BorderWidth,
				    fg_colour,bg_colour);

// Have a little chat with the window manager....

  win_name.value = name;
  win_name.encoding = XA_STRING;
  win_name.format = 8;
  win_name.nitems = strlen(name);
  xwmh.flags = (InputHint | StateHint);
  xwmh.input = True;
  xwmh.initial_state = NormalState;
  xch.res_name = name;
  xch.res_class = new char[strlen(name)+1];
  assert(xch.res_class!=NULL);
  strcpy(xch.res_class,name);
  xch.res_class[0]=toupper(xch.res_class[0]);
  XSetWMProperties(DispPointer(),win_id,&win_name,NULL,argv,argc,
		   &xsh,&xwmh,&xch);
  delete xch.res_class;
  delete name;

// Register this window with UI_Globals

  RegisterWindow(this,win_id,main_height,main_width);

// Select what events we want X to report to us

  XSelectInput(DispPointer(),win_id,ExposureMask | ButtonPressMask |
	       ButtonReleaseMask | StructureNotifyMask | FocusChangeMask
	       | KeyPressMask);

// Select the colourmap for the top level window, in case the user specified
// -private cols

  XSetWindowColormap(DispPointer(),win_id,Colourmap);

// Map the window

  XMapWindow(DispPointer(),win_id);

// Allocate the foreground & background colours of the cursor

  if(XParseColor(DispPointer(),Colourmap,CursorColour,&c_fg_colour)==0 ||
     XAllocColor(DispPointer(),Colourmap,&c_fg_colour)==0)
    c_fg_colour.pixel = Black;

  if(XParseColor(DispPointer(),Colourmap,Background,&c_bg_colour)==0 ||
     XAllocColor(DispPointer(),Colourmap,&c_bg_colour)==0)
    c_bg_colour.pixel = White;

// Make the 'sands of time' cursor

  sands_bmap = XCreateBitmapFromData(DispPointer(),win_id,
				     sands_o_time_bits,sands_o_time_width,
				     sands_o_time_height);
  sands_bmask = XCreateBitmapFromData(DispPointer(),win_id,
				      sands_mask_bits,sands_mask_width,
				      sands_mask_height);
  sands = XCreatePixmapCursor(DispPointer(),sands_bmap,sands_bmask,
			      &c_fg_colour,&c_bg_colour,sands_o_time_x_hot,
			      sands_o_time_y_hot);
// Create the arrow cursor

  arrow = XCreateFontCursor(DispPointer(),XC_left_ptr);
  XRecolorCursor(DispPointer(),arrow,&c_fg_colour,&c_bg_colour);

// Use the arrow cursor

  XDefineCursor(DispPointer(),win_id,arrow);

// Setup the default configure notify function.  This function is called when
// the main window is resized by the user.  Here we set it to a do-nothing
// function.

  configure_fn = default_configure_fn;

// Set the window that wants input focus to this window.  This will do until
// a window that really does want keyboard focus registers itself with the
// SetFocus command

  FocusWindow = win_id;

// At last, we've finished!
}

MainWindow::~MainWindow(void)
{
  colour cols[2];

// Remove the custom cursor

  XUndefineCursor(DispPointer(),WinId());

/* Free the colours that were allocated by the main window */
  cols[0] = fg_colour;
  cols[1] = bg_colour;
  for(int i=0; i<2; i++)
    if(cols[i]!=White && cols[i]!=Black)
      XFreeColors(DispPointer(),Colourmap,&cols[i],1,0);
}

void MainWindow::BusyCursor(void)
{
  XDefineCursor(DispPointer(),WinId(),sands);
}

void MainWindow::NormalCursor(void)
{
  XDefineCursor(DispPointer(),WinId(),arrow);
}

MainWindow::status MainWindow::event_handler(XEvent *Event)
{
  switch(Event->type)
    {
    case Expose:
      if(Event->xexpose.count==0)
	XClearWindow(DispPointer(),WinId());
      break;
    case ButtonPress:
      break;
    case ConfigureNotify:
      if(Event->xconfigure.width!=width() || 
	 Event->xconfigure.height!=height())
	{
	  UI_Globals::ResizeWindow(Event->xconfigure.height,
				   Event->xconfigure.width);
	  (*configure_fn)();
	}
      break;
    case MappingNotify:
      XRefreshKeyboardMapping(&Event->xmapping);
      break;
    case FocusIn:
      if(Event->xfocus.mode==NotifyNormal && 
	 Event->xfocus.detail==NotifyNonlinear)
	{
	  XSetInputFocus(DispPointer(),FocusWindow,RevertToParent,
			 CurrentTime);
	}
      break;
    case KeyPress:
      break;
    default:
      break;
    }
  return(okay);
}

void MainWindow::ResizeWindow(unsigned int new_height,unsigned int new_width)
{
  XSizeHints xsh;
	  
  xsh.flags = (PSize | PMinSize | PMaxSize);
  xsh.min_height = new_height;
  xsh.min_width = new_width;
  xsh.max_width = DisplayWidth(DispPointer(),
			       DefaultScreen(DispPointer()));
  xsh.max_height = DisplayHeight(DispPointer(),
				 DefaultScreen(DispPointer()));
  xsh.height = new_height;
  xsh.width = new_width;

  XSetWMNormalHints(DispPointer(),WinId(),&xsh);
  UI_Globals::ResizeWindow(new_height,new_width);
  (*configure_fn)();
}

void MainWindow::RegisterConfigureFunction(void (*callback)(void))
{
  configure_fn = callback;
}

Window MainWindow::SetFocus(Window new_focus_window)
{
  Window temp=FocusWindow;
  FocusWindow = new_focus_window;
  return(temp);
}

int MainWindow::ColourDepth(void)
{
  Window root;
  unsigned int x,y,width,height;
  unsigned int bd_width, depth;
  XGetGeometry(DispPointer(),WinId(),&root,&x,&y,&width,&height,
	       &bd_width,&depth);
  return depth;
}

unsigned int MainWindow::ScreenHeight(void)
{
  Window root=RootWindow( DispPointer() , DefaultScreen( DispPointer() ) );
  Window root2;
  unsigned int x,y,width,height;
  unsigned int bd_width, depth;
  XGetGeometry(DispPointer(),root,&root2,&x,&y,&width,&height,
	       &bd_width,&depth);
  return height;
}

unsigned int MainWindow::ScreenWidth(void)
{
  Window root=RootWindow( DispPointer() , DefaultScreen( DispPointer() ) );
  Window root2;
  unsigned int x,y,width,height;
  unsigned int bd_width, depth;
  XGetGeometry(DispPointer(),root,&root2,&x,&y,&width,&height,
	       &bd_width,&depth);
  return width;
}

void MainWindow::SetName(char *name)
{
  XStoreName(DispPointer(),WinId(),name);
}

static void default_configure_fn(void)
{
}
