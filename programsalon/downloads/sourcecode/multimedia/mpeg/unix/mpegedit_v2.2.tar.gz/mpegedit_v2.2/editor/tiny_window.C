/**********************************************************/
/* This class controls access to a tiny monochrome window */
/*                                                        */
/*           (c)1994 Alexis 'Milamber' Ashley             */
/**********************************************************/
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "tiny_window.H"
#include "yuv.H"
#include <assert.h>
#include <stdlib.h>

TinyWindow::TinyWindow(UI_Globals *parent,world_c x,world_c y,
		       unsigned int height,unsigned int width,
		       void (*cb)(void) )
: YUV_Window(parent,x,y,height/2,width/2,this, ButtonPressMask | 
	     ButtonReleaseMask)
{
#ifdef SH_MEM
  cout << "Starting Shared memory ";
  if( !XShmQueryExtension(DispPointer()) )
    {
      cout << endl;
      using_shm = false;
      cerr << "Shared memory not supported\n";
      cerr << "Reverting to normal Xlib.\n";
    }
  else
    {
      cout << '.';
      using_shm=true;
      CompletionType=XShmGetEventBase(DispPointer())+ShmCompletion;
    }
#endif

  status stat = InitColours();
  if(stat!=okay)
    {
      abort();
    }
  stat = InitDitherArray();
  if(stat!=okay)
    {
      abort();
    }

#ifdef SH_MEM
  if(using_shm)
    {
      cout << '.';
      ximage = XShmCreateImage(DispPointer(), None, 8, ZPixmap, NULL,
			       &shminfo, width/2 , height/2);
      if (ximage == NULL)
	{
	  using_shm = false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
    }
  if(using_shm)
    {
      cout << '.';
      shminfo.shmid = shmget(IPC_PRIVATE, (ximage->bytes_per_line * 
					   ximage->height),
			     IPC_CREAT | 0777);

      if (shminfo.shmid < 0)
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
    }
  if(using_shm)
    {
      cout << '.';
      shminfo.shmaddr = (char *) shmat(shminfo.shmid, 0, 0);
      if (shminfo.shmaddr == ((char *) -1))
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
      ximage->data = shminfo.shmaddr;
      shminfo.readOnly = False;
      
      XShmAttach(DispPointer(), &shminfo);
      XSync(DispPointer(), False);
    }
  if(using_shm)
    {
      cout << '.';
      FlushEvents();
      XErrorEvent Xerr = GetLastError();
      if (Xerr.error_code==BadAccess && Xerr.request_code==129 &&
	  Xerr.minor_code==1)
	{
	  XDestroyImage(ximage);
	  ximage = NULL;
	  using_shm=false;
	  cout << endl;
	  cerr << "Shared memory error, disabling.\n";
	  cerr << "Reverting to normal Xlib.\n";
	}
      else
	{
	  shmctl(shminfo.shmid, IPC_RMID, 0);
	  cout << "  shared memory fully operational\n";
	}
    }
  if(!using_shm)
    {

#endif
      char dummy;
      
      ximage=XCreateImage(DispPointer(),None,8,ZPixmap,0,&dummy,
			  width/2,height/2,8,0);
      ximage->data = new byte[ximage->bytes_per_line*height/2];
      assert(ximage->data!=NULL);
#ifdef SH_MEM
    }
#endif
  image_available=false;
  callback = cb;
}

TinyWindow::~TinyWindow(void)
{
  long tmp_pixel;

  FlushEvents();
  for(int j = 0; j < GRAY_RANGE; j ++)
    {
      tmp_pixel = col_array[j];
      XFreeColors(DispPointer(), Colourmap, &tmp_pixel, 1, 0);
    }
  XFreeGC(DispPointer(),gc);

#ifdef SH_MEM

  if(using_shm)
    {
      XShmDetach(DispPointer(), &shminfo);
      XDestroyImage(ximage);
      shmdt(shminfo.shmaddr);
    }
  else
    {
#endif

      delete ximage->data;
      XFree(ximage);  // Note: This fn DOESNT destroy the data!

#ifdef SH_MEM
    }
#endif
}

/* The following code based on code in the files gray.c and gdith.c, both
 * from the University of California's mpeg_play programme.
 *
 * Copyright (c) 1992 The Regents of the University of California.
 * All rights reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

UI_Globals::status TinyWindow::InitColours(void)
{
  XColor xcolor;
  int scalor = 256/GRAY_RANGE;

  gc = XCreateGC(DispPointer(), WinId(), 0, 0);

  xcolor.flags = DoRed | DoGreen | DoBlue;

  for (int i=0; i<GRAY_RANGE; i++)
    {
      xcolor.red = (i*scalor) * 256;
      xcolor.green = (i*scalor) * 256;
      xcolor.blue = (i*scalor) * 256;
      if(XAllocColor(DispPointer(), Colourmap, &xcolor) == 0)
	{                    // If we were unable to allocate a colour, free
	  long tmp_pixel;    // the colours we've already allocated, and quit.
	  
	  for(int j = 0; j < i; j ++)
	    {
	      tmp_pixel = col_array[j];
	      XFreeColors(DispPointer(), Colourmap, &tmp_pixel, 1, 0);
	    }
	  cerr << "Unable to allocate the colours required to make the\n"
	       << "monochrome window.  Please re-run with the option "
	       << " -private cols\n";
	  return(out_of_memory);
	}
      col_array[i] = xcolor.pixel;
    }
  return(okay);
}

UI_Globals::status TinyWindow::InitDitherArray(void)
{
  int j=0;
  int granularity=256/GRAY_RANGE;

  dith_array[0]=col_array[0];       // This gets around j being incremented
                                    // in the first pass though the for loop,
  for(int i=1; i<256; i++)          // by starting i at 1
    {
      dith_array[i]=col_array[j];
      if((i % granularity)==0)
	j++;
    }
  return(okay);
}

UI_Globals::status TinyWindow::DisplayFrame(frame &Frame, bool nicely)
{
  assert(Frame.width()/2==ximage->width);
  assert(Frame.height()/2==ximage->height);
  DitherImage(Frame.lum_ptr(),ximage->data,ximage->height,ximage->width);
  if(nicely)
    {
      XEvent Event;
      Event.type = Expose;
      Event.xexpose.window = WinId();
      Event.xexpose.display = DispPointer();
      Event.xexpose.x=0;
      Event.xexpose.y=0;
      Event.xexpose.width = width();
      Event.xexpose.height = height();
      Event.xexpose.count = 0;
      XSendEvent(DispPointer(),WinId(),False,0,&Event);
    }
  else
    {
#ifdef SH_MEM
      if(using_shm)
	{
	  XShmPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		       ximage->height,True);
	}
      else
#endif
	XPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		  ximage->height);
      XFlush(DispPointer());
    }
  image_available = true;
  return(okay);
}

/*
 *--------------------------------------------------------------
 *
 * DitherImage --
 *
 *	Dithers image into gray scales. Simply maps average of 
 *      four luminance values into one pixel which can be 1 of
 *      GRAY_RANGE gray scale colors
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	None.
 *
 *--------------------------------------------------------------
 */

void TinyWindow::DitherImage(unsigned char *lum, unsigned char *out,
			      int h, int w)
{
  register byte *ptr1=lum;
  register byte *ptr2=lum+2*w;
  register byte *ptr3=out;
  int ans;
  int x,y;

  for (y=0; y<h; y++)
    {
      for (x=0; x<w; x++)
	{
	  ans = *(ptr1++) + *(ptr1++) + *(ptr2++) + *(ptr2++);
	  *(ptr3++) = dith_array[ans>>2];
	}
      ptr1 = ptr2;
      ptr2 += w<<1;
    }
}

UI_Globals::status TinyWindow::event_handler(XEvent *Event)
{
  if(Event->type==Expose && Event->xexpose.count==0 && image_available)
    {
#ifdef SH_MEM
      if(using_shm)
	{
	  XShmPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		       ximage->height,True);
	}
      else
#endif
	XPutImage(DispPointer(),WinId(),gc,ximage,0,0,0,0,ximage->width,
		  ximage->height);
      XSync(DispPointer(),False);
    }
  else if(Event->type==ButtonPress)
    {
      (*callback)();
    }
  return(UI_Globals::okay);
}
