/* This is the code for my TypeInBox class */
/* (c)1995 Alexis Ashley         milamber@dcs.warwick.ac.uk */
/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "type_in_box.H"
#include <assert.h>
#include <string.h>
#include <X11/keysym.h>

char TypeInBox::Foreground[80]  = "Black";  // Default font for TypeInBoxes
char TypeInBox::Background[80]  = "Grey75"; // background col used by all TIBs
char TypeInBox::high_name[80]   = "grey90"; // Name of col used for bright line
char TypeInBox::low_name[80]    = "grey56"; // Name of col used for dark line
char TypeInBox::DefaultFont[80] = "*-helvetica-bold-r-*-120-*";
                                  // Default font used for the text TypeInBoxes
UI_Globals::opt_list TypeInBox::resources[] =
    {                                // The resource list used by this class
      { "TypeInBox.foreground" , Foreground  },
      { "TypeInBox.background" , Background  },
      { "TypeInBox.highlight"  , high_name   },
      { "TypeInBox.lowlight"   , low_name    },
      { "TypeInBox.font"       , DefaultFont },
      { ""                  , NULL        }
    };

const unsigned int TypeInBox::BorderWidth = 1;       // border with of all TypeInBoxes
XFontStruct *TypeInBox::Default_Font = NULL;  // used in loading default font
GC TypeInBox::highlight;       // GC of bright line used to make boxes look 3D
GC TypeInBox::lowlight;        // GC of dark line used to make boxes look 3D
colour TypeInBox::high_colour; // Stores colour for bright line
colour TypeInBox::low_colour;  // Stores colour for dark line
int TypeInBox::count=0;        // Tells the constructor that this is the
                               // first type in box, and it should allocate
                               // the colours for the 3D lines

XGCValues TypeInBox::Default_xGCv = 
{
  0,              // Function        - Not set
  0,              // Plane mask      - Not set
  0,              // Fg pixel col    - Not set
  0,              // Bg pixel col    - Not set
  1,              // Line width
  LineSolid,      // Line style
  CapButt,        // Cap style
  JoinMiter,      // Join style
  FillSolid       // Fill style
  };

unsigned long TypeInBox::Default_gc_mask = GCLineWidth | GCLineStyle |
                                           GCCapStyle | GCJoinStyle |
					   GCFillStyle;

/* *********************** TypeInBox Constructor ******************* */

TypeInBox::TypeInBox(UI_Globals *parent, world_c x, world_c y, MainWindow *mw,
		     status (*call_back)(char *),int size, 
		     corner relative_to,
		     const char *fgcolour,char *font)
: UI_Globals(parent)
{
  unsigned int px,py;                    // Used in calculating x,y pos for TypeInBox
  unsigned long mask=0;           // This is used as the mask for xgcv
  XGCValues xgcv;                 // Used to set the values to pass to
                                  // XCreateGC
  XColor tmp_col;                 // Used as a temp colour store
  unsigned int height,width;             // The window's height & width
  Window win_id;                  // The win id of this window

// Check the X resources
  CheckResources(resources);

// If the user didn't specify a font name, use Default_Font.  If they did,
// load this font into memory.  If this fails, use Default_Font.

  if(strcmp(DefaultFont,font)==0)
    Font = Default_Font;
  else
    {
      Font = XLoadQueryFont(DispPointer(),font);
      if(Font==NULL)
	Font = Default_Font;
    }

// If necessary, load DefaultFont into memory

  if(Font==NULL && Default_Font==NULL)
    {
      Font = Default_Font = XLoadQueryFont(DispPointer(),DefaultFont);
    }
  assert(Font != NULL);


// Copy the data from the constructor's parameters into the class' private vars

  width=XTextWidth(Font,"e",1)*size+x_spacing()*2;
  char_buf = new char[size];
  assert(char_buf!=NULL);
  buf_size = size;
  cur_pos = 0;
  char_buf[0]='_';
  char_buf[1]='\0';
  height=Font->max_bounds.ascent + Font->max_bounds.descent + y_spacing();
  MainWin = mw;
  callback = call_back;

// Now work out where to place the window, by using the parent window's
// world coord to pixel functions

  px = parent->wc2pix_x(x);
  py = parent->wc2pix_y(y);

// This switch is used to set which corner the x and y world coords referred
// to, and to adjust px & py accordingly, so that they are correct.

  switch(relative_to)
    {
    case topleft: 
      break;
    case topright:
      px -= width;
      break;
    case bottomleft:
      py -= height;
      break;
    case bottomright:
      px -= width;
      py -= height;
      break;
    }

// The following is just some fairly bog standard code to ask X for two colour
// values.  If X is unable to comply, the code will use black & white, which
// is always guarenteed to be available.

  if(XParseColor(DispPointer(),Colourmap,Background,&tmp_col)==0 ||
     XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
     bg_colour = White;
  else
     bg_colour = tmp_col.pixel;
  if(XParseColor(DispPointer(),Colourmap,fgcolour,&tmp_col)==0 ||
     XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
     fg_colour = Black;
  else
     fg_colour = tmp_col.pixel;

// Now create the window

  win_id=XCreateSimpleWindow(DispPointer(),parent->WinId(),px,py,width,height,
			     BorderWidth,Black,bg_colour);

// Now 'register' with UI_Globals the window, so that it can work out
// world coords correctly inside my window. This will also allow this window
// to receive events

  RegisterWindow(this,win_id,height,width);

// Now create a graphics context, so that I can (later on) draw inside the
// window I've just created.

  xgcv = Default_xGCv;
  xgcv.foreground = fg_colour;
  xgcv.background = bg_colour;
  xgcv.font = Font->fid;
  mask = Default_gc_mask | GCForeground | GCBackground | GCFont;
  GraphicsContext = XCreateGC(DispPointer(),win_id,mask,&xgcv);

// If it's the first initiation of the class, then the colours for the bright
// and dark lines need to be allocated & the GCs need creating

  if(count++==0)
    {
      if(XParseColor(DispPointer(),Colourmap,high_name,&tmp_col)==0 ||
	 XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
	high_colour = White;
      else
	high_colour = tmp_col.pixel;
      if(XParseColor(DispPointer(),Colourmap,low_name,&tmp_col)==0 ||
	 XAllocColor(DispPointer(),Colourmap,&tmp_col)==0)
	low_colour = Black;
      else
	low_colour = tmp_col.pixel;
      mask = Default_gc_mask | GCForeground | GCBackground;
      xgcv = Default_xGCv;
      xgcv.background = bg_colour;
      xgcv.foreground = high_colour;
      highlight = XCreateGC(DispPointer(),win_id,mask,&xgcv);
      xgcv.foreground = low_colour;
      lowlight = XCreateGC(DispPointer(),win_id,mask,&xgcv);
    }

// Now calculate where the bright & dark lines have to be draw to make the
// TypeInBox look 3D

  low_seg[0].x1=0;                      low_seg[0].y1=0;
  low_seg[0].x2=width;                  low_seg[0].y2=0;
  low_seg[1].x1=1;                      low_seg[1].y1=1;
  low_seg[1].x2=width-1;                low_seg[1].y2=1;
  low_seg[2].x1=0;                      low_seg[2].y1=1;
  low_seg[2].x2=0;                      low_seg[2].y2=height;
  low_seg[3].x1=1;                      low_seg[3].y1=2;
  low_seg[3].x2=1;                      low_seg[3].y2=height-1;

  high_seg[0].x1=1;                     high_seg[0].y1=height-BorderWidth;
  high_seg[0].x2=width;                 high_seg[0].y2=height-BorderWidth;
  high_seg[1].x1=2;                     high_seg[1].y1=height-1-BorderWidth;
  high_seg[1].x2=width-1;               high_seg[1].y2=height-1-BorderWidth;
  high_seg[2].x1=width-BorderWidth;     high_seg[2].y1=1;
  high_seg[2].x2=width-BorderWidth;     high_seg[2].y2=height-1;
  high_seg[3].x1=width-1-BorderWidth;   high_seg[3].y1=2;
  high_seg[3].x2=width-1-BorderWidth;   high_seg[3].y2=height-2;

// Now I tell X what events I want to be told about
  XSelectInput(DispPointer(),win_id,ExposureMask | ButtonPressMask | 
	       ButtonReleaseMask | KeyPressMask);

// Map the window

  XMapWindow(DispPointer(),win_id);

// Tell the main window that I want keyboard focus + store the old focus window
  
  old_focus = mw->SetFocus(win_id);

// Send a FocusIn event to the main window, so that this window is guarenteed
// to get the keyboard focus

//  XEvent Event;
//  Event.type = FocusIn;
// Event.xfocus.mode = NotifyNormal;
//  Event.xfocus.detail = NotifyNonlinear;
//  Event.xfocus.window = WinId();
//  Event.xfocus.display = DispPointer();
//  XSendEvent(DispPointer(),mw->WinId(),False,0,&Event);

  XSetInputFocus(DispPointer(),win_id,RevertToParent,CurrentTime);
}

TypeInBox::~TypeInBox(void)
{
  colour cols[4];
  int num_cols=2;

  MainWin->SetFocus(old_focus);

// Free the font, if one was loaded specifically for this type in box

  if(Font!=Default_Font)
    XFreeFont(DispPointer(),Font);

// Free the colours that were allocated by the TypeInBox

  cols[0] = fg_colour;
  cols[1] = bg_colour;
  if(--count==0)
    {
      cols[2] = high_colour;
      cols[3] = low_colour;
      num_cols = 4;
      if(Default_Font!=NULL)
	{
	  XFreeFont(DispPointer(),Default_Font);
	  Default_Font = NULL;
	}
    }
  for(int i=0; i<num_cols; i++)
    if(cols[i]!=White && cols[i]!=Black)
      XFreeColors(DispPointer(),Colourmap,&cols[i],1,0);

// Destroy the graphics context that was created for this window

  XFreeGC(DispPointer(),GraphicsContext);

// Destory all the data that was allocated in the constructor function

  delete char_buf;
}

TypeInBox::status TypeInBox::event_handler(XEvent *Event)
{
  status ret_val=okay;

  switch(Event->type)
    {
    case ButtonPress:
      break;
    case ButtonRelease:
    case KeyPress:
      {
	KeySym key;
	XComposeStatus cs;

// Get X to turn the KeySym into an ascii text string

	int count = XLookupString(&Event->xkey,xlat_buffer,20,&key,&cs);

// Make this string into a valid C string

	xlat_buffer[count]='\0';

// Check for special keys (eg ENTER, DELETE etc)

	switch(key)
	  {
	  case XK_Return:
	  case XK_KP_Enter:
	    return (*callback)(CurrentValue());
	  case XK_Delete:
	    if(cur_pos>0)
	      {
		char_buf[--cur_pos]='_';
		char_buf[cur_pos+1]='\0';
	      }
	    break;
	  default:            // Append it to char_buf
	    for(int i=cur_pos; i<cur_pos+count && i<buf_size-1; i++)
	      {
		char_buf[i]=xlat_buffer[i-cur_pos];
	      }
	    if(cur_pos<buf_size-1)
	      {
		cur_pos += count;
		char_buf[cur_pos]='_';
		char_buf[cur_pos+1]='\0';
	      }
	  }
	// Fool the Expose case into doing a redraw
	Event->xexpose.count=0;
      }
    case Expose:
      if(Event->xexpose.count==0)
	{
	  XClearWindow(DispPointer(),WinId());
	  XDrawSegments(DispPointer(),WinId(),highlight,high_seg,4);
	  XDrawSegments(DispPointer(),WinId(),lowlight,low_seg,4);
	  XDrawString(DispPointer(),WinId(),GraphicsContext,x_spacing(),
		      height()-y_spacing()-BorderWidth,char_buf,
		      strlen(char_buf));
	}
      break;
    default:
      break;
    }
  return(ret_val);
}

char *TypeInBox::CurrentValue(void)
{
  int i,j;

  if(cur_pos==0)
    return(NULL);
  char *retval = new char[strlen(char_buf)+1];
  assert(retval!=NULL);
  for(i=0, j=0; i<strlen(char_buf); i++)
    {
      if(i!=cur_pos)
	retval[j++]=char_buf[i];
    }
  retval[j]='\0';
  return(retval);
}

void TypeInBox::ClearText(void)
{
  cur_pos=0;
  char_buf[0]='_';
  char_buf[1]='\0';
  XEvent Event;
  Event.type = Expose;
  Event.xexpose.window = WinId();
  Event.xexpose.display = DispPointer();
  Event.xexpose.x=0;
  Event.xexpose.y=0;
  Event.xexpose.width = width();
  Event.xexpose.height = height();
  Event.xexpose.count = 0;
  XSendEvent(DispPointer(),WinId(),False,0,&Event);
}

void TypeInBox::SetText(char *new_text)
{
  int i;

  for(i=0; i<strlen(new_text) && i<buf_size-1; i++)
    {
      char_buf[i] = new_text[i];
    }
  char_buf[i] = '_';
  char_buf[i+1] = '\0';
  cur_pos = i;
  XEvent Event;
  Event.type = Expose;
  Event.xexpose.window = WinId();
  Event.xexpose.display = DispPointer();
  Event.xexpose.x=0;
  Event.xexpose.y=0;
  Event.xexpose.width = width();
  Event.xexpose.height = height();
  Event.xexpose.count = 0;
  XSendEvent(DispPointer(),WinId(),False,0,&Event);
}

void TypeInBox::MoveWindow(world_c new_x, world_c new_y)
{
  UI_Globals *parent = Parent();
  unsigned int px = parent->wc2pix_x(new_x);
  unsigned int py = parent->wc2pix_y(new_y);
  XMoveWindow(DispPointer(),WinId(),px,py);
}

