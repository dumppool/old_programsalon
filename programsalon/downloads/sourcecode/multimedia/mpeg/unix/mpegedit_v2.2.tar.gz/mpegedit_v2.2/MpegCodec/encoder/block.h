/*===========================================================================*
 * block.h								     *
 *									     *
 *	Block routines							     *
 *									     *
 * EXPORTED PROCEDURES:							     *
 *	ComputeDiffDCTBlock						     *
 *	ComputeDiffDCTs							     *
 *	ComputeMotionBlock						     *
 *	ComputeMotionLumBlock						     *
 *	LumBlockMAD							     *
 *	LumMotionError							     *
 *	LumMotionErrorSubSampled					     *
 *	LumAddMotionError						     *
 *	AddMotionBlock							     *
 *	BlockToData							     *
 *	BlockifyFrame							     *
 *									     *
 * NOTES:   MAD	=   Mean Absolute Difference				     *
 *									     *
 *===========================================================================*/

/*
 * Copyright (c) 1993 The Regents of the University of California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */


#ifndef __BLOCK__
#define __BLOCK__

#include "ansi.h"

__BEGIN_DECLS

void BlockToData _ANSI_ARGS_((uint8 **data, MBlock block, int by, int bx));

void AddMotionBlock _ANSI_ARGS_((MBlock block, uint8 **prev, int by, int bx,
				 int my, int mx));

void AddBMotionBlock _ANSI_ARGS_((MBlock block, uint8 **prev, uint8 **next,
				  int by, int bx, int mode,
				  int fmy, int fmx, int bmy, int bmx));

void BlockifyFrame _ANSI_ARGS_((EncoderMpegFrame *frame));

void ComputeDiffDCTBlock _ANSI_ARGS_((MBlock current,MBlock motionBlock));

void ComputeDiffDCTs _ANSI_ARGS_((EncoderMpegFrame *current,
				  EncoderMpegFrame *prev,int by,
				  int bx, int my, int mx, int pattern));
void ComputeMotionBlock _ANSI_ARGS_((uint8 **prev, int by, int bx, int my,
				     int mx, MBlock motionBlock));

void ComputeMotionLumBlock _ANSI_ARGS_((EncoderMpegFrame *prevFrame, int by,
					int bx, int my, int mx,
					LumBlock motionBlock));

int32 LumBlockMAD _ANSI_ARGS_((LumBlock currentBlock, LumBlock motionBlock,
			       int32 bestSoFar));

int32 LumMotionError _ANSI_ARGS_((LumBlock currentBlock,
				  EncoderMpegFrame *prevFrame, int by, int bx,
				  int my, int mx, int32 bestSoFar));

int32 LumAddMotionError _ANSI_ARGS_((LumBlock currentBlock, 
				     LumBlock blockSoFar,
				     EncoderMpegFrame *prevFrame, int by,
				     int bx, int my, int mx, int32 bestSoFar));

__END_DECLS

#endif
