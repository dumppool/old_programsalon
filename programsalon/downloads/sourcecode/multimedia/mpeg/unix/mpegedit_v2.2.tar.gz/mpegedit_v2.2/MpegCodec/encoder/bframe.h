/*===========================================================================*
 * bframe.h								     *
 *									     *
 *	Procedures concerned with the P-frame encoding			     *
 *									     *
 * EXPORTED PROCEDURES:							     *
 *	GenPFrame							     *
 *	SetPQScale							     *
 *      GetPQScale                                                           *
 *	ResetPFrameStats						     *
 *	ShowPFrameSummary						     *
 *	EstimateSecondsPerPFrame					     *
 *									     *
 *===========================================================================*/

/*
 * Copyright (c) 1993 The Regents of the University of California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef __BFRAME__
#define __BFRAME__

#include "ansi.h"
#include "encoders_frame.h"
#include "bitio.h"

__BEGIN_DECLS

extern void GenBFrame _ANSI_ARGS_((BitBucket *bb, EncoderMpegFrame *curr,
				   EncoderMpegFrame *prev,
				   EncoderMpegFrame *next));

extern void ResetBFrameStats _ANSI_ARGS_((void));

extern void ShowBFrameSummary _ANSI_ARGS_((int inputFrameBits,int32 totalBits,
					   FILE *fpointer));

extern float EstimateSecondsPerBFrame _ANSI_ARGS_((void));

extern void ComputeBMotionLumBlock _ANSI_ARGS_((EncoderMpegFrame *prev,
						EncoderMpegFrame *next,
						int by,int bx,int mode,int fmy,
						int fmx,int bmy,int bmx,
						LumBlock motionBlock)); 

extern void SetBQScale _ANSI_ARGS_((int qP));

extern int GetBQScale _ANSI_ARGS_((void));

__END_DECLS

#endif






