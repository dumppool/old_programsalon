#define IMAGE_LEFT  25
#define IMAGE_TOP   25

#define NO_COMMAND  0
#define REWIND_COMMAND	1
#define STOP_COMMAND	2
#define PLAY_COMMAND	3
#define NEXT_COMMAND    4

#define STATUS_HEIGHT 	0
#define STATUS_BORDER 	0


