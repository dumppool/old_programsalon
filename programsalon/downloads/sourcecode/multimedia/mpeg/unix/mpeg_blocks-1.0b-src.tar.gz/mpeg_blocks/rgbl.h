
#define R_RANGE 44
#define G_RANGE 44
#define B_RANGE 44

extern int r_values[R_RANGE];
extern int b_values[B_RANGE];
extern int g_values[G_RANGE];
