char *prgVersion = "0.59k";
char *prgDate = "1997/07/13";
char *prgName;
