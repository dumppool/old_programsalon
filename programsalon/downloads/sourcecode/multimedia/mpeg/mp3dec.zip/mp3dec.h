/* MPEG AUDIO LAYER 3 DECODER */
/* Bjorn Wesen 1997           */

#ifndef MP3DEC_H
#define MP3DEC_H

/* enable the assembler version of the IDCT in the subband synth */
#ifdef WIN32
#define USE_INLINE_ASM
#endif

#ifndef INT_MATH
/* enable the fast implementation of the IMDCT */
#define LEE_IMDCT
#endif

#ifndef WIN32
#undef MAKE_DATA
#define USE_DATA
#else
#undef USE_DATA
#undef MAKE_DATA
#endif

#ifdef DSP
/* in wait of a real math runtime... */
float tan(float f);
float sin(float f);
float cos(float f);
float sqrt(float f);
#else
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* enable clipping in the sample output */
#define OVERFLOW_CHECKING
#endif

#ifndef PI
#define PI 3.1415926535897932385
#endif

#define MAXCH 2           /* number of channels - 2 is stereo */
#define NUM_SUBBANDS 32   /* number of frequency subbands */
#define NUM_DCTBANDS 18   /* number of DCT lines */

#ifdef DSP
#define BITSTREAM_BUFSIZE 1024
#else
#define BITSTREAM_BUFSIZE 131072
#endif

/* ISO-MPEG layers */
#define LAYER1 3
#define LAYER2 2
#define LAYER3 1
#define LAYERRS 0

/* for the sampling_frequency field in a Frame */
#define FREQ_44 0    /* 44.1kHz sampling rate */
#define FREQ_48 1    /* 48kHz sampling rate */
#define FREQ_32 2    /* 32kHz sampling rate */
#define FREQ_RS 3    /* reserved */

/* stereo-mode of a Frame */
#define MODE_STEREO 0
#define MODE_JOINT_STEREO 1
#define MODE_DUAL_CHANNEL 2
#define MODE_SINGLE_CHANNEL 3

/* mode-extensions of joint_stereo in layer 3 */
/* maybe recode these to be two on/off fields instead! */
#define EXT_INT_OFF_MS_OFF 0
#define EXT_INT_ON_MS_OFF 1
#define EXT_INT_OFF_MS_ON 2
#define EXT_INT_ON_MS_ON 3

/* types of de-emphasis */
#define EMPH_NONE 0      /* no de-emphasis */
#define EMPH_5015 1      /* 50/15 microseconds */
#define EMPH_RS 2        /* reserved */
#define EMPH_CCITT 3     /* CCITT J.17 */


typedef int ibool;
#ifndef INT_MATH
#ifdef MAKE_DATA
typedef double mpfloat;   /* use extra precision while doing tables */
#else
typedef float mpfloat;   /* used for audio data calculations */
#endif
#define ISCALE(x)
#else

#define INTFACT 32767
#define ISCALE(x) (x).scale()

class mpfloat {
private:
    mpfloat(int i) { _val = i; }
public:
    mpfloat() { _val = 0; }
//    mpfloat(float f) { _val = (int)(f*INTFACT); } 
    mpfloat(double d) { _val = (int)(d*INTFACT); }

    void scale(int i = 16) {
//	printf("Scaling from 0x%8x.\n", _val);
	_val >>= i;
    }

    int operator!=(mpfloat a) {
	return a._val != _val;
    }

    int operator==(mpfloat a) {
	return a._val == _val;
    }

    mpfloat& operator=(mpfloat a) { 
	_val = a._val;
	return *this;
    }

    mpfloat& operator=(float a) { 
	_val = (int)(a*INTFACT);
	return *this;
    }

    mpfloat& operator=(double a) {