
/* --- C ---
************************************************************************
*
*	Filename    : dir.c
*	Description : directory window functions
*	Part of     : XMPLAY - X11-directory-browser for XMPEG
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#define NEEDSDIR
#define NEEDDIALOG

#include "xmplay.h"
#ifndef F_OK
#include <sys/unistd.h>
#endif

static int listh;
extern char *dirnames [MAXNAMES];
extern int numdirnames;
extern int ndirs;
extern char *dirs [MAXDEEP];
extern char *lastdir;
char typename [MAXFNLEN];
static char typebuf [MAXFNLEN];
time_t dirtime;

static void RedrawDList ();
static int LISTW;
static int DDWIDE;

void CreateDirW (geom)
char *geom;
{
	LISTW = dirWIDE - 100;
	DDWIDE = LISTW-65;
	listh = LINEHIGH * NLINES;

	dirW = CreateWindow (PROGNAME, geom, dirWIDE, dirHIGH, infofg, infobg);
	if (!dirW) FatalError ("couldn't create window!");

	CreateIcons ();
	ddirW = XCreateSimpleWindow (theDisp, dirW, 45, 30, DDWIDE,
		LINEHIGH, 2, infofg, pl);
	if (!ddirW) FatalError ("can't create path window");
	XSelectInput (theDisp, ddirW, ExposureMask | ButtonPressMask);

/*
	dnamW = XCreateSimpleWindow (theDisp, dirW, 10, dirHIGH-31,
		dirWIDE-86, LINEHIGH+4, 1, infofg, pl);
	if (!dnamW) FatalError ("can't create typing window");
	XSelectInput (theDisp, dnamW, ExposureMask);
*/

	LSCreate (&dList, dirW, 10, 42+LINEHIGH, LISTW, listh, NLINES, 
		dirnames, numdirnames, 
		infofg, infobg, RedrawDList, 1, 0);

	BTCreate (&dbut [S_BABOUT], dirW, dirWIDE-BUTTW-7, dList.y,
		BUTTW, BUTTH, "About", infofg, pl, hicol, locol);
	BTCreate (&dbut [S_BDITHER], dirW, dirWIDE-BUTTW-7, dList.y+22,
		BUTTW, BUTTH, "Dither", infofg, pl, hicol, locol);
	BTCreate (&dbut [S_BINFO], dirW, dirWIDE-BUTTW-7, dList.y+50,
		BUTTW, BUTTH, "Info", infofg, pl, hicol, locol);
	BTCreate (&dbut [S_BPLAY], dirW, dirWIDE-BUTTW-7, dList.y+72,
		BUTTW, BUTTH, "Play", infofg, pl, hicol, locol);
	BTCreate (&dbut [S_BDELETE], dirW, dirWIDE-BUTTW-7, dList.y+102,
		BUTTW, BUTTH, "Delete", infofg, pl, hicol, locol);
	BTCreate (&dbut [S_BQUIT], dirW, dirWIDE-BUTTW-7, dList.y+listh-BUTTH+1,
		BUTTW, BUTTH, "Quit", infofg, pl, hicol, locol);
	BTSetStyle (&dbut [S_BQUIT], 1);

	SetTypeName (DEFFILENAME);
	LoadCurrentDirectory ();
	XMapSubwindows (theDisp, dirW);
	XSelectInput (theDisp, dirW, ExposureMask | ButtonPressMask
		| KeyPressMask | StructureNotifyMask | LeaveWindowMask);
	XMapRaised (theDisp, dirW);
	XDefineCursor (theDisp, dirW, arrow);
}
 
void RedrawDirW (x, y, w, h)
int x, y, w, h;
{
	int i, ypos;
	char foo [30];
	char *ptr;
	XRectangle xr;

	xr.x = x;
	xr.y = y;
	xr.width = w;
	xr.height = h;
	XSetClipRectangles (theDisp, theGC, 0, 0, &xr, 1, Unsorted);

	ypos = 4 + ASCENT;
	XSetForeground (theDisp, theGC, infobg);
	XFillRectangle (theDisp, dirW, theGC, 10, ypos-ASCENT, dirWIDE, CHIGH);
	XSetForeground (theDisp, theGC, infofg);
	SetBold ();

	ptr = ShortCutPath (path, dirWIDE-25-StringWidth ("Path:"));
	XDrawString (theDisp, dirW, theGC, 10, ypos, "Path:", 5);
	XDrawString (theDisp, dirW, theGC, StringWidth ("Path:")+15,
		ypos, ptr, strlen (ptr));
	SetNormal ();
	XDrawLine (theDisp, dirW, theGC, 0, 23, dirWIDE, 23);

	if (dList.nstr==1) strcpy (foo, "1 file");
	else sprintf (foo, "%d files", dList.nstr);

	ypos = dList.y + dList.h + 5 + ASCENT;
	XSetForeground (theDisp, theGC, infobg);
	XFillRectangle (theDisp, dirW, theGC, 10, ypos-ASCENT, dirWIDE, CHIGH);
	XSetForeground (theDisp, theGC, infofg);
	SetBold ();
	XDrawString (theDisp, dirW, theGC, 10, ypos, foo, strlen (foo));
	SetNormal ();

	for (i=0; i<S_NBUTTS; i++) BTRedraw (&dbut [i]);
	XSetClipMask (theDisp, theGC, None);
}

void RedrawDDirW ()
{
	XSetForeground (theDisp, theGC, infofg);
	XSetBackground (theDisp, theGC, infobg);
	XClearWindow (theDisp, ddirW);
	XDrawString (theDisp, ddirW, theGC, 3, ASCENT + 1, 
		lastdir, strlen (lastdir));
}

void SetButtonX (bp, x)
BUTT *bp;
int x;
{
	bp->x = x;
}

void SetButtonY (bp, y)
BUTT *bp;
int y;
{
	bp->y = y;
}

void DestroyScroll (sc)
LIST *sc;
{
	XDestroyWindow (theDisp, sc->win);
}

void DestroyList (lp)
LIST *lp;
{
	XDestroyWindow (theDisp, lp->win);
	DestroyScroll (&lp->scrl);
}

void ResizeDirW (oldw, oldh)
int oldw, oldh;
{
	int i;

	LISTW = dirWIDE - 100;
	DDWIDE = LISTW-65;
	listh = LINEHIGH * NLINES;

	strcpy (typebuf, typename);
	XSetForeground (theDisp, theGC, infofg);
	XSetBackground (theDisp, theGC, infobg);
	XClearWindow (theDisp, dirW);
	XFlush (theDisp);
	for (i=0; i<S_NBUTTS; i++)
	{
		if (i == S_BQUIT) SetButtonY (&dbut [i], dList.y+listh-BUTTH+1);
		SetButtonX (&dbut [i], dirWIDE-BUTTW-7);
	}

	XDestroyWindow (theDisp, ddirW);
	ddirW = XCreateSimpleWindow (theDisp, dirW, 45, 30, DDWIDE,
		LINEHIGH, 2, infofg, pl);
	if (!ddirW) FatalError ("can't create path window");
	XSelectInput (theDisp, ddirW, ExposureMask | ButtonPressMask);

/*
	XDestroyWindow (theDisp, dnamW);
	dnamW = XCreateSimpleWindow (theDisp, dirW, 10, dirHIGH-31,
		dirWIDE-86, LINEHIGH+4, 1, infofg, infobg);
	if (!dnamW) FatalError ("can't create typing window");
	XSelectInput (theDisp, dnamW, ExposureMask);
*/

	DestroyList (&dList);
	LSCreate (&dList, dirW, 10, 42+LINEHIGH, LISTW, listh, NLINES, 
		dirnames, numdirnames, 
		infofg, infobg, RedrawDList, 1, 0);

	LoadCurrentDirectory ();
	XMapSubwindows (theDisp, dirW);
	SetTypeName (typebuf);
}

int ClickDirW (x, y)
int x, y;
{
	BUTT *bp;
	int bnum;

	for (bnum=0;bnum<S_NBUTTS;bnum++)
	{
		bp = &dbut [bnum];
		if (PTINRECT (x, y, bp->x, bp->y, bp->w, bp->h)) break;
	}
	if (bnum<S_NBUTTS) if (BTTrack (bp)) return (bnum);
	return -1;
}

void SelectDir (n)
int n;
{
	int pend;

	if (n == -1) SetDirFName (dList.str [dirsel]+1);
	else
	{
		if (dList.str [n][0]== C_DIR || dList.str [n][0]== C_LNK)
		{
			pend = strlen (path);
			strcat (path, dList.str [n]+1);
			if (chdir (path))
			{
				CreateErrW ("Unable to change to directory :", path);
				RedrawErrW ();
				ErrorEventLoop ();
				path [pend]= '\0';
				SetDirFName (DEFFILENAME);
			}
			else LoadCurrentDirectory ();
		}
		else
		{
			SetDirFName (dList.str [n]+1);
			if (dblclk) play_mpeg (dList.str [n]+1);
		}
	}
}

void TrackDDirW (x, y)
int x, y;
{
	Window menuW, rW, cW;
	int rx, ry, i, j, sel, lastsel;
	unsigned int mask;

	XSetForeground (theDisp, theGC, infofg);
	XSetBackground (theDisp, theGC, pl);

	menuW = XCreateSimpleWindow (theDisp, dirW, 45, 30, DDWIDE,
		ndirs*LINEHIGH, 2, infofg, pl);
	if (!menuW) FatalError ("can't create path window");

	XMapRaised (theDisp, menuW);

	for (i=ndirs-1, j=0;i>=0;i--, j++)
		XDrawString (theDisp, menuW, theGC, 3, j*LINEHIGH + ASCENT + 1, 
	dirs [i], dirs [i+1]-dirs [i]);

	XFlush (theDisp);
	XSetFunction (theDisp, theGC, GXinvert);
	XSetPlaneMask (theDisp, theGC, infofg ^ pl);
	lastsel = -1;
	sel = 0;

	while (XQueryPointer (theDisp, menuW, &rW, &cW, &rx, &ry, &x, &y, &mask))
	{
		if (! (mask & Button1Mask)) break;
		sel = y / LINEHIGH;
		if (sel>=ndirs) sel = ndirs-1;
		if (sel<0) sel = 0;
		if (sel != lastsel)
		{
			XFillRectangle (theDisp, menuW, theGC, 0, lastsel*LINEHIGH,
				DDWIDE, LINEHIGH);
			XFillRectangle (theDisp, menuW, theGC, 0, sel*LINEHIGH,
				DDWIDE, LINEHIGH);
			lastsel = sel;
		}
	}

	XSetFunction (theDisp, theGC, GXcopy);
	XSetPlaneMask (theDisp, theGC, AllPlanes);
	XDestroyWindow (theDisp, menuW);

	if (sel!=0)
	{
		*(dirs [(ndirs-1)-sel + 1]- 1) = '\0';
		if (path [0]== '\0') strcpy (path, "/");
		if (chdir (path))
		{
			CreateErrW ("Unable to change to directory :", path);
			RedrawErrW ();
			ErrorEventLoop ();
		}
		else LoadCurrentDirectory (); 
	}
}

static void RedrawDList ()
{
	LSRedraw (&dList);
}

int DirKey (c)
int c;
{
	int len;

	len = strlen (typename);
 
	if (c>' ' && c<'\177')
	{
		if (c=='/') return (-1);
		if (len >= MAXFNLEN-1) return (-1);
		typename [len]=c;
		typename [len+1]='\0';
	}
	else if (c=='\010' || c=='\177')
	{
		if (len==0) return (-1);
		typename [len-1]='\0';
	}
	else if (c=='\025' || c=='\013') typename [0]= '\0';
	else return (-1);

	SetTypeName (typename);
	return (0);
}

void RedrawDNamW ()
{
/*
	int width, len;

	len = strlen (typename);
	XSetForeground (theDisp, theGC, infofg);
	XDrawString (theDisp, dnamW, theGC, 3, ASCENT+3, typename, len);
	width = StringWidth (typename);
	XDrawLine (theDisp, dnamW, theGC, 3+width+1, 3, 3+width+1, 3+CHIGH);
*/
}

void SetDirFName (st)
char *st;
{
	strncpy (filename, st, MAXFNLEN-1);
	filename [MAXFNLEN-1]= '\0';
	BTSetActive (&dbut [S_BINFO], (strlen (filename)!=0)
		|| (strlen (typename)!=0));
	BTSetActive (&dbut [S_BPLAY], (strlen (filename)!=0)
		|| (strlen (typename)!=0));
	BTSetActive (&dbut [S_BDELETE], (strlen (filename)!=0)
		|| (strlen (typename)!=0));
}

void SetTypeName (st)
char *st;
{
	strncpy (typename, st, MAXFNLEN-1);
	typename [MAXFNLEN-1]= '\0';
/*
	XClearWindow (theDisp, dnamW);
	RedrawDNamW ();
*/
	BTSetActive (&dbut [S_BINFO], (strlen (filename)!=0)
		|| (strlen (typename)!=0));
	BTSetActive (&dbut [S_BPLAY], (strlen (filename)!=0)
		|| (strlen (typename)!=0));
	BTSetActive (&dbut [S_BDELETE], (strlen (filename)!=0)
		|| (strlen (typename)!=0));
}

/*
static int isdir (dir)
char *dir;
{
	struct stat s;
	struct stat *buf = &s;

#if defined (i386) || defined (SYSV)
	if (stat (dir, buf))
#else
	if (lstat (dir, buf))
#endif
	{
		CreateErrW ("Unable to access file :", dir);
		RedrawErrW ();
		ErrorEventLoop ();
		return (-1);
	}
	else if ((buf->st_mode & S_IFMT) == S_IFDIR) return (1);
	return (0);
}
*/

int dirchanged ()
{
	struct stat st;
	time_t curtime;

#if defined (i386) || defined (SYSV)
	if (stat (path, &st)==0)
#else
	if (lstat (path, &st)==0)
#endif
		curtime = st.st_mtime;
	else curtime = 1;
	if (curtime > dirtime)
	{
		dirtime = curtime;
		return (1);
	}
	else return (0);
}

