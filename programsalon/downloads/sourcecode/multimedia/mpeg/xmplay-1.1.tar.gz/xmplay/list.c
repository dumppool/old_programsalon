
/* --- C ---
************************************************************************
*
*	Filename    : list.c
*	Description : directory list functions
*	Part of     : XMPLAY - X11-directory-browser for XMPEG
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#include "xmplay.h"
#include "bitmaps.h"

#define DBLCLKTIME 500

#define INACTIVE(lptr, item) ((lptr)->filetypes && (lptr)->dirsonly && \
			      (item) >= 0 && (item) < (lptr)->nstr && \
			      (lptr)->str[(item)][0] != C_DIR && \
			      (lptr)->str[(item)][0] != C_LNK)

static Pixmap fifoPix, chrPix, dirPix, blkPix, lnkPix, sockPix, regPix;

static void drawSel ();

void CreateIcons ()
{
	grayStip = XCreatePixmapFromBitmapData (theDisp, dirW, gray50_bits, 
		gray50_width, gray50_height, 1, 0, 1);
	fifoPix = XCreatePixmapFromBitmapData (theDisp, dirW, i_fifo_bits, 
		i_fifo_width, i_fifo_height, 1, 0, 1);
	chrPix = XCreatePixmapFromBitmapData (theDisp, dirW, i_chr_bits, 
		i_chr_width, i_chr_height, 1, 0, 1);
	dirPix = XCreatePixmapFromBitmapData (theDisp, dirW, i_dir_bits, 
		i_dir_width, i_dir_height, 1, 0, 1);
	blkPix = XCreatePixmapFromBitmapData (theDisp, dirW, i_blk_bits, 
		i_blk_width, i_blk_height, 1, 0, 1);
	lnkPix = XCreatePixmapFromBitmapData (theDisp, dirW, i_lnk_bits, 
		i_lnk_width, i_lnk_height, 1, 0, 1);
	sockPix = XCreatePixmapFromBitmapData (theDisp, dirW, i_sock_bits, 
		i_sock_width, i_sock_height, 1, 0, 1);
	regPix = XCreatePixmapFromBitmapData (theDisp, dirW, i_reg_bits, 
		i_reg_width, i_reg_height, 1, 0, 1);
}
 
void LSCreate (lp, win, x, y, w, h, nlines, strlist, nstr, fg, bg, fptr, 
	typ, donly)
LIST *lp;
Window win;
int x, y, w, h, nlines, nstr, typ, donly;
unsigned long fg, bg;
char **strlist;
void (*fptr) ();
{
	lp->win = XCreateSimpleWindow (theDisp, win, x, y, w, h, 1, infofg, infobg);
	if (!lp->win) FatalError ("can't create list window!");

	lp->x = x;
	lp->y = y; 
	lp->w = w;
	lp->h = h;
	lp->fg = fg;
	lp->bg = bg;
	lp->str = strlist;
	lp->nstr = nstr;
	lp->selected = 0;
	lp->nlines = nlines;
	lp->filetypes= typ;
	lp->dirsonly = donly;

	XSelectInput (theDisp, lp->win, ExposureMask | ButtonPressMask
		| ButtonReleaseMask | Button1MotionMask | EnterWindowMask
		| LeaveWindowMask);

	SCCreate (&lp->scrl, win, x+w, y, 1, h, 0, nstr-nlines, curname, nlines-1, 
		fg, pl, fptr);
}

void LSNewData (lp, strlist, nstr)
LIST *lp;
char **strlist;
int nstr;
{
	lp->str = strlist;
	lp->nstr = nstr;
	lp->selected = -1;
	SCSetRange (&lp->scrl, 0, nstr - lp->nlines, 0, lp->nlines-1);
}

static void drawSel (lp, j)
LIST *lp;
int j;
{
	int i, inactive;
	unsigned long fg, bg;

	inactive = INACTIVE (lp, j);

	i = j - lp->scrl.val;
	if (i<0 || i>=lp->nlines) return;

	if (j == lp->selected && !inactive && j<lp->nstr) 
	{
		fg = lp->bg;
		bg = lp->fg;
	}
	else
	{
		fg = lp->fg;
		bg = lp->bg;
	}

	XSetForeground (theDisp, theGC, bg);
	XFillRectangle (theDisp, lp->win, theGC, 0, i*LINEHIGH, lp->w, LINEHIGH);

	if (j>=0 && j<lp->nstr)
	{
		XSetForeground (theDisp, theGC, fg);
		XSetBackground (theDisp, theGC, bg);

		if (!lp->filetypes) 
			XDrawString (theDisp, lp->win, theGC, 3, i*LINEHIGH + ASCENT + 1, 
				lp->str [j], strlen (lp->str [j]));
		else
		{
			int ypos = i*LINEHIGH + (LINEHIGH - i_fifo_height)/2;

			if (lp->str [j][0]== C_FIFO) 
				XCopyPlane (theDisp, fifoPix, lp->win, theGC, 0, 0, 
					i_fifo_width, i_fifo_height, 3, ypos, 1L);
			else if (lp->str [j][0]== C_CHR) 
				XCopyPlane (theDisp, chrPix, lp->win, theGC, 0, 0, 
					i_chr_width, i_chr_height, 3, ypos, 1L);
			else if (lp->str [j][0]== C_DIR) 
				XCopyPlane (theDisp, dirPix, lp->win, theGC, 0, 0, 
					i_dir_width, i_dir_height, 3, ypos, 1L);
			else if (lp->str [j][0]== C_BLK) 
				XCopyPlane (theDisp, blkPix, lp->win, theGC, 0, 0, 
					i_blk_width, i_blk_height, 3, ypos, 1L);
			else if (lp->str [j][0]== C_LNK) 
				XCopyPlane (theDisp, lnkPix, lp->win, theGC, 0, 0, 
					i_lnk_width, i_lnk_height, 3, ypos, 1L);
			else if (lp->str [j][0]== C_SOCK) 
				XCopyPlane (theDisp, sockPix, lp->win, theGC, 0, 0, 
					i_sock_width, i_sock_height, 3, ypos, 1L);
			else XCopyPlane (theDisp, regPix, lp->win, theGC, 0, 0, 
				i_reg_width, i_reg_height, 3, ypos, 1L);

			XDrawString (theDisp, lp->win, theGC, 3 + i_fifo_width + 3, 
				i*LINEHIGH + ASCENT + 1, 
				lp->str [j]+1, strlen (lp->str [j]+1));

#ifdef STIPPLE
			if (inactive)
			{ 
				XSetFillStyle (theDisp, theGC, FillStippled);
				XSetStipple (theDisp, theGC, grayStip);
				XSetForeground (theDisp, theGC, bg);
				XSetBackground (theDisp, theGC, fg);
				XFillRectangle (theDisp, lp->win, theGC, 3, i*LINEHIGH, lp->w,
					LINEHIGH);
				XSetForeground (theDisp, theGC, fg);
				XSetFillStyle (theDisp, theGC, FillSolid);
			}
#endif
		}
	}
}

void LSRedraw (lp)
LIST *lp;
{
	int i;

	for (i = lp->scrl.val;i < lp->scrl.val + lp->nlines;i++) drawSel (lp, i);
}

int LSClick (lp, ev)
LIST *lp;
XButtonEvent *ev;
{
/*
	Window rW, cW;
	int rx, ry, x;
*/
	int y, sel, oldsel;
	unsigned int mask;
	static Time lasttime=0;
	static int lastsel = -1;

/*
	x = ev->x;
*/
	y = ev->y;
	sel = lp->scrl.val + y/LINEHIGH;
	if (sel >= lp->nstr) sel = lp->selected;

	if (ev->time - lasttime < DBLCLKTIME && sel==lastsel 
		&& (lp->scrl.val + y/LINEHIGH) < lp->nstr
		&& !INACTIVE (lp, sel))
    {
		dblclk = 1;
		return (sel);
	}
	dblclk = 0;

	lasttime = ev->time;lastsel = sel;

	if (sel != lp->selected)
	{
		oldsel = lp->selected;
		lp->selected = sel;
		drawSel (lp, sel);
		drawSel (lp, oldsel);
		XFlush (theDisp);
	}

/*
	while (XQueryPointer (theDisp, lp->win, &rW, &cW, &rx, &ry, &x, &y, &mask))
	{
		if (! (mask & Button1Mask)) break;
		XDefineCursor (theDisp, dirW, target);
	}
	XDefineCursor (theDisp, dirW, arrow);
*/

	if (dList.str [sel][0] == C_DIR || dList.str [sel][0] == C_LNK)
	{
		dirsel = sel;
		return (-1);
	}
	else return (sel);
}

