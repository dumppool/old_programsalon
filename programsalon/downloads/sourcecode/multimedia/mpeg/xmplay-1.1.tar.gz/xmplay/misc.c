
/* --- C ---
************************************************************************
*
*	Filename    : misc.c
*	Description : other X11 functions
*	Part of     : XMPLAY - X11-directory-browser for XMPEG
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#define NEEDSTIME
#include "xmplay.h"

static int timerdone;

Window CreateWindow (name, geom, w, h, fg, bg)
char *name, *geom;
unsigned int w, h;
unsigned long fg, bg;
{
	Window win;
	XSetWindowAttributes xswa;
	unsigned int xswamask;
	XWMHints xwmh;
	XSizeHints hints;
	int i, x, y;

	x = y = 1;
	i = XParseGeometry (geom, &x, &y, &xpa, &xpb);
	if (i&XValue || i&YValue) hints.flags = USPosition;
	else hints.flags = PPosition;

	hints.flags |= USSize;

	if (i&XValue && i&XNegative) x = dispWIDE - w - abs (x);
	if (i&YValue && i&YNegative) y = dispHIGH - h - abs (y);

	hints.x = x;
	hints.y = y;
	hints.width = w;
	hints.height = h;
	hints.min_width = DIRWIDE;
	hints.min_height = DIRHIGH;
	hints.max_width = BIGWIDE;
	hints.max_height = BIGHIGH;
	hints.flags |= PMaxSize | PMinSize;

	xswa.background_pixel = bg;
	xswa.border_pixel = fg;
	xswamask = CWBackPixel | CWBorderPixel;

	win = XCreateWindow (theDisp, rootW, x, y, w, h, 
		bwidth, CopyFromParent, CopyFromParent, 
		CopyFromParent, xswamask, &xswa);
	if (!win) return (win);

	XSetStandardProperties (theDisp, win, name, name, None, NULL, 0, &hints);

	xwmh.input = True;
	xwmh.flags = InputHint;
	if (icongeom)
	{
		i = XParseGeometry (icongeom, &x, &y, &xpa, &xpb);
		if ((i&XValue && i&XNegative) ||
			(i&YValue && i&YNegative))
				FatalError ("can't parse negativ icon position");
		if (i&XValue) xwmh.icon_x = x;
		if (i&YValue) xwmh.icon_y = y;
		xwmh.flags |= IconPositionHint;
	}
	if (iconic)
	{
		xwmh.flags |= StateHint;
		xwmh.initial_state = IconicState;
	}

	XSetWMHints (theDisp, win, &xwmh);

	return (win);
}

void SetBold ()
{
	XSetFont (theDisp, theGC, bfont);
	cfinfo = bfinfo;
}

void SetNormal ()
{
	XSetFont (theDisp, theGC, mfont);
	cfinfo = mfinfo;
}

int StringWidth (str)
char *str;
{
	return (XTextWidth (cfinfo, str, strlen (str)));
}
 
void ExposureWin (exp_event)
XExposeEvent *exp_event;
{
	if (exp_event->count>0 && exp_event->window != dirW) return;
	else if (exp_event->window == dirW) 
		RedrawDirW (exp_event->x, exp_event->y,
			exp_event->width, exp_event->height);
	else if (exp_event->window == dList.win) LSRedraw (&dList);
	else if (exp_event->window == dList.scrl.win) SCRedraw (&dList.scrl);
	else if (exp_event->window == ddirW) RedrawDDirW ();
/*
	else if (exp_event->window == dnamW) RedrawDNamW ();
*/
}

void FatalError (identifier)
char *identifier;
{
	fprintf (stderr, "%s: %s\n", cmd, identifier);
	Quit (-1);
}

static void FreeMostResources ()
{
	if (!theDisp) return;
	if (dirW) XDestroyWindow (theDisp, dirW);
	XFlush (theDisp);
}

void Quit (i)
int i;
{ 
	FreeMostResources ();
	exit (i);
}

static void onalarm ()
{
	timerdone=1;
}

void Timer (n)
int n;
{
#ifdef NOTIMER
	int i, j;
#endif

	if (!n) return;

#ifdef SCO
	nap (n);
	return;
#else

#ifdef USLEEP
	usleep (n);
	return;
#else

#ifdef NOTIMER
	for (i=0; i<n;i++) for (j=0; j<500;j++);
	return;
#else
	{
		long usec;
		struct itimerval it;

		usec = (long) n * 1000;
 
		memset (&it, 0, sizeof (it));
		if (usec>=1000000L)
		{
			it.it_value.tv_sec = usec / 1000000L;
			usec %= 1000000L;
		}
	
		it.it_value.tv_usec = usec;
		timerdone=0;
		signal (SIGALRM, onalarm);
		setitimer (ITIMER_REAL, &it, (struct itimerval *)0);
		while (1)
		{
			HOLD_SIG;
			if (timerdone) break;
			else PAUSE_SIG;
		}
		RELEASE_SIG;
		signal (SIGALRM, SIG_DFL);
	}
#endif
#endif
#endif
}

void DimRect (win, x, y, w, h, bg)
Window win;
int x,y,w,h;
u_long bg;
{
	XSetFillStyle (theDisp, theGC, FillStippled);
	XSetStipple (theDisp, theGC, grayStip);
	XSetForeground (theDisp, theGC, bg);
	XFillRectangle (theDisp, win, theGC, x, y, w, h);
	XSetFillStyle (theDisp, theGC, FillSolid);
}

void Draw3dRect (win, x, y, w, h, inout, bwidth, hi, lo, bg)
Window win;
int x, y, w, h, inout, bwidth;
unsigned long hi, lo, bg;
{
	int i;

	if (ctrlColor)
	{
		if (inout == R3D_OUT) XSetForeground (theDisp, theGC, hi);
		else XSetForeground(theDisp, theGC, lo);

		for (i=0; i<bwidth; i++)
		{
			XDrawLine (theDisp, win, theGC, x+i, y+h-i, x+i, y+i);
			XDrawLine (theDisp, win, theGC, x+i, y+i, x+w-i, y+i);
		}
    
		if (inout == R3D_OUT) XSetForeground (theDisp, theGC, lo);
		else XSetForeground (theDisp, theGC, hi);

		for (i=0; i<bwidth; i++)
		{
			XDrawLine (theDisp, win, theGC, x+i+1, y+h-i, x+w-i, y+h-i);
			XDrawLine (theDisp, win, theGC, x+w-i, y+h-i, x+w-i, y+i+1);
		}
		XSetForeground (theDisp, theGC, bg);

		for (i=0; i<bwidth; i++)
		{
			XDrawPoint (theDisp, win, theGC, x+i, y+h-i);
			XDrawPoint (theDisp, win, theGC, x+w-i, y+i);
		}
	}
}

Visual *FindFullColorVisual (dpy, depth)
Display *dpy;
int *depth;
{
	XVisualInfo	vinfo;
	XVisualInfo	*vinfo_ret;
	int			numitems, maxdepth;
  
	vinfo.class = TrueColor;
	vinfo_ret = XGetVisualInfo (dpy, VisualClassMask, &vinfo, &numitems);
  
	if (numitems == 0) return NULL;

	maxdepth = 0;
	while (numitems > 0)
	{
		if (vinfo_ret [numitems-1].depth > maxdepth)
			maxdepth = vinfo_ret[numitems-1 ].depth;
		numitems--;
	}
	XFree (vinfo_ret);

	if (maxdepth < 24) return NULL;

	if (XMatchVisualInfo (dpy, DefaultScreen (dpy), maxdepth, 
		TrueColor, &vinfo))
	{
		*depth = maxdepth;
		return vinfo.visual;
	}
	return NULL;
}

int DetectDisplayType (dpy)
Display *dpy;
{
	int scr = XDefaultScreen (dpy);
	int depth;
	XVisualInfo vinfo;

	if (FindFullColorVisual (dpy, &depth) != NULL) return (FULLCOLOR);
	if (!XMatchVisualInfo (dpy, scr, 8, PseudoColor, &vinfo))
	{
		if (!XMatchVisualInfo (dpy, scr, 8, GrayScale, &vinfo))
			return (MONO);
		else return (GRAYSCALE);
	}
	return COLOR;
}

