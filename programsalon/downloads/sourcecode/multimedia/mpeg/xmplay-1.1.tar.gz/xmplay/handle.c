
/* --- C ---
************************************************************************
*
*	Filename    : handle.c
*	Description : directory and calling functions
*	Part of     : XMPLAY - X11-directory-browser for XMPEG
*
*	Version     : 1.1
*	Date        : Tue Apr  4 14:06:10 MET DST 1995
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#define NEEDSDIR
#define NEEDDIALOG
#include "xmplay.h"
#ifndef F_OK
#include <sys/unistd.h>
#endif
#include "mpeginfo.h"

char *dirnames [MAXNAMES];
int numdirnames = 0, ndirs = 0;
char *dirs [MAXDEEP];
char *lastdir;
extern char typename [MAXFNLEN];
extern time_t dirtime;
static int needfirst = 1;
static char firstpath [MAXPATHLEN];

static int dnamcmp ();

void LoadCurrentDirectory ()
{
	DIR *dirp;
#ifdef DIRENT
	struct dirent *dp;
#else
	struct direct *dp;
#endif
	int i, ftype;
	struct stat st;
	char *dbeg, *dend;

	XDefineCursor (theDisp, dirW, target);
	XFlush (theDisp);
	for (i=0;i<numdirnames;i++) free (dirnames [i]);
	numdirnames = 0;

#ifdef SYSV
	getcwd (path, sizeof (path));
#else
	getwd (path);
#endif
	if (path [strlen (path)-1]!= '/') strcat (path, "/");
	if (needfirst)
	{
		strcpy (firstpath, path);
		needfirst = 0;
	}

	dbeg = dend = path;
	for (i=0;i<MAXDEEP && dend;i++)
	{
		dend = strchr (dbeg, '/');
		dirs [i]= dbeg;
		dbeg = dend+1;
	}
	ndirs = i-1;

	lastdir = dirs [ndirs-1];
	RedrawDDirW ();

	dirp = opendir (".");
	if (!dirp)
	{
		XDefineCursor (theDisp, dirW, arrow);
		CreateErrW ("Unable to open current directory !", "");
		RedrawErrW ();
		ErrorEventLoop ();
		return;
	}

	i=0;
	while ((dp = readdir (dirp)) != NULL)
	{
		if (strcmp (dp->d_name, ".")==0 || strcmp (dp->d_name, "..")==0);
		else
		{
#ifdef DIRENT
#ifdef i386
			dirnames [i]= (char *) malloc (dp->d_reclen + 2);
#else
			dirnames [i]= (char *) malloc (strlen (dp->d_name) + 3);
#endif
#else
			dirnames [i]= (char *) malloc (dp->d_namlen + 2);
#endif
			if (!dirnames [i])
				FatalError ("malloc error while reading directory");
			strcpy (dirnames [i]+1, dp->d_name);

			dirnames [i][0]= C_REG;

#if defined (i386) || defined (SYSV)
			if (stat (dirnames [i]+1, &st)==0)
#else
			if (lstat (dirnames [i]+1, &st)==0)
#endif
			{
				ftype = st.st_mode & S_IFMT;
				if (ftype == S_IFDIR) dirnames [i][0]= C_DIR;
				else if (ftype == S_IFCHR) dirnames [i][0]= C_CHR;
				else if (ftype == S_IFBLK) dirnames [i][0]= C_BLK;
#ifdef S_IFIFO
				else if (ftype == S_IFIFO) dirnames [i][0]= C_FIFO;
#endif
#ifdef S_IFLNK
				else if (ftype == S_IFLNK) dirnames [i][0]= C_LNK;
#endif
#ifdef S_IFSOCK
				else if (ftype == S_IFSOCK) dirnames [i][0]= C_SOCK;
#endif
			}
			else dirnames [i][0]= C_REG;
			i++;
			if (i == MAXNAMES)
			{
				fprintf (stderr, "\n%s: Too much directory entries.\n",
					PROGNAME);
				fprintf (stderr, "Set MAXNAMES higher and recompile.\n");
				break;
			}
		}
	}

	closedir (dirp);

	numdirnames = i;
#if defined (i386) || defined (SYSV)
	if (stat (path, &st)==0)
#else
	if (lstat (path, &st)==0)
#endif
		dirtime = st.st_mtime;
	else dirtime = 0;

	qsort ((char *) dirnames, numdirnames, sizeof (char *), dnamcmp);
	LSNewData (&dList, dirnames, numdirnames);
	RedrawDirW (0, 0, dirWIDE, dirHIGH);
	SetDirFName (DEFFILENAME);
	XDefineCursor (theDisp, dirW, arrow);
}

static int dnamcmp (s1, s2)
char **s1, **s2;
{
	if ((**s1 == C_DIR && **s2 == C_DIR) || (**s1 != C_DIR && **s2 != C_DIR))
		return (strcmp ((*s1)+1, (*s2)+1));

	else if (**s1==C_DIR) return -1;
	else return 1;
}

void DoAbout ()
{
	CreateAboutW ();
	RedrawAboutW ();
	AboutEventLoop ();
}

extern char *ditherType [];

void DoDither ()
{
	char *tmp;

	CreateDitherW ();
	RedrawDitherW ();
	if (DitherEventLoop () == S_SOK)
	{
		tmp = ditherType [RBWhich (ditherRB)];
		if ((!strcmp (tmp, ditherType [2])) &&
			(DetectDisplayType (theDisp) != FULLCOLOR))
		{
			CreateErrW ("Unable to detect full-color-display.", "");
			RedrawErrW ();
			ErrorEventLoop ();
			return;
		}
		if (((strcmp (tmp, ditherType [3])) &&
			(strcmp (tmp, ditherType [4]))) &&
			(DetectDisplayType (theDisp) == MONO))
		{
			CreateErrW ("Unable to detect color-display.", "");
			RedrawErrW ();
			ErrorEventLoop ();
			return;
		}
		dither = ditherType [RBWhich (ditherRB)];
	}
}

void DoDelete ()
{
	CreateQueW ("Do you really want to delete ?", filename);
	RedrawQueW ();
	if (QuestionEventLoop () == S_SOK)
	{
		unlink (filename);
		LoadCurrentDirectory ();
	}
}

void play_mpeg (name)
char *name;
{
	int cpid;
	MPEGINFO mpeginfo;

	if (mpeg_info (&mpeginfo, name) != PARSE_OK)
	{
		CreateErrW (filename, "does not look like a MPEG-I-videofile !");
		RedrawErrW ();
		ErrorEventLoop ();
		return;
	}

	cpid = fork ();
	switch (cpid)
	{
		case -1:
			break;
		case 0:
			if (display)
			{
				if (dither)
				{
					if (loop)
						execlp (player, player, "-display", display,
							"-dither", dither, "-loop", name, (char *)0);
					else
						execlp (player, player, "-display", display,
							"-dither", dither, name, (char *)0);
				}
				else
				{
					if (loop)
						execlp (player, player, "-display", display,
							"-loop", name, (char *)0);
					else
						execlp (player, player, "-display", display,
							name, (char *)0);
				}
			}
			else
			{
				if (dither)
				{
					if (loop)
						execlp (player, player,
							"-dither", dither, "-loop", name, (char *)0);
					else
						execlp (player, player,
							"-dither", dither, name, (char *)0);
				}
				else
				{
					if (loop)
						execlp (player, player, "-loop", name, (char *)0);
					else
						execlp (player, player, name, (char *)0);
				}
			}
			break;
		default:
			/* while (wait (&status) != cpid); */
			XDefineCursor (theDisp, dirW, target);
			XFlush (theDisp);
			XDefineCursor (theDisp, dirW, arrow);
			break;
	}
}

