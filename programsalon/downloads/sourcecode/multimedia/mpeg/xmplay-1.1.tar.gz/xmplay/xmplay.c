
/* --- C ---
************************************************************************
*
*	Filename    : xmplay.c
*	Description : main program and event loop
*	Part of     : XMPLAY - X11-directory-browser for XMPEG
*
*	Version     : 1.1
*	Date        : Tue Apr  4 14:06:10 MET DST 1995
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#define MAIN
#include "xmplay.h"
#include <X11/Xatom.h>

#define QUIT -1
#define FONT "-*-helvetica-medium-r-*-*-12-*"
#define BFONT "-*-helvetica-bold-r-*-*-12-*"

/*	#define FONT "-*-courier-medium-r-*-*-12-*"
	#define BFONT "-*-courier-bold-r-*-*-12-*"	*/

/*	#define FONT "8x13"
	#define BFONT "8x13bold"	*/

char *ditherType [] =
{
	"2x2",
	"gray",
	"color",
	"mono",
	"threshold",
	"hybrid",
	"hybrid2",
	"ordered",
	"ordered2",
	"mbordered",
	"fs2",
	"fs4",
	"fs2fast"
};

static unsigned long rootbg, rootfg;
static Atom __SWM_VROOT = None;
static char *startcwd;
static char str [128];
static char *def_str;
static int def_int;
static char newgeom[20];

static void Syntax ();
static int EventLoop ();
static int rd_int ();
static int rd_str ();
static int rd_flag ();

int main (argc, argv)
int argc;
char *argv [];
{
	int i, x, y, res;
	char *rootfgstr, *rootbgstr;

	XColor ecdef;
	Window rootReturn, parentReturn, *children;
	unsigned int numChildren;

	display = whitestr = blackstr = NULL;
	maingeom = "+50+400";
	fgstr = "black";
	bgstr = "LemonChiffon";
	plstr = "gray70";
	histr = "gray90";
	lostr = "gray30";
	player = "xmpeg";
	dither = "ordered2";

	rootfgstr = rootbgstr = NULL;
	cmd = rindex (argv [0], '/');
	if (!cmd) cmd = argv [0];
	else cmd++;

	ncols = -1;
	mono = 0;
	ctrlColor = 0;
	bwidth = 2;

	dirW = ddirW = dnamW = aboutW = ditherW = diaW = infW = (Window) NULL;
	icongeom = NULL;
	iconic = dblclk = loop = 0;
	startcwd = NULL;

	curname = 0;

	for (i=1;i<argc-1;i++)
	{
		if (!strncmp (argv [i], "-dis", 4))
		{
			display = argv [++i];
			break;
		}
	}

	if ((theDisp=XOpenDisplay (display)) == NULL)
	{
		fprintf (stderr, "%s: Can't open display\n", argv [0]);
		Quit (-1);
	}

	if (rd_str ("geometry")) maingeom = def_str;
	if (rd_str ("icongeom")) icongeom = def_str;
	if (rd_str ("background")) bgstr = def_str;
	if (rd_str ("foreground")) fgstr = def_str;
	if (rd_str ("plane")) plstr = def_str;
	if (rd_str ("path")) startcwd = def_str;
	if (rd_str ("player")) player = def_str;
	if (rd_int ("borderWidth")) bwidth = def_int;
	if (rd_str ("highlight")) histr = def_str;
	if (rd_str ("lowlight")) lostr = def_str;
	if (rd_str ("dither")) dither = def_str;
	iconic = rd_flag ("iconic");
	loop = rd_flag ("loop");
 
	numnames = 0;
	for (i=1;i<argc;i++)
	{
		if (argv [i][0]!= '-') Syntax ();
		else if (!strcmp (argv [i], "-h")) Syntax ();
		else if (!strncmp (argv [i], "-bg", 3))
				{ if (++i<argc) bgstr = argv [i]; }
		else if (!strncmp (argv [i], "-bw", 3))
				{ if (++i<argc) bwidth=atoi (argv [i]); }
		else if (!strncmp (argv [i], "-dis", 4))
				{ if (++i<argc) display = argv [i]; }
		else if (!strncmp (argv [i], "-fg", 3))
				{ if (++i<argc) fgstr = argv [i]; }
		else if (!strncmp (argv [i], "-plan", 5))
				{ if (++i<argc) plstr = argv [i]; }
		else if (!strncmp (argv [i], "-ge", 3))
				{ if (++i<argc) maingeom = argv [i]; }
		else if (!strncmp (argv [i], "-pa", 3))
				{ if (++i<argc) startcwd = argv [i]; }
		else if (!strncmp (argv [i], "-play", 5))
				{ if (++i<argc) player = argv [i]; }
		else if (!strncmp (argv [i], "-icong", 6))
				{ if (++i<argc) icongeom = argv [i]; }
		else if (!strncmp (argv [i], "-hi", 3))
				{ if (++i<argc) histr = argv [i]; }
		else if (!strncmp (argv [i], "-low", 4))
				{ if (++i<argc) lostr = argv [i]; }
		else if (!strncmp (argv [i], "-dit", 4))
				{ if (++i<argc) dither = argv [i]; }
		else if (!strncmp (argv [i], "-iconi", 6)) iconic = 1;
		else if (!strncmp (argv [i], "-loo", 4)) loop = 1;
		else Syntax ();
	}
	if (dither)	
	{
		res = 0;
		for (i=0; i < DITHERMAX; i++)
		{
			res += !(strcmp (dither, ditherType [i]));
		}
		if (!res) Syntax ();
	}
 
	if (startcwd)
		if (chdir (startcwd) == -1)
			fprintf (stderr,
				"%s: Can't change to directory %s. Using current.\n",
				argv [0], startcwd);

	theScreen = DefaultScreen (theDisp);
	theCmap = DefaultColormap (theDisp, theScreen);
	rootW = RootWindow (theDisp, theScreen);
	theGC = DefaultGC (theDisp, theScreen);
	theVisual = DefaultVisual (theDisp, theScreen);
	ncells = DisplayCells (theDisp, theScreen);
	dispWIDE = DisplayWidth (theDisp, theScreen);
	dispHIGH = DisplayHeight (theDisp, theScreen);
	dispDEEP = DisplayPlanes (theDisp, theScreen);

	__SWM_VROOT = XInternAtom (theDisp, "__SWM_VROOT", False);
	XQueryTree (theDisp, rootW, &rootReturn, &parentReturn, &children, 
		&numChildren);
	for (i = 0;i < numChildren;i++)
	{
		Atom actual_type;
		int actual_format;
		unsigned long nitems, bytesafter;
		Window *newRoot = NULL;
		XWindowAttributes xwa;

		if (XGetWindowProperty (theDisp, children [i], __SWM_VROOT, 0, 1, 
			False, XA_WINDOW, &actual_type, &actual_format, &nitems, 
			&bytesafter, (unsigned char **) &newRoot) == Success && newRoot)
		{
			rootW = *newRoot;
			XGetWindowAttributes (theDisp, rootW, &xwa);
			dispWIDE = xwa.width;dispHIGH = xwa.height;
			dispDEEP = xwa.depth;
			break;
		}
	}

	arrow = XCreateFontCursor (theDisp, XC_top_left_arrow);
	target = XCreateFontCursor (theDisp, XC_leftbutton);
	hand = XCreateFontCursor (theDisp, XC_hand1);

	white = WhitePixel (theDisp, theScreen);
	black = BlackPixel (theDisp, theScreen);
	if (whitestr && XParseColor (theDisp, theCmap, whitestr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) white = ecdef.pixel;
	if (blackstr && XParseColor (theDisp, theCmap, blackstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) black = ecdef.pixel;

	fg = black;
	bg = white;
	pl = white;
	if (fgstr && XParseColor (theDisp, theCmap, fgstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) fg = ecdef.pixel;
	if (bgstr && XParseColor (theDisp, theCmap, bgstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) bg = ecdef.pixel;
	if (plstr && XParseColor (theDisp, theCmap, plstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) pl = ecdef.pixel;

	rootfg = white;
	rootbg = black;
	if (rootfgstr && XParseColor (theDisp, theCmap, rootfgstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) rootfg = ecdef.pixel;
	if (rootbgstr && XParseColor (theDisp, theCmap, rootbgstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) rootbg = ecdef.pixel;

	i = 0;
	if (dispDEEP > 1)
	{
		if (histr && XParseColor(theDisp, theCmap, histr, &ecdef) &&
			XAllocColor(theDisp, theCmap, &ecdef))
		{
			hicol = ecdef.pixel;
			i |= 1;
		}
		if (lostr && XParseColor (theDisp, theCmap, lostr, &ecdef) &&
			XAllocColor (theDisp, theCmap, &ecdef))
		{
			locol = ecdef.pixel;
			i |= 2;
		}
	}

	if (i == 0) ctrlColor = 0;
	else if (i == 3) ctrlColor = 1;
	else ctrlColor = 0;

	XSetForeground (theDisp, theGC, fg);
	XSetBackground (theDisp, theGC, bg);

	infofg = fg;
	infobg = bg;

	if (!mono)
	{
		if (theVisual->class == StaticGray || theVisual->class == GrayScale)
		mono = 1;
	}
 
	if ((mfinfo = XLoadQueryFont (theDisp, FONT))==NULL ||
		(bfinfo = XLoadQueryFont (theDisp, BFONT))==NULL)
	{
		sprintf (str,
			"couldn't open the following fonts:\n\t %s \n\t %s", 
			FONT, BFONT);
		FatalError (str);
	}
	mfont=mfinfo->fid;
	bfont=bfinfo->fid;
	SetNormal ();
 
	if (ncols == -1)
	{
		if (dispDEEP>1) ncols = 1<<dispDEEP;
		else ncols = 0;
	}
	else if (ncols>256) ncols = 256;

	i = XParseGeometry (maingeom, &x, &y, &xpa, &xpb);
	if (xpa < DIRWIDE) xpa = DIRWIDE;
	if (xpa > BIGWIDE) xpa = BIGWIDE;
	if (xpb < DIRHIGH) xpb = DIRHIGH;
	if (xpb > BIGHIGH) xpb = BIGHIGH;
	dirWIDE = xpa;
	dirHIGH = xpb;
	NLINES = (dirHIGH-77)/LINEHIGH;
	CreateDirW (maingeom);

	while ((i=EventLoop ()) != QUIT);
	Quit (0);
	return (0);
}

static void Syntax ()
{
	fprintf (stderr, "usage: %s\n", cmd);
	fprintf (stderr,
"   [-bg background] [-bw width] [-display disp] [-fg foreground]\n");
	fprintf (stderr,
"   [-geometry geom] [-h] [-hi highlight] [-icongeom geom] [-iconic] [-loop]\n");
	fprintf (stderr,
"   [-path directory] [-plane plane] [-player MPEG-player [-lo lowlight]\n");
	fprintf (stderr,
"   [-dither {ordered|ordered2|mbordered|fs2|fs4|fs2fast|hybrid|hybrid2|\n");
	fprintf (stderr,
"             2x2|gray|color|mono|threshold}]\n");

	Quit (-1);
}

static int EventLoop ()
{
	XEvent event;
	int retval, done;

	done = retval = 0;
	while (!done)
	{
#ifndef SLOW
		Timer (15);
#endif
		if (XPending (theDisp)>0)
		{
			XNextEvent (theDisp, &event);
			switch (event.type)
			{
				case Expose:
					{
						XExposeEvent *exp_event = (XExposeEvent *) &event;

						ExposureWin (exp_event);
					}
					break;
				case ConfigureNotify:
					{
						int oldw, oldh;

						sprintf (newgeom, "+%d+%d",
							event.xconfigure.x,
							event.xconfigure.y);
						dirGEOM = newgeom;
						if ((event.xconfigure.width != dirWIDE) ||
							(event.xconfigure.height != dirHIGH))
						{
							oldw = dirWIDE;
							oldh = dirHIGH;
							dirWIDE = event.xconfigure.width;
							dirHIGH = event.xconfigure.height;
							NLINES = (dirHIGH-77)/LINEHIGH;
							ResizeDirW (oldw, oldh);
						}
					}
					break;
				case ButtonPress:
					{
					XButtonEvent *but_event = (XButtonEvent *) &event;
					int i;

					switch (but_event->button)
					{
						case Button1: 
							if (but_event->window == dirW)
							{
								i=ClickDirW (but_event->x, but_event->y);
								if (i==S_BABOUT) DoAbout ();
								else if (i==S_BDITHER) DoDither ();
								else if (i==S_BINFO) DoInfo ();
								else if (i==S_BPLAY)
								{
									if (filename)
										if (strlen (filename) > 1)
											play_mpeg (filename);
								}
								else if (i==S_BDELETE) DoDelete ();
								else if (i==S_BQUIT)
								{
									retval = QUIT;
									done=1;
								}
							}
							else if (but_event->window == dList.win)
							{
								i=LSClick (&dList, but_event);
								SelectDir (i);
							}
							else if (but_event->window == dList.scrl.win) 
								SCTrack (&dList.scrl, but_event->x,
									but_event->y);
							else if (but_event->window == ddirW) 
								TrackDDirW (but_event->x, but_event->y);
							break;
						default:
							break;
					}
				}
				break;
			case EnterNotify :
				if (dirchanged ()) LoadCurrentDirectory ();
				break;
			case KeyPress:
				{
					XKeyEvent *key_event = (XKeyEvent *) &event;
					char buf [128];
					KeySym ks;
					XComposeStatus status;
					int stlen;
 
					stlen = XLookupString (key_event, buf, 128, &ks, &status);
					if (!stlen) break;
					if (key_event->window == dirW)
						if (DirKey (buf [0])) XBell (theDisp, 0);
				}
				break;
			default:
				break;
			}
		}
	}
	return (retval);
}

static int rd_int (name)
char *name;
{
	if (def_str = XGetDefault (theDisp, PROGNAME, name))
	{
		if (sscanf (def_str, "%ld", &def_int) == 1) return 1;
		else
		{
			fprintf (stderr,
				"%s: couldn't read integer value for %s resource\n", 
				cmd, name);
			return 0;
		}
	}
	else return 0;
}

static int rd_str (name)
char *name;
{
	if (def_str = XGetDefault (theDisp, PROGNAME, name)) return 1;
	else return 0;
}

static int rd_flag (name)
char *name;
{
	if (def_str = XGetDefault (theDisp, PROGNAME, name))
	{
		def_int = (strcmp (def_str, "on")==0) || 
			(strcmp (def_str, "1")==0) ||
			(strcmp (def_str, "true")==0) ||
			(strcmp (def_str, "yes")==0);
		return 1;
	}
	else return 0;
}

