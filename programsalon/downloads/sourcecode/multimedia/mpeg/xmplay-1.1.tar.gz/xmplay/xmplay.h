
/* --- C ---
************************************************************************
*
*	Filename    : xmplay.h
*	Description : global defines
*	Part of     : XMPLAY - X11-directory-browser for XMPEG
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#define REVDATE   "Rev: 01/01/94"

#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
extern int   errno;
extern char *sys_errlist[];

/* neither IBM AOS 4.3, Convex, nor BSD 4.3 on VAX have <malloc.h> */
#if !defined(ibm032) && !defined(__convexc__) && \
    !(defined(vax) && !defined(ultrix))
#if defined(hp300) || defined(hp800)
#include <sys/malloc.h>
#else
#include <malloc.h>
#endif
#endif

#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include <X11/keysym.h>

#if defined(NEEDSTIME) || defined(NEEDSDIR)
#include <sys/types.h>
#endif

#ifdef NEEDSTIME
#include <sys/time.h>
#include <signal.h>
#if defined(SCO) && !defined(NOTIMER)
#include <sys/itimer.h>
#endif
#ifndef  sigmask
#define  sigmask(m)      (1 << ((m)-1))
#endif
#endif

#ifdef NEEDSDIR
#ifdef SCO
#include <sys/ndir.h>
#define lstat stat
#else
#ifndef SYSV
#include <sys/dir.h>
#endif
#endif
#include <sys/param.h>
#include <sys/stat.h>
#ifdef DIRENT
#include <dirent.h>
#endif
#include <pwd.h>
#endif

#ifdef SYSV
#define HOLD_SIG         sighold(SIGALRM)
#define RELEASE_SIG      sigrelse(SIGALRM)
#define PAUSE_SIG        sigpause(SIGALRM)
#else
#define HOLD_SIG         sigblock(sigmask(SIGALRM))
#define RELEASE_SIG      sigblock(0)
#define PAUSE_SIG        sigpause(0)
#endif

#ifdef i386
#undef  HOLD_SIG
#define HOLD_SIG
#undef  RELEASE_SIG
#define RELEASE_SIG
#undef  PAUSE_SIG
#define PAUSE_SIG
#endif

#ifndef MAXPATHLEN
#include <sys/param.h>
#ifndef MAXPATHLEN
#define MAXPATHLEN    512
#endif
#endif

#define PROGNAME	"xmplay"
#define DEFDIRGEOM	"+300+200"

#define DIRWIDE		300
#define DIRHIGH		275
#define BIGWIDE		700
#define BIGHIGH		700

#define MAXNAMES	1000
#define MAXDEEP		30
#define MAXFNLEN	40
#define DEFFILENAME	""

#define S_NBUTTS	6
#define S_BABOUT	0
#define S_BDITHER	1
#define S_BINFO		2
#define S_BPLAY		3
#define S_BDELETE	4
#define S_BQUIT		5

#define S_SBUTTS	3
#define S_SOK		0
#define S_SCANCEL	1
#define S_SNO		2

#define C_FIFO		'f'
#define C_CHR		'c'
#define C_DIR		'd'
#define C_BLK		'b'
#define C_LNK		'l'
#define C_SOCK		's'
#define C_REG		' '

#define MINLINES	9
#define BUTTW		60
#define BUTTH		19

#define SPACING		3
#define ASCENT   (cfinfo->ascent)
#define DESCENT  (cfinfo->descent)
#define CHIGH    (ASCENT + DESCENT)
#define LINEHIGH (CHIGH + SPACING)

#define STDINSTR "<stdin>"
#define DITHERMAX	13

#ifndef MAIN
#define WHERE extern
#else
#define WHERE
#endif

typedef struct
{
	Window win;
	int len;
	int vert;
	int active;
	int min, max;
	int val;
	int page;
	int tpos;
	int tmin, tmax;
	int tsize;
	unsigned long fg, bg;
	void (*drawobj)();
	int uplit, dnlit;
} SCRL;

typedef struct
{
	Window win;
	int x, y, w, h;
	int lit;
	int active;
	int toggle;
	u_long fg, bg, hi, lo;
	char *str;
	Pixmap pix;
	int pw, ph;
	int style;
	int fwidth;
} BUTT;

typedef struct rbutt
{
	Window win;
	int x,y;
	char *str;
	int selected;
	int active;
	struct rbutt *next;
	u_long fg, bg, hi, lo;
} RBUTT;

typedef struct cbutt
{
	Window win;
	int x, y;
	char *str;
	int val;
	int active;
	u_long fg, bg, hi, lo;
} CBUTT;

typedef struct
{
	Window win;
	int x, y, w, h;
	unsigned long fg, bg;
	char **str;
	int nstr;
	int selected;
	int nlines;
	SCRL scrl;
	int filetypes;
	int dirsonly;
} LIST;

#define R3D_OUT		0
#define R3D_IN		1

#define CENTERX(f,x,str) ((x)-XTextWidth(f,str,strlen(str))/2)
#define CENTERY(f,y) ((y)-((f->ascent+f->descent)/2)+f->ascent)
#define RANGE(a,b,c) { if (a<b) a=b;  if (a>c) a=c; }
#define PTINRECT(x,y,rx,ry,rw,rh) \
           ((x)>=(rx) && (y)>=(ry) && (x)<=(rx)+(rw) && (y)<=(ry)+(rh))

#define COLOR		0
#define GRAYSCALE	1
#define MONO		2
#define FULLCOLOR	3

WHERE Display		*theDisp;
WHERE int			theScreen;
WHERE unsigned int	ncells, dispWIDE, dispHIGH, dispDEEP;
WHERE Colormap		theCmap;
WHERE Window		rootW;
WHERE GC			theGC;
WHERE unsigned long	black, white, fg, bg, pl, infofg, infobg, hicol, locol;
WHERE Font			mfont, bfont;
WHERE XFontStruct	*mfinfo, *bfinfo, *cfinfo;
WHERE Visual		*theVisual;
WHERE Cursor		arrow, target, hand;

WHERE char			*display, *whitestr, *blackstr, *fgstr, *bgstr, *plstr;
WHERE char			*histr, *lostr, *player, *dither;

WHERE char			*maingeom;
WHERE char			*cmd;
WHERE int			mono;

WHERE int			ncols;
WHERE int			bwidth;
WHERE int			ctrlColor;

WHERE int			numnames, curname;
WHERE int			dirsel;
WHERE Pixmap		grayTile, grayStip;

WHERE Window		dirW, ddirW, dnamW, aboutW, diaW, ditherW, infW;
WHERE LIST			dList;
WHERE BUTT			dbut[S_NBUTTS], sbut[S_SBUTTS];
WHERE RBUTT			*ditherRB;
WHERE int			dirWIDE, dirHIGH, NLINES;
WHERE char			*dirGEOM;
WHERE unsigned int	xpa, xpb;

WHERE char			path [MAXPATHLEN+1];
WHERE char			filename [MAXPATHLEN];

WHERE int			iconic, dblclk, loop;
WHERE char			*icongeom;

#undef WHERE


/* exported from MISC.C */

Window CreateWindow();
int StringWidth();
void SetBold (), SetNormal (), ExposureWin (), Timer(), FatalError(), Quit();
void Draw3dRect (), DimRect ();
int DetectDisplayType ();


/* exported from LIST.C */

void CreateIcons (), LSCreate(), LSRedraw(), LSNewData();
int  LSClick();


/* exported from DIR.C */

void CreateDirW(), RedrawDirW(), ResizeDirW ();
int ClickDirW(), DirKey();
void RedrawDDirW(), RedrawDNamW(), SelectDir(), TrackDDirW();
void SetDirFName(), SetTypeName();


/* exported from HANDLE.C */

void LoadCurrentDirectory();
void DoAbout (), DoDither (), DoDelete ();
void play_mpeg ();


/* exported from HANDLE.C */

void DoInfo ();


/* exported from SCRL.C */

void SCCreate(), SCSetRange(), SCSetVal(), SCRedraw(), SCTrack();


/* exported from BUTT.C */

void BTCreate(), BTSetActive(), BTSetStyle (), BTRedraw();
int  BTTrack(), RBTrack();
RBUTT *RBCreate();
void RBRedraw(), RBSelect();


/* exported from DIALOG.C */

#ifdef NEEDDIALOG
void CreateAboutW (), RedrawAboutW (); int AboutEventLoop ();
void CreateDitherW (), RedrawDitherW (); int DitherEventLoop ();
void CreateInfW (), RedrawInfW (); int InfoEventLoop ();
void CreateQueW (), RedrawQueW (); int QuestionEventLoop ();
void CreateErrW (), RedrawErrW (); int ErrorEventLoop ();
int DoReloadWindow ();
#endif

int SimpleEventLoop ();
char *ShortCutPath ();
char *ShortCutName ();
int dirchanged ();

