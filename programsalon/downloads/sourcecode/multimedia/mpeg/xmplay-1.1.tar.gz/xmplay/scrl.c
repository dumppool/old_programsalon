
/* --- C ---
************************************************************************
*
*	Filename    : scrl.c
*	Description : scroller functions
*	Part of     : XMPLAY - X11-directory-browser for XMPEG
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#include "xmplay.h"
#include "bitmaps.h"

#define UPLINE 0
#define UPPAGE 1
#define DNLINE 2
#define DNPAGE 3
#define THUMB 4
#define SCRLWAIT 20

static Pixmap upPix, downPix;
static Pixmap up1Pix, down1Pix;
static Pixmap sgray;
static int pixmaps_built=0;

static int whereInScrl ();
static void drawArrow ();

void SCCreate (sp, parent, x, y, vert, len, minv, maxv, curv, page, 
	fg, bg, func)
SCRL *sp;
Window parent;
int x, y, vert, len, minv, maxv, curv, page;
unsigned long fg, bg;
void (*func) ();
{
	if (!pixmaps_built)
	{
		upPix = XCreatePixmapFromBitmapData (theDisp, parent, 
			up_bits, up_width, up_height, fg, bg, dispDEEP);
		downPix = XCreatePixmapFromBitmapData (theDisp, parent, 
			down_bits, down_width, down_height, fg, bg, dispDEEP);
		up1Pix = XCreatePixmapFromBitmapData (theDisp, parent, 
			up1_bits, up1_width, up1_height, fg, bg, dispDEEP);
		down1Pix = XCreatePixmapFromBitmapData (theDisp, parent, 
			down1_bits, down1_width, down1_height, fg, bg, dispDEEP);
		sgray = XCreatePixmapFromBitmapData (theDisp, parent, 
			scrlgray_bits, scrlgray_width, scrlgray_height, fg, bg, dispDEEP);
	}

	sp->vert = vert;
	sp->len = len;
	sp->fg = fg;
	sp->bg = bg;
	sp->uplit = sp->dnlit = 0;

	if (vert) 
		sp->win = XCreateSimpleWindow (theDisp, parent, x, y, up_width-2,
			len, 1, fg, bg);
	else FatalError ("don't know HOW to make horizontal scrollbar");

	if (!sp->win) FatalError ("can't create scrollbar window");

	sp->tsize = up_width-2;
	sp->tmin = up_height-1;
	sp->tmax = len - (up_height-1) - sp->tsize;
	sp->drawobj = func;

	SCSetRange (sp, minv, maxv, curv, page);
	XSelectInput (theDisp, sp->win, ExposureMask | ButtonPressMask);
}

void SCSetRange (sp, minv, maxv, curv, page)
SCRL *sp;
int minv, maxv, curv, page;
{
	if (maxv<minv) maxv=minv;
	sp->min = minv;
	sp->max = maxv;
	sp->page = page;
	sp->active = (minv < maxv);

	if (sp->active) XSetWindowBackgroundPixmap (theDisp, sp->win, sgray);
	else XSetWindowBackground (theDisp, sp->win, sp->bg);

	SCSetVal (sp, curv);
}

void SCSetVal (sp, curv)
SCRL *sp;
int curv;
{
	RANGE (curv, sp->min, sp->max);
	sp->val = curv;

	if (sp->active) 
		sp->tpos = sp->tmin + ((sp->tmax - sp->tmin)* (curv - sp->min))
			/ (sp->max - sp->min);
	SCRedraw (sp);
	(sp->drawobj) ();
	XFlush (theDisp);
}

void SCRedraw (sp)
SCRL *sp;
{
	XSetForeground (theDisp, theGC, sp->fg);
	XSetBackground (theDisp, theGC, sp->bg);

	XClearWindow (theDisp, sp->win);
 
	if (sp->vert)
	{
		drawArrow (sp, UPLINE);
		drawArrow (sp, DNLINE);

		if (sp->active)
		{
			XSetForeground (theDisp, theGC, sp->bg);
			XFillRectangle (theDisp, sp->win, theGC, 
				1, sp->tpos+1, sp->tsize-2, sp->tsize-2);
			XSetForeground (theDisp, theGC, sp->fg);
			XDrawRectangle (theDisp, sp->win, theGC, 
				0, sp->tpos, sp->tsize-1, sp->tsize-1);
		}
	}
}

static int whereInScrl (sp, x, y)
SCRL *sp;
int x, y;
{
	int v;

	v=0;
	if (sp->vert)
	{
		if (x<0 || x>up_width-2 || y<0 || y>sp->len) return -1;
		v = y;
	}

	if (v < sp->tmin) return UPLINE;
	if (sp->active)
	{
		if (v < sp->tpos) return UPPAGE;
		if (v < sp->tpos + sp->tsize) return THUMB;
		if (v <= sp->tmax + sp->tsize) return DNPAGE;
	}
	if (v > sp->tmax+sp->tsize) return DNLINE;

	return -1;
}

static void drawArrow (sp, arr)
SCRL *sp;
int arr;
{
	if (arr == UPLINE)
	{
		if (sp->uplit) 
			XCopyArea (theDisp, up1Pix, sp->win, theGC, 0, 0,
				up_width, up_height, -1, -1);
		else XCopyArea (theDisp, upPix, sp->win, theGC, 0, 0,
				up_width, up_height, -1, -1);
	}
	else if (arr == DNLINE)
	{
		if (sp->dnlit) 
			XCopyArea (theDisp, down1Pix, sp->win, theGC, 0, 0,
				up_width, up_height, -1, sp->len- (up_height-1));
		else XCopyArea (theDisp, downPix, sp->win, theGC, 0, 0,
			up_width, up_height, -1, sp->len- (up_height-1));
	}
	XFlush (theDisp);
}

void SCTrack (sp, mx, my)
SCRL *sp;
int mx, my;
{
	Window rW, cW;
	int rx, ry, x, y, ipos, pos, lit, ty, tyoff, ty1;
	unsigned int mask;

	ty = tyoff = 0;

	XSetForeground (theDisp, theGC, sp->fg);
	XSetBackground (theDisp, theGC, sp->bg);

	ipos = whereInScrl (sp, mx, my);
	lit = 1;

	switch (ipos)
	{
		case UPLINE:
			sp->uplit = 1;
			if (sp->val > sp->min) SCSetVal (sp, sp->val-1); 
			Timer (SCRLWAIT);
			break;
		case DNLINE:
			sp->dnlit = 1;
			if (sp->val < sp->max) SCSetVal (sp, sp->val+1);
			Timer (SCRLWAIT);
			break;
		case UPPAGE:
			SCSetVal (sp, sp->val - sp->page);
			break;
		case DNPAGE:
			SCSetVal (sp, sp->val + sp->page);
			break;
		case THUMB:
			tyoff = sp->tpos - my;
			ty = sp->tpos;
			if (sp->fg == black)
				XSetState (theDisp, theGC, sp->bg, sp->fg, GXinvert, 
					sp->fg ^ sp->bg);
			else
				XSetState (theDisp, theGC, sp->fg, sp->bg, GXinvert, 
					sp->fg ^ sp->bg);
			XDrawRectangle (theDisp, sp->win, theGC, 
				0, sp->tpos, sp->tsize-1, sp->tsize-1);
			break;
	}

	while (XQueryPointer (theDisp, sp->win, &rW, &cW, &rx, &ry, &x, &y, &mask))
	{
		if (! (mask & Button1Mask)) break;
		switch (ipos)
		{
			case THUMB:
				if (x<-16 || x>16+sp->tsize)
				{
					if (lit)
					{
						lit = 0;
						XDrawRectangle (theDisp, sp->win, theGC, 0, ty,
							sp->tsize-1, sp->tsize-1);
					}
				}
				else
				{
					if (!lit)
					{
						lit = 1;
						ty = y + tyoff;
						RANGE (ty, sp->tmin, sp->tmax);
						XDrawRectangle (theDisp, sp->win, theGC, 0, ty,
							sp->tsize-1, sp->tsize-1);
					}
					else
					{
						ty1 = y+tyoff;
						RANGE (ty1, sp->tmin, sp->tmax);
						if (ty != ty1)
						{
							XDrawRectangle (theDisp, sp->win, theGC, 
								0, ty, sp->tsize-1, sp->tsize-1);
							ty = ty1;
							XDrawRectangle (theDisp, sp->win, theGC, 
								0, ty, sp->tsize-1, sp->tsize-1);
						}
					}
				}
			break;
		case UPLINE:
		case DNLINE:
			pos = whereInScrl (sp, x, y);
			if (pos == ipos)
			{
				if (!lit)
				{ 
					lit = 1;
					if (ipos == UPLINE)
					{
						sp->uplit = 1;
						drawArrow (sp, UPLINE);
					}
					else
					{
						sp->dnlit = 1;
						drawArrow (sp, DNLINE);
					}
				}
				else
				{
					if (sp->val > sp->min && pos==UPLINE)
					{
						SCSetVal (sp, sp->val-1);
						Timer (SCRLWAIT);
					}
					else if (sp->val < sp->max && pos==DNLINE)
					{
						SCSetVal (sp, sp->val+1);
						Timer (SCRLWAIT);
					}
				}
			}
			else
			{
				if (lit)
				{
					lit = 0;
					if (ipos == UPLINE)
					{
						sp->uplit = 0;
						drawArrow (sp, UPLINE);
					}
					else
					{
						sp->dnlit = 0;
						drawArrow (sp, DNLINE);
					}
				}
			}
			break;
		}
	}

	if (ipos == THUMB)
	{
		if (lit)
			XDrawRectangle (theDisp, sp->win, theGC, 0, ty,
				sp->tsize-1, sp->tsize-1);
		XSetState (theDisp, theGC, sp->fg, sp->bg, GXcopy, AllPlanes);

		if (lit && ty != sp->tpos)
		{
			int dt, dv;
			dt = sp->tmax - sp->tmin;
			dv = sp->max - sp->min;
			SCSetVal (sp, sp->min + (dv* (ty - sp->tmin)+dt/2) / dt);
		}
	}

	if (lit && ipos == UPLINE)
	{
		sp->uplit = 0;
		drawArrow (sp, UPLINE);
	}
	if (lit && ipos == DNLINE)
	{
		sp->dnlit = 0;
		drawArrow (sp, DNLINE);
	}
}

