
/* --- C ---
************************************************************************
*
*	Filename    : dialog.c
*	Description : info dialog functions
*	Part of     : XMPLAY - X11-directory-browser for XMPEG
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#define NEEDDIALOG

#include "xmplay.h"
#include "logo.h"
#include "mpeginfo.h"

#define aboutWIDE 230
#define aboutHIGH 240

#define ditherWIDE 280
#define ditherHIGH 210

static int logo_built = 0;
static Pixmap logo;

static int diaWIDE;
#define diaMAXWIDE 440
#define diaHIGH 105

static char title [MAXPATHLEN];
static char *diacom, *dianame;

extern char *ditherType [];

int SimpleEventLoop ();

char *ShortCutPath (name, width)
char *name;
int width;
{
	char buf [MAXPATHLEN];
	char *ptr;

	if (StringWidth (name) > width)
	{
		ptr = name;
		while (StringWidth (ptr) > width) ptr++;
		ptr += 3;
		strcpy (buf, "...");
		strcat (buf, index (ptr, '/'));
	}
	else strcpy (buf, name);
	return (buf);
}

char *ShortCutName (name, width)
char *name;
int width;
{
	char buf [MAXPATHLEN];
	char nam [MAXPATHLEN];

	if (StringWidth (name) > width)
	{
		strcpy (buf, name);
		while (StringWidth (buf) > width) buf [strlen(buf)-3]= '\0';
		strcpy (nam, buf);
		strcat (nam, "...");
	}
	else strcpy (nam, name);
	return (nam);
}

char *maketitle (t)
char *t;
{
	strcpy (title, PROGNAME);
	strcat (title, " ");
	strcat (title, t);
	title [0]= toupper (title [0]);
}


void CreateAboutW ()
{
	maketitle ("About");
	if (!logo_built)
	{
		logo = XCreatePixmapFromBitmapData (theDisp, dirW,
			logo_bits, logo_width, logo_height, infofg, infobg, dispDEEP);
		logo_built = 1;
	}
	XSetForeground (theDisp, theGC, infofg);
	XSetBackground (theDisp, theGC, infobg);
	aboutW = XCreateSimpleWindow (theDisp, dirW,
		(dirWIDE-aboutWIDE-2*bwidth)/2, (dirHIGH-aboutHIGH-2*bwidth)/2,
		aboutWIDE, aboutHIGH, bwidth, infofg, infobg);
	if (!aboutW) FatalError ("can't create about window");
	XSelectInput (theDisp, aboutW, ExposureMask | ButtonPressMask);
	BTCreate (&sbut [S_SOK], aboutW, aboutWIDE-85, aboutHIGH-35,
		BUTTW, BUTTH, "Ok", infofg, pl, hicol, locol);
	BTSetStyle (&sbut [S_SOK], 1);
	XMapRaised (theDisp, aboutW);
}

void RedrawAboutW ()
{
	XSetBackground (theDisp, theGC, infobg);
	XSetForeground (theDisp, theGC, pl);
	XFillRectangle (theDisp, aboutW, theGC, 0, 0, aboutWIDE, 20);
	XSetForeground (theDisp, theGC, infofg);
	SetBold ();
	XDrawString (theDisp, aboutW, theGC, (aboutWIDE-StringWidth (title))/2, 
		15, title, strlen (title));
	XDrawLine (theDisp, aboutW, theGC, 0, 20, aboutWIDE, 20);

	XSetForeground (theDisp, theGC, infofg);
	XCopyArea (theDisp, logo, aboutW, theGC, 0, 0,
		logo_width, logo_height, 20, 35);
	BTRedraw (&sbut [S_SOK]);
}

int AboutEventLoop ()
{
	return (SimpleEventLoop (aboutW));
}


void CreateDitherW ()
{
	int i;

	maketitle ("Dithering");
	XSetForeground (theDisp, theGC, infofg);
	XSetBackground (theDisp, theGC, infobg);
	ditherW = XCreateSimpleWindow (theDisp, dirW,
		(dirWIDE-ditherWIDE-2*bwidth)/2, (dirHIGH-ditherHIGH-2*bwidth)/2,
		ditherWIDE, ditherHIGH, bwidth, infofg, infobg);
	if (!ditherW) FatalError ("can't create dither window");
	XSelectInput (theDisp, ditherW, ExposureMask | ButtonPressMask);

	ditherRB = RBCreate (NULL, ditherW, 20, 40, "2 x 2",
		infofg, infobg, hicol, locol);
	RBCreate (ditherRB, ditherW, 20, 58, "Gray",
		infofg, infobg, hicol, locol);
	RBCreate (ditherRB, ditherW, 20, 76, "Color",
		infofg, infobg, hicol, locol);
	RBCreate (ditherRB, ditherW, 20, 94, "Mono",
		infofg, infobg, hicol, locol);
	RBCreate (ditherRB, ditherW, 20, 112, "Threshold",
		infofg, infobg, hicol, locol);
	RBCreate (ditherRB, ditherW, 20, 130, "Hybrid",
		infofg, infobg, hicol, locol);
	RBCreate (ditherRB, ditherW, 20, 148, "Hybrid 2",
		infofg, infobg, hicol, locol);

	RBCreate (ditherRB, ditherW, 130, 40, "Ordered",
		infofg, infobg, hicol, locol);
	RBCreate (ditherRB, ditherW, 130, 58, "Ordered 2",
		infofg, pl, hicol, locol);
	RBCreate (ditherRB, ditherW, 130, 76, "MBordered",
		infofg, infobg, hicol, locol);
	RBCreate (ditherRB, ditherW, 130, 94, "Floyd-Steinberg 2",
		infofg, infobg, hicol, locol);
	RBCreate (ditherRB, ditherW, 130, 112, "Floyd-Steinberg 4",
		infofg, infobg, hicol, locol);
	RBCreate (ditherRB, ditherW, 130, 130, "Floyd-Steinberg fast",
		infofg, infobg, hicol, locol);

	if (dither)
		for (i=0; i < DITHERMAX; i++)
			if (!strcmp (dither, ditherType [i]))
				RBSelect (ditherRB, i);

	BTCreate (&sbut [S_SOK], ditherW, ditherWIDE-2*(BUTTW+10)-15, ditherHIGH-35,
		BUTTW, BUTTH, "Ok", infofg, pl, hicol, locol);
	BTCreate (&sbut [S_SCANCEL], ditherW, ditherWIDE-BUTTW-25, ditherHIGH-35,
		BUTTW, BUTTH, "Cancel", infofg, pl, hicol, locol);
	BTSetStyle (&sbut [S_SOK], 1);

	XMapRaised (theDisp, ditherW);
}

void RedrawDitherW ()
{
	XSetBackground (theDisp, theGC, infobg);
	XSetForeground (theDisp, theGC, pl);
	XFillRectangle (theDisp, ditherW, theGC, 0, 0, ditherWIDE, 20);
	XSetForeground (theDisp, theGC, infofg);
	SetBold ();
	XDrawString (theDisp, ditherW, theGC, (ditherWIDE-StringWidth (title))/2, 
		15, title, strlen (title));
	XDrawLine (theDisp, ditherW, theGC, 0, 20, ditherWIDE, 20);
	SetNormal ();
	RBRedraw (ditherRB, -1);
	BTRedraw (&sbut [S_SOK]);
	BTRedraw (&sbut [S_SCANCEL]);
}

int DitherEventLoop ()
{
	return (SimpleEventLoop (ditherW));
}

#define infoWIDE 270
#define infoHIGH 240

#include "diainfo.i"

int cancelstate;

void CreateDiaW (comment, name, cancel)
char *comment, *name;
int cancel;
{
	int l;

	cancelstate = cancel;
	diaWIDE = StringWidth (title) + 60;
	
	diacom = comment;
	l = StringWidth (comment) + 30;
	if (l > diaWIDE) diaWIDE = l;
	dianame = name;
	l = StringWidth (name) + 30;
	if (l > diaWIDE) diaWIDE = l;
	if (diaWIDE > diaMAXWIDE)
	{
		diaWIDE = diaMAXWIDE;
		dianame = ShortCutName (name, diaWIDE-30);
	}
	
	XSetForeground (theDisp, theGC, infofg);
	XSetBackground (theDisp, theGC, infobg);
	diaW = XCreateSimpleWindow (theDisp, dirW, (dirWIDE-diaWIDE-2*bwidth)/2,
		(dirHIGH-diaHIGH-2*bwidth)/2, diaWIDE, diaHIGH, 
		bwidth + 2, infofg, infobg);
	if (!diaW) FatalError ("can't create dialog window");
	XSelectInput (theDisp, diaW, ExposureMask | ButtonPressMask);
	if (cancel)
	{
		BTCreate (&sbut [S_SOK], diaW, diaWIDE-2*(BUTTW+10)-15, diaHIGH-35,
			BUTTW, BUTTH, "Ok", infofg, pl, hicol, locol);
		BTCreate (&sbut [S_SCANCEL], diaW, diaWIDE-BUTTW-25, diaHIGH-35,
			BUTTW, BUTTH, "Cancel", infofg, pl, hicol, locol);
	}
	else
		BTCreate (&sbut [S_SOK], diaW, diaWIDE-BUTTW-25, diaHIGH-35,
			BUTTW, BUTTH, "Ok", infofg, pl, hicol, locol);
	BTSetStyle (&sbut [S_SOK], 1);
	XMapRaised (theDisp, diaW);
}

void RedrawDiaW ()
{
	XSetBackground (theDisp, theGC, infobg);
	XSetForeground (theDisp, theGC, pl);
	XFillRectangle (theDisp, diaW, theGC, 0, 0, diaWIDE, 20);
	XSetForeground (theDisp, theGC, infofg);
	SetBold ();
	XDrawString (theDisp, diaW, theGC, (diaWIDE-StringWidth (title))/2, 
		15, title, strlen (title));
	SetNormal ();
	XDrawLine (theDisp, diaW, theGC, 0, 20, diaWIDE, 20);
	XDrawString (theDisp, diaW, theGC, 10, 40, diacom, strlen (diacom));
	XDrawString (theDisp, diaW, theGC, 10, 60, dianame, strlen (dianame));
	BTRedraw (&sbut [S_SOK]);
	if (cancelstate) BTRedraw (&sbut [S_SCANCEL]);
}

void CreateQueW (comment, name)
char *comment, *name;
{
	maketitle ("Question");
	CreateDiaW (comment, name, 1);
}

void RedrawQueW ()
{
	RedrawDiaW ();
}

int QuestionEventLoop ()
{
	return (SimpleEventLoop (diaW));
}


void CreateErrW (comment, name)
char *comment, *name;
{
	maketitle ("Error");
	CreateDiaW (comment, name, 0);
}

void RedrawErrW ()
{
	RedrawDiaW ();
	XBell (theDisp, 0);
}

int ErrorEventLoop ()
{
	return (SimpleEventLoop (diaW));
}

int SimpleEventLoop (win)
Window win;
{
	XEvent event;
	BUTT *bp, *bpc;
	int end = 1;
	int ret = S_SOK;
	int bnum;

	XSetForeground (theDisp, theGC, infofg);
	XSetBackground (theDisp, theGC, infobg);
	bp = &sbut [S_SOK];
	bpc = &sbut [S_SCANCEL];

	XDefineCursor (theDisp, dirW, hand);
	XDefineCursor (theDisp, win, hand);
	while (end)
	{
		XNextEvent (theDisp, &event);
		switch (event.type)
		{
			case Expose:
				{
					XExposeEvent *exp_event = (XExposeEvent *) &event;

					ExposureWin (exp_event);
					if (exp_event->window == diaW) RedrawDiaW ();
					else if (exp_event->window == aboutW) RedrawAboutW ();
					else if (exp_event->window == ditherW) RedrawDitherW ();
					else if (exp_event->window == infW) RedrawInfW ();
				}
				break;
			case ButtonPress:
				{
				XButtonEvent *b = (XButtonEvent *) &event;
				switch (b->button)
				{
					case Button1: 
						if (win == ditherW)
							if ((bnum = RBClick (ditherRB, b->x, b->y)) >= 0)
								if (RBTrack (ditherRB, bnum))
									RBSelect (ditherRB, bnum);
						if (PTINRECT (b->x, b->y, bp->x, bp->y, bp->w, bp->h))
							if (bnum = BTTrack (bp)) end = 0;
						if (PTINRECT (b->x, b->y,
							bpc->x, bpc->y, bpc->w, bpc->h))
								if (bnum = BTTrack (bpc))
								{
									ret = S_SCANCEL;
									end = 0;
								}
						break;
					default:
						break;
				}
				}
				break;
			default :
				break;
		}
	}
	XDefineCursor (theDisp, dirW, arrow);
	XDestroyWindow (theDisp, win);
	return (ret);
}

