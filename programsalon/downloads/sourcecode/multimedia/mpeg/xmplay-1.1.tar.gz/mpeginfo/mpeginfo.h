
/* --- C ---
************************************************************************
*
*	Filename    : mpeginfo.h
*	Description : type definition
*	Part of     : MPEGINFO - info program for MPEG-movies
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#ifdef NETINET
#ifndef MIPS
#include <sys/types.h>
#include <netinet/in.h>
#else
#include <bsd/netinet/in.h>
#endif
#endif

#define SEQ_END_CODE			0x000001b7
#define SEQ_START_CODE			0x000001b3
#define GOP_START_CODE			0x000001b8
#define PICTURE_START_CODE		0x00000100
#define SLICE_MIN_START_CODE	0x00000101
#define SLICE_MAX_START_CODE	0x000001af
#define EXT_START_CODE			0x000001b5
#define USER_START_CODE			0x000001b2


#define PARSE_OK       1
#define PARSE_ERROR   -1
#define NO_MPEG       -2

#define TRUE           1
#define FALSE          0

#define BUFFER_SIZE    24

typedef  struct tag_MPEGINFO
{
	unsigned int h_size;                     /* Horiz. size in pixels.     */
	unsigned int v_size;                     /* Vert. size in pixels.      */
	unsigned int mb_height;                  /* Vert. size in mblocks.     */
	unsigned int mb_width;                   /* Horiz. size in mblocks.    */
	unsigned char aspect_ratio;              /* Code for aspect ratio.     */
	unsigned char picture_rate;              /* Code for picture rate.     */
	unsigned int bit_rate;                   /* Bit rate.                  */
	unsigned int vbv_buffer_size; 
	unsigned int  const_param_flag;          /* Constrained parameter      */
	unsigned int stream_length;              /* Stream length in bits      */
	unsigned int XING;                       /* XING format or MPEG-I      */
	unsigned int SEC_MPEG;        
}
MPEGINFO;

