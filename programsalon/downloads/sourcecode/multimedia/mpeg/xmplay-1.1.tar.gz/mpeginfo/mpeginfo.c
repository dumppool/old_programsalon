
/* --- C ---
************************************************************************
*
*	Filename    : mpeginfo.c
*	Description : info functions
*	Part of     : MPEGINFO - info program for MPEG-movies
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#include <stdlib.h>
#include "mpeginfo.h"

#define get_bitsX(num, mask, shift,  result)                              \
{                                                                         \
  mi_bitOffset += num;                                                       \
                                                                          \
  if (mi_bitOffset & 0x20) {                                                 \
    mi_bitOffset -= 32;                                                      \
    mi_bitBuffer++;                                                          \
    mi_bufLength--;                                                          \
    if (mi_bitOffset) {                                                      \
      mi_curBits |= (*mi_bitBuffer >> (num - mi_bitOffset));                       \
    }                                                                     \
    result = ((mi_curBits & mask) >> shift);                                 \
    mi_curBits = *mi_bitBuffer << mi_bitOffset;                                    \
  }                                                                       \
  else {                                                                  \
    result = ((mi_curBits & mask) >> shift);                                 \
    mi_curBits <<= num;                                                      \
  }                                                                       \
}
#define get_bits1(result) get_bitsX(1,   0x80000000, 31, result)
#define get_bits2(result) get_bitsX(2,   0xc0000000, 30, result)
#define get_bits3(result) get_bitsX(3,   0xe0000000, 29, result)
#define get_bits4(result) get_bitsX(4,   0xf0000000, 28, result)
#define get_bits5(result) get_bitsX(5,   0xf8000000, 27, result)
#define get_bits6(result) get_bitsX(6,   0xfc000000, 26, result)
#define get_bits7(result) get_bitsX(7,   0xfe000000, 25, result)
#define get_bits8(result) get_bitsX(8,   0xff000000, 24, result)
#define get_bits9(result) get_bitsX(9,   0xff800000, 23, result)
#define get_bits10(result) get_bitsX(10, 0xffc00000, 22, result)
#define get_bits11(result) get_bitsX(11, 0xffe00000, 21, result)
#define get_bits12(result) get_bitsX(12, 0xfff00000, 20, result)
#define get_bits14(result) get_bitsX(14, 0xfffc0000, 18, result)
#define get_bits16(result) get_bitsX(16, 0xffff0000, 16, result)
#define get_bits18(result) get_bitsX(18, 0xffffc000, 14, result)
#define get_bits32(result) get_bitsX(32, 0xffffffff,  0, result)

#define get_bitsn(num, result) get_bitsX((num), nBitMask[num], (32-(num)), result)

#define show_bits32(result)                               		\
{                                                                       \
  if (mi_bitOffset)                                                        \
  {							                \
    result = mi_curBits | (*(mi_bitBuffer+1) >> (32 - mi_bitOffset));		\
  }                                                                     \
  else                                                                  \
  {                                                                     \
    result = mi_curBits;							\
  }                                                                     \
}

#define show_bitsX(num, mask, shift, result)                            \
{                                                                       \
  int bO;                                                               \
  bO = mi_bitOffset + num;                                                 \
  if (bO > 32)                                                          \
  {                                                                     \
    bO -= 32;                                                           \
    result = ((mi_curBits & mask) >> shift) |                              \
                (*(mi_bitBuffer+1) >> (shift + (num - bO)));               \
  }                                                                     \
  else                                                                  \
  {                                                                     \
    result = ((mi_curBits & mask) >> shift);                               \
  }                                                                     \
}

#define show_bits1(result)  show_bitsX(1,  0x80000000, 31, result)
#define show_bits2(result)  show_bitsX(2,  0xc0000000, 30, result)
#define show_bits3(result)  show_bitsX(3,  0xe0000000, 29, result)
#define show_bits4(result)  show_bitsX(4,  0xf0000000, 28, result)
#define show_bits5(result)  show_bitsX(5,  0xf8000000, 27, result)
#define show_bits6(result)  show_bitsX(6,  0xfc000000, 26, result)
#define show_bits7(result)  show_bitsX(7,  0xfe000000, 25, result)
#define show_bits8(result)  show_bitsX(8,  0xff000000, 24, result)
#define show_bits9(result)  show_bitsX(9,  0xff800000, 23, result)
#define show_bits10(result) show_bitsX(10, 0xffc00000, 22, result)
#define show_bits11(result) show_bitsX(11, 0xffe00000, 21, result)
#define show_bits12(result) show_bitsX(12, 0xfff00000, 20, result)
#define show_bits13(result) show_bitsX(13, 0xfff80000, 19, result)
#define show_bits14(result) show_bitsX(14, 0xfffc0000, 18, result)
#define show_bits15(result) show_bitsX(15, 0xfffe0000, 17, result)
#define show_bits16(result) show_bitsX(16, 0xffff0000, 16, result)
#define show_bits17(result) show_bitsX(17, 0xffff8000, 15, result)
#define show_bits18(result) show_bitsX(18, 0xffffc000, 14, result)
#define show_bits19(result) show_bitsX(19, 0xffffe000, 13, result)
#define show_bits20(result) show_bitsX(20, 0xfffff000, 12, result)
#define show_bits21(result) show_bitsX(21, 0xfffff800, 11, result)
#define show_bits22(result) show_bitsX(22, 0xfffffc00, 10, result)
#define show_bits23(result) show_bitsX(23, 0xfffffe00,  9, result)
#define show_bits24(result) show_bitsX(24, 0xffffff00,  8, result)
#define show_bits25(result) show_bitsX(25, 0xffffff80,  7, result)
#define show_bits26(result) show_bitsX(26, 0xffffffc0,  6, result)
#define show_bits27(result) show_bitsX(27, 0xffffffe0,  5, result)
#define show_bits28(result) show_bitsX(28, 0xfffffff0,  4, result)
#define show_bits29(result) show_bitsX(29, 0xfffffff8,  3, result)
#define show_bits30(result) show_bitsX(30, 0xfffffffc,  2, result)
#define show_bits31(result) show_bitsX(31, 0xfffffffe,  1, result)

#define show_bitsn(num,result) show_bitsX((num), (0xffffffff << (32-(num))), (32-(num)), result)

#define flush_bits32                                                  \
{                                                                     \
  mi_bitBuffer++;                                                        \
  mi_bufLength--;                                                        \
  mi_curBits = *mi_bitBuffer  << mi_bitOffset;                                 \
}

#define flush_bits(num)                                               \
{                                                                     \
  mi_bitOffset += num;                                                   \
  if (mi_bitOffset & 0x20)                                               \
  {                                                                   \
    mi_bitOffset -= 32;                                                  \
    mi_bitBuffer++;                                                      \
    mi_bufLength--;                                                      \
    mi_curBits = *mi_bitBuffer  << mi_bitOffset;                               \
  }                                                                   \
  else                                                                \
  {                                                                   \
    mi_curBits <<= num;                                                  \
  }                                                                   \
}


/* Declarations of global variables used. */

unsigned int mi_curBits;
int mi_bitOffset;
int mi_bufLength;
unsigned int *mi_bitBuffer;

int fd;

/* Function Prototypes */

int mpeg_info ();

static int ParseSeqHead ();
static int ParseGOP ();
static int next_bits ();
static int get_ext_data ();
static int next_start_code ();

int mpeg_info (mpeginfo, stream)
MPEGINFO *mpeginfo;
char *stream;
{
	unsigned int data;
	unsigned int *ptr;
	int retval = PARSE_OK;
	unsigned int *save_mi_bitBuffer;
	int i;

	if (!stream) return (PARSE_ERROR);
 
	fd = 0;		/* jzl60: just in case we come twice in here */
	fd = fopen (stream, "r");
	if (!fd) return (PARSE_ERROR);
 
	/* jzl60: needs to save buffer ptr to free() to use it. mi_bitBuffer is modified by other fn() */
	save_mi_bitBuffer = mi_bitBuffer = (unsigned int *) malloc (BUFFER_SIZE * sizeof (unsigned int));
	if (!mi_bitBuffer) return (PARSE_ERROR);
 
	mi_bufLength = fread ((unsigned char *)mi_bitBuffer, 1,
		BUFFER_SIZE * sizeof (unsigned int), fd);
 
	if (mi_bufLength < 0)
	{
		retval = PARSE_ERROR;
		goto done;
	}
 
	mi_bufLength /= 4;
	ptr = mi_bitBuffer;
	for (i = 0;i < mi_bufLength;i++) *ptr++ = htonl (*ptr);
		mi_curBits = *mi_bitBuffer;
 
	/* test for secure mpeg-stream */

	next_start_code ();
	show_bits32 (data);

	if (data != SEQ_START_CODE)
	{
		retval = NO_MPEG;
		goto done;
	}
	if (ParseSeqHead (mpeginfo) != PARSE_OK)
	{
		retval = PARSE_ERROR;
		goto done;
	}
	show_bits32 (data);
	if (ParseGOP (mpeginfo) != PARSE_OK) retval = PARSE_ERROR;
 
done:
	/* jzl60: checking and freeing the saved ptr */
	if (save_mi_bitBuffer) free (save_mi_bitBuffer);
	if (fd) fclose (fd);
	return (retval);
} 

static int ParseSeqHead (mpeginfo)
MPEGINFO *mpeginfo;
{
	unsigned int data;
	int i;

	/* Flush off sequence start code. */
	flush_bits32;

	/* Get horizontal size of image space. */
	get_bits12 (data);
	mpeginfo->h_size = data;

	/* Get vertical size of image space. */
	get_bits12 (data);
	mpeginfo->v_size = data;

	/* Parse of aspect ratio code. */
	get_bits4 (data);
	mpeginfo->aspect_ratio = (unsigned char) data;

	/* Parse off picture rate code. */
	get_bits4 (data);
	mpeginfo->picture_rate = (unsigned char) data;

	/* Parse off bit rate. */
	get_bits18 (data);
	mpeginfo->bit_rate = data;

	/* Flush marker bit. */
	flush_bits (1);

	/* Parse off vbv buffer size. */
	get_bits10 (data);
	mpeginfo->vbv_buffer_size = data;

	/* Parse off contrained parameter flag. */
	get_bits1 (data);
	if (data) mpeginfo->const_param_flag = TRUE;
	else mpeginfo->const_param_flag = FALSE;

	/* If intra_quant_matrix_flag set, parse off intra quant matrix values. */

	get_bits1 (data);
	if (data) for (i = 0;i < 64;i++) get_bits8 (data);

	get_bits1 (data);
	if (data) for (i = 0;i < 64;i++) get_bits8 (data);

	/* Go to next start code. */

	next_start_code ();

	/* If next start code is extension start code, parse off extension data. */

	if (next_bits (32, EXT_START_CODE))
	{
		flush_bits32;
		get_ext_data ();
	}

	/* If next start code is user start code, parse off user data. */
	if (next_bits (32, USER_START_CODE))
	{
		flush_bits32;
		get_ext_data ();
	}

	return PARSE_OK;
}


static int ParseGOP (mpeginfo)
MPEGINFO *mpeginfo;
{
	unsigned int data;

	/* Flush group of pictures start code. WWWWWWOOOOOOOSSSSSSHHHHH!!! */
	flush_bits32;

	/* Parse off drop frame flag. */
	get_bits1 (data);
 
	/* Parse off hour component of time code. */
	get_bits5 (data);
 
	/* Parse off minute component of time code. */
	get_bits6 (data);
 
	/* Flush marker bit. */
	flush_bits (1);

	/* Parse off second component of time code. */
	get_bits6 (data);
 
	/* Parse off picture count component of time code. */
	get_bits6 (data);
 
	/* Parse off closed gop and broken link flags. */
	get_bits2 (data);
	if (data > 1) mpeginfo->XING = FALSE;
	else mpeginfo->XING = TRUE;

	next_start_code ();

	/* If next start code is extension start code, parse off extension data.  */

	if (next_bits (32, EXT_START_CODE))
	{
		flush_bits32;
		get_ext_data ();
	}
	/* If next start code is user start code, parse off user data. */

	if (next_bits (32, USER_START_CODE))
	{
		flush_bits32;
		get_ext_data ();
	} 
	return PARSE_OK;
}

static int next_bits (num, mask)
int num;
unsigned int mask;
{
	unsigned int stream;
	int ret_value;

	show_bitsn (num, stream);

	if (mask == stream) ret_value = TRUE;
	else ret_value = FALSE;

	return ret_value;
}

static int get_ext_data ()
{
	unsigned int data;
	int count = 0;

	while (!next_bits (24, 0x000001))
	{ 
		get_bits8 (data);
		count += 8;
	}
	return (count);
}

static int next_start_code ()
{
	int state;
	int byteoff;
	unsigned int data;

	/* If bit offset not zero, reset and advance buffer pointer. */
	byteoff = mi_bitOffset % 8;
	if (byteoff != 0) flush_bits ((8-byteoff));

	/* Set state = 0. */
	state = 0;

	/* While buffer has data ... */
	while (mi_bufLength > 0)
	{
		get_bits8 (data);

		if (data == 0)
		{
			if (state < 2) state++;
		}
		else if (data == 1)
		{
			if (state == 2) state++;
			else state = 0;
		}
		else
		{
			state = 0;
		}
		if (state == 3)
		{
			mi_bitOffset = mi_bitOffset - 24;
			if (mi_bitOffset < 0)
			{
				mi_bitOffset = 32 + mi_bitOffset;
				mi_bufLength++;
				mi_bitBuffer--;
				mi_curBits = *mi_bitBuffer;
			}
			else
			{
				mi_curBits = *mi_bitBuffer;
			}
			return (PARSE_OK);
		}
	}
	return (PARSE_ERROR);
}

