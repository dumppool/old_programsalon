
/* --- C ---
************************************************************************
*
*	Filename    : main.c
*	Description : main file
*	Part of     : MPEGINFO - info program for MPEG-movies
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#include "mpeginfo.h"

extern int mpeg_info ();

void main (argc, argv) 
int argc;
char **argv;
{
	MPEGINFO mpeginfo;
	char cpb[20];

	if (!argv[1])
	{
		printf ("usage: %s filename\n", argv [0]);
		exit (-1);
	}

	printf ("\n%s reports for %s:\n\n", argv [0], argv[1]);
	if (mpeg_info (&mpeginfo, argv[1]) == PARSE_OK)
	{
		printf ("Horizontal frame size : %d\n",mpeginfo.h_size);
		printf ("Vertical frame size   : %d\n",mpeginfo.v_size);
		printf ("Marcoblock width      : %d\n", mpeginfo.mb_width);
		printf ("Marcoblock height     : %d\n\n", mpeginfo.mb_height);
		printf ("Aspect ratio          : %d\n", mpeginfo.aspect_ratio);
		printf ("Picture rate          : %d\n", mpeginfo.picture_rate);
		printf ("Bit rate              : %d\n", mpeginfo.bit_rate);
		printf ("VBV buffer size       : %d\n", mpeginfo.vbv_buffer_size);
		printf ("Stream length         : %d\n\n", mpeginfo.stream_length);
		if (mpeginfo.const_param_flag) strcpy (cpb, "constrained parameter");
		else strcpy (cpb, "no constrained parameter");
		if (mpeginfo.XING) printf ("Stream format         : XING %s\n\n", cpb);
		else printf ("Stream format         : IPB %s\n\n", cpb);
	}
	else printf ("No MPEG-I-video-file.\n\n");

	exit (0);
}

