
/* --- C ---
************************************************************************
*
*	Filename    : playmaps.h
*	Description : include file for button bitmaps
*	Part of     : XMPEG - X11-MPEG-player
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#include "bitmaps/close.xbm"
#include "bitmaps/about.xbm"
#include "bitmaps/first.xbm"
#include "bitmaps/rewind.xbm"
#include "bitmaps/pause.xbm"
#include "bitmaps/play.xbm"
#include "bitmaps/step.xbm"
#include "bitmaps/forward.xbm"
#include "bitmaps/info.xbm"

