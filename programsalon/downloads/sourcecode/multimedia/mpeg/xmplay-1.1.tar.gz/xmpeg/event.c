
/* --- C ---
************************************************************************
*
*	Filename    : event.c
*	Description : X11 event loop
*	Part of     : XMPEG - X11-MPEG-player
*
*	Version     : 1.1
*	Date        : Tue Apr  4 14:06:10 MET DST 1995
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#include "xmpeg.h"

extern Window window;
extern int ditherType;

int EventLoop ()
{
	XEvent event;
	int retval;
   
	retval = XM_STATUS;
#ifndef SLOW
	Timer (15);
#endif
	if (XPending (theDisp)>0)
	{
		XNextEvent (theDisp, &event);
		switch (event.type)
		{
			case Expose:
				{
					XExposeEvent *exp_event = (XExposeEvent *) &event;

					ExposureWin (exp_event);
				}
				break;
			case ButtonPress:
				{
				XButtonEvent *but_event = (XButtonEvent *) &event;
				int i;

				switch (but_event->button)
				{
					case Button1: 
						if (but_event->window == dirW)
						{
							i=ClickDirW (but_event->x, but_event->y);

							if (i==S_BCLOSE) retval = XM_EXIT;	
							else if (i==S_BABOUT) DoAbout ();
							else if (i==S_BFIRST) retval = XM_FIRST;
							else if (i==S_BREWIND)
							{
								if (XM_STATUS == XM_PAUSE)
									retval = XM_FAST_REWIND;
								else retval = XM_REWIND;
							}
							else if (i==S_BPAUSE) retval = XM_PAUSE;
							else if (i==S_BSTEP) retval = XM_STEP;
							else if (i==S_BPLAY) retval = XM_PLAY;
							else if (i==S_BFORWARD)
							{
								if (XM_STATUS == XM_PAUSE)
									retval = XM_FAST_FORWARD;
								else retval = XM_FORWARD;
							}
							else if (i==S_BINFO) DoInfo ();
						}
						else if (but_event->window == window) DoDither ();
						break;
					default:
						break;
				}
			}
			break;
		case EnterNotify :
			break;
		case KeyPress:
/*
			{
				XKeyEvent *key_event = (XKeyEvent *) &event;
				char buf [128];
				KeySym ks;
				XComposeStatus status;
				int stlen;
 
				stlen = XLookupString (key_event, buf, 128, &ks, &status);
				if (!stlen) break;
				if (key_event->window == dirW)
					if (DirKey (buf [0])) XBell (theDisp, 0);
			}
*/
			break;
		default:
			break;
		}
	}
        
	return (retval);
}

