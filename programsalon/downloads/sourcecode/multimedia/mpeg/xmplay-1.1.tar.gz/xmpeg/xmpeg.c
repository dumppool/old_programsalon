
/* --- C ---
************************************************************************
*
*	Filename    : xmpeg.c
*	Description : main program and event loop
*	Part of     : XMPEG - X11-MPEG-player
*
*	Version     : 1.1
*	Date        : Tue Apr  4 13:34:10 MET 1995
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#define MAIN
#define NEEDSVIDEO
#include "xmpeg.h"
#include <X11/Xatom.h>

#define QUIT -1
#define FONT "-*-helvetica-medium-r-*-*-12-*"
#define BFONT "-*-helvetica-bold-r-*-*-12-*"

/*	#define FONT "-*-courier-medium-r-*-*-12-*"
	#define BFONT "-*-courier-bold-r-*-*-12-*"	*/

/*	#define FONT "8x13"
	#define BFONT "8x13bold"	*/

/* ATTENTION: they have to be in the same order like defined in video.h */

/* this is the order the buttons appear in the window */

char *ditherTypeStrings [] =
{
    "2x2",
    "gray",
    "color",
    "mono",
    "threshold",
    "hybrid",
    "hybrid2",
    "ordered",
    "ordered2",
    "mbordered",
    "fs2",
    "fs4",
    "fs2fast"
};

/* this is the order ditherTypeStrings compared to Berkeley's defines */

int ditherIndex [] =
{
	5, 6, 7, 10, 11, 0, 1, 10, 12, 13, 3, 2, 4
};

extern int ditherType;

static unsigned long rootbg, rootfg;
static Atom __SWM_VROOT = None;
static char str [128];
static char *def_str;
static int def_int;

static int rd_int ();
static int rd_str ();
static int rd_flag ();

extern int mpeg_main ();

int main (argc, argv)
int argc;
char *argv [];
{
	int i;
	char *rootfgstr, *rootbgstr;

	XColor ecdef;
	Window rootReturn, parentReturn, *children;
	unsigned int numChildren;

	displaystr = whitestr = blackstr = NULL;
	maingeom = "+400+150";
	fgstr = "black";
	bgstr = "LemonChiffon";
	plstr = "gray70";
	histr = "gray90";
	lostr = "gray30";
	ditherstr = "ordered2";
	dirWIDE = DIRWIDE;
	dirHIGH = DIRHIGH;

	rootfgstr = rootbgstr = NULL;
	filename = STDINSTR;
	filesize = -1;
	firstframe = 1;
	cmd = rindex (argv [0], '/');
	if (!cmd) cmd = argv [0];
	else cmd++;

	ncols = -1;
	mono = ctrlColor = xm_current_frame = xm_zoom = 0;
	bwidth = 2;

	dirW = diaW = aboutW = ditherW = (Window) NULL;
	icongeom = NULL;
	iconic = dblclk = loop = 0;

	for (i=1;i<argc-1;i++)
	{
		if (!strncmp (argv [i], "-dis", 4))
		{
			displaystr = argv [++i];
			break;
		}
	}

	if ((theDisp=XOpenDisplay (displaystr)) == NULL)
	{
		fprintf (stderr, "%s: Can't open display\n", argv [0]);
		xmpeg_exit (-1);
	}

	if (rd_str ("geometry")) maingeom = def_str;
	if (rd_str ("icongeom")) icongeom = def_str;
	if (rd_str ("background")) bgstr = def_str;
	if (rd_str ("foreground")) fgstr = def_str;
	if (rd_str ("plane")) plstr = def_str;
	if (rd_int ("borderWidth")) bwidth = def_int;
	if (rd_str ("highlight")) histr = def_str;
	if (rd_str ("lowlight")) lostr = def_str;
	if (rd_str ("dither")) ditherstr = def_str;
	iconic = rd_flag ("iconic");
	loop = rd_flag ("loop");
 
	for (i=1;i<argc;i++)
	{
		if (argv [i][0] != '-') filename = argv [i];
		else if (!strncmp (argv [i], "-iconi", 6)) iconic = 1;
		else if (!strncmp (argv [i], "-loo", 4)) loop = 1;
		else if (!strcmp (argv [i], "-h")) Syntax ();
		else if (!strncmp (argv [i], "-bg", 3))
				{ if (++i<argc) bgstr = argv [i]; }
		else if (!strncmp (argv [i], "-bw", 3))
				{ if (++i<argc) bwidth=atoi (argv [i]); }
		else if (!strncmp (argv [i], "-dis", 4))
				{ if (++i<argc) displaystr = argv [i]; }
		else if (!strncmp (argv [i], "-fg", 3))
				{ if (++i<argc) fgstr = argv [i]; }
		else if (!strncmp (argv [i], "-pl", 3))
				{ if (++i<argc) plstr = argv [i]; }
		else if (!strncmp (argv [i], "-ge", 3))
				{ if (++i<argc) maingeom = argv [i]; }
		else if (!strncmp (argv [i], "-icong", 6))
				{ if (++i<argc) icongeom = argv [i]; }
		else if (!strncmp (argv [i], "-hi", 3))
				{ if (++i<argc) histr = argv [i]; }
		else if (!strncmp (argv [i], "-lo", 3))
				{ if (++i<argc) lostr = argv [i]; }
		else if (!strncmp (argv [i], "-dit", 4))
				{ if (++i<argc) ditherstr = argv [i]; }
		else Syntax ();
	}
	if (ditherstr)
	{
		ditherType = -1;
		for (i=0; i < DITHERMAX; i++)
			if (!strcmp (ditherstr, ditherTypeStrings [i]))
				ditherType = ditherIndex [i];
        if (ditherType < 0) Syntax ();
    } else Syntax ();

	if (ditherType == Twox2_DITHER) xm_zoom = 1;
 
	theScreen = DefaultScreen (theDisp);
	theCmap = DefaultColormap (theDisp, theScreen);
	rootW = RootWindow (theDisp, theScreen);
	theGC = DefaultGC (theDisp, theScreen);
	theVisual = DefaultVisual (theDisp, theScreen);
	ncells = DisplayCells (theDisp, theScreen);
	dispWIDE = DisplayWidth (theDisp, theScreen);
	dispHIGH = DisplayHeight (theDisp, theScreen);
	dispDEEP = DisplayPlanes (theDisp, theScreen);

	__SWM_VROOT = XInternAtom (theDisp, "__SWM_VROOT", False);
	XQueryTree (theDisp, rootW, &rootReturn, &parentReturn, &children, 
		&numChildren);
	for (i = 0;i < numChildren;i++)
	{
		Atom actual_type;
		int actual_format;
		unsigned long nitems, bytesafter;
		Window *newRoot = NULL;
		XWindowAttributes xwa;

		if (XGetWindowProperty (theDisp, children [i], __SWM_VROOT, 0, 1, 
			False, XA_WINDOW, &actual_type, &actual_format, &nitems, 
			&bytesafter, (unsigned char **) &newRoot) == Success && newRoot)
		{
			rootW = *newRoot;
			XGetWindowAttributes (theDisp, rootW, &xwa);
			dispWIDE = xwa.width;
			dispHIGH = xwa.height;
			dispDEEP = xwa.depth;
			break;
		}
	}

	arrow = XCreateFontCursor (theDisp, XC_top_left_arrow);
	target = XCreateFontCursor (theDisp, XC_leftbutton);
	hand = XCreateFontCursor (theDisp, XC_hand1);

	white = WhitePixel (theDisp, theScreen);
	black = BlackPixel (theDisp, theScreen);
	if (whitestr && XParseColor (theDisp, theCmap, whitestr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) white = ecdef.pixel;
	if (blackstr && XParseColor (theDisp, theCmap, blackstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) black = ecdef.pixel;

	fg = black;
	bg = white;
	pl = white;
	if (fgstr && XParseColor (theDisp, theCmap, fgstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) fg = ecdef.pixel;
	if (bgstr && XParseColor (theDisp, theCmap, bgstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) bg = ecdef.pixel;
	if (plstr && XParseColor (theDisp, theCmap, plstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) pl = ecdef.pixel;

	rootfg = white;
	rootbg = black;
	if (rootfgstr && XParseColor (theDisp, theCmap, rootfgstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) rootfg = ecdef.pixel;
	if (rootbgstr && XParseColor (theDisp, theCmap, rootbgstr, &ecdef) &&
		XAllocColor (theDisp, theCmap, &ecdef)) rootbg = ecdef.pixel;

	i = 0;
	if (dispDEEP > 1)
	{
		if (histr && XParseColor(theDisp, theCmap, histr, &ecdef) &&
			XAllocColor(theDisp, theCmap, &ecdef))
		{
			hicol = ecdef.pixel;
			i |= 1;
		}
		if (lostr && XParseColor (theDisp, theCmap, lostr, &ecdef) &&
			XAllocColor (theDisp, theCmap, &ecdef))
		{
			locol = ecdef.pixel;
			i |= 2;
		}
	}

	if (i == 0) ctrlColor = 0;
	else if (i == 3) ctrlColor = 1;
	else ctrlColor = 0;

	XSetForeground (theDisp, theGC, fg);
	XSetBackground (theDisp, theGC, bg);

	infofg = fg;
	infobg = bg;

	if (!mono)
	{
		if (theVisual->class == StaticGray || theVisual->class == GrayScale)
		mono = 1;
	}
 
	if ((mfinfo = XLoadQueryFont (theDisp, FONT))==NULL ||
		(bfinfo = XLoadQueryFont (theDisp, BFONT))==NULL)
	{
		sprintf (str,
			"couldn't open the following fonts:\n\t %s \n\t %s", 
			FONT, BFONT);
		FatalError (str);
	}
	mfont=mfinfo->fid;
	bfont=bfinfo->fid;
	SetNormal ();
 
	if (ncols == -1)
	{
		if (dispDEEP>1) ncols = 1<<dispDEEP;
		else ncols = 0;
	}
	else if (ncols>256) ncols = 256;

	mpeg_main (argc, argv);
	xmpeg_exit (0);
	return (0);
}


static int rd_int (name)
char *name;
{
	if (def_str = XGetDefault (theDisp, PROGNAME, name))
	{
		if (sscanf (def_str, "%ld", &def_int) == 1) return 1;
		else
		{
			fprintf (stderr,
				"%s: couldn't read integer value for %s resource\n", 
				cmd, name);
			return 0;
		}
	}
	else return 0;
}

static int rd_str (name)
char *name;
{
	if (def_str = XGetDefault (theDisp, PROGNAME, name)) return 1;
	else return 0;
}

static int rd_flag (name)
char *name;
{
	if (def_str = XGetDefault (theDisp, PROGNAME, name))
	{
		def_int = (strcmp (def_str, "on")==0) || 
			(strcmp (def_str, "1")==0) ||
			(strcmp (def_str, "true")==0) ||
			(strcmp (def_str, "yes")==0);
		return 1;
	}
	else return 0;
}

