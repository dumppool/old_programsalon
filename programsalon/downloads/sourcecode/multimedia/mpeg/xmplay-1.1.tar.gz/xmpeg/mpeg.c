
/* --- C ---
************************************************************************
*
*	Filename    : mpeg.c
*	Description : playing routines
*	Part of     : XMPEG - X11-MPEG-player
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#include <stdlib.h>
#include <stdio.h>

#ifdef NETINET
#ifndef MIPS
#include <sys/types.h>
#include <netinet/in.h>
#else
#include <bsd/netinet/in.h>
#endif
#endif

#include "video.h"
#include "proto.h"
#include "util.h"
#include "xmpeg.h"


typedef struct tag_BUFFER_ENTRY
{
	unsigned int offset;
	unsigned int frame;
}
BUFFER_ENTRY;

static BUFFER_ENTRY *xm_buffer;			/* xmpeg offset-buffer */
static unsigned int xm_buffer_length;	/* used buffer_space */

static int xm_buffer_pos;
static int xm_rewind_count;
static int xm_forward_count;
static int xm_skip_frame;
static int xm_insufficient_buffer_space;

static int XM_BUFFER_COMPLETE;			/* true, if all picture offsets */
										/* are buffered */


/* External declarations of bitstream global variables. (util.c) */

extern unsigned int curBits;
extern int bitOffset;
extern int bufLength;					/* current buffer_offset */
extern unsigned int *bitBuffer;


/* External declarations of global File variable. (main.c) */

extern FILE *input;
extern VidStream *theStream;

static int set_stream_pos ();
static int get_buffer_pos ();
static int previous_intra_frame ();
static int previous_start_code ();
static int restore_data ();
static int next_intra_frame ();

int xmpeg_init ()
{
	xm_stream_offset = 0;
	xm_stream_length = 0;
	xm_buffer_pos = 0;
	xm_rewind_count = 0;
	xm_forward_count = 0;
	xm_buffer_length = 0;
	xm_current_frame = 0;
	xm_skip_frame = 0;
	xm_skip = 0;
	xm_insufficient_buffer_space = FALSE;
	xm_oldstatus = XM_FIRST;
	XM_STATUS = XM_FIRST;
	XM_BUFFER_COMPLETE = FALSE;
	XING = FALSE;

	if (input != stdin) /* Input from File ! */
	{
		fseek (input, 0L, 2);
		xm_stream_length = (unsigned int) ftell (input);
		rewind (input);
	}
 
	xm_buffer = (BUFFER_ENTRY *) malloc (XM_BUF_SIZE * sizeof (BUFFER_ENTRY));
	if (!xm_buffer) return (-1);
	memset ((void *)xm_buffer, 0, XM_BUF_SIZE * sizeof (BUFFER_ENTRY));
	return (0);
}

void xmpeg_exit (error)
int error;
{
	if (xm_buffer) free (xm_buffer);
	if (theStream) DestroyVidStream (theStream);
	FreeMostResources ();
	exit (error);
}

int xmpeg_first (vid_stream)
VidStream *vid_stream;
{
	xm_stream_offset = xm_buffer [0].offset;
	XM_STATUS = set_stream_pos (vid_stream, 0);
	xm_current_frame = 0;
	xm_skip_frame = 0;
	get_buffer_pos (RESET);
	set_references (vid_stream, RESET);
	return (XM_STATUS);
}

void xmpeg_sequence_end ()
{ 
	static int eof = 0;

	if (!eof)
	{ 
		if (!xm_insufficient_buffer_space)
		XM_BUFFER_COMPLETE = TRUE;

		if (xm_stream_offset < xm_stream_length)
			fprintf (stderr, " more data after SEQ_END_CODE !!!! \n");
		eof++;
	}
	xm_skip_frame = (XING) ? XING_SKIP : xm_skip;
}


/*
	function is called from ParsePicture (video.c)

	parameter: frame_type
	returnvalue: none
*/

void xmpeg_set_entry (frame_type)
unsigned int frame_type;
{
	unsigned int stream_offset;

	if (frame_type == I_TYPE)
	{
		switch (XM_STATUS)
		{
			case XM_PLAY:
			case XM_STEP:
			case XM_SLOW_MOTION:
			case XM_FIRST:
			case XM_FORWARD:
			case XM_FAST_FORWARD:
				xm_current_frame++;
				break;
			case XM_REWIND:
			case XM_FAST_REWIND:
				xm_current_frame--;
				break;
			default:
				XM_STATUS = XM_EXIT;
				return;
		}
 
		if (xm_skip_frame)
		{
			xm_skip_frame--;
			return;
		} 
		xm_skip_frame = (XING) ? XING_SKIP : xm_skip;

		switch (XM_STATUS)
		{
			case XM_PLAY:
			case XM_STEP:
			case XM_SLOW_MOTION:
				xm_buffer_pos = get_buffer_pos (INC);
				break;
			case XM_FIRST:
				xm_buffer_pos = get_buffer_pos (RESET);
				break;
			case XM_FORWARD:
			case XM_FAST_FORWARD:
				xm_buffer_pos = get_buffer_pos (INC);
				break;
			case XM_REWIND:
			case XM_FAST_REWIND:
				xm_buffer_pos = get_buffer_pos (DEC);
				break;
			default:
				XM_STATUS = XM_EXIT;
				return;
		}

		xm_buffer [xm_buffer_pos].frame = xm_current_frame;
 
		if (XM_BUFFER_COMPLETE) return;
		else
		{
			/* xmpeg_set_entry is called from ParsePicture () */
			/* after parsing the header-start-code, temporal */
			/* reference and picture-type. So we must first */
			/* subtract 4 Bytes from the stream_offset for the */
			/* marker, then subtract 13 bits from bitOffset. */
			/* final we have correct the stream-offset */

			stream_offset = xm_stream_offset - (bufLength * 4) - 4;
			switch (bitOffset - 13)
			{
				case 16:
					stream_offset += 2;
					break;
				case 8:
					stream_offset += 1;
					break;
				case 0: break;
				default:
					stream_offset -= 1;
					break;
			}
			xm_buffer [xm_buffer_pos].offset = stream_offset;
		}
	}
	else /* frame_type */
	{
		switch (XM_STATUS)
		{
			case XM_PLAY:
			case XM_STEP:
			case XM_SLOW_MOTION:
			case XM_FIRST:
			case XM_FORWARD:
			case XM_FAST_FORWARD:
				xm_current_frame++;
				break;
			case XM_REWIND:
			case XM_FAST_REWIND:
				xm_current_frame--;
				break;
			default:
				XM_STATUS = XM_EXIT;
				return;
		}
	}
}

static int set_stream_pos (vid_stream, buffer_pos)
VidStream *vid_stream;
int buffer_pos;
{
	int status = XM_EXIT;
	int ret;
 
	curVidStream = vid_stream;
	bitOffset = 0;
	bufLength = 0;
	bitBuffer = curVidStream->buffer;

	xm_stream_offset = xm_buffer [buffer_pos].offset; 
	ret = fseek (input, (long)xm_buffer [buffer_pos].offset, 0);
 
	xm_current_frame = xm_buffer [buffer_pos].frame - 1;

	if (ret != 0) return (status);

	ret = get_more_data (curVidStream->buf_start,
		curVidStream->max_buf_length, &bufLength, &bitBuffer);

	if (ret < 0) return (status);

	curVidStream->buffer = bitBuffer;
	curVidStream->buf_length = bufLength;
	curVidStream->bit_offset = bitOffset;
	curBits = *curVidStream->buffer;

	return (XM_STATUS);
}

static int get_buffer_pos (value)
int value;
{ 
	int buffer_pos = -1;

	switch (value)
	{
		case RESET:
			xm_buffer_pos = 0;
			if (!XM_BUFFER_COMPLETE)
			{
				xm_forward_count = 0;
				memset ((void *)xm_buffer, 0,
					XM_BUF_SIZE * sizeof (BUFFER_ENTRY));
			}
			else xm_forward_count += xm_rewind_count;
			xm_rewind_count = 0;
			break;
		case INC:
			xm_buffer_pos++;
			xm_buffer_pos %= XM_BUF_SIZE;
			if (!xm_buffer_pos)
			{ 
				xm_buffer_pos++;
				xm_insufficient_buffer_space = TRUE;
			} 

			xm_rewind_count++;
			if (xm_rewind_count == XM_BUF_SIZE)
			xm_rewind_count--;

			if (xm_forward_count) xm_forward_count--;
			else
			{ 
				if (!XM_BUFFER_COMPLETE)
				{
					xm_buffer [xm_buffer_pos].offset = 0;
					xm_buffer [xm_buffer_pos].frame = 0;
				}
			}
			break;
		case DEC:
			xm_buffer_pos--;
			xm_buffer_pos %= XM_BUF_SIZE;
			if (!xm_buffer_pos)
			{ 
				xm_buffer_pos = XM_BUF_SIZE - 1;
				xm_insufficient_buffer_space = TRUE;
			} 

			if (xm_rewind_count) xm_rewind_count--;
			else
			{
				if (!XM_BUFFER_COMPLETE)
				{
					xm_buffer [xm_buffer_pos].offset = 0;
					xm_buffer [xm_buffer_pos].frame = 0;
				}
			}

			if (xm_forward_count != (XM_BUF_SIZE-1))
			xm_forward_count++;
			break;
		case CURRENT:
			break;
		case NEXT:
			if (xm_forward_count)
			{
				buffer_pos = xm_buffer_pos + 1;
				buffer_pos %= XM_BUF_SIZE;
 
				if (!buffer_pos) buffer_pos++;
			}
			else if (XM_BUFFER_COMPLETE) buffer_pos = 0;
			return (buffer_pos);
			break;
		case PREVIOUS:
			if (xm_rewind_count > 1)
			{
				buffer_pos = xm_buffer_pos - 1;
				buffer_pos %= XM_BUF_SIZE;

				if (!buffer_pos) buffer_pos = XM_BUF_SIZE - 1;
			}
			else if (XM_BUFFER_COMPLETE) buffer_pos = 0;
			return (buffer_pos);
			break;
		default:
			XM_STATUS = XM_EXIT;
			break;
	}
	return (xm_buffer_pos);
}

int xmpeg_forward (time_stamp, vid_stream)
TimeStamp time_stamp;
VidStream *vid_stream;
{ 
	int buffer_pos;
	int status;

	/* xm_skip_frame = (XING) ? XING_SKIP : xm_skip; */
	buffer_pos = get_buffer_pos (NEXT);
	switch (buffer_pos)
	{
		case 0:
			status = XM_END;
			break;
		case -1:
			while (TRUE)
			{
				status = next_intra_frame (time_stamp, vid_stream);
				if (status == XM_END) break;
				else
				{
					if (XING)
					{
						if (xm_skip_frame == XING_SKIP)
						break;
					} 
					else
					if (xm_skip_frame == xm_skip) break;
				}
			}
			break;
		default:
			status = set_stream_pos (vid_stream, buffer_pos);
			xm_current_frame = xm_buffer [buffer_pos].frame - 1;
			break;
	}
	return (status);
}

/*
int xmpeg_fast_forward (time_stamp, vid_stream)
TimeStamp time_stamp;
VidStream *vid_stream;
{
	return (xmpeg_forward (time_stamp, vid_stream));
}
*/

static int next_intra_frame (time_stamp, vid_stream) 
TimeStamp time_stamp;
VidStream *vid_stream;
{ 
	unsigned int data;
	int status = XM_FORWARD;
	int ret;

	curVidStream = vid_stream;
	bitOffset = curVidStream->bit_offset;

#ifdef UTIL2
	curBits = *curVidStream->buffer << bitOffset;
#else
	curBits = *curVidStream->buffer;
#endif
	bufLength = curVidStream->buf_length;
	bitBuffer = curVidStream->buffer;

	while (1)
	{ 
		next_start_code ();
		show_bits32 (data);
 
		switch (data)
		{
			case PICTURE_START_CODE:
				ret = ParsePicture (vid_stream, time_stamp);
				switch (ret)
				{
					case SKIP_PICTURE:
						status = XM_FORWARD;
						break;
					case PARSE_OK: 
						if (vid_stream->picture.code_type == I_TYPE)
						{
							status = XM_FORWARD;
							goto done;
						}
						break;
					default: 
						status = XM_EXIT;
						break;
				}
				break; 
			case GOP_START_CODE:
				if (ParseGOP (vid_stream) != PARSE_OK)
				{
					status = XM_EXIT;
					goto done;
				} 
				break;
			case SEQ_START_CODE:
				if (ParseSeqHead (vid_stream) != PARSE_OK)
				{
					status = XM_EXIT;
					goto done;
				} 
				break;
			case SEQ_END_CODE:
				xmpeg_sequence_end (); 
				status = XM_END;
				goto done;
			default:
				flush_bits32;
				break;
		}
	} 

done:
	vid_stream->buffer = bitBuffer;
	vid_stream->buf_length = bufLength;
	vid_stream->bit_offset = bitOffset;
	return (status);
}


#define get_byte(result)                       \
{                                              \
  if (!bitOffset)                              \
  {                                            \
    bitOffset += 32;                           \
    bitBuffer--;                               \
    curBits = *bitBuffer;                      \
    bufLength++;                               \
  }                                            \
  result = curBits & 0x000000ff;               \
  curBits >>= 8;                               \
  bitOffset -= 8;                              \
}                                              

#define get_trailer(result)                                     \
{                                                               \
  switch(bitOffset)                                             \
  {                                                             \
     case  0: result = *bitBuffer & 0x000000ff ;                \
              break;                                            \
     case  8: result = (*(bitBuffer+1) & 0xff0000ff) >> 24;     \
              break;                                            \
     case 16: result = (*(bitBuffer+1) & 0x00ff0000) >> 16;     \
              break;                                            \
     case 24: result = (*(bitBuffer+1) & 0x0000ff00) >>  8;     \
              break;                                            \
  }                                                             \
}

#define get_ptype(result)                                       \
{                                                               \
    switch(bitOffset)                                           \
    {                                                           \
        case  0: result = (*(bitBuffer+1) & 0x00ff0000) >> 16;  \
                 break;                                         \
        case  8: result = (*(bitBuffer+1) & 0x0000ff00) >>  8;  \
                 break;                                         \
        case 16: result = *(bitBuffer+1) & 0x000000ff;          \
                 break;                                         \
        case 24: result = (*(bitBuffer+2) & 0xff000000) >> 24;  \
                 break;                                         \
     }                                                          \
     result = ((result & 56) >> 3);                             \
}

#define FRAME_START_CODE 0x000001c0
#define I_FRAME_START_CODE 0x000001c1
#define P_FRAME_START_CODE 0x000001c2
#define B_FRAME_START_CODE 0x000001c3

int xmpeg_rewind (time_stamp, vid_stream, status_changed)
TimeStamp time_stamp;
VidStream *vid_stream;
int status_changed;
{
	int status;
	int buffer_pos;
 
	buffer_pos = get_buffer_pos (PREVIOUS);
 
	switch (buffer_pos)
	{
		case 0:
			status = XM_START;
			xm_current_frame = -1;
			break;
		case -1:
			xm_skip_frame = (XING) ? XING_SKIP : xm_skip;
			status = previous_intra_frame (time_stamp, vid_stream,
				status_changed);
			break;
		default:
			xm_skip_frame = 0;
			status = set_stream_pos (vid_stream, buffer_pos);
			xm_current_frame = xm_buffer [buffer_pos].frame + 1;
			break;
	}
	return (status);
}

/*
int xmpeg_fast_rewind (time_stamp, vid_stream, status_changed)
TimeStamp time_stamp;
VidStream *vid_stream;
int status_changed;
{
	return (xmpeg_rewind (time_stamp, vid_stream, status_changed));
}
*/

static int previous_intra_frame (time_stamp, vid_stream, status_changed)
TimeStamp time_stamp;
VidStream *vid_stream;
int status_changed;
{ 
	unsigned int data;
	static unsigned int last_i_frame;
 
	int status = XM_REWIND;

	curVidStream = vid_stream;
	bitOffset = curVidStream->bit_offset;

#ifdef UTIL2
	curBits = *curVidStream->buffer << bitOffset;
#else
	curBits = *curVidStream->buffer;
#endif

	bufLength = curVidStream->buf_length;
	bitBuffer = curVidStream->buffer;
 
	/* get last intra frame offset */

 
	xm_current_frame = xm_buffer [get_buffer_pos (CURRENT)].frame;
	last_i_frame = xm_buffer [get_buffer_pos (CURRENT)].offset; 

	/* calculate sensible start position */
	/* align offset to unsigned int boundary */

	last_i_frame = ((last_i_frame / 4) * 4);

	/* flush possible start code */
 
	last_i_frame -= 8;

	/* if the function is called the first time, then */
	/* the data inside the buffer is corrupt, else */
	/* check if requested offset is inside the buffer */ 

	/* if (status_changed) */
	restore_data (last_i_frame, status_changed);

	while (1)
	{
		/* call previous start code */

		previous_start_code (&data);
		switch (data)
		{
			case I_FRAME_START_CODE:
				if ((xm_stream_offset - 4 * bufLength) <= xm_buffer [0].offset)
				{
					status = XM_START;
					xm_current_frame = -1;
					goto done;
				}
 
				if (xm_skip_frame)
				{ 
					xm_skip_frame--;
					xmpeg_set_entry (B_TYPE);
					break;
				}
				curBits = *bitBuffer;curBits <<= bitOffset;

				/* xm_current_frame++; */

				switch (ParsePicture (vid_stream, time_stamp))
				{
					case SKIP_PICTURE:
						break;
					case PARSE_OK: 
						break;
					default: 
						status = XM_EXIT;
						break;
				}
				goto done;
				break; 
			case P_FRAME_START_CODE:
				xmpeg_set_entry (P_TYPE);
				break; 
			case B_FRAME_START_CODE:
				xmpeg_set_entry (B_TYPE);
				break; 
			case GOP_START_CODE:
				break;
			case SEQ_START_CODE:
				curBits = *bitBuffer;curBits <<= bitOffset; 
				status = XM_START;
				xm_current_frame = -1;
				goto done;
				break;
			case SEQ_END_CODE:
				status = XM_EXIT;
				goto done;
			default:/* Slice */
				break;
		}
	} 

done:
	vid_stream->buffer = bitBuffer;
	vid_stream->buf_length = bufLength;
	vid_stream->bit_offset = bitOffset;
 
	return (status);
}

/*
	restore data is called only from previous_intra_frame ()
	and previous_start_code () 
*/

static int restore_data (last_frame, fill_buffer)
unsigned int last_frame;
int fill_buffer;
{
	int status;
	int num_read, i;
	long seek_pos = 0L;
	unsigned int max_buffer_length;
	unsigned int offset;
	unsigned int buffer_start = 0;
	unsigned int buffer_offset = 0;
	unsigned int *ptr;

	max_buffer_length = (unsigned int) curVidStream->max_buf_length * 4;
	ptr = curVidStream->buf_start;
	buffer_start = xm_stream_offset - xm_current_buffer_length;
 
	if (!last_frame)
	{
		offset = buffer_start + 8;
		fill_buffer = TRUE;
	}
	else offset = last_frame;

	/* calculate seek position */

	if (offset > max_buffer_length)
		seek_pos = (long) (offset - max_buffer_length);
 
	if (!fill_buffer)
	{
		/* check if requested offset is inside the buffer */

		if (offset > (buffer_start + 8))
		{
			/* inside the buffer, set bufLength and bitBuffer */

			buffer_offset = offset - buffer_start;
			bitBuffer = curVidStream->buf_start + (buffer_offset / 4);
			bufLength = (xm_current_buffer_length - buffer_offset) / 4;
 
			bitOffset = 32;
			curBits = *bitBuffer;
 
			return (0);
		}
	}

	status = fseek (input, seek_pos, 0);
	if (status != 0) return (XM_EXIT);
 
	num_read = fread ((unsigned char *)ptr, 1, max_buffer_length, input);
	if (num_read < 0) return (XM_EXIT);
 
	num_read /= 4;
	xm_current_buffer_length = num_read * 4;
	for (i = 0;i < num_read;i++) *ptr++ = htonl (*ptr);
	xm_stream_offset = (unsigned int) ftell (input);
 
	bufLength = (max_buffer_length - xm_current_buffer_length) / 4;
	bitBuffer = curVidStream->buf_start + (xm_current_buffer_length / 4);
 
	if (!seek_pos)
	{ 
		buffer_offset = (xm_current_buffer_length - offset) / 4;
		bufLength += buffer_offset;
		bitBuffer -= buffer_offset;
	}
	if (!last_frame)
	{
		bitBuffer -= 2;
		bufLength += 2;
	}
	bitOffset = 32;
	curBits = *bitBuffer;

	return (0);
}
 
static int previous_start_code (start_code)
unsigned int *start_code;
{
	int sc [3];
	int index = 0;
	int max_buf_len;
	int status = XM_STATUS;
	unsigned int ptype;
	unsigned int trailer;

	/* If no current stream, return error. */

	if (curVidStream == NULL) return (XM_EXIT);

	max_buf_len = curVidStream->max_buf_length;
 
	*start_code = 1;
	*start_code <<= 8;
 
	sc [0]= sc [1]= sc [2]= 0xff;

	while (1)
	{
		if (bufLength < max_buf_len)
		{ 
			get_byte (sc [index]);

			if ((sc [0]+ sc [1]+ sc [2]) == 1)
			{
				switch (index)
				{
					case 0:
						if (sc [1]) goto done;
						break;
					case 1:
						if (sc [2]) goto done;
						break;
					case 2:
						if (sc [0]) goto done;
						break;
				}
			} 
			index++;
			index %= 3;
		}
		else restore_data (0, 1);
	}

done:
	get_trailer (trailer);
	*start_code |= trailer;

	if (*start_code == PICTURE_START_CODE)
	{
		get_ptype (ptype);
		*start_code = FRAME_START_CODE | ptype;
	} 
	return (status); 
}

