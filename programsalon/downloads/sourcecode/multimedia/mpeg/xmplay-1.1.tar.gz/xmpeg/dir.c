
/* --- C ---
************************************************************************
*
*	Filename    : dir.c
*	Description : main window functions
*	Part of     : XMPEG - X11-MPEG-player
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#define NEEDSVIDEO
#include "xmpeg.h"
#include "playmaps.h"
#include "proto.h"

static Pixmap closePix, aboutPix, firstPix, rewindPix, pausePix;
static Pixmap playPix, stepPix, forwardPix, infoPix;

#define CLKPATTERN "00:00.00"

void CreateDirW (geom, mpw, mph)
char *geom;
int mpw, mph;
{
	int i;
	int w;

	if (mpw > dirWIDE-20) dirWIDE = mpw + 20;
	if (mph > dirHIGH-58) dirHIGH = mph + 58 + BUTTPH;
	w = (dirWIDE-50)/S_NBUTTS;

	dirW = CreateWindow (PROGNAME, geom, dirWIDE, dirHIGH, infofg, infobg);
	if (!dirW) FatalError ("couldn't create window!");

	CreateIcons ();
	closePix = XCreatePixmapFromBitmapData (theDisp, dirW, close_bits,
		close_width, close_height, 1, 0, 1);
	aboutPix = XCreatePixmapFromBitmapData (theDisp, dirW, about_bits,
		about_width, about_height, 1, 0, 1);
	firstPix = XCreatePixmapFromBitmapData (theDisp, dirW, first_bits,
		first_width, first_height, 1, 0, 1);
	rewindPix = XCreatePixmapFromBitmapData (theDisp, dirW, rewind_bits,
		rewind_width, rewind_height, 1, 0, 1);
	pausePix = XCreatePixmapFromBitmapData (theDisp, dirW, pause_bits,
		pause_width, pause_height, 1, 0, 1);
	playPix = XCreatePixmapFromBitmapData (theDisp, dirW, play_bits,
		play_width, play_height, 1, 0, 1);
	stepPix = XCreatePixmapFromBitmapData (theDisp, dirW, step_bits,
		step_width, step_height, 1, 0, 1);
	forwardPix = XCreatePixmapFromBitmapData (theDisp, dirW, forward_bits,
		forward_width, forward_height, 1, 0, 1);
	infoPix = XCreatePixmapFromBitmapData (theDisp, dirW, info_bits,
		info_width, info_height, 1, 0, 1);

	for (i=0; i<S_NBUTTS; i++)
	{
		BTCreate (&dbut [i], dirW, 10+i*(w+BUTTS)+((i>1)*10)+((i==8)*10),
			dirHIGH-30, w, BUTTPH, "", infofg, pl, hicol, locol);
	}
	BTSetActive (&dbut [S_BFIRST], 0);
	BTSetActive (&dbut [S_BREWIND], 0);
	BTSetActive (&dbut [S_BPAUSE], 0);

	dbut [S_BCLOSE].pix = closePix;
	dbut [S_BCLOSE].pw = close_width;
	dbut [S_BCLOSE].ph = close_height;

	dbut [S_BABOUT].pix = aboutPix;
	dbut [S_BABOUT].pw = about_width;
	dbut [S_BABOUT].ph = about_height;

	dbut [S_BFIRST].pix = firstPix;
	dbut [S_BFIRST].pw = first_width;
	dbut [S_BFIRST].ph = first_height;

	dbut [S_BREWIND].pix = rewindPix;
	dbut [S_BREWIND].pw = rewind_width;
	dbut [S_BREWIND].ph = rewind_height;

	dbut [S_BPAUSE].pix = pausePix;
	dbut [S_BPAUSE].pw = pause_width;
	dbut [S_BPAUSE].ph = pause_height;

	dbut [S_BPLAY].pix = playPix;
	dbut [S_BPLAY].pw = play_width;
	dbut [S_BPLAY].ph = play_height;

	dbut [S_BSTEP].pix = stepPix;
	dbut [S_BSTEP].pw = step_width;
	dbut [S_BSTEP].ph = step_height;

	dbut [S_BFORWARD].pix = forwardPix;
	dbut [S_BFORWARD].pw = forward_width;
	dbut [S_BFORWARD].ph = forward_height;

	dbut [S_BINFO].pix = infoPix;
	dbut [S_BINFO].pw = info_width;
	dbut [S_BINFO].ph = info_height;

	XMapSubwindows (theDisp, dirW);
	XSelectInput (theDisp, dirW, ExposureMask | ButtonPressMask
		| KeyPressMask | LeaveWindowMask);
	XMapRaised (theDisp, dirW);
	XDefineCursor (theDisp, dirW, arrow);
}

void RedrawClock ()
{
	int x = dirWIDE-StringWidth (CLKPATTERN)-3;
	char tstr [10];
	int min;
	double sec;
	int frame = xm_current_frame;

	if (theStream->picture_rate != 0)
	{
		if (frame == 1) frame = 0;
		else frame -= 2;
		SetNormal ();
		XSetForeground (theDisp, theGC, infobg);
		XFillRectangle (theDisp, dirW, theGC, x+1, 0, dirWIDE-x+2, 22);
		XSetForeground (theDisp, theGC, infofg);
		sec = (double) (frame) / (double) theStream->picture_rate;
		min = (int) sec / 60;
		sec = sec - (double) (min * 60);
		if (sec < 10.0) sprintf (tstr, "%02d:0%2.2f", min, sec);
		else sprintf (tstr, "%02d:%2.2f", min, sec);
		XDrawString (theDisp, dirW, theGC, x+2, 4+ASCENT, tstr, strlen (tstr));
	}
}

void RedrawDirW ()
{
	int i;
	char *ptr;
	int x = dirWIDE-StringWidth (CLKPATTERN)-3;

	ExecuteDisplay (theStream);
	XSetBackground (theDisp, theGC, infobg);
	XSetForeground (theDisp, theGC, infofg);
	SetBold ();
	XDrawString (theDisp, dirW, theGC, 10, 4+ASCENT, "Path:", 5);
	if (!filename) ptr = STDINSTR;
	else ptr = ShortCutPath (filename, dirWIDE-25
		-StringWidth ("Path:")-StringWidth (CLKPATTERN));
	XDrawString (theDisp, dirW, theGC, StringWidth ("Path:")+15,
		4+ASCENT, ptr, strlen (ptr));
	XDrawLine (theDisp, dirW, theGC, 0, 23, dirWIDE, 23);
	SetNormal ();

	XDrawLine (theDisp, dirW, theGC, 0, dirHIGH-38, dirWIDE, dirHIGH-38);
	XDrawLine (theDisp, dirW, theGC, x, 0, x, 23);
	RedrawClock ();
	for (i=0; i<S_NBUTTS; i++) BTRedraw (&dbut [i]);
	XFlush (theDisp);
}

void SetButtonX (bp, x)
BUTT *bp;
int x;
{
	bp->x = x;
}

void SetButtonY (bp, y)
BUTT *bp;
int y;
{
	bp->y = y;
}

void SetButtonW (bp, w)
BUTT *bp;
int w;
{
	bp->w = w;
}

int ClickDirW (x, y)
int x, y;
{
	BUTT *bp;
	int bnum;

	for (bnum=0;bnum<S_NBUTTS;bnum++)
	{
		bp = &dbut [bnum];
		if (PTINRECT (x, y, bp->x, bp->y, bp->w, bp->h)) break;
	}
	if (bnum<S_NBUTTS) if (BTTrack (bp)) return (bnum);
	return -1;
}

