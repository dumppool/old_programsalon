
/* --- C ---
************************************************************************
*
*	Filename    : xmpeg.h
*	Description : general header
*	Part of     : XMPEG - X11-MPEG-player
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#define REVDATE   "Rev: 01/01/94"

#include <stdio.h>
#include <ctype.h>
#include <string.h>

#ifdef NEEDSVIDEO
#include "video.h"
#endif

extern int   errno;
extern char *sys_errlist[];

/* neither IBM AOS 4.3, Convex, nor BSD 4.3 on VAX have <malloc.h> */
#if !defined(ibm032) && !defined(__convexc__) && \
    !(defined(vax) && !defined(ultrix))
#if defined(hp300) || defined(hp800)
#include <sys/malloc.h>
#else
#include <malloc.h>
#endif
#endif

#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include <X11/keysym.h>

#if defined(NEEDSTIME)
#include <sys/types.h>
#endif

#ifdef NEEDSTIME
#include <sys/time.h>
#include <signal.h>
#if defined(SCO) && !defined(NOTIMER)
#include <sys/itimer.h>
#endif
#ifndef  sigmask
#define  sigmask(m)      (1 << ((m)-1))
#endif
#endif

#ifdef NEEDSDIR
#ifdef SCO
#include <sys/ndir.h>
#define lstat stat
#endif
#include <sys/param.h>
#include <sys/stat.h>
#include <pwd.h>
#endif

#ifdef SYSV
#define HOLD_SIG         sighold(SIGALRM)
#define RELEASE_SIG      sigrelse(SIGALRM)
#define PAUSE_SIG        sigpause(SIGALRM)
#else
#define HOLD_SIG         sigblock(sigmask(SIGALRM))
#define RELEASE_SIG      sigblock(0)
#define PAUSE_SIG        sigpause(0)
#endif

#ifdef i386
#undef  HOLD_SIG
#define HOLD_SIG
#undef  RELEASE_SIG
#define RELEASE_SIG
#undef  PAUSE_SIG
#define PAUSE_SIG
#endif

#ifndef MAXPATHLEN
#define MAXPATHLEN    512
#endif

#define PROGNAME	"xmpeg"
#define DEFDIRGEOM	"+300+200"

#define DIRWIDE		300
#define DIRHIGH		220
#define BIGWIDE		1000
#define BIGHIGH		700

#define DEFFILENAME	""

#define S_NBUTTS	9
#define S_BCLOSE	0
#define S_BABOUT	1
#define S_BFIRST	2
#define S_BREWIND	3
#define S_BPAUSE	4
#define S_BPLAY 	5
#define S_BSTEP		6
#define S_BFORWARD	7
#define S_BINFO		8

#define S_SBUTTS	2
#define S_SOK		0
#define S_SCANCEL	1

#define BUTTW		60
#define BUTTH		19
#define BUTTPH		24
#define BUTTS		2

#define ASCENT		(cfinfo->ascent)

#define STDINSTR "<stdin>"
#define DITHERMAX	13


#ifndef MAIN
#define WHERE extern
#else
#define WHERE
#endif

typedef struct
{
	Window win;
	int x, y, w, h;
	int lit;
	int active;
	int toggle;
	u_long fg, bg, hi, lo;
	char *str;
	Pixmap pix;
	int pw, ph;
	int style;
	int fwidth;
} BUTT;

typedef struct rbutt
{
	Window win;
	int x,y;
	char *str;
	int selected;
	int active;
	struct rbutt *next;
	u_long fg, bg, hi, lo;
} RBUTT;

typedef struct cbutt
{
	Window win;
	int x, y;
	char *str;
	int val;
	int active;
	u_long fg, bg, hi, lo;
} CBUTT;


#define R3D_OUT		0
#define R3D_IN		1

#define CENTERX(f,x,str) ((x)-XTextWidth(f,str,strlen(str))/2)
#define CENTERY(f,y) ((y)-((f->ascent+f->descent)/2)+f->ascent)
#define RANGE(a,b,c) { if (a<b) a=b;  if (a>c) a=c; }
#define PTINRECT(x,y,rx,ry,rw,rh) \
           ((x)>=(rx) && (y)>=(ry) && (x)<=(rx)+(rw) && (y)<=(ry)+(rh))

#define ASCENT		(cfinfo->ascent)
#define DESCENT		(cfinfo->descent)
#define CHIGH		(ASCENT + DESCENT)

#define COLOR		0
#define GRAYSCALE	1
#define MONO		2
#define FULLCOLOR	3

WHERE Display		*theDisp;
WHERE int			theScreen;
WHERE unsigned int	ncells, dispWIDE, dispHIGH, dispDEEP;
WHERE Colormap		theCmap;
WHERE Window		rootW;
WHERE GC			theGC;
WHERE unsigned long	black, white, fg, bg, pl, infofg, infobg, hicol, locol;
WHERE Font			mfont, bfont;
WHERE XFontStruct	*mfinfo, *bfinfo, *cfinfo;
WHERE Visual		*theVisual;
WHERE Cursor		arrow, target, hand;

WHERE char			*displaystr, *whitestr, *blackstr, *fgstr, *bgstr, *plstr;
WHERE char			*histr, *lostr, *ditherstr;

WHERE char			*maingeom;
WHERE char			*cmd;
WHERE int			mono;

WHERE int			ncols;
WHERE int			bwidth;
WHERE int			ctrlColor;

WHERE Pixmap		grayStip;

WHERE Window		dirW, diaW, aboutW, ditherW, infW;
WHERE BUTT			dbut[S_NBUTTS], sbut[S_SBUTTS];
WHERE RBUTT			*ditherRB;
WHERE int			dirWIDE, dirHIGH;
WHERE char			*dirGEOM;

WHERE char			*filename;
WHERE FILE			*input;
WHERE long			filesize;

#ifdef NEEDSVIDEO
WHERE VidStream		*theStream;
WHERE int			firstframe;
#endif

WHERE int			iconic, dblclk, loop;
WHERE char			*icongeom;


/* exported from MISC.C */

Window CreateWindow();
int StringWidth();
void SetBold (), SetNormal (), ExposureWin (), Timer(), FatalError();
void Draw3dRect (), DimRect ();
void CreateIcons (), FreeMostResources (), Syntax ();
int DetectDisplayType ();


/* exported from DIR.C */

void CreateDirW (), RedrawDirW ();
int ClickDirW ();
void RedrawClock ();


/* exported from HANDLE.C */

void DoAbout (), DoDither ();


/* exported from INFO.C */

void DoInfo ();


/* exported from BUTT.C */

void BTCreate(), BTSetActive(), BTSetAllActive (), BTSetAllInActive ();
void BTSetStyle (), BTRedraw();
int  BTTrack(), RBTrack();
RBUTT *RBCreate();
void RBRedraw(), RBSelect();


/* exported from DIALOG.C */

void CreateAboutW (), RedrawAboutW (); int AboutEventLoop ();
void CreateDitherW (), RedrawDitherW (); int DitherEventLoop ();
void CreateInfW (), RedrawInfW (); int InfoEventLoop ();
void CreateErrW (), RedrawErrW (); int ErrorEventLoop ();

char *ShortCutPath (), *ShortCutName ();


/* exported from MPEG.C */

int          xmpeg_init();
void         xmpeg_exit();

void         xmpeg_set_entry();
int          xmpeg_first();
int          xmpeg_forward();
int          xmpeg_rewind();
void         xmpeg_sequence_end();

/* not needed anymore
int          xmpeg_fast_forward();
int          xmpeg_fast_rewind();
*/

/* exported from XVIDEO.C */

void         xmpeg_display_picture();
void         set_references();
int          xmpeg_Vid_Info();
int          xmpeg_VidRsrc();


/* exported from EVENT.C */

int          EventLoop();


#define XM_BUF_SIZE 8 * 1024        /* Buffersize for offset-buffer */
                                    /* min Buffer Size = 2 !!!      */

#define XM_PAUSE        1           /* flags for buttons            */
#define XM_PLAY         2
#define XM_STEP         3
#define XM_FORWARD      4
#define XM_REWIND       5
#define XM_FIRST        6
#define XM_EXIT         7
#define XM_FAST_FORWARD 8
#define XM_SLOW_MOTION  9
#define XM_FAST_REWIND 10
#define XM_END         11
#define XM_START       12

#define RESET           0
#define INC             1
#define DEC             2
#define NEXT            3
#define CURRENT         4
#define PREVIOUS        5
#define UPDATE          6

#define XING_SKIP       8
#define XM_DELAY        500


WHERE int           XING;                  /* stream contains only i-frames */
WHERE int           XM_STATUS;             /* current status of the player  */
WHERE int           xm_oldstatus;          /* previous status of the player */
WHERE int			xm_zoom;               /* is the window zoomed ?        */
    
WHERE int           xm_current_frame;      /* current frame position 1 .. n */
WHERE int           xm_skip;                                 

WHERE unsigned int  xm_stream_offset;      /* current-stream-offset         */
WHERE unsigned int  xm_stream_length;      /* current-stream-len(if !stdin) */

WHERE unsigned int  xm_current_buffer_length;

#undef WHERE

