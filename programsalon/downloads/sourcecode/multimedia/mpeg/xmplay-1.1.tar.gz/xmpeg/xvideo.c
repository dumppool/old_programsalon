
/* --- C ---
************************************************************************
*
*	Filename    : xvideo.c
*	Description : video routines
*	Part of     : XMPEG - X11-MPEG-player
*
*	Version     : 1.1
*	Date        : Tue Apr  4 14:06:10 MET DST 1995
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#ifndef MIPS
#include <sys/time.h>
#else
#include <sys/types.h>
#include <sys/system.h>
#endif

#include "decoders.h"
#include "video.h"
#include "util.h"
#include "proto.h"
#include "xmpeg.h"


/* External declarations of bitstream global variables. (util.c) */

extern unsigned int curBits;
extern int bitOffset;
extern int bufLength; /* current buffer_offset */
extern unsigned int *bitBuffer;

/* external declaration of global pointer to vid stream */

extern VidStream *curVidStream;


int xmpeg_Vid_Info (vid_stream)
VidStream *vid_stream;
{
	unsigned int data;
 
	curVidStream = vid_stream;
	bitOffset = curVidStream->bit_offset;
#ifdef UTIL2
	curBits = *curVidStream->buffer << bitOffset;
#else
	curBits = *curVidStream->buffer;
#endif
	bufLength = curVidStream->buf_length;
	bitBuffer = curVidStream->buffer;

	next_start_code ();
	show_bits32 (data);
	if (data != SEQ_START_CODE) return (0);

	do
	{
		show_bits32 (data);
		switch (data)
		{
			case SEQ_START_CODE:
				if (ParseSeqHead (vid_stream) != PARSE_OK) return (0);
				break;
			case GOP_START_CODE:
				if (ParseGOP (vid_stream) != PARSE_OK) return (0);
				if (!vid_stream->group.closed_gop)
				{
#ifndef NDEBUG
/*					fprintf (stdout, " XING decoded sequence detected \n"); */
#endif
					XING = TRUE;
				}
				break;
			case PICTURE_START_CODE:
				/*return (1);*/
				vid_stream->buffer = bitBuffer;
				vid_stream->buf_length = bufLength;
				vid_stream->bit_offset = bitOffset;
				return (1);
			default:
				return (0);
		}
	} while (1);
	return (0);
}

int xmpeg_VidRsrc (time_stamp, vid_stream)
TimeStamp time_stamp;
VidStream *vid_stream;
{
	unsigned int data;
	int i, status;
	int ret = 0;

	curVidStream = vid_stream;
	bitOffset = curVidStream->bit_offset;
#ifdef UTIL2
	curBits = *curVidStream->buffer << bitOffset;
#else
	curBits = *curVidStream->buffer;
#endif
	bufLength = curVidStream->buf_length;
	bitBuffer = curVidStream->buffer;

	/* Get next 32 bits (size of start codes). */

	show_bits32 (data);
	switch (data) 
	{
		case SEQ_END_CODE:
 			/* Display last frame. */

			if (vid_stream->future != NULL)
			{
				vid_stream->current = vid_stream->future;
				ExecuteDisplay (vid_stream);
			}
			xmpeg_sequence_end ();

			if (loopFlag) XM_STATUS = XM_START;
			else XM_STATUS = XM_END;
			ret = 1; /* no more frames, so don't block main loop */
			goto done;
		case SEQ_START_CODE:
 			/* Sequence start code. Parse sequence header. */
 
			if (ParseSeqHead (vid_stream) != PARSE_OK) goto error;
			goto done;
		case GOP_START_CODE:
 			/* Group of Pictures start code. Parse gop header. */

			if (ParseGOP (vid_stream) != PARSE_OK) goto error;
			goto done;
		case PICTURE_START_CODE:
 			/* Picture start code. Parse picture header and */
			/* first slice header. */

			status = ParsePicture (vid_stream, time_stamp);
 
			if (status == SKIP_PICTURE) 
			{
				next_start_code ();
#ifndef NDEBUG
				/* fprintf (stderr, "Skipping picture...");*/
				fprintf (stderr, ".");
#endif
				while (!next_bits (32, PICTURE_START_CODE))
				{
					if (next_bits (32, GOP_START_CODE)) break;
					else if (next_bits (32, SEQ_END_CODE)) break;
					flush_bits (24);
					next_start_code ();
				}
#ifndef NDEBUG
				/*fprintf (stderr, "Done.\n");*/
				fprintf (stderr, ";");
#endif
				goto done;
			}
			else if (status != PARSE_OK) goto error;

			if (ParseSlice (vid_stream) != PARSE_OK) goto error;
			break;
		default:
			/* Check for slice start code. */

			if ((data >= SLICE_MIN_START_CODE) &&
				(data <= SLICE_MAX_START_CODE))
			{
				/* Slice start code. Parse slice header. */

				if (ParseSlice (vid_stream) != PARSE_OK)
				{
					fprintf (stderr, " SH2+ \n");
					goto error;
				}
			}
			break;
	}

	/* Parse next MB_QUANTUM macroblocks. */

	for (i = 0;i < MB_QUANTUM;i++)
	{
		if (!next_bits (23, 0x00000000))
		{
			/* Not start code. Parse Macroblock. */

			if (ParseMacroBlock (vid_stream) != PARSE_OK)
			{
				fprintf (stderr, "MB error \n");
				goto error;
			} 
		}
		else
		{
			/* Not macroblock, actually start code. Get start code. */

			next_start_code ();
			show_bits32 (data);

			/* If start code is outside range of slice start codes, frame is */
			/* complete, display frame. */

			if ((data < SLICE_MIN_START_CODE) || (data > SLICE_MAX_START_CODE)) 
			{
				xmpeg_display_picture (vid_stream);
				ret = 1;
			}
			break;
		}
	}

	/* Return pointer to video stream structure. */

	goto done;

error:
	fprintf (stderr, "Error!!--!! %x Frames %d offset %d \n",
		data, xm_current_frame, xm_stream_offset);
	next_start_code ();
	goto done;

done:
	/* Copy global bit i/o variables back into vid_stream. */

	vid_stream->buffer = bitBuffer;
	vid_stream->buf_length = bufLength;
	vid_stream->bit_offset = bitOffset;

	return (ret);
}

void xmpeg_display_picture (vid_stream)
VidStream *vid_stream;
{
	/* Convert to colormap space and dither. */

	DoDitherImage (vid_stream->current->luminance, vid_stream->current->Cr, 
	vid_stream->current->Cb, vid_stream->current->display, 
	vid_stream->mb_height * 16, vid_stream->mb_width * 16);

	/* Update past and future references if needed. */
 
	set_references (vid_stream, UPDATE);
	ExecuteDisplay (vid_stream);
} 

void set_references (vid_stream, value)
VidStream *vid_stream;
int value;
{
	int i;

	switch (value)
	{
		case UPDATE:
			if ((vid_stream->picture.code_type == I_TYPE) ||
				(vid_stream->picture.code_type == P_TYPE))
			{
				if (vid_stream->future == NULL)
				{
					vid_stream->future = vid_stream->current;
					vid_stream->future->locked |= FUTURE_LOCK;
				} 
				else 
				{
					if (vid_stream->past != NULL)
					{
						vid_stream->past->locked &= ~PAST_LOCK;
					}
					vid_stream->past = vid_stream->future;
					vid_stream->past->locked &= ~FUTURE_LOCK;
					vid_stream->past->locked |= PAST_LOCK;
					vid_stream->future = vid_stream->current;
					vid_stream->future->locked |= FUTURE_LOCK;
					vid_stream->current = vid_stream->past;
				}
			}
			break;
		case RESET:
			for (i=0;i<RING_BUF_SIZE;i++)
				vid_stream->ring [i]->locked = 0;
			vid_stream->future = NULL;
			vid_stream->past = NULL;
			break;
	}
}

