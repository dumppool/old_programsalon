
/* --- C ---
************************************************************************
*
*	Filename    : butt.c
*	Description : button functions
*	Part of     : XMPEG - X11-MPEG-player
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#include "xmpeg.h"
#include "bitmaps.h"

static int    rbpixmade = 0;
static Pixmap cboard50 = (Pixmap) NULL;
static Pixmap rb_on, rb_on1, rb_off, rb_off1;

static int    cbpixmade = 0;
static Pixmap cbcheck;

static void drawRB(), drawCB();


void BTCreate(bp,win,x,y,w,h,str,fg,bg,hi,lo)
BUTT         *bp;
Window        win;
int           x,y,w,h;
char         *str;
unsigned long fg,bg,hi,lo;
{
  bp->win = win;
  bp->x = x;  bp->y = y;  bp->w = w;  bp->h = h;
  bp->str = str;
  bp->fg = fg;  bp->bg = bg;  bp->hi = hi;  bp->lo = lo;
  bp->lit = 0;
  bp->active = 1;
  bp->toggle = 0;
  bp->pix = None;
  bp->style = 0;
  bp->fwidth = 3;

  if (!cboard50) {
    cboard50 = XCreatePixmapFromBitmapData(theDisp, rootW, cboard50_bits,
		       cboard50_width, cboard50_height, 1, 0, 1);
    if (!cboard50) FatalError("Unable to create cboard50 bitmap\n");
  }
}

void BTSetActive(bp,act)
BUTT         *bp;
int           act;
{
  if (bp->active != act) {
    bp->active = act;
    BTRedraw(bp);
  }
}

void BTSetAllActive ()
{
	int i;

	for (i=S_BABOUT; i<=S_BINFO; i++)
	{
		if ((filesize > -1) ||
			((i != S_BFIRST) && (i != S_BREWIND)))
			BTSetActive (&dbut [i], 1);
		else BTSetActive (&dbut [i], 0);
	}
}

void BTSetAllInActive ()
{
	int i;

	for (i=S_BABOUT; i<=S_BINFO; i++)
	{
		if (i != S_BPAUSE) BTSetActive (&dbut [i], 0);
		else BTSetActive (&dbut [i], 1);
	}
}

void BTSetStyle (bp, style)
BUTT *bp;
int style;
{
	bp->style = style;
}

void BTRedraw(bp)
BUTT *bp;
{
  int x,y,w,h,r,x1,y1;
  XPoint tpts[10], bpts[10], ipts[5];

  x = bp->x;  y=bp->y;  w=bp->w;  h=bp->h;  r=bp->fwidth;

  if (!bp->active) bp->lit = 0;
  if (bp->lit) {
    r -= 1;
    if (r<0) r = 0;
  }

  if (!ctrlColor) {
    /* set up 'ipts' */
    ipts[0].x = x+r;        ipts[0].y = y+r;         /* topleft */
    ipts[1].x = x+r;        ipts[1].y = y+h-r;       /* botleft */
    ipts[2].x = x+w-r;      ipts[2].y = y+h-r;       /* botright */
    ipts[3].x = x+w-r;      ipts[3].y = y+r;         /* topright */
    ipts[4].x = ipts[0].x;  ipts[4].y = ipts[0].y;   /* close path */

    /* top left polygon */
    tpts[0].x = x;            tpts[0].y = y;
    tpts[1].x = x;            tpts[1].y = y+h;
    tpts[2].x = ipts[1].x;    tpts[2].y = ipts[1].y;
    tpts[3].x = ipts[0].x;    tpts[3].y = ipts[0].y;
    tpts[4].x = ipts[3].x;    tpts[4].y = ipts[3].y;
    tpts[5].x = x+w;          tpts[5].y = y;
    tpts[6].x = x;            tpts[6].y = y;

    /* bot left polygon */
    bpts[0].x = x;            bpts[0].y = y+h;
    bpts[1].x = ipts[1].x;    bpts[1].y = ipts[1].y;
    bpts[2].x = ipts[2].x;    bpts[2].y = ipts[2].y;
    bpts[3].x = ipts[3].x;    bpts[3].y = ipts[3].y;
    bpts[4].x = x+w;          bpts[4].y = y;
    bpts[5].x = x+w;          bpts[5].y = y+h;
    bpts[6].x = x;            bpts[6].y = y+h;


    /* clear button and draw frame */
    XSetForeground(theDisp, theGC, bp->bg);
    XFillRectangle(theDisp, bp->win, theGC, x, y, w, h);
    XSetForeground(theDisp, theGC, bp->fg);
    XDrawRectangle(theDisp, bp->win, theGC, x, y, w, h);

    XSetForeground(theDisp, theGC, bp->fg);
    XSetFillStyle(theDisp, theGC, FillStippled);
    XSetStipple(theDisp, theGC, cboard50);
    XFillPolygon(theDisp, bp->win, theGC, bpts, 7, Nonconvex, CoordModeOrigin);
    XSetFillStyle(theDisp,theGC,FillSolid);

    XSetForeground(theDisp, theGC, bp->fg);
    XDrawLines(theDisp, bp->win, theGC, ipts, 5, CoordModeOrigin);  /* inset */

    XDrawLine(theDisp, bp->win, theGC, x+1,   y+1,  ipts[0].x,ipts[0].y);
    XDrawLine(theDisp, bp->win, theGC, x+1,   y+h-1,ipts[1].x,ipts[1].y);
    XDrawLine(theDisp, bp->win, theGC, x+w-1, y+h-1,ipts[2].x,ipts[2].y);
    XDrawLine(theDisp, bp->win, theGC, x+w-1, y+1,  ipts[3].x,ipts[3].y);

    if (bp->lit) {
      XDrawRectangle(theDisp, bp->win, theGC, x+2, y+2, w-4, h-4);
      XDrawRectangle(theDisp, bp->win, theGC, x+1, y+1, w-2, h-2);
    }
  }
    
  else {   /* ctrlColor */
    XSetForeground(theDisp, theGC, bp->bg);
    XFillRectangle(theDisp, bp->win, theGC, x+1, y+1, w-1, h-1);

    Draw3dRect(bp->win, x+1,y+1,w-2,h-2, R3D_OUT, bp->fwidth, 
	       bp->hi, bp->lo, bp->bg);

    XSetForeground(theDisp, theGC, bp->fg);
    XDrawRectangle(theDisp, bp->win, theGC, x, y, w, h);

    if (bp->lit)
      XDrawRectangle(theDisp, bp->win, theGC, x+1, y+1, w-2, h-2);
  }



  XSetForeground(theDisp, theGC, bp->fg);

  if (bp->pix != None) {                    /* draw pixmap centered in butt */
    x1 = x+(1+w-bp->pw)/2;
    y1 = y+(1+h-bp->ph)/2;

    XSetBackground(theDisp, theGC, bp->bg);
    XCopyPlane(theDisp, bp->pix, bp->win, theGC, 0,0,bp->pw,bp->ph, x1,y1, 1);
    if (!bp->active) DimRect(bp->win, x1,y1, bp->pw, bp->ph, bp->bg);
  }

  else {                                    /* draw string centered in butt */
    x1 = CENTERX(mfinfo, x + w/2, bp->str);
    y1 = CENTERY(mfinfo, y + h/2);

    if (bp->active)
    {
      if (bp->style) SetBold ();
      XDrawString(theDisp, bp->win, theGC, x1,y1, bp->str, strlen(bp->str));
      if (bp->style) SetNormal ();
    }
    else {  /* stipple if not active */
      if (bp->style) SetBold ();
      XSetFillStyle(theDisp, theGC, FillStippled);
      XSetStipple(theDisp, theGC, grayStip);
      XDrawString(theDisp, bp->win, theGC, x1,y1, bp->str, strlen(bp->str));
      XSetFillStyle(theDisp,theGC,FillSolid);
      if (bp->style) SetNormal ();
    }
  }

}

int BTTrack(bp)
BUTT *bp;
{
  /* called when we've gotten a click inside 'bp'.  returns 1 if button
     was still selected lit when mouse was released. */

  Window       rW, cW;
  int          x, y, rx, ry, rval, inval;
  unsigned int mask;

  if (!bp->active) return 0;   /* inactive button */

  inval = bp->lit;
  bp->lit = !bp->lit;

  BTRedraw(bp);  XFlush(theDisp);
  Timer(120);  /* long enough for turn on to be visible */

  while (XQueryPointer(theDisp,bp->win,&rW,&cW,&rx,&ry,&x,&y,&mask)) {
    if (!(mask & Button1Mask)) break;    /* button released */

    if (bp->lit==inval && PTINRECT(x, y, bp->x, bp->y, bp->w, bp->h)) {
      bp->lit = !inval;  BTRedraw(bp);  XFlush(theDisp);
    }
    
    if (bp->lit!=inval && !PTINRECT(x, y, bp->x, bp->y, bp->w, bp->h)) {
      bp->lit = inval;  BTRedraw(bp);  XFlush(theDisp);
    }
  }

  rval = (bp->lit != inval);
  
  if (bp->lit && !bp->toggle) 
    { bp->lit = 0;  BTRedraw(bp);  XFlush(theDisp); }

  return(rval);
}

#define RBSIZE rb_frame_width

RBUTT *RBCreate(rblist, win, x,y,str, fg, bg, hi, lo)
      RBUTT        *rblist;
      Window        win;
      int           x,y;
      char         *str;
      unsigned long fg,bg,hi,lo;
{
  /* mallocs an RBUTT, fills in the fields, and appends it to rblist
     if rblist is NULL, this is the first rb in the list.  It will
     be made the 'selected' one 

     Note: no need to check return status.  It'll fatal error if it 
     can't malloc */

  RBUTT *rb, *rbptr;
  Pixmap rb_frame, rb_frame1, rb_top, rb_bot, rb_dtop, rb_dbot, rb_body, 
         rb_dot;

  rb = (RBUTT *) malloc(sizeof(RBUTT));
  if (!rb) FatalError("couldn't malloc RBUTT");

  /* fill in the fields of the structure */
  rb->win      = win;
  rb->x        = x;
  rb->y        = y;
  rb->str      = str;
  rb->selected = 0;
  rb->active   = 1;
  rb->next     = (RBUTT *) NULL;
  rb->fg       = fg;
  rb->bg       = bg;
  rb->hi       = hi;
  rb->lo       = lo;

  if (rblist) {            /* append to end of list */
    rbptr = rblist;
    while (rbptr->next) rbptr = rbptr->next;
    rbptr->next = rb;
  }
  else {                   /* this is the first one in the list.  select it */
    rb->selected = 1;
  }


  /* and, on an unrelated note, if the RB pixmaps haven't been created yet,
     do so.  We'll be needing them, y'see... */

  if (!rbpixmade) {
    rb_frame  = XCreatePixmapFromBitmapData(theDisp, rootW, 
                  rb_frame_bits, RBSIZE, RBSIZE, 1,0,1);
    rb_frame1 = XCreatePixmapFromBitmapData(theDisp, rootW, 
                  rb_frame1_bits, RBSIZE, RBSIZE, 1,0,1);
    rb_top    = XCreatePixmapFromBitmapData(theDisp, rootW, 
                  rb_top_bits, RBSIZE, RBSIZE, 1,0,1);
    rb_bot    = XCreatePixmapFromBitmapData(theDisp, rootW, 
                  rb_bot_bits, RBSIZE, RBSIZE, 1,0,1);
    rb_dtop   = XCreatePixmapFromBitmapData(theDisp, rootW, 
                  rb_dtop_bits, RBSIZE, RBSIZE, 1,0,1);
    rb_dbot   = XCreatePixmapFromBitmapData(theDisp, rootW, 
                  rb_dbot_bits, RBSIZE, RBSIZE, 1,0,1);
    rb_body   = XCreatePixmapFromBitmapData(theDisp, rootW, 
                  rb_body_bits, RBSIZE, RBSIZE, 1,0,1);
    rb_dot    = XCreatePixmapFromBitmapData(theDisp, rootW, 
                  rb_dot_bits, RBSIZE, RBSIZE, 1,0,1);

    rb_on     = XCreatePixmap(theDisp, rootW, RBSIZE, RBSIZE, dispDEEP);
    rb_on1    = XCreatePixmap(theDisp, rootW, RBSIZE, RBSIZE, dispDEEP);
    rb_off    = XCreatePixmap(theDisp, rootW, RBSIZE, RBSIZE, dispDEEP);
    rb_off1   = XCreatePixmap(theDisp, rootW, RBSIZE, RBSIZE, dispDEEP);

    if (!rb_frame || !rb_frame1 || !rb_top || !rb_bot || !rb_dtop || 
	!rb_dbot  || !rb_body   || !rb_dot || !rb_on  || !rb_on1  ||
	!rb_off   || !rb_off1)
      FatalError("unable to create radio-button pixmaps");

    XSetForeground(theDisp, theGC, bg);
    XFillRectangle(theDisp, rb_on,   theGC, 0,0,RBSIZE,RBSIZE);
    XFillRectangle(theDisp, rb_on1,  theGC, 0,0,RBSIZE,RBSIZE);
    XFillRectangle(theDisp, rb_off,  theGC, 0,0,RBSIZE,RBSIZE);
    XFillRectangle(theDisp, rb_off1, theGC, 0,0,RBSIZE,RBSIZE);

    XSetFillStyle(theDisp, theGC, FillStippled);

    if (ctrlColor) {
      XSetStipple(theDisp, theGC, rb_top);
      XSetForeground(theDisp, theGC, fg);
      XFillRectangle(theDisp, rb_on,   theGC, 0,0,RBSIZE,RBSIZE);
      XFillRectangle(theDisp, rb_on1,  theGC, 0,0,RBSIZE,RBSIZE);
      XSetForeground(theDisp, theGC, hi);
      XFillRectangle(theDisp, rb_off,  theGC, 0,0,RBSIZE,RBSIZE);
      XFillRectangle(theDisp, rb_off1, theGC, 0,0,RBSIZE,RBSIZE);

      XSetStipple(theDisp, theGC, rb_body);
      XSetForeground(theDisp, theGC, lo);
      XFillRectangle(theDisp, rb_on,   theGC, 0,0,RBSIZE,RBSIZE);
      XFillRectangle(theDisp, rb_on1,  theGC, 0,0,RBSIZE,RBSIZE);
      XSetForeground(theDisp, theGC, bg);
      XFillRectangle(theDisp, rb_off,  theGC, 0,0,RBSIZE,RBSIZE);
      XFillRectangle(theDisp, rb_off1, theGC, 0,0,RBSIZE,RBSIZE);

      XSetStipple(theDisp, theGC, rb_bot);
      XSetForeground(theDisp, theGC, bg);
      XFillRectangle(theDisp, rb_on,   theGC, 0,0,RBSIZE,RBSIZE);
      XFillRectangle(theDisp, rb_on1,  theGC, 0,0,RBSIZE,RBSIZE);
      XSetForeground(theDisp, theGC, lo);
      XFillRectangle(theDisp, rb_off,  theGC, 0,0,RBSIZE,RBSIZE);
      XFillRectangle(theDisp, rb_off1, theGC, 0,0,RBSIZE,RBSIZE);

      XSetStipple(theDisp, theGC, rb_dtop);
      XSetForeground(theDisp, theGC, bg);
      XFillRectangle(theDisp, rb_on,   theGC, 0,0,RBSIZE,RBSIZE);
      XFillRectangle(theDisp, rb_on1,  theGC, 0,0,RBSIZE,RBSIZE);
      XSetForeground(theDisp, theGC, hi);
      XFillRectangle(theDisp, rb_off,  theGC, 0,0,RBSIZE,RBSIZE);
      XFillRectangle(theDisp, rb_off1, theGC, 0,0,RBSIZE,RBSIZE);

      XSetStipple(theDisp, theGC, rb_dbot);
      XSetForeground(theDisp, theGC, fg);
      XFillRectangle(theDisp, rb_on,   theGC, 0,0,RBSIZE,RBSIZE);
      XFillRectangle(theDisp, rb_on1,  theGC, 0,0,RBSIZE,RBSIZE);
      XSetForeground(theDisp, theGC, lo);
      XFillRectangle(theDisp, rb_off,  theGC, 0,0,RBSIZE,RBSIZE);
      XFillRectangle(theDisp, rb_off1, theGC, 0,0,RBSIZE,RBSIZE);
    }
    else {
      XSetStipple(theDisp, theGC, rb_dot);
      XSetForeground(theDisp, theGC, fg);
      XFillRectangle(theDisp, rb_on,   theGC, 0,0,RBSIZE,RBSIZE);
      XFillRectangle(theDisp, rb_on1,  theGC, 0,0,RBSIZE,RBSIZE);
    }
      
    XSetStipple(theDisp, theGC, rb_frame);
    XSetForeground(theDisp, theGC, fg);
    XFillRectangle(theDisp, rb_on,   theGC, 0,0,RBSIZE,RBSIZE);
    XFillRectangle(theDisp, rb_off,  theGC, 0,0,RBSIZE,RBSIZE);

    XSetStipple(theDisp, theGC, rb_frame1);
    XSetForeground(theDisp, theGC, fg);
    XFillRectangle(theDisp, rb_on1,  theGC, 0,0,RBSIZE,RBSIZE);
    XFillRectangle(theDisp, rb_off1, theGC, 0,0,RBSIZE,RBSIZE);

    XSetFillStyle(theDisp, theGC, FillSolid);

    /* destroy mask pixmaps */
    XFreePixmap(theDisp, rb_frame);
    XFreePixmap(theDisp, rb_frame1);
    XFreePixmap(theDisp, rb_top);
    XFreePixmap(theDisp, rb_bot);
    XFreePixmap(theDisp, rb_dtop);
    XFreePixmap(theDisp, rb_dbot);
    XFreePixmap(theDisp, rb_body);

    rbpixmade = 1;
  }

  return(rb);
}
  
void RBRedraw(rblist, num)
RBUTT *rblist;
int    num;
{
  /* redraws the 'num-th' RB in the list.  if num < 0, redraws entire list */

  RBUTT *rb;
  int    i;

  /* point 'rb' at the appropriate RBUTT, *if* we're not drawing entire list */
  if (num>=0) {
    i=0;  rb=rblist;
    while (i!=num && rb) { rb = rb->next;  i++; }
    if (!rb) return;                     /* num is out of range.  do nothing */
    drawRB(rb,0);
  }

  else {                                 /* draw entire list */
    rb = rblist;
    while (rb) {
      drawRB(rb,0);
      rb = rb->next;
    }
  }
}

static void drawRB(rb, lit)
RBUTT *rb;
int   lit;
{
  /* draws the rb being pointed at */

  Pixmap pix;

  if (!rb) return;  /* rb = NULL */

  XSetForeground(theDisp, theGC, rb->fg);

  if (rb->selected) { pix = (lit) ? rb_on1 : rb_on; }
               else { pix = (lit) ? rb_off1 : rb_off; }

  XCopyArea(theDisp, pix, rb->win, theGC, 0,0,RBSIZE,RBSIZE, rb->x, rb->y);
  XDrawString(theDisp, rb->win, theGC, rb->x + RBSIZE + 4, 
	      rb->y + RBSIZE/2 - CHIGH/2 + ASCENT,rb->str,strlen(rb->str));

  if (!rb->active) {  /* if non-active, dim button and string */
    DimRect(rb->win, rb->x, rb->y, RBSIZE, RBSIZE, rb->bg);
    DimRect(rb->win, rb->x + RBSIZE + 4, rb->y + RBSIZE/2 - CHIGH/2, 
	    StringWidth(rb->str),CHIGH, rb->bg);
  }
}

void RBSelect(rblist, n)
RBUTT *rblist;
int    n;
{
  RBUTT *rbold, *rb;
  int    i;

  /* makes rb #n the selected rb in the list.  Does all redrawing.  Does
     nothing if rb already selected */

  /* get pointers to the currently selected rb and the desired rb */
  rbold = rblist;
  while (rbold && !rbold->selected) rbold = rbold->next;
  if (!rbold) return;    /* no currently selected item.  shouldn't happen */

  rb = rblist;  i=0;
  while (rb && i!=n) {rb = rb->next;  i++; }
  if (!rb) return;    /* 'n' is out of range */


  if (rb == rbold) return;   /* 'n' is already selected.  do nothing */

  rbold->selected = 0;
  rb->selected    = 1;
  drawRB(rbold, 0);
  drawRB(rb, 0);
}

int RBWhich(rblist)
RBUTT *rblist;
{
  int i;

  /* returns index of currently selected rb.  if none, returns -1 */

  i = 0;
  while (rblist && !rblist->selected) { rblist = rblist->next;  i++; }

  if (!rblist) return -1;             /* didn't find one */
  return i;
}

int RBCount(rblist)
RBUTT *rblist;
{
  int i;

  /* returns # of rb's in the list */

  i = 0;
  while (rblist) { rblist = rblist->next; i++; }
  return i;
}

void RBSetActive(rblist, n, act)
RBUTT *rblist;
int n,act;
{
  RBUTT *rb;
  int    i;

  /* sets 'active' status of rb #n.  does redrawing */

  rb=rblist;  i=0;
  while (rb && i!=n) { rb = rb->next; i++; }
  if (!rb) return;                         /* n out of range.  do nothing */

  if (rb->active != act) {
    rb->active = act;
    drawRB(rb, 0);
  }
}

int RBClick(rblist, mx, my)
RBUTT *rblist;
int    mx,my;
{
  int i;

  i = 0;
  while (rblist) {
    if (PTINRECT(mx, my, rblist->x, rblist->y, RBSIZE, RBSIZE)) 
      break;
    rblist = rblist->next;
    i++;
  }

  if (!rblist) return -1;
  return(i);
}

int RBTrack(rblist, n)
RBUTT *rblist;
int    n;
{
  RBUTT       *rb;
  Window       rW, cW;
  int          i, x, y, rx, ry, lit, rv;
  unsigned int mask;

  /* returns '1' if selection changed */

  rb=rblist;  i=0;
  while (rb && i!=n) { rb = rb->next; i++; }
  if (!rb) return 0;                    /* n out of range */

  /* called once we've figured out that the mouse clicked in 'rb' */

  if (!rb->active) return 0;

  lit = 1;
  drawRB(rb, lit);
  XFlush(theDisp);
  Timer(75);          /* give chance for 'turn on' to become visible */

  while (XQueryPointer(theDisp,rb->win,&rW,&cW,&rx,&ry,&x,&y,&mask)) {
    if (!(mask & Button1Mask)) break;    /* button released */

    if (!lit && PTINRECT(x, y, rb->x, rb->y, RBSIZE, RBSIZE)) {
      lit=1;
      drawRB(rb, lit);
      XFlush(theDisp);
    }
    
    if (lit && !PTINRECT(x, y, rb->x, rb->y, RBSIZE, RBSIZE)) {
      lit=0;
      drawRB(rb, lit);
      XFlush(theDisp);
    }
  }

  rv = 0;

  if (lit) {
    drawRB(rb, 0);
    if (RBWhich(rblist) != n) rv = 1;
    RBSelect(rblist, n);
  }

  XFlush(theDisp);
  return rv;
}

#define CBSIZE 16

void CBCreate(cb, win, x,y, str, fg, bg, hi, lo)
      CBUTT        *cb;
      Window        win;
      int           x,y;
      char         *str;
      unsigned long fg,bg,hi,lo;
{
  /* fill in the fields of the structure */
  cb->win      = win;
  cb->x        = x;
  cb->y        = y;
  cb->str      = str;
  cb->val      = 0;
  cb->active   = 1;
  cb->fg       = fg;
  cb->bg       = bg;
  cb->hi       = hi;
  cb->lo       = lo;

  /* and, on an unrelated note, if the CB pixmaps haven't been created yet,
     do so.  We'll be needing them, y'see... */

  if (!cbpixmade) {
    cbcheck = XCreatePixmapFromBitmapData(theDisp, rootW, cb_check_bits,
	     cb_check_width, cb_check_height, fg, bg, dispDEEP);

    cbpixmade = 1;
  }
}

void CBRedraw(cb)
CBUTT *cb;
{
  /* draws the cb being pointed at */

  XSetForeground(theDisp, theGC, cb->bg);
  XFillRectangle(theDisp, cb->win, theGC, cb->x+2, cb->y+2, CBSIZE-3,CBSIZE-3);

  XSetForeground(theDisp, theGC, cb->fg);
  XDrawRectangle(theDisp, cb->win, theGC, cb->x, cb->y, CBSIZE, CBSIZE);
  Draw3dRect(cb->win, cb->x+1, cb->y+1, CBSIZE-2, CBSIZE-2, R3D_OUT, 2,
	     cb->hi, cb->lo, cb->bg); 

  if (cb->val) XCopyArea(theDisp, cbcheck, cb->win, theGC, 
			 0, 0, cb_check_width, cb_check_height, 
			 cb->x+3, cb->y+3);
 
  XSetForeground(theDisp, theGC, cb->fg);
  XDrawString(theDisp, cb->win, theGC, cb->x + CBSIZE+4, 
	      cb->y+CBSIZE/2 - CHIGH/2 + ASCENT,cb->str,strlen(cb->str));

  if (!cb->active) {  /* if non-active, dim button and string */
    DimRect(cb->win, cb->x, cb->y, CBSIZE, CBSIZE, cb->bg);
    DimRect(cb->win, cb->x + CBSIZE+4, cb->y+CBSIZE/2 - CHIGH/2, 
	    StringWidth(cb->str),CHIGH, cb->bg);
  }
}

void CBSetActive(cb,act)
CBUTT        *cb;
int           act;
{
  if (cb->active != act) {
    cb->active = act;
    CBRedraw(cb);
  }
}

int CBClick(cb, mx, my)
CBUTT *cb;
int    mx,my;
{
  if (PTINRECT(mx, my, cb->x, cb->y, CBSIZE,CBSIZE)) return 1;
  return 0;
}

int CBTrack(cb)
CBUTT *cb;
{
  Window       rW, cW;
  int          x, y, rx, ry, lit;
  unsigned int mask;

  /* called once we've figured out that the mouse clicked in 'cb' */

  if (!cb->active) return 0;

  XSetForeground(theDisp, theGC, cb->fg);

  lit = 1;
  drawCB(cb, lit);
  XFlush(theDisp);
  Timer(75);          /* give chance for 'turn on' to become visible */

  while (XQueryPointer(theDisp,cb->win,&rW,&cW,&rx,&ry,&x,&y,&mask)) {
    if (!(mask & Button1Mask)) break;    /* button released */

    if (!lit && PTINRECT(x, y, cb->x, cb->y, CBSIZE, CBSIZE)) {
      lit=1;
      drawCB(cb,lit);
      XFlush(theDisp);
    }
    
    if (lit && !PTINRECT(x, y, cb->x, cb->y, CBSIZE, CBSIZE)) {
      lit=0;
      drawCB(cb,lit);
      XFlush(theDisp);
    }
  }

  if (lit) {
    cb->val = !cb->val;
    drawCB(cb,0);
    CBRedraw(cb);
  }

  XFlush(theDisp);

  return(lit);
}

static void drawCB(cb, lit)
CBUTT *cb;
int lit;
{
  /* draws highlighting */
  if (lit) {
    if (ctrlColor) 
      Draw3dRect(cb->win, cb->x+1, cb->y+1, CBSIZE-2, CBSIZE-2, R3D_IN, 2,
		 cb->hi, cb->lo, cb->bg);
    else {
      XSetForeground(theDisp, theGC, cb->fg);
      XDrawRectangle(theDisp, cb->win, theGC, cb->x+1, cb->y+1, 
		     CBSIZE-2, CBSIZE-2);
    }
  }

  else {
    if (ctrlColor) 
      Draw3dRect(cb->win, cb->x+1, cb->y+1, CBSIZE-2, CBSIZE-2, R3D_OUT, 2,
		 cb->hi, cb->lo, cb->bg);
    else {
      XSetForeground(theDisp, theGC, cb->bg);
      XDrawRectangle(theDisp, cb->win, theGC, cb->x+1, cb->y+1, 
		     CBSIZE-2, CBSIZE-2);
    }
  }
}

