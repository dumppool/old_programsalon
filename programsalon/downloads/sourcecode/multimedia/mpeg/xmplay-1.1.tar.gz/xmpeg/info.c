
/* --- C ---
************************************************************************
*
*	Filename    : info.c
*	Description : info-box function
*	Part of     : XMPLAY - X11-directory-browser for XMPEG
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#define NEEDSDIR
#define NEEDDIALOG
#ifdef XMPEG
#include "xmpeg.h"
#else
#include "xmplay.h"
#endif
#ifndef F_OK
#include <sys/unistd.h>
#endif
#include "mpeginfo.h"

char *shtimestr (s)
char *s;
{
	char *t;

	s = s + 4;
	for (t = s;*t != ':';t++);
	for (t++;*t != ':';t++);
	*t = '\0';
	return (s);
}

void DoInfo ()
{
	struct stat s;
	struct stat *buf = &s;
	struct passwd *p;
	struct tm *llat;

	int special = 0;

	char fpath [MAXPATHLEN];
	char fname [MAXPATHLEN];
	char ftype [20];
	char fmode [20];
	char flink [4];
	char *fown;
	char *ftime;
	char fsize [20];

	MPEGINFO mpeginfo;

#ifdef XMPEG
	char path [MAXPATHLEN];
	char *ptr;

	if (!strcmp (filename, STDINSTR))
	{
		CreateErrW ("Unable to stat stdin.", "");
		RedrawErrW ();
		ErrorEventLoop ();
		return;
	}
	if (ptr = rindex (filename, '/'))
	{
		strcpy (path, filename);
		ptr = rindex (path, '/');
		strcpy (fname, ptr+1);
		path [strlen (path)-strlen (ptr)+1] = (char)0;
	}
	else
	{
#ifdef SYSV
		getcwd (path, sizeof (fpath));
#else
		getwd (path);
#endif
		strcat (path, "/");
		strcpy (fname, filename);
	}
	strcpy (fpath, path);
	strcat (fpath, fname);
#else
	strcpy (fpath, path);
	if (strlen (filename) > 0)
	{
		strcat (fpath, filename);
		strcpy (fname, filename);
	}
/*

extern char *typename;

	else if (strlen (typename) > 0)
	{
		strcat (fpath, typename);
		strcpy (fname, typename);
	}
*/
	else
	{
		CreateErrW ("Unable to access file :", fpath);
		RedrawErrW ();
		ErrorEventLoop ();
		return;
	}
#endif

	if (mpeg_info (&mpeginfo, fpath) != PARSE_OK)
	{

/* here is something wrong, something declared twice */

#ifndef XMPEG
		CreateErrW (filename, "does not look like a MPEG-I-videofile !");
		RedrawErrW ();
		ErrorEventLoop ();
		return;
#endif
	}
	
#if defined (i386) || defined (SYSV)
	if (stat (fpath, buf))
#else
	if (lstat (fpath, buf))
#endif
	{
		CreateErrW ("Unable to access file :", fpath);
		RedrawErrW ();
		ErrorEventLoop ();
		return;
	}
	else
	{
		switch (buf->st_mode & S_IFMT)
		{
#ifdef S_IFLNK
			case S_IFLNK:
				strcpy (ftype, "Link");
				break;
#endif
			case S_IFCHR:
				strcpy (ftype, "Character special");
				special = 1;
				break;
			case S_IFBLK:
				strcpy (ftype, "Block special");
				special = 1;
				break;
			case S_IFDIR:
				strcpy (ftype, "Directory");
				break;
#ifdef S_IFSOCK
			case S_IFSOCK:
				strcpy (ftype, "Socket");
				special = 1;
				break;
#endif
#ifdef S_IFIFO
			case S_IFIFO:
				strcpy (ftype, "Fifo");
				break;
#endif
			case S_IFREG:
				strcpy (ftype, "Regular");
				break;
			default:
				strcpy (ftype, "Unknown");
				break;
		}
	}

	strcpy (fmode, "");
	if (buf->st_mode & S_IREAD) strcat (fmode, "R");else strcat (fmode, "-");
	if (buf->st_mode & S_IWRITE) strcat (fmode, "W");else strcat (fmode, "-");
	if (buf->st_mode & S_IEXEC) strcat (fmode, "X");else strcat (fmode, "-");
	if (buf->st_mode & S_IRGRP) strcat (fmode, "R");else strcat (fmode, "-");
	if (buf->st_mode & S_IWGRP) strcat (fmode, "W");else strcat (fmode, "-");
	if (buf->st_mode & S_IXGRP) strcat (fmode, "X");else strcat (fmode, "-");
	if (buf->st_mode & S_IROTH) strcat (fmode, "R");else strcat (fmode, "-");
	if (buf->st_mode & S_IWOTH) strcat (fmode, "W");else strcat (fmode, "-");
	if (buf->st_mode & S_IXOTH) strcat (fmode, "X");else strcat (fmode, "-");

	sprintf (flink, "%-3d", buf->st_nlink);
	p = getpwuid (buf->st_uid);
	fown = p->pw_name;
	llat = localtime (&buf->st_mtime);
	ftime = shtimestr (asctime (llat));
	if (!special) sprintf (fsize, "%-9d", buf->st_size);

	CreateInfW (special, path, fname, ftype, fmode, flink, fown, ftime, fsize);
	RedrawInfW ();
	InfoEventLoop ();
	return;
}

