
/* --- C ---
************************************************************************
*
*	Filename    : handle.c
*	Description : callback functions for button actions
*	Part of     : XMPEG - X11-MPEG-player
*
*	Version     : 1.0
*	Date        : Sun Feb  6 13:34:10 MET 1994
*	Language    : C
*	For machine : INTERACTIVE Unix, Sun OS, SCO, AU/X, Solaris, Linux
*	Compile as  : see Makefile
*
*	Author      : Frank Gadegast, Juergen Meyer, Metin Cetinkaya
*	Contact     : phade@cs.tu-berlin.de, jm@cs..., brain@cs...
*
************************************************************************
*/

#define NEEDSVIDEO
#include "xmpeg.h"

extern Window window;

void DoAbout ()
{
	CreateAboutW ();
	RedrawAboutW ();
	AboutEventLoop ();
}

extern char *ditherTypeStrings [];
extern int ditherIndex [];
extern int ditherType;

extern void SwitchDither ();
extern void MakeWindow ();

void DoDither ()
{
	int i, tmpType;
	char *tmpStr;

	if ((ditherType == Twox2_DITHER) || (ditherType == FULL_COLOR_DITHER) ||
		(ditherType == NO_DITHER))
	{
		XBell (theDisp, 0);
		return;
	}
	CreateDitherW ();
	RedrawDitherW ();
	if (DitherEventLoop () == S_SOK)
	{
		tmpType = -1;
		tmpStr = ditherTypeStrings [RBWhich (ditherRB)];
		for (i=0; i < DITHERMAX; i++)
			if (!strcmp (tmpStr, ditherTypeStrings [i]))
				tmpType = ditherIndex [i];
		if ((tmpType == FULL_COLOR_DITHER) &&
			(DetectDisplayType (theDisp) != FULLCOLOR))
		{
			CreateErrW ("Unable to detect full-color-display.", "");
			RedrawErrW ();
			ErrorEventLoop ();
			return;
		}
		if (((tmpType != MONO_DITHER) && (tmpType != MONO_THRESHOLD)) &&
			(DetectDisplayType (theDisp) == MONO))
		{
			CreateErrW ("Unable to detect color-display.", "");
			RedrawErrW ();
			ErrorEventLoop ();
			return;
		}

		/* should rewind here to the last I-frame */

		ditherType = tmpType;
		ditherstr = ditherTypeStrings [RBWhich (ditherRB)];
		XDestroyWindow (theDisp, window);
		SwitchDither ("");
		RedrawDirW ();
	}
}

