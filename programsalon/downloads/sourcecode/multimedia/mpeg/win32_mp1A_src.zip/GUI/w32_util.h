#ifndef W32_UTIL_H
#define W32_UTIL_H

#include <windows.h>

void report_mci_error(HWND hWnd0, DWORD error, LPSTR heading);

int get_dropped_files(LPSTR ret_str, int max_file_len,
                      HDROP hDrop);

BOOL launch_file(LPSTR filename, HWND hSender,
                 LPSTR cmdline=NULL, LPSTR cust_exe_name=NULL);

#endif
