#include "codecbase.h"

void* quicktime_plugin_get_codec(quicktime_t *file, int track)
{
	
}
