#ifndef QUICKTIME_RAW_H
#define QUICKTIME_RAW_H

typedef struct
{
} quicktime_raw_codec_t;

#endif
