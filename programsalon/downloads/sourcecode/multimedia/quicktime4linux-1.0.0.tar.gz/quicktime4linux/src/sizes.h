#ifndef QUICKTIME_SIZES_H
#define QUICKTIME_SIZES_H

typedef short int QUICKTIME_INT16;

#endif
