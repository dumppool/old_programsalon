//-----------------------------------------------------------------------------
// project:		ZModem
// author:		Frank Weiler, Genshagen, Germany
// version:		0.91
// date:		October 10, 2000
// email:		frank@weilersplace.de
// copyright:	This Software is OpenSource.
// file:		ZModemFile
// description:	a class to handle all the file-based stuff
// 
//-----------------------------------------------------------------------------

#if !defined(AFX_ZMODEMFILE_H__6A43214D_9C2E_11D4_8639_F6B82A27C85A__INCLUDED_)
#define AFX_ZMODEMFILE_H__6A43214D_9C2E_11D4_8639_F6B82A27C85A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define ZMODEMFILE_OK 0
#define ZMODEMFILE_NOMOREDATA 1
#define ZMODEMFILE_ERROR -1

class ZMODEM CZModemFile  
{
public:
	CString GetReceivedFileName();
	void ResetAll();
	bool InitFromFILEINFO(char* buffer);
	CZModemFile(HWND hOwner);
	virtual ~CZModemFile();
	bool Open(CString filename,DWORD mode);
	void WriteData(void* buffer,DWORD bytes);
	void Finish();
	void SetPos(DWORD offset);
	void OpenReceivingFile(LPDWORD offset,bool* skip);
	int GetData(void *buffer,DWORD max,LPDWORD bytes);
	LONG GetFileSize();
	int MakeFileInfo(unsigned char* buf);
	void SetReceivingDir(CString szDir);
protected:
	HWND m_hOwner;
	HANDLE m_hFile;
	CString m_Filename;
	LONG m_Filesize;
	CString m_ReceiveDir;
	char m_fileinfo[1024];
};

#endif // !defined(AFX_ZMODEMFILE_H__6A43214D_9C2E_11D4_8639_F6B82A27C85A__INCLUDED_)
