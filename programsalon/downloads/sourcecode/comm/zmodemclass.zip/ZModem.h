// ZModem.h : Haupt-Header-Datei f�r die DLL ZMODEM
//

#if !defined(AFX_ZMODEM_H__6A432143_9C2E_11D4_8639_F6B82A27C85A__INCLUDED_)
#define AFX_ZMODEM_H__6A432143_9C2E_11D4_8639_F6B82A27C85A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// Hauptsymbole


/////////////////////////////////////////////////////////////////////////////
// CZModemApp
// Siehe ZModem.cpp f�r die Implementierung dieser Klasse
//

class CZModemApp : public CWinApp
{
public:
	CZModemApp();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CZModemApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CZModemApp)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_ZMODEM_H__6A432143_9C2E_11D4_8639_F6B82A27C85A__INCLUDED_)
