//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ZMODEM.RC
//

// N�chste Standardwerte f�r neue Objekte
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE	8000
#define _APS_NEXT_CONTROL_VALUE		8000
#define _APS_NEXT_SYMED_VALUE		8000
#define _APS_NEXT_COMMAND_VALUE		32771          101
#endif
#endif
