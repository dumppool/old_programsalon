/* -*- C++ -*-
 * SportsterVoice.C - source file for class SportsterVoice
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "SportsterVoice.h"

#include <sys/poll.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

//#define SILENCE
//#define USE_NDELAY
//#define DEBUG

const int MAX=255;

#define ETX	0x03
#define DLE	0x10

bool SportsterVoice::openPort()
{
#ifdef DEBUG
    printf("Calling open()... ");
#endif
    if( (fd = open(MODEM, O_RDWR | O_NDELAY)) == -1 ) {
	setLocked(false);
	return false;
    }
#ifdef DEBUG
    printf("done.\n");
#endif
    
#ifdef DEBUG
    printf("Calling flock()... ");
#endif
    if( flock(fd, LOCK_EX | LOCK_NB) == -1 ) {
	setLocked(false);
    }
    else {
	setLocked(true);
    }
#ifdef DEBUG
    printf("done.\n");
#endif

    okMessages.insert("OK");
    okMessages.insert("CONNECT");
    okMessages.insert("VCON");
    
    errorMessages.insert("ERROR");
    errorMessages.insert("NO DIAL TONE");
    errorMessages.insert("NO CARRIER");

#ifndef USE_NDELAY
    int n = fcntl(fd, F_GETFL);
#ifdef DEBUG
    printf("Calling fcntl()... ");
#endif
    fcntl(fd, F_SETFL, (n & ~O_NDELAY));
#ifdef DEBUG
    printf("done.\n");
#endif
#endif
    
    tcgetattr(fd,&oldtio);
    memset(&newtio, 0, sizeof(newtio));
    
    newtio.c_iflag = IGNPAR | IGNBRK;
    newtio.c_oflag = 0;
    
#ifdef CRTSCTS
    newtio.c_cflag = CRTSCTS | CREAD;
#else
    newtio.c_cflag = CREAD;
#endif
    
    newtio.c_lflag = 0;
    
    newtio.c_cc[VMIN] = 1;
    
    tcflush(fd, TCIOFLUSH);
    cfsetospeed(&newtio, B0);
    cfsetispeed(&newtio, B0);
    tcsetattr(fd,TCSANOW,&newtio);
    
    sleep(1);
    
    cfsetospeed(&newtio, B38400);
    cfsetispeed(&newtio, B38400);
    tcsetattr(fd,TCSAFLUSH,&newtio);  
    
    String modemReset(MODEM_RESET), modemInit(MODEM_INIT);
    
    writeLine(modemReset);
    writeLine(modemInit);

    return true;
}

void SportsterVoice::closePort()
{
    tcflush(fd, TCIOFLUSH);
    cfsetospeed(&newtio, B0);
    cfsetispeed(&newtio, B0);
    tcsetattr(fd,TCSANOW,&newtio);
    
    sleep(1);
    
    cfsetospeed(&newtio, B38400);
    cfsetispeed(&newtio, B38400);
    tcsetattr(fd,TCSAFLUSH,&newtio);  
    
    tcsetattr(fd, TCSANOW, &oldtio);
    flock(fd, LOCK_UN);
    setLocked(false);
    close(fd);
    fd = -1;
}

String SportsterVoice::readLine()
{
#ifdef DEBUG
    printf("Entering readLine()... read ");
#endif
    char buffer[MAX];
    int i=0;
    int j;
    char temp[1];
    j=read(fd,temp,1);
#ifdef DEBUG
    printf("%c", temp[0]);
#endif
    while(j > 0 && temp[0] != 10 && i < MAX) {
	buffer[i++]=temp[0];
	j=read(fd,temp,1);
#ifdef DEBUG
	printf("%c", temp[0]);
#endif
    }
    buffer[i]=0;
    while(buffer[i-1] > 0x01 && buffer[i-1] < 0x1f) {
	buffer[--i] = 0;
    }
#ifdef DEBUG
    printf(" done. Final String is %s\n", buffer);
#endif
    return String(buffer);
}


void SportsterVoice::callNumber(String& number, target where)
{
    writeLine("AT&F1");
    /* select voice mode */
    writeLine("at#cls=8");
    writeLine("AT #VSM=128,8000");
    /* select speaker output device */
    
    switch(where) {
    case line:
	writeLine("AT #VLS=0");
	break;
    case handset:
	writeLine("AT #VLS=1");
	break;
    case speaker:
	writeLine("AT #VLS=2");
	break;
    case microphone:
	writeLine("AT #VLS=3");
	break;
    case line_speaker:
	writeLine("AT #VLS=4");
	break;
    case speakerphone:
	writeLine("AT #VLS=6");
	break;
	
    }

    writeLine("ATDT "+number);
}

void SportsterVoice::hangUp()
{
    writeLine("AT H0");
    
    //writeLine("at#vls=0");
    writeLine("at#cls=0");
    
    writeLine(MODEM_RESET);
    writeLine(MODEM_INIT);
}


bool SportsterVoice::writeLine(String buffer)
{
    String buf1, buf2;
    
    struct pollfd pollRead[1];
    struct pollfd pollWrite[1];
    pollRead[0].fd = fd;
    pollRead[0].events = POLLIN;
    pollWrite[0].fd = fd;
    pollWrite[0].events = POLLOUT;

    buf1 = buffer + "\r";
#ifdef USE_NDELAY
    poll(pollWrite, 1, 2000);
#endif
    write(fd, buf1.cstr(), buf1.length());
    while(!buf2.contains(buffer)) {
#ifdef USE_NDELAY
	poll(pollRead, 1, 2000);
#endif
	buf2 = readLine();
    }
    while(okMessages.find(buf2) == okMessages.end() && errorMessages.find(buf2) == errorMessages.end()) {
#ifdef USE_NDELAY
	poll(pollRead, 1, 2000);
#endif
	buf2 = readLine();
    }
    if(okMessages.find(buf2) != okMessages.end()) {
	return true;
    }
    else {
	return false;
    }
}

int SportsterVoice::getDes()
{
    return fd;
}

bool SportsterVoice::getLocked()
{
    return locked;
}

void SportsterVoice::setLocked(bool lock)
{
    locked=lock;
}

#ifdef VOICE
void SportsterVoice::recordFile(String& file, target where)
{
    String gsmFile = file + ".gsm";
    String wavFile = file + ".wav";
    String rawFile = file + ".raw";
    unsigned char buf[1024];
    
    bool bunny = true;
    int numRead = 0;
    time_t now;
    int numFrame = 3000;
    int bytesPerFrame = 38;
    
    
    struct pollfd pollRead[1];
    struct pollfd pollWrite[1];
    
    pollRead[0].fd = fd;
    pollRead[0].events = POLLIN;
    pollWrite[0].fd = fd;
    pollWrite[0].events = POLLOUT;
    
    now = time(NULL);

    writeLine("AT&F1");
    /* select voice mode */
    writeLine("AT #CLS=8");
    
    writeLine("AT #VSM=128,8000");

#ifdef SILENCE    
    writeLine("AT #VSP=0");
    writeLine("AT #VSD=0");
    writeLine("AT #VSS=0");
#endif    
    //writeLine("AT S41=4");
    
    /* select appropriate input device */
    
    switch(where) {
    case line:
	writeLine("AT #VLS=0");
	break;
    case handset:
	writeLine("AT #VLS=1");
	break;
    case speaker:
	writeLine("AT #VLS=2");
	break;
    case microphone:
	writeLine("AT #VLS=3");
	break;
    case line_speaker:
	writeLine("AT #VLS=4");
	break;
    case speakerphone:
	writeLine("AT #VLS=6");
	break;
    default:
	writeLine("AT #VLS=0");
    }
    
    
    FILE* fp = fopen(file.cstr(), "w");
    FILE* gsmfp = fopen(gsmFile.cstr(), "w");
    
    writeLine("AT#VRX");
    
    bool thisFrameQuiet = false;
    bool lastFrameQuiet = false;

    bool firstByteQuiet = false; 
    bool secndByteQuiet = false; 

    int numQuietFrame = 0;

    int maxQuietFrame = 100;

    for(int i=0; (i<numFrame) && bunny; i++) {
#ifdef DEBUG
	printf("Frame %d: ", i);
#endif

	lastFrameQuiet = thisFrameQuiet;
	thisFrameQuiet = false;

	for(int j=0; (j<bytesPerFrame); j++) {
	    numRead = read(fd, buf, 1);
	    if(numRead == 1) {
		if(buf[0] != DLE) {
		    if(j == 0) {
			if(buf[0] == 0xb6) {
			    firstByteQuiet = true;
			}
			else {
			    firstByteQuiet = false;
			}
		    }
		    else if(j == 1) {
			if(buf[0] == 0xb6) {
			    secndByteQuiet = true;
			}
			else {
			    secndByteQuiet = false;
			}
			
			if( firstByteQuiet && secndByteQuiet ) {
			    thisFrameQuiet = true;
			}
			else {
			    thisFrameQuiet = false;
			}

			if(thisFrameQuiet && lastFrameQuiet) {
			    numQuietFrame++;
			}
			else {
			    numQuietFrame = 0;
			}

			if(numQuietFrame > maxQuietFrame) {
			    bunny = false;
			}
		    }
#ifdef DEBUG
		    printf("%02x", buf[0]);
#endif
		    fwrite(buf, sizeof(char), 1, fp);
		    if(j > 1 && j < (bytesPerFrame-3)) {
			fwrite(buf, sizeof(char), 1, gsmfp);
		    }
		}
		else {
		    numRead = read(fd, buf, 1);
		    
		    while(numRead != 1) {
			numRead = read(fd, buf, 1);
		    }
		    buf[1]=0;

		    if(buf[0] == DLE) {
#ifdef DEBUG
			printf("%02x", buf[0]);
#endif
			fwrite(buf, sizeof(unsigned char), 1, fp);
			//if(j > 1 && j < (bytesPerFrame-3)) {
			    fwrite(buf, sizeof(char), 1, gsmfp);
			    //}
		    }
		    else {
			j--;
		    }
		}
	    }
	    else {
		j--;
	    }
	}
#ifdef DEBUG
	printf("\n");
#endif
    }
    
    buf[0]=0x10;
    write(fd, buf, 1);
    
    fclose(fp);
    fclose(gsmfp);

    /* untoast the gsm file */

    String toast = String(TOAST_PATH) + " -dlc " + gsmFile + " > " + rawFile;
    system(toast.cstr());

    /* convert to wav */
    FILE* wavfp = fopen(wavFile.cstr(), "w");
    FILE* rawfp = fopen(rawFile.cstr(), "r");

    struct stat mystat;
    stat(rawFile.cstr(), &mystat);
    numRead = mystat.st_size;
    
    int recBitsPerSample = 16;
    int recSamplesPerSec = 8000;
    int recNumChannels = 1;
    //double recSecFraction = 0.25;
    
    char groupID[8], riffType[5], chunkID[5];
    long chunkSize;
    short wFormatTag;
    unsigned short wChannels;
    unsigned long dwSamplesPerSec;
    unsigned long dwAvgBytesPerSec;
    unsigned short wBlockAlign;
    unsigned short wBitsPerSample;
    
    int bufSize = numRead;
    unsigned char* recBuf = new unsigned char[bufSize];
    
    
    strcpy(groupID, "RIFF");
    strcpy(riffType, "WAVE");
    strcpy(chunkID, "fmt ");
    chunkSize = 16;
    
    wFormatTag = 1;
    wChannels = recNumChannels;
    dwSamplesPerSec = recSamplesPerSec;
    wBlockAlign = recNumChannels*recBitsPerSample/8;
    dwAvgBytesPerSec = recSamplesPerSec*wBlockAlign;
    wBitsPerSample = recBitsPerSample;
    
    fwrite(groupID,sizeof(char),8,wavfp);
    fwrite(riffType,sizeof(char),4,wavfp);
    fwrite(chunkID,sizeof(char),4,wavfp);
    fwrite(&chunkSize,sizeof(long),1,wavfp);
    fwrite(&wFormatTag,sizeof(short),1,wavfp);
    fwrite(&wChannels,sizeof(unsigned short),1,wavfp);
    fwrite(&dwSamplesPerSec,sizeof(unsigned long),1,wavfp);
    fwrite(&dwAvgBytesPerSec,sizeof(unsigned long),1,wavfp);
    fwrite(&wBlockAlign,sizeof(unsigned short),1,wavfp);
    fwrite(&wBitsPerSample,sizeof(unsigned short),1,wavfp);
    
    strcpy(chunkID, "data");
    chunkSize = numRead;
    
    fwrite(chunkID,sizeof(char),4,wavfp);
    fwrite(&chunkSize,sizeof(long),1,wavfp);
    
    for(int i=0; i< numRead; i+= bufSize) {
	fread(recBuf, sizeof(char), bufSize, rawfp);
	fwrite(recBuf, sizeof(char), bufSize, wavfp);
    }

    fclose(rawfp);        
    fclose(wavfp);

    /* done with conversion */
    
    String newBuf;
    
    newBuf = readLine();
    while(okMessages.find(newBuf) == okMessages.end() && errorMessages.find(newBuf) == errorMessages.end()) {
	newBuf = readLine();
    }
    
    writeLine("at#vls=0");
    writeLine("at#cls=0");
    
    writeLine(MODEM_RESET);
    writeLine(MODEM_INIT);
}
#endif

#ifdef VOICE
void SportsterVoice::playFile(String& file, target where)
{
    unsigned char buf[1024];
    String newBuf;
    
    FILE* fp;
    
    struct pollfd pollRead[1];
    struct pollfd pollWrite[1];
    
    pollRead[0].fd = fd;
    pollRead[0].events = POLLIN;
    pollWrite[0].fd = fd;
    pollWrite[0].events = POLLOUT;
    

    if( (fp = fopen(file.cstr(), "r")) == NULL) {
	return;
    }
    
    writeLine("AT&F1");
    /* select voice mode */
    writeLine("at#cls=8");
    writeLine("AT #VSM=128,8000");
    /* select speaker output device */
    
    switch(where) {
    case line:
	writeLine("AT #VLS=0");
	break;
    case handset:
	writeLine("AT #VLS=1");
	break;
    case speaker:
	writeLine("AT #VLS=2");
	break;
    case microphone:
	writeLine("AT #VLS=3");
	break;
    case line_speaker:
	writeLine("AT #VLS=4");
	break;
    case speakerphone:
	writeLine("AT #VLS=6");
	break;
	
    }
    
    writeLine("at#vtx");
    
    while(!feof(fp)) {
	int n = fread(buf, sizeof(unsigned char), 1, fp);
	if(n == 1) {
	    if(buf[0] == DLE) {
		write(fd, buf, n);
	    }
	    write(fd, buf, n);
	}
    }
    
    char temp[4];
    temp[0] = DLE;
    temp[1] = ETX;
    write(fd, temp, 2);
    
    fclose(fp);
    
    newBuf = readLine();

    while(okMessages.find(newBuf) == okMessages.end() && errorMessages.find(newBuf) == errorMessages.end()) {
	newBuf = readLine();
    }
    
    writeLine("at#vls=0");
    writeLine("at#cls=0");
    
    writeLine(MODEM_RESET);
    writeLine(MODEM_INIT);
}
#endif

#ifdef VOICE
void SportsterVoice::answerCall(String& greetingFile, String& messageFile)
{
    String gsmFile = messageFile + ".gsm";
    String wavFile = messageFile + ".wav";
    String rawFile = messageFile + ".raw";

    writeLine("AT&F1");
    /* select voice mode */
    writeLine("AT #CLS=8");
    
    writeLine("AT #VSM=128,8000");
    
    //writeLine("AT S41=4");
    
    /* select telephone line device */
    
    writeLine("AT #VLS=0");
    
    unsigned char buf[1024];
    String newBuf;
    
    FILE* fp;
    if( (fp = fopen(greetingFile.cstr(), "r")) == NULL) {
	return;
    }
    
    writeLine("AT A");
    
    writeLine("AT #VTX");
    
    while(!feof(fp)) {
	int n = fread(buf, sizeof(unsigned char), 1, fp);
	if(n == 1) {
	    if(buf[0] == DLE) {
		write(fd, buf, n);
	    }
	    write(fd, buf, n);
	}
    }
    
    char temp[4];

    temp[0] = DLE;
    temp[1] = ETX;
    write(fd, temp, 2);
    
    newBuf = readLine();
    while(okMessages.find(newBuf) == okMessages.end() && errorMessages.find(newBuf) == errorMessages.end()) {
	newBuf = readLine();
    }
    
    fclose(fp);
    

    writeLine("AT #VTS=\"{3,10}\"");
    
    /*
      greeting done, record message
    */
    
    fp = fopen(messageFile.cstr(), "w");
    FILE* gsmfp = fopen(gsmFile.cstr(), "w");

#ifdef SILENCE        
    writeLine("AT #VSP=20");
    writeLine("AT #VSD=1");
    writeLine("AT #VSS=1");
#endif    

    writeLine("AT #VRX");
    
    bool bunny = true;
    int numRead = 0;

    int numFrame = 3000;
    int bytesPerFrame = 38;

    bool thisFrameQuiet = false;
    bool lastFrameQuiet = false;

    bool firstByteQuiet = false; 
    bool secndByteQuiet = false; 

    int numQuietFrame = 0;

    int maxQuietFrame = 100;

    for(int i=0; (i<numFrame) && bunny; i++) {
#ifdef DEBUG
	printf("Frame %d: ", i);
#endif

	lastFrameQuiet = thisFrameQuiet;
	thisFrameQuiet = false;

	for(int j=0; (j<bytesPerFrame); j++) {
	    numRead = read(fd, buf, 1);
	    if(numRead == 1) {
		if(buf[0] != DLE) {
		    if(j == 0) {
			if(buf[0] == 0xb6) {
			    firstByteQuiet = true;
			}
			else {
			    firstByteQuiet = false;
			}
		    }
		    else if(j == 1) {
			if(buf[0] == 0xb6) {
			    secndByteQuiet = true;
			}
			else {
			    secndByteQuiet = false;
			}
			
			if( firstByteQuiet && secndByteQuiet ) {
			    thisFrameQuiet = true;
			}
			else {
			    thisFrameQuiet = false;
			}

			if(thisFrameQuiet && lastFrameQuiet) {
			    numQuietFrame++;
			}
			else {
			    numQuietFrame = 0;
			}

			if(numQuietFrame > maxQuietFrame) {
			    bunny = false;
			}
		    }
#ifdef DEBUG
		    printf("%02x", buf[0]);
#endif
		    fwrite(buf, sizeof(char), numRead, fp);
		    if(j > 1 && j < (bytesPerFrame-3)) {
			fwrite(buf, sizeof(char), 1, gsmfp);
		    }
		}
		else {
		    numRead = read(fd, buf, 1);
		    
		    while(numRead != 1) {
			numRead = read(fd, buf, 1);
		    }
		    buf[1]=0;

		    if(buf[0] == DLE) {
			printf("%02x", buf[0]);
			fwrite(buf, sizeof(unsigned char), 1, fp);
			fwrite(buf, sizeof(char), 1, gsmfp);
		    }
		    else {
			j--;
		    }
		}
	    }
	    else {
		j--;
	    }
	}
#ifdef DEBUG
	printf("\n");
#endif
    }
    
    buf[0]=0x10;
    write(fd, buf, 1);
    
    fclose(fp);
    fclose(gsmfp);

    /* untoast the gsm file */

    String toast = String(TOAST_PATH) + " -dlc " + gsmFile + " > " + rawFile;
    system(toast.cstr());

    /* convert to wav */
    FILE* wavfp = fopen(wavFile.cstr(), "w");
    FILE* rawfp = fopen(rawFile.cstr(), "r");

    struct stat mystat;
    stat(rawFile.cstr(), &mystat);
    numRead = mystat.st_size;
    
    int recBitsPerSample = 16;
    int recSamplesPerSec = 8000;
    int recNumChannels = 1;
    //double recSecFraction = 0.25;
    
    char groupID[8], riffType[5], chunkID[5];
    long chunkSize;
    short wFormatTag;
    unsigned short wChannels;
    unsigned long dwSamplesPerSec;
    unsigned long dwAvgBytesPerSec;
    unsigned short wBlockAlign;
    unsigned short wBitsPerSample;
    
    int bufSize = numRead;
    unsigned char* recBuf = new unsigned char[bufSize];
    
    
    strcpy(groupID, "RIFF");
    strcpy(riffType, "WAVE");
    strcpy(chunkID, "fmt ");
    chunkSize = 16;
    
    wFormatTag = 1;
    wChannels = recNumChannels;
    dwSamplesPerSec = recSamplesPerSec;
    wBlockAlign = recNumChannels*recBitsPerSample/8;
    dwAvgBytesPerSec = recSamplesPerSec*wBlockAlign;
    wBitsPerSample = recBitsPerSample;
    
    fwrite(groupID,sizeof(char),8,wavfp);
    fwrite(riffType,sizeof(char),4,wavfp);
    fwrite(chunkID,sizeof(char),4,wavfp);
    fwrite(&chunkSize,sizeof(long),1,wavfp);
    fwrite(&wFormatTag,sizeof(short),1,wavfp);
    fwrite(&wChannels,sizeof(unsigned short),1,wavfp);
    fwrite(&dwSamplesPerSec,sizeof(unsigned long),1,wavfp);
    fwrite(&dwAvgBytesPerSec,sizeof(unsigned long),1,wavfp);
    fwrite(&wBlockAlign,sizeof(unsigned short),1,wavfp);
    fwrite(&wBitsPerSample,sizeof(unsigned short),1,wavfp);
    
    strcpy(chunkID, "data");
    chunkSize = numRead;
    
    fwrite(chunkID,sizeof(char),4,wavfp);
    fwrite(&chunkSize,sizeof(long),1,wavfp);
    
    for(int i=0; i< numRead; i+= bufSize) {
	fread(recBuf, sizeof(char), bufSize, rawfp);
	fwrite(recBuf, sizeof(char), bufSize, wavfp);
    }

    fclose(rawfp);        
    fclose(wavfp);

    /* done with conversion */
    
    newBuf = readLine();

    while(okMessages.find(newBuf) == okMessages.end() && errorMessages.find(newBuf) == errorMessages.end()) {
	newBuf = readLine();
    }
    
    writeLine("AT H0");
    
    //writeLine("at#vls=0");
    writeLine("at#cls=0");
    
    writeLine(MODEM_RESET);
    writeLine(MODEM_INIT);
    
}

#endif
