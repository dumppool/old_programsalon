/* -*- C++ -*-
 * 
 * Copyright (c) 1999 Joe Yandle <yandle@cs.unc.edu>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#ifndef DATABASEOBJECT_H
#define DATABASEOBJECT_H

#include "defs.h"

#include <map.h>
#include "String.h"
#include "Database.h"


class DatabaseObject
{
public:
    DatabaseObject();
    DatabaseObject(Database* d, String tName);
    DatabaseObject(Database* d, String tName, String primID);
    
    String get(String key);
    void set(String key, String val);

    void setOrder(String order);
    String getOrder();

    void insert();
    void remove();
    void update();

    bool fill();
    
    ResultSet* select();

protected:
    String orderField;
    Database* data;
    Hashtable dataHash;
    String tableName;
    StringVector columnVector;

private:
    void setColumns();

};

#endif
