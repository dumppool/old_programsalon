/* -*- C++ -*-
 * MsqlDatabase.C - source file for class MsqlDatabase
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "MsqlDatabase.h"
#include "MsqlResultSet.h"

#include <stdlib.h>

String dbase = "gnuvoice";

String createCall = "CREATE TABLE Call ( CallID int NOT NULL, CallerID int NOT NULL, CallDate CHAR(255) NOT NULL, CallTime time NOT NULL, MessageID int NOT NULL )";
String createCallSeq = "CREATE SEQUENCE ON Call STEP 1 VALUE 1";

String createCaller = "CREATE TABLE Caller ( CallerID int NOT NULL, CallerName CHAR(255) NOT NULL, CallerNumber CHAR(255) NOT NULL, TagID int NOT NULL )";
String createCallerSeq = "CREATE SEQUENCE ON Caller STEP 1 VALUE 1";

String createMessage = "CREATE TABLE Message ( MessageID int NOT NULL, MessageFile CHAR(255) NOT NULL )";
String createMessageSeq = "CREATE SEQUENCE ON Message STEP 1 VALUE 1";

String createTag = "CREATE TABLE Tag ( TagID int NOT NULL, TagFile CHAR(255) NOT NULL )";
String createTagSeq = "CREATE SEQUENCE ON Tag STEP 1 VALUE 1";


bool MsqlDatabase::open() {
    if((sock=msqlConnect(NULL)) == -1) {
	return false;
    }  
    if(msqlSelectDB(sock,dbase.cstr()) == -1) {
	return false;
    }

    executeUpdate(createCall);
    executeUpdate(createCallSeq);
    executeUpdate(createCaller);
    executeUpdate(createCallerSeq);
    executeUpdate(createMessage);
    executeUpdate(createMessageSeq);
    executeUpdate(createTag);
    executeUpdate(createTagSeq);

    return true;
    
}

bool MsqlDatabase::useSeq() {
    return true;
}


String MsqlDatabase::escapeArg(String arg) {
    String temp(2*arg.length()+1);

    for(int i=0; i<arg.length(); i++) {
	if(arg(i) == "'") {
	    temp += "\\";
	}
	temp += arg(i);
    }

    return temp;
}


ResultSet* MsqlDatabase::executeQuery(String sql) {
    m_result* res;

    printf("SQL = %s\n", sql.cstr());
    /*
      Since msql doesn't implement the SQL DESC clause,
      it is necessary to run a different query if that
      is the desired resultset
     */
    if(sql(0,4) == "DESC") {
	StringVector vec = sql.tokenize();
	String tableName = vec[1];

	res = msqlListFields(sock, tableName.cstr());
    }
    else {
	msqlQuery(sock,sql.cstr());
	res = msqlStoreResult();
    }

    MsqlResultSet* retVal = new MsqlResultSet(res);
    return (ResultSet*)retVal;
}

void MsqlDatabase::executeUpdate(String sql) {
    /*
      Since msql uses sequences instead of auto_increment fields,
      inserts require that we first get the next value from the
      sequence, then modify the original SQL string.
     */
    if(sql.contains("INSERT INTO")) {
	StringVector vec = sql.tokenize();
	String tableName = vec[2];

	String seqSql = "SELECT _seq FROM " + tableName;
	ResultSet* res = executeQuery(seqSql);
	res->next();
	String objID = res->getString(0);

	String newSql;

	for(int i=0; i<(int)vec.size(); i++) {
	    newSql += (vec[i] + " ");
	    
	    if(vec[i] == "(") {
		if(vec[i-1] == tableName) {
		    newSql += (tableName + "ID, ");
		}
		else if(vec[i-1] == "VALUES") {
		    newSql += (objID + ", ");
		}
	    }
	}

	sql = newSql;

	delete res;	
    }
    printf("SQL = %s\n", sql.cstr());
    msqlQuery(sock, sql.cstr());
}
