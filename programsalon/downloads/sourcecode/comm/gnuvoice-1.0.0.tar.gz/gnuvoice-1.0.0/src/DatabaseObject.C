/* -*- C++ -*-
 * DatabaseObject.C - source file for class DatabaseObject
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "DatabaseObject.h"
#include <iterator.h>

/*
  DatabaseObject::DatabaseObject()
*/
DatabaseObject::DatabaseObject()
{

}

/*
  DatabaseObject::DatabaseObject(Database* d, String tableName)
*/
DatabaseObject::DatabaseObject(Database* d, String tName)
    : tableName(tName)
{
    data = d;
    setColumns();
}

/*
  DatabaseObject::DatabaseObject(Database* d, String tableName, String primaryID)
*/
DatabaseObject::DatabaseObject(Database* d, String tName, String pID)
    : tableName(tName)
{
    data = d;
    setColumns();

    String temp(tableName + "ID");
    set(temp, pID);
    fill();
}


/*
  String DatabaseObject::get(String key)
*/
String DatabaseObject::get(String key)
{
    return dataHash[key];
}

/*
  void DatabaseObject::set(String key, String val)
*/
void DatabaseObject::set(String key, String val)
{
    if(dataHash[key] != val) {
	dataHash.erase(key);
	dataHash.insert( Hashtable::value_type(key, val)  );
    }
}


/*
  void DatabaseObject::setOrder(String order)
*/
void DatabaseObject::setOrder(String order)
{
    orderField = order;
}

/*
  String DatabaseObject::getOrder()
*/
String DatabaseObject::getOrder()
{
    return orderField;
}




/*
  void DatabaseObject::insert()
*/
void DatabaseObject::insert()
{
    String sql("INSERT INTO " + tableName + " ( ");

    Hashtable::iterator i;

    for(i=dataHash.begin(); i != dataHash.end(); i++) {
	sql += (*i).first;

	if(++i != dataHash.end()) {
	    sql += ", ";
	}
	i--;
    }

    sql += " ) VALUES ( ";

    for(i=dataHash.begin(); i != dataHash.end(); i++) {
	if((*i).first.contains("ID")) {
	    sql += data->escapeArg((*i).second);
	}
	else {
	    sql += "'" + data->escapeArg((*i).second) + "'";
	}

	if(++i != dataHash.end()) {
	    sql += ", ";
	}
	i--;
    }

    sql += " )";

    //printf("SQL = %s\n", sql.cstr());

    data->executeUpdate( sql );
}

/*
  void DatabaseObject::delete()
*/
void DatabaseObject::remove()
{
    String sql("DELETE FROM " + tableName + " WHERE " + tableName + "ID = " + get(tableName+"ID"));
    data->executeUpdate( sql );    
}


/*
  void DatabaseObject::update()
*/
void DatabaseObject::update()
{
    String sql("UPDATE " + tableName + " SET ");

    Hashtable::iterator i;

    for(i=dataHash.begin(); i != dataHash.end(); i++) {
	if((*i).first.contains("ID")) {
	    sql += (*i).first + " = " + data->escapeArg( (*i).second );
	}
	else {
	    sql += (*i).first + " = '" + data->escapeArg( (*i).second ) + "'";
	}

	if(++i != dataHash.end()) {
	    sql += ", ";
	}
	i--;
    }

    sql += " WHERE " + tableName + "ID = " + get(tableName+"ID");

    //printf("SQL = %s\n", sql.cstr());

    data->executeUpdate( sql );
}


/*
  void DatabaseObject::fill()
*/
bool DatabaseObject::fill()
{
    ResultSet* res = select();
    if(res->next()) {
	Hashtable hash = res->getHashtable();
	
	for(Hashtable::iterator i = hash.begin(); i != hash.end(); i++) {
	    set( (*i).first, (*i).second);
	}
	
	delete res;
	return true;
    }
    else {
	delete res;
	return false;
    }
    delete res;
}


/*
  void DatabaseObject::select()
*/
ResultSet* DatabaseObject::select()
{
    String sql("SELECT * FROM " + tableName + " WHERE ");

    Hashtable::iterator i;

    for(i=dataHash.begin(); i != dataHash.end(); i++) {
	if((*i).first.contains("ID")) {
	    sql += (*i).first + " = " + data->escapeArg( (*i).second );
	}
	else {
	    sql += (*i).first + " = '" + data->escapeArg( (*i).second ) + "'";
	}

	if(++i != dataHash.end()) {
	    sql += " AND ";
	}
	i--;
    }

    if(orderField.length() > 0) {
	sql += (" ORDER BY " + orderField);
    }

    //printf("SQL = %s\n", sql.cstr());

    return data->executeQuery( sql );
}

/*
  void Database::setColumns()
*/
void DatabaseObject::setColumns()
{
    String sql = "DESC " + tableName;
    ResultSet* res = data->executeQuery(sql);

    while(res->next()) {
	columnVector.push_back(res->getString("Field"));
    }

    delete res;
}
