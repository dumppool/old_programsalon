/* -*- C++ -*-
 * 
 * Copyright (c) 1999 Joe Yandle <yandle@cs.unc.edu>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#ifndef STRING_H
#define STRING_H

#include "gtk--.h"

typedef vector<class String> StringVector;

class String
{
 public:
    String();
    String(const String& s);
    String(int size);
    String(char* s);
    String(const char* s);
    String(const string& s);
    String(const _gtk_string& s);
    ~String();

    static String valueOf(int i);
    static String valueOf(double i);

    void chop();
    void chopWhite();

    void setSize();

    char* cstr() const;
    string str() const;
    _gtk_string gstr() const;

    int length() const;
    bool contains(String s) const;

    StringVector tokenize() const;
    StringVector tokenize(const String& delim) const;

    String operator=(const String& s);
    String operator=(const char* s);
    String operator+=(const String& s);

    String operator()(int i) const;
    String operator()(int i, int j) const;

    friend String operator+(const String& s1, const String& s2);
    friend String operator+(const String& s1, const char* s2);
    friend String operator+(const String& s1, const int i);
    friend String operator+(const String& s1, const double i);
    friend String operator+(const char* s1, const String& s2);

    friend bool operator==(const String& s1, const String& s2);
    friend bool operator!=(const String& s1, const String& s2);

    friend bool operator<=(const String& s1, const String& s2);
    friend bool operator>=(const String& s1, const String& s2);

    friend bool operator<(const String& s1, const String& s2);
    friend bool operator>(const String& s1, const String& s2);

 private:
    char* data;
    int sz;

};

#endif
