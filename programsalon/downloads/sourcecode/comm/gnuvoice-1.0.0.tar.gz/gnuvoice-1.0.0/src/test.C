#include <gtk--.h>
#include "String.h"

int main()
{
    while(true) {
	printf("Creating Gtk_Window objects... ");
	//for(int i=0; i<100; i++) {
	String title("Window");
	Gtk_Window* win = new Gtk_Window(GTK_WINDOW_TOPLEVEL);
	sleep(1);
	win->set_title(title.gstr());
	win->set_default_size(100,100);
	printf("Showing Gtk_Window objects... ");	
	win->show_all();
	sleep(1);
	while (gtk_events_pending()) {
	    gtk_main_iteration();
	}
	printf("Sleeping... ");
	sleep(1);
	printf("Hiding... ");
	win->hide();
	sleep(1);
	printf("Deleting... ");
	delete (Gtk_Widget*)win;
	sleep(1);
	printf("done.\n");
    }
}
