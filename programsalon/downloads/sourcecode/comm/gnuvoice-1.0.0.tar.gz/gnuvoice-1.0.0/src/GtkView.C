/* -*- C++ -*-
 * GtkView.C - source file for class GtkView
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "GtkView.h"
#include "GtkModel.h"
#include "Speaker.h"
#include "String.h"

#include "GtkMessageWin.h"

#include <string.h>
#include <stdio.h>
#include <time.h>

#include "Caller.h"
#include "Tag.h"
#include "Call.h"
#include "Message.h"

GtkView::GtkView(GtkModel* m)
{
    speaker = new Speaker(this);
    
    setModel(m);
    
    numRows=0;
    rowSelect = -1;
    
    vbox = new Gtk_VBox(FALSE, 0);
#ifdef VOICE
    set_default_size(550, 350);
#else
    set_default_size(490, 350);
#endif


    set_title("gnuvoice");
    set_policy(TRUE,TRUE,FALSE);
    
    accelGroup = new Gtk_AccelGroup();
    
    itemFactory = new Gtk_ItemFactory_MenuBar("<Main>", *accelGroup);
    itemFactory->create_item("/File", 0, "<Branch>", 0);  
    itemFactory->create_item("/File/Quit", "<control>Q", "<Item>", ItemFactoryConnector<GtkView,string>(this,&fileCallback,"Quit"));
    
    itemFactory->create_item("/Edit", 0, "<Branch>", 0);  
    //itemFactory->create_item("/Edit/View", "<control>L", "<Item>", ItemFactoryConnector<GtkView,string>(this,&folderCallback,"View"));
    itemFactory->create_item("/Edit/Edit Name", "<control>N", "<Item>", ItemFactoryConnector<GtkView,string>(this,&editCallback,"Edit Name"));
    itemFactory->create_item("/Edit/Edit Tag", "<control>G", "<Item>", ItemFactoryConnector<GtkView,string>(this,&editCallback,"Edit Tag"));
    itemFactory->create_item("/Edit/Play Tag", "<control>P", "<Item>", ItemFactoryConnector<GtkView,string>(this,&editCallback,"Play Tag"));
    itemFactory->create_item("/Edit/Record Tag", "<control>R", "<Item>", ItemFactoryConnector<GtkView,string>(this,&editCallback,"Record Tag"));
    
    itemFactory->create_item("/Search", 0, "<Branch>", 0);  
    itemFactory->create_item("/Search/Search by Date", "<control>D", "<Item>", ItemFactoryConnector<GtkView,string>(this,&searchCallback,"Search by Date"));
    itemFactory->create_item("/Search/Search by Name", "<control>M", "<Item>", ItemFactoryConnector<GtkView,string>(this,&searchCallback,"Search by Name"));
    itemFactory->create_item("/Search/Search by Number", "<control>B", "<Item>", ItemFactoryConnector<GtkView,string>(this,&searchCallback,"Search by Number"));
    
    itemFactory->create_item("/Daemon", 0, "<Branch>", 0);  
    itemFactory->create_item("/Daemon/Start Daemon", "<control>S", "<Item>", ItemFactoryConnector<GtkView,string>(this,&daemonCallback,"Start Daemon"));
    itemFactory->create_item("/Daemon/Stop Daemon", "<control>T", "<Item>", ItemFactoryConnector<GtkView,string>(this,&daemonCallback,"Stop Daemon"));
#ifdef VOICE
    itemFactory->create_item("/Voice", 0, "<Branch>", 0);
    itemFactory->create_item("/Voice/Greeting", 0, "<Branch>", 0);
    itemFactory->create_item("/Voice/Greeting/Record Greeting", "<control>E", "<Item>", ItemFactoryConnector<GtkView,string>(this,&voiceCallback,"Record Greeting"));
    itemFactory->create_item("/Voice/Greeting/Play Greeting", 0, "<Branch>", 0);
    itemFactory->create_item("/Voice/Greeting/Play Greeting/Through Soundcard", "<control>L", "<Item>", ItemFactoryConnector<GtkView,string>(this,&voiceCallback,"Play Greeting Soundcard"));
    itemFactory->create_item("/Voice/Greeting/Play Greeting/Through Modem", 0, "<Item>", ItemFactoryConnector<GtkView,string>(this,&voiceCallback,"Play Greeting Modem"));
    itemFactory->create_item("/Voice/Message", 0, "<Branch>", 0);
    itemFactory->create_item("/Voice/Message/Play Message", 0, "<Branch>", 0);
    itemFactory->create_item("/Voice/Message/Play Message/Through Soundcard", "<control>V", "<Item>", ItemFactoryConnector<GtkView,string>(this,&voiceCallback,"Play Message Soundcard"));
    itemFactory->create_item("/Voice/Message/Play Message/Through Modem", 0, "<Item>", ItemFactoryConnector<GtkView,string>(this,&voiceCallback,"Play Message Modem"));
    itemFactory->create_item("/Voice/Message/Delete Message", "<control>U", "<Item>", ItemFactoryConnector<GtkView,string>(this,&voiceCallback,"Delete Message"));

    itemFactory->create_item("/Voice/Call", 0, "<Branch>", 0);
    itemFactory->create_item("/Voice/Call/Return Call", 0, "<Branch>", 0);
    itemFactory->create_item("/Voice/Call/Return Call/Through Handset", "<control>C", "<Item>", ItemFactoryConnector<GtkView,string>(this,&voiceCallback,"Handset Return Call"));
    itemFactory->create_item("/Voice/Call/Return Call/Through Speakerphone", 0, "<Item>", ItemFactoryConnector<GtkView,string>(this,&voiceCallback,"Speakerphone Return Call"));
    itemFactory->create_item("/Voice/Call/Hangup Call", "<control>C", "<Item>", ItemFactoryConnector<GtkView,string>(this,&voiceCallback,"Hangup Call"));
    /*
      itemFactory->create_item("/Voice/Test", 0, "<Branch>", 0);
      itemFactory->create_item("/Voice/Test/Test Answer", "<control>O", "<Item>", ItemFactoryConnector<GtkView,string>(this,&voiceCallback,"Test Answer"));
    */
#endif
    itemFactory->create_item("/Help", 0, "<LastBranch>", 0);  
    itemFactory->create_item("/Help/About", "<control>H", "<Item>", ItemFactoryConnector<GtkView,string>(this,&helpCallback,"About"));
    
    add_accel_group(*accelGroup);
    
    vbox->pack_start((const Gtk_ObjectHandle<Gtk_Widget> &)(itemFactory->get_menubar_widget("<Main>")), FALSE, TRUE, 0);
    
#ifdef VOICE
    char* titles[] = {"CallID", "Number","Name","Date","Time","Message"};
    callList = new Gtk_CList(6,(const gchar**)titles);
    for(int i=0;i<6;i++) {
	callList->set_column_justification(i,GTK_JUSTIFY_CENTER);
    }
    callList->set_column_width(0,40);
    callList->set_column_width(1,100);
    callList->set_column_width(2,150);
    callList->set_column_width(3,80);
    callList->set_column_width(4,60);
    callList->set_column_width(5,60);
    callList->set_selection_mode(GTK_SELECTION_SINGLE );
#else
    char* titles[] = {"CallID", "Number","Name","Date","Time"};
    callList = new Gtk_CList(5,(const gchar**)titles);
    for(int i=0;i<5;i++) {
	callList->set_column_justification(i,GTK_JUSTIFY_CENTER);
    }
    callList->set_column_width(0,40);
    callList->set_column_width(1,100);
    callList->set_column_width(2,150);
    callList->set_column_width(3,80);
    callList->set_column_width(4,60);
    callList->set_selection_mode(GTK_SELECTION_SINGLE );

#endif
    
    updateView();
    
    callListWin = new Gtk_ScrolledWindow();
    callListWin->set_policy(GTK_POLICY_AUTOMATIC,GTK_POLICY_AUTOMATIC);  
    
    callListWin->add(callList);
    vbox->pack_start(*callListWin, TRUE, TRUE, 0);

    statusBar = new Gtk_Label();
    statusBar->set_alignment(0.0, 0.5);
    updateModemStatus();
    vbox->pack_end(*statusBar, FALSE, FALSE, 0);

    add(*vbox);
        
    connect_to_method(callList->select_row, this, &selectionMade);
    connect_to_method(callList->unselect_row, this, &selectionMade);
    
    show_all();
    
}

void GtkView::destroy() 
{
    model->quitModel();
}


void GtkView::displayAbout() 
{ 
    StringVector s;
    s.push_back("gnuvoice-1.0.0 (c) 1999");
    s.push_back("Joe Yandle <joe@wlcg.com>");

    GtkMessageWin* m;
    m = new GtkMessageWin(s);
}

void GtkView::editNameCallback() 
{
    if(rowSelect == -1)
	return;
    
    Gtk_Dialog* aboutd;
    Gtk_Button* okbutton;
    Gtk_Button* cabutton;
    Gtk_Entry* name_entry;
    Gtk_HBox* hbox;
    
    hbox = new Gtk_HBox(TRUE,0);
    
    okbutton = new Gtk_Button("Ok");
    cabutton = new Gtk_Button("Cancel");
    aboutd = new Gtk_Dialog();
    
    //char num[64];
    _gtk_string num;
    callList->get_text(rowSelect,1,&num);
    
    char dtitle[256];
    sprintf(dtitle, "Edit name for %s", num.c_str());
    aboutd->set_title(dtitle);
    
    //char name[64];
    _gtk_string name;
    callList->get_text(rowSelect,2,&name);
    
    name_entry = new Gtk_Entry();
    name_entry->set_text(name.c_str());
    
    hbox->pack_start(*name_entry, FALSE, TRUE, 20);
    
    aboutd->get_vbox()->pack_start(*hbox, TRUE, TRUE, 10);
    aboutd->get_action_area()->pack_start(*okbutton,TRUE, TRUE, 25);
    aboutd->get_action_area()->pack_start(*cabutton,TRUE, TRUE, 25);
    aboutd->set_position(GTK_WIN_POS_CENTER);    
    okbutton->show();
    cabutton->show();
    name_entry->show();
    hbox->show();
    aboutd->show();
    
    connect_to_method(name_entry->activate,this,  &updateNameCallback, (Gtk_Entry*)name_entry);
    connect_to_method(okbutton->clicked,this, &updateNameCallback, (Gtk_Entry*)name_entry);
    connect_to_method(name_entry->activate, this, &killWidget, (Gtk_Widget*)aboutd);
    connect_to_method(okbutton->clicked, this, &killWidget, (Gtk_Widget*)aboutd);
    connect_to_method(cabutton->clicked, this, &killWidget, (Gtk_Widget*)aboutd);
}

void GtkView::updateNameCallback(Gtk_Entry* entry)
{
    //char* name;
    _gtk_string gtkNmbr;;
    callList->get_text(rowSelect,1,&gtkNmbr);
    
    String nmbr(gtkNmbr);
    String name(entry->get_text());

    Caller caller(model->getDbase());
    caller.set("CallerNumber", nmbr);
    caller.fill();
    caller.set("CallerName", name);
    caller.update();
    
    resetList();
}

void GtkView::editTagCallback() 
{
    if(rowSelect == -1)
	return;
    
    Gtk_FileSelection* fdialog;
    
    //char* num;
    _gtk_string num;
    callList->get_text(rowSelect,1,&num);
    char dtitle[256];
    sprintf(dtitle, "Edit tag for %s", num.c_str());
    fdialog = new Gtk_FileSelection(dtitle);
    
    fdialog->show();
    fdialog->set_position(GTK_WIN_POS_CENTER);

    connect_to_method(fdialog->get_ok_button()->clicked, this, &updateTagCallback, (Gtk_FileSelection*)fdialog);
    connect_to_method(fdialog->get_selection_entry()->activate, this, &updateTagCallback, (Gtk_FileSelection*)fdialog);
    connect_to_method(fdialog->get_cancel_button()->clicked, this, &killWidget, (Gtk_Widget*)fdialog);
}

void GtkView::updateTagCallback(Gtk_FileSelection* data)
{
    //char* name;
    _gtk_string gtkNmbr;
    callList->get_text(rowSelect,1,&gtkNmbr);
    
    String tagFile(data->get_filename());
    String nmbr(gtkNmbr);

    Tag tag(model->getDbase());
    tag.set("TagFile", tagFile);
    
    if(!tag.fill()) {
	tag.insert();
	tag.fill();
    }

    Caller caller(model->getDbase());
    caller.set("CallerNumber", nmbr);
    caller.fill();
    caller.set("TagID", tag.get("TagID"));
    caller.update();

    data->delete_self();
}

void GtkView::editPlayCallback()
{
    if(rowSelect == -1)
	return;
    
    //char* num;
    _gtk_string num;  
    callList->get_text(rowSelect,1,&num);

    String nmbr(num);
    Caller caller(model->getDbase());
    caller.set("CallerNumber", nmbr);
    caller.fill();

    Tag tag(model->getDbase(), caller.get("TagID"));
    
    speaker->playWav(tag.get("TagFile"));
}


void GtkView::editRecordCallback()
{
    Gtk_FileSelection* fsel = new Gtk_FileSelection("Choose filename");
    
    connect_to_method(fsel->destroy, this, &killWidget, (Gtk_Widget*)fsel);
    connect_to_method(fsel->get_ok_button()->clicked, this, &recWav, (Gtk_FileSelection*)fsel);
    connect_to_method(fsel->get_ok_button()->clicked, this, &killWidget, (Gtk_Widget*)fsel);
    connect_to_method(fsel->get_cancel_button()->clicked, this, &killWidget, (Gtk_Widget*)fsel);
    fsel->set_position(GTK_WIN_POS_CENTER);    
    fsel->show();
}

void GtkView::recWav(Gtk_FileSelection* data)
{
    String recFile(data->get_filename());
    
    Gtk_Dialog* dialog;
    Gtk_Button* recButton;
    Gtk_Button* stopButton;
    Gtk_Button* playButton;
    Gtk_HBox* hbox;
    Gtk_Button* okButton;
    Gtk_Button* caButton;
    
    char temp1[255], temp2[255];
    temp1[0]=0;
    temp2[0]=0;
    
    hbox = new Gtk_HBox(TRUE,5);
    
    recButton = new Gtk_Button("Record");
    recButton->show();
    hbox->pack_start(*recButton,true,true,10);
    
    stopButton = new Gtk_Button("Stop");
    stopButton->show();
    hbox->pack_start(*stopButton,true,true,10);
    
    playButton = new Gtk_Button("Play");
    playButton->show();
    hbox->pack_start(*playButton,true,true,10);
    
    hbox->show();

    String* recFileRef = new String(recFile);
    
    connect_to_method(recButton->clicked, this, &recWavCallback, recFileRef);
    connect_to_method(stopButton->clicked, this, &stopRecCallback);
    connect_to_method(playButton->clicked, this, &playWavCallback, recFileRef);
    
    dialog = new Gtk_Dialog();
    dialog->get_vbox()->pack_start(*hbox,true,true,10);
    
    okButton = new Gtk_Button("Ok");
    caButton = new Gtk_Button("Cancel");
    
    dialog->set_title(recFile.cstr());
    dialog->set_position(GTK_WIN_POS_CENTER);

    dialog->get_action_area()->pack_start(*okButton,TRUE, TRUE, 25);
    dialog->get_action_area()->pack_start(*caButton,TRUE, TRUE, 25);
    
    okButton->show();
    caButton->show();
    
    connect_to_method(okButton->clicked, this, &killWidget, (Gtk_Widget*)dialog);
    connect_to_method(caButton->clicked, this, &killWidget, (Gtk_Widget*)dialog);
    connect_to_method(caButton->clicked, this, &killString, recFileRef);

    
    dialog->show();
}

void GtkView::playWavCallback(String* s)
{
    speaker->playWav(*s);
}


void GtkView::recWavCallback(String* s)
{
    speaker->recWav(*s);
}


void GtkView::stopRecCallback()
{
    setRecOn(false);
}

/*
  void GtkView::fileCallback(string item)
*/
void GtkView::fileCallback(string item)
{
    if(item == "Quit") {
	destroy();
    }
}

#ifdef VOICE
/*
  void GtkView::voiceCallback(string item)
*/
void GtkView::voiceCallback(string item)
{
    if(item == "Play Greeting Soundcard") {
	voicePlayCallback("Soundcard");
    }
    else if(item == "Play Greeting Modem") {
	voicePlayCallback("Modem");
    }
    else if(item == "Record Greeting") {
	voiceRecordCallback();
    }
    else if(item == "Play Message Soundcard") {
	voiceMessageCallback("Soundcard");
    }
    else if(item == "Play Message Modem") {
	voiceMessageCallback("Modem");
    }
    else if(item == "Delete Message") {
	voiceMessageDeleteCallback();
    }
    else if(item == "Handset Return Call") {
	if(rowSelect == -1) return;
	_gtk_string gtkNmbr;
	callList->get_text(rowSelect,1,&gtkNmbr);
	String callNmbr(gtkNmbr);

	model->handsetCallNumber(callNmbr);
    }
    else if(item == "Speakerphone Return Call") {
	if(rowSelect == -1) return;
	_gtk_string gtkNmbr;
	callList->get_text(rowSelect,1,&gtkNmbr);
	String callNmbr(gtkNmbr);
	
	model->speakerphoneCallNumber(callNmbr);
    }
    else if(item == "Hangup Call") {
	model->hangUp();
    }
    else if(item == "Test Answer") {
	model->answerCall();
    }
}
#endif

#ifdef VOICE
/*
  void GtkView::voicePlayCallback()
*/
void GtkView::voicePlayCallback(String where)
{
    if(where == "Modem") {
	model->playGreeting();
    }
    else if(where == "Soundcard") {
	String greetWav = String(getenv("HOME")) + "/.messages/greeting.wav";
	speaker->playWav(greetWav);
    }
}
#endif

#ifdef VOICE
/*
  void GtkView::voiceRecordCallback()
*/
void GtkView::voiceRecordCallback()
{
    model->recordGreeting();
}
#endif

#ifdef VOICE
/*
  void GtkView::voiceMessageCallback()
*/
void GtkView::voiceMessageCallback(String where)
{
    if(rowSelect == -1)
	return;
    
    //char* num;


    _gtk_string haveMessage;  
    callList->get_text(rowSelect,5,&haveMessage);
    
    if(haveMessage == "No") {
	return;
    }
    
    _gtk_string gtkCallID;  
    callList->get_text(rowSelect,0,&gtkCallID);
    String callID(gtkCallID);
    
    Call call(model->getDbase(), callID);
    Message message(model->getDbase(), call.get("MessageID"));
    String messageFile(message.get("MessageFile"));

    if(where == "Modem") {
	model->playMessage(messageFile);
    }
    else if(where == "Soundcard") {
	speaker->playWav(messageFile+".wav");
    }
    
}
#endif

#ifdef VOICE
/*
  void GtkView::voiceMessageDeleteCallback()
*/
void GtkView::voiceMessageDeleteCallback()
{
    if(rowSelect == -1)
	return;
    
    //char* num;


    _gtk_string haveMessage;  
    callList->get_text(rowSelect,5,&haveMessage);
    
    if(haveMessage == "No") {
	return;
    }
    
    _gtk_string gtkCallID;  
    callList->get_text(rowSelect,0,&gtkCallID);
    String callID(gtkCallID);
    
    Call call(model->getDbase(), callID);
    Message message(model->getDbase(), call.get("MessageID"));
    String messageFile(message.get("MessageFile"));

    call.set("MessageID", "0");
    call.update();

    message.remove();

    unlink(messageFile.cstr());

    resetList();
}
#endif

/*
  void GtkView::editCallback(string item)
*/
void GtkView::editCallback(string item)
{
    if(item == "Edit Name") {
	editNameCallback();
    }
    else if(item == "Edit Tag") {
	editTagCallback();
    }
    else if(item == "Play Tag") {
	editPlayCallback();
    }
    else if(item == "Record Tag") {
	editRecordCallback();
    }
}

/*
  void GtkView::searchCallback(string item)
*/
void GtkView::searchCallback(string item)
{
    Gtk_Dialog* aboutd;
    Gtk_Button* okbutton;
    Gtk_Button* cabutton;
    Gtk_Entry* name_entry;
    Gtk_HBox* hbox;
    
    hbox = new Gtk_HBox(TRUE,0);
    okbutton = new Gtk_Button("Ok");
    cabutton = new Gtk_Button("Cancel");
    aboutd = new Gtk_Dialog();

    aboutd->set_title(item.c_str());
    aboutd->set_position(GTK_WIN_POS_CENTER);
    
    name_entry = new Gtk_Entry();
    
    hbox->pack_start(*name_entry, FALSE, TRUE, 20);
    
    
    aboutd->get_vbox()->pack_start(*hbox, TRUE, TRUE, 10);
    aboutd->get_action_area()->pack_start(*okbutton, TRUE, TRUE, 25);
    aboutd->get_action_area()->pack_start(*cabutton, TRUE, TRUE, 25);
    
    if(item == "Search by Date") {
	time_t now=time(NULL);
	String temp = model->getDate(now);
	name_entry->set_text(temp.cstr());
	
	connect_to_method(okbutton->clicked, this, &searchDateUpdate, (Gtk_Entry*)name_entry);
	connect_to_method(name_entry->activate, this, &searchDateUpdate, (Gtk_Entry*)name_entry);
    }
    else if(item == "Search by Name") {
	connect_to_method(okbutton->clicked, this, &searchNameUpdate, (Gtk_Entry*)name_entry);
	connect_to_method(name_entry->activate, this, &searchNameUpdate, (Gtk_Entry*)name_entry);
    }
    else if(item == "Search by Number") {
	connect_to_method(okbutton->clicked, this, &searchNumbUpdate, (Gtk_Entry*)name_entry);
	connect_to_method(name_entry->activate, this, &searchNumbUpdate, (Gtk_Entry*)name_entry);
    }
    
    connect_to_method(okbutton->clicked, this, &killWidget, (Gtk_Widget*)aboutd);
    connect_to_method(name_entry->activate, this, &killWidget, (Gtk_Widget*)aboutd);
    connect_to_method(cabutton->clicked, this, &killWidget, (Gtk_Widget*)aboutd);
    
    aboutd->show_all();    
}

/*
  void GtkView::daemonCallback(string item)
*/
void GtkView::daemonCallback(string item)
{
    if(item == "Start Daemon") {
	model->startModel();
	updateModemStatus();
	handleEvents();
    }
    else if(item == "Stop Daemon") {
	model->stopModel();	
	updateModemStatus();
	handleEvents();
    }
}

void GtkView::updateModemStatus()
{
    char statusText[255];
    strcpy(statusText, " Modem status: ");
    if(model->modemOpen()) {
	strcat(statusText,"open, ");
    }
    else {
	strcat(statusText,"NOT open, " );
    }
    if(model->modemLock()) {
	strcat(statusText,"locked ");
    }
    else {
	strcat(statusText,"NOT locked ");
    }
    statusBar->set_text(statusText);
}

/*
  void GtkView::helpCallback(string item)
*/
void GtkView::helpCallback(string item)
{
    if(item == "About") {
	displayAbout();
    }
}


void GtkView::searchDateUpdate(Gtk_Entry* data)
{
    oldField = "CallDate";
    oldValue = String(data->get_text());
    resetList();
}

/*
  searchNameUpdate() 
*/
void GtkView::searchNameUpdate(Gtk_Entry* data)
{
    oldField = "CallerName";
    oldValue = String(data->get_text());
    resetList();
}

/*
  searchNumbUpdate() 
*/
void GtkView::searchNumbUpdate(Gtk_Entry* data)
{
    oldField = "CallerNumber";
    oldValue = String(data->get_text());
    resetList();
}

void GtkView::updateView()
{
    String today;
    time_t now = time(NULL);
    today = model->getDate(now);

    Call call(model->getDbase());
    call.set("CallDate", today);

    ResultSet* res = call.select();
    
    callList->freeze();
    while(numRows>0) {
	callList->remove_row(0);
	numRows--;
    }
    
    int n=0;

    while(res->next()) {
	Caller caller(model->getDbase(), res->getString("CallerID"));

	String callerNumber = caller.get("CallerNumber"),
	       callerName = caller.get("CallerName"),
	       callDate = res->getString("CallDate"),
	       callTime = res->getString("CallTime"),
	       callID = res->getString("CallID");
	
	String messageID;

	if(res->getString("MessageID") == "0") {
	    messageID = "No";
	}
	else {
	    messageID = "Yes";
	}

	gchar* cdata[] = { callID.cstr(), callerNumber.cstr(), callerName.cstr(), 
			   callDate.cstr(), callTime.cstr(), messageID.cstr() };
	callList->append((const gchar**)cdata);
	//delete [] cdata;
	n++;
    }
    numRows=n;
    rowSelect = -1;
    
    callList->thaw();

    oldField = "CallDate";
    oldValue = today;

    delete res;
}

void GtkView::resetList()
{
    ResultSet* res;
    Call call(model->getDbase());

    if(oldField == "CallDate") {
	call.set("CallDate", oldValue);
    }
    else if(oldField == "CallerName" || oldField == "CallerNumber") {
	Caller caller(model->getDbase());
	caller.set(oldField, oldValue);
	caller.fill();
	call.set("CallerID", caller.get("CallerID"));
    }
    res = call.select();

    callList->freeze();
    while(numRows>0) {
	callList->remove_row(0);
	numRows--;
    }
    
    int n=0;

    while(res->next()) {
	Caller caller(model->getDbase(), res->getString("CallerID"));

	String callerNumber = caller.get("CallerNumber"),
	       callerName = caller.get("CallerName"),
	       callDate = res->getString("CallDate"),
	       callTime = res->getString("CallTime"),
	       callID = res->getString("CallID");

	String messageID;

	if(res->getString("MessageID") == "0") {
	    messageID = "No";
	}
	else {
	    messageID = "Yes";
	}

	gchar* cdata[] = { callID.cstr(), callerNumber.cstr(), callerName.cstr(), 
			   callDate.cstr(), callTime.cstr(), messageID.cstr() };

	callList->append((const gchar**)cdata);
	//delete [] cdata;
	n++;
    }

    numRows=n;
    rowSelect = -1;
    
    callList->thaw();

    delete res;
}


void GtkView::selectionMade(gint row, gint column, GdkEvent* button)
{
    rowSelect = row;
}


void GtkView::selectionLost(gint row, gint column, GdkEvent* button)
{
    rowSelect = -1;
}


void GtkView::handleEvents()
{
    while (gtk_events_pending())
	gtk_main_iteration();
}

void GtkView::display(String msg1, String msg2, bool isMsg, double pause)
{
    GtkMessageWin* m;
    StringVector s;
    s.push_back(msg1);
    s.push_back(msg2);
    if(pause > 0) {
	m = new GtkMessageWin(s,(int)pause);
    }
    else {
	m = new GtkMessageWin(s);
    }
}


void GtkView::killWidget(Gtk_Widget* data)
{
    data->delete_self();
}


int GtkView::killWidgetCallback(Gtk_Widget* data)
{
    killWidget(data);
    return 0;
}


bool GtkView::getRecOn()
{
    return recOn;
}


void GtkView::setRecOn(bool on)
{
    recOn = on;
}

void GtkView::setModel(GtkModel* m)
{
    model = m;
}

gint GtkView::delete_event_impl(GdkEventAny *)
{
    model->quitModel();
    return 0;
}

void GtkView::speakWav(String wav)
{
    speaker->playWav(wav);
}

void GtkView::killString(String* ptr)
{
    delete ptr;
}
