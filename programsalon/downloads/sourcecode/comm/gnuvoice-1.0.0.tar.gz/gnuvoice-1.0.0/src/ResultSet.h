/* -*- C++ -*-
 * ResultSet.h - header file for abstract class ResultSet
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#ifndef RESULTSET_H
#define RESULTSET_H

#include "defs.h"

class ResultSet
{
 public:
    virtual ~ResultSet() {}
    virtual StringVector getVector()=0;
    virtual Hashtable getHashtable()=0;
    virtual bool next()=0;
    virtual String getString(String colName)=0;
    virtual String getString(int colNmbr)=0;

    virtual int numRows()=0;
    virtual int numCols()=0;
 protected:
    StringVector rowVector;
    StringVector colVector;
    Hashtable rowHash;
    int numRow;
    int curRow;
    int numCol;
};

#endif
