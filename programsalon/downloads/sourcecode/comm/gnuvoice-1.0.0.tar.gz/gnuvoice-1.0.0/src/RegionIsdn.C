/* -*- C++ -*-
 * RegionIsdn.C - source file for class RegionIsdn
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "RegionIsdn.h"

#include <string.h>

const String ISDN_PRE = "isdn_tty: call from";

const int MAX = 255;


bool RegionIsdn::isAllFields(String& data)
{
    return (data.contains(ISDN_PRE));
}


bool RegionIsdn::isNameField(String& data)
{
    return false;
}


bool RegionIsdn::isNmbrField(String& data)
{
    return false;
}

bool RegionIsdn::isRing(String& data)
{
    return false;
}


String RegionIsdn::getName(String& data)
{
    return String("Unknown");
}


String RegionIsdn::getNmbr(String& data)
{
    char nmbr[255];
    char temp[255];
    strcpy(temp, data.cstr());
    
    strcpy(nmbr, strtok(temp, " "));
    
    while(strcmp(nmbr, "isdn_tty:")) {
	strcpy(nmbr, strtok(NULL, " "));
    }
    
    while(strcmp(nmbr, "call")) {
	strcpy(nmbr, strtok(NULL, " "));
    }
    
    while(strcmp(nmbr, "from")) {
	strcpy(nmbr, strtok(NULL, " "));
    }
    
    strcpy(nmbr, strtok(NULL, " "));
    return String(nmbr);
}
