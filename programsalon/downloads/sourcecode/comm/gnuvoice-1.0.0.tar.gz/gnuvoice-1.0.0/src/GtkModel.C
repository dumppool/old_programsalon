/*
 * GtkModel.C - source file for class GtkModel
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "Call.h"
#include "Caller.h"
#include "Message.h"
#include "Tag.h"

#include "GtkMessageWin.h"
#include "DatabaseObject.h"
#include "String.h"
#include "GtkView.h"
#include "GtkModel.h"

#ifdef MSQL_DBASE
#include "MsqlDatabase.h"
#endif
#ifdef MYSQL_DBASE
#include "MysqlDatabase.h"
#endif
#ifdef PGSQL_DBASE
#include "PgsqlDatabase.h"
#endif
#ifdef LOG_DBASE
#include "LogDatabase.h"
#endif

#ifdef STD_MODEM
#include "StdModem.h"
#endif
#ifdef ISDN_MODEM
#include "IsdnModem.h"
#endif
#ifdef SPORTSTER_MODEM
#include "SportsterVoice.h"
#endif

#ifdef REGION_USA
#include "RegionUSA.h"
#endif
#ifdef REGION_ISDN
#include "RegionIsdn.h"
#endif

#include <sys/stat.h>
#include <sys/time.h>
#include <sys/poll.h>
#include <stdio.h>

const String UNKNOWN_CALLER = String(GNUVOICE_ROOT) + "/share/wav/unknown.wav";


GtkModel::GtkModel(int argc, char** argv)
    : Gtk_Main(argc,argv)
{
#ifdef MSQL_DBASE
    dbase = new MsqlDatabase();
#endif
#ifdef MYSQL_DBASE
    dbase = new MysqlDatabase();
#endif
#ifdef PGSQL_DBASE
    dbase = new PgsqlDatabase();
#endif    
#ifdef LOG_DBASE
    dbase = new LogDatabase();
#endif
    
#ifdef STD_MODEM
    modem = new StdModem();
#endif
#ifdef ISDN_MODEM
    modem = new IsdnModem();
#endif
#ifdef SPORTSTER_MODEM
    modem = new SportsterVoice();
#endif
    
#ifdef REGION_USA
    region = new RegionUSA();
#endif
#ifdef REGION_ISDN
    region = new RegionIsdn();
#endif
    
    if(!modem->openPort()) {
	perror("Couldn't open modem");
    }
    if(!dbase->open()) {
	perror("Fatal error: couldn't open database");
	exit(1);
    }

    String messageDir(getenv("HOME"));
    messageDir += String("/.messages");

    mkdir(messageDir.cstr(), 0755);

    lastCallID = "1";

    ringSpace = 8;
    numRing = 0;

    haveCallerID = false;

    lastRingTime = time(NULL);
#ifdef ISDN_MODEM
    inputCon = connect_to_method(Gtk_Main::timeout(100), this, &GtkModel::timeoutCallback);
#else
    inputCon = connect_to_method(Gtk_Main::input(modem->getDes(),GDK_INPUT_READ), this, &GtkModel::inputCallback);
#endif

    recordOn = false;
}

gint GtkModel::timeoutCallback()
{
    inputCallback();
    return true;
}

void GtkModel::inputCallback()
{
    if(modem->getDes() == -1) {
	return;
    }

    String buf, callName, callNmbr;
    
    bool haveName=false;
    bool haveNmbr=false;
    bool haveRing=false;
    bool bunny=true;
    
    buf = modem->readLine();

    if(buf.length() == 0) {
	return;
    }
    
    /*
      if we're using an isdn4linux, we get everything in one lump string
    */
    if(region->isAllFields(buf)) {
	haveCallerID = true;
	callName = region->getName(buf);
	callNmbr = region->getNmbr(buf);
	update(callName, callNmbr);
	haveCallerID = false;
    }
    else if(region->isRing(buf)) {
#ifdef DEBUG
	printf("Got ring ");
#endif
	if(time(NULL)-lastRingTime > ringSpace) {
	    haveCallerID = false;
	    numRing = 1;
	    lastRingTime = time(NULL);
	    printf("%d\n", numRing);
	}
	else {
	    numRing++;
	    printf("%d\n", numRing);
	    lastRingTime = time(NULL);
#ifdef VOICE
	    if(numRing == ANSWER_RING) {
		if(!haveCallerID) {
		    update("Unknown", "Unknown");
		}
		answerCall();
	    }
#endif
	}
    }
    /*
      otherwise, look for a NAME or NMBR field.  when you find one, search 
      for the other until either you find it or you get to a RING.
      
      if you don't find the other field, set the string to "Unknown"
    */
    else if( (haveName=region->isNameField(buf)) || (haveNmbr=region->isNmbrField(buf)) ) {    
	numRing = 1;
	haveCallerID = true;
	if(haveName) {
	    callName = region->getName(buf);
	    while( bunny && !(haveNmbr=region->isNmbrField(buf)) && !(haveRing=region->isRing(buf)) ) {
		struct pollfd pol[1];
		pol[0].fd = modem->getDes();
		pol[0].events = POLLIN;

		if(poll(pol, 1, ringSpace*1000) > 0) {
		    buf = modem->readLine();
		}
		else {
		    bunny=false;
		}
	    }
	    if(haveNmbr) {
		callNmbr = region->getNmbr(buf);
	    }
	    else {
		callNmbr = "Unknown";
	    }
	}
	else {
	    callNmbr = region->getNmbr(buf);
	    while( bunny && !(haveName=region->isNameField(buf)) && !(haveRing=region->isRing(buf)) ) {
		struct pollfd pol[1];
		pol[0].fd = modem->getDes();
		pol[0].events = POLLIN;

		if(poll(pol, 1, ringSpace*1000) > 0) {
		    buf = modem->readLine();
		}
		else {
		    bunny=false;
		}
	    }
	    if(haveName) {
		callName = region->getName(buf);
	    }
	    else {
		callName = "Unknown";
	    }
	}
	update(callName, callNmbr);
    }
}

void GtkModel::update(String callName, String callNmbr)
{
    Caller caller(dbase);
    caller.set("CallerNumber", callNmbr);
    if(!caller.fill()) {
	caller.set("CallerName", callName);
	
	Tag tag(dbase);
	tag.set("TagFile", UNKNOWN_CALLER);
	if(!tag.fill()) {
	    tag.insert();
	    tag.fill();
	}
	
	caller.set("TagID", tag.get("TagID"));
	
	caller.insert();
	caller.fill();
    }
    
    time_t now = time(NULL);
    
    Call call(dbase);
    call.set("CallerID", caller.get("CallerID"));
    call.set("CallDate", getDate(now));
    call.set("CallTime", getTime(now));
    call.set("MessageID", "0");
    
    call.insert();
    call.fill();
    
    lastCallID = call.get("CallID");
    
    String incomingFile = String(GNUVOICE_ROOT)+"/share/wav/incoming.wav";
    Tag tag(dbase, caller.get("TagID"));
    
    StringVector s;
    s.push_back("Caller: "+callName);
    s.push_back("Number: "+callNmbr);

    GtkMessageWin* m;
    m = new GtkMessageWin(s,10);
    
    view->updateView();  
    
    iterate();
    
    view->speakWav(incomingFile);
    view->speakWav(tag.get("TagFile"));
}


String GtkModel::getDate(time_t t)
{
    char buffer[255];
    struct tm* nowDate = localtime((const time_t*)(&t));
    sprintf(buffer, "%04d-%02d-%02d", (1900 + nowDate->tm_year),(nowDate->tm_mon + 1), (nowDate->tm_mday)  ); 
    return String(buffer);
}


String GtkModel::getTime(time_t t)
{
    char buffer[255];
    struct tm* nowDate = localtime((const time_t*)(&t));
    sprintf(buffer, "%02d:%02d:%02d", (nowDate->tm_hour), (nowDate->tm_min), (nowDate->tm_sec) );    
    return String(buffer);
}



#ifdef VOICE

void GtkModel::answerCall()
{
    Call call(dbase, lastCallID);
    String callDate(call.get("CallDate"));
    String callTime(call.get("CallTime"));


    char messFile[1024];
    int year, mon, day, hour, min, sec;
    sscanf(callDate.cstr(), "%4d-%2d-%2d", &year, &mon, &day);
    sscanf(callTime.cstr(), "%2d:%2d:%2d", &hour, &min, &sec);
    
    sprintf(messFile, "%s/.messages/%04d%02d%02d%02d%02d%02d", getenv("HOME"), year, mon, day, hour, min, sec);
    
    String messageFile(messFile);

    Message message(dbase);
    message.set("MessageFile", messageFile);
    message.insert();
    message.fill();
    call.set("MessageID", message.get("MessageID"));
    call.update();

    String greetFile = (String)getenv("HOME") + "/.messages/greeting";
    
    inputCon.disconnect();
    modem->answerCall(greetFile, messageFile);
    inputCon = connect_to_method(Gtk_Main::input(modem->getDes(),GDK_INPUT_READ), this, &GtkModel::inputCallback);
    view->updateView();
}

#endif

#ifdef VOICE
void GtkModel::playGreeting()
{
    String greetFile = (String)getenv("HOME") + "/.messages/greeting";

    inputCon.disconnect();
    modem->playFile(greetFile, speaker);
    inputCon = connect_to_method(Gtk_Main::input(modem->getDes(),GDK_INPUT_READ), this, &GtkModel::inputCallback);
}
#endif

#ifdef VOICE
void GtkModel::playMessage(String messageFile)
{
    inputCon.disconnect();
    modem->playFile(messageFile, speaker);
    inputCon = connect_to_method(Gtk_Main::input(modem->getDes(),GDK_INPUT_READ), this, &GtkModel::inputCallback);
}
#endif

#ifdef VOICE
void GtkModel::recordMessage(String messageFile)
{
    inputCon.disconnect();
    modem->recordFile(messageFile, line);
    inputCon = connect_to_method(Gtk_Main::input(modem->getDes(),GDK_INPUT_READ), this, &GtkModel::inputCallback);
}
#endif

#ifdef VOICE
void GtkModel::recordGreeting()
{
    String greetFile = (String)getenv("HOME") + "/.messages/greeting";

    inputCon.disconnect();
    modem->recordFile(greetFile, microphone);
    inputCon = connect_to_method(Gtk_Main::input(modem->getDes(),GDK_INPUT_READ), this, &GtkModel::inputCallback);
}
#endif

#ifdef VOICE
void GtkModel::speakerphoneCallNumber(String& number)
{
    inputCon.disconnect();
    modem->callNumber(number, speakerphone);
    inputCon = connect_to_method(Gtk_Main::input(modem->getDes(),GDK_INPUT_READ), this, &GtkModel::inputCallback);
}
#endif
#ifdef VOICE
void GtkModel::handsetCallNumber(String& number)
{
    inputCon.disconnect();
    modem->callNumber(number, line);
    inputCon = connect_to_method(Gtk_Main::input(modem->getDes(),GDK_INPUT_READ), this, &GtkModel::inputCallback);
}
#endif
#ifdef VOICE
void GtkModel::hangUp()
{
    inputCon.disconnect();
    modem->hangUp();
    inputCon = connect_to_method(Gtk_Main::input(modem->getDes(),GDK_INPUT_READ), this, &GtkModel::inputCallback);
}
#endif


Database* GtkModel::getDbase() 
{ 
    return dbase;
}

void GtkModel::setView(GtkView* v)
{
    view = v;
}

void GtkModel::runModel()
{
    run();
}


void GtkModel::startModel()
{
    if(modem->getDes() == -1) {
	if(modem->openPort()) {
	    inputCon = connect_to_method(Gtk_Main::input(modem->getDes(),GDK_INPUT_READ), this, &GtkModel::inputCallback);
	}
    }
}


void GtkModel::stopModel()
{
    if(modem->getDes() != -1) {
	inputCon.disconnect();
	modem->closePort();
    }
}

void GtkModel::quitModel()
{
    stopModel();
    quit();
}

void GtkModel::iterate()
{
    while(events_pending()) {
	iteration();
    }
}


bool GtkModel::modemOpen()
{
    return (modem->getDes() != -1);
}

bool GtkModel::modemLock()
{
    return modem->getLocked();
}
