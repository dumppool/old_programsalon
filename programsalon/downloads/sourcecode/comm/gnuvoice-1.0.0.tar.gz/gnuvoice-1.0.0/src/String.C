/* -*- C++ -*-
 * String.C - source file for class String
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "String.h"

#include <assert.h>

const int DEF = 255;

String::String()
{
    sz = 0;
    data = new char[DEF];
    data[sz] = 0;
}

String::String(const String& s)
{
    sz = s.sz;
    data = new char[s.sz+1];
    strcpy(data, s.data);
    data[sz]=0;
}


String::String(int size)
{
    sz = 0;
    data = new char[size+1];
    data[sz] = 0;
}


String::String(char* s)
{
    sz = strlen(s);
    data = new char[sz+1];
    strcpy(data, s);
    data[sz] = 0; 
}

String::String(const char* s)
{
    sz = strlen(s);
    data = new char[sz+1];
    strcpy(data, s);
    data[sz] = 0; 
}

String::String(const string& s)
{
    sz = strlen(s.c_str());
    data = new char[sz+1];
    strcpy(data, s.c_str());
    data[sz] = 0; 
}

String::String(const _gtk_string& s)
{    
    sz = strlen(s.c_str());
    data = new char[sz+1];
    strcpy(data, s.c_str());
    data[sz] = 0; 
}

String::~String()
{
    delete [] data;
}

String String::valueOf(int i)
{
    char temp[255];
    sprintf(temp, "%d", i);
    return String(temp);
}


String String::valueOf(double i)
{
    char temp[255];
    sprintf(temp, "%f", i);
    return String(temp);
}


void String::chop()
{
    data[--sz]=0;
}

void String::chopWhite()
{
    while(data[sz-1] == '\n' || data[sz-1] == 10 || data[sz-1] == 13) {
	chop();
    }
}

void String::setSize()
{
    sz = strlen(data);
}

char* String::cstr() const
{
    return data;
}

string String::str() const
{
    return string(data);
}

_gtk_string String::gstr() const
{
    return _gtk_string(data);
}

int String::length() const
{
    return sz;
}

bool String::contains(String s) const
{
    return strstr(data, s.data);
}


/*
  String String::operator()(int i)
*/
String String::operator()(int i) const
{
    assert(i>=0 && i<sz);
    
    char temp[2];
    temp[0]=data[i];
    temp[1]=0;
    return String(temp);
}

/*
  String String::operator()(int i, int j)
  
  returns substring from i (inclusive) 
  to j (non-inclusive)
*/
String String::operator()(int i, int j) const
{
    assert(i>=0 && i<=j && j<=sz);

    String ret(j-i);
    for(int q=0; q<(j-i); q++) {
	ret.data[q] = data[i+q];
    }
    ret.data[(j-i)]=0;
    ret.sz = (j-i);
    return ret;
}


/*
  StringVector String::tokenize() const
*/
StringVector String::tokenize() const
{
    String delim = " ";
    return tokenize(delim);
}

/*
  StringVector String::tokenize(const String& delim) const
*/
StringVector String::tokenize(const String& delim) const
{
    StringVector ret;
    String token;
    char* tmp1 = new char[sz+1];
    char* tmp2;

    strcpy(tmp1, data);

    tmp2 = strtok(tmp1, delim.cstr());

    while(tmp2) {
	token = String(tmp2);
	ret.push_back(token);
	tmp2 = strtok(NULL, delim.cstr());
    }

    delete [] tmp1;

    return ret;
}




String String::operator=(const String& s)
{
    delete [] data;
    data = new char[s.sz+1];
    strcpy(data, s.data);
    sz = s.sz;
    return (*this);
}

String String::operator=(const char* s)
{
    delete [] data;
    data = new char[strlen(s)+1];
    strcpy(data, s);
    sz = strlen(s);
    return (*this);
}


String String::operator+=(const String& s)
{
    return ((*this) = (*this)+s);
}



String operator+(const String& s1, const String& s2)
{
    String ret(s1.sz + s2.sz + 1);
    strcpy(ret.data, s1.data);
    strcpy(ret.data+s1.sz, s2.data);
    ret.sz = s1.sz+s2.sz;
    ret.data[ret.sz]=0;
    return ret;
}

String operator+(const String& s1, const char* s2)
{
    String temp(s2);
    return (s1+temp);
}


String operator+(const String& s1, const int i)
{
    return (s1 + String::valueOf(i));
}

String operator+(const String& s1, const double i)
{
    return (s1 + String::valueOf(i));
}



String operator+(const char* s1, const String& s2)
{
    String temp(s1);
    return (temp+s2);
}




bool operator==(const String& s1, const String& s2)
{
    if(s1.sz != s2.sz) {
	return false;
    }
    else {
	for(int i=0; i<s1.sz; i++) {
	    if(s1.data[i] != s2.data[i]) {
		return false;
	    }
	}
	return true;
    }
}

bool operator!=(const String& s1, const String& s2)
{
    return !(s1 == s2);
}

bool operator<(const String& s1, const String& s2)
{
    int size = 0;
    if(s1.sz < s2.sz) {
	size = s1.sz;
    }
    else {
	size = s2.sz;
    }
    for(int i=0; i<size; i++) {
	if( s1.data[i] < s2.data[i] ) {
	    return true;
	}
	else if( s1.data[i] > s2.data[i] ) {
	    return false;
	}
    }
    if(s1.sz < s2.sz) {
	return true;
    }
    else {
	return false;
    }
}

bool operator>=(const String& s1, const String& s2)
{
    return !(s1 < s2);
}

bool operator>(const String& s1, const String& s2)
{
    return !(s1 <= s2);
}

bool operator<=(const String& s1, const String& s2)
{
    return ((s1 < s2) || (s1 == s2));
}


