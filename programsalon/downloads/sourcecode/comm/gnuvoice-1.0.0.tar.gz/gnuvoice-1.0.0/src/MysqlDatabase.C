/*
 * 
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "MysqlDatabase.h"
#include "MysqlResultSet.h"

#include <stdlib.h>

String dbase = "gnuvoice";

String createCall = "CREATE TABLE Call ( CallID int NOT NULL AUTO_INCREMENT, CallerID int NOT NULL, CallDate date NOT NULL, CallTime time NOT NULL, MessageID int NOT NULL DEFAULT 0, KEY _CallID(CallID), KEY _CallerID(CallerID), KEY _CallDate(CallDate) )";

String createCaller = "CREATE TABLE Caller ( CallerID int NOT NULL AUTO_INCREMENT, CallerName VARCHAR(255) NOT NULL, CallerNumber VARCHAR(255) NOT NULL, TagID int NOT NULL DEFAULT 0, KEY _CallerID(CallerID), KEY _CallerName(CallerName), KEY _CallerNumber(CallerNumber) )";

String createMessage = "CREATE TABLE Message ( MessageID int NOT NULL AUTO_INCREMENT, MessageFile VARCHAR(255) NOT NULL, KEY _MessageID(MessageID) )";

String createTag = "CREATE TABLE Tag ( TagID int NOT NULL AUTO_INCREMENT, TagFile VARCHAR(255) NOT NULL, KEY _TagID(TagID) )";


bool MysqlDatabase::open() {
#ifdef DUSER
#ifdef DPASS
    if((sock=mysql_connect(NULL, "localhost", DUSER, DPASS)) == NULL) {
	return false;
    }  
#else 
    if((sock=mysql_connect(NULL, "localhost", DUSER, DPASS)) == NULL) {
	return false;
    }  
#endif
#else
#ifdef DPASS
    if((sock=mysql_connect(NULL, "localhost", "root", DPASS)) == NULL) {
	return false;
    }  
#else    
    if((sock=mysql_connect(NULL, "localhost", "root", NULL)) == NULL) {
	return false;
    }  
#endif
#endif  
    mysql_create_db(sock, dbase.cstr());
    
    if(mysql_select_db(sock, dbase.cstr()) != 0) {
	return false;
    }

    executeUpdate(createCall);
    executeUpdate(createCaller);
    executeUpdate(createMessage);
    executeUpdate(createTag);

    return true;
    
}

bool MysqlDatabase::useSeq() {
    return false;
}



String MysqlDatabase::escapeArg(String arg) {
    String temp(2*arg.length()+1);
    mysql_escape_string(temp.cstr(), arg.cstr(), arg.length());
    return String(temp.cstr());
}


ResultSet* MysqlDatabase::executeQuery(String sql) {
    mysql_query(sock,sql.cstr());
    MYSQL_RES* res = mysql_store_result(sock);
    MysqlResultSet* retVal = new MysqlResultSet(res);
    return (ResultSet*)retVal;
}

void MysqlDatabase::executeUpdate(String sql) {
    mysql_query(sock, sql.cstr());
    MYSQL_RES* res = mysql_store_result(sock);
    mysql_free_result(res);
}
