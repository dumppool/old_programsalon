/* -*- C++ -*-
 * 
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "utils.h"
#include "GtkMessageWin.h"

GtkMessageWin::GtkMessageWin() {}

GtkMessageWin::GtkMessageWin(const StringVector& s)
    : Gtk_Dialog(),
      label1(s[0].gstr()),
      label2(s[1].gstr()),
      hbox1(FALSE,10),
      hbox2(FALSE,10),
      vbox(FALSE, 5),
      okButton("Ok"),
      caButton("Cancel")
{
    hbox1.pack_start(label1, false, true, 10);
    vbox.pack_start(hbox1, false, true, 0);
    hbox2.pack_start(label2, false, true, 10);
    vbox.pack_start(hbox2, false, true, 0);

    get_vbox()->pack_start(vbox,true,true,10);
    set_position(GTK_WIN_POS_CENTER);
    
    get_action_area()->pack_start(okButton,TRUE, TRUE, 25);
    get_action_area()->pack_start(caButton,TRUE, TRUE, 25);
    
    connect_to_method(okButton.clicked, this, &deleteSelf);
    connect_to_method(caButton.clicked, this, &deleteSelf);
    
    show_all();
}


GtkMessageWin::GtkMessageWin(const StringVector& s, int t) 
    : Gtk_Dialog(),
      label1(s[0].gstr()),
      label2(s[1].gstr()),
      hbox1(FALSE,10),
      hbox2(FALSE,10),
      vbox(FALSE, 5),
      okButton("Ok"),
      caButton("Cancel")
{
    hbox1.pack_start(label1, false, true, 10);
    vbox.pack_start(hbox1, false, true, 0);
    hbox2.pack_start(label2, false, true, 10);
    vbox.pack_start(hbox2, false, true, 0);

    get_vbox()->pack_start(vbox,true,true,10);
    set_position(GTK_WIN_POS_CENTER);
    
    get_action_area()->pack_start(okButton,TRUE, TRUE, 25);
    get_action_area()->pack_start(caButton,TRUE, TRUE, 25);
    
    timeCon = connect_to_method(Gtk_Main::timeout(1000*t), this, &deleteSelf2);

    connect_to_method(okButton.clicked, this, &deleteSelf);
    connect_to_method(caButton.clicked, this, &deleteSelf);
    
    show_all();
}


void GtkMessageWin::deleteSelf()
{
    hide();
    timeCon.disconnect();
    connect_to_function(Gtk_Main::idle(), &idleDelete, (Gtk_Widget*)this);
}

gint GtkMessageWin::deleteSelf2()
{
    hide();
    connect_to_function(Gtk_Main::idle(), &idleDelete, (Gtk_Widget*)this);
    return 0;
}
