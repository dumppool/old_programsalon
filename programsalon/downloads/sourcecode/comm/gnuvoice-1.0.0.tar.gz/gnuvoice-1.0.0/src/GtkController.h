/*
 * GtkController.h - header file for class GtkController
 * Copyright (c) 1999 Joe Yandle <yandle@cs.unc.edu>
 *
 * The Controller class creates instances of a Model and a View, and 
 * runs the Model.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#ifndef GTKCONTROLLER_H
#define GTKCONTROLLER_H

#include "GtkModel.h"
#include "GtkView.h"

class GtkController
{
 public:
  GtkController(int argc, char** argv);
 private:
  GtkModel* model;
  GtkView* view;
};

#endif
