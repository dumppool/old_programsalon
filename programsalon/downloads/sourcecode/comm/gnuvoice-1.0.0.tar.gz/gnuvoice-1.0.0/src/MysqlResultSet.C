/*
 * 
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "MysqlResultSet.h"

MysqlResultSet::MysqlResultSet(MYSQL_RES* qRet)
{
    queryRet = qRet;
    numRow = mysql_num_rows(queryRet);
    numCol = mysql_num_fields(queryRet);
    curRow = 0;
    MYSQL_FIELD* colNames = mysql_fetch_fields(queryRet);
    
    for(int i=0; i<numCol; i++) {
	colVector.push_back( String(colNames[i].name) );
    }
}


MysqlResultSet::~MysqlResultSet()
{
    mysql_free_result(queryRet);
}

bool MysqlResultSet::next()
{
    if(++curRow > numRow) {
	return false;
    }
    
    char** temp = mysql_fetch_row(queryRet);

    rowVector.clear();
    rowHash.clear();

    for(int i=0; i<numCol; i++) {
	String key = colVector[i];
	String val( temp[i] );
	
	rowVector.push_back(val);
	rowHash.insert( Hashtable::value_type(key, val)  );
    }

    return true;
}

StringVector MysqlResultSet::getVector()
{
    return rowVector;
}

Hashtable MysqlResultSet::getHashtable()
{
    return rowHash;
}

String MysqlResultSet::getString(String colName)
{
    return rowHash[colName];
}

String MysqlResultSet::getString(int colNmbr)
{
    return rowVector[colNmbr];
}

int MysqlResultSet::numRows() 
{
    return numRow;
}

int MysqlResultSet::numCols() 
{
    return numCol;
}
