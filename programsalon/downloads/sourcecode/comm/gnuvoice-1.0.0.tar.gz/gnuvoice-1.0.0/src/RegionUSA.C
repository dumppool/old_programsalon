/* -*- C++ -*-
 * RegionUSA.C - source file for class RegionUSA
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "RegionUSA.h"

#include <string.h>

const String NAME_PRE = "NAME = ";
const String NMBR_PRE = "NMBR = ";
const String RING = "RING";
const int MAX = 32;

bool RegionUSA::isAllFields(String& data)
{
    return false;
}


bool RegionUSA::isNameField(String& data)
{
    return (data.contains(NAME_PRE));
}


bool RegionUSA::isNmbrField(String& data)
{
    return (data.contains(NMBR_PRE));
}

bool RegionUSA::isRing(String& data)
{
    return (data.contains(RING));
}


String RegionUSA::getName(String& data)
{
    return String( data(NAME_PRE.length(), data.length()) );
}


String RegionUSA::getNmbr(String& data)
{
    if(data(NMBR_PRE.length()) == "O") {
	return String("Out of Area");
    }
    else if(data(NMBR_PRE.length()) == 'P') {
	return String("Private");
    }
    else {
	String temp = data(NMBR_PRE.length(), data.length());
	return String(temp(0, 3) + "-" + temp(3, 6) + "-" + temp(6, 10));
  }
}


