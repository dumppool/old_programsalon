/* -*- C++ -*-
 * Modem.h - header file for class Modem
 * Copyright (c) 1999 Joe Yandle <yandle@cs.unc.edu>
 *
 * Modem is an abstract class that declares the interface which is
 * implemented by the Modem subclasses.  It is not entirely implementation
 * independent, since it is necessary to have a file descriptor of some
 * sort associated with the Modem.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#ifndef MODEM_H
#define MODEM_H

#include "String.h"

enum target { line, handset, speaker, microphone, line_speaker, speakerphone };

class Modem
{
public:
    virtual ~Modem() {}
    virtual bool openPort()=0;  
    virtual void closePort()=0;
    virtual String readLine()=0;
    virtual int getDes()=0;
    virtual bool getLocked()=0;
    virtual void setLocked(bool lock)=0;
#ifdef VOICE
    virtual void playFile(String& file, target where)=0;
    virtual void recordFile(String& file, target where)=0;
    virtual void answerCall(String& greetingFile, String& messageFile)=0;
    virtual void callNumber(String& number, target where)=0;
    virtual void hangUp()=0;
#endif
};

#endif
