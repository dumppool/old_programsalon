/* -*- C++ -*-
 * Model.h - header file for class Model
 * Copyright (c) 1999 Joe Yandle <yandle@cs.unc.edu>
 *
 * Class Model is an abstract class that declares the functions
 * needed by an implementation of a Model, and what data members it
 * should have.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#ifndef MODEL_H
#define MODEL_H

#include <time.h>

#include "Database.h"
#include "Modem.h"
#include "Region.h"
#include "String.h"

class View;

class Model
{
 public:
    virtual void runModel()=0;
    virtual void quitModel()=0;
    virtual Database* getDbase()=0;
    virtual void setView(View* v)=0;
    virtual void startModel()=0;
    virtual void stopModel()=0;
    virtual void iterate()=0;
    virtual bool modemOpen()=0;
    virtual bool modemLock()=0;
    virtual String getDate(time_t t)=0;
    virtual String getTime(time_t t)=0;
#ifdef VOICE
    virtual void playGreeting()=0;
    virtual void recordGreeting()=0;
    virtual void playMessage(String messageFile)=0;
    virtual void recordMessage(String messageFile)=0;
    virtual void answerCall()=0;
    virtual void handsetCallNumber(String& number)=0;
    virtual void speakerphoneCallNumber(String& number)=0;
    virtual void hangUp()=0;
#endif
 protected:
    Database* dbase;
    View* view;
    Modem* modem;
    Region* region;
};

#endif
