/* -*- C++ -*-
 * StdModem.C - source file for class StdModem
 * Copyright (c) 1999 Joe Yandle <joe@wlcg.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */

#include "StdModem.h"

#include <sys/poll.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

const int MAX=255;

#define ETX	003
#define DLE	020

bool StdModem::openPort()
{
    if( (fd = open(MODEM, O_RDWR | O_NDELAY)) == -1 ) {
	return false;
    }
    
//    if( flock(fd, LOCK_EX | LOCK_NB) == -1 ) {
	setLocked(false);
//    }
//    else {
//	setLocked(true);
//    }
    
#ifndef USE_NDELAY
    int n = fcntl(fd, F_GETFL);
    fcntl(fd, F_SETFL, (n & ~O_NDELAY));
#endif
    
    tcgetattr(fd,&oldtio);
    memset(&newtio, 0, sizeof(newtio));
    
    newtio.c_iflag = IGNPAR | ICRNL;
    newtio.c_oflag = 0;
    
#ifdef CRTSCTS
    newtio.c_cflag = CRTSCTS | CS8 | CREAD;
#else
    newtio.c_cflag = CS8 | CREAD;
#endif
    
    newtio.c_lflag = ICANON;
    
    tcflush(fd, TCIOFLUSH);
    cfsetospeed(&newtio, B0);
    cfsetispeed(&newtio, B0);
    tcsetattr(fd,TCSANOW,&newtio);
    
    sleep(1);
    
    cfsetospeed(&newtio, B38400);
    cfsetispeed(&newtio, B38400);
    tcsetattr(fd,TCSAFLUSH,&newtio);  

    String modemReset(MODEM_RESET), modemInit(MODEM_INIT);
    
    writeLine(modemReset);
    writeLine(modemInit);
    
    return true;
}

void StdModem::closePort()
{
    tcsetattr(fd, TCSANOW, &oldtio);
    flock(fd, LOCK_UN);
    setLocked(false);
    close(fd);
    fd = -1;
}

String StdModem::readLine()
{
    char temp[MAX];
    int i = read(fd,temp,MAX);
    temp[i]=0;

    String ret(temp);

    if(i>0) {
	ret.chopWhite();
    }
    return ret;
}

void StdModem::writeLine(String& buffer)
{
    String buf1, buf2;

    buf1 = buffer + "\r";
#ifdef USE_NDELAY    
    struct pollfd pollRead[1];
    struct pollfd pollWrite[1];
    pollRead[0].fd = fd;
    pollRead[0].events = POLLIN;
    pollWrite[0].fd = fd;
    pollWrite[0].events = POLLOUT;

    poll(pollWrite, 1, 2000);
#endif

    write(fd, buf1.cstr(), buf1.length());
    while(buf2 != buffer) {
#ifdef USE_NDELAY
	poll(pollRead, 1, 2000);
#endif
	buf2 = readLine();
    }

    while( (buf2 != "OK") && (buf2 != "VCON") && (buf2 != "CONNECT") ) {
#ifdef USE_NDELAY
	poll(pollRead, 1, 2000);
#endif
 	buf2 = readLine();
    }
}

int StdModem::getDes()
{
    return fd;
}

bool StdModem::getLocked()
{
    return locked;
}

void StdModem::setLocked(bool lock)
{
    locked=lock;;
}

