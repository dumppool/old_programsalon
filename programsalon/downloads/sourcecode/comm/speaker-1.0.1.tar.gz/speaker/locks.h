//************************************************************
//  locks.h - source file for creation and removal of port 
//             locks
//************************************************************

class Locks
{
   int PortLocked;
   char*  LockFileName;
  public:
   Locks();
   ~Locks();
   void Init(ConfigInfo* conf);
   int  MakeLockFile();
   int  CheckLockFile();
   void RemoveLockFile();
};

