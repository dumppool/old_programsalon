//************************************************************
//   commandsequence class definition for the speakerphone app.
//************************************************************

class CommandSequence
{
   protected:
      char* Command;
      char* GoodAnswer;
      CommandSequence* next;
   public:
      CommandSequence();
      CommandSequence(char* Cmd, char* GdAnswr);
      ~CommandSequence();
      char* GetCommand(){return Command;};
      char* GetAnswer(){return GoodAnswer;};
      CommandSequence* GetNext(){return next;};
      void SetNext(CommandSequence* nxt){next = nxt;};
};

