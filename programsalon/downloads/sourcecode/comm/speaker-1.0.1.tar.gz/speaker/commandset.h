//************************************************************
//   commandsequence class definition for the speakerphone app.
//************************************************************

class CommandSet
{
   protected:
      char*             Name;
      CommandSequence*  Commands;
      CommandSet*       next;
   public:
      CommandSet();
      int Init(ConfigInfo* conf);
      int ReadFile(FILE* fp);
      ~CommandSet();
      CommandSequence* GetSequence(char* Name);
};

