//************************************************************
//   commandSequence classe definition for the speakerphone app.
//************************************************************
#include "incall.h"

CommandSequence::CommandSequence()
{
   Command = NULL;
   GoodAnswer = NULL;
   next = NULL;
};

CommandSequence::CommandSequence(char* Cmd, char* GdAnswr)
{
   Command = new char[strlen(Cmd) + 1];
   strcpy(Command, Cmd);
   GoodAnswer = new char[strlen(GdAnswr) + 1];
   strcpy(GoodAnswer, GdAnswr);
   next = NULL;
};


CommandSequence::~CommandSequence()
{
   if (next) delete next;
   if (Command) delete Command;
   if (GoodAnswer) delete GoodAnswer;
};
