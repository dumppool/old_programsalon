/*
    window.h -- Header file for the window object.
    Copyright (C) 1996  Nadav Cohen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __WINDOW_H_
#define __WINDOW_H_

#include <ncurses.h>

class tWindow {
  int X1, Y1, X2, Y2;
  int bgColor, fgColor;
  /* Holds the data that was overwritten */
  void *bkgd;
  WINDOW *Window;
  
  public:
  
  tWindow(WINDOW *Win, int x1, int y1, int x2, int y2, int bColor, int fColor);
  ~tWindow();
  /* Makes a frame */
  void Frame(int Which, int Color);
  /* Writes a string at the top of the window */
  void Headline(char *Text, int Color);
};

#endif
