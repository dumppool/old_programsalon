/*
 * patchlevel.h		Defines the version strings
 *			in one central place.
 *
 * Version:		1.83 Nov 1999 MvS, JL, some others..
 *
 */
#define SCCS_ID "@(#)Minicom V1.83.0"
#define ST_VERSION "1.83.0"
#define CR_VERSION "Welcome to minicom 1.83.0"

/*
 * fmg 8/22/97
 * show on startup what compile options were used...
 */

#if _HISTORY
#define CR_OPTION1 "History Buffer, "
#else
#define CR_OPTION1 ""
#endif /*HISTORY*/
#if _HAVE_MACROS
#define CR_OPTION2 "F-key Macros, "
#else
#define CR_OPTION2 ""
#endif /*HAVE_MACROS*/
#if _RH_FIX
#define CR_OPTION3 "RedHat fix, "
#else
#define CR_OPTION3 ""
#endif /*RH_FIX*/
#if _SEARCH_HISTORY
#define CR_OPTION4 "Search History Buffer, "
#else
#define CR_OPTION4 ""
#endif /*SEARCH_HISTORY*/
#if _I18N_
#define CR_OPTION5 "I18n "
#else
#define CR_OPTION5 ""
#endif 
