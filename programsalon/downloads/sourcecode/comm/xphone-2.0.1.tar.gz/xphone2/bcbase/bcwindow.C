#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <math.h>

#include "bccolors.h"
#include "bckeys.h"
#include "bcmenubar.h"
#include "bcpopupmenu.h"
#include "bcwindow.h"

BC_Window::BC_Window(char *display_name, 
					 int color, 
					 char *title, 
					 int w, int h, 
					 int minw, int minh, 
					 int private_color, int hide)
 : BC_WindowBase(0, 0, w, h, color)
{
// initialize flags
	ctrl_mask = shift_mask = button_pressed = key_pressed = key_sym = resized = 0;
	done = 0;
	button_down = double_click = cursorleft = button_just_released = 0;
	button_time1 = button_time2 = 0;
	motion_buffer = 0;
	repeat_buffer = 0;
	last_deleted_window = motion_buffer_win = 0;
	active_menubar = 0;
	active_tool = 0;
	active_popup_menu = 0;
	last_w = w;
	last_h = h;
	
	repeat = 0;
	this->hidden = hide;

// This function must be the first Xlib
// function a multi-threaded program calls
	XInitThreads();

	this->private_color = private_color;

	if(display_name && display_name[0] == 0) display_name = NULL;
	if ( (display=XOpenDisplay(display_name)) == NULL ) 
	{
  		printf("cannot connect to X server\n");
  		if (getenv("DISPLAY") == NULL)
    		printf("'DISPLAY' environment variable not set.\n");
  		exit ( -1 );
 	}

	screen = DefaultScreen(display);
	rootwin = RootWindow(display, screen);
	vis = DefaultVisual(display, screen);

	init_colors();
	init_fonts();

// ==================================== build the window

	unsigned long gcmask;
	gcmask = GCFont | GCGraphicsExposures;

	XGCValues gcvalues;
	gcvalues.font = largefont->fid;        // set the font
	gcvalues.graphics_exposures = 0;        // prevent expose events for every redraw
	gc = XCreateGC(display, rootwin, gcmask, &gcvalues);

	XSetWindowAttributes attr;
	unsigned long mask;
	Cursor arrow;
	XSizeHints size_hints;

	arrow = XCreateFontCursor(display, XC_top_left_arrow);

	mask = CWBackingStore | CWEventMask | CWBackPixel | CWBorderPixel | CWColormap | CWCursor | CWOverrideRedirect | CWSaveUnder;
	attr.event_mask = LeaveWindowMask | ExposureMask | ButtonPressMask | ButtonReleaseMask | StructureNotifyMask | KeyPressMask | PointerMotionMask | FocusChangeMask;
	attr.background_pixel = get_color(color);
	attr.border_pixel = get_color(color);
	attr.colormap = cmap;
	attr.cursor = arrow;
	attr.override_redirect = False;
	attr.save_under = False;
	attr.backing_store = Always;

	win = XCreateWindow(display, rootwin, 0, 0, w, h, 0, depth, InputOutput, vis, mask, &attr);

	size_hints.flags = PSize | PMinSize | PMaxSize;
	size_hints.width = w;
	size_hints.height = h;
	size_hints.min_width = minw;
	if(minw == w) size_hints.max_width = w; else size_hints.max_width = 32767;
	size_hints.min_height = minh;
	if(minh == h) size_hints.max_height = h; else size_hints.max_height = 32767;

	XSetStandardProperties(display, win, title, title, None, 0, 0, &size_hints);

// =============================== fix close button

	DelWinXAtom = XInternAtom(display, "WM_DELETE_WINDOW", False);
	if(ProtoXAtom = XInternAtom(display, "WM_PROTOCOLS", False))
		XChangeProperty(display, win, ProtoXAtom, XA_ATOM, 32, PropModeReplace, (unsigned char *)&DelWinXAtom, True );

// show the window
	if(!hide) show_window();
	XFlush(display);
// ======================== fix threading
//unlock_window();
}

BC_Window::~BC_Window()
{         // base class deletes everything since it's the last destructor called
}


// ================================== color table

BC_Window::init_fonts()
{

	if ((titlefont = XLoadQueryFont(display, "-*-helvetica-bold-r-normal--24-240-75-75-p-124-iso8859-1")) == NULL) 
	{
		printf("Sorry, can't find helvetica font.  Using fixed instead.\n");
		titlefont = XLoadQueryFont(display, "fixed");
	}

	if ((largefont = XLoadQueryFont(display, "-*-helvetica-bold-o-normal-*-14-*")) == NULL) 
	{
		printf("Sorry, can't find helvetica font.  Using fixed instead.\n");
		largefont = XLoadQueryFont(display, "fixed");
	}

	if ((smallfont = XLoadQueryFont(display, "-*-helvetica-medium-r-normal-*-10-*")) == NULL) 
	{
		printf("Sorry, can't find helvetica font.  Using fixed instead.\n");
		smallfont = XLoadQueryFont(display, "fixed");
	}
}


BC_Window::init_colors()
{
	total_colors = 0;
	current_color_value = current_color_pixel = 0;
	
	depth = DefaultDepth(display, screen);

	switch(depth)
	{
		case 8:
			if(private_color)
			{
  				cmap = XCreateColormap(display, rootwin, vis, AllocNone);
				create_private_colors();
			}
			else
			{
				
	 		  	cmap = DefaultColormap(display, screen);
				create_shared_colors();
			}
	  		
			allocate_color_table();
			break;

		default:
 			cmap = DefaultColormap(display, screen);
			break;
	}
}

BC_Window::create_private_colors()
{
	int color;
	total_colors = 256;

	for(int i = 0; i < 255; i++)
	{
		color = (i & 0xc0) << 16;
		color += (i & 0x38) << 10;
		color += (i & 0x7) << 5;
		color_table[i][0] = color;
	}
	create_shared_colors();        // overwrite the necessary colors on the table
}


BC_Window::create_color(int color)
{
	if(total_colors == 256)
	{
// replace the closest match with an exact match
		color_table[get_color_8(color)][0] = color;
	}
	else
	{
// add the color to the table
		color_table[total_colors][0] = color;
		total_colors++;
	}
}

BC_Window::create_shared_colors()
{
	create_color(BLACK);
	create_color(WHITE);   

	create_color(LTGREY);  
	create_color(MEGREY);  
	create_color(MDGREY);  
	create_color(DKGREY);   		  	

	create_color(LTCYAN);  
	create_color(MECYAN);  
	create_color(MDCYAN);  
	create_color(DKCYAN);  

	create_color(LTGREEN); 
	create_color(GREEN);   
	create_color(DKGREEN); 

	create_color(LTPINK);  
	create_color(PINK);
	create_color(RED);     

	create_color(LTBLUE);  
	create_color(BLUE);    
	create_color(DKBLUE);  

	create_color(LTYELLOW); 
	create_color(MEYELLOW); 
	create_color(MDYELLOW); 
	create_color(DKYELLOW); 

	create_color(LTPURPLE); 
	create_color(MEPURPLE); 
	create_color(MDPURPLE); 
	create_color(DKPURPLE); 
}

BC_Window::allocate_color_table()
{
	int red, green, blue, color;
	int result;
	XColor col;

	for(int i = 0; i < total_colors; i++)
	{
		color = color_table[i][0];
		red = (color & 0xFF0000) >> 16;
		green = (color & 0x00FF00) >> 8;
		blue = color & 0xFF;

		col.flags = DoRed | DoGreen | DoBlue;
		col.red   = red<<8   | red;
		col.green = green<<8 | green;
		col.blue  = blue<<8  | blue;

		XAllocColor(display, cmap, &col);
		color_table[i][1] = col.pixel;

//printf("BC_Window::allocate_color_table %x %x %x %d\n", col.red, col.green, col.blue, color_table[i][1]);
		//if(!)
		//{
		//	cmap = XCopyColormapAndFree(display, cmap);
		//	XAllocColor(display, cmap, &Col);
		//}
	}

	XInstallColormap(display, cmap);
}

BC_Window::get_color(long color) 
{
// return pixel of color
// use this only for drawing tools not for bitmaps
	 int i, test, difference, result;
		
	if(depth <= 8)
	{
		if(private_color)
		{
			return get_color_8(color);
		}
		else
		{
// test last color looked up
			if(current_color_value == color) return current_color_pixel;

// look up in table
			current_color_value = color;
			for(i = 0; i < total_colors; i++)
			{
				if(color_table[i][0] == color)
				{
					current_color_pixel = color_table[i][1];
//printf("BC_Window::get_color %x %d\n", color, current_color_pixel);
					return current_color_pixel;
				}
			}

// find nearest match
			difference = 0xFFFFFF;

			for(i = 0, result = 0; i < total_colors; i++)
			{
				test = abs((int)(color_table[i][0] - color));

				if(test < difference) 
				{
					current_color_pixel = color_table[i][1]; 
					difference = test;
				}
			}

			return current_color_pixel;
		}
	}	
	else
	switch(depth){
		case 16:
			return get_color_16(color);
			break;
		case 24:
			return color;
			break;
		default:
			return color;
			break;	
	}
	return color;
}

BC_Window::get_color_8(int color)
{
	int pixel;

	pixel = (color & 0xc00000) >> 16;
	pixel += (color & 0xe000) >> 10;
	pixel += (color & 0xe0) >> 5;
	return pixel;
}

long BC_Window::get_color_16(int color)
{
	long result;
	result = (color & 0xf80000) >> 8;
	result += (color & 0xfc00) >> 5;
	result += (color & 0xf8) >> 3;
	
	return result;
}

// =========================== initialization

BC_Tool* BC_Window::add_tool(BC_Tool *tool)
{
	if(!top_level) top_level = this;
	BC_WindowBase::add_tool(tool);
}

BC_Window::add_border(int light, int medium, int dark)
{
	if(!top_level) top_level = this;
	BC_WindowBase::add_border(light, medium, dark);
}

BC_SubWindow* BC_Window::add_subwindow(BC_SubWindow* subwindow)
{
	if(!top_level) top_level = this;
	BC_WindowBase::add_subwindow(subwindow);
}





// =========================== event dispatching



BC_Window::run_window()
{
// initialize final flags
	done = 0;             // reset done flag
	return_value = 0;     // default return value
	top_level = this;
	parent_window = this;

	while(!done)
	{
		dispatch_event();
	}

	unlock_window();
	return return_value;
}

BC_Window::dispatch_event()
{
	static XEvent report, report2;
	static Window tempwin;
	static int repeat_next_event;     // for clearing motion notifies
	static int button_x, button_y;
	static result, i;         // result from a dispatch determines if event has been trapped

// delay next repeat and execute repeat if
// there is no active menubar
// there are no waiting events
// there is no motion history
	if(repeat && !active_menubar && !active_popup_menu && !XPending(display) && !motion_buffer)
	{
// wait only if no repeats were skipped for events
		//if(!repeat_buffer)
		//{
			repeat_timer.get_difference(&current_repeat);
//printf("current_repeat.tv_sec %ld current_repeat.tv_usec %ld\n", current_repeat.tv_sec, current_repeat.tv_usec);
			if(current_repeat.tv_sec < 1 && current_repeat.tv_usec < repeat)
			{
				delay_duration.tv_sec = 0;
				delay_duration.tv_usec  = repeat - current_repeat.tv_usec;
				select(0,  NULL,  NULL, NULL, &delay_duration);
			}
		//}

// dispatch repeat if there is no waiting event
		if(!XPending(display))
		{
			repeat_timer.update();

			repeat_buffer = 0;

			repeat_dispatch();
		}
	}



// quit if repeat resulted in a set_done
	if(done) return 1;

// zero all flags
	key_pressed = 0;
	button_pressed = 0;
	ctrl_mask = 0;
	shift_mask = 0;
	cursorleft = 0;
	resized = 0;
	event_win = 0;
	double_click = 0;
	



// if an event is waiting, get it, otherwise
// wait for next event if there is no repeat and no motion history
	if(XPending(display) || (!repeat && !motion_buffer))
	{
// test for skipped repeat event if there is an event waiting
		if(repeat) repeat_buffer = 1;
		
		XNextEvent(display, &report);
//printf("XNextEvent(display, &report); %d\n", report.type);
// lock out anyone who tries to delete a window beyond this point
// deletions between XNextEvent and this get through
		lock_window();
	}
	else
	if(motion_buffer)
	{
// handle buffered motion events if there is no waiting event
		lock_window();

// ctrl key down
		if(report.xkey.state & ControlMask) ctrl_mask = 1;
// shift key down
		if(report.xkey.state & ShiftMask) shift_mask = 1;
		
		dispatch_motion_event_main();
	}

// ctrl key down
	if(report.xkey.state & ControlMask) ctrl_mask = 1;
// shift key down
	if(report.xkey.state & ShiftMask) shift_mask = 1;
  
// need cursor position for button events
	if(report.type == ButtonPress || report.type == ButtonRelease)
	{
		XTranslateCoordinates(display, report.xany.window, win, report.xbutton.x, report.xbutton.y, &button_x, &button_y, &tempwin);
	}

// dispatch the event
	switch(report.type)
	{
// window exposed
		case Expose:
//printf("Expose\n");
			event_win = report.xany.window;
			expose_event_dispatch();
			break;
			
// window closed
		case ClientMessage:
// clear the motion buffer since this can clear the window
			if(motion_buffer) { dispatch_motion_event_main(); }
			{
				XClientMessageEvent *ptr;
				ptr = (XClientMessageEvent*)&report;

        		if(ptr->message_type == ProtoXAtom && 
        			ptr->data.l[0] == DelWinXAtom)
        		{
					close_event();
				}
			}
			break;

		case ButtonPress:
//printf("ButtonPress\n");
// get location information
			cursor_x = button_x;
			cursor_y = button_y;

// get button information
			button_pressed = report.xbutton.button;
	
// get time information
			event_win = report.xany.window;
  			button_down = 1;
			button_time1 = button_time2;
			button_time2 = report.xbutton.time;
			if(button_time2 - button_time1 < 300) double_click = 1;
			else double_click = 0;

			if(active_menubar) active_menubar->button_press_dispatch();
			else
			if(active_popup_menu) active_popup_menu->button_press_dispatch();
			else 
			button_press_dispatch();
			break;

		case ButtonRelease:
//printf("ButtonRelease\n");
// get location information
			cursor_x = button_x;
			cursor_y = button_y;

//printf("cursor_x %d cursor_y %d active_menubar %x active_popup_menu %x \n", cursor_x, cursor_y, active_menubar, active_popup_menu);
			event_win = report.xany.window;
			button_just_released++;   // X generates cursor leave events after button release
  			button_down = 0;
  		
			if(active_menubar) active_menubar->button_release_dispatch();
			else
			if(active_popup_menu) active_popup_menu->button_release_dispatch();
  			else 
  			button_release_dispatch();
			break;

		case MotionNotify:
//printf("MotionNotify\n");
// window can get destroyed after the button release and the motion notify event
// buffer it if it's the first motion from any window
			if(!motion_buffer)
			{
				store_motion_event(&report);
			}
			else
// buffer it if it's a subsequent motion from the same window
			if(motion_buffer_win == report.xany.window)
			{
				store_motion_event(&report);
			}
			else
// dispatch it if it's a subsequent motion from a different window			
			{
				dispatch_motion_event_main();
				
// arm buffer with new motion event
				store_motion_event(&report);
			}
			break;

		case ConfigureNotify:
			if(report.xany.window == win && 
				(report.xconfigure.width != w || report.xconfigure.height != h)
				&& (report.xconfigure.width != last_w || report.xconfigure.height != last_h))
			{
//printf("ConfigureNotify %d %d %d %d\n", w, h, report.xconfigure.width, report.xconfigure.height);
//sleep(1);
				last_w = w = report.xconfigure.width;
				last_h = h = report.xconfigure.height;
				resized = 1;

// only give to user here
				resize_event(w, h);
// send to all objects
				resize_event_dispatch();
			}
			break;

		case KeyPress:
//printf("KeyPress\n");
  			static KeySym keysym;
  			static char keys_return[2];

  			keys_return[0] = '\0';
  			XLookupString ((XKeyEvent*)&report, keys_return, 1, &keysym, 0);
//printf("keysym %x\n", keysym);

// block out control keys
			if(keysym > 0xffe0){ break; }
			
  			switch(keysym){
// block out some keys
        		case XK_Alt_L:      key_pressed = 0;         break;
        		case XK_Alt_R:      key_pressed = 0;         break;
        		case XK_Shift_L:    key_pressed = 0;         break;
        		case XK_Shift_R:    key_pressed = 0;         break;
        		case XK_Control_L:  key_pressed = 0;         break;
        		case XK_Control_R:  key_pressed = 0;         break;

		// translate key codes
  	    		case XK_Up:         key_pressed = UP;        break;
   				case XK_Down:       key_pressed = DOWN;      break;
   				case XK_Left:       key_pressed = LEFT;      break;
    			case XK_Right:      key_pressed = RIGHT;     break;
    			case XK_Next:       key_pressed = PGDN;      break;
    			case XK_Prior:      key_pressed = PGUP;      break;
    			case XK_BackSpace:  key_pressed = BACKSPACE; break;
  	    		case XK_Escape:     key_pressed = ESC;       break;
  	    		case XK_Tab:        key_pressed = TAB;       break;
 				case XK_underscore: key_pressed = '_';       break;
   	    		case XK_asciitilde: key_pressed = '~';       break;

	// number pad
				case XK_KP_Enter:       key_pressed = KPENTER;   break;
				case XK_KP_Add:         key_pressed = KPPLUS;    break;
				case XK_KP_End:         key_pressed = KP1;       break;
				case XK_KP_Down:        key_pressed = KP2;       break;
				case XK_KP_Page_Down:   key_pressed = KP3;       break;
				case XK_KP_Left:        key_pressed = KP4;       break;
				case XK_KP_Begin:       key_pressed = KP5;       break;
				case XK_KP_Right:       key_pressed = KP6;       break;
				case XK_KP_Insert:      key_pressed = KPINS;     break;
				case XK_KP_Delete:      key_pressed = KPDEL;     break;

 	    		default:       key_pressed = keys_return[0]; break;
  			}

// dispatch keypress until trapped
			keypress_event_dispatch();
			
// give to user after everyone else has trapped it		
  			if(key_pressed && enabled) keypress_event();    
			break;

		case FocusOut:
			cursor_x = cursor_y = -1;
			cursor_left_dispatch();
			break;

		case LeaveNotify:
//printf("LeaveNotify\n");
			event_win = report.xany.window;
			if(report.xcrossing.focus)
			{
// button release dispatches leavenotify
				cursor_x = report.xcrossing.x;
				cursor_y = report.xcrossing.y;
			}
			else
			{
// cursor position is reported inside tool when crossing to a higher window
				cursor_x = cursor_y = -1;
			}
//printf("%d %d focus %d\n", cursor_x, cursor_y, report.xcrossing.focus);

// dispatch to subwindows
			cursor_left_dispatch();
			break;
	}

	unlock_window();
	report.type = 0;           // clear this report in case next event is a repeat or motion buffer
}



// ================================== motion events

BC_Window::store_motion_event(XEvent *report)
{
	static Window tempwin;

// only store if the motion wasn't in the last deleted window
	if(last_deleted_window != report->xany.window)
	{	
		motion_buffer = 1;
		XTranslateCoordinates(display, report->xany.window, win, report->xmotion.x, report->xmotion.y, &motion_buffer_x, &motion_buffer_y, &tempwin);
		motion_buffer_win = report->xany.window;
	}
}

BC_Window::dispatch_motion_event_main()
{
	event_win = motion_buffer_win;
	cursor_x = motion_buffer_x;
	cursor_y = motion_buffer_y;
	motion_buffer = 0;

//printf("BC_Window::dispatch_motion_event_main %d %d\n", cursor_x, cursor_y);
	if(active_menubar) active_menubar->motion_event_dispatch();
	else
	if(active_popup_menu) active_popup_menu->motion_event_dispatch();
  else 
  motion_event_dispatch();
}



// ===================================== configuration

BC_Window::set_last_deleted(Window win) { last_deleted_window = win; }

BC_Window::shift_down(){ return shift_mask; };
BC_Window::ctrl_down(){ return ctrl_mask; };
BC_Window::lock_window() { XLockDisplay(display); }
BC_Window::unlock_window() { XUnlockDisplay(display); }

BC_Window::show_window() { XMapWindow(display, win); hidden = 0; XFlush(display); }
BC_Window::hide_window() { XUnmapWindow(display, win); hidden = 1; XFlush(display); }

// flush out all the events
BC_Window::window_reset()
{
	XEvent report;
	
	//while(XPending(display)) XNextEvent(display, &report);
	//flash();
}

// ================================== event handlers

BC_Window::set_repeat(long duration)                  // signal the event handler to repeat
{
	repeat = duration;
	repeat_timer.update();
	repeat_buffer = 0;
}

BC_Window::unset_repeat() 
{ 
	repeat = 0; 
	repeat_buffer = 0;
}


BC_Window::set_done(int return_value)
{
	XExposeEvent report;
	report.type = Expose;
	done = 1;
	XSendEvent(display, win, 0, 0, (XEvent *)&report);
	this->return_value = return_value;
	XFlush(display);
}

BC_Window::set_title(char *title) 
{ 
	XSetStandardProperties(display, win, title, title, None, 0, 0, 0); 
	XFlush(display);
}

BC_Window::to_clipboard(char *data) { XStoreBytes(display, data, strlen(data)); }

BC_Window::clipboard_len()
{
	char *data2;
	int len;
	
	data2 = XFetchBytes(display, &len);
	XFree(data2);
	return len;
}

BC_Window::from_clipboard(char *data)
{
	char *data2;
	int len, i;
	
	data2 = XFetchBytes(display, &len);
	for(i = 0; i < len; i++)
		data[i] = data2[i];
		
	data[i] = 0;
	
	XFree(data2);
}

// ========================= cycle every text box in every subwindow

BC_Window::cycle_textboxes()
{
	int result = 0;
	BC_Tool *tool = 0;
	
	find_next_textbox(tool, &result);
	
	if(result == 0)
	{
// no active textbox found
		return 0;
	}
	
	if(result == 1)
	{
// no next textbox found
		find_first_textbox(tool);
	}

// activate the tool
	if(tool) tool->activate();
}
