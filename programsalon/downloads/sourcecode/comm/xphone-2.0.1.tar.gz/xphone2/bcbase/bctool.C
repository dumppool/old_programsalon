#include "bctool.h"

BC_Tool::BC_Tool(int x_, int y_, int w_, int h_)
{
	x = x_; y = y_; w = w_; h = h_;
	pixmap = 0;
	win = 0;
	enabled = 1;
	list_item = 0;      // in case this tool is never incorporated into a window
	temp_pixmap = 0;
	temp_pixmap_w = temp_pixmap_h = 0;
	temp_bitmap = 0;
}

BC_Tool::~BC_Tool()
{
// deactivate if active
	if(top_level->active_tool == this) top_level->active_tool = 0;

// destroy the X window
	if(temp_pixmap)
	{
		XFreePixmap(top_level->display, temp_pixmap);
		temp_pixmap = 0;
	}

	if(temp_bitmap)
	{
		delete temp_bitmap;
		temp_bitmap = 0;
	}

	if(top_level->win)
	{
		XDestroyWindow(top_level->display, win);
		XFreePixmap(top_level->display, pixmap);

		XFlush(top_level->display);
	}
	if(list_item)
	{
		list_item->pointer = 0;   // stop an infinite loop
		delete list_item;        // delete the list item that owns this tool
	}
}

BC_Tool::create_tool_objects(BC_Window *top_level, BC_WindowBase *subwindow)
{
	this->top_level = top_level;
	this->subwindow = subwindow;
	create_tool_objects();   // tool creates its window here
}

BC_Tool::create_tool_objects()
{
// copy the subwindow's color by default
	create_window(x, y, w, h, subwindow->color);
	create_objects();       // user can create objects here
}

BC_Tool::create_window(int x, int y, int w, int h, int color)
{
	this->color = color;

// create the window
	unsigned long mask;
	XSetWindowAttributes attr;

	mask = CWEventMask | CWBackPixel | CWBorderPixel;
	attr.event_mask = ExposureMask;
	attr.background_pixel = top_level->get_color(color);
	attr.border_pixel = top_level->get_color(color);

	win = XCreateWindow(top_level->display, subwindow->win, x, y, w, h, 0, top_level->depth, InputOutput, top_level->vis, mask, &attr);

	XMapWindow(top_level->display, win);
	pixmap = XCreatePixmap(top_level->display, win, w, h, top_level->depth);
	set_color(color);
	draw_box(0, 0, w, h);
}

BC_Tool::button_release_dispatch()
{
	cursor_x = subwindow->cursor_x - x;
	cursor_y = subwindow->cursor_y - y;
	if(enabled) button_release_();
}

BC_Tool::button_press_dispatch()
{
	cursor_x = subwindow->cursor_x - x;
	cursor_y = subwindow->cursor_y - y;
	if(enabled) button_press_();
}

BC_Tool::expose_event_dispatch()
{
// if window flashes black and white, gc is inverse
	if(top_level->event_win == win) flash();
}

BC_Tool::cursor_left_dispatch()
{
	cursor_x = subwindow->cursor_x - x;
	cursor_y = subwindow->cursor_y - y;
	if(enabled) cursor_left_();
}

BC_Tool::motion_event_dispatch()
{
	cursor_x = subwindow->cursor_x - x;
	cursor_y = subwindow->cursor_y - y;
	if(enabled) cursor_motion_();          // send to tool
}

BC_Tool::repeat_dispatch()
{
	return repeat_();
}

BC_Tool::cursor_left_()
{
	//printf("No cursor_left_ event handler declared\n");
}

BC_Tool::repeat_()
{
	return 0;
}

BC_Tool::resize_window(int x, int y, int w, int h)
{
	XMoveResizeWindow(top_level->display, win, x, y, w, h);
	XFreePixmap(top_level->display, pixmap);
  pixmap = XCreatePixmap(top_level->display, win, w, h, top_level->depth);
  this->x = x; this->y = y; this->w = w; this->h = h;
// clear the pixmap
	set_color(color);
	draw_box(0, 0, w, h);
}

BC_Tool::enable() { enabled = 1; }

BC_Tool::disable() { enabled = 0; }

BC_Tool::disable_window() { top_level->disable_window(); }

BC_Tool::enable_window() { top_level->enable_window(); }

BC_Tool::lock_window() { top_level->lock_window(); }

BC_Tool::unlock_window() { top_level->unlock_window(); }

BC_Tool::change_y(int y)
{
	this->y += y;
	XMoveResizeWindow(top_level->display, win, x, this->y, w, h);
	change_y_(y);
}

BC_Tool::set_y(int y)
{
	this->y = y;
	XMoveResizeWindow(top_level->display, win, x, y, w, h);
}

BC_Tool::set_x(int x)
{
	this->x = x;
	if(x < -w || x > subwindow->w)     // move just outside window if out of range
	XMoveResizeWindow(top_level->display, win, -w, y, w, h);
	else
	XMoveResizeWindow(top_level->display, win, x, y, w, h);
}

BC_Tool::get_keypress()
{
	return top_level->get_keypress();
}

BC_Tool::get_buttonpress()
{
	return top_level->get_buttonpress();
}

BC_Tool::ctrl_down()
{
	return top_level->ctrl_down();
}

BC_Tool::shift_down()
{
	return top_level->shift_down();
}

BC_Tool::trap_keypress()
{
	top_level->key_pressed = 0;
}

BC_Tool::set_done(int return_value)
{
	top_level->set_done(return_value);
}

BC_Tool::flash()
{
	set_opaque();
  XCopyArea(top_level->display, pixmap, win, top_level->gc, 0, 0, w, h, 0, 0);
  XFlush(top_level->display);
};

BC_Tool::flash(int x_, int y_, int w_, int h_)
{
	if(y_ < 0)
	{
		h_ += y_; y_ = 0;  
	}
	if(x_ < 0)
	{
		w_ += x_; x_ = 0;  
	}
	if(y_ + h_ > h) h_ = h - y_;
	if(x_ + w_ > w) w_ = w - x_;

  XCopyArea(top_level->display, pixmap, win, top_level->gc, x_, y_, w_, h_, x_, y_);
	XFlush(top_level->display);
}

BC_Tool::activate()
{
	if(top_level->active_tool != this)
	{
		if(top_level->active_tool) top_level->active_tool->deactivate();
		top_level->active_tool = this;
		activate_();
	}
}

BC_Tool::is_active()
{
	if(top_level->active_tool == this) return 1; else return 0;
}

BC_Tool::set_repeat(long repeat)
{
	top_level->set_repeat(repeat);
}

BC_Tool::unset_repeat()
{
	top_level->unset_repeat();
}

BC_Tool::set_color(int color, GC *gc = 0)
{
	XSetForeground(top_level->display, gc ? *gc : top_level->gc, top_level->get_color(color)); 
}

BC_Tool::set_inverse() 
{
	XSetFunction(top_level->display, top_level->gc, GXxor);
}

BC_Tool::set_opaque() 
{
	XSetFunction(top_level->display, top_level->gc, GXcopy);
}

BC_Tool::draw_3d_diamond(int x1, int y1, int w, int h, int light, int middle, int shadow)
{
	int x2, x3, y2, y3;
	XPoint point[4];
	
	w--; h--;
	x2 = x1 + w / 2;
	x3 = x1 + w;
	y2 = y1 + h / 2;
	y3 = y1 + h;

	point[0].x = x1; point[0].y = y2;
	point[1].x = x2; point[1].y = y1;
	point[2].x = x3; point[2].y = y2;
	point[3].x = x2; point[3].y = y3;
  set_color(middle);
  XFillPolygon(top_level->display, pixmap, top_level->gc, point, 4, Nonconvex, CoordModeOrigin);
	
  set_color(light);
	draw_line(x1, y2, x2, y1);
	draw_line(x1+1, y2, x2+1, y1);
	
	draw_line(x2, y1, x3, y2);
	draw_line(x2+1, y1, x3+1, y2);
	
  set_color(shadow);
	draw_line(x3, y2, x2, y3);
	draw_line(x3+1, y2, x2+1, y3);
	
	draw_line(x2, y3, x1, y2);
	draw_line(x2+1, y3, x1+1, y2);
}

BC_Tool::draw_3d_big(int x1, int y1, int w, int h, int light, int middle, int shadow)
{
  int lx,ly,ux,uy;

	h--; w--;
	
  lx = x1+1;  ly = y1+1;
  ux = x1+w-1;  uy = y1+h-1;

  set_color(middle);
  draw_box(x1, y1, w, h);
  
  set_color(light);
  draw_line(x1, y1, x1+w, y1);
  draw_line(x1, y1, x1, y1+h);
  draw_line(lx, ly, ux, ly);
  draw_line(lx, ly, lx, uy);

  set_color(shadow);
  draw_line(x1+w, y1, x1+w, y1+h);
  draw_line(x1, y1+h, x1+w, y1+h);
  draw_line(ux, ly, ux, uy);
  draw_line(lx, uy, ux, uy);
}

BC_Tool::draw_3d_small(int x1, int y1, int w, int h, int light, int middle, int shadow)
{
	h--; w--;
	
  set_color(middle);
  draw_box(x1, y1, w, h);
  
  set_color(light);
  draw_line(x1, y1, x1+w, y1);
  draw_line(x1, y1, x1, y1+h);

  set_color(shadow);
  draw_line(x1+w, y1, x1+w, y1+h);
  draw_line(x1, y1+h, x1+w, y1+h);
}

BC_Tool::draw_rectangle(int x_, int y_, int w_, int h_) 
{ 
	XDrawRectangle(top_level->display, pixmap, top_level->gc, x_, y_, w_ - 1, h_ - 1); 
}

BC_Tool::draw_box(int x_, int y_, int w_, int h_) 
{ 
  //printf("draw_box %d\n", pixmap);
	XFillRectangle(top_level->display, pixmap, top_level->gc, x_, y_, w_, h_); 
}

BC_Tool::draw_line(int x1, int y1, int x2, int y2) 
{
	XDrawLine(top_level->display, pixmap, top_level->gc, x1, y1, x2, y2);
}

BC_Tool::draw_3d_line(int x1, int y1, int x2, int y2, int color1, int color2, GC *gc = 0)
{
	set_color(color1, gc ? gc : &(top_level->gc));
	XDrawLine(top_level->display, pixmap, gc ? *gc : top_level->gc, x1, y1, x2, y2);
	set_color(color2, gc ? gc : &(top_level->gc));
	XDrawLine(top_level->display, pixmap, gc ? *gc : top_level->gc, x1, y1+1, x2, y2+1);
}

BC_Tool::draw_disc(int x, int y, int w, int h, GC *gc)
{
	XFillArc(top_level->display, pixmap, gc ? *gc : top_level->gc, x, y, (w - 1), (h - 2), 0*64, 360*64);
}

BC_Tool::draw_bitmap(VFrame *frame, 
			int in_x1, int in_y1, int in_x2, int in_y2, 
			int out_x1, int out_y1, int out_x2, int out_y2, GC *gc)
{
	if(!gc) gc = &(top_level->gc);

	get_temp_bitmap(out_x2 - out_x1, out_y2 - out_y1);
	temp_bitmap->read_frame(frame, in_x1, in_y1, in_x2, in_y2);
	temp_bitmap->write_drawable(pixmap, out_x1, out_y1, 0, 0, out_x2 - out_x1, out_y2 - out_y1);
}

BC_Tool::draw_text(int x_, int y_, char *text) 
{
	XDrawString(top_level->display, pixmap, top_level->gc, x_, y_, text, strlen(text));
}

BC_Tool::draw_vertical_text(int x, int y, char *text, int fgcolor, int bgcolor, GC *gc)
{
	int len = strlen(text);
	int w = XTextWidth(top_level->largefont, text, len) + 10;
	int h = top_level->largefont->ascent + top_level->largefont->descent;
	int d = w > h ? w : h;

	if(!gc) gc = &(top_level->gc);

	get_temp_pixmap(d, d);     // pixmap has to be the same size as bitmap for ShmGetImage
	get_temp_bitmap(d, d);
	set_color(bgcolor, gc);
	XFillRectangle(top_level->display, temp_pixmap, *gc, 0, 0, d, d);
	set_color(fgcolor, gc);
	XDrawString(top_level->display, temp_pixmap, *gc, 0, top_level->largefont->ascent, text, len);
//printf("BC_Tool::draw_vertical_text 1 %d %d\n", d, d);
	temp_bitmap->read_drawable(temp_pixmap, 0, 0);
//printf("BC_Tool::draw_vertical_text 2\n");
	temp_bitmap->rotate_90(d);
	temp_bitmap->write_drawable(pixmap, x, y, d - h, 0, h, w);
//printf("BC_Tool::draw_vertical_text 3\n");
}



BC_Tool::draw_center_text(int x, int y, char *text, XFontStruct *font) {
	if(!font) font = top_level->smallfont;
	x -= XTextWidth(font, text, strlen(text)) / 2;
	XDrawString(top_level->display, pixmap, top_level->gc, x, y, text, strlen(text));
};

BC_Tool::set_font(XFontStruct *font) 
{ 
	XSetFont(top_level->display, top_level->gc, font->fid);
};

BC_Tool::get_text_width(XFontStruct *font, char *text)
{
	return XTextWidth(font, text, strlen(text));
}

BC_Tool::get_text_height(XFontStruct *font)
{
	return font->ascent + font->descent;
}

BC_Tool::get_text_ascent(XFontStruct *font)
{
	return font->ascent;
}

BC_Tool::get_text_height(int font)
{
	switch(font)
	{
		case LARGEFONT: return top_level->largefont->ascent + top_level->largefont->descent; break;
		case SMALLFONT: return top_level->smallfont->ascent + top_level->smallfont->descent; break;
		case TITLEFONT: return top_level->titlefont->ascent + top_level->titlefont->descent; break;
	}
}

BC_Tool::get_text_ascent(int font)
{
	switch(font)
	{
		case LARGEFONT: return top_level->largefont->ascent; break;
		case SMALLFONT: return top_level->smallfont->ascent; break;
		case TITLEFONT: return top_level->titlefont->ascent; break;
	}
}

BC_Tool::get_text_descent(int font)
{
	switch(font)
	{
		case LARGEFONT: return top_level->largefont->descent; break;
		case SMALLFONT: return top_level->smallfont->descent; break;
		case TITLEFONT: return top_level->titlefont->descent; break;
	}
}

BC_Tool::set_font(int font) 
{ 
	switch(font)
	{
		case LARGEFONT: XSetFont(top_level->display, top_level->gc, top_level->largefont->fid); break;
		case SMALLFONT: XSetFont(top_level->display, top_level->gc, top_level->smallfont->fid); break;
		case TITLEFONT: XSetFont(top_level->display, top_level->gc, top_level->titlefont->fid); break;
	}
};

BC_Tool::get_text_width(int font, char *text)
{
	switch(font)
	{
		case LARGEFONT: return XTextWidth(top_level->largefont, text, strlen(text)); break;
		case SMALLFONT: return XTextWidth(top_level->smallfont, text, strlen(text)); break;
		case TITLEFONT: return XTextWidth(top_level->titlefont, text, strlen(text)); break;
	}
}

BC_Tool::slide_left(int distance)
{
	if(distance < w)
	{
		XCopyArea(top_level->display, pixmap, pixmap, top_level->gc, distance, 0, w - distance, h, 0, 0);
	}
}

BC_Tool::slide_right(int distance)
{
	if(distance < w)
	{
		XCopyArea(top_level->display, pixmap, pixmap, top_level->gc, 0, 0, w - distance, h, distance, 0);
	}
}

BC_Tool::slide_up(int distance)
{
	if(distance < h)
	{
	  XCopyArea(top_level->display, pixmap, pixmap, top_level->gc, 0, distance, w, h - distance, 0, 0);
		set_color(subwindow->color);
	  XFillRectangle(top_level->display, pixmap, top_level->gc, 0, h - distance, w, distance);
  }
}

BC_Tool::slide_down(int distance)
{
	if(distance < h)
	{
		XCopyArea(top_level->display, pixmap, pixmap, top_level->gc, 0, 0, w, h - distance, 0, distance);
		set_color(subwindow->color);
		XFillRectangle(top_level->display, pixmap, top_level->gc, 0, 0, w, distance);
	}
}

BC_Tool::uses_text()
{             // set to 1 if tool uses text input
	return 0;
}

BC_Tool::get_temp_pixmap(int w, int h)
{
	if(temp_pixmap && (w > temp_pixmap_w || h > temp_pixmap_h))
	{
		XFreePixmap(top_level->display, temp_pixmap);
		temp_pixmap = 0;
	}

	if(!temp_pixmap)
	{
		temp_pixmap = XCreatePixmap(top_level->display, win, w, h, top_level->depth);
	}
}

BC_Tool::get_temp_bitmap(int w, int h)
{
//printf("BC_Tool::get_temp_bitmap 1\n");
// the bitmap must be wholly contained in the source during a GetImage
	if(temp_bitmap && (w != temp_bitmap->w || h != temp_bitmap->h))
	{
//printf("BC_Tool::get_temp_bitmap 2\n");
		delete temp_bitmap;
		temp_bitmap = 0;
	}

	if(!temp_bitmap)
	{
//printf("BC_Tool::get_temp_bitmap 3\n");
		temp_bitmap = new BC_Bitmap(top_level, w, h, top_level->depth);
//printf("BC_Tool::get_temp_bitmap 4\n");
	}
}






BC_ToolItem::BC_ToolItem(BC_Tool *pointer)
 : ListItem<BC_ToolItem>()
{
	this->pointer = pointer;
	pointer->list_item = this;
}

BC_ToolItem::~BC_ToolItem()
{
//printf("BC_ToolItem::~BC_ToolItem %x\n", pointer);
	if(pointer)
	{
		pointer->list_item = 0;      // stop an infinite loop
		delete pointer;        // delete the tool object
		pointer = 0;
	}
}

BC_ToolList::BC_ToolList()
 : List<BC_ToolItem>()
{
}

BC_ToolList::~BC_ToolList()
{
// delete from first to last since some tools delete their own tools
	while(first) delete first;
}

BC_ToolList::append(BC_Tool *tool)
{
	List<BC_ToolItem>::append(new BC_ToolItem(tool));
}

BC_ToolList::remove(BC_Tool *tool)
{
	BC_ToolItem *current;
	
	for(current = first; current && current->pointer != tool; current = NEXT)
		;
	
	if(current) List<BC_ToolItem>::remove(current);
}
