#ifndef BCPROGRESS_H
#define BCPROGRESS_H

class BC_ProgressBar;

#include "bccolors.h"
#include "bctool.h"

class BC_ProgressBar : public BC_Tool
{
public:
	BC_ProgressBar(int x_, int y_, int w_, int h_, long length_);
	create_tool_objects();
	
	draw();
	update(long position_);
	update_length(long length);
	
	long length, position;
	int percentage;
};

#endif
