#include "bcsubwindow.h"
#include "bctool.h"
#include "bcwindow.h"
#include "bcwindowbase.h"

// =============================== initialization

BC_WindowBase::BC_WindowBase(int x, int y, int w, int h, int color)
{
	this->x = x; this->y = y; this->w = w; this->h = h, this->color = color;
	subwindows = new BC_SubWindowList;
	tools = new BC_ToolList;
	border = 0;
	enabled = 1;
	top_level = 0;
	parent_window = 0;
}

BC_WindowBase::~BC_WindowBase()
{
//printf("BC_WindowBase::~BC_WindowBase 1 %x\n", top_level->win);
// =================================== delete subwindows
	delete subwindows;     // delete owned subwindow base classes

//printf("BC_WindowBase::~BC_WindowBase 2\n");

// delete the tools
	delete tools;

// delete the X window of this subwindow
	if(top_level->win != 0) 
	{
//printf("BC_WindowBase::~BC_WindowBase 3 %d\n", top_level->win);
		XDestroyWindow(top_level->display, win);
		XFlush(top_level->display);
		win = 0;
//printf("BC_WindowBase::~BC_WindowBase 4\n");
	}
	
	if(top_level == this)
	{
//printf("BC_WindowBase::~BC_WindowBase 5\n");
		//XCloseDisplay(top_level->display);
		win = 0;
//printf("BC_WindowBase::~BC_WindowBase 6\n");
	}
}

BC_WindowBase::destroy_window()
{
// destroy just the X window
	for(BC_SubWindowItem* subwindow = subwindows->first; 
		subwindow; subwindow = subwindow->next) subwindow->pointer->destroy_window();

// destroy it's own window
	XDestroyWindow(top_level->display, win);
	XFlush(top_level->display);
	win = 0;
}

BC_SubWindow* BC_WindowBase::add_subwindow(BC_SubWindow *subwindow) 
{
	if(!parent_window) parent_window = this;
	
// add pointer to the subwindow to the list
	subwindows->append(subwindow); 

// build the subwindow
	subwindow->create_objects_(top_level, this); 
}

BC_WindowBase::delete_subwindow(BC_SubWindow* subwindow)
{
	if(subwindow)            // delete the object
	subwindows->remove(subwindow);
	
// user must delete derived class
}

BC_Tool* BC_WindowBase::add_tool(BC_Tool *tool)
{
	if(!parent_window) parent_window = this;
	
// add the object
	tools->append(tool);
	
// build the tool
	tool->create_tool_objects(top_level, this);

	return tool;
}

BC_WindowBase::delete_tool(BC_Tool *tool)
{
// delete the object
// user must delete derived class
	tools->remove(tool);
}

BC_WindowBase::add_border(int light, int medium, int dark)
{
	if(!parent_window) parent_window = this;
	
	border = 1;    
	this->light = light;    
	this->medium = medium;
	this->dark = dark;
	draw_border();
}

BC_WindowBase::resize_window(int x, int y, int w, int h)
{
	XMoveResizeWindow(top_level->display, win, x, y, w, h);
	this->x = x; this->y = y; this->w = w; this->h = h;
	if(border) draw_border();
// send tools and menubar the new size
	for(BC_ToolItem *tool = tools->first; tool; tool = tool->next)
	{
		tool->pointer->resize_event_(w, h);
	}
}

BC_WindowBase::resize_window(int w, int h)
{
	XResizeWindow(top_level->display, win, w, h);
	this->w = w; this->h = h;
	if(border) draw_border();
// send tools and menubar the new size
	for(BC_ToolItem *tool = tools->first; tool; tool = tool->next)
	{
		tool->pointer->resize_event_(w, h);
	}
}

BC_WindowBase::get_keypress() { return top_level->key_pressed; }

BC_WindowBase::get_buttonpress() { return top_level->button_pressed; }

// ================================= event handlers

BC_WindowBase::repeat_dispatch()
{
	int result = 0;
	
// all repeat event handlers must return either 1 or 0 to trap the repeat
	for(BC_SubWindowItem *subwindow = subwindows->first; 
		subwindow && !result; subwindow = subwindow->next)
	{
		result = subwindow->pointer->repeat_dispatch();
	}
	
	for(BC_ToolItem *tool = tools->first; tool && !result; tool = tool->next)
	{
		result = tool->pointer->repeat_dispatch();
	}
	
	return result;
}

BC_WindowBase::expose_event_dispatch()
{
// if window flashes black and white, gc is inverse
// refresh this window's border
	if(top_level->event_win == win && border) draw_border();

// send to all subwindows
	for(BC_SubWindowItem *subwindow = subwindows->first; subwindow; subwindow = subwindow->next)
	{
		subwindow->pointer->expose_event_dispatch();
	}
			
// send to all tools in this subwindow
	for(BC_ToolItem *tool = tools->first; tool; tool = tool->next)
	{
		tool->pointer->expose_event_dispatch();
	}
}

BC_WindowBase::button_press_dispatch()
{
	cursor_x = parent_window->cursor_x - x;
	cursor_y = parent_window->cursor_y - y;

// give to user
	button_press();

	for(BC_SubWindowItem *subwindow = subwindows->first; 
		subwindow; subwindow = subwindow->next)
	{
		subwindow->pointer->button_press_dispatch();
	}

	if(cursor_x > 0 && cursor_x < w && cursor_y > 0 && cursor_y < h)
	{
		for(BC_ToolItem *tool = tools->first; tool; tool = tool->next)
		{
			tool->pointer->button_press_dispatch();
		}
	}
}

BC_WindowBase::button_release_dispatch()
{
	cursor_x = parent_window->cursor_x - x;
	cursor_y = parent_window->cursor_y - y;
//printf("BC_WindowBase::button_release_dispatch cursor_x %d cursor_y %d\n", cursor_x, cursor_y);
// give to user
	button_release();

	for(BC_SubWindowItem *subwindow = subwindows->first; 
		subwindow; subwindow = subwindow->next)
	{
		subwindow->pointer->button_release_dispatch();
	}

	for(BC_ToolItem *tool = tools->first; tool; tool = tool->next)
	{
		tool->pointer->button_release_dispatch();
	}
}

BC_WindowBase::motion_event_dispatch()
{
	cursor_x = parent_window->cursor_x - x;
	cursor_y = parent_window->cursor_y - y;
			
	for(BC_SubWindowItem *subwindow = subwindows->first; 
		subwindow; subwindow = subwindow->next)
	{
		subwindow->pointer->motion_event_dispatch();
	}

	for(BC_ToolItem *tool = tools->first; tool; tool = tool->next)
	{
		tool->pointer->motion_event_dispatch();
	}
	
	cursor_motion();    // give to user
}

BC_WindowBase::resize_event_dispatch()
{
// only give to user on top level
// give user size of parent window
//resize_event(parent_window->w, parent_window->h);

// resize other subwindows
	for(BC_SubWindowItem *subwindow = subwindows->first; 
		subwindow; subwindow = subwindow->next)
	{
		subwindow->pointer->resize_event_dispatch();
	}
	
// send tools and menubar the size of this window
	for(BC_ToolItem *tool = tools->first; tool; tool = tool->next)
	{
		tool->pointer->resize_event_(w, h);
	}
}

BC_WindowBase::keypress_event_dispatch()
{
// give keypress to active tool first
	if(top_level->active_tool) top_level->active_tool->keypress_event_();

// give to all subwindows
	for(BC_SubWindowItem *subwindow = subwindows->first; 
		subwindow && top_level->key_pressed; subwindow = subwindow->next)
	{
		subwindow->pointer->keypress_event_dispatch(); 
	}

// give to all tools
	for(BC_ToolItem *tool = tools->first; tool && top_level->key_pressed; tool = tool->next)
	{
		if(tool->pointer->enabled) tool->pointer->keypress_event_();
	}
}

BC_WindowBase::cursor_left_dispatch()
{
	cursor_x = parent_window->cursor_x - x;
	cursor_y = parent_window->cursor_y - y;

	for(BC_SubWindowItem *subwindow = subwindows->first; 
		subwindow; subwindow = subwindow->next)
	{
		subwindow->pointer->cursor_left_dispatch();
	}

	for(BC_ToolItem *tool = tools->first; tool; tool = tool->next)
	{
		tool->pointer->cursor_left_dispatch();
	}
}

// =========================== configuration

// flash all the subwindows
BC_WindowBase::flash()
{
	if(border) draw_border();

// flash all the subwindows
	for(BC_SubWindowItem *subwindow = subwindows->first; 
		subwindow; subwindow = subwindow->next)
	{
		subwindow->pointer->flash();
	}

// flash all the tools
	for(BC_ToolItem *tool = tools->first; tool; tool = tool->next)
	{
		tool->pointer->flash();
	}
}





// ============================= control

BC_WindowBase::enable_window()
{
	enabled = 1;
	for(BC_SubWindowItem* subwindow = subwindows->first; 
		subwindow; subwindow = subwindow->next) subwindow->pointer->enable_window();
		
	for(BC_ToolItem *tool = tools->first; tool; tool = tool->next)
	{
		tool->pointer->enable();
	}
}

BC_WindowBase::disable_window()
{
	enabled = 0;
	for(BC_SubWindowItem* subwindow = subwindows->first; 
		subwindow; subwindow = subwindow->next) subwindow->pointer->disable_window();
		
	for(BC_ToolItem *tool = tools->first; tool; tool = tool->next)
	{
		tool->pointer->disable();
	}
}

BC_WindowBase::find_first_textbox(BC_Tool *tool)
{
	int result = 0;

// search this subwindow for tool
	for(BC_ToolItem *test_tool = tools->first; test_tool && !result; test_tool = test_tool->next)
	{
		if(test_tool->pointer->uses_text())
		{
			tool = test_tool->pointer;
			result = 1;
		}
	}

// search subwindows for tool if not found
	for(BC_SubWindowItem* test_subwindow = subwindows->first; 
		test_subwindow && !result; test_subwindow = test_subwindow->next)
	{
  	 result = test_subwindow->pointer->find_first_textbox(tool);
	}
	
	return result;
}


BC_WindowBase::find_next_textbox(BC_Tool *tool, int *result)
{
// search this subwindow for a tool
	for(BC_ToolItem *test_tool = tools->first; test_tool && *result != 2;)
	{
		if(*result == 0)
		{
// searching for active text box 
			if(top_level->active_tool == test_tool->pointer && test_tool->pointer->uses_text())
			{
				(*result)++;
			}
		}
		else
		{
// searching for next text box in line
			if(test_tool->pointer->uses_text())
			{
				tool = test_tool->pointer;
				(*result)++;
			}
		}
		if(*result != 2)  test_tool = test_tool->next;
	}

// try the subwindows
	for(BC_SubWindowItem* test_subwindow = subwindows->first; 
		test_subwindow && *result != 2; test_subwindow = test_subwindow->next)
	{
  	 test_subwindow->pointer->find_next_textbox(tool, result);
	}
}

// =================================== drawing

BC_WindowBase::draw_border()
{
  int lx,ly,ux,uy;
	int h = this->h, w = this->w;
	
	h--; w--;
	
  lx = 1;  ly = 1;
  ux = w-1;  uy = h-1;

  set_color(light);
  draw_line(0, 0, w, 0);
  draw_line(0, 0, 0, h);
  draw_line(lx, ly, ux, ly);
  draw_line(lx, ly, lx, uy);

  set_color(dark);
  draw_line(w, 0, w,h);
  draw_line(0, h, w, h);
  draw_line(ux, ly, ux, uy);
  draw_line(lx, uy, ux, uy);
}

BC_WindowBase::set_color(int color)
{
	XSetForeground(top_level->display, top_level->gc, top_level->get_color(color)); 
}

BC_WindowBase::draw_line(int x1, int y1, int x2, int y2) 
{
	XDrawLine(top_level->display, win, top_level->gc, x1, y1, x2, y2);
}
