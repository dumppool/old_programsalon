#ifndef BCSUBWINDOW_H
#define BCSUBWINDOW_H

class BC_SubWindow;
class BC_SubWindows;
class BC_SubWindowItem;
class BC_SubWindowList;

#include "bcwindowbase.h"
#include "linklist.h"

class BC_SubWindow : public BC_WindowBase
{
public:
	BC_SubWindow() {};

// create the data for a subwindow to a window
	BC_SubWindow(int x, int y, int w, int h, int color);

// destroy the subwindow
	virtual ~BC_SubWindow();


// user routines specific to subwindows

	change_x(int distance);                   // change the x position of this window
	change_y(int distance);                   // change the y position of this window

// ========== called by the parent window to actually create this window
	create_objects_(BC_Window *top_level, BC_WindowBase *parent_window);

// create the subwindow window
	create_window();
	BC_SubWindowItem *subwindow_item;      // list item to delete when this is deleted
};

class BC_SubWindowItem : public ListItem<BC_SubWindowItem>
{
public:
	BC_SubWindowItem(BC_SubWindow *pointer);
	~BC_SubWindowItem();
	
	BC_SubWindow *pointer;
};

class BC_SubWindowList : public List<BC_SubWindowItem>
{
public:
	BC_SubWindowList();
	~BC_SubWindowList();
	
	append(BC_SubWindow *subwindow);
	remove(BC_SubWindow *subwindow);
};

#endif
