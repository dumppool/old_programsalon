#ifndef BCBUTTON_H
#define BCBUTTON_H

class BC_Button;

#include "bccolors.h"
#include "bctool.h"
#include "bcwindow.h"

class BC_Button : public BC_Tool
{
public:
	BC_Button(int x, int y, char *text);
	BC_Button(int x, int y, int w, char *text);
	virtual ~BC_Button();
	create_tool_objects();
	resize_tool(int x, int y);
	
	cursor_left_();
	button_press_();
	cursor_motion_();
	button_release_();
	keypress_event_();
	
	repeat_();      // must return 0 to avoid trapping
	virtual draw() = 0;              // defined in button class
	resize(int x, int y);
	update(char *text);
			
	int down, button_down, cursor_over, highlighted;
	char *text;
};

// Up triangle
class BC_UpTriangleButton : public BC_Button  // zoom out button
{
public:
	BC_UpTriangleButton(int x, int y, int w, int h);
	create_tool_objects();
	draw();
};

// Down triangle
class BC_DownTriangleButton : public BC_Button  // zoom in button
{
public:
	BC_DownTriangleButton(int x, int y, int w, int h);
	create_tool_objects();
	draw();
};

// Small button
class BC_SmallButton : public BC_Button     // small button
{
public:
	BC_SmallButton(int x, int y, char *text);
	BC_SmallButton(int x, int y, int w, char *text);
	create_tool_objects();
	draw();
};

// Big button
class BC_BigButton : public BC_Button      // big button
{
public:
	BC_BigButton(int x, int y, char *text);
	create_tool_objects();
	draw();
};

// Record button
class BC_RecButton : public BC_Button     // record button
{
public:
	BC_RecButton(int x, int y, int w, int h);
	create_tool_objects();
	draw();
	
	int is_rec;
};

// Duplex button
class BC_DuplexButton : public BC_Button      // play button
{
public:
	BC_DuplexButton(int x, int y, int w, int h);
	create_tool_objects();
	draw();
};

// Fast Rewind button
class BC_FastRewindButton : public BC_Button      // Fast rewind button
{
public:
	BC_FastRewindButton(int x, int y, int w, int h);
	create_tool_objects();
	draw();
	update();      // toggle between on and off
	
	int is_play;
};


// Stop button
class BC_StopButton : public BC_Button        // stop button
{
public:
	BC_StopButton(int x, int y, int w, int h);
	create_tool_objects();
	draw();
};

// Rewind button
class BC_RewindButton : public BC_Button        // Rewind button
{
public:
	BC_RewindButton(int x, int y, int w, int h);
	create_tool_objects();
	draw();
};

// End button
class BC_EndButton : public BC_Button        // End button
{
public:
	BC_EndButton(int x, int y, int w, int h);
	create_tool_objects();
	draw();
};

// =================================== playback buttons

// Playback button base class
class BC_PlayButton : public BC_Button      // play button
{
public:
	BC_PlayButton(int x, int y, int w, int h);
	
	update(int value);      // toggle between play, pause, and paused
	
	create_tool_objects();
	draw();
	virtual draw_polygon() {};
	set_orange(int value);
	reset_button();
	draw_pause();
	
	int mode;       // 0 - paused   1 - play    2 - pause
	int orange;
};

// Forward Play
class BC_ForwardButton : public BC_PlayButton      // play button
{
public:
	BC_ForwardButton(int x, int y, int w, int h);
	draw_polygon();
};

// Fast Playback button
class BC_FastForwardButton : public BC_PlayButton      // Fast play button
{
public:
	BC_FastForwardButton(int x, int y, int w, int h);
	draw_polygon();
};

// Reverse playback button
class BC_ReverseButton : public BC_PlayButton      // play button
{
public:
	BC_ReverseButton(int x, int y, int w, int h);
	draw_polygon();
};

// Fast Reverse Playback button
class BC_FastReverseButton : public BC_PlayButton      // Fast play button
{
public:
	BC_FastReverseButton(int x, int y, int w, int h);
	draw_polygon();
};


#endif
