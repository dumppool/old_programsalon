#ifndef POPUPMENU_H
#define POPUPMENU_H

#define ITEMHEIGHT 22

class BC_PopupMenu;
class BC_PopupMenuPopup;

#include "arraylist.h"
#include "bccolors.h"
#include "bcpopup.h"
#include "bctool.h"

class BC_PopupItem
{
public:
	BC_PopupItem(char *text, int checked = 0);
	virtual ~BC_PopupItem();
	create_objects(BC_PopupMenu *menu, int y);
	set_checked(int checked);
	
// ============================ user event handlers

	virtual handle_event();
	
// =========================== popup event handlers
	
	button_release(int cursor_x, int cursor_y);
	button_press(int cursor_x, int cursor_y);
	cursor_motion(int cursor_x, int cursor_y);
	cursor_left();
	deactivate();
	draw();
	get_width();
	update_menu();        // set the menu text to this text
	
	char *text;
	int y;
	int checked;
	int highlighted;
	BC_PopupMenu *menu;
};

class BC_PopupMenuPopup : public BC_Popup
{
public:
	BC_PopupMenuPopup(BC_PopupMenu *menu, BC_Window *top_level, int color, int x, int y, int w, int h);
	virtual ~BC_PopupMenuPopup();
	
	BC_PopupMenu *menu;
};

class BC_PopupMenu : public BC_Tool
{
public:
	BC_PopupMenu(int x, int y, int w, char *text, int small = 0);
	virtual ~BC_PopupMenu();

// user commands
	resize_tool(int x, int y, int w, int h);
	resize_tool(int x, int y);
	virtual add_items() {};    // user adds initial menu items here

	deactivate();
	add_item(BC_PopupItem *item);    // user adds an item
	delete_item(BC_PopupItem *item);   // user deletes an item
	update(char *text);               // change title string
	virtual handle_event() {};

	create_tool_objects();

	button_release_();
	button_press_();
	cursor_motion_();
	cursor_left_();
	draw_text();
	draw_items();
	draw();
	
	int popup_w, popup_h;
	int small;
	char text[1024];
	ArrayList<BC_PopupItem *> *items;
	int highlighted, down, button_down, cursor_over, popup_down;
	BC_PopupMenuPopup *popup;
};

#endif
