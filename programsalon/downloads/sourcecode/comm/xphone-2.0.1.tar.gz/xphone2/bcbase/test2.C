#include "bcbase.h"




main()
{
	BC_Window window("", BLACK, "Test", 320, 320, 320, 320);
	BC_Canvas *canvas;
	
	window.add_tool(canvas = new BC_Canvas(10, 10, 300, 300, MEGREY));
	canvas->draw_vertical_text(100, 100, "Test", WHITE, BLACK);
	canvas->flash();
	window.run_window();
}
