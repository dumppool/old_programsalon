#include "test.h"

void main()
{
	MainWindow *window;
	SubWindow *subwindow;
	MenuSubWindow *menusubwindow;
	BC_MenuBar *mainmenubar;
	BC_Menu *filemenu, *editmenu, *windowmenu;
	PanAutomation *panautomation;
	PanMenu *panmenu;
	PanItem *panitem[10];
	
	window = new MainWindow("");
	window->add_subwindow(subwindow = new SubWindow);

	window->add_tool(mainmenubar = new BC_MenuBar(10, 10, 380));
	mainmenubar->add_menu(filemenu = new BC_Menu("File"));
	filemenu->add_menuitem(new New(0));
	filemenu->add_menuitem(new Load(0));
	filemenu->add_menuitem(new Save(0));
	filemenu->add_menuitem(new SaveAs(0));
	filemenu->add_menuitem(new Import(0));
	filemenu->add_menuitem(new Quit(0));
	
	mainmenubar->add_menu(editmenu = new BC_Menu("Edit"));
	editmenu->add_menuitem(new Undo(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));
	editmenu->add_menuitem(new LongMenuItem(0));

	mainmenubar->add_menu(windowmenu = new BC_Menu("Window"));
	windowmenu->add_menuitem(new ShowEdits(0));
	windowmenu->add_menuitem(new ShowTitles(0));
	windowmenu->add_menuitem(new BC_MenuItem("-"));
	windowmenu->add_menuitem(new MuteAutomation(0));
	windowmenu->add_menuitem(new FadeAutomation(0));
	windowmenu->add_menuitem(panautomation = new PanAutomation(0));
	windowmenu->add_menuitem(new InverseAutomation(0));

	panautomation->add_submenu(panmenu = new PanMenu(0));
	for(int i = 0; i < 5; i++)
	{
		char string[256];
		sprintf(string, "Channel %d", i + 1);
		panmenu->add_submenuitem(panitem[i] = new PanItem(string));
	}
		
	subwindow->add_tool(new OK_Button(subwindow));
	subwindow->add_tool(new Cancel_Button(subwindow));
	subwindow->add_tool(new Small_Button(subwindow));
	subwindow->add_tool(new XScroll(subwindow));
	subwindow->add_tool(new YScroll(subwindow));
	subwindow->add_tool(new Text_Box(subwindow, "This is text"));
	subwindow->add_tool(new BC_TextBox(310, 40, 100, "Mary Egbert had a little lamb", 0));
	char *items[] = 
	{
"-rw-r-----   1 root     root        11011 Jun  4 14:31 bctool.C",
"-rw-r-----   1 root     root         4413 Jun  4 14:32 bctool.h",
"-rw-r--r--   1 root     root        12472 Jun  4 15:24 bctool.o",
"-rw-r-----   1 root     root        18644 Jun  3 20:34 bcwindow.C",
"-rw-r-----   1 root     root         4416 Jun  3 01:56 bcwindow.h",
"-rw-r--r--   1 root     root        13264 Jun  4 15:24 bcwindow.o",
"-rw-r--r--   1 root     root         9179 Jun  3 17:47 bcwindowbase.C",
"-rw-r--r--   1 root     root         2997 May 31 14:13 bcwindowbase.h",
"-rw-r--r--   1 root     root         6380 Jun  4 15:24 bcwindowbase.o",
"-rw-r-----   1 root     root         2481 May 26 12:29 defaults.C",
"-rw-r-----   1 root     root         1021 May 26 12:29 defaults.h",
"-rw-r--r--   1 root     root         3648 Jun  3 16:28 defaults.o",
"-rw-r--r--   1 root     root         5039 May 30 21:42 depend",
"-rw-r-----   1 root     root          936 May 30 21:31 errorbox.C",
"-rw-r-----   1 root     root          452 May 26 12:29 errorbox.h",
"-rw-r--r--   1 root     root         4232 Jun  4 15:24 errorbox.o",
"-rw-r-----   1 root     root         7992 May 31 01:12 filesystem.C",
"-rw-r-----   1 root     root         1286 May 26 12:29 filesystem.h",
"-rw-r--r--   1 root     root         5592 Jun  3 16:27 filesystem.o",
"-rwxr-xr-x   1 root     root       253774 Jun  4 15:28 libbcbase.so",
"-rw-r-----   1 root     root         5098 May 31 12:32 linklist.h",
"-rw-r-----   1 root     root         4120 May 26 12:29 stringfile.C",
"-rw-r-----   1 root     root         1512 May 26 12:29 stringfile.h",
"-rw-r--r--   1 root     root         5616 Jun  3 16:28 stringfile.o",
"-rwxr-xr-x   1 root     root          159 May 31 21:55 test",
"-rw-r-----   1 root     root         7791 Jun  4 13:39 test.C",
"-rwxr-xr-x   1 root     root        29202 Jun  4 15:26 test.bin",
"-rw-r-----   1 root     root         2715 May 30 22:20 test.h",
"-rw-r--r--   1 root     root        21768 Jun  4 15:26 test.o",
"-rw-r--r--   1 root     root          215 May 31 21:57 test2.C",
"-rw-r-----   1 root     root         1336 May 26 12:29 thread.C",
"-rw-r-----   1 root     root          645 May 26 12:29 thread.h",
"-rw-r--r--   1 root     root         2072 Jun  3 16:28 thread.o",
"-rw-r-----   1 root     root          889 May 28 17:45 timer.C",
"-rw-r-----   1 root     root          486 May 28 16:07 timer.h",
"-rw-r--r--   1 root     root         1476 Jun  3 16:27 timer.o",
"-rw-r-----   1 root     root         1822 May 26 12:29 units.C",
"-rw-r-----   1 root     root         2356 May 26 12:29 units.h",
"-rw-r--r--   1 root     root         2408 Jun  3 16:28 units.o",
"-rw-r--r--   1 root     root         7768 Jun  4 15:31 ~test.C"
	};
	
	
	subwindow->add_tool(new List_Box(subwindow, items, 40));

	subwindow->add_tool(new BC_Radial(150, 100, 15, 15, 1));
	subwindow->add_tool(new BC_CheckBox(170, 100, 15, 15, 1));
	subwindow->add_tool(new BC_RecordPatch(190, 100, 15, 15, 1));
	subwindow->add_tool(new BC_PlayPatch(210, 100, 15, 15, 1));
	subwindow->add_tool(new BC_Label(230, 100, 15, 15, 1));

	subwindow->add_tool(new BC_UpTriangleButton(150, 120, 25, 25));
	subwindow->add_tool(new BC_DownTriangleButton(180, 120, 25, 25));
	subwindow->add_tool(new BC_RecButton(210, 120, 25, 25));
	subwindow->add_tool(new BC_ForwardButton(240, 120, 25, 25));
	subwindow->add_tool(new BC_DuplexButton(280, 120, 48, 25));
	subwindow->add_tool(new BC_StopButton(330, 120, 25, 25));
	subwindow->add_tool(new BC_RewindButton(370, 120, 25, 25));
	subwindow->add_tool(new BC_EndButton(400, 120, 25, 25));

	int pan_positions[] = { 315, 0, 45, 135, 225 };


	subwindow->add_tool(new BC_Pan(500, 60, 30, 100, 1, 5, pan_positions, 0, 0));

	subwindow->add_tool(new BC_Title(150, 150, "Title"));
	subwindow->add_tool(new BC_Canvas(200, 150, 100, 100));
	subwindow->add_tool(new BC_IPot(200, 260, 30, 30, 0, 0, 100, PINK, RED));
	subwindow->add_tool(new BC_QPot(240, 260, 30, 30, 0, 0, 20000, DKGREY, BLACK));
	subwindow->add_tool(new BC_FPot(280, 260, 30, 30, 0, -15, 15, LTGREY, MEGREY));

printf("window->run()\n");
	window->run_window();
	
	delete window;
}

MainWindow::MainWindow(char *display) : BC_Window(display, MEGREY, "Test", 640, 400, 50, 50) {}

MainWindow::resize_event()
{
	printf("Resized\n");
}

MainWindow::keypress_event()
{
	printf("%d\n", get_keypress());
}

MainWindow::close_event()
{
	printf("Close Window\n");
}

SubWindow::SubWindow() : BC_SubWindow(10, 40, 620, 350, LTBLUE) { }
MenuSubWindow::MenuSubWindow() : BC_SubWindow(10, 10, 620, 30, GREEN) { }

New::New(int dummy) : BC_MenuItem("New", "Ctrl+N", 14) {}
New::handle_event()
{
	printf("New\n");
}

Load::Load(int dummy) : BC_MenuItem("Load", "Ctrl+O", 15) {}
Load::handle_event()
{
	BC_FileBox window("", "~", "Load File", "Select a file to load");
	window.run_window();
}

Save::Save(int dummy) : BC_MenuItem("Save", "Ctrl+S", 19) {}
Save::handle_event()
{
	printf("Save\n");
}

SaveAs::SaveAs(int dummy) : BC_MenuItem("Save as", "") {}
SaveAs::handle_event()
{
	printf("SaveAs\n");
}

Import::Import(int dummy) : BC_MenuItem("Import", "Ctrl+I", 9) {}
Import::handle_event()
{
	printf("Import\n");
}

Quit::Quit(int dummy) : BC_MenuItem("Quit", "Ctrl+Q", 17) {}
Quit::handle_event()
{
	printf("Quit\n");
	set_done(0);
}

Undo::Undo(int dummy) : BC_MenuItem("Undo", "Ctrl+Z", 26) {}
Undo::handle_event()
{
	printf("Undo\n");
}

LongMenuItem::LongMenuItem(int dummy) : BC_MenuItem("This is a long menu item", "", 0) {}
LongMenuItem::handle_event()
{
	printf("LongMenuItem\n");
}




ShowEdits::ShowEdits(int dummy) : BC_MenuItem("Show edits", "") {}
ShowEdits::handle_event()
{
	printf("ShowEdits\n");
	checked ^= 1;
}

ShowTitles::ShowTitles(int dummy) : BC_MenuItem("Show titles", "") {}
ShowTitles::handle_event()
{
	printf("ShowTitles\n");
	checked ^= 1;
}

MuteAutomation::MuteAutomation(int dummy) : BC_MenuItem("Mute automation", "") {}
MuteAutomation::handle_event()
{
	printf("Mute automation\n");
	checked ^= 1;
}

FadeAutomation::FadeAutomation(int dummy) : BC_MenuItem("Fade automation", "") {}
FadeAutomation::handle_event()
{
	printf("FadeAutomation\n");
	checked ^= 1;
}

PanAutomation::PanAutomation(int dummy) : BC_MenuItem("Pan automation", "") {}
PanAutomation::handle_event()
{
	printf("PanAutomation\n");
}

InverseAutomation::InverseAutomation(int dummy) : BC_MenuItem("Inverse automation", "") {}
InverseAutomation::handle_event()
{
	printf("InverseAutomation\n");
	checked ^= 1;
}

PanMenu::PanMenu(int dummy) : BC_SubMenu() {}

PanItem::PanItem(char *text) : BC_SubMenuItem(text) {}
PanItem::handle_event()
{
	printf("%s\n", text);
	checked ^= 1;
}

Text_Box::Text_Box(BC_SubWindow *subwindow, char *text)
 : BC_TextBox(200, 40, 100, text) {}

Text_Box::handle_event()
{
	printf("Text box changed to %s\n", get_text());
}

List_Box::List_Box(BC_SubWindow *subwindow, char **data, int totallines)
 : BC_ListBox(10, 40, 140, 200, data, totallines) {}

List_Box::handle_event()
{
	printf("Item selected: %s\n", get_selection());
}

List_Box::selection_changed()
{
	printf("Selection changed to: %s\n", get_selection());
}

OK_Button::OK_Button(BC_SubWindow *subwindow) : BC_BigButton(10, 10, "OK") { }

OK_Button::handle_event()
{
	printf("OK pressed\n");
}

Cancel_Button::Cancel_Button(BC_SubWindow *subwindow) : BC_BigButton(200, 10, "Cancel") {}

Cancel_Button::handle_event()
{
	printf("Cancel pressed\n");
}

Small_Button::Small_Button(BC_SubWindow *subwindow) : BC_SmallButton(100, 10, "Small") {}

Small_Button::handle_event()
{
	printf("Small pressed\n");
}

XScroll::XScroll(BC_SubWindow *subwindow) : BC_XScrollBar(0, 300, 600, 15, 1000, 0, 25) {}
	
XScroll::handle_event()
{
	printf("XScroll moved\n");
}

YScroll::YScroll(BC_SubWindow *subwindow) : BC_YScrollBar(600, 0, 15, 300, 1000, 0, 25) 
{
	printf("YScroll constructor\n");
}
	
YScroll::handle_event()
{
	printf("YScroll moved\n");
}




