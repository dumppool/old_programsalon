#ifndef TIMER_H
#define TIMER_H

#include <sys/time.h>


class Timer
{
public:
	Timer();
	virtual ~Timer();
	
	update();                // set last update to now
	
// get difference between now and last update
// must be positive or error results
	long get_difference(struct timeval *result);    

// get difference in arbitrary units between now and last update    
	long get_scaled_difference(long denominator);        
	delay(long milliseconds);
	
	struct timeval current_time;
};



#endif
