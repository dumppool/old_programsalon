#include "bcprogressbox.h"

BC_ProgressBox::BC_ProgressBox(char *display, char *text, long length, int cancel_button)
 : Thread(1)                    // create synchronous
{
//printf("BC_ProgressBox::BC_ProgressBox\n");
	pwindow = new BC_ProgressWindow(display, cancel_button);
	pwindow->create_objects(text, length);
	this->cancel_button = cancel_button;
}

BC_ProgressBox::~BC_ProgressBox()
{
	delete pwindow;
}

void BC_ProgressBox::run()
{
	pwindow->run_window();
}

BC_ProgressBox::update(long position)
{
	return pwindow->update(position);
}

BC_ProgressBox::update_title(char *title)
{
	pwindow->caption->update(title);
}

BC_ProgressBox::update_length(long length)
{
	pwindow->bar->update_length(length);
}


BC_ProgressBox::cancelled()
{
	return pwindow->cancelled;
}

BC_ProgressWindow::BC_ProgressWindow(char *display = "", int cancel_button)
 : BC_Window(display, MEGREY, "Progress", 340, 120, 340, 120)
{
	cancelled = 0;
	cancel = 0;
	this->cancel_button = cancel_button;
}

BC_ProgressWindow::~BC_ProgressWindow()
{
	if(cancel_button) delete cancel;
}

BC_ProgressWindow::create_objects(char *text, long length)
{
	this->text = text;
	add_tool(caption = new BC_Title(5, 5, text));
	add_tool(bar = new BC_ProgressBar(5, 35, 330, 30, length));
	if(cancel_button) add_tool(cancel = new BC_ProgressWindowCancelButton(this));
	else
	{
		add_tool(caption = new BC_Title(5, 75, "This process may not be interrupted.", LARGEFONT, RED));
	}
}

BC_ProgressWindow::update(long position)
{
	if(!cancelled)
	{
		lock_window();
		bar->update(position);
		unlock_window();
	}
	return cancelled;
}

BC_ProgressWindowCancelButton::BC_ProgressWindowCancelButton(BC_ProgressWindow *pwindow)
 : BC_BigButton(130, 80, "Cancel")
{ this->pwindow = pwindow; }

BC_ProgressWindowCancelButton::handle_event()
{
	pwindow->set_done(1);
	pwindow->cancelled = 1;
}

BC_ProgressWindowCancelButton::keypress_event()
{
	if(pwindow->get_keypress() == ESC) handle_event();
}
