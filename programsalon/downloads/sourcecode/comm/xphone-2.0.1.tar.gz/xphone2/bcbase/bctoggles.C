#include "bctitle.h"
#include "bctoggles.h"

BC_Toggle::BC_Toggle(int x_, int y_, int w_, int h_, int down_, char *text)
	: BC_Tool(x_, y_, w_, h_)
{
	down = down_;
	highlighted = 0;
	this->text = text;
}

BC_Toggle::create_tool_objects()
{
	create_window(x, y, w, h, MEGREY);
	if(text) subwindow->add_tool(new BC_Title(x + w + 5, y, text));
}

BC_Toggle::cursor_left_()
{
	if(highlighted)
	{
		if(cursor_x < 0 || cursor_x > w ||
			 cursor_y < 0 || cursor_y > h)
		{   // draw highlighted
			highlighted = 0;
			draw();
			return 0;
		}
	}
}

BC_Toggle::button_press_()
{
	if(  // subwindow test
		subwindow->cursor_x > x && subwindow->cursor_x < subwindow->w
		 && subwindow->cursor_y > y && subwindow->cursor_y < subwindow->h
		&& 	 // label test
		cursor_x > 0 && cursor_x < w
		 && cursor_y > 0 && cursor_y < h
		 )
	{
		activate();
		down ^= 1;
		draw();
		button_press();
		handle_event(); // status changed
	}
}

BC_Toggle::button_release_()
{
	button_release();      // user event
}

BC_Toggle::cursor_motion_()
{
	if(highlighted)
	{
		if(cursor_x < 0 || cursor_x > w
		  	|| cursor_y < 0 || cursor_y > h
		  )
		{
		  highlighted = 0;
			draw();
			return 0;
		}
	}
	else
	{
		if(cursor_x > 0 && cursor_x < w
		  	&& cursor_y > 0 && cursor_y < h
		  )
		{
		  highlighted = 1;
			draw();
			cursor_moved_over();    // user can recieve cursor motion over
			return 0;
		}
	}
}

BC_Toggle::resize(int x_, int y_, int w_, int h_, int down_)
{
	x = x_; y = y_; w = w_; h = h_;
	down = down_;
	resize_window(x, y, w, h);
}

BC_Toggle::resize_tool(int x, int y)
{
	resize_window(x, y, w, h);
	draw();
}

BC_Toggle::update(int down_)
{
	down = down_;
	draw();
}

BC_Toggle::get_value()
{
	return down;
}


BC_Radial::BC_Radial(int x_, int y_, int w_, int h_, int down, char *text)
	: BC_Toggle(x_, y_, w_, h_, down, text)
{
}

BC_Radial::create_tool_objects()
{
	create_window(x, y, w, h, subwindow->color);
	if(text) subwindow->add_tool(new BC_Title(x + w + 5, y, text));
	draw();
}

BC_Radial::draw()
{
	if(!down){
		if(highlighted)
  	set_color(LTGREY);
		else
  	set_color(MEGREY);
  	
  	XFillArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-2, 0*64, 360*64);
  	set_color(LTGREY);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-2, 45*64, 180*64);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 1, w-1, h-2, 45*64, 180*64);

  	set_color(DKGREY);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-2, 225*64, 180*64);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 1, w-1, h-2, 225*64, 180*64);
		set_color(BLACK);
	}else{
		if(highlighted)
  	set_color(PINK);
		else
  	set_color(RED);
  	
  	XFillArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-2, 0*64, 360*64);
  	set_color(DKGREY);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-2, 45*64, 180*64);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 1, w-1, h-2, 45*64, 180*64);

  	set_color(LTGREY);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-2, 225*64, 180*64);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 1, w-1, h-2, 225*64, 180*64);
		set_color(BLACK);
	}
	flash();
}

BC_CheckBox::BC_CheckBox(int x_, int y_, int w_, int h_, int down, char *text)
	: BC_Toggle(x_, y_, w_, h_, down, text)
{
}

BC_CheckBox::create_tool_objects()
{
	create_window(x, y, w, h, MEGREY);
	if(text) subwindow->add_tool(new BC_Title(x + w + 5, y, text));
	draw();
}

BC_CheckBox::draw()
{
	if(!down){
		if(highlighted)
		draw_3d_big(0, 0, w, h, WHITE, LTGREY, DKGREY);
		else
		draw_3d_big(0, 0, w, h, WHITE, MEGREY, DKGREY);
	}else{
		if(highlighted)
		draw_3d_big(0, 0, w, h, DKGREY, MEGREY, WHITE);
		else
		draw_3d_big(0, 0, w, h, DKGREY, MDGREY, WHITE);

		set_color(BLACK);
		draw_line(3, h/2+0, 6, h/2+2);
		draw_line(3, h/2+1, 6, h/2+3);
		draw_line(3, h/2+2, 6, h/2+4);
		draw_line(6, h/2+2, w - 4, h/2-3);
		draw_line(6, h/2+3, w - 4, h/2-2);
		draw_line(6, h/2+4, w - 4, h/2-1);
	}
	flash();
}

BC_RecordPatch::BC_RecordPatch(int x_, int y_, int w_, int h_, int down)
	: BC_Toggle(x_, y_, w_, h_, down)
{
}

BC_RecordPatch::create_tool_objects()
{
	create_window(x, y, w, h, subwindow->color);
	draw();
}

BC_RecordPatch::draw()
{
	if(!down){
		if(highlighted)
  		set_color(LTGREY);
		else
  		set_color(MEGREY);
  		
  	XFillArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-1, 0*64, 360*64);
  	set_color(WHITE);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-1, 45*64, 180*64);
  	set_color(DKGREY);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-1, 225*64, 180*64);
		set_color(BLACK);
	}else{
		if(highlighted)
  		set_color(PINK);
		else
  		set_color(RED);
  		
  	XFillArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-1, 0*64, 360*64);
  	set_color(DKGREY);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-1, 45*64, 180*64);
  	set_color(WHITE);
  	XDrawArc(top_level->display, pixmap, top_level->gc, 0, 0, w-1, h-1, 225*64, 180*64);
		set_color(BLACK);
	}
	flash();
}

BC_PlayPatch::BC_PlayPatch(int x_, int y_, int w_, int h_, int down)
	: BC_Toggle(x_, y_, w_, h_, down)
{
}

BC_PlayPatch::create_tool_objects()
{
	create_window(x, y, w, h, subwindow->color);
	draw();
}

BC_PlayPatch::draw()
{
  int x1, y1, x2, y2, x3, y3;
	XPoint point[3];

  y1 = 0;
  y2 = h / 2;
  y3 = h;
  x1 = 0;
  x2 = w;

  point[0].x = x1;
  point[0].y = y1;
  point[1].x = x2;
  point[1].y = y2;
  point[2].x = x1;
  point[2].y = y3;

  if(down)
  { 
    if(highlighted)
  	set_color(LTGREEN);
    else 
  	set_color(GREEN);
  }
  else 
  {
    if(highlighted)
    set_color(LTGREY);
    else 
    set_color(MEGREY);
  }
  XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);

  if(down) set_color(WHITE);
    else  set_color(DKGREY);
  draw_line(x2, y2, x1, y3);

  if(down) set_color(DKGREY);
    else  set_color(WHITE);

  draw_line(x1, y3, x1, y1);
  draw_line(x1, y1, x2, y2);
  flash();
}

// ================================= labels ================================

BC_Label::BC_Label(int x_, int y_, int w_, int h_, int down)
	: BC_Toggle(x_, y_, w_, h_, down)
{
	// draw();
	// x isn't set in the constructor
}

BC_Label::create_tool_objects()
{
	create_window(x, y, w, h, MDPURPLE);
	draw();
}

BC_Label::set_status(int down_)
{
	down = down_;
	draw();
}

BC_Label::draw()
{
/*********************** old diamond
	if(down)
	{
		if(highlighted)
		draw_3d_diamond(0, 0, w, h, DKPURPLE, MEPURPLE, LTPURPLE);
		else
		draw_3d_diamond(0, 0, w, h, DKPURPLE, MDPURPLE, LTPURPLE);
	}
	else
	{
		if(highlighted)
		draw_3d_diamond(0, 0, w, h, WHITE, LTPURPLE, DKPURPLE);
		else
		draw_3d_diamond(0, 0, w, h, LTPURPLE, MEPURPLE, DKPURPLE);
	}
*/
// new square
	if(down)
	{
		if(highlighted)
		draw_3d_big(0, 0, w, h, DKPURPLE, MEPURPLE, LTPURPLE);
		else
		draw_3d_big(0, 0, w, h, DKPURPLE, MDPURPLE, LTPURPLE);
	}
	else
	{
		if(highlighted)
		draw_3d_big(0, 0, w, h, WHITE, LTPURPLE, DKPURPLE);
		else
		draw_3d_big(0, 0, w, h, LTPURPLE, MEPURPLE, DKPURPLE);
	}
	flash();
}
