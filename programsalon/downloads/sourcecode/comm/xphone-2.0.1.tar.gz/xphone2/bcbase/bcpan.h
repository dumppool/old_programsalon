#ifndef BCVECTOR_H
#define BCVECTOR_H

class BC_Pan;

#include "bctool.h"


// pan  angles
//
//        360/0
//
//     270      90
//
//         180

class BC_Pan : public BC_Tool
{
public:
	BC_Pan(int x, int y, int r, int virtual_r, float maxvalue, int total_values, int *value_positions, int stick_x, int stick_y);
	BC_Pan(int x, int y, int r, int virtual_r, float maxvalue, int total_values, int *value_positions, float *values);
	virtual ~BC_Pan();
	
	initialize(int r, int virtual_r, float maxvalue, int total_values, int *value_positions);
	create_tool_objects();
	
	update(int x, int y);
	change_channels(int new_channels, int *value_positions);
	resize_tool(int x, int y);

	keypress_event_();
	cursor_left_();
	cursor_motion_();
	button_press_();
	button_release_();
	
	
// get x and y positions of channels
	get_channel_positions();
// update stick position from values
// only works for max and min values
	get_stick_position(int total_values, int *value_positions, float *values, float maxvalue, int virtual_r);
// update values from stick position
	get_values();

	draw();
	rdtoxy(int &x, int &y, int r, int a, int virtual_r);
	distance(int x1, int x2, int y1, int y2);

	int button_down;
	int highlighted;
	int total_values;
	int r;
	float maxvalue;
	int virtual_r;
	float scale;
	int x_adjust, y_adjust;
	int stick_x, stick_y;    // position of stick

	float *values;
	int *value_positions;       // degree measures of channels
	int *value_x, *value_y;     // virtual x and y positions

private:
	char string[64];
};







#endif
