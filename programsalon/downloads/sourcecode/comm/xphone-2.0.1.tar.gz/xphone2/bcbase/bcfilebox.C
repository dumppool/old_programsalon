#include "bcfilebox.h"

BC_FileBox::BC_FileBox(char *display, char *init_directory, char *title, char *caption, int show_all_files, int want_directory)
 : BC_Window(display, MEGREY, title, 320, 400, 0, 0)
{
	dir = new FileSystem(0);
// defeat non existant directories
	if(init_directory[0] == 0) sprintf(init_directory, "~");
	
	dir->complete_path(init_directory);

	dir->extract_dir(directory, init_directory);
	dir->extract_name(filename, init_directory);
	
	strcpy(this->caption, caption);
	if(show_all_files) dir->set_show_all();
	if(want_directory) dir->set_want_directory();
	dir->update(directory);

	this->want_directory = want_directory;
}

BC_FileBox::~BC_FileBox()
{
	delete dir;
	delete listbox;
	delete textbox;
	delete directory_title;
	delete ok;
	delete cancel;
	if(want_directory) delete usethis;
}

BC_FileBox::create_objects()
{
	add_tool(listbox = new BC_FileBoxListBox(this, dir->dir_list, dir->total_files));
	add_tool(new BC_Title(10, 5, caption));
	add_tool(ok = new BC_FileBoxOK(this));
	add_tool(cancel = new BC_FileBoxCancel(this));
	
	if(want_directory)
	{
		add_tool(textbox = new BC_FileBoxTextBox(this, directory));
		add_tool(usethis = new BC_FileBoxUseThis(this));
	}
	else
	add_tool(textbox = new BC_FileBoxTextBox(this, filename));
	
	add_tool(directory_title = new BC_FileBoxDirectory(this, directory));
	listbox->activate();
}


BC_FileBox::ok_event()
{
	set_done(0);
}


BC_FileBox::cancel_event()
{
	set_done(1);
}

char* BC_FileBox::get_directory()
{
	return directory;
}

char* BC_FileBox::get_filename()
{
	return filename;
}

BC_FileBox::set_show_all()
{
	dir->set_show_all();
	dir->update(directory);
}

BC_FileBox::submit_file(char *text)
{
	if(!dir->is_dir(text))
	{            // is a directory, change directories
		dir->change_dir(text);     // change to it
		listbox->set_contents(dir->dir_list, dir->total_files);
		directory_title->update(dir->current_dir);

		if(dir->current_dir[0]) strcpy(directory, dir->current_dir);
		if(want_directory) textbox->update(dir->current_dir);
		else textbox->update("");

		listbox->reset_query();
		return 1;
	}
	else
	{            // not a directory, quit now
		if(text[0]) dir->extract_dir(directory, text);     // directory is saved in directory for default updating
		dir->complete_path(text);
		strcpy(filename, text);          // save complete path in filename
		return 0;
	}
}

BC_FileBoxOK::BC_FileBoxOK(BC_FileBox *filebox)
 : BC_BigButton(10, 370, "OK")
{ this->filebox = filebox; }

BC_FileBoxOK::handle_event()
{
	int result = 0;
	if(!filebox->submit_file(filebox->textbox->text) && strlen(filebox->textbox->text))
	{
		result = 1;
	}
	
	if(result && !filebox->want_directory)
	{
		filebox->ok_event();
		filebox->set_done(0);
	}
}

BC_FileBoxOK::keypress_event()
{
	if(get_keypress() == 13) handle_event();
}








BC_FileBoxUseThis::BC_FileBoxUseThis(BC_FileBox *filebox)
 : BC_BigButton(100, 370, "Use This")
{ this->filebox = filebox; }

BC_FileBoxUseThis::handle_event()
{
	if(filebox->submit_file(filebox->textbox->text) && strlen(filebox->textbox->text))
	{
		filebox->ok_event();
		set_done(0);
	}
}






BC_FileBoxCancel::BC_FileBoxCancel(BC_FileBox *filebox) 
 : BC_BigButton(200, 370, "Cancel")
{ this->filebox = filebox; }

BC_FileBoxCancel::handle_event()
{
// get it saved for default updates
	filebox->submit_file(filebox->textbox->text) && strlen(filebox->textbox->text);
	filebox->cancel_event();
	set_done(1);
}

BC_FileBoxCancel::keypress_event()
{
	if(top_level->get_keypress() == ESC) handle_event();
}

BC_FileBoxTextBox::BC_FileBoxTextBox(BC_FileBox *filebox, char *text)
 : BC_TextBox(10, 340, 300, text)
{ this->filebox = filebox; }

BC_FileBoxTextBox::handle_event()
{
}

BC_FileBoxDirectory::BC_FileBoxDirectory(BC_FileBox *filebox, char *text)
 : BC_Title(10, 300, filebox->directory)
{
}

BC_FileBoxListBox::BC_FileBoxListBox(BC_FileBox *filebox, char **dir_list, int total_files)
 : BC_ListBox(10, 30, 300, 250, dir_list, total_files, 0, 0)
{ this->filebox = filebox; }

BC_FileBoxListBox::~BC_FileBoxListBox() {}

BC_FileBoxListBox::handle_event()
{
	if(get_keypress() == ESC)
	{
		filebox->cancel_event();
		set_done(1);
	}
	else
	{
		char string[1024];
		int result = 0;
		
		get_selection(string);

		if(filebox->want_directory)
		{
			if(filebox->submit_file(string)) result = 0;
		}
		else
		{
			if(!filebox->submit_file(string)) result = 1;
		}
		
		if(result)
		{
			filebox->ok_event();
			set_done(0);
		}
	}
}

BC_FileBoxListBox::selection_changed()
{
	char string[1024];
	get_selection(string);
	filebox->textbox->update(string);
}
