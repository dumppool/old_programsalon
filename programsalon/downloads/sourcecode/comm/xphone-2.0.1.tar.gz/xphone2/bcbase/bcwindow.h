#ifndef BCWINDOW_H
#define BCWINDOW_H

class BC_Window;
class BC_MenuBar;
class BC_PopupMenu;

#include "bcwindowbase.h"
#include "timer.h"
#include "vframe.h"

// ================================= top level windows only

class BC_Window : public BC_WindowBase
{
public:
	BC_Window() {};           // broken compiler

// build a standalone window
	BC_Window(char *display_name, 
						int color, 
						char *title, 
						int w, int h, 
						int minw, int minh, 
						int private_color = 0, 
						int hide = 0);
	
	virtual ~BC_Window();

// =============================== initialization

// need routines here to set top_level
	BC_Tool* add_tool(BC_Tool *tool);                     // add a lowest level component
	add_border(int light, int medium, int dark);         // add a border to this window
	BC_SubWindow* add_subwindow(BC_SubWindow* subwindow);         // add a subwindow object

	run_window();            // run event handler
	hide_window();           // hide window
	show_window();           // show window
	lock_window();           // lock the window from events
	unlock_window();         // unlock the window from events
	
	set_done(int return_value);                    // quit the window event dispatcher
	set_repeat(long duration = 50000);             // signal the event handler to send a repeat after this duration
	unset_repeat();                                // tell event handler to stop sending repeats
	set_title(char *title);                        // set the title of this standalone window
	shift_down();                                  // flags for certain keys
	ctrl_down();


// ================================= clipboard

	to_clipboard(char *data);                  // send data to the global clipboard
	clipboard_len();                           // get length of clipboard data
	from_clipboard(char *data);                // get data from the global clipboard
	
// ================================= user declared event handlers

	virtual keypress_event() {};       // handle a key press
	virtual close_event() {};        // close box pressed




// ================================== event dispatchers

	dispatch_event();        // send event to all subwindows until trapped
	store_motion_event(XEvent *report);    // arm the motion buffer with the current event
	dispatch_motion_event_main();           // master motion event dispatcher translates motion history
	window_reset();                    // flush all the events in the queue
	cycle_textboxes();                 // activate the next textbox in the window


// color table
// 8 bit is rrgggbbb
// 16 bit is rrrrrggggggbbbbb
	init_fonts();
	init_colors();
	get_color(long color);          // return the colormap pixel of the color for all bit depths
	get_color_8(int color);         // get the pixel value for the color for 8 bit
	long get_color_16(int color);   // get the pixel value for the color for 16 bit
	allocate_color_table();         // install the color table in the X server
	create_private_colors();        // create a table containing 255 colors including the necessary colors
	create_shared_colors();         // create a table containing only the necessary colors
	create_color(int color);    // add the color to the table or replace the closest match with the color
	int color_table[256][2];    // table for every color allocated
	int private_color;          // use installed colormap
	int total_colors;           // number of colors in color table
	int current_color_value, current_color_pixel;// last color found in table

	Display* display;
	int screen;
	Window rootwin;
 	Window event_win;       // window the last event happened in
	Colormap cmap;
	GC gc;
	int depth;
	XFontStruct *titlefont, *largefont, *smallfont;      // fonts used by everyone
	Visual *vis;
	Atom DelWinXAtom;
	Atom ProtoXAtom;

// masks for event queries
	int ctrl_mask, shift_mask, key_pressed, button_pressed, key_sym, resized;
// some window managers send the same configure event over and over and over again
// which breaks some routines for flipping vertical
	int last_w, last_h;
	int done;
	int hidden;
	int button_just_released;
	unsigned long button_time1, button_time2;
	int double_click;
	int button_down;
	int cursorleft;
	int return_value;

// information for repeating

	int repeat_buffer;    // 1 if a repeat was skipped for events
	struct timeval current_repeat;
	struct timeval delay_duration;
	Timer repeat_timer;	
	long repeat;             // usec until next repeat

// motion history buffer

	int motion_buffer;       // motion event in buffer
	int motion_buffer_x, motion_buffer_y;      // coordinates of buffered motion
	Window motion_buffer_win;       // window of buffered motion

// window can get destroyed after the button release and the last motion notify events in it

	Window last_deleted_window;       // store most recent deleted window
	set_last_deleted(Window win);

	BC_Tool* active_tool;            // pointer to the active tool in this window
	BC_MenuBar* active_menubar;      // pointer to the active menubar in the window
	BC_PopupMenu* active_popup_menu;    // pointer to the active popup menu in the window
};

#endif
