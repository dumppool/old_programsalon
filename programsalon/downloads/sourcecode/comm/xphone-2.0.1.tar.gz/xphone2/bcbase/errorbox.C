#include "errorbox.h"

ErrorBox::ErrorBox(char *display = "")
 : BC_Window(display, MEGREY, "2000: FYI", 340, 140, 340, 140)
{
}

ErrorBox::~ErrorBox()
{
	delete ok;
}

ErrorBox::create_objects(char *text1, char *text2, char *text3, char *text4)
{
	BC_SubWindow *subwindow;
	add_subwindow(subwindow = new BC_SubWindow(0, 0, w, h, MEGREY));
	
	subwindow->add_tool(new BC_Title(5, 5, text1));
	if(text2) subwindow->add_tool(new BC_Title(5, 25, text2));
	if(text3) subwindow->add_tool(new BC_Title(5, 45, text3));
	if(text4) subwindow->add_tool(new BC_Title(5, 65, text4));
	subwindow->add_tool(ok = new ErrorBoxOkButton(this));
}

ErrorBoxOkButton::ErrorBoxOkButton(ErrorBox *errorbox)
 : BC_BigButton(50, 80, "OK")
{ this->errorbox = errorbox; }

ErrorBoxOkButton::handle_event()
{
	errorbox->set_done(0);
}

ErrorBoxOkButton::keypress_event()
{
	if(errorbox->get_keypress() == 13 ||
		errorbox->get_keypress() == ESC) handle_event();
}
