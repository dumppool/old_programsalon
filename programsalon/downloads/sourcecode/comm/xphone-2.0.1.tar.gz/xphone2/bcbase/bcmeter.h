#ifndef BCMETER_H
#define BCMETER_H

class BC_Meter;

#define METER_DB 0
#define METER_INT 1


#include "bccolors.h"
#include "bctool.h"
#include "units.h"

class BC_Meter : public BC_Tool
{
public:
	BC_Meter(int x_, int y_, int w_, int h_, float min = -80, int mode = METER_DB);
	virtual ~BC_Meter();
	create_tool_objects();
	init_graphics();
	
	draw();
	update(float new_value, int over);
	resize_tool(int x, int y, int w, int h);
	reset();
	reset_over();
	get_divisions(int *low_division, 
			  int *medium_division,
			  int total_width, 
			  char **titles, 
			  int *title_x, 
			  int vertical);
	change_format(int mode);
	
	
	float peak;
	int peak_timer;
	int peak_x, level_x, peak_x1, peak_x2;
	int over_count, over_timer;
	int total_width, vertical;
	int low_division;
	int medium_division;
	const long low_color = GREEN;
	const long medium_color = MEYELLOW;
	const long high_color = RED;
	DB db;
	int title_x[6];
	char *db_titles[6];
	float min;
	int mode;
};

#endif
