#ifndef TEST_H
#define TEST_H

#include "bcbase.h"
#include "bclistbox.h"
#include "bcmenubar.h"

class MainWindow : public BC_Window
{
public:
	MainWindow(char *display);  // parameter required for inheritance to work
	
	close_event();
	resize_event();
	keypress_event();
};

class SubWindow : public BC_SubWindow
{
public:
	SubWindow();  // parameter required for inheritance to work
};

class MenuSubWindow : public BC_SubWindow
{
public:
	MenuSubWindow();
};

class New : public BC_MenuItem
{
public:
	New(int dummy);
	handle_event();
};

class Load : public BC_MenuItem
{
public:
	Load(int dummy);
	handle_event();
};

class Save : public BC_MenuItem
{
public:
	Save(int dummy);
	handle_event();
};

class SaveAs : public BC_MenuItem
{
public:
	SaveAs(int dummy);
	handle_event();
};

class Import : public BC_MenuItem
{
public:
	Import(int dummy);
	handle_event();
};

class Quit : public BC_MenuItem
{
public:
	Quit(int dummy);
	handle_event();
};

class Undo : public BC_MenuItem
{
public:
	Undo(int dummy);
	handle_event();
};

class LongMenuItem : public BC_MenuItem
{
public:
	LongMenuItem(int dummy);
	handle_event();
};


class ShowEdits : public BC_MenuItem
{
public:
	ShowEdits(int dummy);
	handle_event();
};

class ShowTitles : public BC_MenuItem
{
public:
	ShowTitles(int dummy);
	handle_event();
};

class MuteAutomation : public BC_MenuItem
{
public:
	MuteAutomation(int dummy);
	handle_event();
};

class FadeAutomation : public BC_MenuItem
{
public:
	FadeAutomation(int dummy);
	handle_event();
};

class PanAutomation : public BC_MenuItem
{
public:
	PanAutomation(int dummy);
	handle_event();
};

class InverseAutomation : public BC_MenuItem
{
public:
	InverseAutomation(int dummy);
	handle_event();
};

class PanMenu : public BC_SubMenu
{
public:
	PanMenu(int dummy);
};

class PanItem : public BC_SubMenuItem
{
public:
	PanItem(char *text);
	handle_event();
};

class List_Box : public BC_ListBox
{
public:
	List_Box(BC_SubWindow *subwindow, char **data, int totallines);
	
	handle_event();
	selection_changed();
};

class Text_Box : public BC_TextBox
{
public:
	Text_Box(BC_SubWindow *subwindow, char *text);
	
	handle_event();
};

class OK_Button : public BC_BigButton
{
public:
	OK_Button(BC_SubWindow *subwindow);
	
	handle_event();
};

class Cancel_Button : public BC_BigButton
{
public:
	Cancel_Button(BC_SubWindow *subwindow);
	
	handle_event();
};

class Small_Button : public BC_SmallButton
{
public:
	Small_Button(BC_SubWindow *subwindow);
	
	handle_event();
};

class XScroll : public BC_XScrollBar
{
public:
	XScroll(BC_SubWindow *subwindow);
	
	handle_event();
};

class YScroll : public BC_YScrollBar
{
public:
	YScroll(BC_SubWindow *subwindow);
	
	handle_event();
};

#endif
