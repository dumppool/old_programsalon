#ifndef ERRORBOX_H
#define ERRORBOX_H

#include "bcbase.h"

class ErrorBoxOkButton;


class ErrorBox : public BC_Window
{
public:
	ErrorBox(char *display = "");
	virtual ~ErrorBox();
	
	create_objects(char *text1, char *text2 = 0, char *text3 = 0, char *text4 = 0);
	ErrorBoxOkButton *ok;
};

class ErrorBoxOkButton : public BC_BigButton
{
public:
	ErrorBoxOkButton(ErrorBox *errorbox);
	
	handle_event();
	keypress_event();
	
	ErrorBox *errorbox;
};

#endif

