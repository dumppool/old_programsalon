#ifndef DIRECTORY_H
#define DIRECTORY_H

class FileSystem
{
public:
	FileSystem(int need_home = 1);      // sets the working directory to the user
	virtual ~FileSystem();
	
	move_up();
	set_filter(char *new_filter);
	set_show_all();     // show hidden files
	set_want_directory();
	update(char *new_dir);     // load the new directory, filtering using filter
	is_dir(char *new_dir_);     // return 0 if the text is a directory
	create_dir(char *new_dir_);    // create a new directory
	change_dir(char *new_dir_); // change to the directory in the string
	complete_path(char *filename);   // use the filename and the current_dir to create a complete filename
	extract_dir(char *out, char *in); // extract the directory from the filename
	extract_name(char *out, char *in);
	join_names(char *out, char *dir_in, char *name_in);    // combine a directory and filename
	long get_date(char *filename);        // get the date of the filename modification
	add_end_slash(char *new_dir);
	sort();

	parse_tildas(char *new_dir);     // expand tildas
	parse_dots(char *new_dir);         // move up directory tree after expanding tildas
	compare(const char *c1, const char *c2);
	
	char current_dir[1024];
	char *dir_list[1000];
	int total_files;
	int show_all_files;       // shows . files
	int want_directory;
	char filter[1024];     // what filenames have to end in to get displayed
};

#endif
