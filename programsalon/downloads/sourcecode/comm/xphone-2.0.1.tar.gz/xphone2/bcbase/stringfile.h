#ifndef STRINGFILE_H
#define STRINGFILE_H

// use for extracting databases
#include "units.h"

class StringFile
{
public:
	StringFile(long length = 0);
	StringFile(char *filename);
	virtual ~StringFile();
	
	readline();   // read next line from string
	readline(char *arg2);   // read next line from string
	readline(long *arg2);   // read next line from string
	readline(int *arg2);   // read next line from string
	readline(float *arg2);   // read next line from string
	readline(Freq *arg2);   // read next line from string
	
	readline(char *arg1, char *arg2);   // read next line from string
	readline(char *arg1, long *arg2);   // read next line from string
	readline(char *arg1, int *arg2);   // read next line from string
	readline(char *arg1, float *arg2);   // read next line from string
	writeline(char *arg1, int indent);   // write next line to string
	writeline(char *arg1, char *arg2, int indent);   // write next line to string
	writeline(char *arg1, long arg2, int indent);   // write next line to string
	writeline(char *arg1, int arg2, int indent);   // write next line to string
	writeline(char *arg1, float arg2, int indent);   // write next line to string
	writeline(char *arg1, Freq arg2, int indent);   // write next line to string
	backupline();       // move back one line

	long get_length();
	long get_pointer();
	write_to_file(char *filename);
	read_from_string(char *string);
	
	char *string;
	long pointer, length, available;
	char string1[1024];      // general purpose strings
};

#endif
