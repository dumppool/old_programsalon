#ifndef BCFONT_H
#define BCFONT_H


// macros used for font calls

#define LARGEFONT 0            // font for everything
#define SMALLFONT 1            // smallest readable font
#define TITLEFONT 2            // large font for titles

#endif
