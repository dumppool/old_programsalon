#include "bcscrollbar.h"
#include <sys/timeb.h>

BC_ScrollBar::BC_ScrollBar(int x_, int y_, int w_, int h_, long length_, long position_, long handlelength_)
	: BC_Tool(x_, y_, w_, h_)
{
	buttondown = backarrow = forwardarrow = box = backpage = forwardpage = 0;
	backhi = forwardhi = boxhi = 0;
	length = length_;
	position = position_;
	distance = 0;
	handlelength = handlelength_;
	init_repeat = 500000;
	sustain_repeat = 50000;
	next_repeat = sustain_repeat;
}

BC_ScrollBar::create_tool_objects()
{
	create_window(x, y, w, h, MDGREY);
	draw();
}

BC_ScrollBar::resize(int x_, int y_, int w_, int h_, long length_, long position_, long handlelength_)
{
	x = x_; y = y_; w = w_; h = h_;
	length = length_;
	position = position_;
	handlelength = handlelength_;
	resize_window(x, y, w, h);
	//draw();
}

BC_ScrollBar::resize(int w, int h)
{
	//draw();	
}

BC_ScrollBar::button_release_()
{
	if(buttondown){
		buttondown = backarrow = forwardarrow = box = backpage = forwardpage = 0;
		test_highlight();
		draw();
		unset_repeat();
	}
}

BC_ScrollBar::set_size(int x_, int y_, int w_, int h_)
{
	x = x_; y = y_; w = w_; h = h_;
	resize_window(x, y, w, h);

	draw();
}

BC_ScrollBar::set_position(long length_, long position_, long handlelength_)
{
	length = length_;
	position = position_;
	handlelength = handlelength_;
	draw();
}

BC_ScrollBar::get_positions(int boxlength)
{
  if(length > handlelength)
  {
		handlew = (int)((float)boxlength / length * handlelength) + 2;
		if(handlew < 10)
		{          // length too small
			int boxlength_;   // imaginary boxlength
			
			handlew = 10;   // force length
			boxlength_ = boxlength - handlew;    // fake boxlength and actual length
    	handlex = (int)((float)boxlength_ / (length - handlelength) * position);
		}
		else
		{
    	handlex = (int)((float)boxlength / length * position);
    }
	}
	else
	{  // fill entire scrollbar with handle
    	handlex = 0;
    	handlew = boxlength;
	}
	
	if(handlex < 0) handlex = 0;
	if(handlex > boxlength)
	{
		handlex = 0; handlew = boxlength;  // give up if beyond end
	}
	else
	if(handlew + handlex > boxlength) handlew = boxlength - handlex;
}

long BC_ScrollBar::get_position()
{
	return position;
}

long BC_ScrollBar::get_distance() { return distance; }       // old position of scrollbar

BC_ScrollBar::in_use()
{
	if(backarrow || forwardarrow || box || backpage || forwardpage) return 1;
	else
	return 0;
}

BC_ScrollBar::repeat_()         // need repeat routine since most events are Expose
{
	if(handle_arrows()) 
	{
		handle_event();
		return 1;
	}
	return 0;
}


BC_ScrollBar::handle_arrows()
{
	long oldposition;
	int result = 0;
	distance = 0;
	
  if(backarrow)
  {
  	top_level->set_repeat(next_repeat);
    oldposition = position;
    if(handlelength < 100) position -= 1; // for list boxes
    else position -= handlelength / 10;
    if(position < 0) position = 0;
    if(oldposition != position){ draw(); result = 1; distance = position - oldposition; }
    else result = 0;
  }
  else if(forwardarrow)
  {
  	top_level->set_repeat(next_repeat);

    oldposition = position;
    if(handlelength < 100) position += 1; // for list boxes
    else position += handlelength / 10;
    if(position > length - handlelength) position = length - handlelength;
    if(position < 0) position = 0; // the handlelength may be longer than the list
    if(oldposition != position){ draw(); result = 1; distance = position - oldposition; }
    else result = 0;
  }
  else if(backpage)
  {
  	top_level->set_repeat(next_repeat);

    oldposition = position;
    position -= handlelength;
    if(position < 0) position = 0;
    if(oldposition != position){ draw(); result = 1; distance = position - oldposition; }
    else result = 0;
  }
  else if(forwardpage)
  {
  	top_level->set_repeat(next_repeat);

    oldposition = position;
    position += handlelength;
    if(position > length - handlelength) position = length - handlelength;
    if(oldposition != position){ draw(); result = 1; distance = position - oldposition; }
    else result = 0;
  }
	next_repeat = sustain_repeat;
  return result;
}

//================================ x scrollbar=======================

BC_XScrollBar::BC_XScrollBar(int x_, int y_, int w_, int h_, long length_, long position_, long handlelength_)
	: BC_ScrollBar(x_, y_, w_, h_, length_, position_, handlelength_)
{
}

BC_XScrollBar::test_highlight()
{
	if(!enabled) return 0;
	if(boxhi)
	{
		if(subwindow->cursor_y < y || subwindow->cursor_y > y + h ||
			 subwindow->cursor_x < handlex + x + h || subwindow->cursor_x > handlex + x + h + handlew)
		{
			boxhi = 0;
			draw();
		}
	}
	else if(backhi)
	{
		if(subwindow->cursor_y < y || subwindow->cursor_y > y + h ||
			 subwindow->cursor_x < x || subwindow->cursor_x > x + h)
		{
			backhi = 0;
			draw();
		}
	}
	else if(forwardhi)
	{
		if(subwindow->cursor_y < y || subwindow->cursor_y > y + h ||
			 subwindow->cursor_x < x + w - h || subwindow->cursor_x > x + w)
		{
			forwardhi = 0;
			draw();
		}
	}
	else
	{
		if(subwindow->cursor_y > y && subwindow->cursor_y < y + h)
		{
			if(subwindow->cursor_x > handlex + x + h && subwindow->cursor_x < handlex + x + h + handlew)
			{
				boxhi = 1;
				draw();
			}
			else if(subwindow->cursor_x > x && subwindow->cursor_x < x + h)
			{
				backhi = 1;
				draw();
			}
			else if(subwindow->cursor_x > x + w - h && subwindow->cursor_x < x + w)
			{
				forwardhi = 1;
				draw();
			}
		}
	}		
}

BC_XScrollBar::cursor_left_()
{
// highlighting
	if(!buttondown && !backarrow && !forwardarrow && !box && !backpage && !forwardpage)
	{
		if(cursor_x < 0 || cursor_x > w || cursor_y < 0 || cursor_y > h)
		test_highlight();
	}
}

BC_XScrollBar::button_press_()
{
//printf("BC_XScrollBar::button_press_\n");
	next_repeat = init_repeat;
	if(!top_level->repeat) 
	{
		if(cursor_y > 0 && cursor_y < h && cursor_x > 0 && cursor_x < w)
		{
			buttondown = 1;
    	if(cursor_x < h){
    		set_repeat(init_repeat);
      	backarrow = 1;
      	draw();
    	}else
    	if(cursor_x > w - h){
    		set_repeat(init_repeat);
      	forwardarrow = 1;
      	draw();
    	}else
    	if(cursor_x > h && cursor_x < w - h) // between pointers
    	{
      	get_positions(w - h * 2);

      	if(cursor_x < handlex + h) 
      	{
     			set_repeat(init_repeat);
     			backpage = 1;
      	}
      	else
      	if(cursor_x > handlex + h + handlew) 
      	{
     			set_repeat(init_repeat);
     			forwardpage = 1;
      	}
      	else
      	{
        	oldx = cursor_x;
        	relativex = (int)(position / ((float)length / (w - h * 2)));
        	box = 1;
        	draw();
      	}
    	}
  	}
	}
  if(handle_arrows()) handle_event();
}

BC_XScrollBar::cursor_motion_()
{
	result = 0;
	distance = 0;
	if(!buttondown && !backarrow && !forwardarrow && !box && !backpage && !forwardpage)
	{
		test_highlight();
	}

	if(box)
	{
  	oldposition = position;

  	relativex += cursor_x - oldx;
  	oldx = cursor_x;

  	position = (long)((float)length / (w - h * 2) * relativex);

  	if(position < 0) position = 0;
  	if(position > length - handlelength)
    	position = length - handlelength;
  	if(position < 0) position = 0;
  	if(oldposition != position){ draw(); result = 1; distance = position - oldposition; }
  	else result = 0;
	}
	if(result) handle_event();
}

BC_XScrollBar::draw()
{
	if(w < h * 2 + 5)
	{            // too small
		draw_3d_big(0, 0, w, h, LTGREY, MEGREY, DKGREY);
	}
	else
	{
  	int x1, y1, x2, y2, x3, y3;
		XPoint point[3];

		// background box
		draw_3d_big(0, 0, w, h, DKGREY, MDGREY, LTGREY);

		// draw back arrow
  	y1 = 2;
  	x1 = 2;
  	y2 = h / 2;
  	x2 = h - 1;
  	y3 = h - 3;

  	point[0].x = x1;
  	point[0].y = y2;
  	point[1].x = x2;
  	point[1].y = y1;
  	point[2].x = x2;
  	point[2].y = y3;

  	if(backarrow) set_color(MDGREY);
    else  
		if(backhi)
		set_color(LTGREY);
		else
		set_color(MEGREY);
  	XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);

  	if(backarrow) set_color(WHITE);
    	else  set_color(DKGREY);
  	draw_line(x2-1, y1, x2-1, y3);
  	draw_line(x2, y1, x2, y3);
  	draw_line(x2-1, y3, x1, y2);
  	draw_line(x2, y3, x1+1, y2);

  	if(backarrow) set_color(DKGREY);
    	else  set_color(WHITE);
  	draw_line(x1, y2, x2-1, y1);
  	draw_line(x1+1, y2, x2, y1);

		// forward arrow

  	x1 = w - h + 1;
  	x2 = w - 3;

  	point[0].x = x1;
  	point[0].y = y1;
  	point[1].x = x2;
  	point[1].y = y2;
  	point[2].x = x1;
  	point[2].y = y3;

  	if(forwardarrow) set_color(MDGREY);
    else  
		if(forwardhi)
		set_color(LTGREY);
		else
		set_color(MEGREY);
  	XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);

  	if(forwardarrow) set_color(WHITE);
    	else  set_color(DKGREY);
  	draw_line(x2-1, y2, x1, y3);
  	draw_line(x2, y2, x1+1, y3);

  	if(forwardarrow) set_color(DKGREY);
    	else  set_color(WHITE);
  	draw_line(x1-1, y3, x1-1, y1);
  	draw_line(x1, y3, x1, y1);
  	draw_line(x1, y1, x2-1, y2);
  	draw_line(x1+1, y1, x2, y2);

		get_positions(w - h * 2);
		if(box)
		{
			draw_3d_big(handlex + h, 2, handlew, h - 4, DKGREY, MDGREY, LTGREY);
		}
		else
		{
			if(boxhi)
  		draw_3d_big(handlex + h, 2, handlew, h - 4, WHITE, LTGREY, DKGREY);
			else
  		draw_3d_big(handlex + h, 2, handlew, h - 4, LTGREY, MEGREY, DKGREY);
  	}
	}
	
	flash();
}

//================================ y scrollbar=======================
BC_YScrollBar::BC_YScrollBar(int x_, int y_, int w_, int h_, long length_, long position_, long handlelength_)
	: BC_ScrollBar(x_, y_, w_, h_, length_, position_, handlelength_)
{
}

BC_YScrollBar::test_highlight()
{
	if(!enabled) return 0;
	if(boxhi)
	{
		if(subwindow->cursor_x < x || subwindow->cursor_x > x + w ||
			 subwindow->cursor_y < handlex + y + w || subwindow->cursor_y > handlex + y + w + handlew)
		{
			boxhi = 0;
			draw();
		}
	}
	else if(backhi)
	{
		if(subwindow->cursor_x < x || subwindow->cursor_x > x + w ||
			 subwindow->cursor_y < y || subwindow->cursor_y > y + w)
		{
			backhi = 0;
			draw();
		}
	}
	else if(forwardhi)
	{
		if(subwindow->cursor_x < x || subwindow->cursor_x > x + w ||
			 subwindow->cursor_y < y + h - w || subwindow->cursor_y > y + h)
		{
			forwardhi = 0;
			draw();
		}
	}
	else
	{
		if(subwindow->cursor_x > x && subwindow->cursor_x < x + w)
		{
			if(subwindow->cursor_y > handlex + y + w && subwindow->cursor_y < handlex + y + w + handlew)
			{
				boxhi = 1;
				draw();
			}
			else if(subwindow->cursor_y > y && subwindow->cursor_y < y + w)
			{
				backhi = 1;
				draw();
			}
			else if(subwindow->cursor_y > y + h - w && subwindow->cursor_y < y + h)
			{
				forwardhi = 1;
				draw();
			}
		}
	}		
}

BC_YScrollBar::cursor_left_()
{
// highlighting
	if(!buttondown && !backarrow && !forwardarrow && !box && !backpage && !forwardpage)
	{
		if(cursor_x < 0 || cursor_x > w || cursor_y < 0 || cursor_y > h)
		test_highlight();
	}
}

BC_YScrollBar::button_press_()
{
	next_repeat = init_repeat;
	if(!top_level->repeat) 
	{
		if(cursor_y > 0 && cursor_y < h && cursor_x > 0 && cursor_x < w)
		{
			buttondown = 1;
    	if(cursor_y < w){ set_repeat(init_repeat); backarrow = 1; draw(); }
    	else
    	if(cursor_y > h - w){ set_repeat(init_repeat); forwardarrow = 1; draw(); }
    	else
    	if(cursor_y > w && cursor_y < h - w) // between pointers
    	{
      	get_positions(h - w * 2);

      	if(cursor_y < handlex + w) { set_repeat(init_repeat); backpage = 1; }
      	else
      	if(cursor_y > handlex + w + handlew) { set_repeat(init_repeat); forwardpage = 1; }
      	else
      	{
        	oldy = cursor_y;
        	relativey = (int)(position / ((float)length / (h - w * 2)));
        	box = 1;
        	draw();
      	}
    	}
  	}
  }
// handle first repeat
  if(handle_arrows()) handle_event();
}

BC_YScrollBar::cursor_motion_()
{
// highlighting
	result = 0;
	distance = 0;
	if(!buttondown && !backarrow && !forwardarrow && !box && !backpage && !forwardpage)
	{
		test_highlight();
	}

  if(box)
  {
    oldposition = position;

    relativey += cursor_y - oldy;
    oldy = cursor_y;

    position = (long)((float)length / (h - w * 2) * relativey);

    if(position < 0) position = 0;
    if(position > length - handlelength)
      position = length - handlelength;
    if(position < 0) position = 0;
    if(oldposition != position){ draw(); result = 1; distance = position - oldposition; }
    else result = 0;
  }
  if(result) handle_event();
}



BC_YScrollBar::draw()
{
 	if(h < w * 2 + 5)
	{            // too small
		draw_3d_big(0, 0, w, h, LTGREY, MEGREY, DKGREY);
	}
	else
	{
 		int x1, y1, x2, y2, x3, y3;
  		XPoint point[3];

		// background box
		draw_3d_big(0, 0, w, h, DKGREY, MDGREY, LTGREY);

		// draw back arrow
  		x1 = 2;
  		y1 = 2;
  		x2 = w / 2;
  		y2 = w - 1;
  		x3 = w - 3;

  		point[0].x = x2;
  		point[0].y = y1;
  		point[1].x = x3;
  		point[1].y = y2;
  		point[2].x = x1;
  		point[2].y = y2;

  		if(backarrow) set_color(MDGREY);
    	else 
    	if(backhi)
    	set_color(LTGREY);
    	else
    	set_color(MEGREY);
  		XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);

  		if(backarrow) set_color(WHITE);
    		else  set_color(DKGREY);
  		draw_line(x2, y1, x3, y2-1);
  		draw_line(x2, y1+1, x3, y2);
  		draw_line(x3, y2-1, x1, y2-1);
  		draw_line(x3, y2, x1, y2);

  		if(backarrow) set_color(DKGREY);
    		else  set_color(WHITE);
  		draw_line(x2, y1, x1, y2-1);
  		draw_line(x2, y1+1, x1, y2);

  		y1 = h - w;
  		y2 = h - 3;

  		point[0].x = x2;
  		point[0].y = y2;
  		point[1].x = x3;
  		point[1].y = y1;
  		point[2].x = x1;
  		point[2].y = y1;

  		if(forwardarrow) set_color(MDGREY);
    	else
    	if(forwardhi) 
    	set_color(LTGREY);
    	else
    	set_color(MEGREY);
  		XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);

  		if(forwardarrow) set_color(WHITE);
    		else  set_color(DKGREY);
  		draw_line(x3, y1-1, x2, y2-1);
  		draw_line(x3, y1, x2, y2);

  		if(forwardarrow) set_color(DKGREY);
    		else  set_color(WHITE);
  		draw_line(x3, y1, x1, y1);
  		draw_line(x3, y1+1, x1, y1+1);
  		draw_line(x1, y1, x2, y2-1);
  		draw_line(x1, y1+1, x2, y2);

// handle
		get_positions(h - w * 2);
		if(box)
		{
			draw_3d_big(2, handlex + w, w - 4, handlew, DKGREY, MDGREY, LTGREY);
		}
		else
		{
			if(boxhi)
  		draw_3d_big(2, handlex + w, w - 4, handlew, WHITE, LTGREY, DKGREY);
  		else
  		draw_3d_big(2, handlex + w, w - 4, handlew, LTGREY, MEGREY, DKGREY);
		}
	}
	
  flash();
}
