#ifndef BCBITMAP_H
#define BCBITMAP_H

#include <X11/Xlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <X11/extensions/XShm.h>

#include "bcwindow.h"

class BC_Bitmap
{
public:
	BC_Bitmap(BC_Window *top_level, int w, int h, int depth);
	virtual ~BC_Bitmap();

	write_drawable(Drawable &pixmap, int dest_x, int dest_y, int source_x, int source_y, int w, int h);
// the bitmap must be wholly contained in the source during a GetImage
	read_drawable(Drawable &pixmap, int source_x, int source_y);
	read_frame(VFrame *frame, int x1, int y1, int x2, int y2);
	rotate_90(int side);
	
	int w, h, depth;
	unsigned char **row_data;

private:
	transfer_direct(VFrame *frame, int x1, int y1, int x2, int y2);
	transfer_reduce(VFrame *frame, int x1, int y1, int x2, int y2);
	transfer_row_direct_8(unsigned char *output, VPixel *input, int width);
	transfer_row_reduce_8(unsigned char *output, VPixel *input, int *column_table);
	transfer_row_direct_16(unsigned short *output, VPixel *input, int width);
	transfer_row_reduce_16(unsigned short *output, VPixel *input, int *column_table);
	transfer_row_direct_24(unsigned char *output, VPixel *input, int width);
	transfer_row_reduce_24(unsigned char *output, VPixel *input, int *column_table);
	transfer_pixel_8(unsigned char **result, VPixel *input);
	transfer_pixel_16(unsigned short **result, VPixel *input);
	transfer_pixel_24(unsigned char **result, VPixel *input);
	allocate_data();
	delete_data();
	
	int use_shm;
	unsigned char *data;
	BC_Window *top_level;
	XImage *ximage;
	XShmSegmentInfo shm_info;
};






#endif
