#ifndef BCSLIDERS_H
#define BCSLIDERS_H

#include "bccolors.h"
#include "bckeys.h"
#include "bctool.h"
#include "bcwindow.h"
#include "units.h"

class BC_Slider_Base : public BC_Tool
{
public:
	BC_Slider_Base(int x_, int y_, int w_, int h_, int virtual_pixels, int ltface_, int dkface_, int fader_);
	
// base event dispatch handlers
	keypress_event_();
	cursor_motion_();
	cursor_left_();
	button_release_();
	virtual button_press_() {};
	virtual cursor_motion_derived() {};
	resize_tool(int x, int y, int w, int h);
	
	
	update_();
	change_backcolor(int newcolor);
	virtual increase_level() {};
	virtual decrease_level() {};

	static int hs;      // handle size
	
	int base_pixel;
	int virtual_pixels;
	int backcolor;
	int position;
	int ltface, dkface, fader;
	int highlighted;
	int buttondown;
	char text[256];


		
// derived dispatch handler
	virtual get_new_value(int result, float x_, float y_) {};
};

// Integer slider
class BC_ISlider : public BC_Slider_Base
{
public:
	BC_ISlider(int x_, int y_, int w_, int h_, int virtual_pixels, int value_, int minvalue_, int maxvalue_, int ltface_, int dkface_, int fader_);
	
	create_tool_objects();
// put new value in slider
	update(int value_);
	update(char *value_);
	get_value();

	button_press_();
	cursor_motion_derived();

	increase_level();
	decrease_level();

	int value, minvalue, maxvalue;
};

// Float slider
class BC_FSlider : public BC_Slider_Base
{
public:
	BC_FSlider(int x_, int y_, int w_, int h_, int virtual_pixels, float value_, float minvalue_, float maxvalue_, int ltface_, int dkface_, int fader_);

	create_tool_objects();
// put new value in slider
	update(float value_);
	update(char *value_);
	float get_value();

	button_press_();
	cursor_motion_derived();

	increase_level();
	decrease_level();

	float value, minvalue, maxvalue;
};

// Frequency slider
class BC_QSlider : public BC_Slider_Base
{
public:
	BC_QSlider(int x_, int y_, int w_, int h_, int virtual_pixels, int value_, int minvalue_, int maxvalue_, int ltface_, int dkface_, int fader_);

	create_tool_objects();

// put new value in slider
	update(int value_);
	update(char *value_);

	button_press_();
	cursor_motion_derived();

	increase_level();
	decrease_level();

	Freq value, minvalue, maxvalue;
};

#endif
