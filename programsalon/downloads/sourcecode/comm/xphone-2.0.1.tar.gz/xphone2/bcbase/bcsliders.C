#include "bcsliders.h"

int BC_Slider_Base::hs = 15;

BC_Slider_Base::BC_Slider_Base(int x_, int y_, int w_, int h_, int virtual_pixels, int ltface_, int dkface_, int fader_)
	: BC_Tool(x_, y_, w_, h_)
{
	buttondown = 0;
	highlighted = 0;
	dkface = dkface_; ltface = ltface_;
	this->virtual_pixels = virtual_pixels;
	fader = fader_;
}

BC_Slider_Base::change_backcolor(int newcolor)
{
	backcolor = newcolor;
}

BC_Slider_Base::resize_tool(int x, int y, int w, int h)
{
	resize_window(x, y, w, h);
	update_();	
}


BC_Slider_Base::update_()
{
	if(w > h)
	{
		static int hh;    /* handle dimensions */
  	static int x1, y1;  /* position of handle */
		static int y2, hb;  // position of bar

  	x1 = position - hs / 2;
  	y1 = 2;
  	hh = h - 4;

  	if(fader)
  	{ y2 = h / 2 - 4; hb = 8; } 
  	else
  	{ y2 = 0; hb = h; }

		set_color(backcolor);
  	draw_box(0, 0, w, h);   // clear box
  	draw_3d_big(0, y2, w, hb, DKGREY, MDGREY, LTGREY);   // slider box

  	if(highlighted) draw_3d_big(x1, y1, hs, hh, WHITE, ltface, DKGREY);  // handle
  	else
  	draw_3d_big(x1, y1, hs, hh, LTGREY, dkface, DKGREY);  // handle

		set_color(BLACK);
  	draw_line(x1 + hs / 2, y1, x1 + hs / 2, y1 + hh - 1);

		set_font(top_level->smallfont);
  	if(fader)
  	{
			set_color(RED);
  		draw_center_text(w / 2, y2, text, top_level->smallfont);
  	}
  	else
  	{
			set_color(MEYELLOW);
  		draw_center_text(w / 2, y2 + hb - 2, text, top_level->smallfont);
		}
		set_font(top_level->largefont);
	}
	else
	{
		static int hw;    // handle dimensions
  	static int x1, y1;  // position of handle 
		static int x2, wb;  // position of bar

  	x1 = 2;
  	y1 = h - position - hs / 2;
  	hw = w - 4;

  	if(fader)
  	{ x2 = w / 2 - 4; wb = 8; } 
  	else
  	{ x2 = 0; wb = w; }

		set_color(backcolor);
  	draw_box(0, 0, w, h);   // clear box
  	draw_3d_big(x2, 0, wb, h, DKGREY, MDGREY, LTGREY);   // slider box

  	if(highlighted) draw_3d_big(x1, y1, hw, hs, WHITE, ltface, DKGREY);  // handle
  	else
  	draw_3d_big(x1, y1, hw, hs, LTGREY, dkface, DKGREY);  // handle

		//set_color(BLACK);
  	//draw_line(x1, y1 + hs / 2, x1 + hw - 1, y1 + hs / 2);

		set_color(RED);
		set_font(top_level->smallfont);
		if(fader)
		{
  		draw_center_text(x1 + w / 2, y1 + hs - 2, text, top_level->smallfont);
		}
		else
		{
  		draw_center_text(x + w / 2, h / 2, text, top_level->smallfont);
		}
		set_font(top_level->largefont);
	}
	flash();
}



//  ========================= event dispatch handlers

BC_Slider_Base::keypress_event_()
{
	static int result;
	result = 0;
	
	if(top_level->active_tool == this)
	{
		if(top_level->get_keypress() == LEFT) { decrease_level(); result = 3; };
		if(top_level->get_keypress() == RIGHT) { increase_level(); result = 3; };
		if(top_level->get_keypress() == DOWN) { decrease_level(); result = 3; };
		if(top_level->get_keypress() == UP) { increase_level(); result = 3; };
	}
	if(result == 3) { trap_keypress(); handle_event(); }    // user event handler
}

BC_Slider_Base::cursor_left_()
{
	if(highlighted)
	{
		if(cursor_x < 0 || cursor_x > w ||
			 cursor_y < 0 || cursor_y > h)
		{   // draw highlighted
			highlighted = 0;
			update_();
		}
	}
}

BC_Slider_Base::button_release_()
{
	if(buttondown) buttondown = 0;
}

BC_Slider_Base::cursor_motion_()
{
	if(buttondown)
	{
		cursor_motion_derived();
	}
	else
	if(highlighted)
	{
		if(cursor_x < 0 || cursor_x > w ||
			 cursor_y < 0 || cursor_y > h)
		{   // draw highlighted
			highlighted = 0;
			update_();
		}
	}
	else //if(!active || !active->buttondown)  // kept only one slider highlighted
	{
		if(cursor_x > 0 && cursor_x < w &&
			 cursor_y > 0 && cursor_y < h)
		{   // draw highlighted
			highlighted = 1;
			update_();
		}
	}
}



// ==================================== constructors

BC_ISlider::BC_ISlider(int x_, int y_, int w_, int h_, int virtual_pixels, int value_, int minvalue_, int maxvalue_, int ltface_, int dkface_, int fader_)
	: BC_Slider_Base(x_, y_, w_, h_, virtual_pixels, ltface_, dkface_, fader_)
{
	minvalue = minvalue_;
	maxvalue = maxvalue_;
	value = value_;
}

BC_FSlider::BC_FSlider(int x_, int y_, int w_, int h_, int virtual_pixels, float value_, float minvalue_, float maxvalue_, int ltface_, int dkface_, int fader_)
	: BC_Slider_Base(x_, y_, w_, h_, virtual_pixels, ltface_, dkface_, fader_)
{
	minvalue = minvalue_;
	maxvalue = maxvalue_;
	value = value_;
}

BC_QSlider::BC_QSlider(int x_, int y_, int w_, int h_, int virtual_pixels, int value_, int minvalue_, int maxvalue_, int ltface_, int dkface_, int fader_)
	: BC_Slider_Base(x_, y_, w_, h_, virtual_pixels, ltface_, dkface_, fader_)
{
	minvalue = minvalue_;
	maxvalue = maxvalue_;
	value = value_;
}

BC_ISlider::create_tool_objects()
{
	backcolor = subwindow->color;
	create_window(x, y, w, h, backcolor);
	update(value);
}

BC_FSlider::create_tool_objects()
{
	backcolor = subwindow->color;
	create_window(x, y, w, h, backcolor);
	update(value);
}

BC_QSlider::create_tool_objects()
{
	backcolor = subwindow->color;
	create_window(x, y, w, h, backcolor);
	update(value.freq);
}





// ==================================== contents updating

BC_ISlider::update(int value_)
{
	int x_, w_; // inner dimensions
	
	if(w > h)
	{
		 w_ = w - 4 - hs;
		 x_ = 2 + hs / 2;
	}
	else
	{
		 w_ = h - 4 - hs;
		 x_ = 2 + hs / 2;
	}

	if(value_ > maxvalue) value_ = maxvalue;
	if(value_ < minvalue) value_ = minvalue;

	value = value_;
	sprintf(text, "%d", value);
		position = (int)(x_ + w_ * ((float)(value - minvalue) / (float)(maxvalue - minvalue)));
	update_();
}

BC_FSlider::update(float value_)
{
	int x_, w_; // inner dimensions
	
	if(w > h)
	{
		w_ = w - 4 - hs;
		x_ = 2 + hs / 2;
	}
	else
	{
		w_ = h - 4 - hs;
		x_ = 2 + hs / 2;
	}
	
	if(value_ > maxvalue) value_ = maxvalue;
	if(value_ < minvalue) value_ = minvalue;

	value = value_;
	position = (int)(x_ + w_ * (value - minvalue) / (maxvalue - minvalue));
	
	if(value >= 0) sprintf(text, "+%.1f", value);
	else 
	if(value == INFINITYGAIN) sprintf(text, "oo");
	else 
	sprintf(text, "%.1f", value);
	update_();
}
	
BC_QSlider::update(int value_)
{
	int x_, w_; // inner dimensions
	
	if(w > h)
	{
		w_ = w - 4 - hs;
		x_ = 2 + hs / 2;
	}
	else
	{
		w_ = h - 4 - hs;
		x_ = 2 + hs / 2;
	}
	
	if(value_ > maxvalue.freq) value_ = maxvalue.freq;
	if(value_ < minvalue.freq) value_ = minvalue.freq;
	
	value = value_;
	position = (int)(x_ + w_ * ((float)(value.fromfreq() - minvalue.fromfreq()) / (maxvalue.fromfreq() - minvalue.fromfreq())));

	if(value.freq < 10000)
		sprintf(text, "%d", value.freq);
	else
		sprintf(text, "%.1fk", (float)value.freq / 1000);
	update_();
}



BC_ISlider::get_value()
{
	return value;
}

float BC_FSlider::get_value()
{
	return value;
}




BC_ISlider::update(char *value_)
{
	update(atol(value_));
}

BC_FSlider::update(char *value_)
{
	if(!strcmp(value_, "oo")) update(INFINITYGAIN);
	else update(atof(value_));
}

BC_QSlider::update(char *value_)
{
	update(atol(value_));
}


// =============================== event handlers


BC_FSlider::button_press_()
{
	if(cursor_x > 0 && cursor_x < w
		 && cursor_y > 0 && cursor_y < h)
	{
		if(w > h)
// horizontal slider
			base_pixel = cursor_x;
		else
// vertical slider
			base_pixel = (h - cursor_y);

		base_pixel -= (int)(virtual_pixels * (value - minvalue) / (maxvalue - minvalue));
		buttondown = 1;
		if(top_level->active_tool != this){ activate(); }
	}
}

BC_ISlider::button_press_()
{
	if(cursor_x > 0 && cursor_x < w
		 && cursor_y > 0 && cursor_y < h)
	{
		if(w > h)
// horizontal slider
			base_pixel = cursor_x;
		else
// vertical slider
			base_pixel = (h - cursor_y);

		base_pixel -= (int)(virtual_pixels * (float)(value - minvalue) / (maxvalue - minvalue));
		buttondown = 1;
		if(top_level->active_tool != this){ activate(); }
	}
}

BC_QSlider::button_press_()
{
	if(cursor_x > 0 && cursor_x < w
		 && cursor_y > 0 && cursor_y < h)
	{
		if(w > h)
// horizontal slider
			base_pixel = cursor_x;
		else
// vertical slider
			base_pixel = (h - cursor_y);
		
		base_pixel -= (int)(virtual_pixels * (float)(value.freq - minvalue.freq) / (maxvalue.freq - minvalue.freq));
		buttondown = 1;
		if(top_level->active_tool != this){ activate(); }
	}
}

BC_FSlider::cursor_motion_derived()
{
	int virtual_pixel;

	if(w > h)
		virtual_pixel = cursor_x - base_pixel;
	else
		virtual_pixel = (h - cursor_y) - base_pixel;
	
	update(minvalue + (maxvalue - minvalue) * virtual_pixel / virtual_pixels);
	handle_event();
}

BC_ISlider::cursor_motion_derived()
{
	int virtual_pixel;
	
	if(w > h)
		virtual_pixel = cursor_x - base_pixel;
	else
		virtual_pixel = (h - cursor_y) - base_pixel;
	
	update(minvalue + (maxvalue - minvalue) * virtual_pixel / virtual_pixels);
	handle_event();
}

BC_QSlider::cursor_motion_derived()
{
	int virtual_pixel;
	
	if(w > h)
		virtual_pixel = cursor_x - base_pixel;
	else
		virtual_pixel = (h - cursor_y) - base_pixel;
	
	update(minvalue.freq + (maxvalue.freq - minvalue.freq) * virtual_pixel / virtual_pixels);
	handle_event();
}



// ======================================== keypress handlers

BC_ISlider::decrease_level()
{
	value--;
	if(value < minvalue) value = minvalue;
	update(value);
}

BC_FSlider::decrease_level()
{
	value -= 0.1;
	if(value < minvalue) value = minvalue;
	update(value);
}

BC_QSlider::decrease_level()
{
	--value;
	update(value.freq);
}

BC_ISlider::increase_level()
{
	value++;
	if(value > maxvalue) value = maxvalue;
	update(value);
}

BC_FSlider::increase_level()
{
	value += 0.1;
	if(value > maxvalue) value = maxvalue;
	update(value);
}

BC_QSlider::increase_level()
{
	++value;
	update(value.freq);
}
