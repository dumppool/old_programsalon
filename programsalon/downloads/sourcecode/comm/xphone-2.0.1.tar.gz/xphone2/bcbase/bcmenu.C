#include "bcmenubar.h"

// ============================================== menu popup

BC_MenuPopup::BC_MenuPopup(BC_Menu *menu, 
						BC_MenuBar *menubar, 
						ArrayList<BC_MenuItem*> *menuitems, 
						BC_Window *parent, 
						int color, int x, int y, int w, int h) 
: BC_Popup(parent, color, x, y, w, h) 
{ 
	this->menuitems = menuitems;
	this->menubar = menubar;
	this->menu = menu;
}

BC_MenuPopup::~BC_MenuPopup()
{
}

BC_MenuPopup::draw()
{
	static int i;
	draw_3d_big(0, 0, w, h, LTCYAN, MECYAN, DKCYAN);
	for(i = 0; i < menuitems->total; i++)
	{
		menuitems->values[i]->draw();
	}
	flash();
}

BC_MenuPopup::cursor_motion()
{
	static int i, result;
	
	result = 0;

	for(i = 0; i < menuitems->total; i++)
	{
		result += menuitems->values[i]->cursor_motion(cursor_x, cursor_y);
	}
	if(result) draw();
}

BC_MenuPopup::button_press()
{
	static int i;
	for(i = 0; i < menuitems->total; i++)
	{
		menuitems->values[i]->button_press();
	}
	flash();
}

BC_MenuPopup::button_release()
{
	menu->button_release(cursor_x, cursor_y);
}

// ============================================== menu

BC_Menu::BC_Menu(char *text)
{
	active = 0;
	strcpy(this->text, text);
	highlighted = 0;
	popup_menu = 0;
}

BC_Menu::~BC_Menu()
{
	if(popup_menu) delete popup_menu;
// delete derived objects manually
// objects that weren't inherited
	for(int i = 0; i < menuitems.total; i++) delete menuitems.values[i];
// pointers
	menuitems.remove_all();
// call back to menubar to delete this pointer
}

BC_Menu::create_objects(BC_MenuBar *menubar, BC_Window *top_level, int x, int w)
{
	this->title_x = x;  this->title_w = w;
	this->menubar = menubar;
	this->top_level = top_level;
	subwindow = menubar->subwindow;
	draw_title();
}

BC_Menu::add_menuitem(BC_MenuItem* menuitem)
{
	int y;
	
	if(menuitems.total == 0)
	{
		y = 0;
	}
	else
	{
		y = menuitems.values[menuitems.total - 1]->get_y() + menuitems.values[menuitems.total - 1]->get_height();
	}

	menuitem->create_objects(this, y);
// pointer
	menuitems.append(menuitem);
}

BC_Menu::remove_menuitem(BC_MenuItem *item)
{ // remove from end
// derived object must be deleted
// object
//	delete menuitems.values[menuitems.total - 1];
// pointer
	menuitems.remove(item);
}

BC_Menu::get_text_width(XFontStruct *font, char *text)
{
	return menubar->get_text_width(font, text);
}


BC_Menu::get_width()
{
	static int w, test_w, i;
	static int text_w, hotkey_w;
	w = 0;
	text_w = 0;
	hotkey_w = 0;
	
	
	for(i = 0; i < menuitems.total; i++)
	{
		if((test_w = menuitems.values[i]->get_text_width()) > text_w) text_w = test_w;
		if((test_w = menuitems.values[i]->get_hotkey_width()) > hotkey_w) hotkey_w = test_w;
	}
	
	w = text_w + hotkey_w;
	hotkey_x = text_w;
	return w;
}

BC_Menu::get_height()
{
	static int h, i;
	h = 0;
	
	for(i = 0; i < menuitems.total; i++)
	{
		h += menuitems.values[i]->get_height();
	}
	return h;
}

BC_Menu::activate()
{
	popup_menu = new BC_MenuPopup(this, menubar, &menuitems, top_level, MECYAN, title_x + menubar->x, menubar->h + menubar->y - 2, get_width(), get_height());

	active = 1;
	draw_title();
	popup_menu->draw();
}

BC_Menu::deactivate(int cursor_x, int cursor_y)
{
	static int min_title_y;
	min_title_y = -menubar->h;

// deactivate recursively
	if(active && popup_menu)
	{
		deactivate_items();
		active = 0;

		if(cursor_y > min_title_y && cursor_y < 0 && cursor_x > 0 && cursor_x < title_w)
			highlighted = 1;
		else
			highlighted = 0;

		delete popup_menu;
		popup_menu = 0;
		draw_title();
	}
}

BC_Menu::deactivate_items()
{
	if(active && popup_menu)
	{
		popup_menu->draw_3d_big(0, 0, popup_menu->w, popup_menu->h, LTCYAN, MECYAN, DKCYAN);
		for(int i = 0; i < menuitems.total; i++)
		{
			menuitems.values[i]->deactivate();
		}                       // run popup second
 		popup_menu->flash();
 	}
}

BC_Menu::translate_coords(int *x_, int *y_)
{
	*x_ = top_level->cursor_x - subwindow->x - menubar->x; 
	*y_ = top_level->cursor_y - subwindow->y - menubar->y;
}

BC_Menu::expose_event_dispatch()
{
}


BC_Menu::button_release_dispatch()
{
// dispatch to popup
	if(active) popup_menu->button_release_dispatch();
}

BC_Menu::button_press_dispatch()
{
// handle popup properties first
// dispatch to popup
	if(active && popup_menu)
	{
		popup_menu->button_press_dispatch();
	}
	else
	{  // no popup so handle title properties in title
		int minx = title_x;
		int miny = 0;
		int x_, y_;

		translate_coords(&x_, &y_);
		if(x_ > minx && x_ < minx + title_w &&
			 y_ > miny && y_ < miny + menubar->h)
		{
			menubar->button_releases = 0;
			menubar->activate();
			activate();
		}
	}
}

BC_Menu::cursor_left_dispatch()
{
	if(highlighted)
	{
		if(subwindow->cursor_x < title_x || subwindow->cursor_x > title_x + title_w ||
			 subwindow->cursor_y < menubar->y || subwindow->cursor_y > menubar->y + menubar->h)
		{   // draw highlighted
			highlighted = 0;
			draw_title();
		}
	}

// dispatch to popup
	if(active && popup_menu)
	{
		int result = 0;
		for(int i = 0; i < menuitems.total; i++)
		{
			result += menuitems.values[i]->cursor_left_dispatch();
		}
		if(result) popup_menu->draw();
	}
}

BC_Menu::motion_event_dispatch()
{
// handle items first
	if(active && popup_menu)
	{
// dispatch to popup
		popup_menu->motion_event_dispatch();
	}

// if menubar is active
	if(menubar->active)
	{
// cursor has just moved into this title
		static int minx;
		static int miny;
		static int x_, y_;

		minx = title_x;
		miny = 0;

		translate_coords(&x_, &y_);
		if(x_ > minx && x_ < minx + title_w &&
			 y_ > miny && y_ < miny + menubar->h && !this->active)
		{
			menubar->deactivate();
			menubar->activate();
			activate();
		}
	}
// not already active so control highlighting
	else
	{
		if(highlighted)
		{
			if(subwindow->cursor_x < title_x || subwindow->cursor_x > title_x + title_w ||
				 subwindow->cursor_y < menubar->y || subwindow->cursor_y > menubar->y + menubar->h)
			{   // draw highlighted
				highlighted = 0;
				draw_title();
			}
		}
		else
		{
			if(subwindow->cursor_x > title_x && subwindow->cursor_x < title_x + title_w &&
				 subwindow->cursor_y > menubar->y && subwindow->cursor_y < menubar->y + menubar->h)
			{   // draw highlighted
				highlighted = 1;
				draw_title();
			}
		}
	}
}

BC_Menu::key_press_dispatch()
{
	static int i;
	for(i = 0; i < menuitems.total && top_level->key_pressed; i++)
	{
		menuitems.values[i]->key_press();
	}
}

// must handle button release here since popup is deleted during button release
BC_Menu::button_release(int cursor_x, int cursor_y)
{
	menubar->button_releases++;

// released in title
	if(cursor_y > -menubar->h && cursor_y < 0 && cursor_x > 0 && cursor_x < title_w)
	{               // inside title
		if(menubar->button_releases == 2)
		{
			highlighted = 1;
			menubar->deactivate(cursor_x, cursor_y);
		}
	}
	else
// released in popup
	if((cursor_x > 0 && cursor_x < popup_menu->w && cursor_y > 0 && cursor_y < popup_menu->h) || in_submenu())
	{             // inside popup
		for(int i = 0; i < menuitems.total && active; i++)
		{
			menuitems.values[i]->button_release_dispatch(cursor_x, cursor_y);
		}
	}
	else
// released somewhere else
	{
		menubar->deactivate();
	}
}

BC_Menu::get_keypress()
{
	return top_level->get_keypress();
}

BC_Menu::set_keypress(int value)
{
	top_level->key_pressed = value;
}

BC_Menu::shift_down()
{
	return top_level->shift_down();
}

BC_Menu::button_down()
{
	return menubar->button_down;
}

BC_Menu::in_submenu()
{
	static int i;
	for(i = 0; i < menuitems.total; i++)
	{
		if(menuitems.values[i]->in_submenu()) return 1;
	}
	return 0;
}

BC_Menu::set_done(int return_value)
{
	top_level->set_done(return_value);
}


BC_Menu::draw_title()
{
	if(active && popup_menu)
	{
		menubar->draw_3d_big(title_x + 2, 2, title_w - 2, menubar->h - 4, DKCYAN, MDCYAN, LTCYAN);
	}
	else
	{
		if(highlighted)
		{
			menubar->set_color(LTBLUE);
		}
		else
		{
			menubar->set_color(MECYAN);
		}
	
		menubar->draw_box(title_x + 2, 2, title_w - 2, menubar->h - 4);
	}
	menubar->set_color(BLACK);
	menubar->draw_text(title_x + 10, menubar->h - 7, text);
	menubar->flash();
}
