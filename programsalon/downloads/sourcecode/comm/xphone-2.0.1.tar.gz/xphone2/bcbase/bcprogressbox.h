#ifndef BCPROGRESSBOX_H
#define BCPROGRESSBOX_H

class BC_ProgressWindow;
class BC_ProgressBox;

#include "bcbutton.h"
#include "bckeys.h"
#include "bcprogress.h"
#include "bcsubwindow.h"
#include "bctitle.h"
#include "bcwindow.h"
#include "thread.h"

class BC_ProgressBox : public Thread
{
public:
	BC_ProgressBox(char *display, char *text, long length, int cancel_button = 1);
	virtual ~BC_ProgressBox();
	
	void run();
	update(long position);    // return 1 if cancelled
	update_title(char *title);
	update_length(long length);
	cancelled();      // return 1 if cancelled
	
	BC_ProgressWindow *pwindow;
	char *display;
	char *text;
	long length;
	int cancel_button;
};

class BC_ProgressWindowCancelButton;

class BC_ProgressWindow : public BC_Window
{
public:
	BC_ProgressWindow(char *display = "", int cancel_button = 1);
	virtual ~BC_ProgressWindow();
	
	create_objects(char *text, long length);
	update(long position);    // return 1 if cancelled
	
	char *text;
	BC_ProgressBar *bar;
	BC_ProgressWindowCancelButton *cancel;
	BC_Title *caption;
	int cancelled;
	int cancel_button;
};

class BC_ProgressWindowCancelButton : public BC_BigButton
{
public:
	BC_ProgressWindowCancelButton(BC_ProgressWindow *pwindow);
	
	handle_event();
	keypress_event();
	
	BC_ProgressWindow *pwindow;
};

#endif
