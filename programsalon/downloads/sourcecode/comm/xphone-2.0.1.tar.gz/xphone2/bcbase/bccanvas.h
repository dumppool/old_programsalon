#ifndef BCCANVAS_H
#define BCCANVAS_H

class BC_Canvas;

#include "bccolors.h"
#include "bctool.h"
#include "bcwindow.h"

class BC_Canvas : public BC_Tool
{
public:
	BC_Canvas(int x, int y, int w, int h, int color = BLACK);

	create_tool_objects();
// ============================ user event handlers
	virtual resize(int w, int h) {};         // user determines size here and calls set_size back
	virtual cursor_motion() {};               // event handlers for user
	virtual button_release() {}; 
	virtual button_press() {};

// ============================== canvas event handlers

	button_release_();
	button_press_();
	cursor_motion_();
	set_size(int x, int y, int w, int h);    // called by user to set the size
	deactivate_tools();            // deactivate tools if a button press
	
	virtual draw();
// =============================== drawing 

// draw a segment of a frame anywhere on the canvas
	draw_bitmap(VFrame *frame, 
			int in_x1, int in_y1, int in_x2, int in_y2, 
			int out_x1, int out_y1, int out_x2, int out_y2);
	draw_edit(int x, int y, int h);
	draw_start_edit(int x, int y, int vertical);
	draw_end_edit(int x, int y, int vertical);
	draw_3d_big(int x1, int y1, int w, int h, int light, int middle, int shadow);
	set_inverse();
	set_opaque();
	set_color(int color);
	clear_box(int x_, int y_, int w_, int h_);
	draw_box(int x_, int y_, int w_, int h_);
	draw_rectangle(int x_, int y_, int w_, int h_);
	draw_circle(int x_, int y_, int w_, int h_);
	draw_disc(int x, int y, int w, int h);
	draw_line(int x1, int y1, int x2, int y2);
	draw_3d_line(int x1, int y1, int x2, int y2, int color1, int color2);
	draw_text(int x_, int y_, char *text);
	draw_vertical_text(int x, int y, char *text, int fgcolor, int bgcolor);
	draw_center_text(int x, int y, char *text, XFontStruct *font);
	get_text_width(int font, char *text);
	get_text_width(XFontStruct *font, char *text);
	set_font(int font);
	set_font(XFontStruct *font);
	
	GC gc; // private GC for threads
	int color;
};

#endif
