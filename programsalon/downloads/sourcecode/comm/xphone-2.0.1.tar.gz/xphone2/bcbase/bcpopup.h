#ifndef BCPOPUP_H
#define BCPOPUP_H

class BC_Popup;

#include "bctool.h"
#include "bcwindow.h"

class BC_Popup          // inherited by popup windows
{
public:
	BC_Popup(BC_Window *top_level, int color, int x, int y, int w, int h);
// x, y, w, and h are relative to top_level window
	virtual ~BC_Popup();
	
// drawing
	set_color(int color);
	draw_check(int x, int y, int w, int h);
	draw_box(int x_, int y_, int w_, int h_);
	draw_rectangle(int x_, int y_, int w_, int h_);
	draw_3d_big(int x1, int y1, int w, int h, int light, int middle, int shadow);
	draw_text(int x_, int y_, char *text);
	draw_line(int x1, int y1, int x2, int y2);
	get_text_width(XFontStruct *font, char *text);
	resize_window(int x, int y, int w, int h);       // user calls to resize this window
	flash();

// event handlers
	motion_event_dispatch();
	button_press_dispatch();
	button_release_dispatch();
	cursor_left_dispatch();
	expose_event_dispatch();

// user event handlers
	virtual cursor_left() {};
	virtual cursor_motion() {};
	virtual button_press() {};
	virtual button_release() {};
	
	int cursor_x, cursor_y;
	Pixmap pixmap;
	Window win;
	BC_Window *top_level;
	int x, y, w, h, color;
};

#endif
