#include "bcmenubar.h"

BC_MenuBar::BC_MenuBar(int x, int y, int w) : BC_Tool(x, y, w, 25)
{
	active = 0;
	button_down = 0;
	enabled = 1;
}

BC_MenuBar::~BC_MenuBar()
{
// delete derived classes manually
// delete base classes here
	for(int i = 0; i < menus.total; i++) delete menus.values[i];
// delete pointers
	menus.remove_all();
}

BC_MenuBar::create_tool_objects()
{
	create_window(x, y, w, h, MECYAN);
	draw();
}

BC_MenuBar::resize_event_(int w, int h)
{
  this->w = w;
	resize_window(x, y, w, this->h);
  draw();
	for(int i = 0; i < menus.total; i++)
	{
		menus.values[i]->draw_title();
	}
}

BC_MenuBar::draw()
{
	draw_3d_big(0, 0, w, h, LTCYAN, MECYAN, DKCYAN);
	flash();
}

BC_MenuBar::add_menu(BC_Menu* menu)
{
	int x, w;
	if(menus.total == 0)
	{
		x = 0;
	}
	else
	{
		x = menus.values[menus.total - 1]->title_x + menus.values[menus.total - 1]->title_w;
	}
	
	w = get_text_width(top_level->largefont, menu->text) + 20;

// add pointer	
	menus.append(menu);
	menu->create_objects(this, top_level, x, w); // initialize and draw
}

BC_MenuBar::deactivate(int cursor_x, int cursor_y)
{
	for(int i = 0; i < menus.total; i++)
	{
		menus.values[i]->deactivate(cursor_x, cursor_y);
	}
	active = 0;
	top_level->active_menubar = 0;
}

BC_MenuBar::activate()
{
	active = 1;
	top_level->active_menubar = this;
}

BC_MenuBar::keypress_event_()
{
// menu is enabled, no tool is active, or active tool doesn't use text
	if(enabled && (!top_level->active_tool || !top_level->active_tool->uses_text()))
	{
		for(int i = 0; i < menus.total && top_level->key_pressed; i++)
		{
			menus.values[i]->key_press_dispatch();
		}
	}
}

BC_MenuBar::button_release_()
{
	button_down = 0;
	for(int i = 0; i < menus.total && enabled; i++)
	{
		menus.values[i]->button_release_dispatch();
	}
}

BC_MenuBar::button_press_()
{
	button_down = 1;
	for(int i = 0; i < menus.total && enabled; i++)
	{
		menus.values[i]->button_press_dispatch();
	}
}

BC_MenuBar::expose_event_dispatch()
{
	if(top_level->event_win == win) flash();

// dispatch to menus
	for(int i = 0; i < menus.total; i++)
	{
		menus.values[i]->expose_event_dispatch();
	}
}

BC_MenuBar::cursor_left_()
{
	for(int i = 0; i < menus.total && enabled; i++)
	{
		menus.values[i]->cursor_left_dispatch();
	}
}

BC_MenuBar::cursor_motion_()
{
	for(int i = 0; i < menus.total && enabled; i++)
	{
		menus.values[i]->motion_event_dispatch();
	}
}

BC_MenuBar::enable()
{
	enabled = 1;
}

BC_MenuBar::disable()
{
	enabled = 0;
}
