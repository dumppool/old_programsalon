#ifndef BCFILEBOX_H
#define BCFILEBOX_H


class BC_FileBoxOK;
class BC_FileBoxCancel;
class BC_FileBoxSubWindow;
class BC_FileBoxUseThis;

#include "bcbutton.h"
#include "bclistbox.h"
#include "bcsubwindow.h"
#include "bctextbox.h"
#include "bctitle.h"
#include "filesystem.h"

class BC_FileBox : public BC_Window
{               // inherited by the actual file box
public:
	BC_FileBox(char *display, char *init_directory, char *title, char *caption, int show_all_files = 0, int want_directory = 0);
	virtual ~BC_FileBox();
	create_objects();
	
	// ================================== user defined event handlers
	virtual ok_event();
	virtual cancel_event();
	set_show_all();                // show all files
	char* get_directory();
	char* get_filename();
	
	submit_file(char *text);       // return 1 if directory 0 if file
	char directory[1024], filename[1024];   // output
	// ===================================== data
	int want_directory;
	char caption[1024];
	FileSystem *dir;
	BC_FileBox *filebox;
	BC_FileBoxOK *ok;
	BC_FileBoxCancel *cancel;
	BC_FileBoxUseThis *usethis;
	BC_TextBox *textbox;
	BC_ListBox *listbox;
	BC_Title *directory_title;
	BC_FileBoxSubWindow *subwindow;
};

class BC_FileBoxOK : public BC_BigButton
{
public:
	BC_FileBoxOK(BC_FileBox *filebox);
	
	handle_event();
	keypress_event();
	
	BC_FileBox *filebox;
};

class BC_FileBoxCancel : public BC_BigButton
{
public:
	BC_FileBoxCancel(BC_FileBox *filebox);
	
	handle_event();
	keypress_event();
	
	BC_FileBox *filebox;
};

class BC_FileBoxUseThis : public BC_BigButton
{
public:
	BC_FileBoxUseThis(BC_FileBox *filebox);
	
	handle_event();
	
	BC_FileBox *filebox;
};

class BC_FileBoxTextBox : public BC_TextBox
{
public:
	BC_FileBoxTextBox(BC_FileBox *filebox, char *text);
	
	handle_event();
	
	BC_FileBox *filebox;
};

class BC_FileBoxDirectory : public BC_Title
{
public:
	BC_FileBoxDirectory(BC_FileBox *filebox, char *text);
};

class BC_FileBoxListBox : public BC_ListBox
{
public:
	BC_FileBoxListBox(BC_FileBox *filebox, char **dir_list, int total_files);
	virtual ~BC_FileBoxListBox();
	
	handle_event();
	selection_changed();
	
	BC_FileBox *filebox;
};

#endif

