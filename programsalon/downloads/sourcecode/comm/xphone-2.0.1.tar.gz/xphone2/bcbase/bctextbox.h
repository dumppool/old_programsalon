#ifndef BCTEXTBOX_H
#define BCTEXTBOX_H

#include "bccolors.h"
#include "bckeys.h"
#include "bctool.h"
#include "bcwindow.h"

class BC_TextBox : public BC_Tool
{
public:
	BC_TextBox(int x, int y, int w, char *text, int has_border = 1);
	BC_TextBox(int x, int y, int w, int text, int has_border = 1);
	BC_TextBox(int x, int y, int w, float text, int has_border = 1);
	create_tool_objects();

	cursor_left_();
	button_press_();
	cursor_motion_();
	button_release_();
	keypress_event_();
	resize_tool(int x, int y);


	draw();
// put new text in box and set up the selection
	update(char *text_);               // set text to a string
	update(int value);                 // set text to a number
	char* get_text();                  // get the string contained in the textbox
	
// redraw the textbox
	update();
// deactivate all the text boxes
	deactivate_all();

	int highlighted;
	int x1, x2, x1_, x2_, center_, start, selecttext, selectword;
	int has_border;
	char text[1024];
	uses_text();
	
	charof(int x);
// activate this textbox
	activate_();
// deactivate this textbox
	deactivate();
	int text_color, back_color, high_color;
	int text_ascent;
	int center, wordx1, wordx2;
};

#endif
