#ifndef BCTOGGLES_H
#define BCTOGGLES_H

#include "bccolors.h"
#include "bctool.h"
#include "bcwindow.h"

class BC_Toggle : public BC_Tool // Base class
{
public:
	BC_Toggle(int x_, int y_, int w_, int h_, int down, char *text = 0);
	create_tool_objects();

	// update status
	resize(int x_, int y_, int w_, int h_, int down);
	resize_tool(int x, int y);
	update(int down_);
	get_value();
// ============================== user event handlers	
	virtual draw() {};
	virtual cursor_moved_over() {};
	virtual button_press() {};
	virtual button_release() {};

// ================================ tool event handlers
	cursor_left_();
	button_press_();
	cursor_motion_();
	button_release_();

	int highlighted;
	int down;
	char *text;
};

class BC_Radial : public BC_Toggle
{
public:
	BC_Radial(int x_, int y_, int w_, int h_, int down, char *text = 0);
	create_tool_objects();

	draw();
};

class BC_CheckBox : public BC_Toggle
{
public:
	BC_CheckBox(int x_, int y_, int w_, int h_, int down, char *text = 0);
	create_tool_objects();

	draw();
};

class BC_RecordPatch : public BC_Toggle
{
public:
	BC_RecordPatch(int x_, int y_, int w_, int h_, int down);
	create_tool_objects();

	draw();
};

class BC_PlayPatch : public BC_Toggle
{
public:
	BC_PlayPatch(int x_, int y_, int w_, int h_, int down);
	create_tool_objects();

	draw();
};

class BC_Label : public BC_Toggle
{
public:
	BC_Label(int x_, int y_, int w_, int h_, int down);
	create_tool_objects();

	set_status(int down_);
	draw();
};

#endif
