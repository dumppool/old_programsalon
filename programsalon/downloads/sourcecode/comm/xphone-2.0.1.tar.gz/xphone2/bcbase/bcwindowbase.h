#ifndef BCWINDOWBASE_H
#define BCWINDOWBASE_H

class BC_Window;
class BC_WindowBase;
class BC_SubWindow;
class BC_SubWindowItem;
class BC_SubWindowList;
class BC_Tool;
class BC_ToolItem;
class BC_ToolList;

#include <stdio.h>
#include <stdlib.h>
#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <X11/cursorfont.h>

class BC_WindowBase
{
public:
	BC_WindowBase() {};
	BC_WindowBase(int x, int y, int w, int h, int color);
	virtual ~BC_WindowBase();

// affect this window and all its subwindows

	enable_window();         // enable all events
	disable_window();        // disable all events except expose
	destroy_window();        // destroy the window but keep the object
	
// ================================= initialization
	virtual create_objects() {};    // routine user adds components from
	
	BC_Tool* add_tool(BC_Tool *tool);                     // add a lowest level component
	add_border(int light, int medium, int dark);         // add a border to this window
	BC_SubWindow* add_subwindow(BC_SubWindow* subwindow);         // add a subwindow object
	delete_tool(BC_Tool *tool);                   // delete a lowest level component
	delete_subwindow(BC_SubWindow* subwindow);           // delete a subwindow object
	resize_window(int x, int y, int w, int h);       // user calls to resize this window
	resize_window(int w, int h);       // user calls to resize this window
	
// ================================= user declared event handlers

	virtual cursor_motion() {};  
	virtual button_release() {}; 
	virtual button_press() {};
	virtual resize_event(int w, int h) {};      // gives w and h of parent window
	
	
	
	
	
// ============================ internal event dispatchers

	keypress_event_dispatch();
	expose_event_dispatch();
	button_press_dispatch();
	button_release_dispatch();
	motion_event_dispatch();
	resize_event_dispatch();
	flash();
	repeat_dispatch();          // for repeats
	cursor_left_dispatch();

// =============================== queries

	get_keypress();            // return the key pressed during this event
	get_buttonpress();         // return the button pressed 
	find_next_textbox(BC_Tool *tool, int *result);        // return the next textbox in line
	find_first_textbox(BC_Tool *tool);                //  find a textbox

// ======================================= drawing commands
	
	draw_border();
	draw_line(int x1, int y1, int x2, int y2);
	set_color(int color);
	
	
 	Window win;               // this window

// parameters for all

	int x, y, w, h, color;          // position of subwindow or size of top level window
	int border;                        // if this window has a border
	int light, medium, dark;           // border colors
	int cursor_x, cursor_y;        // cursor position of last event relative to this window
	int enabled;                  // if this window is enabled

	BC_Window *top_level;           // pointer to top level window or this if it is the top
	BC_WindowBase *parent_window;   // pointer to parent window or this if it is the top
	BC_SubWindowList* subwindows;     // list of subwindows owned by this window
	BC_ToolList* tools;              // list of lowest level components owned
};




#endif
