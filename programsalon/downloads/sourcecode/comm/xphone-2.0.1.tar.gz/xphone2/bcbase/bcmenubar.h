#ifndef BCMENUBAR_H
#define BCMENUBAR_H

class BC_Menu;
class BC_MenuItem;
class BC_MenuBar;
class BC_SubMenu;
class BC_SubMenuItem;

#include "arraylist.h"
#include "bccolors.h"
#include "bctool.h"
#include "bcpopup.h"
#include "bcwindow.h"

class BC_SubMenuItem
{
public:
	BC_SubMenuItem(char *text);
	virtual ~BC_SubMenuItem();
	create_objects(BC_SubMenu *submenu, int y);
	
	virtual handle_event() {};
	
	get_text_width();
	get_height();
	get_y();
	set_checked(int checked);
	activate();
	deactivate();
	draw();
	motion_event_dispatch(int cursor_x, int cursor_y);
	button_press();
	button_release();

	int checked, highlighted;
	int y, h;
	char text[256];
	BC_SubMenu *submenu;
};

class BC_SubMenuPopup : public BC_Popup
{
public:
	BC_SubMenuPopup(BC_SubMenu *submenu, 
	                ArrayList<BC_SubMenuItem*> *submenuitems, 
	                BC_Window *top_level, 
	                int color, int x, int y, int w, int h);
	virtual ~BC_SubMenuPopup();
	
	cursor_motion();
	button_press();
	button_release();
	draw();
	
	ArrayList<BC_SubMenuItem*> *submenuitems;
	BC_SubMenu *submenu;
};

class BC_SubMenu
{
public:
	BC_SubMenu();
	virtual ~BC_SubMenu();
	create_objects(BC_MenuItem *menuitem, int x, int y);
	
	activate();
	deactivate();
	deactivate_items();
	add_submenuitem(BC_SubMenuItem* menuitem);
	remove_submenuitem(BC_SubMenuItem *item);
	
	
	button_down();
	button_press_dispatch();
	button_release_dispatch();
	motion_event_dispatch();
	cursor_left_dispatch();
	int highlighted;

// events must be handled here since they delete the popup
	button_release(int cursor_x, int cursor_y);
	cursor_motion(int cursor_x, int cursor_y);
	get_text_width(XFontStruct *font, char *text);
	get_width();
	get_height();
	get_checked();
	in_submenu();

	int active;
	int menu_x, menu_y;
	ArrayList<BC_SubMenuItem*> submenuitems;
	BC_SubMenuPopup *popup_submenu;
	BC_MenuItem *menuitem;
	BC_MenuBar *menubar;
	BC_Window *top_level;
	BC_WindowBase *subwindow;
};

class BC_MenuItem
{
public:
	BC_MenuItem(char *text, char *hotkey_text, int hotkey = 0);
	BC_MenuItem(char *text);
	virtual ~BC_MenuItem();
	
	virtual handle_event() {};           // user event is defined here
	set_done(int return_value);                        // quit the program
	cursor_motion(int cursor_x, int cursor_y);
	button_press();
	button_release_dispatch(int cursor_x, int cursor_y);
	key_press();
	set_shift();               // shift key needed for hot key
	set_text(char *text);        // change text
	set_checked(int checked);
	
	draw();
	create_objects(BC_Menu* menu, int y);
	
	cursor_left_dispatch();
	deactivate(); 
	activate(); 
	add_submenu(BC_SubMenu* submenu);
	get_width();
	get_text_width(XFontStruct *font, char *text);
	get_text_width();
	get_hotkey_width();
	get_height();
	get_y();
	get_checked();
	in_submenu();

	int y, h;                     // dimensions relative to popup
	int active;                  // whether it works or not
	int highlighted;              // whether the cursor is over or not
	char text[256];               // title
	int checked;                  // check box
	int hotkey;                   // code of hotkey
	char hotkey_text[16];         // text of hotkey
	int shift_set;                 // if hotkey includes shift
	BC_SubMenu* submenu;             // submenu if one exists
	BC_Menu* menu;                 // parent menu
};

class BC_MenuPopup : public BC_Popup
{
public:
	BC_MenuPopup(BC_Menu *menu, 
							 BC_MenuBar *menubar, 
							 ArrayList<BC_MenuItem*> *menuitems, 
							 BC_Window *parent, 
							 int color, int x, int y, int w, int h);
	virtual ~BC_MenuPopup();
	
	draw();
	cursor_motion();
	button_press();
	button_release();
	
	ArrayList<BC_MenuItem*> *menuitems;
	BC_MenuBar *menubar;
	BC_Menu *menu;
};

class BC_Menu
{
public:
	BC_Menu(char *text);
	virtual ~BC_Menu();
	create_objects(BC_MenuBar *menubar, BC_Window *top_level, int x, int w);

	draw_title();                    // draw menubar title after resize

// event handlers for window
	key_press_dispatch();
	button_release_dispatch();
	button_press_dispatch();
	expose_event_dispatch();
	cursor_left_dispatch();
	motion_event_dispatch();

// event handlers for menu
	button_release(int cursor_x, int cursor_y);    // handle button release in popup since button release deletes popup
	get_keypress();
	set_keypress(int value);
	shift_down();
	set_done(int return_value);
	button_down();
	in_submenu();
	
	add_menuitem(BC_MenuItem* menuitem);
	remove_menuitem(BC_MenuItem *item);

	activate();                // initialize popup
	deactivate(int cursor_x = -1, int cursor_y = -1);    // delete popup
	deactivate_items();
	
	get_text_width(XFontStruct *font, char *text);
	get_width();
	get_height();
	translate_coords(int *x_, int *y_);       // get x and y relative to subwindow from window
	
	int highlighted;             // if cursor is over title
	char text[256];
	ArrayList<BC_MenuItem*> menuitems;
	int active;
	BC_MenuPopup *popup_menu;
	BC_MenuBar *menubar;
	BC_Window *top_level;
	BC_WindowBase *subwindow;
	int hotkey_x;     // position of text and hotkey relative to popup
	int title_x, title_w;    // dimensions of title
	int box_w, box_h;       // dimensions of popup
};

class BC_MenuBar : public BC_Tool
{
public:
	BC_MenuBar(int x, int y, int w);
	virtual ~BC_MenuBar();
	create_tool_objects();
	
	resize_event_(int w, int h);
	keypress_event_();
	add_menu(BC_Menu* menu);
	cursor_motion_();
	cursor_left_();
	button_press_();
	button_release_();
	expose_event_dispatch();
	activate();                    // moving cursor activates menus
	deactivate(int cursor_x = -1, int cursor_y = -1);             // deactivate current popup
	draw();
	enable();
	disable();
	
// ============================= data
	ArrayList<BC_Menu*> menus;
	int button_releases;        // number of button releases since activation
	int active;                    // moving cursor activates menus
	int button_down, cursorleft;
	int enabled;
};

#endif
