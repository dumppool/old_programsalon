#ifndef BCTITLE_H
#define BCTITLE_H

class BC_Title;

#include "bccolors.h"
#include "bctool.h"

class BC_Title : public BC_Tool
{
public:
	BC_Title(int x, int y, 
					 char *text,          // string to draw
					 int font = 0,        // a font macro
					 int color = BLACK);     // a color macro
	
	create_tool_objects();
	resize(int w, int h);
	resize_tool(int x, int y);
	set_color(int color);
	update(char *text);         // replace the text
	draw();
	
	char text[256];
  int color;
	int font;
};

#endif
