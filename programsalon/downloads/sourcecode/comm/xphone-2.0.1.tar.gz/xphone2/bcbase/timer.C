#include "timer.h"
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

Timer::Timer()
{
}

Timer::~Timer()
{
}

Timer::update()
{
	gettimeofday(&current_time, 0);
}

long Timer::get_difference(struct timeval *result)
{
	struct timeval new_time;
	
	gettimeofday(&new_time, 0);
	
	result->tv_usec = new_time.tv_usec - current_time.tv_usec;
	result->tv_sec = new_time.tv_sec - current_time.tv_sec;
	if(result->tv_usec < 0) { result->tv_usec += 1000000; result->tv_sec--; }
}

long Timer::get_scaled_difference(long denominator)
{
	struct timeval new_time;
	
	get_difference(&new_time);
	return new_time.tv_sec * denominator + (long)((float)new_time.tv_usec / 1000000 * denominator);
}

Timer::delay(long milliseconds)
{
	static struct timeval delay_duration;
	delay_duration.tv_sec = 0;
	delay_duration.tv_usec = milliseconds;
	select(0,  NULL,  NULL, NULL, &delay_duration);
}
