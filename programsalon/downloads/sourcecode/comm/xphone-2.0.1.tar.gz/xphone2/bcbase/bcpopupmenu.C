#include "bcpopupmenu.h"

BC_PopupMenu::BC_PopupMenu(int x, int y, int w, char *text, int small)
 : BC_Tool(x, y, w, small ? 20 : 25)
{
	items = new ArrayList<BC_PopupItem *>;
	highlighted = down = button_down = cursor_over = popup_down = 0;
	strcpy(this->text, text);
	popup_w = w;       // total width of the popup window
	popup_h = 0;
	popup = 0;
	button_down = 0;
	this->small = small;
}

BC_PopupMenu::~BC_PopupMenu()
{
// objects
	for(int i = 0; i < items->total; i++) delete items->values[i];
// pointers
	delete items; 
	delete popup;
}

BC_PopupMenu::create_tool_objects()
{
	create_window(x, y, w, h, MECYAN);
	draw_text();
	add_items();
}

BC_PopupMenu::resize_tool(int x, int y, int w, int h)
{
	resize_window(x, y, w, h);
	draw_text();
}

BC_PopupMenu::resize_tool(int x, int y)
{
	resize_window(x, y, w, h);
	draw_text();
}

BC_PopupMenu::update(char *text)
{
	strcpy(this->text, text);
	draw_text();
}

BC_PopupMenu::draw_text()
{
	if(!popup_down)
	{
		if(small)
		{
			if(highlighted) draw_3d_small(1, 1, w-2, h-2, LTCYAN, LTBLUE, DKCYAN);
			else draw_3d_small(1, 1, w-2, h-2, LTCYAN, MECYAN, DKCYAN);
		}
		else
		{
			if(highlighted) draw_3d_big(1, 1, w-2, h-2, LTCYAN, LTBLUE, DKCYAN);
			else draw_3d_big(1, 1, w-2, h-2, LTCYAN, MECYAN, DKCYAN);
		}
	}
	else
	{
		if(small)
		{
			draw_3d_small(1, 1, w-2, h-2, DKCYAN, MDCYAN, LTCYAN);
		}
		else
		{
			draw_3d_big(1, 1, w-2, h-2, DKCYAN, MDCYAN, LTCYAN);
		}
	}

	set_color(BLACK);
	draw_rectangle(0, 0, w, h);
	if(small)       // a.k.a. plugin menu
	{
		//draw_center_text(w / 2, h - 5, text, top_level->largefont);
		set_font(LARGEFONT);
		BC_Tool::draw_text(3, h - 5, text);
	}
	else
	{
		draw_center_text(w / 2, h - 7, text, top_level->largefont);
	}
	flash();
}

BC_PopupMenu::draw_items()
{
	static int i;
	popup->draw_3d_big(0, 0, popup_w, popup_h, LTCYAN, MECYAN, DKCYAN);

	for(i = 0; i < items->total; i++)
	{
		items->values[i]->draw();
	}
	popup->flash();
}

BC_PopupMenu::draw()
{
	draw_text();
	if(popup_down && popup) draw_items();
}

BC_PopupMenu::deactivate()
{
	if(popup_down && popup)
	{
		delete popup;
		for(int i = 0; i < items->total; i++)
		{
			items->values[i]->deactivate();
		}
		popup_down = down = 0;
		popup = 0;
		draw();    // draw the title
		top_level->active_popup_menu = 0;
	}
}

BC_PopupMenu::add_item(BC_PopupItem *item)
{
// pointer
	items->append(item);
	item->create_objects(this, popup_h);
	popup_h += ITEMHEIGHT;
}

BC_PopupMenu::delete_item(BC_PopupItem *item)
{
	items->remove(item); // delete pointer
}

BC_PopupMenu::button_release_()
{
	if(!button_down) return 0;
	static int popup_x, popup_y, result, i;
	cursor_x = top_level->cursor_x - subwindow->x - x;
	cursor_y = top_level->cursor_y - subwindow->y - y;
	result = 0;
	
//printf("BC_PopupMenu::button_release_ cursor_x %d cursor_y %d\n", top_level->cursor_x, top_level->cursor_y);
	if(cursor_x > 0 && cursor_x < w &&
		 cursor_y > 0 && cursor_y < h)
	{
		if(popup_down == 1) result = 1;         // don't deactivate
		popup_down++;
	}
	else
	{
		if(popup_down && popup)
		{
 			popup_x = top_level->cursor_x - x - subwindow->x;
			popup_y = top_level->cursor_y - y - subwindow->y - h;

			for(i = 0; i < items->total; i++)
			{
				result += items->values[i]->button_release(popup_x, popup_y);
			}
		}
	}
	button_down = 0;

//printf("result %d\n", result);
	if(!result)
	{
		deactivate();
	}
	else
	draw();
}

BC_PopupMenu::button_press_()
{
	static int popup_x, popup_y, result, i, test_w;

// pressed in title
	if(cursor_x > 0 && cursor_x < w &&
		 cursor_y > 0 && cursor_y < h)
	{
		button_down = 1;
		if(popup_down && popup)
		{
			popup_down++;
		}
		else
		{
// activate the popup window here
// get the width of the window
			for(i = 0, popup_w = 0; i < items->total; i++)
			{
				test_w = items->values[i]->get_width();
				if(test_w > popup_w) popup_w = test_w;
			}
			if(popup_w < w) popup_w = w;

			popup_down = down = button_down = 1;
			popup = new BC_PopupMenuPopup(this, top_level, MECYAN, x + subwindow->x, y + h + subwindow->y, popup_w, popup_h);
			activate();
			top_level->active_popup_menu = this;
		}
		draw();
	}
	else
// pressed somewhere else
	{
		if(popup_down)
		{
			button_down = 1;
			result = 0;
			popup_x = top_level->cursor_x - x - subwindow->x;
			popup_y = top_level->cursor_y - y - subwindow->y - h;

			for(i = 0; i < items->total; i++)
			{
				result += items->values[i]->button_press(popup_x, popup_y);
			}
			if(result) draw();
		}
	}
}

BC_PopupMenu::cursor_left_()
{
	static int result, i;
	result = 0;

	if(popup_down)
	{
		for(i = 0; i < items->total; i++)
		{
			result += items->values[i]->cursor_left();
		}
	}
	else
	{
		if(highlighted)
		{
			highlighted = 0;
			result = 1;
		}
	}

	if(result) draw();
}

BC_PopupMenu::cursor_motion_()
{
	static int popup_x, popup_y, result, i;
	
	result = 0;
	if(button_down)
	{
		if(cursor_over)
		{
			if(cursor_x < 0 || cursor_x > w ||
				 cursor_y < 0 || cursor_y > h)
			{
				down = 0;
				cursor_over = 0;
				highlighted = 0;
				result = 1;
			}
		}
		else
		{
			if(cursor_x > 0 && cursor_x < w &&
				 cursor_y > 0 && cursor_y < h)
			{
				down = 1;
				cursor_over = 1;
				highlighted = 1;
				result = 1;
			}
		}
	}
	else
	{
  	if(top_level->button_down) return 0;
		if(highlighted)
		{
			if(cursor_x < 0 || cursor_x > w ||
				 cursor_y < 0 || cursor_y > h)
			{   // draw highlighted
				highlighted = 0;
				result = 1;
			}
		}
		else
		{
			if(cursor_x > 0 && cursor_x < w &&
				 cursor_y > 0 && cursor_y < h)
			{   // draw highlighted
				highlighted = 1;
				result = 1;
			}
		}
	}
	
	if(popup_down && popup)
	{
		popup_x = top_level->cursor_x - x - subwindow->x;
		popup_y = top_level->cursor_y - y - subwindow->y - h;
		for(i = 0; i < items->total; i++)
		{
			result += items->values[i]->cursor_motion(popup_x, popup_y);
		}
	}

	if(result) draw();
}

// ================================ items

BC_PopupItem::BC_PopupItem(char *text, int checked)
{
	this->text = new char[strlen(text) + 1];
	strcpy(this->text, text);
	this->checked = checked;
	highlighted = 0;
}

BC_PopupItem::~BC_PopupItem()
{
	menu->delete_item(this);   // delete the pointer
	delete text;
}

BC_PopupItem::create_objects(BC_PopupMenu *menu, int y)
{
	this->menu = menu;
	this->y = y;
}

BC_PopupItem::handle_event()
{
}

BC_PopupItem::set_checked(int checked)
{
	this->checked = checked;
}

BC_PopupItem::button_release(int cursor_x, int cursor_y)
{
	if(cursor_x > 0 && cursor_x < menu->popup_w &&
		cursor_y > y && cursor_y <= y + ITEMHEIGHT)
	{
		menu->deactivate();
		handle_event();
		return 1;
	}
	return 0;
}

BC_PopupItem::button_press(int cursor_x, int cursor_y)
{
	if(cursor_x > 0 && cursor_x < menu->popup_w &&
		cursor_y > y && cursor_y <= y + ITEMHEIGHT)
	{
		highlighted = 1; return 1;
	}
	else
	{
		highlighted = 0; return 0;
	}
}

BC_PopupItem::cursor_left()
{
	if(highlighted)
	{
		highlighted = 0;
		return 1;
	}
	else
	return 0;
}

BC_PopupItem::cursor_motion(int cursor_x, int cursor_y)
{
	if(highlighted)
	{
		if(!(cursor_x > 0 && cursor_x < menu->popup_w &&
			cursor_y > y && cursor_y <= y + ITEMHEIGHT))
		{
			highlighted = 0;
			return 1;
		}
	}
	else
	{
		if(cursor_x > 0 && cursor_x < menu->popup_w &&
			cursor_y > y && cursor_y <= y + ITEMHEIGHT)
		{
			highlighted = 1;
			return 1;
		}
	}
	return 0;
}

BC_PopupItem::deactivate()
{
	highlighted = 0;
}

BC_PopupItem::draw()
{
	BC_PopupMenuPopup *popup;
	
	popup = menu->popup;
	
	if(highlighted)
	{
		if(menu->button_down)
		{
			if(y == 0)
			popup->draw_3d_big(2, 2, popup->w - 4, ITEMHEIGHT - 2, DKCYAN, MDCYAN, LTCYAN);
			else 
			if(y + ITEMHEIGHT == popup->h)
			popup->draw_3d_big(2, y, popup->w - 4, ITEMHEIGHT - 2, DKCYAN, MDCYAN, LTCYAN);
			else
			popup->draw_3d_big(2, y, popup->w - 4, ITEMHEIGHT, DKCYAN, MDCYAN, LTCYAN);
		}
		else
		{
			popup->set_color(LTBLUE);
			if(y == 0)
			popup->draw_box(2, 2, popup->w - 4, ITEMHEIGHT - 2);
			else if(y + ITEMHEIGHT == popup->h)
			popup->draw_box(2, y, popup->w - 4, ITEMHEIGHT - 2);
			else
			popup->draw_box(2, y, popup->w - 4, ITEMHEIGHT);
		}
	}

// draw the text
	popup->set_color(BLACK);
	if(checked)
	{
		popup->draw_check(10, y + 2, 15, 15);
		popup->draw_text(30, y + ITEMHEIGHT - 7, text);
	}
	else
	{
		popup->draw_text(5, y + ITEMHEIGHT - 5, text);
	}
}

BC_PopupItem::get_width()
{
	static int result;
	
	result = menu->get_text_width(LARGEFONT, text) + 20;
	if(checked) result += 20;
	
	return result;
}

BC_PopupItem::update_menu()
{
	menu->update(text);
}


// ================================== window

BC_PopupMenuPopup::BC_PopupMenuPopup(BC_PopupMenu *menu, BC_Window *top_level, int color, int x, int y, int w, int h)
 : BC_Popup(top_level, color, x, y, w, h)
{
	this->menu = menu;
}

BC_PopupMenuPopup::~BC_PopupMenuPopup()
{
}
