#ifndef UNITS_H
#define UNITS_H

#include <math.h>
#include <stdio.h>
#define INFINITYGAIN -40
#define MAXGAIN 50
#define TOTALFREQS 400

// time formats:     // 0 HMS   1 HMSF   2 integer   3 hex

class DB
{
public:
	DB(float infinitygain = INFINITYGAIN);
	virtual ~DB() {};
	
// return power of db using a table
	float fromdb();
	float fromdb(float db);

// set db to the power given using a formula
	float todb(float newdb);

	inline DB& operator++() { if(db < MAXGAIN) db += 0.1; return *this; };
	inline DB& operator--() { if(db > INFINITYGAIN) db -= 0.1; return *this; };
	inline int operator=(DB &newdb) { db = newdb.db; };
	inline DB& operator=(int newdb) { db = newdb; return *this; };
	inline int operator==(DB &newdb) { return db == newdb.db; };
	inline int operator==(int newdb) { return db == newdb; };

	static float *topower;
	float db;
	float infinitygain;
};

class Freq
{
public:
	Freq();
	Freq(const Freq& oldfreq);
	virtual ~Freq() {};

// set freq to index given
	tofreq(int index);

// return index of frequency
	fromfreq();

// increment frequency by one
	Freq& operator++();
	Freq& operator--();
	
	operator>(Freq &newfreq);
	operator<(Freq &newfreq);
	Freq& operator=(const Freq &newfreq);
	operator=(const int newfreq);
	operator!=(Freq &newfreq);
	operator==(Freq &newfreq);
	operator==(int newfreq);

	static int *freqtable;
	int freq;
};


// time conversions
float toframes(long samples, int sample_rate, float framerate);
long tosamples(float frames, int sample_rate, float framerate);
char* totext(char *text, long samples, int samplerate, int time_format, float frame_rate = 30);    // give text representation as time
long fromtext(char *text, int samplerate, int time_format, float frame_rate = 30);    // convert time to samples

#endif
