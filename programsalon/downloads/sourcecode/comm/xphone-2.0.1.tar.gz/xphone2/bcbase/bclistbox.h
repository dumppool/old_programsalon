#ifndef LISTBOX_H
#define LISTBOX_H

class BC_ListBox;

#include "bcscrollbar.h"
#include "bctool.h"
#include "bcwindow.h"

class BC_ListBoxYScroll : public BC_YScrollBar
{
public:
	BC_ListBoxYScroll(BC_ListBox *listbox,  
	                  int totallines,       // total lines in data 
	                  int position);        // start position of scrollbar
	handle_event();
	
	BC_ListBox *listbox;
};

class BC_ListBoxXScroll : public BC_XScrollBar
{
public:
	BC_ListBoxXScroll(BC_ListBox *listbox, 
	                  int totalcolumns,     // total columns in box in pixels
	                  int position);        // start position of scrollbar
	handle_event();
	
	BC_ListBox *listbox;
};

class BC_ListBox : public BC_Tool
{
public:
// content can be specified here or with set_contents
	BC_ListBox(int x, int y, int w, int h, 
						 char **data = 0,         // pointer to data array
						 int totallines = 0,      // number of items in array
						 int yposition = 0,        // top item in window
						 int currentitem = 0);    // current selected item
	virtual ~BC_ListBox();
	create_tool_objects();     // called by subwindow

// user event handler for new selections
	virtual selection_changed() {};
// put current selection in the string
	get_selection(char *string);
	char *get_selection();
	get_selection_number();     // returns -1 if no selection

// change window size and content
	resize(int x, int y, int w, int h, char **data, int totallines, int position, int currentitem);

// change the window size
	set_size(int x, int y, int w, int h);

// change the contents
	set_contents(char **data, int totallines, int position = 0, int currentitem = -1);

	set_selection(int selection);
	
	stay_highlighted();     // force highlighting when inactive
	
// ================================ internal event handlers
	cursor_left_();
	keypress_event_();
	button_press_();
	button_release_();
	cursor_motion_();
	
	
	
	get_total_columns();
	set_current_item(int currentitem);
	resize(int w, int h);
	draw();
	deactivate();
	
	query_list();      // crude search engine
	query_list(char *regexp);
	set_query(char *new_query);
	reset_query();
	motion_update();

// list box creates two scrollbars itself
	BC_ListBoxXScroll *xscrollbar;
	BC_ListBoxYScroll *yscrollbar;
	
	char query[1024];
	int deactivates_highlight;   // stay highlighted when inactive
	int query_x;
	int result;
	int redraw;
	int highlighted;  // item cursor is over
	int currentitem;  // item currently highlighted
	int buttondown;   // button currently down
	char **data;      // pointer to a data list
	int totallines;   // total items in the data list
	int yposition;    // item of top line in list display
	int xposition;    // pixel column of list the box starts on
	int itemheight;   // height of a row in a list
	int text_descent;   // font size parameter
};

#endif
