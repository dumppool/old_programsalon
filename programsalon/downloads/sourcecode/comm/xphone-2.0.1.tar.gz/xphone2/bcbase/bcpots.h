#ifndef BCPOTS_H
#define BCPOTS_H

#include "bccolors.h"
#include "bckeys.h"
#include "bctool.h"
#include "bcwindow.h"
#include "units.h"

class BC_Pot_Base : public BC_Tool
{
public:
	BC_Pot_Base(int x_, int y_, int w_, int h_, int ltface_, int dkface_);
	virtual create_tool_objects() {};
	
// event handler for derived pots
	virtual handle_event_derived() {};
	get_arc_length(int result, float x_, float y_);

// dispatch event handlers
	cursor_left_();
	keypress_event_();
	button_release_();
	cursor_motion_();
	button_press_();
	
	update_();
	change_y_(int y);       // required since additional values are affected
	virtual update() {};
	virtual increase_level() {};
	virtual decrease_level() {};

	int x2, y2;      // position of pointer relative to x, y
	float base1, base2, base3, base_angle;
	int negative;
	
// redraw the pot
	draw_pot();
	float get_angle(float x_, float y_);
	float angle;              // static angle of this pointer
	int buttondown;           // mouse button is down
	int highlighted;
	int ltface, dkface;
	char text[256];
};

// Integer pot
class BC_IPot : public BC_Pot_Base
{
public:
	BC_IPot(int x_, int y_, int w_, int h_, int value_, int minvalue_, int maxvalue_, int ltface_, int dkface_);
	create_tool_objects();
	
// put new value in pot
	update(int value_);
	update(char *value_);
	get_value();
	handle_event_derived();
	
	increase_level();
	decrease_level();
	
	int value, minvalue, maxvalue;
};

// Float pot
class BC_FPot : public BC_Pot_Base
{
public:
	BC_FPot(int x_, int y_, int w_, int h_, float value_, float minvalue_, float maxvalue_, int ltface_, int dkface_);
	create_tool_objects();
	
// put new value in pot
	update(float value_);
	update(char *value_);
	handle_event_derived();
	increase_level();
	decrease_level();
	float get_value();
		
	float value, minvalue, maxvalue;
};

// Frequency pot
class BC_QPot : public BC_Pot_Base
{
public:
	BC_QPot(int x_, int y_, int w_, int h_, int value_, int minvalue_, int maxvalue_, int ltface_, int dkface_);
	BC_QPot(int x_, int y_, int w_, int h_, Freq value_, Freq minvalue_, Freq maxvalue_, int ltface_, int dkface_);
	create_tool_objects();
	
// put new value in pot
	update(int value_);
	update(Freq value_);
	update(char *value_);
	handle_event_derived();
	increase_level();
	decrease_level();
	int get_value();
	
	Freq value, minvalue, maxvalue;
};

#endif
