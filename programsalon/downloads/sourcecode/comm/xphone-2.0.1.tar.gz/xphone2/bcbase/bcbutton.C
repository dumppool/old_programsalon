#include "bcbutton.h"

BC_Button::BC_Button(int x, int y, char *text)
	: BC_Tool(x, y, 0, 0)
{
	this->text = new char[strlen(text) + 1];
	strcpy(this->text, text);
	down = button_down = cursor_over = highlighted = 0;
}

BC_Button::BC_Button(int x, int y, int w, char *text)
	: BC_Tool(x, y, w, 0)
{
	this->text = new char[strlen(text) + 1];
	strcpy(this->text, text);
	down = button_down = cursor_over = highlighted = 0;
}

BC_Button::~BC_Button() { delete text; }

BC_Button::create_tool_objects() { create_window(x, y, w, h, MEGREY); }

BC_Button::resize_tool(int x, int y)
{
	resize(x, y);
}

BC_Button::resize(int x, int y)
{ 
	resize_window(x, y, w, h);
	draw(); 
}

BC_Button::cursor_left_()
{
	if(highlighted)
	{
		if(cursor_x < 0 || cursor_x > w ||
			 cursor_y < 0 || cursor_y > h)
		{   // draw unhighlighted
			highlighted = 0;
			draw();
		}
	}
}

BC_Button::button_press_()
{
	if(cursor_x > 0 && cursor_x < w
		 && cursor_y > 0 && cursor_y < h)
	{
  	if(top_level->event_win != top_level->win) return 0;
		down = button_down = cursor_over = 1;
		draw();
		if(top_level->active_tool) top_level->active_tool->deactivate();
		button_press();
	}
}

BC_Button::cursor_motion_()
{
	if(button_down)
	{
		if(cursor_over)
		{
			if(cursor_x < 0 || cursor_x > w ||
				 cursor_y < 0 || cursor_y > h)
			{
				down = 0;
				cursor_over = 0;
				highlighted = 0;
				draw();
			}
		}
		else
		{
			if(cursor_x > 0 && cursor_x < w &&
				 cursor_y > 0 && cursor_y < h)
			{
				down = 1;
				cursor_over = 1;
				highlighted = 1;
				draw();
			}
		}
	}
	else
	{
  		if(top_level->button_down) return 0;
  		if(top_level->event_win != top_level->win) return 0;

		if(highlighted)
		{
			if(cursor_x < 0 || cursor_x > w ||
				 cursor_y < 0 || cursor_y > h)
			{   // draw highlighted
				highlighted = 0;
				draw();
			}
		}
		else
		{
			if(cursor_x > 0 && cursor_x < w &&
				 cursor_y > 0 && cursor_y < h)
			{   // draw highlighted
				highlighted = 1;
				draw();
			}
		}
	}
}

BC_Button::repeat_()
{
	if(down) return repeat();     // go to user
	else return 0;
}

BC_Button::button_release_()
{
	if(button_down)
	{
		if(down)
		{
			down = 0;
			handle_event();      // call user event handler
			// highlighted = 0;     // disabled windows can't update button
			draw();
			button_release();
		}
		button_down = 0;
	}
}

BC_Button::keypress_event_() { keypress_event(); }

BC_Button::update(char *text)
{
	strcpy(this->text, text);
	draw();
}

// ===================================================================

BC_BigButton::BC_BigButton(int x, int y, char *text)
 : BC_Button(x, y, text) { }

BC_BigButton::create_tool_objects()
{
	h = 25; w = XTextWidth(top_level->largefont, text, strlen(text)) + 25;
	create_window(x, y, w, h, MEGREY);
	draw();
}

BC_BigButton::draw()
{
	if(!down)
	{
		if(highlighted) draw_3d_big(1, 1, w-2, h-2, WHITE, LTGREY, DKGREY);
		else draw_3d_big(1, 1, w-2, h-2, LTGREY, MEGREY, DKGREY);
	}
	else
	{
		draw_3d_big(1, 1, w-2, h-2, DKGREY, MDGREY, WHITE);
	}
	set_color(BLACK);
	draw_rectangle(0, 0, w, h);
	draw_center_text(w / 2, h - 7, text, top_level->largefont);
	flash();
}

BC_SmallButton::BC_SmallButton(int x, int y, char *text)
 : BC_Button(x, y, text) { }

BC_SmallButton::BC_SmallButton(int x, int y, int w, char *text)
 : BC_Button(x, y, w, text) { }

BC_SmallButton::create_tool_objects()
{
	h = 20; 
	if(w == 0) w = XTextWidth(top_level->largefont, text, strlen(text)) + 20;
	create_window(x, y, w, h, MEGREY);
	draw();
}

BC_SmallButton::draw()
{
	if(!down)
	{
		if(highlighted) draw_3d_small(0, 0, w, h, WHITE, LTGREY, DKGREY);
		else draw_3d_small(0, 0, w, h, LTGREY, MEGREY, DKGREY);
	}
	else
	{
		draw_3d_small(0, 0, w, h, DKGREY, MDGREY, WHITE);
	}
	set_color(BLACK);
	draw_center_text(w / 2, h - 5, text, top_level->largefont);
	flash();
}

BC_UpTriangleButton::BC_UpTriangleButton(int x, int y, int w, int h)
 : BC_Button(x, y, "")
{ this->h = h; this->w = w; }

BC_UpTriangleButton::create_tool_objects()
{
	create_window(x, y, w, h, subwindow->color);
	draw();
}

BC_UpTriangleButton::draw()
{
  static int x1, y1, x2, y2, x3, y3;
	static XPoint point[3];

  x1 = 1; y1 = 0; x2 = w / 2;
  y2 = h - 1; x3 = w - 1;

  point[0].x = x2; point[0].y = y1; point[1].x = x3;
  point[1].y = y2; point[2].x = x1; point[2].y = y2;

	if(down)
	{
		set_color(MDGREY);
	}
	else
	{
  	if(highlighted) set_color(LTGREY);
  	else set_color(MEGREY);
	}
	  
  XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);
	if(down)
	{
  	set_color(DKGREY);
	}
	else
	{
		set_color(WHITE);
	}
  draw_line(x2, y1, x1, y2);
	if(down)
	{
  	set_color(WHITE);
	}
	else
	{
		set_color(DKGREY);
	}
  draw_line(x2, y1, x3, y2);
  draw_line(x3, y2, x1, y2);
	flash();
}

BC_DownTriangleButton::BC_DownTriangleButton(int x, int y, int w, int h)
 : BC_Button(x, y, "")
{ this->h = h; this->w = w; }

BC_DownTriangleButton::create_tool_objects()
{
	create_window(x, y, w, h, subwindow->color);
	draw();
}

BC_DownTriangleButton::draw()
{
  static int x1, y1, x2, y2, x3, y3;
  static XPoint point[3];

  x1 = 1; x2 = w / 2;
  x3 = w - 1; y1 = 0; y2 = h - 1;

  point[0].x = x2; point[0].y = y2; point[1].x = x3;
  point[1].y = y1; point[2].x = x1; point[2].y = y1;
	
	if(down)
	{
  	set_color(MDGREY);
	}
	else
	{
		if(highlighted) set_color(LTGREY);
  	else set_color(MEGREY);
  }
  XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);
	if(down)
	{
		set_color(WHITE);
	}
	else
	{
		set_color(DKGREY);
	}
  draw_line(x3, y1, x2, y2);
	if(!down)
	{
		set_color(WHITE);
	}
	else
	{
		set_color(DKGREY);
	}
  draw_line(x3, y1, x1, y1);
  draw_line(x1, y1, x2, y2);
	flash();
}

BC_RecButton::BC_RecButton(int x, int y, int w, int h)
 : BC_Button(x, y, "")
{ this->h = h; this->w = w; }

BC_RecButton::create_tool_objects()
{
	create_window(x, y, w, h, subwindow->color);
	draw();
}

BC_RecButton::draw()
{
	if(down)
	{
		draw_3d_small(0, 0, w, h, DKGREY, MDGREY, LTGREY);
	}
	else
	{
		if(highlighted) draw_3d_small(0, 0, w, h, WHITE, LTGREY, DKGREY);
		else draw_3d_small(0, 0, w, h, LTGREY, MEGREY, DKGREY);
	}
	
	set_color(RED);
  XFillArc(top_level->display, pixmap, top_level->gc, w / 5, w / 5, w - 2 * w / 5, h - 2 * h / 5, 0*64, 360*64);
	flash();
}

BC_DuplexButton::BC_DuplexButton(int x, int y, int w, int h)
 : BC_Button(x, y, "")
{ this->h = h; this->w = w; }

BC_DuplexButton::create_tool_objects()
{
	create_window(x, y, w, h, subwindow->color);
	draw();
}

BC_DuplexButton::draw()
{
	if(down)
	{
		draw_3d_small(0, 0, w, h, DKGREY, MDGREY, LTGREY);
	}
	else
	{
		if(highlighted) draw_3d_small(0, 0, w, h, WHITE, LTGREY, DKGREY);
		else draw_3d_small(0, 0, w, h, LTGREY, MEGREY, DKGREY);
	}

// draw record

	set_color(RED);
  XFillArc(top_level->display, pixmap, top_level->gc, w / 6, h / 5, w / 2 - w / 6, h - h / 5 - h / 5, 180*64, 360*64);

// draw carrot

  static XPoint point[3];

	set_color(GREEN);
  point[0].x = w / 2; point[0].y = h / 5; point[1].x = w / 2;
  point[1].y = h - h / 5; point[2].x = w - w / 6; point[2].y = h / 2;

  XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);
	flash();
}

// ======================================= playback buttons

// this is a base class used by all play buttons and should not by used
BC_PlayButton::BC_PlayButton(int x, int y, int w, int h)
 : BC_Button(x, y, "")
{
	this->h = h; this->w = w; orange = 0;
}

BC_PlayButton::create_tool_objects()
{
	create_window(x, y, w, h, subwindow->color);
	draw();
}

BC_PlayButton::update(int value)
{
	mode = value;
	draw();
}

BC_PlayButton::set_orange(int value)
{
	this->orange = value;
}

BC_PlayButton::reset_button()
{
	if(orange) set_orange(0);
	update(1); 
}

BC_PlayButton::draw()
{
// draw down
	if(down || mode == 0)
	{
		draw_3d_small(0, 0, w, h, DKGREY, MDGREY, LTGREY);
	}
	else
// draw up and highlighted
	{
		if(orange)
		{
			if(highlighted) draw_3d_small(0, 0, w, h, WHITE, LTPINK, DKGREY);
			else draw_3d_small(0, 0, w, h, LTGREY, PINK, DKGREY);
		}
		else
		{
			if(highlighted) draw_3d_small(0, 0, w, h, WHITE, LTGREY, DKGREY);
			else draw_3d_small(0, 0, w, h, LTGREY, MEGREY, DKGREY);
		}
	}

// play mode
	if(mode == 1)
	{    // draw polygon
		draw_polygon();
	}
	else 
// paused
	{           // draw pause
		set_color(BLACK);
  	XFillRectangle(top_level->display, pixmap, top_level->gc, w / 5, h / 5, w / 5, h - 2 * h / 5);
  	XFillRectangle(top_level->display, pixmap, top_level->gc, 3 * w / 5, h / 5, w / 5, h - 2 * h / 5);
	}
	flash();
}






BC_ForwardButton::BC_ForwardButton(int x, int y, int w, int h)
 : BC_PlayButton(x, y, w, h)
{ mode = 1; }     // default to play

BC_ForwardButton::draw_polygon()
{
	static XPoint point[3];

	set_color(GREEN);
	point[0].x = w / 5; point[0].y = h / 5; point[1].x = w / 5;
	point[1].y = h - h / 5; point[2].x = w - w / 5; point[2].y = h / 2;

	XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);
}






BC_FastForwardButton::BC_FastForwardButton(int x, int y, int w, int h)
 : BC_PlayButton(x, y, w, h)
{ mode = 1; }     // default to fast forward

BC_FastForwardButton::draw_polygon()
{
  static int x1, x2, x3, y1, y2, y3;
  static XPoint point[3];

	x1 = w / 5; x2 = w / 2; x3 = w - w / 5;
  y1 = h / 5; y2 = h - h / 5; y3 = h / 2;

  point[0].x = x1; point[0].y = y1; point[1].x = x1;
  point[1].y = y2; point[2].x = x2; point[2].y = y3;

	set_color(BLACK);
  XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);

  point[0].x = x2; point[0].y = y1; point[1].x = x2;
  point[1].y = y2; point[2].x = x3; point[2].y = y3;

	set_color(BLACK);
  XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);
}







BC_ReverseButton::BC_ReverseButton(int x, int y, int w, int h)
 : BC_PlayButton(x, y, w, h)
{ mode = 1; }     // default to fast forward

BC_ReverseButton::draw_polygon()
{
	static XPoint point[3];

	point[0].x = w - w / 5; point[0].y = h / 5; point[1].x = w / 5;
	point[1].y = h / 2; point[2].x = w - w / 5; point[2].y = h - h / 5;

	set_color(GREEN);
	XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);
}







BC_FastReverseButton::BC_FastReverseButton(int x, int y, int w, int h)
 : BC_PlayButton(x, y, w, h)      // Fast play button
{ mode = 1; }

BC_FastReverseButton::draw_polygon()
{
  static int x1, x2, x3, y1, y2, y3;
  static XPoint point[3];

	x3 = w / 5; x2 = w / 2; x1 = w - w / 5;
  y1 = h / 5; y2 = h - h / 5; y3 = h / 2;

  point[0].x = x1; point[0].y = y1; point[1].x = x1;
  point[1].y = y2; point[2].x = x2; point[2].y = y3;

	set_color(BLACK);
  XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);

  point[0].x = x2; point[0].y = y1; point[1].x = x2;
  point[1].y = y2; point[2].x = x3; point[2].y = y3;

	set_color(BLACK);
  XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);
}








BC_StopButton::BC_StopButton(int x, int y, int w, int h)
 : BC_Button(x, y, "")
{
	this->h = h; this->w = w;
}

BC_StopButton::create_tool_objects()
{
	create_window(x, y, w, h, subwindow->color);
	draw();
}

BC_StopButton::draw()
{
	if(down)
	{
		draw_3d_small(0, 0, w, h, DKGREY, MDGREY, LTGREY);
	}
	else
	{
		if(highlighted) draw_3d_small(0, 0, w, h, WHITE, LTGREY, DKGREY);
		else draw_3d_small(0, 0, w, h, LTGREY, MEGREY, DKGREY);
	}
	set_color(BLACK);
  XFillRectangle(top_level->display, pixmap, top_level->gc, w / 5, h / 5, w - 2 * w / 5, h - 2 * h / 5);
	flash();
}

BC_RewindButton::BC_RewindButton(int x, int y, int w, int h)
 : BC_Button(x, y, "")
{ this->h = h; this->w = w; }

BC_RewindButton::create_tool_objects()
{
	create_window(x, y, w, h, subwindow->color);
	draw();
}

BC_RewindButton::draw()
{
	if(down)
	{
		draw_3d_small(0, 0, w, h, DKGREY, MDGREY, LTGREY);
	}
	else
	{
		if(highlighted) draw_3d_small(0, 0, w, h, WHITE, LTGREY, DKGREY);
		else draw_3d_small(0, 0, w, h, LTGREY, MEGREY, DKGREY);
	}

  static int x1, x2, y1, y2, y3;
  static XPoint point[3];

	x1 = 2 * (w / 5); x2 = w - w / 5;
	y1 = h / 5; y2 = h - h / 5; y3 = h / 2;

  point[0].x = x2; point[0].y = y1; point[1].x = x2;
  point[1].y = y2; point[2].x = x1; point[2].y = y3;

	set_color(BLACK);
  XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);
  XFillRectangle(top_level->display, pixmap, top_level->gc, w / 5, y1, w / 5, y2 - y1);
	flash();
}

BC_EndButton::BC_EndButton(int x, int y, int w, int h)
 : BC_Button(x, y, "")
{
	this->h = h; this->w = w;
}

BC_EndButton::create_tool_objects()
{
	create_window(x, y, w, h, subwindow->color);
	draw();
}

BC_EndButton::draw()
{
	if(down)
	{
		draw_3d_small(0, 0, w, h, DKGREY, MDGREY, LTGREY);
	}
	else
	{
		if(highlighted) draw_3d_small(0, 0, w, h, WHITE, LTGREY, DKGREY);
		else draw_3d_small(0, 0, w, h, LTGREY, MEGREY, DKGREY);
	}

  static int x1, x2, y1, y2, y3;
  static XPoint point[3];

	x1 = w / 5; x2 = w - 2 * (w / 5);
  y1 = h / 5; y2 = h - h / 5; y3 = h / 2;

  point[0].x = x1; point[0].y = y1; point[1].x = x1;
  point[1].y = y2; point[2].x = x2; point[2].y = y3;

	set_color(BLACK);
  XFillPolygon(top_level->display, pixmap, top_level->gc, (XPoint *)point, 3, Nonconvex, CoordModeOrigin);
  XFillRectangle(top_level->display, pixmap, top_level->gc, x2, y1, w / 5, y2 - y1);
	flash();
}
