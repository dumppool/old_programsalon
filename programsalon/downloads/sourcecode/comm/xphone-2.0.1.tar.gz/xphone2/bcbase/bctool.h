#ifndef BCTOOL_H
#define BCTOOL_H

class BC_Tool;
class BC_Tools;
class BC_ToolList;
class BC_ToolItem;

#include "bcbitmap.h"
#include "bcfont.h"
#include "bcsubwindow.h"
#include "bcwindow.h"
#include "linklist.h"

class BC_Tool
{
public:
	BC_Tool(int x_, int y_, int w_, int h_);
	virtual ~BC_Tool();

	virtual create_objects() {};           // user creates derived objects here
	
	activate();                   // activate this tool by deactivating the current active_tool and pointing active_tool here
	create_window(int x, int y, int w, int h, int color);    // tool does this from its create_objects()
	resize_window(int x, int y, int w, int h);        // tool calls this to resize its window
	enable();
	disable();
	disable_window();        // disable and enable the top window
	enable_window();
	lock_window();          // lock and unlock the top window for threading
	unlock_window();

// ====================== tool routines

// get pointers for all tools
	create_tool_objects(BC_Window *top_level, BC_WindowBase *subwindow);

	virtual create_tool_objects();         // the tool's create objects routine
	virtual flash();
	virtual flash(int x_, int y_, int w_, int h_);
	virtual activate_() {};       // activation routine for tool being activated
	virtual deactivate() {};       // alternative cleanup routine for tool being deactivated by activate()
	virtual draw() {};            
	
// ====================== tool event dispatch handlers
// for dispatcher
	motion_event_dispatch();
	cursor_left_dispatch();
	expose_event_dispatch();
	button_press_dispatch();
	button_release_dispatch();
	repeat_dispatch();      // for updating scrollbars

// ======================= for tools
	virtual cursor_left_();
	virtual resize_event_(int w, int h) {};         // tool defined handler for resize from subwindow
	virtual button_press_() {};
	virtual cursor_motion_() {};         // for tool
	virtual button_release_() {};
	virtual keypress_event_() {};
	virtual change_y_(int y) {};
	virtual repeat_();
	
// ====================== user event handlers

	virtual handle_event() {};     // user defined event handler
	virtual button_press() {};     // user defined 
	virtual button_release() {};     // user defined 
	virtual keypress_event() {};   // user defined key binding
	virtual repeat() {};       // msut return 0 to avoid trapping or 1 to trap

// ====================== flags
	change_y(int y);      // change the value of y by this amount
	set_y(int y);
	set_x(int x);
	is_active();
	get_keypress();          // which key was pressed
	get_buttonpress();       // which button was pressed
	ctrl_down();
	shift_down();
	trap_keypress();
	set_repeat(long repeat = 50000);
	unset_repeat();
	set_done(int return_value);       // quit the top window
	
// ============================= drawing
// draw a segment of a frame anywhere on the canvas
	draw_bitmap(VFrame *frame, 
			int in_x1, int in_y1, int in_x2, int in_y2, 
			int out_x1, int out_y1, int out_x2, int out_y2, GC *gc = 0);
	draw_3d_diamond(int x1, int y1, int w, int h, int light, int middle, int shadow);
	draw_3d_big(int x1, int y1, int w, int h, int light, int middle, int shadow);
	draw_3d_small(int x1, int y1, int w, int h, int light, int middle, int shadow);
	draw_center_text(int x, int y, char *text, XFontStruct *font);
	draw_text(int x_, int y_, char *text);
	draw_vertical_text(int x, int y, char *text, int fgcolor, int bgcolor, GC *gc = 0);
	draw_rectangle(int x_, int y_, int w_, int h_);
	draw_box(int x_, int y_, int w_, int h_);
	draw_line(int x1, int y1, int x2, int y2);
	draw_3d_line(int x1, int y1, int x2, int y2, int color1, int color2, GC *gc = 0);
	draw_disc(int x, int y, int w, int h, GC *gc = 0);
	
	set_inverse();
	set_opaque();
	set_color(int color, GC *gc = 0);
	get_text_width(XFontStruct *font, char *text);
	get_text_height(XFontStruct *font);
	get_text_ascent(XFontStruct *font);
	get_text_height(int font);
	get_text_ascent(int font);
	get_text_descent(int font);
	set_font(XFontStruct *font);
	get_text_width(int font, char *text);
	set_font(int font);
	slide_left(int distance);
	slide_right(int distance);
	slide_up(int distance);
	slide_down(int distance);









// =============== data

	virtual uses_text();        // set to 1 if tool uses text input
	BC_Window *top_level;
	BC_WindowBase *subwindow;
	BC_ToolItem *list_item;      // list item to delete when this is deleted
	Window win; 		  // tool window
	Pixmap pixmap;  	  // tool pixmap

	int color;            // color of tool background
	int cursor_x, cursor_y;     // position of cursor relative to tool
	int x, y, w, h;        // dimensions of tool
	int enabled;            // tool is on
private:
	get_temp_pixmap(int w, int h);
	get_temp_bitmap(int w, int h);
	BC_Bitmap *temp_bitmap;
	Pixmap temp_pixmap;       // scratch pixmap for rotating
	int temp_pixmap_w, temp_pixmap_h;
	int use_shm;
};

class BC_ToolItem : public ListItem<BC_ToolItem>
{
public:
	BC_ToolItem(BC_Tool *pointer);
	virtual ~BC_ToolItem();
	
	BC_Tool *pointer;
};

class BC_ToolList : public List<BC_ToolItem>
{
public:
	BC_ToolList();
	virtual ~BC_ToolList();
	
	append(BC_Tool *tool);
	remove(BC_Tool *tool);
};

#endif
