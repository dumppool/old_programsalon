#ifndef VCONFIG_H
#define VCONFIG_H

// size of a channel
#define VWORD unsigned short int

// maximum value of a channel
#define VMAX 65535

typedef struct {
	VWORD red;
	VWORD green;
	VWORD blue;
	VWORD alpha;
} VPixel;


class VFrame
{
public:
	VFrame(int w, int h);
	~VFrame();
	
	transfer_from(VFrame *frame, long position, int center_x, int center_y, float zoom, float opacity, int fast);
	VPixel **rows;
	int w, h;

private:
	transfer_enlarge(VFrame *input, int in_row1, int out_row1, int in_height, int out_height,
				int in_column1, int out_column1, int in_width, int out_width, float opacity, int fast);
	get_enlarge_tables(int *input_table_x, 
		int *input_table_y, 
		float *input_fraction_table_x, 
		float *input_fraction_table_y, 
		int in_width, 
		int out_width, 
		int in_height, 
		int out_height);
	transfer_reduce(VFrame *input, int in_row1, int out_row1, int in_height, int out_height,
				int in_column1, int out_column1, int in_width, int out_width, float opacity, int fast);
	clear_row(VPixel *row, int width);
	get_reduce_tables(int *output_table_x, 
		int *output_table_y, 
		float *output_fraction_table_x,
		float *output_fraction_table_y,
		int in_width, 
		int out_width, 
		int in_height, 
		int out_height);
	get_fast_reduce_tables(int *output_table_x,
		int *output_table_y,
		int in_width,
		int out_width,
		int in_height,
		int out_height);
	reduce_row(VPixel *output, VPixel *input, int in_width, int *output_table_x, float *output_fraction_table_x, float y_fraction);
	reduce_row_fast(VPixel *output, VPixel *input, int *input_table_x, int out_width, float opacity);
	enlarge_row(VPixel *output, VPixel *input, int out_columns, int *input_table_x, float *input_fraction_table_x);
	enlarge_row_fast(VPixel *output, VPixel *input, int out_columns, int *input_table_x);
	transfer_row_enlarge(VPixel *output_row, VPixel *previous_row, VPixel *next_row, int columns, float input_ratio, float opacity);
	transfer_row_direct(VPixel *output, VPixel *input, int out_columns, float opacity);
	overlay_pixel(VPixel *output, VPixel *input, float opacity);
};

#endif
