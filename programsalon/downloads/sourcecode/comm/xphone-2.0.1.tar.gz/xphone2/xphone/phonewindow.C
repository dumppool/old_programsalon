#include "phone.h"
#include "phoneprefs.h"
#include "phonewindow.h"

PhoneWindow::PhoneWindow(Phone *phone)
 : BC_Window("", MEGREY, "XPhone 2.0", 420, PRESETS * 30 + 50, 420, PRESETS * 30 + 20, 0, 0)
{ this->phone = phone; }

PhoneWindow::~PhoneWindow()
{
	delete menubar;
	
	for(int i = 0; i < PRESETS; i++) delete preset[i];
	for(int i = 0; i < PRESETS; i++) delete preset_dial[i];
	for(int i = 0; i < 10; i++) number[i];
	delete pnd;
	delete star;
	for(int i = 0; i < 4; i++) delete volume[i];
	delete off;
	delete on;
	delete flash;
}

PhoneWindow::create_objects()
{
	int i, y, x;
	char string[256];
	
	add_tool(menubar = new PhoneMenu(phone));
	menubar->create_objects();

// keypad
	for(y = 40, i = 1; i < 10; y += 30)
	{
		for(x = 15; x < 95; x += 35, i++)
		{
			sprintf(string, "%d", i);
			add_tool(number[i] = new PhoneButton(phone, x, y, string));
		}
	}
	
	add_tool(pnd = new PhoneButton(phone, 15, y, "#"));
	add_tool(number[0] = new PhoneButton(phone, 50, y, "0"));
	add_tool(star = new PhoneButton(phone, 85, y, "*"));
	
	y += 60;
	add_tool(on = new PhoneOnButton(phone, 15, y));
	add_tool(off = new PhoneOffButton(phone, 70, y));
	add_tool(flash = new PhoneFlashButton(phone, 125, y));

// volume
	add_tool(new BC_Title(130, 40, "Volume"));
	for(i = 0, y = 70; i < 4; i++, y += 25)
	{
		sprintf(string, "%d", i + 1);
		add_tool(volume[i] = new PhoneVolumeButton(phone, y, i, string));
	}

// presets
	for(i = 0, y = 40; i < PRESETS; i++, y += 30)
	{
		add_tool(preset[i] = new PhonePreset(phone, i, y));
		add_tool(preset_dial[i] = new PhonePresetDial(phone, i, y));
	}
}

PhoneWindow::close_event()
{
	set_done(0);
}


PhoneWindow::keypress_event()
{
	char key_pressed[5];     // argument for dial
	int key = get_keypress();
	sprintf(key_pressed, "%c", key);
	
	
	switch(key)
	{
		case 0:
			break;

		case ESC:
			set_done(0);	
			break;

		default:
			if(!phone->test_character(key))
			{
				phone->dial(key_pressed);
			}
			break;
	}
}

PhoneMenu::PhoneMenu(Phone *phone)
 : BC_MenuBar(0, 0, phone->gui->w)
{ this->phone = phone; }

PhoneMenu::~PhoneMenu()
{
	delete file;
}

PhoneMenu::create_objects()
{
	add_menu(file = new PhoneFileMenu(phone));
	file->create_objects();
}

PhoneFileMenu::PhoneFileMenu(Phone *phone)
 : BC_Menu("XPhone")
{ this->phone = phone; }

PhoneFileMenu::~PhoneFileMenu()
{
	delete quit;
}

PhoneFileMenu::create_objects()
{
	add_menuitem(new PhonePreferences(phone));
	add_menuitem(quit = new PhoneQuit(phone));
}

PhoneQuit::PhoneQuit(Phone *phone)
 : BC_MenuItem("Quit", "Ctrl-q", 17)
{ this->phone = phone; }

PhoneQuit::~PhoneQuit()
{
}

PhoneQuit::handle_event()
{
	set_done(0);
}

PhonePreferences::PhonePreferences(Phone *phone)
 : BC_MenuItem("Preferences...")
{
	this->phone = phone;
	thread = new PhonePrefsThread(phone);
}

PhonePreferences::~PhonePreferences()
{
	delete thread;
}

PhonePreferences::handle_event()
{
	thread->start();
}



PhonePreset::PhonePreset(Phone *phone, int number, int y)
 : BC_TextBox(200, y, 150, phone->preset[number])
{ this->phone = phone; this->number = number; }

PhonePreset::~PhonePreset()
{
}

PhonePreset::handle_event()
{
	strcpy(phone->preset[number], get_text());
}



PhonePresetDial::PhonePresetDial(Phone *phone, int number, int y)
 : BC_BigButton(360, y, "Dial")
{ this->phone = phone; this->number = number; }

PhonePresetDial::~PhonePresetDial()
{
}

PhonePresetDial::handle_event()
{
	char string[1024];
	if(!phone->fix_preset(phone->preset[number], string))
	{
		phone->dial(string);
	}
}

PhoneButton::PhoneButton(Phone *phone, int x, int y, char *string)
 : BC_SmallButton(x, y, string)
{ this->phone = phone; strcpy(this->string, string); }

PhoneButton::~PhoneButton()
{
}

PhoneButton::handle_event()
{
	phone->dial(string);
}


PhoneVolumeButton::PhoneVolumeButton(Phone *phone, int y, int number, char *string)
 : BC_BigButton(140, y, string)
{ this->phone = phone; this->number = number; }

PhoneVolumeButton::~PhoneVolumeButton()
{
}

PhoneVolumeButton::handle_event()
{
	phone->set_volume(number);
}



PhoneOffButton::PhoneOffButton(Phone *phone, int x, int y)
 : BC_BigButton(x, y, "Off")
{ this->phone = phone; }

PhoneOffButton::~PhoneOffButton()
{
}

PhoneOffButton::handle_event()
{
	phone->go_off();
}

PhoneOnButton::PhoneOnButton(Phone *phone, int x, int y)
 : BC_BigButton(x, y, "On")
{ this->phone = phone; }

PhoneOnButton::~PhoneOnButton()
{
}

PhoneOnButton::handle_event()
{
	phone->go_on();
}


PhoneFlashButton::PhoneFlashButton(Phone *phone, int x, int y)
 : BC_BigButton(x, y, "Flash")
{ this->phone = phone; }

PhoneFlashButton::~PhoneFlashButton()
{
}

PhoneFlashButton::handle_event()
{
	phone->flash_it();
}
