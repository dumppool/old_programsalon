#include "phone.h"
#include <ctype.h>


Phone::Phone()
{
	is_on = 0;
	cur_volume = 3;
	is_debugging = 0;
}

Phone::~Phone()
{
	delete gui;
	delete defaults;
}

Phone::create_objects()
{
	defaults = new Defaults("~/.phonerc");
	defaults->load();
	
	char string[256];
	for(int i = 0; i < PRESETS; i++)
	{
		sprintf(preset[i], "");
		sprintf(string, "PRESET%d", i);
		defaults->get(string, preset[i]);
	}

	gui = new PhoneWindow(this);
	gui->create_objects();
	cur_volume = defaults->get("VOLUME", cur_volume);
	duplex = (defaults->get("DUPLEX", 0) ? FULLDUPLEX : HALFDUPLEX);
	sprintf(phone_path, "%s", PHONE);
	sprintf(chat_path, "%s", CHAT);
	defaults->get("PHONEPATH", phone_path);
	defaults->get("CHATPATH", chat_path);
}

Phone::run()
{
	start_modem();
	gui->run_window();

	defaults->update("VOLUME", cur_volume);	
	defaults->update("DUPLEX", duplex);
	defaults->update("PHONEPATH", phone_path);
	defaults->update("CHATPATH", chat_path);

	char string[256];
	for(int i = 0; i < PRESETS; i++)
	{
		sprintf(string, "PRESET%d", i);
		defaults->update(string, preset[i]);
	}
	defaults->save();
	cleanup();
}

Phone::send(char *string, char *expect)
{
	char string_[256];

	sprintf(string_, "%s \'\' \'%s\' \'%s\' <%s >%s", chat_path, string, expect, phone_path, phone_path);   // JP
	
	//printf("[%s]", string_); 
	//fflush(stdout); // JP
	system(string_);
	
	//printf("\n");  // JP
}

Phone::start_modem()
{
  if(duplex)
  {
	  send("AT&F");
  }
  else
  {
	  send("atm2");
  }

	set_volume(cur_volume);
	is_on = 0;
}

Phone::cleanup()
{
	if(duplex)
	{
		 send("ATM1");
		 send("ATL1");
	}
	else
	{
		send("atm1");
		send("atl0");
	}
}

Phone::go_on()
{
	is_on = 1;
	if(duplex)
	{
		send("ATZ");
        send("ATM2");
        send("AT#CLS=8#VRN=0#VLS=6#VBT=1");
        send("ATH1");
	}
	else
	{
		send("ath1");
	}
}

Phone::go_off()
{
	if(duplex)
	{
		send("ATH0");
	}
	else
	{
		send("ath0");
	}

	is_on = 0;
}

Phone::flash_it()
{
	if(is_on)
	{
		if(duplex)
		{
			send("atdt!;");
		}
		else
		{
			send("atdt!;");
		}
	}
}

Phone::set_volume(int level)
{
	cur_volume = level;
	if(duplex)
	{
        char string[10];
        sprintf(string, "ATL%d", level);
        send(string);
	}
	else
	{
		char string[10];
		sprintf(string, "atl%d", level);
		send(string);
	}
}

Phone::dial(char *string)
{
	if(is_on)
	{
		char string_[256];

		strcpy(string_, string);
		lton(string_);       // replace letters with numbers

		if(duplex)
		{
				char string__[256];
				if(string_[1])
				{
					sprintf(string__, "ATDT%s", string_);
                	send(string__, "VCON");
                	send("AT#SPK=1,15,1", "OK");
				}
				else
				{
					sprintf(string__, "AT#SPK=2,16,1#VTS=%s#SPK=1,15,1", string_);
					send(string__);
				}
		}
		else
		{
			char string__[256];
			sprintf(string__, "atdt%s;", string_);
			send(string__);
		}
	}
}

Phone::fix_preset(char *textin, char *textout) // make sure preset is a legal number
{
	int i, o;
	for(i = 0, o = 0; textin[i] != 0;)
	{
		char c = textin[i];

		if(test_character(c))
		{ // ================= illegal character
			if(c == '(')
			{ // ===================== skip comment
				for(; c != ')' && c != 0; i++)
				{
					c = textin[i];
				}
				if(c == 0) i--; // get 0 back
			}
			else
			{ // ====================== skip input character
				i++;
			}
		}
		else
		{
			textout[o++] = textin[i++];
		}
	}
	textout[o] = 0;

	if(!strlen(textout)) return 1; // nothing passed
	else return 0;
}

Phone::test_character(char c)    // return 1 if character is invalid
{
	if((tolower(c) < 97 || tolower(c) > 121 || tolower(c) == 'q') && (c < 48 || c > 57) && c != 35 && c != 42 && c != ',')
	{ // ================= illegal character
		return 1;
	}
	return 0;      // legal character
}

Phone::lton(char *string)        // convert letters to phone digits
{
	int len = strlen(string);
	char* num[10] = {"", "", "abc", "def", "ghi", "jkl", "mno", "prs", "tuv", "wxy"};
	
	for(int i = 0; i < len; i++)
	{
		char c = tolower(string[i]);
		
		if(c >= 97 && c <= 121)
		{
			for(int j = 0, result = 0; j < 10 && !result; j++)
			{            // test each number
				for(int k = 0; k < strlen(num[j]) && !result; k++)
				{          // test each letter for each number
					if(c == num[j][k])
					{        // replace letter with number
						string[i] = j + 48;
						result = 1;
					}
				}
			}
		}
	}
	
	return 0;
}
