#ifndef HEADERS_H
#define HEADERS_H



class PhonePrefs;
class PhonePrefsThread;
class Phone;






#endif
