#ifndef PHONEPREFS_H
#define PHONEPREFS_H

class PrefFullDuplex;
class PrefHalfDuplex;
class PrefModemPath;
class PrefChatCommand;
class PrefOK;
class PrefCancel;



#include "bcbase.h"
#include "headers.h"

class PhonePrefsThread : public Thread
{
public:
	PhonePrefsThread(Phone *phone);
	~PhonePrefsThread();

	void run();

	Phone *phone;
};

class PhonePrefs : public BC_Window
{
public:
	PhonePrefs(Phone *phone);
	~PhonePrefs();
	
	create_objects();
	
	Phone *phone;
	PrefFullDuplex *full_duplex;
	PrefHalfDuplex *half_duplex;
	PrefModemPath *phone_path;
	PrefChatCommand *chat_path;
};

class PrefFullDuplex : public BC_Radial
{
public:
	PrefFullDuplex(Phone *phone, int x, int y);
	~PrefFullDuplex();
	
	handle_event();
	
	PrefHalfDuplex *half_duplex;
	Phone *phone;
};

class PrefHalfDuplex : public BC_Radial
{
public:
	PrefHalfDuplex(Phone *phone, int x, int y);
	~PrefHalfDuplex();
	
	handle_event();
	
	PrefFullDuplex *full_duplex;
	Phone *phone;
};

class PrefModemPath : public BC_TextBox
{
public:
	PrefModemPath(Phone *phone, int x, int y);
	~PrefModemPath();
	
	handle_event();
	
	Phone *phone;
};

class PrefChatCommand : public BC_TextBox
{
public:
	PrefChatCommand(Phone *phone, int x, int y);
	~PrefChatCommand();

	handle_event();

	Phone *phone;
};


class PrefOK : public BC_BigButton
{
public:
	PrefOK(Phone *phone, int x, int y);
	~PrefOK();
	
	handle_event();
	
	Phone *phone;
};

class PrefCancel : public BC_BigButton
{
public:
	PrefCancel(Phone *phone, int x, int y);
	~PrefCancel();
	
	handle_event();
	
	Phone *phone;
};

#endif
