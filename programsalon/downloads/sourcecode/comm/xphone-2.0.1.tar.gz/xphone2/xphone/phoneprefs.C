#include "phone.h"
#include "phoneprefs.h"

PhonePrefsThread::PhonePrefsThread(Phone *phone)
 : Thread()
{
	this->phone = phone;
}

PhonePrefsThread::~PhonePrefsThread()
{
}

void PhonePrefsThread::run()
{
	PhonePrefs window(phone);
	window.create_objects();
	int result = window.run_window();

	if(!result)
	{
		phone->duplex = window.full_duplex->get_value();
		strcpy(phone->phone_path, window.phone_path->get_text());
		strcpy(phone->chat_path, window.chat_path->get_text());
	}
}

PhonePrefs::PhonePrefs(Phone *phone)
 : BC_Window("", MEGREY, "XPhone Preferences", 390, 230, 390, 230)
{
	this->phone = phone;
}

PhonePrefs::~PhonePrefs()
{
}

PhonePrefs::create_objects()
{
	int x = 10, y = 10;
	
	add_tool(new BC_Title(x, y, "XPhone Preferences", TITLEFONT, RED));
	y += 30;
	add_tool(half_duplex = new PrefHalfDuplex(phone, x, y));
	x += 120;
	add_tool(full_duplex = new PrefFullDuplex(phone, x, y));
	half_duplex->full_duplex = full_duplex;
	full_duplex->half_duplex = half_duplex;

	x -= 120;
	y += 30;
	add_tool(new BC_Title(x, y, "Modem Device"));
	y += 30;
	add_tool(phone_path = new PrefModemPath(phone, x, y));
	y += 30;
	add_tool(new BC_Title(x, y, "Chat Command"));
	y += 30;
	add_tool(chat_path = new PrefChatCommand(phone, x, y));
	y += 30;
	add_tool(new PrefOK(phone, x, y));
	x += 200;
	add_tool(new PrefCancel(phone, x, y));
}




PrefFullDuplex::PrefFullDuplex(Phone *phone, int x, int y)
 : BC_Radial(x, y, 15, 15, phone->duplex, "Full Duplex (at your own risk)")
{
	this->phone = phone;
}
PrefFullDuplex::~PrefFullDuplex()
{
}
PrefFullDuplex::handle_event()
{
	if(get_value()) 
		half_duplex->update(0);
	else
		half_duplex->update(1);
}



PrefHalfDuplex::PrefHalfDuplex(Phone *phone, int x, int y)
 : BC_Radial(x, y, 15, 15, !phone->duplex, "Half Duplex")
{
	this->phone = phone;
}

PrefHalfDuplex::~PrefHalfDuplex()
{
}

PrefHalfDuplex::handle_event()
{
	if(get_value())
		full_duplex->update(0);
	else
		full_duplex->update(1);
}

PrefModemPath::PrefModemPath(Phone *phone, int x, int y)
 : BC_TextBox(x, y, 300, phone->phone_path)
{
	this->phone = phone;
}

PrefModemPath::~PrefModemPath()
{
}

PrefModemPath::handle_event()
{
}

PrefChatCommand::PrefChatCommand(Phone *phone, int x, int y)
 : BC_TextBox(x, y, 300, phone->chat_path)
{
	this->phone = phone;
}

PrefChatCommand::~PrefChatCommand()
{
}

PrefChatCommand::handle_event()
{
}




PrefOK::PrefOK(Phone *phone, int x, int y)
 : BC_BigButton(x, y, "OK")
{
	this->phone = phone;
}
PrefOK::~PrefOK()
{
}

PrefOK::handle_event()
{
	set_done(0);
}

PrefCancel::PrefCancel(Phone *phone, int x, int y)
 : BC_BigButton(x, y, "Cancel")
{
	this->phone = phone;
}

PrefCancel::~PrefCancel()
{
}

PrefCancel::handle_event()
{
	set_done(1);
}
