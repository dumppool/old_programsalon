#include "phone.h"

main()
{
	printf("xphone 2.0 (C) 1998 Adam Williams\n");
	printf("No warranties of any kind.\n");
	Phone phone;
	phone.create_objects();
	phone.run();
}
