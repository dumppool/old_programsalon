#ifndef PHONE_H
#define PHONE_H



// full duplex coding by J Poulsen <titan@cin-tech.ns.ca>

class Phone;
#define HALFDUPLEX 0
#define FULLDUPLEX 1



// number of presets
#define PRESETS 9

// device for modem
#define PHONE "/dev/modem"

// chat parameters
#define CHAT "/usr/sbin/chat"



#include "phonewindow.h"


class Phone
{
public:
	Phone();
	~Phone();
	
	create_objects();

	start_modem();
	cleanup();
	send(char *string, char *expect = "OK");
	run();
	go_on();
	go_off();
	flash_it();
	set_volume(int level);
	dial(char *string);
	fix_preset(char*, char*);
	test_character(char c);    // return 1 if character is invalid
	lton(char *string);        // convert letters to phone digits

	char preset[PRESETS][1024];
	Defaults *defaults;
	PhoneWindow *gui;
	int is_on, cur_volume;
	int is_debugging;
	int duplex;
	char phone_path[1024];
	char chat_path[1024];	
};

#endif
