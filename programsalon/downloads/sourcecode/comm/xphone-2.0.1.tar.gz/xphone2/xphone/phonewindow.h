#ifndef PHONEWINDOW_H
#define PHONEWINDOW_H

class PhoneWindow;

#include "bcbase.h"
#include "headers.h"

class PhoneMenu;
class PhonePreset;
class PhonePresetDial;
class PhoneButton;
class PhoneVolumeButton;
class PhoneOffButton;
class PhoneOnButton;
class PhoneFlashButton;

class PhoneWindow : public BC_Window
{
public:
	PhoneWindow(Phone *phone);
	~PhoneWindow();
	
	create_objects();
	keypress_event();
	close_event();
	
	PhoneMenu *menubar;
	PhonePreset *preset[PRESETS];
	PhonePresetDial *preset_dial[PRESETS];
	PhoneButton *number[10], *pnd, *star;
	PhoneVolumeButton *volume[4];
	PhoneOffButton *off;
	PhoneOnButton  *on;
	PhoneFlashButton *flash;

	Phone *phone;
};

class PhoneFileMenu;

class PhoneMenu : public BC_MenuBar
{
public:
	PhoneMenu(Phone *phone);
	~PhoneMenu();
	
	create_objects();

	PhoneFileMenu *file;
	Phone *phone;
};

class PhoneQuit;

class PhoneFileMenu : public BC_Menu
{
public:
	PhoneFileMenu(Phone *phone);
	~PhoneFileMenu();
	
	create_objects();
	
	PhoneQuit *quit;
	Phone *phone;
};


class PhoneQuit : public BC_MenuItem
{
public:
	PhoneQuit(Phone *phone);
	~PhoneQuit();

	handle_event();
	Phone *phone;
};

class PhonePreferences : public BC_MenuItem
{
public:
	PhonePreferences(Phone *phone);
	~PhonePreferences();

	handle_event();
	Phone *phone;
	PhonePrefsThread *thread;
};

class PhonePreset : public BC_TextBox
{
public:
	PhonePreset(Phone *phone, int number, int y);
	~PhonePreset();
	handle_event();
	
	Phone *phone;
	int number;
};

class PhonePresetDial : public BC_BigButton
{
public:
	PhonePresetDial(Phone *phone, int number, int y);
	~PhonePresetDial();
	handle_event();
	
	Phone *phone;
	int number;
};

class PhoneButton : public BC_SmallButton
{
public:
	PhoneButton(Phone *phone, int x, int y, char *string);
	~PhoneButton();
	handle_event();
	
	Phone *phone;
	char string[10];
};

class PhoneVolumeButton : public BC_BigButton
{
public:
	PhoneVolumeButton(Phone *phone, int y, int number, char *string);
	~PhoneVolumeButton();
	handle_event();
	
	Phone *phone;
	int number;
};

class PhoneOffButton : public BC_BigButton
{
public:
	PhoneOffButton(Phone *phone, int x, int y);
	~PhoneOffButton();
	handle_event();
	
	Phone *phone;
};

class PhoneOnButton : public BC_BigButton
{
public:
	PhoneOnButton(Phone *phone, int x, int y);
	~PhoneOnButton();
	handle_event();
	
	Phone *phone;
};

class PhoneFlashButton : public BC_BigButton
{
public:
	PhoneFlashButton(Phone *phone, int x, int y);
	~PhoneFlashButton();
	handle_event();
	
	Phone *phone;
};


#endif
