Dial - Freeware phone dialer for Win95 (not tested on NT or 98)
---------------------------------------------------------------------------------------------

Description
  Uses your PC's soundcard to audibly dial any phone number you give to it.
  This does not use a modem, just a properly configured soundcard and Win95.
  Complete source code with MSVC project file and resources are included. This
  program, and the source code, is public domain. Do whatever ya want with it.

Instructions
  This program is controlled completely via the command line.
    ex:  dial 5551212
  To actually dial that number, you'd enter that as the command line, put the end
  of the phone that you speak into within a few inches of your computer speakers,
  and press Enter. It'll play the phone number through your speakers in a form 
  that your phone will recognize

  You may use the following characters in the command line..
    Digits (0 through 9)
    Letters (a to z, A to Z)
    Pound (#) and star (*)
    Commas will cause a one second pause
    Periods will cause a 1/2 second pause
    Hyphens (-) and spaces are ignored.

Tips
  This program was designed with shortcuts in mind. To create a shortcut to it
  with the proper command line, right-click the .exe in Explorer and drag it out
  to your desktop. When you release the button a menu will pop up; choose 
  'Create Shortcut Here'. Now right-click the shortcut you've just created and
  choose 'Properties'. On the window that pops up, navigate to the 'Shortcut'
  tab. Now simply put the phone number you'd like this shortcut to dial after 
  'dial.exe' in the box next to 'Target'. Make sure to put a space between the
  filename in the box and the number you're telling it to dial. To complete
  the process, click OK and rename the shortcut so that it'll reflect who it will be
  calling. Do this for each phone number you'd like to have a shortcut to. Now
  whenever you want to call someone, you can simply pick up the phone and
  double click the appropriate shortcut.

Contact
  Send bug reports, questions, and comments to dial@bored.nu 