/*
danpage v0.6 Copyright (c) 1997 by Dan Baker (5/26/1997)
A program to send alphanumeric pages.

Tested on:
	Linux 2.0.28, Linux 2.0.30

To compile and install:
 Edit Makefile if necessary
 make or make all
 make install

Before first use:
 Edit sample file /danpage/danpagerc (phone numbers, modem init, etc.)
 Read man page (man danpage)

danpage takes input from stdin, so you can redirect a (small) file
to a pager, or pipe (short) program output to a pager.
example: danpage -d /dev/cua1 -p mygirl < /usr/pages/youre.so.sweet
     or  some_program | danpage -p 4564567 -r 15 -q

v0.5  - Original release
v0.6  -	Added -s option to suppress signature
	Began the Herculean Task of cleaning up my code.
	Added modem_restore string
	Added code to log optional text messages sent by server
	Added optional bits/sec setting via -b option
	(or bps parameter in rc file)
	Added -i option to ignore lockfiles
	Added -w option to wait for lockfile (if any) to go away
	Added -t option to truncate long messages
	Added -u option to replace sig with username@host
	Added code to respond to SIGTERM and SIGINT semi-gracefully
	Added code to send message as multiple packets
	Added -M option and splitsize parameter to send as multiple pages

----------
Note: As of May 1997, my provider does not accept multi-block pages,
so I haven't been able to test this feature. If your provider can
handle multiple packets, you should be able to send long messages
(up to 2048 chars) by using the -t commandline option
(ie: -t 512 for 512 char. messages) or the truncate parameter
(ie: truncate = 512) in your danpagerc file. By default, messages
are truncated to 80 characters, because that is my provider's limit.
The packet size defaults to 250, but can be changed with the -m option
or the packetsize parameter.
----------

Yet to do (maybe):
 Send a page to a group of pagers
 Mail error messages to sysadmin?
 Improve error messages and progress messages
 Run as a server with queues, etc.
 Implement clever user suggestions

Send suggestions, bug reports, and lavish praise to
danbaker@iquest.net
Sorry, I can't guarantee a reply :-(

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

#include <termios.h>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <sys/file.h>
#include <sys/types.h>
#include <pwd.h>

#define maxpacket 256
#define maxmsg 2048
#define maxstr maxmsg+80
#define maxlogstr maxstr+100
#define devbufsiz 200
#define hostnamelen 50

#define STX	0x02
#define ETX	0x03
#define EOT	0x04
#define ACK	0x06
#define LF	0x0A
#define CR	0x0D
#define NAK	0x15
#define ESC	0x1B
#define RS	0x1E
#define US	0x1F
#define FALSE 0
#define TRUE ~FALSE
#define PARM 0
#define ALIAS 1

/* --- You may need to edit this section ----------------------------------- */
char tempdir[] = "/tmp";
char lockdir[80] = "/var/lock";
char device[80] = "/dev/modem";            /* Can be overridden in danpagerc */
char modem_init[80] = "at&f&c1&d2e0q0m1x4";/* Can be overridden in danpagerc */
char modem_restore[80] = "at&f&c1&d2";     /* Can be overridden in danpagerc */
int bps = 1200; /* default modem port speed   Can be overridden in danpagerc */
int truncatesize = 80;                     /* Can be overridden in danpagerc */
int packetsize = 250;                      /* Can be overridden in danpagerc */
/* ------------------------------------------------------------------------- */

char version[] = "0.6";
char revdate[] = "5/26/1997";

uid_t uid;
struct passwd *pwuid;
char hostname[hostnamelen] = "unknown";
time_t timer;
speed_t speed;
struct tm *tblock;
struct termios t,t_old;
int i,j;
int modem, lock, rc_fd, logfile, templogfile, redials, result = 0;
int done, done_rc, found_alias, nosig, quiet, wait_for_lock, truncated = FALSE;
int split = FALSE;
int splitsize = maxmsg;
int ignorelock, username_sig = FALSE;
int lastpacket;
int retrans = 20;
int maxmessage, max_pkt_len, packetnum, segmentnum;
char sum[4];
char ch;
char message[maxmsg];
char segment[maxmsg];
char *message_ptr;
char *pkt_ptr;
char central[80] = "";
char account[80] = "";
char danpagerc1[80] = "";
char danpagerc2[80] = "";
char danpagelog[80] = "";
char templog[80] = "";
char sig[100] = "";
char line[200] = "";
char devbuf[devbufsiz] = "";
char str[maxstr] = "";
char status_msg[300] = "";
int statptr = 0;
char safestr[600]="";
char *ptr;
char *parmptr;
char *nxtparmptr;
char dial_prefix[] = "atdt";
char dial_suffix[] = "\r";
char hangup_str[] = "ath\r";
char autolog[] = "\033PG1\r";
char libdir[] = "/danpage";
char copyright[200];
char packet[maxpacket];
char lockfile1[80];
char lockfile2[80];
char my_name_is[80];

/* Function Prototypes: ----------------- */

void no_eol(char *str1);
void wrt_log(char *logmsg);
void cleanup(int code);
void abort(char *abortstr);
int init (void);
void timed_out(void);
void sig_term(void);
void sig_int(void);
void sig_segv(void);
void hangup_modem(void);
void usage(void);
int calc_sum(char *string1);
void read_msg(void);
void waitfor(char ch);
int waitfor_ack(void);
void init_modem(void);
int dial_modem(void);
int connect_modem(void);
void freadln(int fd);
void get_parms(void);
int str_nocase_equ(char *str1, char *str2);
void read_rc(char *rc, int funct);
char *safestring(char *str);
void log_status_msg(char ch);
void build_packet(void);
void send_packet(void);
void copy_pkt(void);
void copy_segment(void);

/******************************************************/

int main(int argc, char *argv[]) {
int ch = 0;

 strcpy(my_name_is, argv[0]);
 signal(SIGALRM, (void *)timed_out);
 signal(SIGINT, (void *)sig_int);
 signal(SIGSEGV, (void *)sig_segv);
 alarm(30);
 signal(SIGTERM, (void *)sig_term);

 sprintf(copyright, "\ndanpage v%s Copyright (c) 1997 by Dan Baker" \
                   " (%s)\nA program to send alphanumeric pages.\n", \
                   version, revdate);

 sprintf(danpagelog, "%s/danpage.log", libdir);
 sprintf(templog, "%s/danpage.log", tempdir);
 unlink(templog);
 sprintf(danpagerc1, "%s/danpagerc", libdir);
 sprintf(danpagerc2, "%s/danpagerc", (char *)getenv("HOME"));

 quiet = TRUE;
 wrt_log("\n"); /* Insert a blank line in log file */
 sprintf(str,"Version %s, (%s)", version, revdate);
 wrt_log(str);
 strcpy(str,"Options: ");
 for (i=1; i<argc; i++) {
  strcat(str, argv[i]); /* log command-line parameters */
  strcat(str, " ");
 }
 wrt_log(str);
 quiet = FALSE;

 read_rc(danpagerc1, PARM); /* read rc file from libdir, if possible */
 read_rc(danpagerc2, PARM); /* read rc file from home dir, if possible */

 while ((ch = getopt(argc, argv, "c:p:d:r:b:t:m:M:wsqiu")) != -1) switch(ch) {
  case 'c': strcpy(central,optarg); break;
  case 'p': strcpy(account,optarg); break;
  case 'd': strcpy(device,optarg); break;
  case 'r': redials = atoi(optarg); break;
  case 'b': bps = atoi(optarg); break;
  case 't': truncatesize = atoi(optarg); break;
  case 'm': packetsize = atoi(optarg); break;
  case 'M': split = TRUE; splitsize = atoi(optarg); break;
  case 'w': wait_for_lock = TRUE; break;
  case 's': nosig = TRUE; break;
  case 'q': quiet = TRUE; break;
  case 'i': ignorelock = TRUE; break;
  case 'u': username_sig = TRUE; break;
  default: usage();
 }

/* scan rc file(s) for pager string */
 read_rc(danpagerc2, ALIAS); /* read rc file from home dir, if possible */
 if ( !found_alias)
  read_rc(danpagerc1, ALIAS); /* read rc file from danpage dir, if possible */

 if (strlen(account) && index(account, ':')) {
  strcpy(central, account);
  ptr =  (char *)index(central, ':');
  if (ptr) ptr[0] = 0;
  strcpy(account,(char *)(index(account,':') +1));
 }

 if ((strlen(central) == 0) || (strlen(account) == 0)) usage();

 if (!quiet) printf(copyright);

 uid = getuid();
 pwuid = getpwuid(uid);
 sprintf(str, "Called by %s (uid=%d)\n", pwuid->pw_name, uid);
 wrt_log(str);

 if ( username_sig && gethostname(hostname, hostnamelen) )
  username_sig = FALSE;
 if (username_sig)
  sprintf(sig, "%s@%s", pwuid->pw_name, hostname);
 if (nosig) strcpy(sig,"");

 if (ignorelock) {
  strcpy(str, "Ignoring lock files (if any).\n");
  wrt_log(str);
 }
 else {
  if (wait_for_lock) {
   strcpy(str, "Wait for device lockfile (if found) to go away.\n");
   wrt_log(str);
  }
 }
 if (wait_for_lock) alarm(0);
 if (init() == -1) abort("Unable to initialize port");
 if ( (!quiet) && ( isatty(fileno(stdin)) ) )
  printf("Enter message, ending with Control-D\n");
 alarm(0);
 read_msg();
 alarm(20);

 if ( isatty(fileno(stdin)) )
  wrt_log("Message was entered from a terminal\n");
 else
  wrt_log("Message is from a pipe or by redirection\n");
 sprintf(str, "modem_init=%s\n",modem_init);
 wrt_log(safestring(str));
 sprintf(str, "modem_restore=%s\n",modem_restore);
 wrt_log(safestring(str));
 sprintf(str, "bps=%i\n",bps);
 wrt_log(str);
 sprintf(str, "truncate=%i\n",truncatesize);
 wrt_log(str);
 sprintf(str, "packetsize=%i\n",packetsize);
 wrt_log(str);
 if (split) {
  sprintf(str, "splitsize=%i\n",splitsize);
  wrt_log(str);
 }
 sprintf(str, "central=%s\n",central);
 wrt_log(str);
 sprintf(str, "device=%s\n",device);
 wrt_log(str);
 if (!ignorelock) {
  sprintf(str, "lockfile1=%s\n",lockfile1);
  wrt_log(str);
 }
 sprintf(str, "redials=%i\n",redials);
 wrt_log(str);
 sprintf(str, "paging %s\n",account);
 wrt_log(str);
 sprintf(str, "message=%s",message);
 if ( (str[strlen(str)-1] != CR) && (str[strlen(str)-1] != LF) )
  strcat(str,"\n");
 wrt_log(safestring(str));
 sprintf(str, "sig=%s\n",sig);
 wrt_log(safestring(str));

 if (sig && strlen(sig)) { strcat(message,"\n"); strcat(message, sig); }
 
 init_modem();
 alarm(60);
 if (dial_modem()) abort("ERROR DIALING MODEM");
 alarm(60);
 sleep(1); write(modem, "\r", 1); sleep(1); write(modem, "\r", 1);
 waitfor('='); sleep(1);
 wrt_log("Writing autolog...\n");
 write(modem, autolog, strlen(autolog));
 waitfor('['); waitfor('p');
 sleep(1);
  
 message_ptr = message;
 segmentnum = 1;
 do {
  packetnum = 1;
  pkt_ptr = segment;
  done = ( !split || ( strlen(message_ptr) <= splitsize ) );
  copy_segment();
  do {
   build_packet();
   send_packet();
  } while (!lastpacket);
  segmentnum++;
 } while (!done);
 write(modem, "\004\r", 2); /* send <EOT><CR> */

 hangup_modem();
 cleanup(0);
 exit(0);
} /* end of main() */


/* Functions: ------------------------------------------------------------- */

void no_eol(char *str1) {
 for( i=0; i < strlen(str1); i++)
  if((str1[i] ==  CR) || (str1[i] == LF)) str1[i] = ' ';
}

void wrt_log(char *logmsg) {
char logstr[maxlogstr] = "";
char timestr[maxlogstr];
 if( strlen(logmsg) && (logmsg[strlen(logmsg)-1] != '\n') )
  strcat(logmsg,"\n");
 if ( !strcmp(logmsg, "\n") ) strcpy(logstr, logmsg);
 else {
  if (!quiet) printf("%s : %s", my_name_is, logmsg);
  timer = time(NULL); tblock = localtime(&timer);
  strcpy(timestr, asctime(tblock)); no_eol(timestr);
  sprintf(logstr, "%s - %s", timestr, logmsg);
 }
 if ( strlen(danpagelog)
 && (logfile = open(danpagelog, O_RDWR | O_APPEND | O_CREAT, 0660)) )
  { write(logfile, logstr, strlen(logstr)); close(logfile); }
 if ( strlen(templog)
 && (templogfile = open(templog, O_RDWR | O_APPEND | O_CREAT, 0660)) )
  { write(templogfile, logstr, strlen(logstr)); close(templogfile); }
}

void cleanup(int code) {
 alarm(30);
 if (modem) {
  if (strlen(modem_restore)) {
   write(modem, modem_restore, strlen(modem_restore));
   write(modem, "\r", 1);
/*   waitfor('K'); */
  }
  tcsetattr(modem, TCSANOW, &t_old); /* restore old comport settings */
  close(modem);
 }
 if ((lock) && (lock != -1)) unlink(lockfile1);
 if (code == 0) wrt_log("Done.\n");
 alarm(0);
}

void abort(char *abortstr) {
char errstr[200];
 sprintf(errstr,"++ %s ++\n", abortstr);
 quiet = TRUE; /* so wrt_log won't send msg to stdout (we send to stderr anyway) */
 wrt_log(errstr);
/* strcat(errstr, "\007"); */  /* ring the bell */
 fprintf(stderr, errstr);
 strcpy(errstr,"danpage aborting!\n");
 wrt_log(errstr);
 fprintf(stderr, errstr);
 cleanup(2);
 exit(2);
}

int init (void) {
 pid_t pid;
 if (strstr(device, "/dev/") == 0) {
  if (strchr(device,'/')) abort("Invalid device name");
  else sprintf(device,"/dev/%s",device);
 }

 if (!ignorelock) {
  do {
   sprintf(lockfile1,"%s/LCK..", lockdir);
   if ( (i=readlink(device,devbuf,devbufsiz)) == -1)
    strcat(lockfile1, (char *)(rindex(device,'/')+1));
   else {
    devbuf[i]=0;
    strcat(lockfile1, devbuf);
   }
   if ((lock=open (lockfile1, O_RDWR | O_CREAT | O_EXCL, 0444)) == -1) {
    if (!wait_for_lock) {
     sprintf(str, "Failed opening LCK file %s",lockfile1);
     abort(str);
    }
   }
   else {
    pid = getpid(); write(lock, &pid, sizeof(pid)); close(lock);
   }
  } while ( wait_for_lock && (lock == -1) );
 }

 alarm(30);

 if ((modem = open(device, O_RDWR, 0)) == -1) {
  sprintf(str, "Failed opening modem device %s",device); abort(str);
 }
 
 if (tcgetattr(modem, &t) || tcgetattr(modem, &t_old)) return (-1);
 t.c_cc[VMIN] = 1; t.c_cc[VTIME] = 0;
 t.c_iflag &= ~(BRKINT | IGNPAR | PARMRK | INPCK | ISTRIP |
	          INLCR | IGNCR | ICRNL | IXON | ICANON);
 t.c_iflag |= (IGNBRK | IGNPAR | ISTRIP);
 t.c_oflag = (0); t.c_lflag = (0);
 t.c_cflag &= ~(CSTOPB | CSIZE | PARODD);
 t.c_cflag |= (HUPCL | CLOCAL | CREAD | CS7 | PARENB);

switch(bps) {
  case 300   : speed = B300; break;
  case 1200  : speed = B1200; break;
  case 2400  : speed = B2400; break;
  case 4800  : speed = B4800; break;
  case 9600  : speed = B9600; break;
  case 19200 : speed = B19200; break;
  case 38400 : speed = B38400; break;
  default    : speed = B1200;
 }

 if (cfsetispeed(&t, speed) == -1) return (-1);
 if (cfsetospeed(&t, speed) == -1) return (-1);
 if (tcflush(modem, TCIFLUSH) == -1) return (-1);
 if (tcsetattr(modem,TCSANOW, &t) == -1) return (-1);
 return (0);
}

void timed_out(void) {
 abort("Timed out.");
}

void sig_term(void) {
 abort("Received SIGTERM (Termination signal from kernel).");
}

void sig_int(void) {
 abort("Received SIGINT (User Interrupt).");
}

void sig_segv(void) {
 abort("Received SIGSEGV (Segmentation Fault)" \
       " Please send log file to danbaker@iquest.net ");
}

void hangup_modem(void) {
 sleep(3); write(modem, "+++", 3); sleep(3);
 write(modem, hangup_str, strlen(hangup_str));
}

void usage(void) {
 fprintf(stderr,
 "%sUsage:\n"
 " danpage -p <pager#> [-c <central#>] [-d <device>] [-r <redials>]\n" \
 "         [-t <length>] [-m <length>] [-M <length>] [-b <bits/sec>]\n" \
 "         [-w] [-s] [-q] [-i] [-u]\n" \
 " (takes message from standard input, end with ^D)\n" \
 "For more instructions, type 'man danpage'\n",copyright);
 quiet = TRUE;
 wrt_log("Displayed usage message and exited.\n");
 exit(1);
}

int calc_sum(char *string1) {
int i,isum = 0;
 for (i=0;i<strlen(string1);i++) isum += string1[i];
 for (i=2; i>=0; i--) sum[2-i] = (char) (0x30 | ((isum >> (i*4))& 0x000f));
 sum[3] = 0;
}

void read_msg(void) {
 int i = 0;
 maxmessage = truncatesize - strlen(sig) - 1;
 while(( (read(STDIN_FILENO, message+i, 1)) == 1 ) && (i < maxmessage)) {
  if (message[i] == CR) message[i] = LF;
  if ((message[i] != LF) && iscntrl(message[i])) message[i] = ' ';
  if ( (message[i] == LF) && (i > 0) && (message[i-1] == LF) )
   continue;
  i++;
 }
 message[i] = 0;
 while ( strlen(message) && (message[strlen(message)-1] == LF) )
  message[strlen(message)-1] = 0; /* strip off any trailing linefeeds */
}

void waitfor(char ch) {
char c;
 do if (read(modem, &c , 1) == 1) log_status_msg(c);
  while (c != ch);
}

int waitfor_ack(void) {
int Linux_Rules = TRUE;
 while(Linux_Rules) {
  while (read(modem, &ch, 1) != 1); /* wait for a character */
  log_status_msg(ch);
  if ((ch == ACK) || (ch == NAK) || (ch == EOT) || (ch == RS)) return(ch);
 }
}

void init_modem(void) {
 if (strlen(modem_init)) {
  wrt_log("Initializing modem...\n");
  write(modem, modem_init, strlen(modem_init)); 
  write(modem, "\r", 1);
  waitfor('K');
 }
}

int dial_modem(void) {
int i;
 do {
  redials--;
  wrt_log("Dialing...\n");
  sleep(1);
  write(modem, dial_prefix, strlen(dial_prefix));
  write(modem, central, strlen(central));
  write(modem, dial_suffix, strlen(dial_suffix));
  if ((i=connect_modem()) == 0) {
   wrt_log("Connect!\n");
   return 0;
  }
  else if (i==1) {
   wrt_log("BUSY\n");
   continue;
  }
 } while (redials >= 0);
 abort("BUSY");
}

int connect_modem(void) {
char c;
int i;
char line[maxpacket];
 for (i=0; i<strlen(line);i++) line[i] = 0;
 i = 0;
 while (i<maxpacket) {
  if (read(modem, &c, 1)==1) {
   log_status_msg(c);
   line[i] = c; line[i+1] = 0; i++;
   if (strstr(line,"CONNECT") != 0) return 0;
   if (strstr(line,"BUSY") != 0) return 1;
   if (strstr(line,"NO DIALTONE") != 0) abort("NO DIALTONE");
  }
 } 
}

void freadln(int fd) {
int rdstat;
char c;
int i = 0;
 while (((rdstat = read(fd, &c, 1)) == 1) && (i<199) && (c != '\n') ) {
  if ((c == EOF) || (rdstat != 1)) { line[i] = 0; done_rc = TRUE; return; }
  line[i] = c; i++;
 }
 line[i] = 0;
 if (rdstat != 1) done_rc = TRUE;
}

void get_parms(void) {
char ch;
 nxtparmptr = 0;
/* scan to first non-space,non-tab,non'=' char , set parmptr*/
 ch = parmptr[0];
 while ( (ch==' ') || (ch=='=') || (ch=='\t') ) {parmptr++; ch = parmptr[0]; }
 ptr = parmptr;
/* scan to next space, tab, or '=' char, set to zero */
 ch = ptr[0];
 while ( (ch != ' ') && (ch != '=') && !iscntrl(ch) ) {
  if ( (ch == 0) || (ch == CR) || (ch == LF) )
   {nxtparmptr = 0; return;}
  ptr++;
  if (ptr[0] == 0) return;
  ch = ptr[0];
 }
 ptr[0] = 0; ptr++;
 if (ptr[0] == 0) return;
/* scan to next non-space,non-tab,non'=' char, set nxtparmptr*/
 ch = ptr[0];
 while ( (ch == ' ') || (ch == '=') || (ch == '\t') ) {ptr++; ch = ptr[0]; }
 nxtparmptr = ptr;
 if (parmptr) {
  if (str_nocase_equ(parmptr,"central") || str_nocase_equ(parmptr,"device")) {
   while (isgraph(ptr[0])) ptr++;
   ptr[0] = 0;
  }
  else if ( str_nocase_equ(parmptr,"redials") 
         || str_nocase_equ(parmptr,"bps")
         || str_nocase_equ(parmptr,"truncate")
         || str_nocase_equ(parmptr,"packetsize")
         || str_nocase_equ(parmptr,"splitsize") ) {
   while (isdigit(ptr[0])) ptr++;
   ptr[0] = 0;
  }
  else if (str_nocase_equ(parmptr,"sig")) {
    while (isprint(ptr[0])) ptr++;
    ptr[0] = 0;
  }
 }
}

int str_nocase_equ(char *str1, char *str2) {
 return ( strncasecmp(str1, str2, strlen(str1)) == 0 );
}

void read_rc(char *rc, int funct) { /* open rc file if possible */
 done_rc = FALSE;
 if (rc_fd = open(rc, O_RDONLY, 0)) {
  do {
   freadln(rc_fd);
   if (line && strlen(line)) {
    if ((line[0] != '#') && (line[0] != ';')) {
     parmptr = line;
     get_parms();
     if (parmptr && strlen(parmptr)) {
      if (funct == PARM) {
       if (str_nocase_equ(parmptr, "modem_init")) {
        if (nxtparmptr && strlen(nxtparmptr))
         strcpy(modem_init, nxtparmptr);
        else modem_init[0] = 0;
       }
       if (str_nocase_equ(parmptr, "modem_restore")) {
        if (nxtparmptr && strlen(nxtparmptr))
         strcpy(modem_restore, nxtparmptr);
        else modem_restore[0] = 0;
       }
       else if (str_nocase_equ(parmptr, "central")) {
        if (nxtparmptr && strlen(nxtparmptr))
         strcpy(central, nxtparmptr);
       }
       else if (str_nocase_equ(parmptr, "device")) {
        if (nxtparmptr && strlen(nxtparmptr))
         strcpy(device, nxtparmptr);
       }
       else if (str_nocase_equ(parmptr, "redials")) {
        if (nxtparmptr && strlen(nxtparmptr))
         redials = atoi(nxtparmptr);
       }
       else if (str_nocase_equ(parmptr, "bps")) {
        if (nxtparmptr && strlen(nxtparmptr))
         bps = atoi(nxtparmptr);
       }
       else if (str_nocase_equ(parmptr, "truncate")) {
        if (nxtparmptr && strlen(nxtparmptr))
         truncatesize = atoi(nxtparmptr);
       }
       else if (str_nocase_equ(parmptr, "packetsize")) {
        if (nxtparmptr && strlen(nxtparmptr))
         packetsize = atoi(nxtparmptr);
       }
       else if (str_nocase_equ(parmptr, "splitsize")) {
        if (nxtparmptr && strlen(nxtparmptr))
         splitsize = atoi(nxtparmptr);
       }
       else if ( (str_nocase_equ(parmptr, "sig")) ) {
        if (nxtparmptr && strlen(nxtparmptr))
         strcpy(sig, nxtparmptr);
       }
      }
      else if ((funct == ALIAS) && (str_nocase_equ(parmptr, account))) {
       if ( !found_alias && nxtparmptr && strlen(nxtparmptr))
        strcpy(account, nxtparmptr);
       found_alias = TRUE;
      }
     }
    }
   }
  } while ( !done_rc && !( (funct==ALIAS) && found_alias));
  close(rc_fd);
 }
}

char *safestring(char *str) {
 int i,j;
 for (i=0,j=0; i<strlen(str); i++,j++) {
  if ( ( isprint(str[i]) ) || ( ( i==strlen(str) - 1 ) && (str[i]==LF) ) )
   safestr[j]=str[i];
  else if ( str[i]=='\r' ) {
   safestr[j++]='\\';
   safestr[j]='r';
  }
  else if ( str[i]=='\n' ) {
   safestr[j++]='\\';
   safestr[j]='n';
  }
  else if ( str[i]=='\t' ) {
   safestr[j++]='\\';
   safestr[j]='t';
  }
  else if ( str[i]=='\f' ) {
   safestr[j++]='\\';
   safestr[j]='f';
  }
  else {
   safestr[j++]='^';
   safestr[j]=((str[i] + 0x40) & 0x7f);
  }
 }
 safestr[j]=0;
 return (safestr);
}

void log_status_msg(char ch) {
 if (ch=='\r') ch = '\n';
 status_msg[statptr++]=ch;
 status_msg[statptr]=0;
 if (ch == '\n') {
  if ( ( statptr > 4 ) && ( strncmp(status_msg,"ID=",3) != 0 ) )
   wrt_log(safestring(status_msg));
  statptr=0; status_msg[statptr]=0;
 }
}

void build_packet(void) {
 if (packetnum == 1)
  max_pkt_len = packetsize - strlen(account) - 8;
 else
  max_pkt_len = packetsize - 7;
 lastpacket = ( strlen(pkt_ptr) <= max_pkt_len);
 if (packetnum == 1)
  sprintf(packet, "%c%s\r", STX, account);
 else
  sprintf(packet, "%c", STX);
 copy_pkt();
 if (lastpacket)
  sprintf(packet, "%s\r%c", packet, ETX);
 else
  sprintf(packet, "%s%c", packet, US);
 calc_sum(packet);
 strcat(packet, sum);
 strcat(packet, "\r");
}

void send_packet(void) {
 do {
  retrans--;
  sprintf(str, "Writing segment %d, packet %d ...\n", segmentnum, packetnum);
  wrt_log(str);
  write(modem, packet, strlen(packet));
  result = waitfor_ack();
  if (result == ACK) {
   wrt_log("Received ACK - Success!\n");
   packetnum++;
   break;
  }
  else if (result == NAK) {
   wrt_log("Received NAK - retransmitting...");
   continue;
  }
  else if (result == RS)
   abort("Data format error- possibly incorrect pager ID");
  else if (result == EOT) abort("Received EOT - Forced disconnect!");
 } while (retrans > 0);
 if (result == NAK) abort("Page rejected- unknown error");
}

void copy_pkt(void) {
 int i;
 i = strlen(packet);
 while ( strlen(pkt_ptr) && (i < packetsize) ) {
  packet[i++] = pkt_ptr[0];
  pkt_ptr++;
 }
 packet[i] = 0;
}

void copy_segment(void) {
 int i, chars, continued;
 continued = FALSE;
 i = 0;
 chars = splitsize;
 if ( strlen(message_ptr) > splitsize ) {
  continued = TRUE;
  chars -= 4;
 }
 while ( strlen(message_ptr) && (i < chars) ) {
  segment[i++] = message_ptr[0];
  message_ptr++;
 }
 segment[i] = 0;
 if (continued) strcat (segment, " ...");
}

/* End of danpage.c */
