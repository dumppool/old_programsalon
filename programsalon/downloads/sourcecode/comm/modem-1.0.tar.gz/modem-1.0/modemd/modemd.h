/*
 * $Id: modemd.h,v 1.7 1998/02/17 09:53:15 mdejonge Exp $
 *
 *   $Source: /home/mdejonge/CVS/projects/modem/modemd/modemd.h,v $
 * $Revision: 1.7 $
 *    Author: Merijn de Jonge
 *     Email: mdejonge@wins.uva.nl
 * 
 *  
 * 
 * This file is part of the modem communication package.
 * Copyright (C) 1996-1998  Merijn de Jonge
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * 
 */
#ifndef _modemd_h
#define _modemd_h

/* Serveral functions used by modemd */

/* Start server process */
void server();

/* Handle new client */
void handle_client( int, const char*, const char* );

/* Become daemon */
int startup_daemon( int daemon);

char   *rfc931(sockStruct* remote, sockStruct* local );
#define FROM_UNKNOWN  "unknown"

#endif
/*
 * EOF modemd/modemd.h
 */
