/*
 * $Id: match.h,v 1.7 1998/02/17 09:52:06 mdejonge Exp $
 *
 *   $Source: /home/mdejonge/CVS/projects/modem/libmodem/match.h,v $
 * $Revision: 1.7 $
 *    Author: Merijn de Jonge
 *     Email: mdejonge@wins.uva.nl
 * 
 *  
 * 
 * This file is part of the modem communication package.
 * Copyright (C) 1996-1998  Merijn de Jonge
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * 
 */
#ifndef _match_h
#define _match_h

#define MATCH_INCONCLUSIVE  -2
#define MATCH_NO_MATCH      -1
#define MATCH_BEGINNING     1 
#define MATCH_ALL           0 

void matchInit( void );
int matchOneChar( const char* str[], char c, int option );
int matchText( const char* str[], int option, char (*rfunc)() );

#endif
/*
 * EOF libmodem/match.h
 */
