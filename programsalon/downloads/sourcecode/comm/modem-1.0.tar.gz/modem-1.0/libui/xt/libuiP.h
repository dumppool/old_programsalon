/*
 * $Id: libuiP.h,v 1.3 1998/02/17 09:53:00 mdejonge Exp $
 *
 *   $Source: /home/mdejonge/CVS/projects/modem/libui/xt/libuiP.h,v $
 * $Revision: 1.3 $
 *    Author: Merijn de Jonge
 *     Email: mdejonge@wins.uva.nl
 * 
 *  
 * 
 * This file is part of the modem communication package.
 * Copyright (C) 1996-1998  Merijn de Jonge
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * 
 */
#ifndef _libuiP_h
#define _libuiP_h

#include <X11/Intrinsic.h>

#include "libui.h"

extern XtAppContext __app;
extern Display*     __dpy;
extern Widget       __toplevel;

#define AppShell   __toplevel
#define AppDisplay __dpy
#define AppContext __app

void displayHelpCallback( Widget w, XtPointer p1, XtPointer p2 );

#endif
/*
 * EOF libui/xt/libuiP.h
 */
