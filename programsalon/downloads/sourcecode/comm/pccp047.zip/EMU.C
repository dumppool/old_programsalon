/* Released to the Public Domain in 1992 by Peter Edward Cann */

#include"emu.h"

struct emu_s emu;

nullemu()
	{
	int i;
	for(i=0;i<NFUNCS;i++)
		{
		emu.funcs[i].func=NOOP;
		emu.funcs[i].codes[0]=END;
		}
	for(i=0;i<256;i++)
		emu.keys[i].len=0;
	for(i=0;i<256;i++)
		emu.gchars[i]=0;
	emu.keys[0x03].len=1;
	emu.keys[0x03].chars[0]='\0';
	emu.default_wrap_p=1;
	}

