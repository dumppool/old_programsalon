/*	Copyright (C) 1992 Peter Edward Cann, all rights reserved.
 *	MicroSoft QuickC
 */

#include<stdio.h>
#include<bios.h>
#include<dos.h>
#include<fcntl.h>
#include<sys\types.h>
#include<sys\stat.h>
#include<signal.h>
#include<process.h>
#include"port.h"

sendchar(c)
	unsigned char c;
	{
	while(!((inp(basereg+STATREG)&TXMTMASK)&&(inp(basereg+MSTATREG)&CTSMASK)))
		if(kbhit())
			getch();
	outp(basereg, c);
	}

int follow;

quit()
	{
	cleanup(0);
	exit(99);
	}

sendstr(str)
	char *str;
	{
	int i;
	for(i=0;str[i]!='\0';++i)
		if(str[i]=='\n')
			{
			sendchar('\r');
			sendchar('\n');
			}
		else
			sendchar(str[i]);
	}

portgets(str)
	char *str;
	{
	int i;
	i=0;
	while(i<255)
		{
		while(follow==index)
			{
			if(!(inp(basereg+MSTATREG)&DCDMASK))
				return(-1);
			if(kbhit())
				getch();
			}
		str[i]=buf[follow++];
		follow%=TBUFSIZ;
		if(str[i]=='\b')
			if(i>0)
				{
				i-=2;
				sendchar('\b');
				sendchar(' ');
				sendchar('\b');
				}
			else
				{
				i--;
				sendchar(0x07);
				}
		else
			sendchar(str[i]);
		if((str[i]=='\r')||(str[i]=='\n'))
			{
			sendchar('\r');
			sendchar('\n');
			str[i]='\0';
			break;
			}
		i++;
		}
	str[255]='\0';
	return(0);
	}
		
getlegalpath(str, dirstr)
	char *str, *dirstr;
	{
	char str1[256];
	int i;
	if(portgets(str1)==-1)
		return(-1);
	if(dirstr[0])
		{
		for(i=0;i<255;++i)
			{
			if(str1[i]=='\0')
				break;
			if((str1[i]=='.')&&(str1[i+1]=='.'))
				{
				str[0]='\0';
				return(0);
				}
			}
		sprintf(str, "%s\\%s", dirstr, str1);
		}
	else
		strcpy(str, str1);
	}

main(argc, argv)
	int argc;
	char **argv;
	{
	long timestamp;
	int i, j, outfd, ok, c, run, result;
	char str[256], udir[256], ddir[256];
	index=follow=0;
	printf("Copyright (C) 1992 Peter Edward Cann, all rights reserved.\n");
	if(!strcmp(getenv("REMOTE"), "YES"))
		{
		printf("You appear to be already logged in remotely, judging by the environment\n");
		printf("variable REMOTE, so this is probably a very bad idea.\n");
		printf("Are you sure you want to run SESSION? (y or n) --> ");
		if(getchar()!='y') /* Note getchar() and not getch()! */
			{
			printf("I didn't think so!\n");
			exit(99);
			}
		else
			printf("OK, you're the boss!");
		}
	printf("Control-C to Exit.\n");
	if((argc!=5)&&(argc!=3))
		{
		printf("USAGE: session <comnum> <bps> [<download dir> <upload dir>]\n");
		exit(1);
		}
	if(argc==5)
		{
		strcpy(ddir, argv[3]);
		strcpy(udir, argv[4]);
		}
	else
		{
		ddir[0]='\0';
		udir[0]='\0';
		}
	comnum=atoi(argv[1])-1;
	speed=atoi(argv[2]);
	databits='8';
	parity='n';
	stopbits='1';
	setport();
	readset();
	setup();
	signal(SIGINT, quit);
	run=1;
	while(run)
		{
		sendstr("\n\n     DOWNLOAD:  (1) Xmodem   (2) Xmodem CRC   (3) Xmodem CRC 1K\n\n");
		sendstr("       UPLOAD:  (4) Xmodem   (5) Xmodem CRC 1K Optional\n\n");
		if(argc==5)
			sendstr("                   (q) Quit\n\n             ---> ");
		else
			sendstr("                 (s) Shell        (q) Quit\n\n             ---> ");
		while(index==follow)
			{
			if(!(inp(basereg+MSTATREG)&DCDMASK))
				{
				run=0;
				break;
				}
			if(kbhit())
				getch();
			}
		if(!run)
			break;
		c=buf[follow++];
		follow%=TBUFSIZ;
		switch(c)
			{
			case 'q':
			case 'Q':
				sendstr("Quit\n");
				run=0;
				break;
			case 's':
			case 'S':
				if(argc==5)
					{
					sendstr("Shell not available with restricted directory.\n");
					break;
					}
				sendstr("Shell\n");
				printf("Entering command.com remote shell.\n");
				sprintf(str, "COM%d", comnum+1);
				putenv("PROMPT=REMOTE>$p$g");
				putenv("REMOTE=YES");
				cleanup(INHCTL);
				spawnlp(P_WAIT, "c:\\command.com", "command.com", str, "/e:01024", NULL);
				putenv("REMOTE=NO");
				setup();
				break;
			case '1':
				sendstr("Xmodem Download.\nSource file pathname? (Blank to cancel)\n --> ");
				if((result=getlegalpath(str, ddir))==-1)
					{
					run=0;
					break;
					}
				if(!strlen(str))
					break;
				cleanup(INHCTL);
				result=spawnlp(P_WAIT, "xmodems", "xmodems", argv[1], argv[2], "1", str, NULL);
				setup();
				sendstr("Press any key to continue: --> ");
				while(follow==index)
					{
					if(!(inp(basereg+MSTATREG)&DCDMASK))
						{
						run=0;
						break;
						}
					if(kbhit())
						getch();
					}
				follow=index;
				sprintf(str, "Exit code = %d.\n", result);
				sendstr(str);
				break;
			case '2':
				sendstr("Xmodem CRC Download.\nSource file pathname? (Blank to cancel)\n --> ");
				if((result=getlegalpath(str, ddir))==-1)
					{
					run=0;
					break;
					}
				if(!strlen(str))
					break;
				cleanup(INHCTL);
				result=spawnlp(P_WAIT, "xmcrcs", "xmcrcs", argv[1], argv[2], "1", str, NULL);
				setup();
				sendstr("Press any key to continue: --> ");
				while(follow==index)
					{
					if(!(inp(basereg+MSTATREG)&DCDMASK))
						{
						run=0;
						break;
						}
					if(kbhit())
						getch();
					}
				follow=index;
				sprintf(str, "Exit code = %d.\n", result);
				sendstr(str);
				break;
			case '3':
				sendstr("Xmodem CRC 1k Download.\nSource file pathname? (Blank to cancel)\n --> ");
				if((result=getlegalpath(str, ddir))==-1)
					{
					run=0;
					break;
					}
				if(!strlen(str))
					break;
				cleanup(INHCTL);
				result=spawnlp(P_WAIT, "xmcrc1ks", "xmcrc1ks", argv[1], argv[2], "1", str, NULL);
				setup();
				sendstr("Press any key to continue: --> ");
				while(follow==index)
					{
					if(!(inp(basereg+MSTATREG)&DCDMASK))
						{
						run=0;
						break;
						}
					if(kbhit())
						getch();
					}
				follow=index;
				sprintf(str, "Exit code = %d.\n", result);
				sendstr(str);
				break;
			case '4':
				sendstr("Xmodem Upload.\nTarget file pathname? (Blank to cancel)\n --> ");
				if((result=getlegalpath(str, udir))==-1)
					{
					run=0;
					break;
					}
				if(!strlen(str))
					break;
				cleanup(INHCTL);
				result=spawnlp(P_WAIT, "xmodemr", "xmodemr", argv[1], argv[2], "1", str, NULL);
				setup();
				sendstr("Press any key to continue: --> ");
				while(follow==index)
					{
					if(!(inp(basereg+MSTATREG)&DCDMASK))
						{
						run=0;
						break;
						}
					if(kbhit())
						getch();
					}
				follow=index;
				sprintf(str, "Exit code = %d.\n", result);
				sendstr(str);
				break;
			case '5':
				sendstr("Xmodem CRC Upload, 1k Optional.\nTarget file pathname? (Blank to cancel)\n --> ");
				if((result=getlegalpath(str, udir))==-1)
					{
					run=0;
					break;
					}
				if(!strlen(str))
					break;
				cleanup(INHCTL);
				result=spawnlp(P_WAIT, "xmcrc1kr", "xmcrc1kr", argv[1], argv[2], "1", str, NULL);
				setup();
				sendstr("Press any key to continue: --> ");
				while(follow==index)
					{
					if(!(inp(basereg+MSTATREG)&DCDMASK))
						{
						run=0;
						break;
						}
					if(kbhit())
						getch();
					}
				follow=index;
				sprintf(str, "Exit code = %d.\n", result);
				sendstr(str);
				break;
			}
		}
	cleanup(INHCTL);
	exit(0);
	}
