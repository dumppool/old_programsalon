#include<stdio.h>
#include<graph.h>

main()
	{
	char str[16];
	int i;
	for(i=0;i<256;++i)
		{
		if(!(i%16))
			{
			sprintf(str, "\n");
			_outtext(str);
			}
		else
			{
			sprintf(str, " ");
			_outtext(str);
			}
		if((i!=10)&&(i!=13))
			{
			sprintf(str, "%02x>%c", i, i);
			_outtext(str);
			}
		else
			{
			sprintf(str, "    ");
			_outtext(str);
			}
		}
	}
