/*	Copyright (C) 1992 Peter Edward Cann, all rights reserved.
 *	MicroSoft QuickC: >qcl term.c graphics.lib
 */

#include<stdio.h>
#include<bios.h>
#include<dos.h>
#include<fcntl.h>
#include<signal.h>
#include"port.h"

#define CAN 24 /* Control-X */

quit()
	{
	cleanup();
	exit(99);
	}

sendchar(c)
	unsigned char c;
	{
	while(!((inp(basereg+STATREG)&TXMTMASK)&&(inp(basereg+MSTATREG)&CTSMASK)))
		if(kbhit())
			getch();
	outp(basereg, c);
	}

main(argc, argv)
	int argc;
	char **argv;
	{
	FILE *fd;
	char c, str[256];
	int follow, i;
	index=follow=0;
	printf("Copyright (C) 1992 Peter Edward Cann, all rights reserved.\n");
	if(argc!=5)
		{
		printf("USAGE: term <comnum> <bps> <data><parity><stop> <file>\n");
		exit(1);
		}
	printf("ASCII send of %s\n", argv[4]);
	if((fd=fopen(argv[4], "r"))==NULL)
		{
		printf("Couldn't open file %s.\n");
		exit(10);
		}
	comnum=atoi(argv[1])-1;
	speed=atoi(argv[2]);
	parity=argv[3][1];
	databits=argv[3][0];
	stopbits=argv[3][2];
	setport();
	signal(SIGINT, quit);
	readset();
	setup();
	while(1)
		{
		if(kbhit())
			getch();
		if(fgets(str, 255, fd)==NULL)
			exit(0);
		for(i=0;(str[i]!='\0')&&(i<256);++i)
			if(str[i]!='\n')
				sendchar(str[i]);
			else
				sendchar('\r');
		do
			{
			while(follow==index);
			if(buf[follow]!=CAN)
				putch(buf[follow]);
			else
				exit(12);
			}
		while(buf[follow++]!='\r');
		}
	}
