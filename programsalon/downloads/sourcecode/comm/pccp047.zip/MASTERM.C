#include<stdio.h>
#include<process.h>
#include"port.h"

main(argc, argv)
	int argc;
	char **argv;
	{
	int run, basereg;
	char stopbstr[2], fpname[256], cmdstr[256], c, oldstat;
	if(!strcmp(getenv("REMOTE"), "YES"))
		{
		printf("You appear to be logged in remotely, judging by the environment\n");
		printf("variable REMOTE, so this is probably a very bad idea.\n");
		printf("Are you sure you want to run MASTERM? (y or n) --> ");
		if(getchar()!='y') /* Note getchar() and not getch()! */
			{
			printf("n\nI didn't think so!\n");
			exit(99);
			}
		else
			printf("y\nOK, you're the boss!\n");
		}
	if((argc!=4)&&(argc!=5))
		{
		printf("USAGE: masterm <port#> <speed> <databits><parity><stopbits> [<emu file>]\n");
		exit(1);
		}
	switch(argv[1][0])
		{
		case '1':
			basereg=0x3f8;
			break;
		case '2':
			basereg=0x2f8;
			break;
		case '3':
		case '5':
		case '7':
			basereg=0x3e8;
			break;
		case '4':
		case '6':
		case '8':
			basereg=0x2e8;
			break;
		default:
			printf("Bad port number.\n");
			exit(2);
		}
	oldstat=inp(basereg+MCTLREG);
	outp(basereg+MCTLREG, 0x03);
	spawnlp(P_WAIT, "term", "term", argv[1], argv[2], argv[3], argv[4], NULL);
	stopbstr[0]=argv[3][2];
	stopbstr[1]='\0';
	run=1;
	while(run)
		{
		printf("\n     Copyright (C) 1992 Peter Edward Cann, all rights reserved.\n\n");
		printf("     UPLOAD:  (1) Xmodem   (2) Xmodem CRC   (3) Xmodem CRC 1K   (a) ASCII\n\n");
		printf("     DOWNLOAD:  (4) Xmodem   (5) Xmodem CRC 1K Optional\n\n");
		printf("      (t, SPACE or ENTER) Terminal   (d) Terminal with Dribble\n\n");
		printf("                             (q) Quit\n\n             ---> ");
		c=getch();
		printf("%c\n", c);
		switch(c)
			{
			case 'q':
			case 'Q':
				run=0;
				break;
			case 't':
			case 'T':
			case ' ':
			case '\r':
				if(getenv("PCCPPATH")==NULL)
					sprintf(cmdstr, "term");
				else
					sprintf(cmdstr, "%s/term", getenv("PCCPPATH"));
				if(argc==5)
					spawnlp(P_WAIT, cmdstr, "term", argv[1], argv[2], argv[3], argv[4], NULL);
				else
					spawnlp(P_WAIT, cmdstr, "term", argv[1], argv[2], argv[3], NULL);
				break;
			case 'd':
			case 'D':
				if(getenv("PCCPPATH")==NULL)
					sprintf(cmdstr, "term");
				else
					sprintf(cmdstr, "%s/term", getenv("PCCPPATH"));
				printf("Dribble file pathname? (Blank to cancel)\n --> ");
				gets(fpname);
				if(!strlen(fpname))
					break;
				if(argc==5)
					spawnlp(P_WAIT, cmdstr, "term", argv[1], argv[2], argv[3], argv[4], fpname, NULL);
				else
					spawnlp(P_WAIT, cmdstr, "term", argv[1], argv[2], argv[3], "-", fpname, NULL);
				break;
			case '1':
				if(getenv("PCCPPATH")==NULL)
					sprintf(cmdstr, "xmodems");
				else
					sprintf(cmdstr, "%s/xmodems", getenv("PCCPPATH"));
				printf("Source file pathname? (Blank to cancel)\n --> ");
				gets(fpname);
				if(!strlen(fpname))
					break;
				spawnlp(P_WAIT, cmdstr, "xmodems", argv[1], argv[2], stopbstr, fpname, NULL);
				putch('\007');
				break;
			case 'a':
			case 'A':
				if(getenv("PCCPPATH")==NULL)
					sprintf(cmdstr, "asciis");
				else
					sprintf(cmdstr, "%s/asciis", getenv("PCCPPATH"));
				printf("Source file pathname? (Blank to cancel)\n --> ");
				gets(fpname);
				if(!strlen(fpname))
					break;
				spawnlp(P_WAIT, cmdstr, "asciis", argv[1], argv[2], argv[3], fpname, NULL);
				putch('\007');
				break;
			case '2':
				if(getenv("PCCPPATH")==NULL)
					sprintf(cmdstr, "xmcrcs");
				else
					sprintf(cmdstr, "%s/xmcrcs", getenv("PCCPPATH"));
				printf("Source file pathname? (Blank to cancel)\n --> ");
				gets(fpname);
				if(!strlen(fpname))
					break;
				spawnlp(P_WAIT, cmdstr, "xmcrcs", argv[1], argv[2], stopbstr, fpname, NULL);
				putch('\007');
				break;
			case '3':
				if(getenv("PCCPPATH")==NULL)
					sprintf(cmdstr, "xmcrc1ks");
				else
					sprintf(cmdstr, "%s/xmcrc1ks", getenv("PCCPPATH"));
				printf("Source file pathname? (Blank to cancel)\n --> ");
				gets(fpname);
				if(!strlen(fpname))
					break;
				spawnlp(P_WAIT, cmdstr, "xmcrc1ks", argv[1], argv[2], stopbstr, fpname, NULL);
				putch('\007');
				break;
			case '4':
				if(getenv("PCCPPATH")==NULL)
					sprintf(cmdstr, "xmodemr");
				else
					sprintf(cmdstr, "%s/xmodemr", getenv("PCCPPATH"));
				printf("Target file pathname? (Blank to cancel)\n --> ");
				gets(fpname);
				if(!strlen(fpname))
					break;
				spawnlp(P_WAIT, cmdstr, "xmodemr", argv[1], argv[2], stopbstr, fpname, NULL);
				putch('\007');
				break;
			case '5':
				if(getenv("PCCPPATH")==NULL)
					sprintf(cmdstr, "xmcrc1kr");
				else
					sprintf(cmdstr, "%s/xmcrc1kr", getenv("PCCPPATH"));
				printf("Target file pathname? (Blank to cancel)\n --> ");
				gets(fpname);
				if(!strlen(fpname))
					break;
				spawnlp(P_WAIT, cmdstr, "xmcrc1kr", argv[1], argv[2], stopbstr, fpname, NULL);
				putch('\007');
				break;
			}
		}
	outp(basereg+MCTLREG, oldstat);
	exit(0);
	}
