/*	Copyright (C) 1992 Peter Edward Cann, all rights reserved.
 *	MicroSoft QuickC
 */

#include<stdio.h>
#include<bios.h>
#include<dos.h>
#include<fcntl.h>
#include<sys\types.h>
#include<sys\stat.h>
#include<signal.h>
#include<process.h>
#include"port.h"

sendchar(c)
	unsigned char c;
	{
	while(!((inp(basereg+STATREG)&TXMTMASK)&&(inp(basereg+MSTATREG)&CTSMASK)))
		if(kbhit())
			getch();
	outp(basereg, c);
	}

int follow;

quit()
	{
	cleanup(0);
	exit(99);
	}

sendstr(str)
	char *str;
	{
	int i;
	for(i=0;str[i]!='\0';++i)
		if(str[i]=='\n')
			{
			sendchar('\r');
			sendchar('\n');
			}
		else
			sendchar(str[i]);
	}

portgets(str)
	char *str;
	{
	int i;
	i=0;
	while(i<255)
		{
		while(follow==index)
			{
			if(!(inp(basereg+MSTATREG)&DCDMASK))
				return(-1);
			if(kbhit())
				getch();
			}
		str[i]=buf[follow++];
		follow%=TBUFSIZ;
		if(str[i]=='\b')
			if(i>0)
				{
				i-=2;
				sendchar('\b');
				sendchar(' ');
				sendchar('\b');
				}
			else
				{
				i--;
				sendchar(0x07);
				}
		else
			sendchar(str[i]);
		if((str[i]=='\r')||(str[i]=='\n'))
			{
			sendchar('\r');
			sendchar('\n');
			str[i]='\0';
			break;
			}
		i++;
		}
	str[255]='\0';
	return(0);
	}
		
main(argc, argv)
	int argc;
	char **argv;
	{
	FILE *fd;
	long timestamp;
	int i, j, outfd, ok, c, run, result;
	char str[256], filename[256], str1[256];
	index=follow=0;
	printf("Copyright (C) 1992 Peter Edward Cann, all rights reserved.\n");
	if(!strcmp(getenv("REMOTE"), "YES"))
		{
		printf("You appear to be already logged in remotely, judging by the environment\n");
		printf("variable REMOTE, so this is probably a very bad idea.\n");
		printf("Are you sure you want to run MESSIN? (y or n) --> ");
		if(getchar()!='y') /* Note getchar() and not getch()! */
			{
			printf("I didn't think so!\n");
			exit(99);
			}
		else
			printf("OK, you're the boss!");
		}
	printf("Control-C to Exit.\n");
	if(argc!=4)
		{
		printf("USAGE: messin <comnum> <bps> <directory>\n");
		exit(1);
		}
	comnum=atoi(argv[1])-1;
	speed=atoi(argv[2]);
	databits='8';
	parity='n';
	stopbits='1';
	setport();
	readset();
	setup();
	signal(SIGINT, quit);
	sprintf(str, "\nEnter your account name: --> ");
	sendstr(str);
	if(portgets(str)==-1)
		{
		printf("Lost carrier detect.\n");
		exit(10);
		}
	for(i=(strlen(str)-1);i>=0;i--)
		if((str[i]=='\\')||(str[i]=='/'))
			{
			sprintf(str, "Backslash and slash are not permitted!\n");
			sendstr(str);
			exit(11);
			}
	printf("MESSOUT called on account %s.\n", str);
	sprintf(filename, "%s\\%s", argv[3], str);
	if((fd=fopen(filename, "r"))==NULL)
		{
		sprintf(str, "Sorry, can't open the file.\n");
		sendstr(str);
		printf("Error opening MESSOUT file.\n");
		exit(1);
		}
	i=0;
	while(1)
		{
		i++;
		if(fgets(str, 80, fd)==NULL)
			{
			sprintf(str, "*** END OF MESSAGE. PRESS ANY KEY TO CONTINUE --> ");
			sendstr(str);
			while(follow==index)
				{
				if(!(inp(basereg+MSTATREG)&DCDMASK))
					{
					cleanup();
					exit(10);
					}
				if(kbhit())
					getch();
				}
			follow=index;
			exit(0);
			}
		sendstr(str);
		if(!(i%20))
			{
			sprintf(str, "PRESS ANY KEY TO CONTINUE: --> ");
			sendstr(str);
			while(index==follow)
				{
				if(kbhit())
					getch();
				if(!(inp(basereg+MSTATREG)&DCDMASK))
					{
					cleanup();
					exit(10);
					}
				}
			follow=index;
			sprintf(str, "\n");
			sendstr(str);
			}
		}
	exit(0);
	}
