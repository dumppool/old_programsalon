
struct tel_fav {
	char *nick;
	char *nombre;
	char *tel;

	struct tel_fav *sig;
	};

	
struct {
	int vol, mic; 	/* vol�men del altavoz y sensibilidad del micr�fono (0-255) */
	char dev[30]; 	/* dispositivo del m�dem */
	int vel;		/* velocidad del puerto */
	char xpm[255];	/* icono */
	struct tel_fav *tf;
	
	int debug;		/* modo depuraci�n */
	int modo_x;		/* usar las XForms */
	}
	config;

int leeconfig(void);


#define CFG_ERR_OK 		0
#define CFG_ERR_FOPEN 	1


#define CFG_NOMBRE_FICH 	"lfonorc"
#define CFG_VAR_ENTORNO		"LFONORC"
#define CFG_MAX_LINEA		80
#define CFG_CAR_COMENTARIO 	';'