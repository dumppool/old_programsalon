#include <unistd.h>
#include "forms.h"
#include "lfono-form.h"

extern FD_lfono *form_ppal; /* en interfaz-x.c */ 


#define MAX_STATUS 40
char st[MAX_STATUS+1];

void status(char *msg)
	{
#if 0
	/* Lo olvidamos por el momento... */
	int i;
	
	if( strlen(st)+strlen(msg)+3 > MAX_STATUS ) {
		strcpy(st, st+strlen(msg)+3);
		}
		
	strcat(st, " - " );
	strcat(st, msg );

	fl_set_object_label(form_ppal->visor_status, st);
	fl_redraw_object(form_ppal->visor_status);
	for(i=0; i<=100000; i++) 
		;
#endif	
	}
	