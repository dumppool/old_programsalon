#ifndef FD_lfono_h_
#define FD_lfono_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void cb_marca_favorito(FL_OBJECT *, long);
extern void cb_salir(FL_OBJECT *, long);
extern void cb_descolgar(FL_OBJECT *, long);
extern void cb_boton(FL_OBJECT *, long);
extern void cb_vol(FL_OBJECT *, long);
extern void cb_mic(FL_OBJECT *, long);
extern void cb_onoff(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *lfono;
	void *vdata;
	long ldata;
	FL_OBJECT *favoritos;
	FL_OBJECT *salir;
	FL_OBJECT *descolgar;
	FL_OBJECT *visor;
	FL_OBJECT *g_botones;
	FL_OBJECT *b8;
	FL_OBJECT *b9;
	FL_OBJECT *b5;
	FL_OBJECT *b6;
	FL_OBJECT *b1;
	FL_OBJECT *b2;
	FL_OBJECT *b3;
	FL_OBJECT *b0;
	FL_OBJECT *bnum;
	FL_OBJECT *b7;
	FL_OBJECT *bast;
	FL_OBJECT *b4;
	FL_OBJECT *g_niveles;
	FL_OBJECT *vol;
	FL_OBJECT *mic;
	FL_OBJECT *onoff;
} FD_lfono;

extern FD_lfono * create_form_lfono(void);

#endif /* FD_lfono_h_ */
