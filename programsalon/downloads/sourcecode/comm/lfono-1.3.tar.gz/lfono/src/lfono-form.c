/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "lfono-form.h"

FD_lfono *create_form_lfono(void)
{
  FL_OBJECT *obj;
  FD_lfono *fdui = (FD_lfono *) fl_calloc(1, sizeof(*fdui));

  fdui->lfono = fl_bgn_form(FL_NO_BOX, 470, 340);
  obj = fl_add_box(FL_EMBOSSED_BOX,0,0,470,340,"");
  obj = fl_add_text(FL_NORMAL_TEXT,50,10,210,70,"Lin�xFono 1.2");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_COL1,33);
    fl_set_object_lcolor(obj,FL_DARKVIOLET);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_FIXEDBOLD_STYLE);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,0,0,30,50,"");
  obj = fl_add_labelframe(FL_ENGRAVED_FRAME,290,10,160,70,"");
  fdui->favoritos = obj = fl_add_browser(FL_HOLD_BROWSER,320,100,140,210,"");
    fl_set_object_boxtype(obj,FL_UP_BOX);
    fl_set_object_lcolor(obj,FL_RIGHT_BCOL);
    fl_set_object_callback(obj,cb_marca_favorito,0);
  fdui->salir = obj = fl_add_button(FL_NORMAL_BUTTON,140,240,60,70,"Salir");
    fl_set_object_lcolor(obj,FL_RED);
    fl_set_object_callback(obj,cb_salir,0);
  obj = fl_add_text(FL_NORMAL_TEXT,300,20,140,30,"!997 Eloy R. Sanz");
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
  obj = fl_add_text(FL_NORMAL_TEXT,310,50,120,20,"eloyrsanz@ThePentagon.com");
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_TINY_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE);
  fdui->descolgar = obj = fl_add_lightbutton(FL_PUSH_BUTTON,140,150,60,70,"Des\ncol\ngar");
    fl_set_object_callback(obj,cb_descolgar,0);
  fdui->visor = obj = fl_add_text(FL_NORMAL_TEXT,10,100,190,30,"");
    fl_set_object_boxtype(obj,FL_EMBOSSED_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_RIGHT|FL_ALIGN_INSIDE);

  fdui->g_botones = fl_bgn_group();
  fdui->b8 = obj = fl_add_button(FL_NORMAL_BUTTON,50,230,40,40,"8");
    fl_set_button_shortcut(obj,"8",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,8L);
  fdui->b9 = obj = fl_add_button(FL_NORMAL_BUTTON,90,230,40,40,"9");
    fl_set_button_shortcut(obj,"9",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,9L);
  fdui->b5 = obj = fl_add_button(FL_NORMAL_BUTTON,50,190,40,40,"5");
    fl_set_button_shortcut(obj,"5",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,5L);
  fdui->b6 = obj = fl_add_button(FL_NORMAL_BUTTON,90,190,40,40,"6");
    fl_set_button_shortcut(obj,"6",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,6L);
  fdui->b1 = obj = fl_add_button(FL_NORMAL_BUTTON,10,150,40,40,"1");
    fl_set_button_shortcut(obj,"1",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,1L);
  fdui->b2 = obj = fl_add_button(FL_NORMAL_BUTTON,50,150,40,40,"2");
    fl_set_button_shortcut(obj,"2",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,2L);
  fdui->b3 = obj = fl_add_button(FL_NORMAL_BUTTON,90,150,40,40,"3");
    fl_set_button_shortcut(obj,"3",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,3L);
  fdui->b0 = obj = fl_add_button(FL_NORMAL_BUTTON,50,270,40,40,"0");
    fl_set_button_shortcut(obj,"0",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,0L);
  fdui->bnum = obj = fl_add_button(FL_NORMAL_BUTTON,90,270,40,40,"#");
    fl_set_button_shortcut(obj,"^#",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,-2L);
  fdui->b7 = obj = fl_add_button(FL_NORMAL_BUTTON,10,230,40,40,"7");
    fl_set_button_shortcut(obj,"7",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,7L);
  fdui->bast = obj = fl_add_button(FL_NORMAL_BUTTON,10,270,40,40,"*");
    fl_set_button_shortcut(obj,"*",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,-1L);
  fdui->b4 = obj = fl_add_button(FL_NORMAL_BUTTON,10,190,40,40,"4");
    fl_set_button_shortcut(obj,"4",1);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_callback(obj,cb_boton,4L);
  fl_end_group();


  fdui->g_niveles = fl_bgn_group();
  fdui->vol = obj = fl_add_valslider(FL_VERT_SLIDER,270,100,30,210,"Vol");
    fl_set_object_lsize(obj,FL_DEFAULT_SIZE);
    fl_set_object_callback(obj,cb_vol,0);
    fl_set_slider_precision(obj, 0);
    fl_set_slider_bounds(obj, 255, 0);
    fl_set_slider_value(obj, 192);
     fl_set_slider_return(obj, FL_RETURN_END_CHANGED);
  fdui->mic = obj = fl_add_valslider(FL_VERT_SLIDER,220,100,30,210,"Mic");
    fl_set_object_lsize(obj,FL_DEFAULT_SIZE);
    fl_set_object_callback(obj,cb_mic,0);
    fl_set_slider_precision(obj, 0);
    fl_set_slider_bounds(obj, 255, 0);
    fl_set_slider_value(obj, 192);
     fl_set_slider_return(obj, FL_RETURN_END_CHANGED);
  fl_end_group();

  fdui->onoff = obj = fl_add_round3dbutton(FL_PUSH_BUTTON,0,0,30,30,"On");
    fl_set_object_color(obj,FL_COL1,FL_CHARTREUSE);
    fl_set_object_lalign(obj,FL_ALIGN_BOTTOM);
    fl_set_object_callback(obj,cb_onoff,0);
    fl_set_button(obj, 1);
  fl_end_form();

  fdui->lfono->fdui = fdui;

  return fdui;
}
/*---------------------------------------*/

