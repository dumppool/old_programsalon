#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "funciones.h"
#include "config.h"
#include "aux.h"
#include "msj.h"


void modo_texto(void)
	{
	char opcion[10], numero[25], cad[5];
	void marca_favorito(void);
	
	while(1) {
		printf( "\n\nlfono [%s][%s]:\n", cogido?MSJ_ON:MSJ_OFF, 
			colgado?MSJ_COLGADO:MSJ_DESCOLGADO );
		printf( MSJ_TECLAS1 );
		if( !colgado )
			printf( MSJ_TECLAS2 );
		
		printf( MSJ_TECLAS3 );
		
		gets(opcion);
		
		switch( opcion[0] ) {
			case 'c':
				if( cogido )
					suelta_modem();
				else
					coge_modem();
				break;
				
			case 'h':
				if( colgado )
					descuelga();
				else
					cuelga();
				break;
				
			case 'f':
				if( colgado )
					printf( MSJ_DESCUELGUE );
				else
					marca_favorito();
				break;
				
			case 'm':
				if( colgado )
					printf( MSJ_DESCUELGUE );
				else {
					printf( MSJ_MARCAR );
					gets(numero);
					marca_dtmf(numero);
					}
				break;

			case 'v':
				if( colgado )
					printf( MSJ_DESCUELGUE );
				else {
					printf( MSJ_ENTRAR_VOL );
					gets(cad);
					fija_vol( atoi(cad) );
					}
				break;
			
			case 'M':
				if( colgado )
					printf( MSJ_DESCUELGUE );
				else {
					printf( MSJ_ENTRAR_MIC );
					gets(cad);
					fija_mic( atoi(cad) );
					}
				break;
			
			case 'x':
				suelta_modem();
				exit(0);
				
			default:
				printf( MSJ_ERR_OPCION );
			}
		}
	}


void marca_favorito(void)
	{
	int hallado;
	char n[10];
	struct tel_fav *f;
	
	printf( "\n%5s %20s %20s\n", MSJ_NICK, MSJ_NOMBRE, MSJ_TEL );
	printf( "--------------------------------------------------------------\n");
	f= config.tf;
	while(f!=NULL) {
		printf( "%5s %20s %20s\n", f->nick, f->nombre, f->tel );
		f= f->sig;
		}

	printf( MSJ_ELEGIR_NICK );
	gets(n);
	
	if( n[0]==0 )
		return;
		
	hallado= 0;
	f= config.tf;
	while(f!=NULL) {
		if( !strcasecmp(n,f->nick) ) {
			hallado= 1;
			break;
			}
		f= f->sig;
		}

	if( !hallado )
		printf( MSJ_ERR_NICK, n );
	else {
		printf( MSJ_MARCANDO, f->nombre, f->tel );
		marca_dtmf(f->tel);
		}
	}