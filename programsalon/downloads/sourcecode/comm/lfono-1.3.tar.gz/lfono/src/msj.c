#include <stdio.h>

int main()
	{
	char linea[81], id_msj[81];
	int lee(char *l);
	
	printf( "/* Generado por msj.c a partir de msj.txt */\n\n" );
	
	while(1) {
		if( lee(linea) )
			break;
		
		strcpy(id_msj, linea);
		printf( "#ifdef ESPANOL\n" );
		printf( "#define %s ", id_msj );
		
		if( lee(linea) ) {
			fprintf( stderr, "EOF inesperado\n" );
			break;
			}
		printf( "%s\n", linea );
		
		printf( "#else\n" );
		printf( "#define %s ", id_msj );

		if( lee(linea) ) {
			fprintf( stderr, "EOF inesperado\n" );
			break;
			}
		printf( "%s\n", linea );
		
		printf( "#endif\n\n" );
		}
		
	return 0;
	}
	
	
int lee(char *l)
	{
	do {
		if( gets(l)==NULL )
			return 1;
		}
		while(l[0]==';' || l[0]==0);
		
	return 0;
	}
		