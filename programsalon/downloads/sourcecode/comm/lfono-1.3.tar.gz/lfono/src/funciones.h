void coge_modem(void);
void suelta_modem(void);
void descuelga(void);
void dtmf(int digito);
void marca_dtmf(char *numero);
void cuelga(void);
void fija_vol(int vol);
void fija_mic(int mic);
void muere(int retorno);

extern int colgado, cogido;