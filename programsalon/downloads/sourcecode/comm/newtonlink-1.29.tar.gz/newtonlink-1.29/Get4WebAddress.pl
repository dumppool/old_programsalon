#=======================================================================
# Newtonlink   - transfer data between a Apple Newton Message Pad and
#                Unix applications
#
# Copyright (C) 1996-1998    The Newtonlink Developers
#                            (newtonlink@newton.bawue.de)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#=======================================================================

#---------------------------------------------------------------------
# Get4WebAddress
#---------------------------------------------------------------------

# $Log: Get4WebAddress.pl,v $
# Revision 1.3  1998/09/02 13:55:44  kalli
# *** empty log message ***
#
# Revision 1.2  1998/03/07 18:05:05  kalli
# *** empty log message ***
#
# Revision 1.1  1997/11/30 11:52:22  kalli
# Initial revision
#

sub Get4WebAddress {

    # Get Newton addresses and write to addressbook file
    &Get4Addressbook;

    printf "Writing WebAddress files ...\n";

    # Call WebAddress to convert from addressbook format
    system "$WebAddressCommand";
}

1;
