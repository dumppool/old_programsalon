#=======================================================================
# Newtonlink   - transfer data between a Apple Newton Message Pad and
#                Unix applications
#
# Copyright (C) 1996-1998    The Newtonlink Developers
#                            (newtonlink@newton.bawue.de)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#=======================================================================

#---------------------------------------------------------------------
# SloupTest.pl
#---------------------------------------------------------------------

# $Log: SloupTest.pl,v $
# Revision 1.5  1998/03/06 23:12:27  kalli
# Umstellung auf neue ser. Treiber
#
# Revision 1.4  1997/12/15 12:31:25  kalli
# Dump all notes entries
#
# Revision 1.3  1997/12/06 17:08:23  kalli
# Umstellung auf Sloup
#
# Revision 1.2  1997/05/31 09:49:59  kalli
# Test email-groups
#
# Revision 1.1  1997/04/22 20:00:05  kalli
# Initial revision
#


sub SloupTest {

    #send commands to Sloup : send new entries to notes soup
    &send_line (COMNEWTON, "\nNotes");
    &send_line (COMNEWTON, '{labels: \'Business, }'); 
    &send_line (COMNEWTON, "first paragraph, first line");
    &send_line (COMNEWTON, "second line");
    &send_line (COMNEWTON, "third line");
    &send_line (COMNEWTON, "that's all folks");
    &send_line (COMNEWTON, "----------");
    &send_line (COMNEWTON, "second paragraph, first line");
    &send_line (COMNEWTON, "2nd line");
    &send_line (COMNEWTON, "3rd line");
    &send_line (COMNEWTON, "4th line");
    &send_line (COMNEWTON, "more");
    &send_line (COMNEWTON, "more");
    &send_line (COMNEWTON, "more");
    &send_line (COMNEWTON, "more");
    &send_line (COMNEWTON, "more");
    &send_line (COMNEWTON, "more");
    &send_line (COMNEWTON, "etc.");
    &send_line (COMNEWTON, "end");
    &send_line (COMNEWTON, "---------");
    &send_line (COMNEWTON, "third para");
    &send_line (COMNEWTON, "---------");
    &send_line (COMNEWTON, "BYE!");
}

1;
