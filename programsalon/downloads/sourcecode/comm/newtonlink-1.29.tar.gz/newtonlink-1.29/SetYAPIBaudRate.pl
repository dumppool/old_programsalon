#---------------------------------------------------------------------
# SetYAPIBaudrate
#---------------------------------------------------------------------

# $Log: SetYAPIBaudRate.pl,v $
# Revision 1.1  1996/11/24 19:17:48  kalli
# Initial revision
#

sub SetYAPIBaudrate {

    if ($YAPIBaudrate eq "38400") {
	system "setserial $tty spd_normal";
	system "stty 38400 < $tty";
    } elsif ($YAPIBaudrate eq "19200") {
	system "setserial $tty spd_normal";
	system "stty 19200 < $tty";
    } else {
	printf "Exit - wrong YAPI baudrate selected\n";
	exit;
    }

}

1;
