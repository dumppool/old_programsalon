// FrontEnd Plus for JAD
// DeCompiled : encoder.class

package utils;

import java.util.Date;

// Referenced classes of package utils:
//            coder, encoderException

public class encoder extends coder//�����
{

    public void int16(short word0)//����һ��16λ����
    {
        if(len + 2 > size)
            increase(2);
        bytes[len] = (byte)(word0 >>> 8 & 0xff);
        len++;
        bytes[len] = (byte)(word0 & 0xff);
        len++;
    }

    public void int16(byte byte0)
    {
        int16(byte0);
    }

    public void int16(int i)
    {
        int16((short)i);
    }

    public void UTC(Date date)//������ת��Ϊ�ַ���
        throws encoderException
    {
        try
        {
            if(date == null)
            {
                int8(0);
                return;
            }
            int i = date.getTimezoneOffset();
            String s1;
            if(i <= 0)
                s1 = s2c((Math.abs(i) + 1) / 15) + "+";
            else
                s1 = s2c((i + 1) / 15) + "-";
            String s = s2c(date.getYear()) + s2c(date.getMonth() + 1) + s2c(date.getDate()) + s2c(date.getHours()) + s2c(date.getMinutes()) + s2c(date.getSeconds()) + (int)((date.getTime() % 1000L) / 100L) + s1;
            asciiz(s, 16);
            return;
        }
        catch(Exception exception)
        {
            throw new encoderException(exception + "time.");
        }
    }

    public void int8(byte byte0)//����һ���ַ�
    {
        if(len + 1 > size)
            increase(1);
        bytes[len] = byte0;
        len++;
    }

    public void int8(short word0)
    {
        int8((byte)word0);
    }

    public void int8(int i)
    {
        int8((byte)i);
    }

    public byte[] getBytes()//ȡ������
    {
        byte abyte0[] = new byte[len];
        for(int i = 0; i < len; i++)
            abyte0[i] = bytes[i];

        return abyte0;
    }

    public void int32(int i)//����һ��32λ����
    {
        if(len + 4 > size)
            increase(4);
        bytes[len] = (byte)(i >>> 24 & 0xff);
        len++;
        bytes[len] = (byte)(i >>> 16 & 0xff);
        len++;
        bytes[len] = (byte)(i >>> 8 & 0xff);
        len++;
        bytes[len] = (byte)(i & 0xff);
        len++;
    }

    public void int32(short word0)
    {
        int32(word0);
    }

    public void int32(byte byte0)
    {
        int32(byte0);
    }

    private static String s2c(int i)//�������淶��100����
    {
        int j = i % 100;
        if(j < 10)
            return "0" + j;
        else
            return "" + j;
    }

    public encoder(int i)
    {
        super(i);
    }

    public encoder()
    {
        super(0);
    }

    public void asciiz(String s, int i)//�����ַ�
        throws encoderException
    {
        int j = s.length();
        if(j > i)
            throw new encoderException("toolong.string.");
        if(len + j + 1 > size)
            increase(j + 1);
        for(int k = 0; k < j; k++)
        {
            bytes[len] = (byte)(s.charAt(k) & 0xff);
            len++;
        }

        bytes[len] = 0;
        len++;
    }
}
