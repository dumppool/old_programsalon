// FrontEnd Plus for JAD
// DeCompiled : decoderException.class

package utils;


public class decoderException extends Exception//�����쳣
{

    private String s;

    public decoderException(String s1)
    {
        s = s1;
    }

    public String toString()
    {
        return s;
    }
}
