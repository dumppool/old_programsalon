// FrontEnd Plus for JAD
// DeCompiled : socks.class

package utils;

import java.io.*;
import java.net.*;

// Referenced classes of package utils:
//            socksException

public class socks
{

    static final byte SOCKS_VERSION = 4;
    static final byte SOCKS_CONNECT = 1;
    static final byte SOCKS_CONNECT_RESPONSE_LEN = 8;
    static final byte SOCKS_ERROR_GRANTED = 90;
    static final byte SOCKS_ERROR_REJECTED = 91;
    static final byte SOCKS_ERROR_IDENTD = 92;
    static final byte SOCKS_ERROR_USERID = 93;
    private static InetAddress socksAddress;
    private static int socksPort;
    private static String userid;

    public static Socket Socket(InetAddress inetaddress, int i)
    //ָ������ĵ�ַ�Ͷ˿ںţ������ӵ�������
        throws socksException, IOException
    {
        if(socksAddress == null || i == 0)
        {
            System.out.println("No Socks V4 server specified");
            return new Socket(inetaddress, i);
        }
        System.out.println("Socks V4 server specified");
        int j;
        if(userid == null)
            j = 9;
        else
            j = 9 + userid.length();
        byte abyte0[] = new byte[j];
        byte abyte1[] = inetaddress.getAddress();
        Socket socket;
        try
        {
            socket = new Socket(socksAddress, socksPort);
        }
        catch(Exception exception)
        {
            throw new socksException(" " + exception);
        }
        InputStream inputstream = socket.getInputStream();
        OutputStream outputstream = socket.getOutputStream();
        if(abyte1.length < 4)
            throw new socksException("Cant convert IP address for server");
        abyte0[0] = 4;
        abyte0[1] = 1;
        abyte0[2] = (byte)(i >>> 8 & 0xff);
        abyte0[3] = (byte)(i & 0xff);
        abyte0[4] = abyte1[0];
        abyte0[5] = abyte1[1];
        abyte0[6] = abyte1[2];
        abyte0[7] = abyte1[3];
        j = 8;
        if(userid == null)
        {
            abyte0[j] = 0;
            j++;
        } else
        {
            userid.getBytes(0, userid.length(), abyte0, 8);
            j += userid.length();
            abyte0[j] = 0;
            j++;
        }
        try
        {
            outputstream.write(abyte0, 0, j);
        }
        catch(IOException _ex)
        {
            throw new socksException("Cannot send a request to the proxy");
        }
        j = 0;
        do
        {
            int k;
            try
            {
                k = inputstream.read(abyte0, j, 1);
            }
            catch(IOException _ex)
            {
                throw new socksException("Cannot read a response from proxy");
            }
            if(k == -1)
                throw new socksException("proxy prematurely closed connection");
            if(j == 1)
                switch(abyte0[1])
                {
                case 91: // '['
                    throw new socksException("proxy rejected the connect request");

                case 92: // '\\'
                    throw new socksException("proxy cannot connect to client's ident daemon");

                case 93: // ']'
                    throw new socksException("ident daemon and client user-ids conflict");

                default:
                    throw new socksException("proxy returned unknown error (" + abyte0[1] + ")");

                case 90: // 'Z'
                    break;
                }
        } while(++j < 8);
        return socket;
    }

    public static Socket Socket(String s, int i)
        throws UnknownHostException, IOException, socksException
    {
        InetAddress inetaddress;
        try
        {
            inetaddress = InetAddress.getByName(s);
        }
        catch(NullPointerException nullpointerexception)
        {
            System.out.println("Cannot convert address to ip " + nullpointerexception);
            throw new UnknownHostException("Cannot resolve host (suspect application has gone off line) " + nullpointerexception);
        }
        return Socket(inetaddress, i);
    }

    public static void setProxy(InetAddress inetaddress, int i, String s)//���ô����ĵ�ַ�Ͷ˿ںţ��Լ��û���ʶ
    {
        socksAddress = inetaddress;
        socksPort = i;
        userid = s;
    }

    public static void setProxy(InetAddress inetaddress, int i)//���ô����ĵ�ַ�Ͷ˿ں�
    {
        socksAddress = inetaddress;
        socksPort = i;
        userid = null;
    }

    public static void setProxy(String s, int i)
        throws UnknownHostException
    {
        setProxy(InetAddress.getByName(s), i);
    }

    public static void setProxy(String s, int i, String s1)
        throws UnknownHostException
    {
        setProxy(InetAddress.getByName(s), i, s1);
    }

    public socks()//��ʼ��
    {
    }

}
