// FrontEnd Plus for JAD
// DeCompiled : socksException.class

package utils;


public class socksException extends Exception//socks�쳣
{

    private String s;

    socksException(String s1)
    {
        s = s1;
    }

    public String toString()
    {
        return "SOCKS V4 problem, " + s;
    }
}
