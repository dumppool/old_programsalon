// FrontEnd Plus for JAD
// DeCompiled : proxyWriter.class

package utils;

import java.io.*;
import java.net.Socket;

class proxyWriter
    implements Runnable
{

    private static final int WRITE_BUFFER_SIZE = 1024;
    private InputStream in;
    private OutputStream out;
    protected Thread t;
    protected Thread rt;
    private static boolean log_on;
    private Socket server;

    private static void log(String s)
    {
        if(log_on)
            System.out.println("Writer: " + s);
    }

    proxyWriter(InputStream inputstream, OutputStream outputstream, Socket socket, Thread thread, boolean flag)
    {
        in = inputstream;
        out = outputstream;
        log_on = flag;
        server = socket;
        rt = thread;
        t = new Thread(this, "Writer");
        t.start();
    }

    public void run()
    {
        log("Started");
        byte abyte0[] = new byte[1024];
        try
        {
            do
            {
                int i = in.read(abyte0);
                if(i == -1)
                {
                    log("Client connection closed");
                    break;
                }
                out.write(abyte0, 0, i);
            } while(true);
        }
        catch(Exception exception)
        {
            log("Reason is " + exception);
        }
        try
        {
            server.close();
        }
        catch(Exception exception1)
        {
            log("Cannot close server socket" + exception1);
        }
        try
        {
            in.close();
        }
        catch(Exception exception2)
        {
            log("Cannot close client input " + exception2);
        }
        try
        {
            out.close();
        }
        catch(Exception exception3)
        {
            log("Cannot close server output " + exception3);
        }
        log("Finished");
    }
}
