// FrontEnd Plus for JAD
// DeCompiled : fifo.class

package utils;


// Referenced classes of package utils:
//            semaphore

public class fifo extends semaphore//��ջ
{

    private int step;
    private Object objs[];
    private int start;
    private int next;
    private int count;

    public fifo(int i)
    {
        super("FIFO");
        step = 20;
        step = i;
        objs = new Object[step];
    }

    public fifo()
    {
        super("FIFO");
        step = 20;
        objs = new Object[step];
    }

    private void resize()
    {
        Object aobj[] = new Object[objs.length + step];
        int i = start;
        for(int j = 0; j != count; j++)
        {
            if(i == objs.length)
                i = 0;
            aobj[j] = objs[i];
            i++;
        }

        objs = aobj;
        start = 0;
        next = count;
    }

    public Object peek()
        throws InterruptedException
    {
        use();
        if(count == 0)
        {
            finished();
            return null;
        } else
        {
            Object obj = objs[start];
            finished();
            return obj;
        }
    }

    public void push(Object obj)
        throws InterruptedException
    {
        if(obj == null)
            return;
        use();
        if(count == 0)
        {
            objs[0] = obj;
            start = 0;
            next = 1;
            count = 1;
            finished();
            return;
        }
        if(count == objs.length)
            resize();
        objs[next] = obj;
        next++;
        count++;
        if(next == objs.length)
            next = 0;
        finished();
    }

    public Object pop()
        throws InterruptedException
    {
        use();
        if(count == 0)
        {
            finished();
            return null;
        }
        Object obj = objs[start];
        objs[start] = null;
        start++;
        count--;
        if(start == objs.length)
            start = 0;
        if(count == 0)
        {
            start = 0;
            next = 0;
        }
        finished();
        return obj;
    }
}
