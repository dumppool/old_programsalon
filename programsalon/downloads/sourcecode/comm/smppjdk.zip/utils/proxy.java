// FrontEnd Plus for JAD
// DeCompiled : proxy.class

package utils;

import java.io.DataInputStream;
import java.io.PrintStream;
import java.net.*;

// Referenced classes of package utils:
//            proxyReader

public class proxy//������������!
{

    private static boolean log_on;
    private static DataInputStream din;

    private static void log(String s)
    {
        if(log_on)
            System.out.println("Proxy:  " + s);
    }

    private static void usage()
    {
        print("Usage: jproxy local-port remote-host remote-port [log]");
        print("This relays incoming connections on the local-port to");
        print("the server at the remote-host listening on remote-port.");
        print("The 'log' option turns on the log");
        print("(C) Copyright 1997 Noctor Consulting");
    }

    public proxy()
    {
    }

    private static String get()
        throws Exception
    {
        if(din == null)
            din = new DataInputStream(System.in);
        return din.readLine();
    }

    private static void print(String s)
    {
        System.out.println(s);
    }

    public static void main(String args[])
    {
        if(args.length != 3 && args.length != 4)
        {
            usage();
            return;
        }
        if(args.length == 4)
            log_on = true;
        int i;
        try
        {
            i = Integer.parseInt(args[0]);
        }
        catch(Exception _ex)
        {
            print("Invalid local-port number");
            return;
        }
        int j;
        try
        {
            j = Integer.parseInt(args[2]);
        }
        catch(Exception _ex)
        {
            print("Invalid remote-port number");
            return;
        }
        InetAddress inetaddress;
        try
        {
            inetaddress = InetAddress.getByName(args[1]);
        }
        catch(Exception exception)
        {
            print("Can't convert remote-host to IP address" + exception);
            return;
        }
        try
        {
            ServerSocket serversocket = new ServerSocket(i);
            log("Started... (on port " + i + ")");
            do
            {
                Socket socket = serversocket.accept();
                log("Call from " + socket.getInetAddress() + " on port " + socket.getPort());
                new proxyReader(socket, inetaddress, j, log_on);
            } while(true);
        }
        catch(Exception exception1)
        {
            log("Can't accept any more connections ");
            log("Reason is " + exception1);
        }
        try
        {
            Thread.currentThread().join();
            return;
        }
        catch(Exception exception2)
        {
            log("Finished threading " + exception2);
        }
    }
}