// FrontEnd Plus for JAD
// DeCompiled : decoder.class

package utils;

import java.util.Date;

// Referenced classes of package utils:
//            coder, decoderException

public class decoder extends coder
{

    public short int16()//��ƫ���������ֽڣ���ɶ������ֽ�
        throws decoderException
    {
        if(offset + 1 > size)
        {
            throw new decoderException("underrun.int16.");
        } else
        {
            short word0 = (short)((bytes[offset] & 0xff) << 8 | bytes[offset + 1] & 0xff);
            offset += 2;
            return word0;
        }
    }

    public Date UTC()//���ַ���ʱ��ת��Ϊ�����׼ʱ��
        throws decoderException
    {
        String s = asciiz(18);
        if(s == null)
            return null;
        if(s.length() == 0)
            return null;
        if(s.length() != 16 && s.length() != 18)
            throw new decoderException("length.time.");
        int i2 = 0;
        int k1;
        int l1;
        long l2;
        try
        {
            int i;
            if(s.length() == 16)
            {
                i = Integer.parseInt(s.substring(i2, i2 + 2));
                if(i < 97)
                    i += 2000;
                else
                if(i < 100)
                    i += 1900;
                i2 += 2;
            } else
            if(s.length() == 18)
            {
                i = Integer.parseInt(s.substring(i2, i2 + 4));
                i2 += 4;
            } else
            {
                return null;
            }
            int j = Integer.parseInt(s.substring(i2, i2 + 2));
            i2 += 2;
            int k = Integer.parseInt(s.substring(i2, i2 + 2));
            i2 += 2;
            int l = Integer.parseInt(s.substring(i2, i2 + 2));
            i2 += 2;
            int i1 = Integer.parseInt(s.substring(i2, i2 + 2));
            i2 += 2;
            int j1 = Integer.parseInt(s.substring(i2, i2 + 2));
            i2 += 2;
            k1 = Integer.parseInt(s.substring(i2, i2 + 1));
            i2++;
            l1 = Integer.parseInt(s.substring(i2, i2 + 2));
            i2 += 2;
            i -= 1900;
            j--;
            l2 = Date.UTC(i, j, k, l, i1, j1);
        }
        catch(Exception _ex)
        {
            throw new decoderException("format.time.");
        }
        l2 += k1 * 100;
        if(s.charAt(i2) == '+')
            l2 -= l1 * 15 * 60000;
        else
            l2 += l1 * 15 * 60000;
        return new Date(l2);
    }

    public byte int8()//ȡ��ƫ���������ַ�
        throws decoderException
    {
        if(offset > size)
        {
            throw new decoderException("underrun.int8.");
        } else
        {
            byte byte0 = bytes[offset];
            offset++;
            return byte0;
        }
    }

    public int int32()//ȡ��ƫ��������32λ����
        throws decoderException
    {
        if(offset + 3 > size)
        {
            throw new decoderException("underrun.int32.");
        } else
        {
            int i = (bytes[offset] & 0xff) << 24 | (bytes[offset + 1] & 0xff) << 16 | (bytes[offset + 2] & 0xff) << 8 | bytes[offset + 3] & 0xff;
            offset += 4;
            return i;
        }
    }

    public decoder(byte abyte0[])
    {
        super(abyte0);
    }

    public String asciiz(int i)//��offset����ת��Null��β���ַ���
        throws decoderException
    {
        byte abyte0[] = new byte[i + 1];
        int j;
        for(j = 0; j < i + 1 && offset + j < size && bytes[offset + j] != 0; j++)
            abyte0[j] = bytes[offset + j];

        if(offset + j == size)//�������б�Ҫô��
            throw new decoderException("underrun.string.");
        if(j == i + 1)//�������б�Ҫô��
            throw new decoderException("toolong.string.");
        offset += j + 1;
        if(j == 0)//���iΪ0�����ؿ��ַ���
        {
            return null;
        } else
        {
            abyte0[j] = 0;//��βΪ0��ת��Ϊ��0��β���ַ���
            return new String(abyte0, 0, 0, j);
        }
    }
}
