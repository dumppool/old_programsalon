// FrontEnd Plus for JAD
// DeCompiled : encoderException.class

package utils;


public class encoderException extends Exception //�����쳣
{

    private String s;

    public encoderException(String s1)
    {
        s = s1;
    }

    public String toString()
    {
        return s;
    }
}
