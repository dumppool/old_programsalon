// FrontEnd Plus for JAD
// DeCompiled : table.class

package utils;


// Referenced classes of package utils:
//            semaphore

public class table extends semaphore//��ϣ��
{

    private int step;
    private Object keys[];
    private Object records[];

    public void add(Object obj, Object obj1)
        throws InterruptedException
    {
        if(obj == null)
        {
            return;
        } else
        {
            use();
            int i = emptySlot();
            keys[i] = obj;
            records[i] = obj1;
            finished();
            return;
        }
    }

    private int emptySlot()
    {
        int i;
        for(i = 0; i < keys.length; i++)
            if(keys[i] == null)
                return i;

        resize();
        return i;
    }

    public table(int i)
    {
        super("TABLE");
        step = 5;
        step = i;
        keys = new Object[step];
        records = new Object[step];
    }

    public table()
    {
        super("TABLE");
        step = 5;
        keys = new Object[step];
        records = new Object[step];
    }

    private void resize()
    {
        Object aobj[] = new Object[keys.length + step];
        Object aobj1[] = new Object[records.length + step];
        int i;
        for(i = 0; i < keys.length; i++)
        {
            aobj[i] = keys[i];
            aobj1[i] = records[i];
        }

        for(; i < aobj.length; i++)
            aobj[i] = null;

        keys = aobj;
        records = aobj1;
    }

    private int getIndex(Object obj)
    {
        for(int i = 0; i < keys.length; i++)
            if(keys[i] == obj)
                return i;

        return -1;
    }

    public Object get(Object obj)
        throws InterruptedException
    {
        if(obj == null)
            return null;
        use();
        int i = getIndex(obj);
        if(i == -1)
        {
            finished();
            return null;
        } else
        {
            Object obj1 = records[i];
            finished();
            return obj1;
        }
    }

    public Object delete(Object obj)
        throws InterruptedException
    {
        if(obj == null)
            return null;
        use();
        int i = getIndex(obj);
        if(i == -1)
        {
            finished();
            return null;
        } else
        {
            Object obj1 = records[i];
            records[i] = null;
            keys[i] = null;
            finished();
            return obj1;
        }
    }
}
