// FrontEnd Plus for JAD
// DeCompiled : coder.class

package utils;


public class coder//����
{

    protected int len;//����
    protected int offset;//ƫ����
    protected int size;//��С
    protected int step;//ÿ�����ӵĳ���
    protected byte bytes[];//�ֽ�����

    protected void increase(int i)//����step���ӳ���
    {
        if(i < step)
            i = step;
        int j = size + i;
        byte abyte0[] = new byte[j];
        for(int k = 0; k < size; k++)
            abyte0[k] = bytes[k];

        bytes = abyte0;
        size = j;
    }

    public int lenfix(byte byte0)
    {
        if(byte0 >= 0)
            return byte0;
        else
            return byte0 + 256;
    }

    public int lenfix(int i)
    {
        return i;
    }

    protected coder(int i)
    {
        len = 0;
        offset = 0;
        if(i == 0)
            i = 500;
        size = i;
        step = i;
        bytes = new byte[size];
    }

    protected coder(byte abyte0[])
    {
        size = abyte0.length;
        bytes = abyte0;
        len = abyte0.length;
        offset = 0;
        step = 500;
    }

    public String toString()//�任��16���ַ�һ�е�16����ASCII��
    {
        String s = "Size:" + size + " Len:" + len + " Offset:" + offset + " Step:" + step;
        for(int j = 0; j < len; j++)
        {
            if(j % 16 == 0)
                s = s + "\n  ";
            int i = bytes[j] & 0xff;
            if(i < 16)
                s = s + '0';
            s = s + Integer.toHexString(i) + " ";
        }

        s = s + "\n";
        return s;
    }
}
