// FrontEnd Plus for JAD
// DeCompiled : proxyReader.class

package utils;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

// Referenced classes of package utils:
//            proxyWriter

class proxyReader
    implements Runnable
{

    private static final int READ_BUFFER_SIZE = 1024;
    private Socket client;
    private InetAddress host;
    private int port;
    private Thread t;
    private static boolean log_on;

    public void start()
    {
        log("(Started)");
    }

    public void stop()
    {
        log("(Stopped)");
    }

    private static void log(String s)
    {
        if(log_on)
            System.out.println("Reader: " + s);
    }

    public void run()
    {
        Socket socket = null;
        proxyWriter proxywriter = null;
        InputStream inputstream = null;
        InputStream inputstream1 = null;
        OutputStream outputstream = null;
        OutputStream outputstream1 = null;
        Exception exception = null;
        try
        {
            try
            {
                socket = new Socket(host, port);
            }
            catch(Exception exception1)
            {
                log("Cannot connect to server at " + host + " on port " + port);
                exception = exception1;
                return;
            }
            try
            {
                inputstream = client.getInputStream();
                outputstream = client.getOutputStream();
                inputstream1 = socket.getInputStream();
                outputstream1 = socket.getOutputStream();
            }
            catch(Exception exception2)
            {
                log("Cannot create I/O streams");
                exception = exception2;
                return;
            }
            try
            {
                proxywriter = new proxyWriter(inputstream, outputstream1, socket, t, log_on);
            }
            catch(Exception exception3)
            {
                log("Cannot create the writer");
                exception = exception3;
                return;
            }
            byte abyte0[] = new byte[1024];
            try
            {
                do
                {
                    int i = inputstream1.read(abyte0);
                    if(i == -1)
                    {
                        log("Server connection closed");
                        client.close();
                        break;
                    }
                    outputstream.write(abyte0, 0, i);
                } while(true);
                return;
            }
            catch(Exception exception4)
            {
                log("Cannot forward any more data");
                exception = exception4;
            }
            return;
        }
        catch(Exception exception5)
        {
            log("Reason is " + exception5);
        }
        finally
        {
            if(exception != null)
                log("Reason is " + exception);
            if(proxywriter != null)
            {
                try
                {
                    proxywriter.t.join();
                }
                catch(Exception exception7)
                {
                    log("Can't join with writer " + exception7);
                }
            } else
            {
                if(inputstream != null)
                    try
                    {
                        inputstream.close();
                    }
                    catch(Exception exception8)
                    {
                        log("Can't close client input " + exception8);
                    }
                if(outputstream1 != null)
                    try
                    {
                        outputstream1.close();
                    }
                    catch(Exception exception9)
                    {
                        log("Can't close server output" + exception9);
                    }
            }
            if(inputstream1 != null)
                try
                {
                    inputstream1.close();
                }
                catch(Exception exception10)
                {
                    log("Can't close server input " + exception10);
                }
            if(outputstream != null)
                try
                {
                    outputstream.close();
                }
                catch(Exception exception11)
                {
                    log("Can't close client output" + exception11);
                }
            if(socket != null)
                try
                {
                    socket.close();
                }
                catch(Exception exception12)
                {
                    log("Can't close server socket" + exception12);
                }
            if(client != null)
                try
                {
                    client.close();
                }
                catch(Exception exception13)
                {
                    log("Can't close client socket" + exception13);
                }
            log("Finished");
        }
        log("Finished");
    }

    proxyReader(Socket socket, InetAddress inetaddress, int i, boolean flag)
    {
        log_on = flag;
        client = socket;
        host = inetaddress;
        port = i;
        log("Started");
        t = new Thread(this, "Reader");
        t.start();
    }
}
