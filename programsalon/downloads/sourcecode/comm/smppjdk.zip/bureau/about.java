
/*
 * Copyright (C) 1998 Noctor Consulting, Ltd. All rights reserved.
 * SMS JDK 2.0 Bureau application
 */

package bureau;
import java.awt.*;

public class about extends Dialog
{
  smb parent;
	// Control definitions
	Button        IDOK;
	Label         IDC_STATIC1;
	Label         IDC_STATIC2;
	Label         IDC_STATIC3;


	// Constructor
	public about (smb parent)
	{
    super(parent,"About",true);
    if(parent!=null) setFont(parent.getFont());
    this.parent=parent;

		DialogLayout m_Layout = new DialogLayout(parent, 203, 142);
		setLayout(m_Layout);

		Dimension size   = m_Layout.getDialogSize();
		Insets    insets = parent.insets();
		
		resize(insets.left + size.width  + insets.right,
                        insets.top  + size.height + insets.bottom);

		IDOK = new Button ("OK");
		add(IDOK);
		m_Layout.setShape(IDOK, 75, 121, 50, 14);

    String text=
"Bureau Application/Applet\n"+
"Copyright (c) 1998 Noctor Consulting.\n\n"+
"This sample application can be executed\n" +
"as a Java applet within a web browser or as\n" +
"an application using a command line loader\n" +
"such as Microsoft's 'jview' command or SUN\n" +
"Microsystems 'java' command.\n\n" +
"The source code of this applet/application\n"+
"is available with SMS JDK 2.0\n\n"+

"The applet looks for parameters at run-time.\n"+
"These are shown below. They are set in the\n"+
"HTML file in which the applet is embedded.\n"+
"All (except the IMaGe) are optional and can\n"+
"be configured within the application or\n"+
"the applet:-\n"+
"  <param name=\"img\" value=\"images/sms.jpg\" param>\n"+
"  <param name=\"id\" value=\"id\">\n"+
"  <param name=\"type\" value=\"type\">\n"+
"  <param name=\"pass\" value=\"pass\">\n"+
"  <param name=\"host\" value=\"hostname\">\n"+
"  <param name=\"port\" value=\"8011\">\n\n"+
"The command line arguments are the same except\n"+
"they have a '-' before the parameter name:-\n" +
"  -id sysid\n"+
"  -type systype\n"+
"  -pass password\n"+
"  -host hostname\n"+
"  -port 8011\n";

/*
    Label ta = new Label(text);
*/
    TextArea ta=new TextArea(text);
    ta.setEditable(false);
    add(ta);
		m_Layout.setShape(ta, 7, 7, 189, 108);

    show();
	}


  public boolean handleEvent(Event ev)
  {
  if(ev.id==Event.WINDOW_DESTROY)
    { 
    this.dispose(); 
    return true;
    }
  return super.handleEvent(ev);;
  }

  public boolean action(Event ev,Object obj)
  {
  if(ev.target instanceof Button)
    {
      dispose(); return true;
    }
  return false;
  }
}



