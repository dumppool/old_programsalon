
/*
 * Copyright (C) 1998 Noctor Consulting, Ltd. All rights reserved.
 * SMS JDK 2.0 Bureau application
 */


package bureau;

import java.net.*;
import java.awt.*;
import java.util.*;
import sms.*;
import utils.*;

class smb extends Frame implements sms.Constants,
        sms.BindResponse,
        sms.SendResponse,
        sms.ReplaceResponse,
        sms.CancelResponse,
        sms.StatusResponse
{
  String sysid;
  String systype;
  String password;
  String smscip;
  String smscport;

  String socksip;
  String socksport;
  String socksuserid;
  boolean applet=false;

  Vector vmessages;
  List messages;

  Smpp smbc; // smb connection

  menu m;

  public void bindResponse(Exception ex,Binding b)
  {
    if(ex!=null) new mbox(this,trans.lookup("Cannot bind")+": "+ex);
    else new mbox(this,"Connected: "+b.smscID());
  }

  public void cancelResponse(Exception ex,Message m)
  {
    if(ex!=null) new mbox(this,trans.lookup("Cannot cancel")+": "+ex);
    else new mbox(this,"Message cancelled");
  }

  public void statusResponse(Exception ex,Message m)
  {
    if(ex!=null) new mbox(this,trans.lookup("Cannot query")+": "+ex);
    else 
      {
      String s = trans.lookup("Message status")+": ";
      switch(m.getStatus())
        {
          case STATUS_ENROUTE: s+=trans.lookup("Enroute");break;
          case STATUS_DELIVERED: s+=trans.lookup("Delivered");break;
          case STATUS_EXPIRED: s+=trans.lookup("Expired");break;
          case STATUS_DELETED: s+=trans.lookup("Deleted");break;
          case STATUS_UNDELIVERABLE: s+=trans.lookup("Undeliverable");break;
          case STATUS_ACCEPTED: s+=trans.lookup("Accepted");break;
          default: s+="Invalid";break;
        }
      if(m.getTimeStamp()!=null) s+=" - "+trans.lookup("Time stamp")+": "+m.getTimeStamp();
      if(m.getGSMerror()!=0) s+=" - "+trans.lookup("GSM error")+": "+m.getGSMerror();
      new mbox(this,s);
      }
  }

  public void sendResponse(Exception ex,Message m)
  {
    System.out.println("Send calback");
    if(ex!=null) 
      new mbox(this,"Cannot send"+ex);
    else 
      {
      Address a = (Address)m.getTo();
      messages.addItem( a.getNumber()+" "+m.getText());
      vmessages.addElement(m);
      }
  }

  public void replaceResponse(Exception ex,Message m)
  {
    System.out.println("Send calback");
    if(ex!=null) 
      new mbox(this,trans.lookup("Cannot send")+ex);
    else 
      {
      int i;
      for(i=0;i<vmessages.size();i++)
        { 
          Message vm = (Message) vmessages.elementAt(i);
          System.out.println("Callback Message id "+m.getID());
          System.out.println("vm Message id "+vm.getID());
          if( m.getID().equals(vm.getID())==true )
            {
              Address a = (Address)m.getTo();
              messages.delItem(i);
              messages.addItem( a.getNumber()+" "+m.getText(),i);
              vmessages.setElementAt(m,i);
              break;
            }
        }
      }
  }
  smb(boolean applet)
  {
    super("Short Messaging");
    m = new menu(this);
    m.CreateMenu();
    vmessages = new Vector();
    this.applet=applet;


    messages = new List(20,false);

    setLayout( new  BorderLayout() );
    add("Center",messages);
  
    setBackground(java.awt.Color.lightGray);
    resize(300,300);
    this.show();
  }

  public boolean handleEvent(Event ev)
  {
  if(ev.id==Event.WINDOW_DESTROY)
    { 
    if(smbc!=null) smbc.close();
    this.dispose(); 
    if(!applet)
      System.exit(0);
    return true;
    }
  return super.handleEvent(ev);;
  }

  public void connect() throws Exception
  {
    if(smscip==null || smscport==null)
      { new mbox(this,trans.lookup("Please configure the application")); return;}
    if(socksip!=null && socksport!=null)
      {
      System.out.println("Setting Socks proxy "+socksip+":"+socksport);
      socks.setProxy(socksip,Integer.parseInt(socksport));
      }
    System.out.println("Parse port");
    int port = Integer.parseInt(smscport);
    System.out.println("Creating a new SMPP connection "+smscip+":"+smscport);
    if(smbc!=null) smbc.close();
    smbc=new Smpp(smscip,port); 
    smbc.debug(true,true);
    System.out.println("Binding...");
    Binding b = new Binding(sysid,systype,password);
    smbc.bind(this,b); 
    System.out.println("Awaiting a response...");
  }

  public boolean action(Event ev,Object obj)
  {
    System.out.println("obj: '"+obj+"'");
    if( ev.target instanceof MenuItem )
      {
        if( ev.target == m.ID_FILE_EXIT )
         { 
        if(smbc!=null) smbc.close();
	      this.dispose(); 
        if(!applet)
          System.exit(0);
        return true;
	 }
        if( ev.target == m.ID_FILE_CONFIGURE )
         {
           configureDialog cdialog = new configureDialog(this);
           return true;
         }
        if( ev.target == m.ID_FILE_CONNECT)
         {
           try {connect();} 
           catch(Exception ex)
             { 
              if(smbc!=null) smbc.close();
              new mbox(this,trans.lookup("Cannot connect")+": "+ex);
             }

           return true;
	 }

        if( ev.target == m.ID_FILE_DISCONNECT)
         {
           try { 
                if(smbc!=null)
                  { smbc.close(); smbc=null; }
                }
           catch(Exception ex)
             { new mbox(this,trans.lookup("Ungraceful disconnection")+": "+ex);}
           return true;
	 }

        if( ev.target == m.ID_FILE_SOCKS)
         {
           new socksDialog(this);
           return true;
	 }
        if( ev.target == m.ID_MESSAGE_CANCEL)
         {
            if(smbc==null) 
              {new mbox(this,trans.lookup("No connection established")); return true;}
           int i=messages.getSelectedIndex();
           if(i<0) { new mbox(this,trans.lookup("Please select a message first")); 
                        return true;}
           try {smbc.cancel(this,(Message)vmessages.elementAt(i) );}
           catch(Exception e){new mbox(this,trans.lookup("Cannot cancel")+": "+e);}
           return true;
	 }
        if( ev.target == m.ID_MESSAGE_QUERY)
         {
            if(smbc==null) 
              {new mbox(this,trans.lookup("No connection established")); return true;}
           int i=messages.getSelectedIndex();
           if(i<0) { new mbox(this,trans.lookup("Please select a message first")); 
                        return true;}
           try{smbc.status(this,(Message)vmessages.elementAt(i) );}
           catch(Exception e){new mbox(this,trans.lookup("Cannot query")+": "+e);}
           return true;
	 }
        if( ev.target == m.ID_MESSAGE_SEND)
         {
            if(smbc==null) 
              {new mbox(this,trans.lookup("No connection established")); return true;}
           new messageDialog(this);
           return true;
	 }
        if( ev.target == m.ID_MESSAGE_REPLACE)
         {
            if(smbc==null) 
              {new mbox(this,trans.lookup("No connection established")); return true;}
           int i;
           if( (i=messages.getSelectedIndex())==-1)
             {
               new mbox(this,trans.lookup("Please select a message first")); 
               return true;
             }
           new messageDialog(this,(Message)(vmessages.elementAt(i)) );
           return true;
	 }
        if( ev.target == m.ID_HELP_ABOUT)
         { 
           new about(this);
           return true;
	 }
      }
    return false;
  }

  public void finalize()
  {
    System.out.print("Finalized");
  }
}
