
/*
 * Copyright (C) 1998 Noctor Consulting, Ltd. All rights reserved.
 * SMS JDK 2.0 Bureau application
 */

package bureau;

class trans
{
  static String words[]=
  {  
  "File","Fichier",
  "Connect","Connectez",
  "Disconnect","Debranchez",
  "Configure","Initialization",
  "Exit","Sortez",

  "Send...","Envoyez...",
  "Replace...","Replacez...",
  "Cancel","Annulez",
  "Query","Remettez",

  "Help","Aidez",
  "About...","Au sujet...",

  "Number:","Nombre:",
  "Text","Texte",

  "OK","D'accord",
  "Cancel","Annulez",
  "Please configure the application","Initialization!"
  };

  private static int langoff=0;

  static void setLanguage(String s)
  {
    System.out.println("Setting language to "+s);
    if( s.equals("english") )
      {langoff=0;}
    else if( s.equals("french") ) 
      { langoff=1;}
    else {System.out.println("Unknown language");}
    System.out.println("Offset "+langoff);
  }

  static String lookup(String s)
  {
    for(int i=0;i<words.length;i+=2)
      {
        if( s.equals(words[i]) ) return words[i+langoff];
      }
    System.out.println("Can't translate "+s);
    return s;
  }
}

