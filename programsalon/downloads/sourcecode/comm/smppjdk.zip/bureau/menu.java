
/*
 * Copyright (C) 1998 Noctor Consulting, Ltd. All rights reserved.
 * SMS JDK 2.0 Bureau application
 */

package bureau;
import java.awt.*;

public class menu
{
	Frame   m_Frame        = null;
	boolean m_fInitialized = false;

	// MenuBar definitions
	MenuBar mb;

	// Menu and Menu item definitions
	Menu m1;	// File
	MenuItem ID_FILE_CONNECT;	// Connect
	MenuItem ID_FILE_DISCONNECT;	// Disconnect
	MenuItem ID_FILE_CONFIGURE;	// Configure...
	MenuItem ID_FILE_SOCKS;	// Socks...
	MenuItem m5;	// Separator
	/*
	MenuItem ID_FILE_LOAD;	// Load
	MenuItem ID_FILE_SAVE;	// Save
	MenuItem m8;	// Separator
	*/
	MenuItem ID_FILE_EXIT;	// Exit
	Menu m10;	// Message
	MenuItem ID_MESSAGE_SEND;	// Send...
	MenuItem ID_MESSAGE_REPLACE;	// Replace...
	MenuItem ID_MESSAGE_CANCEL;	// Cancel
	MenuItem ID_MESSAGE_QUERY;	// Query
	Menu m11;	// Message
	MenuItem ID_HELP_ABOUT;	// About...

	// Constructor
	public menu (Frame frame)
	{
		m_Frame = frame;
	}

	// Initialization.
	public boolean CreateMenu()
	{
		// Can only init controls once
		if (m_fInitialized || m_Frame == null)
			return false;

		// Create menubar and attach to the frame
		mb = new MenuBar();
		m_Frame.setMenuBar(mb);

		// Create menu and menu items and assign to menubar
		m1 = new Menu(trans.lookup("File"));
		mb.add(m1);
			ID_FILE_CONNECT = new MenuItem(trans.lookup("Connect"));
			m1.add(ID_FILE_CONNECT);
			ID_FILE_DISCONNECT = new MenuItem(trans.lookup("Disconnect"));
			m1.add(ID_FILE_DISCONNECT);
			ID_FILE_CONFIGURE = new MenuItem(trans.lookup("Configure..."));
			m1.add(ID_FILE_CONFIGURE);
			ID_FILE_SOCKS = new MenuItem(trans.lookup("Socks..."));
			m1.add(ID_FILE_SOCKS);
			m5 = new MenuItem("-");
			m1.add(m5);
			/*
			ID_FILE_LOAD = new MenuItem(trans.lookup("Load"));
			m1.add(ID_FILE_LOAD);
			ID_FILE_SAVE = new MenuItem(trans.lookup("Save"));
			m1.add(ID_FILE_SAVE);
			m8 = new MenuItem("-");
			m1.add(m8);
			*/
			ID_FILE_EXIT = new MenuItem(trans.lookup("Exit"));
			m1.add(ID_FILE_EXIT);
		m10 = new Menu(trans.lookup("Message"));
		mb.add(m10);
			ID_MESSAGE_SEND = new MenuItem(trans.lookup("Send..."));
			m10.add(ID_MESSAGE_SEND);
			ID_MESSAGE_REPLACE = new MenuItem(trans.lookup("Replace..."));
			m10.add(ID_MESSAGE_REPLACE);
			ID_MESSAGE_CANCEL = new MenuItem(trans.lookup("Cancel"));
			m10.add(ID_MESSAGE_CANCEL);
			ID_MESSAGE_QUERY = new MenuItem(trans.lookup("Query"));
			m10.add(ID_MESSAGE_QUERY);
		m11 = new Menu(trans.lookup("Help"));
		mb.add(m11);
			ID_HELP_ABOUT = new MenuItem(trans.lookup("About..."));
			m11.add(ID_HELP_ABOUT);

		m_fInitialized = true;
		return true;
	}
}
