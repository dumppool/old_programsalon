
/*
 * Copyright (C) 1998 Noctor Consulting, Ltd. All rights reserved.
 * SMS JDK 2.0 Bureau application
 */

package bureau;
import java.awt.*;

public class mbox extends Dialog
{
  public mbox (Frame parent,String message)
  {
	super(parent,parent.getTitle(),true);
        if(parent!=null) setFont(parent.getFont());

  int width = getFontMetrics(getFont()).stringWidth(message);

	DialogLayout m_Layout = new DialogLayout(parent, width+20, 50);
	setLayout(m_Layout);
	Dimension size   = m_Layout.getDialogSize();
	Insets    insets = parent.insets();
	resize(insets.left + size.width  + insets.right,
                        insets.top  + size.height + insets.bottom);

  /*
  resize(width,100);

  */
	Button IDOK = new Button ("OK");
	add(IDOK);
	m_Layout.setShape(IDOK, (width>>>1)-25, 37, 50, 14);

	Label IDTEXT = new Label(message,Label.CENTER);
	add(IDTEXT);
	m_Layout.setShape(IDTEXT, 5, 5, width, 30);

	show();
  }

  public boolean handleEvent(Event ev)
  {
  if(ev.id==Event.WINDOW_DESTROY)
    { 
    this.dispose(); 
    return true;
    }
  return super.handleEvent(ev);;
  }

  public boolean action(Event ev,Object obj)
  {
  if(ev.target instanceof Button)
    {
      // only one button
      dispose(); return true;
    }
  return false;
  }

}
