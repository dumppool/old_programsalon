
/*
 * Copyright (C) 1998 Noctor Consulting, Ltd. All rights reserved.
 * SMS JDK 2.0 Bureau application
 */

package bureau;
import java.awt.*;

public class socksDialog extends Dialog
{
	smb           parent;
	Button        IDOK;
	Button        IDCANCEL;
	TextField     IP;
	TextField     PORT;
	TextField     USERID;
	Label         IDC_STATIC1;
	Label         IDC_STATIC2;
	Label         IDC_STATIC3;

  socksDialog(smb parent)
  {
        super(parent,"Socks V4 Proxy",true);
        if(parent!=null) setFont(parent.getFont());
	this.parent=parent;

	DialogLayout m_Layout = new DialogLayout(parent, 190, 80);
	setLayout(m_Layout);
	//m_Parent.addNotify();

	Dimension size   = m_Layout.getDialogSize();
	Insets    insets = parent.insets();
		
	resize(insets.left + size.width  + insets.right,
        insets.top  + size.height + insets.bottom);

	IDOK = new Button ("OK");
	add(IDOK);
	m_Layout.setShape(IDOK, 133, 16, 50, 14);

	IDCANCEL = new Button ("Cancel");
	add(IDCANCEL);
	m_Layout.setShape(IDCANCEL, 133, 34, 50, 14);

	IP = new TextField (parent.socksip!=null?parent.socksip:"");
	add(IP);
	m_Layout.setShape(IP, 57, 16, 54, 16);

	PORT = new TextField (parent.socksport!=null?parent.socksport:"");
	add(PORT);
	m_Layout.setShape(PORT, 57, 38, 54, 16);

	USERID = new TextField (parent.socksuserid!=null?parent.socksuserid:"");
	add(USERID);
	m_Layout.setShape(USERID, 57, 60, 54, 16);

	IDC_STATIC1 = new Label ("Socks IP:", Label.RIGHT);
	add(IDC_STATIC1);
	m_Layout.setShape(IDC_STATIC1, 14, 18, 38, 14);

	IDC_STATIC2 = new Label ("Socks port:", Label.RIGHT);
	add(IDC_STATIC2);
	m_Layout.setShape(IDC_STATIC2, 5, 40, 48, 14);

	IDC_STATIC3 = new Label ("Userid:", Label.RIGHT);
	add(IDC_STATIC3);
	m_Layout.setShape(IDC_STATIC3, 15, 61, 38, 14);

 	show();
  }

  public boolean handleEvent(Event ev)
  {
  if(ev.id==Event.WINDOW_DESTROY)
    { 
    this.dispose(); 
    return true;
    }
  return super.handleEvent(ev);;
  }

  public boolean action(Event ev,Object obj)
  {
  if(ev.target instanceof Button)
    {
      if(ev.target==IDOK)
        {
// Normally, changing SMB object variables should be synchronised
// in a threaded application (as is the case with java windows)
// however, as we have made the window modal, we should have no
// problems
	  parent.socksip=IP.getText();
	  parent.socksport=PORT.getText();
	  parent.socksuserid=USERID.getText();
	  
        }
      dispose(); return true;
    }
  return false;
  }
}
