
/*
 * Copyright (C) 1998 Noctor Consulting, Ltd. All rights reserved.
 * SMS JDK 2.0 Bureau application
 */

package bureau;

import java.applet.*;
import java.awt.*;
import java.io.*;


public class app extends Applet
{
  Image img;
  smb root=null;

  static void print(String s)
  { return ;}
  //{ System.out.println("App.java:"+ s);}

  public void init()
  {
    print("Started");
    print("Getting image");
    img = getImage(getDocumentBase(),getParameter("img"));
    showStatus("Ready");
  }

/*
  public void start()
  { 
  print("Start() called");
  showStatus("Ready");
  if(root!=null)
    root.show();
  }

  public void stop()
  { 
  if(root!=null)
   root.hide();
  }
*/

  public void paint(Graphics g)
  {
    g.drawImage(img,0,0,this);
  }

  public void params(smb s)
  {
          s.sysid=getParameter("id");
          s.systype=getParameter("type");
          s.password=getParameter("pass");
          s.smscip=getParameter("host");
          s.smscport=getParameter("port");
  }
  public boolean mouseUp(Event ev,int x,int y)
  {
    if(root==null)
      {
      root = new smb(true);
      showStatus("SMS running");
      params(root);
      }
    else
      {
      root.dispose();
      root = new smb(true);
      params(root);
      }
    return true;
  }

  public boolean action(Event ev,Object obj)
  {
   if(ev.target instanceof Button)
     { 
     if(root!=null) 
       {
       root.dispose();
       root=null;
       }
     else
       {
       root = new smb(true);
      params(root);
       }
     return true;
     }
   return false;
  }

  // ONLY CALLED IF A VIEWER IS USED
  static void usage()
  {
    System.out.println("Bureau (C) Copyright 1998 Noctor Consulting");
    System.out.println("Usage: bureau ");
    System.out.println("  [-id sysid]");
    System.out.println("  [-type systype]");
    System.out.println("  [-password password]");
    System.out.println("  [-host hostname/IP-address]");
    System.out.println("  [-port smpp-port-number]");
    System.out.println("If all parameters are specified, connection with the SMSC will be attempted.");
  }

  public static void main(String args[])
  {
    int i;
    for(i=0; i<args.length ; i+=2 )
      { if(args[i].equals("-lang")) trans.setLanguage(args[i+1]); }

    smb s = new smb(false);

    for(i=0; i<args.length ; i+=2 )
      {
        if(i==args.length-1) 
          {usage();System.exit(0);}

        if(args[i].equals("-id"))
          s.sysid=args[i+1];
        else if(args[i].equals("-type"))
          s.systype=args[i+1];
        else if(args[i].equals("-pass"))
          s.password=args[i+1];
        else if(args[i].equals("-host"))
          s.smscip=args[i+1];
        else if(args[i].equals("-port"))
          s.smscport=args[i+1];
        else if(args[i].equals("-lang")) ;
        else
          {usage();System.exit(0);}
      }
    if(i==10)
      { 
      try{ s.connect();} 
      catch(Exception e){System.out.println("Can't connect "+e);} 
      }
    return;
  }

}

