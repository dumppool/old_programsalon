
/*
 * Copyright (C) 1998 Noctor Consulting, Ltd. All rights reserved.
 * SMS JDK 2.0 Bureau application
 */

package bureau;
import java.awt.*;
import sms.*;

public class messageDialog extends Dialog implements sms.Constants
{
	Button        IDOK;
	Button        IDCANCEL;
	TextArea      IDTEXT;
	Label         IDC_STATIC1;
	TextField     IDNUMBER;
	Label         IDC_STATIC2;
  smb par;
  Message replace=null;


	void init(Frame parent,Message m)
	{
      par=(smb)parent;

		DialogLayout m_Layout = new DialogLayout(parent, 219, 110);
		setLayout(m_Layout);
		//parent.addNotify();

		Dimension size   = m_Layout.getDialogSize();
		Insets    insets = parent.insets();
		
		resize(insets.left + size.width  + insets.right,
                        insets.top  + size.height + insets.bottom);

		IDOK = new Button (trans.lookup("OK"));
		add(IDOK);
		m_Layout.setShape(IDOK, 162, 7, 50, 14);

		IDCANCEL = new Button (trans.lookup("Cancel"));
		add(IDCANCEL);
		m_Layout.setShape(IDCANCEL, 162, 24, 50, 14);

		IDTEXT = new TextArea ("");
		add(IDTEXT);
		m_Layout.setShape(IDTEXT, 15, 54, 191, 64);

		IDC_STATIC1 = new Label ("Message:", Label.LEFT);
		add(IDC_STATIC1);
		m_Layout.setShape(IDC_STATIC1, 15, 42, 33, 12);

		IDNUMBER = new TextField ("");
    if(m!=null) IDNUMBER.setEditable(false);
		add(IDNUMBER);
		m_Layout.setShape(IDNUMBER, 47, 14, 76, 18);

		IDC_STATIC2 = new Label (trans.lookup("Number:"), Label.LEFT);
		add(IDC_STATIC2);
		m_Layout.setShape(IDC_STATIC2, 16, 17, 29, 12);

    if(m!=null)
      {
      replace=m;
      IDNUMBER.setText( ((Address)m.getTo()).getNumber());
      IDTEXT.setText(m.getText());
      }
		show();
	}

	messageDialog (Frame parent)
	{ 
	  super(parent,"Message",true);
    init(parent,null); 
  }
	messageDialog (Frame parent,Message m)
	{ 
	  super(parent,"Message",true);
    init(parent,m); 
  }

  public boolean handleEvent(Event ev)
  {
  if(ev.id==Event.WINDOW_DESTROY)
    { 
    this.dispose(); 
    return true;
    }
  return super.handleEvent(ev);;
  }

  public boolean action(Event ev,Object obj)
  {
  if(ev.target instanceof Button)
    {
      if(ev.target==this.IDOK)
        {
          try{
            if(replace==null)
              {
              Address a = new Address(IDNUMBER.getText()) ;
              par.smbc.send(par,new Message(a, IDTEXT.getText() ) );
              System.out.println( "Text:"+IDTEXT.getText());
              System.out.println( "Address:"+a);
              }
            else
              {
                replace.setTo( new Address(IDNUMBER.getText()) );
                replace.setText(IDTEXT.getText());
                par.smbc.replace(par,replace);
                
              }
            }
          catch(Exception ex)
            { new mbox(par,trans.lookup("Cannot send: ")+ex);}
         } 
      dispose(); return true;
    }
  return false;
  }

}
