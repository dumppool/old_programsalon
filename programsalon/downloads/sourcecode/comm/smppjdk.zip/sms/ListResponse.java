// FrontEnd Plus for JAD
// DeCompiled : ListResponse.class

package sms;


// Referenced classes of package sms:
//            Address

public interface ListResponse
{

    public abstract void listResponse(Exception exception, Address address, String as[]);
}
