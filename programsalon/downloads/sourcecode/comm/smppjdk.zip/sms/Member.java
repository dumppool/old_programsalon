// FrontEnd Plus for JAD
// DeCompiled : Member.class

package sms;


// Referenced classes of package sms:
//            Address

public class Member
{

    public Address smsAddress;
    String id;
    public int type;

    public String toString()
    {
        return "Member ID:" + id + "\n" + "  SMS Address: " + (smsAddress == null ? "(none)" : smsAddress.toString()) + "\n" + "  Type :" + type + "\n";
    }

    Member()
    {
    }

    public Member(String s, Address address)
    {
        smsAddress = address;
        id = s;
        type = 0;
    }

    public Member(String s)
    {
        smsAddress = null;
        id = s;
        type = 0;
    }
}
