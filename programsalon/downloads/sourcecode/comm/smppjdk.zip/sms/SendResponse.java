// FrontEnd Plus for JAD
// DeCompiled : SendResponse.class

package sms;


// Referenced classes of package sms:
//            Message

public interface SendResponse
{

    public abstract void sendResponse(Exception exception, Message message);
}
