// FrontEnd Plus for JAD
// DeCompiled : GetCustomerResponse.class

package sms;


// Referenced classes of package sms:
//            Customer

public interface GetCustomerResponse
{

    public abstract void getResponse(Exception exception, Customer customer);
}
