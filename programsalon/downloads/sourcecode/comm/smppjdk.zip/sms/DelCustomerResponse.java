// FrontEnd Plus for JAD
// DeCompiled : DelCustomerResponse.class

package sms;


// Referenced classes of package sms:
//            Customer

public interface DelCustomerResponse
{

    public abstract void delResponse(Exception exception, Customer customer);
}
