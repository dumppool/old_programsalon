// FrontEnd Plus for JAD
// DeCompiled : viewDLresponse.class

package sms;


// Referenced classes of package sms:
//            Member

class viewDLresponse
{

    int members_len;
    Member members[];

    viewDLresponse()
    {
    }
}
