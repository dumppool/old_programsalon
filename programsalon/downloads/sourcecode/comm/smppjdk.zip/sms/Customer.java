// FrontEnd Plus for JAD
// DeCompiled : Customer.class

package sms;


// Referenced classes of package sms:
//            Address

public class Customer
{

    String id;
    public String name;
    public String streetAddress;
    public Address smsAddress;
    public int serviceLevel;
    public boolean smsAllowed;
    public int ocos;
    public int tcos;
    public String password;

    Customer()
    {
        id = "";
        name = "";
        streetAddress = "";
        smsAllowed = true;
        password = "";
    }

    public Customer(String s, Address address)
    {
        id = "";
        name = "";
        streetAddress = "";
        smsAllowed = true;
        password = "";
        id = s;
        smsAddress = address;
    }

    public Customer(String s)
    {
        id = "";
        name = "";
        streetAddress = "";
        smsAllowed = true;
        password = "";
        id = s;
        smsAddress = null;
    }

    public String toString()
    {
        return "Customer ID:" + id + "\n" + "  SMS Address: " + (smsAddress == null ? "(none)" : smsAddress.toString()) + "\n" + "  Password: " + (password == null ? "(none)" : password) + "\n" + "  Name: " + (name == null ? "(none)" : name) + "\n" + "  Address: " + (streetAddress == null ? "(none)" : streetAddress) + "\n" + "  Service Level:" + serviceLevel + " OCOS:" + ocos + " TCOS:" + tcos + "\n" + "  SMS Allowed:" + smsAllowed + "\n";
    }
}
