// FrontEnd Plus for JAD
// DeCompiled : smDLModification.class

package sms;


// Referenced classes of package sms:
//            modDL, smDL, Member, Address

class smDLModification extends modDL
{

    Member member;
    boolean delete;

    smDLModification(Address address, String s, Member member1, boolean flag)
    {
        dl = new smDL();
        dl.source = address;
        dl.name = s;
        member = member1;
        delete = flag;
        if(delete)
        {
            modify = member1.id;
            return;
        } else
        {
            modify = member1;
            return;
        }
    }
}
