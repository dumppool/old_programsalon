// FrontEnd Plus for JAD
// DeCompiled : smDL.class

package sms;


// Referenced classes of package sms:
//            Address

class smDL
{

    Address source;
    String name;

    smDL()
    {
    }
}
