// FrontEnd Plus for JAD
// DeCompiled : CancelResponse.class

package sms;


// Referenced classes of package sms:
//            Message

public interface CancelResponse
{

    public abstract void cancelResponse(Exception exception, Message message);
}
