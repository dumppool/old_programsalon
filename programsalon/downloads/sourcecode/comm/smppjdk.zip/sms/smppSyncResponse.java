// FrontEnd Plus for JAD
// DeCompiled : smppSyncResponse.class

package sms;


class smppSyncResponse
{

    Exception exception;
    Object returns;

    smppSyncResponse()
    {
    }
}
