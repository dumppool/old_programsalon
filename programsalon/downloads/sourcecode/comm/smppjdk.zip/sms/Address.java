// FrontEnd Plus for JAD
// DeCompiled : Address.class

package sms;


// Referenced classes of package sms:
//            Constants

public class Address
    implements Constants
{

    int ton;
    int npi;
    String msisdn;
    public static short defaultTON = 2;
    public static short defaultNPI = 1;

    public boolean equals(Address address)
    {
        return ton == address.ton && npi == address.npi && msisdn.equals(address.msisdn);
    }

    public int getTON()
    {
        return ton;
    }

    public String getMSISDN()
    {
        return msisdn;
    }

    Address()
    {
    }

    public Address(String s, int i, int j)
    {
        msisdn = s;
        ton = i;
        npi = j;
    }

    public Address(String s)
    {
        msisdn = s;
        ton = defaultTON;
        npi = defaultNPI;
    }

    public int getNPI()
    {
        return npi;
    }

    public String getNumber()
    {
        return msisdn;
    }

    public String toString()
    {
        return msisdn + " (" + ton + "," + npi + ")";
    }

}
