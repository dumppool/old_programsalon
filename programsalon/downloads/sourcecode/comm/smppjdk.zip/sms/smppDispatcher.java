// FrontEnd Plus for JAD
// DeCompiled : smppDispatcher.class

package sms;

import java.io.*;
import java.net.Socket;
import utils.*;

// Referenced classes of package sms:
//            smppHeader, smppEncoder, Smpp, SMSException, 
//            Receiver, smppDecoder, Message, smppRequest, 
//            smppSyncResponse, smDL, AddDLResponse, DelDLResponse, 
//            smDLModification, AddMemberResponse, modDL, DelMemberResponse, 
//            viewDLresponse, Member, GetMemberResponse, Address, 
//            listDLResponse, DLName, GetDLResponse, param, 
//            ParameterResponse, queryAllResponse, messageId, ListResponse, 
//            Binding, BindResponse, SendResponse, StatusResponse, 
//            ReplaceResponse, CancelResponse, Customer, AddCustomerResponse, 
//            DelCustomerResponse, ModCustomerResponse, GetCustomerResponse, DetailsResponse, 
//            smppCommands, Errors

class smppDispatcher
    implements Runnable, smppCommands, Errors
{

    boolean debugon;
    fifo pendingRequests;
    table pendingResponses;
    InputStream in;
    Thread dispatcherThread;
    Smpp smppSender;

    private void log(String s)
    {
        if(debugon)
            System.out.println("" + Thread.currentThread() + "  DISPATCHER: " + s);
    }

    private void queryLinkRespond(int i)
    {
        smppHeader smppheader = new smppHeader();
        smppheader.command = 0x80000015;
        smppheader.status = 0;
        smppheader.length = 16;
        smppheader.sequence = i;
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            smppencoder.smppHeader(smppheader);
            smppSender.write(smppencoder.getBytes(), null);
            return;
        }
        catch(encoderException encoderexception)
        {
            if(debugon)
            {
                log("Error sending query link response " + encoderexception);
                return;
            } else
            {
                return;
            }
        }
        catch(IOException _ex)
        {
            return;
        }
        catch(SMSException _ex)
        {
            return;
        }
    }

    private void receiveRespond(int i, Message message)
    {
        try
        {
            smppEncoder smppencoder = new smppEncoder();
            smppencoder.submitResponse(message);
            smppHeader smppheader = new smppHeader();
            smppheader.command = 0x80000004;
            smppheader.status = 0;
            smppheader.length = 16 + smppencoder.getBytes().length;
            smppheader.sequence = i;
            smppEncoder smppencoder1 = new smppEncoder();
            smppencoder1.smppHeader(smppheader);
            smppSender.write(smppencoder1.getBytes(), smppencoder.getBytes());
            return;
        }
        catch(Exception exception)
        {
            smppSender.receiverTarget.receive(exception, message);
        }
    }

    public void smppDispatch(int i)
        throws SMSException, decoderException, encoderException, IOException
    {
        try
        {
            smppRequest smpprequest;
            while(smpprequest.sequenceNumber != i) 
            {
                smppDecoder smppdecoder;
                smppHeader smppheader;
                do
                {
                    if(debugon)
                        log("Waiting for smpp header");
                    smppdecoder = new smppDecoder(read(16));
                    if(debugon)
                        log("Received header " + smppdecoder);
                    smppheader = smppdecoder.smppHeader();
                    if(debugon)
                        log("Header sequence number is " + smppheader.sequence);
                    if(smppheader.length > 16)
                        smppdecoder = new smppDecoder(read(smppheader.length - 16));
                    else
                        smppdecoder = null;
                    if(debugon)
                        log("Message body " + smppdecoder);
                    if(smppheader.command == 21)
                    {
                        if(smppheader.length != 16)
                            throw new SMSException(10005);
                        queryLinkRespond(smppheader.sequence);
                        continue;
                    }
                    if(smppheader.command == 4)
                    {
                        Exception exception = null;
                        if(smppSender.receiverTarget == null)
                            System.out.println("Received a message, but there is no callback");
                        else
                        if(smppdecoder != null)
                        {
                            Message message = new Message("0");
                            try
                            {
                                smppdecoder.submit(message);
                            }
                            catch(Exception exception1)
                            {
                                exception = exception1;
                                message = null;
                            }
                            if(smppSender.receiverTarget.receive(exception, message))
                                receiveRespond(smppheader.sequence, message);
                        }
                        continue;
                    }
                    if(smppheader.command == 0x80000006)
                    {
                        if(debugon)
                            log("received unbind response");
                        return;
                    }
                    smpprequest = (smppRequest)pendingRequests.peek();
                    if(smppheader.sequence < smpprequest.sequenceNumber)
                    {
                        if(debugon)
                            log("Received an old reponse");
                        continue;
                    }
                    if(smppheader.sequence <= smpprequest.sequenceNumber)
                        break;
                    if(debugon)
                        log("Received sequence is " + smppheader.sequence + " expected " + smpprequest.sequenceNumber);
                    if(debugon)
                        log("Received an invalid sequence number in a response");
                } while(true);
                pendingRequests.pop();
                SMSException smsexception;
                if(smppheader.status != 0)
                    smsexception = new SMSException(smppheader.status);
                else
                    smsexception = null;
                if(smppheader.command == 0x80000000)
                {
                    if(smppheader.status == 0)
                        smsexception = new SMSException(10007);
                    smppheader.command = smpprequest.command | 0x80000000;
                }
                try
                {
                    smppCallback(smpprequest, smppheader.command, smsexception, smppdecoder);
                }
                catch(decoderException decoderexception)
                {
                    smppCallback(smpprequest, smppheader.command, new IOException("SMPP protocol error:" + decoderexception), null);
                }
            }
            return;
        }
        catch(InterruptedException _ex)
        {
            throw new SMSException(10011);
        }
    }

    public void run()
    {
        if(debugon)
            log("started");
        try
        {
            smppDispatch(-1);
        }
        catch(Exception exception)
        {
            finishup(exception);
            return;
        }
        finishup(null);
    }

    private void finishup(Exception exception)
    {
        if(exception != null)
        {
            if(debugon)
                log("Ungraceful finish " + exception);
        } else
        if(debugon)
            log("Graceful cleanup");
        if(exception == null)
            exception = new SMSException("Unexpected shutdown");
        if(smppSender.receiverTarget != null)
        {
            Object obj;
            if(exception != null)
                obj = exception;
            else
                obj = new SMSException(10004);
            try
            {
                smppSender.receiverTarget.receive(((Exception) (obj)), null);
            }
            catch(Exception exception1)
            {
                System.out.println("Receive callback threw exception: " + exception1);
            }
        }
        smppRequest smpprequest;
        try
        {
            while((smpprequest = (smppRequest)pendingRequests.pop()) != null) 
                smppCallback(smpprequest, smpprequest.command | 0x80000000, exception, null);
        }
        catch(Exception exception2)
        {
            if(debugon)
                log("Callback cleanup failed " + exception2);
        }
        try
        {
            in.close();
            return;
        }
        catch(IOException ioexception)
        {
            if(debugon)
                log("error closing input stream - " + ioexception);
        }
    }

    void smppCallback(smppRequest smpprequest, int i, Exception exception, smppDecoder smppdecoder)
        throws decoderException
    {
        if(debugon)
            log("Callback");
        smppSyncResponse smppsyncresponse;
        if(smpprequest.thread != null)
        {
            if(debugon)
                log("synch callback");
            smppsyncresponse = new smppSyncResponse();
            smppsyncresponse.returns = null;
            smppsyncresponse.exception = exception;
        } else
        {
            if(debugon)
                log("async callback");
            smppsyncresponse = null;
        }
        int j = 0;
        do
            try
            {
                switch(i)
                {
                case -2147483626: 
                    smDL smdl = (smDL)smpprequest.argument;
                    if(smpprequest.thread == null)
                        ((AddDLResponse)smpprequest.target).addResponse(exception, smdl.source, smdl.name);
                    break;

                case -2147483624: 
                    smDL smdl1 = (smDL)smpprequest.argument;
                    if(smpprequest.thread == null)
                        ((DelDLResponse)smpprequest.target).delResponse(exception, smdl1.source, smdl1.name);
                    break;

                case -2147483625: 
                    smDLModification smdlmodification = (smDLModification)smpprequest.argument;
                    if(smpprequest.thread == null)
                        if(!smdlmodification.delete)
                            ((AddMemberResponse)smpprequest.target).addResponse(exception, smdlmodification.dl.source, smdlmodification.dl.name, smdlmodification.member);
                        else
                            ((DelMemberResponse)smpprequest.target).delResponse(exception, smdlmodification.dl.source, smdlmodification.dl.name, smdlmodification.member);
                    break;

                case -2147483623: 
                    smDL smdl2 = (smDL)smpprequest.argument;
                    Member amember[] = null;
                    if(smppdecoder != null)
                    {
                        viewDLresponse viewdlresponse = smppdecoder.viewDLresponse();
                        amember = new Member[viewdlresponse.members_len];
                        for(j = 0; j < viewdlresponse.members_len; j++)
                            amember[j] = viewdlresponse.members[j];

                    }
                    if(smpprequest.thread == null)
                        ((GetMemberResponse)smpprequest.target).getResponse(exception, smdl2.source, smdl2.name, amember);
                    else
                        smppsyncresponse.returns = amember;
                    break;

                case -2147483616: 
                    Address address = (Address)smpprequest.argument;
                    String as[] = null;
                    if(smppdecoder != null)
                    {
                        listDLResponse listdlresponse = smppdecoder.listDLResponse();
                        as = new String[listdlresponse.names_len];
                        for(j = 0; j < listdlresponse.names_len; j++)
                            as[j] = listdlresponse.names[j].name;

                    }
                    if(smpprequest.thread == null)
                        ((GetDLResponse)smpprequest.target).getResponse(exception, address, as);
                    else
                        smppsyncresponse.returns = as;
                    break;

                case -2147483614: 
                    param param1 = (param)smpprequest.argument;
                    if(smppdecoder != null)
                        smppdecoder.paramRet(param1);
                    if(smpprequest.thread == null)
                        ((ParameterResponse)smpprequest.target).parameterResponse(exception, param1.name, param1.value);
                    else
                        smppsyncresponse.returns = param1.value;
                    break;

                case -2147483613: 
                    Address address1 = (Address)smpprequest.argument;
                    String as1[] = null;
                    if(smppdecoder != null)
                    {
                        queryAllResponse queryallresponse = smppdecoder.queryAllResponse();
                        if(queryallresponse.ids_len != 0)
                        {
                            as1 = new String[queryallresponse.ids_len];
                            for(j = 0; j < queryallresponse.ids_len; j++)
                                as1[j] = queryallresponse.ids[j].id;

                        } else
                        {
                            as1 = null;
                        }
                    }
                    if(smpprequest.thread == null)
                        ((ListResponse)smpprequest.target).listResponse(exception, address1, as1);
                    else
                        smppsyncresponse.returns = as1;
                    break;

                case -2147483647: 
                case -2147483646: 
                    Binding binding = (Binding)smpprequest.argument;
                    if(debugon)
                        log("Decoding bind: " + smppdecoder);
                    if(smppdecoder != null)
                        smppdecoder.bindResponse(binding);
                    if(smpprequest.thread == null)
                        ((BindResponse)smpprequest.target).bindResponse(exception, binding);
                    else
                        smppsyncresponse.returns = binding;
                    break;

                case -2147483644: 
                    Message message = (Message)smpprequest.argument;
                    if(smppdecoder != null)
                        smppdecoder.submitResponse(message);
                    if(smpprequest.thread == null)
                        ((SendResponse)smpprequest.target).sendResponse(exception, message);
                    else
                        smppsyncresponse.returns = message;
                    break;

                case -2147483615: 
                    Message message1 = (Message)smpprequest.argument;
                    if(smppdecoder != null)
                        smppdecoder.submitMultiResponse(message1);
                    if(smpprequest.thread == null)
                        ((SendResponse)smpprequest.target).sendResponse(exception, message1);
                    else
                        smppsyncresponse.returns = message1;
                    break;

                case -2147483645: 
                    Message message2 = (Message)smpprequest.argument;
                    if(smppdecoder != null)
                        smppdecoder.queryResponse(message2);
                    if(smpprequest.thread == null)
                        ((StatusResponse)smpprequest.target).statusResponse(exception, message2);
                    else
                        smppsyncresponse.returns = message2;
                    break;

                case -2147483641: 
                    Message message3 = (Message)smpprequest.argument;
                    if(smpprequest.thread == null)
                        ((ReplaceResponse)smpprequest.target).replaceResponse(exception, message3);
                    else
                        smppsyncresponse.returns = message3;
                    break;

                case -2147483640: 
                    Message message4 = (Message)smpprequest.argument;
                    if(smpprequest.thread == null)
                        ((CancelResponse)smpprequest.target).cancelResponse(exception, message4);
                    else
                        smppsyncresponse.returns = message4;
                    break;

                case -2147483631: 
                case -2147483630: 
                case -2147483629: 
                    Customer customer = (Customer)smpprequest.argument;
                    if(smpprequest.thread == null)
                    {
                        if(i == 0x80000011)
                            ((AddCustomerResponse)smpprequest.target).addResponse(exception, customer);
                        if(i == 0x80000012)
                            ((DelCustomerResponse)smpprequest.target).delResponse(exception, customer);
                        if(i == 0x80000013)
                            ((ModCustomerResponse)smpprequest.target).modResponse(exception, customer);
                    } else
                    {
                        smppsyncresponse.returns = customer;
                    }
                    break;

                case -2147483628: 
                    Customer customer1 = (Customer)smpprequest.argument;
                    if(smppdecoder != null)
                        smppdecoder.getCustomerResponse(customer1);
                    if(smpprequest.thread == null)
                        ((GetCustomerResponse)smpprequest.target).getResponse(exception, customer1);
                    else
                        smppsyncresponse.returns = customer1;
                    break;

                case -2147483612: 
                    Message message5 = (Message)smpprequest.argument;
                    log("Decoding query details response");
                    if(smppdecoder != null)
                        smppdecoder.queryDetailsResponse(message5);
                    log("Query details response decoded");
                    if(smpprequest.thread == null)
                        ((DetailsResponse)smpprequest.target).detailsResponse(exception, message5);
                    else
                        smppsyncresponse.returns = message5;
                    break;

                default:
                    if(debugon)
                        log("Unknown command code " + i);
                    break;

                case -2147483642: 
                case -2147483627: 
                    break;
                }
            }
            catch(decoderException decoderexception)
            {
                if(debugon)
                    log("Decoding error");
                exception = decoderexception;
                smppdecoder = null;
                j = -1;
                if(smpprequest.thread != null)
                    smppsyncresponse.exception = decoderexception;
            }
            catch(Exception exception1)
            {
                if(smpprequest.thread == null)
                {
                    System.out.println("External callback code threw an exception: " + exception1);
                } else
                {
                    System.out.println("Internal dispatcher exception: " + exception1);
                    smppsyncresponse.exception = exception1;
                }
            }
        while(++j < 1);
        if(smpprequest.thread != null)
        {
            if(smpprequest.thread.equals(dispatcherThread))
                return;
            try
            {
                if(debugon)
                    log("Placing response in the table");
                pendingResponses.add(smpprequest.thread, smppsyncresponse);
                if(debugon)
                {
                    log("Response in the table");
                    return;
                }
            }
            catch(InterruptedException interruptedexception)
            {
                if(debugon)
                    log("Cannot store the SMPP response in shared table" + interruptedexception);
            }
        }
    }

    smppDispatcher(Smpp smpp)
        throws IOException
    {
        pendingRequests = smpp.pendingRequests;
        pendingResponses = smpp.pendingResponses;
        smppSender = smpp;
        try
        {
            in = smpp.socket.getInputStream();
        }
        catch(IOException ioexception)
        {
            if(debugon)
                log("Cannot get input stream - " + ioexception);
            throw ioexception;
        }
        dispatcherThread = new Thread(this, "SMPP Dispatcher");
        dispatcherThread.start();
    }

    private byte[] read(int i)
        throws IOException, SMSException
    {
        int j = 0;
        byte abyte0[] = new byte[i];
        try
        {
            int k;
            for(; j < i; j += k)
                if((k = in.read(abyte0, j, i - j)) == -1)
                    throw new IOException("SMSC Connection closed (remotely)");

            return abyte0;
        }
        catch(IOException ioexception)
        {
            if(debugon)
                log("Read error " + ioexception);
            throw ioexception;
        }
    }
}
