// FrontEnd Plus for JAD
// DeCompiled : SMSException.class

package sms;

import utils.encoderException;

// Referenced classes of package sms:
//            Errors

public class SMSException extends Exception
    implements Errors
{

    private static String errorStrings[];
    private static int errorNumbers[];
    private static int errorCount = 0;
    private String exceptionString;
    private int exceptionError;

    private String findString()
    {
        for(int i = 0; i < errorCount; i++)
            if(errorNumbers[i] == exceptionError)
                return errorStrings[i];

        return "Unknown error code (" + exceptionError + ")";
    }

    private static void addSmppError(int i, String s)
    {
        errorStrings[errorCount] = s;
        errorNumbers[errorCount] = i;
        errorCount++;
    }

    SMSException(int i)
    {
        exceptionError = i;
        exceptionString = null;
    }

    SMSException(String s)
    {
        exceptionError = 0;
        exceptionString = s;
    }

    SMSException(int i, String s)
    {
        exceptionError = i;
        exceptionString = s;
    }

    SMSException(encoderException encoderexception)
    {
        exceptionError = 10013;
        exceptionString = encoderexception.toString();
    }

    public int getErrno()
    {
        return exceptionError;
    }

    public String toString()
    {
        if(exceptionError != 0 && exceptionString != null)
            return findString() + ": " + exceptionString;
        if(exceptionString != null)
            return exceptionString;
        else
            return findString();
    }

    static 
    {
        errorStrings = new String[200];
        errorNumbers = new int[errorStrings.length];
        addSmppError(0, "Command successful");
        addSmppError(1, "Invalid message length");
        addSmppError(2, "Invalid command length");
        addSmppError(3, "Invalid command Id");
        addSmppError(4, "Invalid bind status");
        addSmppError(5, "Already bound");
        addSmppError(6, "Invalid Priority flag");
        addSmppError(7, "Invalid register Delivery flag");
        addSmppError(8, "SMSC system error");
        addSmppError(9, "Invalid Parameter");
        addSmppError(10, "Invalid source address");
        addSmppError(11, "Invalid destination address");
        addSmppError(12, "Invalid message ID");
        addSmppError(13, "Invalid password");
        addSmppError(14, "Invalid Password length");
        addSmppError(15, "Invalid System-ID Service-Type Combination");
        addSmppError(17, "Unable to Cancel message");
        addSmppError(18, "Invalid Date Format");
        addSmppError(19, "Cannot Replace Message");
        addSmppError(20, "Too many messages in queue");
        addSmppError(21, "Invalid or Unknown Service Type");
        addSmppError(22, "Service Not Supported");
        addSmppError(23, "Invalid Message-ID Service-Type combination");
        addSmppError(24, "Address mismatch in replacement attempt");
        addSmppError(25, "Can't Add Subscriber");
        addSmppError(26, "Can't delete Subscriber");
        addSmppError(27, "Can't Modify Subscriber");
        addSmppError(28, "Can't Modify Subscriber");
        addSmppError(29, "Invalid Subscriber ID");
        addSmppError(30, "Subscriber-id length invalid");
        addSmppError(31, "Subscriber-name length invalid");
        addSmppError(33, "Subscriber  address length invalid");
        addSmppError(34, "Subscriber  address length invalid");
        addSmppError(35, "Subscriber Already exists");
        addSmppError(36, "Subscriber does not exist");
        addSmppError(38, "Can't Add Distribution List");
        addSmppError(39, "Can't Modify Distribution List");
        addSmppError(40, "Can't Delete Distribution List");
        addSmppError(41, "Can't View Distribution List");
        addSmppError(48, "Can't list Distribution Lists");
        addSmppError(49, "Can't Retrieve Parameter");
        addSmppError(50, "Invalid length for incoming Parameter");
        addSmppError(51, "Invalid number of destinations");
        addSmppError(52, "Invalid Destination Name Length");
        addSmppError(53, "Invalid Desc. Length for member");
        addSmppError(54, "Can't add member to DL");
        addSmppError(55, "Can't delete member from DL");
        addSmppError(56, "Invalid Member Type");
        addSmppError(57, "Invalid Modify Option ");
        addSmppError(64, "Invalid Dest Flag Option-SubMulti ");
        addSmppError(66, "Invalid submit with replace option ");
        addSmppError(67, "Invalid value for esm_class ");
        addSmppError(68, "Can't submit to distribution list ");
        addSmppError(69, "Can't submit to multi recipients");
        addSmppError(70, "Invalid length for source address ");
        addSmppError(71, "Invalid length for dest address ");
        addSmppError(72, "   Invalid source ton ");
        addSmppError(73, "Invalid source npi ");
        addSmppError(80, "Invalid destination ton ");
        addSmppError(81, "Invalid destination npi ");
        addSmppError(82, "Invalid ESM type ");
        addSmppError(83, "Invalid system type ");
        addSmppError(84, "Invalid value for replace flag ");
        addSmppError(85, "Invalid numbner of msgs for query ");
        addSmppError(86, "Limit exceeded (kif) ");
        addSmppError(87, "Transaction not allowd (kif) ");
        addSmppError(88, "Throttling (kif) ");
        addSmppError(89, "Provisionging not allowed ");
        addSmppError(96, "Trans.limit exceeded for primitive");
        addSmppError(97, "Invalid Schedule Date ");
        addSmppError(98, "Invalid Expiry Date ");
        addSmppError(99, "Invalid predefined message ");
        addSmppError(100, "Invalid TON");
        addSmppError(101, "Invalid NPI");
        addSmppError(102, "Invalid Address");
        addSmppError(255, "Unknown Error");
        addSmppError(10000, "Internal Class/Library Error");
        addSmppError(10001, "No default SMSC address specified");
        addSmppError(10002, "Must bind before sending any data");
        addSmppError(10003, "Bind as transmitter to use this");
        addSmppError(10004, "The connection has been closed");
        addSmppError(10005, "Invalid link query length");
        addSmppError(10006, "Protocol error - invalid sequence");
        addSmppError(10007, "General SMPP command failure (NACK)");
        addSmppError(10008, "Response missing");
        addSmppError(10009, "The connection has been closed locally");
        addSmppError(10010, "The SMSC has closed the connection");
        addSmppError(10012, "Bind as receiver to use this");
        addSmppError(10013, "Invalid field");
        addSmppError(10014, "Missing argument");
        addSmppError(128, "Paging Customer ID Invalid No such subscriber");
        addSmppError(129, "Paging Customer ID length Invalid");
        addSmppError(130, "City Length Invalid");
        addSmppError(131, "State Length Invalid");
        addSmppError(132, "Zip Prefix Length Invalid");
        addSmppError(133, "Zip Postfix Length Invalid");
        addSmppError(134, "MIN Length Invalid");
        addSmppError(135, "MIN Invalid (i.e. No such MIN)");
        addSmppError(136, "PIN Length Invalid");
        addSmppError(137, "Terminal Code Length Invalid");
        addSmppError(138, "Channel Length Invalid");
        addSmppError(139, "Coverage Region Length Invalid");
        addSmppError(140, "Cap Code Length Invalid");
        addSmppError(141, "Message delivery time Length Invalid");
        addSmppError(142, "Priority Message Length Invalid");
        addSmppError(143, "Periodic Messages Length Invalid");
        addSmppError(144, "Paging Alerts Length Invalid");
        addSmppError(145, "Short Message User Group Length Invalid");
        addSmppError(146, "Real Time Data broadcasts Length Invalid");
        addSmppError(147, "Registered Delivery Lenght Invalid   ");
        addSmppError(148, "Message Distribution Lenght Invalid");
        addSmppError(149, "Priority Message Length Invalid");
        addSmppError(150, "Message delivery time Invalid");
        addSmppError(151, "Periodic Messages Invalid");
        addSmppError(152, "Message Distribution Invalid");
        addSmppError(153, "Paging Alerts Invalid");
        addSmppError(154, "Short Message User Group Invalid");
        addSmppError(155, "Real Time Data broadcasts Invalid");
        addSmppError(156, "Registered Delivery Invalid");
    }
}
