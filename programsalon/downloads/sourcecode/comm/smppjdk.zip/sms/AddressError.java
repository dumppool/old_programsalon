// FrontEnd Plus for JAD
// DeCompiled : AddressError.class

package sms;


// Referenced classes of package sms:
//            Address

public class AddressError
{

    public Address address;
    public int error;

    AddressError()
    {
    }

    AddressError(Address address1, int i)
    {
        error = i;
        address = address1;
    }
}
