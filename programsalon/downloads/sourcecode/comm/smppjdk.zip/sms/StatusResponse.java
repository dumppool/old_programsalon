// FrontEnd Plus for JAD
// DeCompiled : StatusResponse.class

package sms;


// Referenced classes of package sms:
//            Message

public interface StatusResponse
{

    public abstract void statusResponse(Exception exception, Message message);
}
