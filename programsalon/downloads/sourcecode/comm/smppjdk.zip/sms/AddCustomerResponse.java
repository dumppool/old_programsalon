// FrontEnd Plus for JAD
// DeCompiled : AddCustomerResponse.class

package sms;


// Referenced classes of package sms:
//            Customer

public interface AddCustomerResponse
{

    public abstract void addResponse(Exception exception, Customer customer);
}
