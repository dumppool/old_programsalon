// FrontEnd Plus for JAD
// DeCompiled : DLName.class

package sms;


class DLName
{

    String name;

    DLName()
    {
    }

    public String toString()
    {
        return name;
    }
}
