// FrontEnd Plus for JAD
// DeCompiled : smppRequest.class

package sms;


class smppRequest
{

    int sequenceNumber;
    int command;
    Object argument;
    Object target;
    Thread thread;

    smppRequest(int i, Object obj, Object obj1)
    {
        sequenceNumber = 0;
        command = i;
        argument = obj;
        if(obj1 == null)
        {
            thread = Thread.currentThread();
            target = null;
            return;
        } else
        {
            target = obj1;
            thread = null;
            return;
        }
    }
}
