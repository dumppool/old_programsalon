// FrontEnd Plus for JAD
// DeCompiled : smppCommands.class

package sms;


interface smppCommands
{

    public static final int SMPP_RESPONSE_BIT = 0x80000000;
    public static final int SMPP_NACK = 0x80000000;
    public static final int SMPP_BNDRCV = 1;
    public static final int SMPP_BNDTRN = 2;
    public static final int SMPP_QUERY_SM = 3;
    public static final int SMPP_SUB_SM = 4;
    public static final int SMSC_DELIVER_SM = 5;
    public static final int SMPP_UBD = 6;
    public static final int SMPP_REPLACE_SM = 7;
    public static final int SMPP_CANCEL_SM = 8;
    public static final int SMPP_ADD_SUB = 17;
    public static final int SMPP_DEL_SUB = 18;
    public static final int SMPP_MOD_SUB = 19;
    public static final int SMPP_ENQ_SUB = 20;
    public static final int SMPP_QRYLINK = 21;
    public static final int SMPP_ADD_DL = 22;
    public static final int SMPP_MOD_DL = 23;
    public static final int SMPP_DEL_DL = 24;
    public static final int SMPP_VIEW_DL = 25;
    public static final int SMPP_LIST_DLS = 32;
    public static final int SMPP_SUB_MULTI = 33;
    public static final int SMPP_PARAM_GET = 34;
    public static final int SMPP_QUERY_ALL_MSG = 35;
    public static final int SMPP_QUERY_DETAILS = 36;
}
