// FrontEnd Plus for JAD
// DeCompiled : DelDLResponse.class

package sms;


// Referenced classes of package sms:
//            Address

public interface DelDLResponse
{

    public abstract void delResponse(Exception exception, Address address, String s);
}
