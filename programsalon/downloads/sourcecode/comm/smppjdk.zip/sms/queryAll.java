// FrontEnd Plus for JAD
// DeCompiled : queryAll.class

package sms;


// Referenced classes of package sms:
//            Address

class queryAll
{

    Address source;
    byte count;

    queryAll()
    {
    }
}
