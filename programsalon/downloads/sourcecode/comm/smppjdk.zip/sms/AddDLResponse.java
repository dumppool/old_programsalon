// FrontEnd Plus for JAD
// DeCompiled : AddDLResponse.class

package sms;


// Referenced classes of package sms:
//            Address

public interface AddDLResponse
{

    public abstract void addResponse(Exception exception, Address address, String s);
}
