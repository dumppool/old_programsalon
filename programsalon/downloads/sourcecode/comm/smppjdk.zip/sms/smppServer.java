// FrontEnd Plus for JAD
// DeCompiled : smppServer.class

package sms;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import utils.decoder;
import utils.encoder;

// Referenced classes of package sms:
//            smppDecoder, smppHeader, smppEncoder, Message, 
//            param, Customer, Address, Binding, 
//            listDLResponse, DLName, viewDLresponse, Member, 
//            AddressError, queryAllResponse, queryAll, messageId, 
//            smppCommands, Errors

class smppServer
    implements smppCommands, Errors
{

    ServerSocket ss;
    Socket s;
    InputStream in;
    OutputStream out;
    static boolean logon;
    static boolean debugon;
    int qlink;
    int qlinkr;

    void start()
        throws Exception
    {
        boolean flag = false;
        int i = 0x989680;
        log("Started, ready to accept");
        s = ss.accept();
        in = s.getInputStream();
        out = s.getOutputStream();
        log("Got connection");
        do
        {
            smppDecoder smppdecoder = new smppDecoder(read(16));
            debug(smppdecoder);
            smppHeader smppheader = smppdecoder.smppHeader();
            if(smppheader.length > 16)
            {
                smppdecoder = new smppDecoder(read(smppheader.length - 16));
                debug(smppdecoder);
            } else
            {
                smppdecoder = null;
            }
            log("Sequence " + smppheader.sequence + " length " + smppheader.length + " command " + smppheader.command);
            smppEncoder smppencoder = new smppEncoder();
            if(smppheader.command == 0x80000015)
            {
                log("Link check response");
                qlinkr++;
            } else
            if((smppheader.command & 0x80000000) != 0)
            {
                if(smppheader.command == 0x80000004)
                {
                    Message message = smppdecoder.submitResponse();
                    log("Response from deliver short message " + message.id);
                }
            } else
            {
                switch(smppheader.command)
                {
                case 34: // '"'
                    param param1 = smppdecoder.paramGet();
                    param1.value = param1.name + "-value";
                    smppencoder.paramRet(param1);
                    break;

                case 21: // '\025'
                    log("Received link query");
                    break;

                case 7: // '\007'
                    log("Replace short message");
                    break;

                case 8: // '\b'
                    log("Cancel short message");
                    break;

                case 22: // '\026'
                    log("Add distribution list");
                    break;

                case 23: // '\027'
                    log("Modify distribution list");
                    break;

                case 24: // '\030'
                    log("Delete distribution list");
                    break;

                case 17: // '\021'
                    log("Add Customer");
                    break;

                case 18: // '\022'
                    log("Delete Customer");
                    break;

                case 19: // '\023'
                    log("Modify Customer");
                    break;

                case 20: // '\024'
                    log("Query Customer");
                    Customer customer = smppdecoder.getCustomer();
                    customer.ocos = 11111;
                    customer.tcos = 22222;
                    customer.serviceLevel = 33333;
                    customer.password = "qpass";
                    customer.streetAddress = "qstreet";
                    customer.name = "qname";
                    customer.smsAddress = new Address("qaddress", 9, 9);
                    customer.smsAllowed = false;
                    smppencoder.getCustomerResponse(customer);
                    break;

                case 1: // '\001'
                    flag = true;
                    // fall through

                case 2: // '\002'
                    log("Bind");
                    Binding binding = smppdecoder.bind();
                    binding.smsc = "ESME";
                    smppencoder.bindResponse(binding);
                    break;

                case 6: // '\006'
                    log("Unbind");
                    smppencoder = null;
                    break;

                case 32: // ' '
                    log("List DLS");
                    listDLResponse listdlresponse = new listDLResponse();
                    listdlresponse.names = new DLName[20];
                    listdlresponse.names_len = 20;
                    int j = 0;
                    do
                    {
                        DLName dlname = new DLName();
                        dlname.name = "DLNAME" + j;
                        listdlresponse.names[j] = dlname;
                    } while(++j < 20);
                    smppencoder.listDLResponse(listdlresponse);
                    break;

                case 25: // '\031'
                    log("View DL");
                    viewDLresponse viewdlresponse = new viewDLresponse();
                    viewdlresponse.members = new Member[20];
                    viewdlresponse.members_len = 20;
                    int k = 0;
                    do
                        viewdlresponse.members[k] = new Member("mem" + k, new Address("memaddr" + k, k, k));
                    while(++k < 20);
                    smppencoder.viewDLresponse(viewdlresponse);
                    break;

                case 4: // '\004'
                    log("Submit");
                    Message message1;
                    if(smppdecoder == null)
                    {
                        log("No message body!");
                        message1 = new Message();
                    } else
                    {
                        log("Submit Decoding submit");
                        message1 = smppdecoder.submit();
                        log("Submit Decoded submit");
                    }
                    message1.id = "" + i;
                    i++;
                    log("Submit Sending response");
                    smppencoder.submitResponse(message1);
                    log("Submit response sent");
                    break;

                case 33: // '!'
                    log("Submit-multi");
                    Message message2 = smppdecoder.submitMulti();
                    message2.id = "" + i;
                    i++;
                    message2.fails = new AddressError[1];
                    message2.fails[0] = new AddressError(new Address("999999999", 9, 9), 100);
                    message2.fails_len = 1;
                    smppencoder.submitMultiResponse(message2);
                    break;

                case 3: // '\003'
                    log("Query message");
                    Message message3 = smppdecoder.query();
                    message3.gsmError = 9;
                    message3.status = 9;
                    message3.timeStamp = new Date();
                    smppencoder.queryResponse(message3);
                    break;

                case 35: // '#'
                    log("Query all messages");
                    queryAll queryall = smppdecoder.queryAll();
                    log("Decoded");
                    queryAllResponse queryallresponse = new queryAllResponse();
                    queryallresponse.ids = new messageId[queryall.count];
                    for(int l = 0; l < queryall.count; l++)
                    {
                        queryallresponse.ids[l] = new messageId();
                        queryallresponse.ids[l].id = "12345678";
                    }

                    queryallresponse.ids_len = queryall.count;
                    smppencoder.queryAllResponse(queryallresponse);
                    break;

                case 36: // '$'
                    log("Query message details");
                    Message message4 = smppdecoder.queryDetails();
                    message4.priority = false;
                    message4.replacement = false;
                    message4.registered = false;
                    message4.esm = 0;
                    message4.dcs = 1;
                    message4.pid = 1;
                    message4.setFrom(new Address("999", 9, 9));
                    message4.predefined = 0;
                    message4.setText("This is a query details response");
                    message4.CC(new Address("000", 0, 0));
                    message4.CC(new Address("111", 1, 1));
                    message4.CC(new Address("222", 2, 2));
                    message4.CC("DLIST1");
                    message4.CC("DLIST2");
                    message4.CC("DLIST3");
                    message4.schedule = new Date();
                    message4.expiry = new Date();
                    message4.gsmError = 9;
                    message4.status = 9;
                    message4.timeStamp = new Date();
                    smppencoder.queryDetailsResponse(message4);
                    break;

                default:
                    log("Unknown command code " + smppheader.command);
                    break;
                }
                if(smppheader.command == 6)
                {
                    s.close();
                    return;
                }
                byte abyte0[] = null;
                if(smppencoder != null)
                    abyte0 = smppencoder.getBytes();
                smppheader.command = smppheader.command | 0x80000000;
                if(abyte0 != null)
                    smppheader.length = abyte0.length + 16;
                else
                    smppheader.length = 16;
                smppEncoder smppencoder1 = new smppEncoder();
                smppencoder1.smppHeader(smppheader);
                log("Sending header");
                byte abyte1[] = smppencoder1.getBytes();
                log("  Header sent");
                debug(smppencoder1);
                if(smppencoder != null)
                    debug(smppencoder);
                log("Sending body");
                byte abyte2[];
                if(abyte0 != null)
                    abyte2 = new byte[abyte1.length + abyte0.length];
                else
                    abyte2 = new byte[abyte1.length];
                for(int i1 = 0; i1 < abyte1.length; i1++)
                    abyte2[i1] = abyte1[i1];

                if(abyte0 != null)
                {
                    for(int j1 = 0; j1 < abyte0.length; j1++)
                        abyte2[j1 + abyte1.length] = abyte0[j1];

                }
                out.write(abyte2);
                log("  body sent");
                if(smppheader.command == 0x80000006)
                {
                    System.out.println("Server closing connection");
                    s.close();
                    return;
                }
                if(flag)
                    sendMessages(10);
            }
        } while(true);
    }

    static void log(String s1)
    {
        if(logon)
            System.out.println("SERVER: " + s1);
    }

    void stats()
    {
        log("Link queries sent " + qlink + " received " + qlinkr);
    }

    void sendqlink()
        throws Exception
    {
        smppHeader smppheader = new smppHeader();
        smppheader.command = 21;
        smppheader.sequence = qlink;
        qlink++;
        smppheader.status = 0;
        smppheader.length = 16;
        smppEncoder smppencoder = new smppEncoder();
        smppencoder.smppHeader(smppheader);
        out.write(smppencoder.getBytes());
        log("Sent query link");
    }

    void close()
        throws Exception
    {
        s.close();
    }

    smppServer(int i)
        throws Exception
    {
        ss = new ServerSocket(i);
    }

    static void debug(decoder decoder)
    {
        if(!debugon)
        {
            return;
        } else
        {
            System.out.println("RECEIVED: " + decoder);
            return;
        }
    }

    static void debug(encoder encoder1)
    {
        if(!debugon)
        {
            return;
        } else
        {
            System.out.println("SENT:     " + encoder1);
            return;
        }
    }

    void sendMessages(int i)
        throws Exception
    {
        for(int j = 0; j < i; j++)
        {
            Message message = new Message();
            message.priority = false;
            message.replacement = false;
            message.registered = false;
            message.esm = 0;
            message.dcs = 1;
            message.pid = 1;
            message.setFrom(new Address("999", 9, 9));
            message.setTo(new Address("8888", 8, 8));
            message.predefined = 0;
            message.setText("This is a message to be received");
            message.schedule = new Date();
            message.expiry = new Date();
            smppEncoder smppencoder1 = new smppEncoder();
            smppencoder1.submit(message);
            smppHeader smppheader = new smppHeader();
            smppheader.command = 4;
            smppheader.sequence = j;
            smppheader.status = 0;
            smppheader.length = 16 + smppencoder1.getBytes().length;
            smppEncoder smppencoder = new smppEncoder();
            smppencoder.smppHeader(smppheader);
            out.write(smppencoder.getBytes());
            out.write(smppencoder1.getBytes());
            log("Sent message");
        }

    }

    public static void main(String args[])
    {
        smppServer smppserver = null;
        try
        {
            smppserver = new smppServer(8011);
        }
        catch(Exception exception)
        {
            log("Exception: " + exception);
            return;
        }
        for(int i = 0; i < args.length; i++)
        {
            if(args[i].equals("log"))
                logon = true;
            if(args[i].equals("debug"))
                debugon = true;
        }

        do
        {
            try
            {
                smppserver.start();
            }
            catch(Exception exception1)
            {
                log("Exception: " + exception1);
            }
            smppserver.stats();
            try
            {
                smppserver.close();
            }
            catch(Exception exception2)
            {
                log("Close Exception: " + exception2);
            }
        } while(true);
    }

    byte[] read(int i)
        throws IOException
    {
        int j = 0;
        byte abyte0[] = new byte[i];
        try
        {
            int k;
            for(; j < i; j += k)
                if((k = in.read(abyte0, j, i - j)) == -1)
                    throw new IOException("SMSC Connection closed (remotely)");

            return abyte0;
        }
        catch(IOException ioexception)
        {
            log("Read error " + ioexception);
            throw ioexception;
        }
    }
}
