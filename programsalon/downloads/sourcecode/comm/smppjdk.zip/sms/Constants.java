// FrontEnd Plus for JAD
// DeCompiled : Constants.class

package sms;


public interface Constants
{

    public static final short GSM_ERR_NONE = 0;
    public static final short GSM_ERR_P_UNKNOWN = 1;
    public static final short GSM_ERR_P_PROVISION = 11;
    public static final short GSM_ERR_T_BARRED = 13;
    public static final short GSM_ERR_P_CUG = 15;
    public static final short GSM_ERR_T_MSSUPPORT = 19;
    public static final short GSM_ERR_T_MSERROR = 20;
    public static final short GSM_ERR_T_SUPPORT = 21;
    public static final short GSM_ERR_T_MEMCAP = 22;
    public static final short GSM_ERR_T_ABSENT = 29;
    public static final short GSM_ERR_T_ABSENT_DETACHED = 30;
    public static final short GSM_ERR_T_ABSENT_PAGEFAIL = 31;
    public static final short GSM_ERR_T_SUPPORT_ROAMING = 32;
    public static final short GSM_ERR_T_SYSTEM = 36;
    public static final short GSM_TON_UNKNOWN = 0;
    public static final short GSM_TON_INTERNATIONAL = 1;
    public static final short GSM_TON_NATIONAL = 2;
    public static final short GSM_TON_NETWORK = 3;
    public static final short GSM_TON_SUBSCRIBER = 4;
    public static final short GSM_TON_ALPHANUMERIC = 5;
    public static final short GSM_TON_ABBREVIATED = 6;
    public static final short GSM_TON_RESERVED_EXTN = 7;
    public static final short GSM_NPI_UNKNOWN = 0;
    public static final short GSM_NPI_E164 = 1;
    public static final short GSM_NPI_ISDN = 1;
    public static final short GSM_NPI_X121 = 3;
    public static final short GSM_NPI_TELEX = 4;
    public static final short GSM_NPI_NATIONAL = 8;
    public static final short GSM_NPI_PRIVATE = 9;
    public static final short GSM_NPI_ERMES = 10;
    public static final short GSM_NPI_RESERVED_EXTN = 15;
    public static final short GSM_ASCII_MESSAGE_LENGTH = 160;
    public static final short GSM_OCTET_MESSAGE_LENGTH = 140;
    public static final short MAXIMUM_MESSAGE_LENGTH = 255;
    public static final short GSM_DCS_7BIT = 0;
    public static final short GSM_DCS_8BIT = 244;
    public static final short GSM_DCS_SIM = 246;
    public static final short GSM_PID_NORMAL = 0;
    public static final short GSM_PID_TELEX = 1;
    public static final short GSM_PID_TELEFAX3 = 2;
    public static final short GSM_PID_TELEFAX4 = 3;
    public static final short GSM_PID_VOICE = 4;
    public static final short GSM_PID_ERMES = 5;
    public static final short GSM_PID_PAGING_SYSTEM = 6;
    public static final short GSM_PID_VIDEOTEX = 7;
    public static final short GSM_PID_UCI = 13;
    public static final short GSM_PID_X400_MHS = 17;
    public static final short STATUS_ENROUTE = 1;
    public static final short STATUS_DELIVERED = 2;
    public static final short STATUS_EXPIRED = 3;
    public static final short STATUS_DELETED = 4;
    public static final short STATUS_UNDELIVERABLE = 5;
    public static final short STATUS_ACCEPTED = 6;
    public static final short STATUS_INVALID = 7;
}
