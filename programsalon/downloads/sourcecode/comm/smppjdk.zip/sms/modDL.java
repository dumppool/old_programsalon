// FrontEnd Plus for JAD
// DeCompiled : modDL.class

package sms;


// Referenced classes of package sms:
//            smDL

class modDL
{

    smDL dl;
    Object modify;

    modDL()
    {
    }
}
