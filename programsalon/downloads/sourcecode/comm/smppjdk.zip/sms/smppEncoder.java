// FrontEnd Plus for JAD
// DeCompiled : smppEncoder.class

package sms;

import utils.*;

// Referenced classes of package sms:
//            Message, Customer, smDL, param, 
//            messageId, smppHeader, Address, listDLResponse, 
//            queryAllResponse, Binding, DLName, modDL, 
//            viewDLresponse, AddressError, queryAll, Member

class smppEncoder extends encoder
{

    public void cancel(Message message)
        throws encoderException
    {
        String s = null;
        try
        {
            if(message == null)
                throw new encoderException("missing.cancel.");
            s = "service.";
            if(message.service != null)
                asciiz(message.service, 6);
            else
                int8(0);
            s = "id.";
            if(message.id != null)
                asciiz(message.id, 9);
            else
                int8(0);
            s = "from.";
            Address(message.from);
            s = "to.";
            Address(message.to);
            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void modifyCustomer(Customer customer)
        throws encoderException
    {
        String s = null;
        try
        {
            if(customer == null)
                throw new encoderException("missing.modifyCustomer.");
            s = "id.";
            if(customer.id != null)
                asciiz(customer.id, 21);
            else
                int8(0);
            s = "name.";
            if(customer.name != null)
                asciiz(customer.name, 21);
            else
                int8(0);
            s = "streetAddress.";
            if(customer.streetAddress != null)
                asciiz(customer.streetAddress, 31);
            else
                int8(0);
            s = "smsAddress.";
            Address(customer.smsAddress);
            s = "serviceLevel.";
            int32(customer.serviceLevel);
            s = "smsAllowed.";
            int8(!customer.smsAllowed ? 0 : 1);
            s = "ocos.";
            int32(customer.ocos);
            s = "tcos.";
            int32(customer.tcos);
            s = "password.";
            if(customer.password != null)
            {
                asciiz(customer.password, 9);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void submitResponse(Message message)
        throws encoderException
    {
        String s = null;
        try
        {
            if(message == null)
                throw new encoderException("missing.submitResponse.");
            s = "id.";
            if(message.id != null)
            {
                asciiz(message.id, 9);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void addDL(smDL smdl)
        throws encoderException
    {
        String s = null;
        try
        {
            if(smdl == null)
                throw new encoderException("missing.addDL.");
            s = "source.";
            Address(smdl.source);
            s = "name.";
            if(smdl.name != null)
            {
                asciiz(smdl.name, 21);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void paramGet(param param1)
        throws encoderException
    {
        String s = null;
        try
        {
            if(param1 == null)
                throw new encoderException("missing.paramGet.");
            s = "name.";
            if(param1.name != null)
            {
                asciiz(param1.name, 32);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void messageId(messageId messageid)
        throws encoderException
    {
        String s = null;
        try
        {
            if(messageid == null)
                throw new encoderException("missing.messageId.");
            s = "id.";
            if(messageid.id != null)
            {
                asciiz(messageid.id, 9);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void viewDL(smDL smdl)
        throws encoderException
    {
        String s = null;
        try
        {
            if(smdl == null)
                throw new encoderException("missing.viewDL.");
            s = "source.";
            Address(smdl.source);
            s = "name.";
            if(smdl.name != null)
            {
                asciiz(smdl.name, 21);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void smppHeader(smppHeader smppheader)
        throws encoderException
    {
        String s = null;
        try
        {
            if(smppheader == null)
            {
                throw new encoderException("missing.smppHeader.");
            } else
            {
                s = "length.";
                int32(smppheader.length);
                s = "command.";
                int32(smppheader.command);
                s = "status.";
                int32(smppheader.status);
                s = "sequence.";
                int32(smppheader.sequence);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void Address(Address address)
        throws encoderException
    {
        String s = null;
        try
        {
            if(address == null)
                throw new encoderException("missing.Address.");
            s = "ton.";
            int8(address.ton);
            s = "npi.";
            int8(address.npi);
            s = "msisdn.";
            if(address.msisdn != null)
            {
                asciiz(address.msisdn, 21);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    smppEncoder()
    {
    }

    public void listDLResponse(listDLResponse listdlresponse)
        throws encoderException
    {
        String s = null;
        try
        {
            if(listdlresponse == null)
                throw new encoderException("missing.listDLResponse.");
            s = "names_len.";
            int8(listdlresponse.names_len);
            s = "names.";
            for(int i = 0; i < lenfix(listdlresponse.names_len); i++)
                DLName(listdlresponse.names[i]);

            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void queryAllResponse(queryAllResponse queryallresponse)
        throws encoderException
    {
        String s = null;
        try
        {
            if(queryallresponse == null)
                throw new encoderException("missing.queryAllResponse.");
            s = "ids_len.";
            int8(queryallresponse.ids_len);
            s = "ids.";
            for(int i = 0; i < lenfix(queryallresponse.ids_len); i++)
                messageId(queryallresponse.ids[i]);

            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void paramRet(param param1)
        throws encoderException
    {
        String s = null;
        try
        {
            if(param1 == null)
                throw new encoderException("missing.paramRet.");
            s = "value.";
            if(param1.value != null)
            {
                asciiz(param1.value, 101);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void bind(Binding binding)
        throws encoderException
    {
        String s = null;
        try
        {
            if(binding == null)
                throw new encoderException("missing.bind.");
            s = "sysid.";
            if(binding.sysid != null)
                asciiz(binding.sysid, 16);
            else
                int8(0);
            s = "password.";
            if(binding.password != null)
                asciiz(binding.password, 9);
            else
                int8(0);
            s = "systype.";
            if(binding.systype != null)
                asciiz(binding.systype, 13);
            else
                int8(0);
            s = "version.";
            int8(binding.version);
            s = "ton.";
            int8(binding.ton);
            s = "npi.";
            int8(binding.npi);
            s = "range.";
            if(binding.range != null)
            {
                asciiz(binding.range, 41);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void recipient(Object obj)
        throws encoderException
    {
        String s = null;
        try
        {
            if(obj == null)
                throw new encoderException("missing.recipient.");
            if(obj instanceof Address)
            {
                s = "Address.";
                int8((byte)1);
                Address((Address)obj);
                return;
            }
            if(obj instanceof DLName)
            {
                s = "DLName.";
                int8((byte)2);
                DLName((DLName)obj);
                return;
            } else
            {
                s = null;
                throw new encoderException("unknown.instance.recipient.");
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void queryDetailsResponse(Message message)
        throws encoderException
    {
        String s = null;
        try
        {
            if(message == null)
                throw new encoderException("missing.queryDetailsResponse.");
            s = "service.";
            if(message.service != null)
                asciiz(message.service, 6);
            else
                int8(0);
            s = "from.";
            Address(message.from);
            s = "recipients_len.";
            int8(message.recipients_len);
            s = "recipients.";
            for(int i = 0; i < lenfix(message.recipients_len); i++)
                recipient(message.recipients[i]);

            s = "pid.";
            int8(message.pid);
            s = "priority.";
            int8(!message.priority ? 0 : 1);
            s = "schedule.";
            UTC(message.schedule);
            s = "expiry.";
            UTC(message.expiry);
            s = "registered.";
            int8(!message.registered ? 0 : 1);
            s = "dcs.";
            int8(message.dcs);
            s = "text_len.";
            int8(message.text_len);
            s = "text.";
            for(int j = 0; j < lenfix(message.text_len); j++)
                int8(message.text[j]);

            s = "id.";
            if(message.id != null)
                asciiz(message.id, 9);
            else
                int8(0);
            s = "timeStamp.";
            UTC(message.timeStamp);
            s = "status.";
            int8(message.status);
            s = "gsmError.";
            int8(message.gsmError);
            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void getCustomerResponse(Customer customer)
        throws encoderException
    {
        String s = null;
        try
        {
            if(customer == null)
                throw new encoderException("missing.getCustomerResponse.");
            s = "id.";
            if(customer.id != null)
                asciiz(customer.id, 21);
            else
                int8(0);
            s = "name.";
            if(customer.name != null)
                asciiz(customer.name, 21);
            else
                int8(0);
            s = "streetAddress.";
            if(customer.streetAddress != null)
                asciiz(customer.streetAddress, 31);
            else
                int8(0);
            s = "smsAddress.";
            Address(customer.smsAddress);
            s = "serviceLevel.";
            int32(customer.serviceLevel);
            s = "smsAllowed.";
            int8(!customer.smsAllowed ? 0 : 1);
            s = "ocos.";
            int32(customer.ocos);
            s = "tcos.";
            int32(customer.tcos);
            s = "password.";
            if(customer.password != null)
            {
                asciiz(customer.password, 9);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void deleteDL(smDL smdl)
        throws encoderException
    {
        String s = null;
        try
        {
            if(smdl == null)
                throw new encoderException("missing.deleteDL.");
            s = "source.";
            Address(smdl.source);
            s = "name.";
            if(smdl.name != null)
            {
                asciiz(smdl.name, 21);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void listDL(Address address)
        throws encoderException
    {
        String s = null;
        try
        {
            if(address == null)
                throw new encoderException("missing.listDL.");
            s = "ton.";
            int8(address.ton);
            s = "npi.";
            int8(address.npi);
            s = "msisdn.";
            if(address.msisdn != null)
            {
                asciiz(address.msisdn, 21);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void DLName(DLName dlname)
        throws encoderException
    {
        String s = null;
        try
        {
            if(dlname == null)
                throw new encoderException("missing.DLName.");
            s = "name.";
            if(dlname.name != null)
            {
                asciiz(dlname.name, 21);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void addCustomer(Customer customer)
        throws encoderException
    {
        String s = null;
        try
        {
            if(customer == null)
                throw new encoderException("missing.addCustomer.");
            s = "id.";
            if(customer.id != null)
                asciiz(customer.id, 21);
            else
                int8(0);
            s = "name.";
            if(customer.name != null)
                asciiz(customer.name, 21);
            else
                int8(0);
            s = "streetAddress.";
            if(customer.streetAddress != null)
                asciiz(customer.streetAddress, 31);
            else
                int8(0);
            s = "smsAddress.";
            Address(customer.smsAddress);
            s = "serviceLevel.";
            int32(customer.serviceLevel);
            s = "smsAllowed.";
            int8(!customer.smsAllowed ? 0 : 1);
            s = "ocos.";
            int32(customer.ocos);
            s = "tcos.";
            int32(customer.tcos);
            s = "password.";
            if(customer.password != null)
            {
                asciiz(customer.password, 9);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void submitMulti(Message message)
        throws encoderException
    {
        String s = null;
        try
        {
            if(message == null)
                throw new encoderException("missing.submitMulti.");
            s = "service.";
            if(message.service != null)
                asciiz(message.service, 6);
            else
                int8(0);
            s = "from.";
            Address(message.from);
            s = "recipients_len.";
            int8(message.recipients_len);
            s = "recipients.";
            for(int i = 0; i < lenfix(message.recipients_len); i++)
                recipient(message.recipients[i]);

            s = "esm.";
            int8(message.esm);
            s = "pid.";
            int8(message.pid);
            s = "priority.";
            int8(!message.priority ? 0 : 1);
            s = "schedule.";
            UTC(message.schedule);
            s = "expiry.";
            UTC(message.expiry);
            s = "registered.";
            int8(!message.registered ? 0 : 1);
            s = "replacement.";
            int8(!message.replacement ? 0 : 1);
            s = "dcs.";
            int8(message.dcs);
            s = "predefined.";
            int8(message.predefined);
            s = "text_len.";
            int8(message.text_len);
            s = "text.";
            for(int j = 0; j < lenfix(message.text_len); j++)
                int8(message.text[j]);

            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void getCustomer(Customer customer)
        throws encoderException
    {
        String s = null;
        try
        {
            if(customer == null)
                throw new encoderException("missing.getCustomer.");
            s = "id.";
            if(customer.id != null)
            {
                asciiz(customer.id, 21);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void modDL(modDL moddl)
        throws encoderException
    {
        String s = null;
        try
        {
            if(moddl == null)
            {
                throw new encoderException("missing.modDL.");
            } else
            {
                s = "dl.";
                smDL(moddl.dl);
                s = "modify.";
                DLmodification(moddl.modify);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void viewDLresponse(viewDLresponse viewdlresponse)
        throws encoderException
    {
        String s = null;
        try
        {
            if(viewdlresponse == null)
                throw new encoderException("missing.viewDLresponse.");
            s = "members_len.";
            int8(viewdlresponse.members_len);
            s = "members.";
            for(int i = 0; i < lenfix(viewdlresponse.members_len); i++)
                Member(viewdlresponse.members[i]);

            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void AddressError(AddressError addresserror)
        throws encoderException
    {
        String s = null;
        try
        {
            if(addresserror == null)
            {
                throw new encoderException("missing.AddressError.");
            } else
            {
                s = "address.";
                Address(addresserror.address);
                s = "error.";
                int32(addresserror.error);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void bindResponse(Binding binding)
        throws encoderException
    {
        String s = null;
        try
        {
            if(binding == null)
                throw new encoderException("missing.bindResponse.");
            s = "smsc.";
            if(binding.smsc != null)
            {
                asciiz(binding.smsc, 16);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void queryAll(queryAll queryall)
        throws encoderException
    {
        String s = null;
        try
        {
            if(queryall == null)
            {
                throw new encoderException("missing.queryAll.");
            } else
            {
                s = "source.";
                Address(queryall.source);
                s = "count.";
                int8(queryall.count);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void deleteCustomer(Customer customer)
        throws encoderException
    {
        String s = null;
        try
        {
            if(customer == null)
                throw new encoderException("missing.deleteCustomer.");
            s = "id.";
            if(customer.id != null)
            {
                asciiz(customer.id, 21);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void queryDetails(Message message)
        throws encoderException
    {
        String s = null;
        try
        {
            if(message == null)
                throw new encoderException("missing.queryDetails.");
            s = "id.";
            if(message.id != null)
                asciiz(message.id, 9);
            else
                int8(0);
            s = "from.";
            Address(message.from);
            s = "text_len.";
            int8(message.text_len);
            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void submitMultiResponse(Message message)
        throws encoderException
    {
        String s = null;
        try
        {
            if(message == null)
                throw new encoderException("missing.submitMultiResponse.");
            s = "id.";
            if(message.id != null)
                asciiz(message.id, 9);
            else
                int8(0);
            s = "fails_len.";
            int8(message.fails_len);
            s = "fails.";
            for(int i = 0; i < lenfix(message.fails_len); i++)
                AddressError(message.fails[i]);

            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void DLmodification(Object obj)
        throws encoderException
    {
        String s = null;
        try
        {
            if(obj == null)
                throw new encoderException("missing.DLmodification.");
            if(obj instanceof Member)
            {
                s = "Member.";
                int8((byte)1);
                Member((Member)obj);
                return;
            }
            if(obj instanceof String)
            {
                s = "asciiz.";
                int8((byte)2);
                if(obj != null)
                {
                    asciiz((String)obj, 21);
                    return;
                } else
                {
                    int8(0);
                    return;
                }
            } else
            {
                s = null;
                throw new encoderException("unknown.instance.DLmodification.");
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void query(Message message)
        throws encoderException
    {
        String s = null;
        try
        {
            if(message == null)
                throw new encoderException("missing.query.");
            s = "id.";
            if(message.id != null)
                asciiz(message.id, 9);
            else
                int8(0);
            s = "from.";
            Address(message.from);
            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void submit(Message message)
        throws encoderException
    {
        String s = null;
        try
        {
            if(message == null)
                throw new encoderException("missing.submit.");
            s = "service.";
            if(message.service != null)
                asciiz(message.service, 6);
            else
                int8(0);
            s = "from.";
            Address(message.from);
            s = "to.";
            Address(message.to);
            s = "esm.";
            int8(message.esm);
            s = "pid.";
            int8(message.pid);
            s = "priority.";
            int8(!message.priority ? 0 : 1);
            s = "schedule.";
            UTC(message.schedule);
            s = "expiry.";
            UTC(message.expiry);
            s = "registered.";
            int8(!message.registered ? 0 : 1);
            s = "replacement.";
            int8(!message.replacement ? 0 : 1);
            s = "dcs.";
            int8(message.dcs);
            s = "predefined.";
            int8(message.predefined);
            s = "text_len.";
            int8(message.text_len);
            s = "text.";
            for(int i = 0; i < lenfix(message.text_len); i++)
                int8(message.text[i]);

            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void smDL(smDL smdl)
        throws encoderException
    {
        String s = null;
        try
        {
            if(smdl == null)
                throw new encoderException("missing.smDL.");
            s = "source.";
            Address(smdl.source);
            s = "name.";
            if(smdl.name != null)
            {
                asciiz(smdl.name, 21);
                return;
            } else
            {
                int8(0);
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void replace(Message message)
        throws encoderException
    {
        String s = null;
        try
        {
            if(message == null)
                throw new encoderException("missing.replace.");
            s = "id.";
            if(message.id != null)
                asciiz(message.id, 9);
            else
                int8(0);
            s = "from.";
            Address(message.from);
            s = "schedule.";
            UTC(message.schedule);
            s = "expiry.";
            UTC(message.expiry);
            s = "registered.";
            int8(!message.registered ? 0 : 1);
            s = "predefined.";
            int8(message.predefined);
            s = "text_len.";
            int8(message.text_len);
            s = "text.";
            for(int i = 0; i < lenfix(message.text_len); i++)
                int8(message.text[i]);

            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void queryResponse(Message message)
        throws encoderException
    {
        String s = null;
        try
        {
            if(message == null)
                throw new encoderException("missing.queryResponse.");
            s = "id.";
            if(message.id != null)
                asciiz(message.id, 9);
            else
                int8(0);
            s = "timeStamp.";
            UTC(message.timeStamp);
            s = "status.";
            int8(message.status);
            s = "gsmError.";
            int8(message.gsmError);
            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }

    public void Member(Member member)
        throws encoderException
    {
        String s = null;
        try
        {
            if(member == null)
                throw new encoderException("missing.Member.");
            s = "smsAddress.";
            Address(member.smsAddress);
            s = "id.";
            if(member.id != null)
                asciiz(member.id, 21);
            else
                int8(0);
            s = "type.";
            int8(member.type);
            return;
        }
        catch(encoderException encoderexception)
        {
            if(s != null)
                throw new encoderException(encoderexception + s);
            else
                throw encoderexception;
        }
    }
}
