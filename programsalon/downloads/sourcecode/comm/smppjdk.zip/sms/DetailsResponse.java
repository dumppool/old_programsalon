// FrontEnd Plus for JAD
// DeCompiled : DetailsResponse.class

package sms;


// Referenced classes of package sms:
//            Message

public interface DetailsResponse
{

    public abstract void detailsResponse(Exception exception, Message message);
}
