// FrontEnd Plus for JAD
// DeCompiled : ModCustomerResponse.class

package sms;


// Referenced classes of package sms:
//            Customer

public interface ModCustomerResponse
{

    public abstract void modResponse(Exception exception, Customer customer);
}
