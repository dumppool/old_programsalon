// FrontEnd Plus for JAD
// DeCompiled : Binding.class

package sms;


// Referenced classes of package sms:
//            Address, Receiver

public class Binding
{

    String sysid;
    String password;
    String systype;
    int version;
    int ton;
    int npi;
    String range;
    String smsc;
    Receiver target;

    public Binding(String s, String s1, String s2)
    {
        bind_init(s, s1, s2, null, null);
    }

    public Binding(String s, String s1, String s2, Address address, Receiver receiver)
    {
        bind_init(s, s1, s2, address, receiver);
    }

    public Binding(String s, String s1, String s2, Receiver receiver)
    {
        bind_init(s, s1, s2, null, receiver);
    }

    public String smscID()
    {
        return smsc;
    }

    public void setVersion(int i)
    {
        version = i;
    }

    private void bind_init(String s, String s1, String s2, Address address, Receiver receiver)
    {
        version = 0;
        sysid = s;
        systype = s1;
        password = s2;
        smsc = null;
        if(address != null)
        {
            ton = address.ton;
            npi = address.npi;
            range = address.msisdn;
        }
        target = receiver;
    }

    Binding()
    {
    }
}
