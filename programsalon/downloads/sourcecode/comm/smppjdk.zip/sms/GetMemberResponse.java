// FrontEnd Plus for JAD
// DeCompiled : GetMemberResponse.class

package sms;


// Referenced classes of package sms:
//            Address, Member

public interface GetMemberResponse
{

    public abstract void getResponse(Exception exception, Address address, String s, Member amember[]);
}
