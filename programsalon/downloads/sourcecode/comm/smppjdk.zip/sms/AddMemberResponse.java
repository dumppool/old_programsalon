// FrontEnd Plus for JAD
// DeCompiled : AddMemberResponse.class

package sms;


// Referenced classes of package sms:
//            Address, Member

public interface AddMemberResponse
{

    public abstract void addResponse(Exception exception, Address address, String s, Member member);
}
