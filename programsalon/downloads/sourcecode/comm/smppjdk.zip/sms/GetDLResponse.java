// FrontEnd Plus for JAD
// DeCompiled : GetDLResponse.class

package sms;


// Referenced classes of package sms:
//            Address

public interface GetDLResponse
{

    public abstract void getResponse(Exception exception, Address address, String as[]);
}
