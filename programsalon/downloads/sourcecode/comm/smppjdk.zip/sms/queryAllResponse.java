// FrontEnd Plus for JAD
// DeCompiled : queryAllResponse.class

package sms;


// Referenced classes of package sms:
//            messageId

class queryAllResponse
{

    int ids_len;
    messageId ids[];

    queryAllResponse()
    {
    }
}
