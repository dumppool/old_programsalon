// FrontEnd Plus for JAD
// DeCompiled : smppDecoder.class

package sms;

import utils.*;

// Referenced classes of package sms:
//            Message, smDL, messageId, smppHeader, 
//            Address, listDLResponse, DLName, modDL, 
//            queryAll, Customer, param, queryAllResponse, 
//            Binding, viewDLresponse, Member, AddressError

class smppDecoder extends decoder
{

    public Message cancel(Message message)
        throws decoderException
    {
        if(message == null)
            message = new Message();
        String s = null;
        try
        {
            s = "service.";
            message.service = asciiz(6);
            s = "id.";
            message.id = asciiz(9);
            s = "from.";
            message.from = Address();
            s = "to.";
            message.to = Address();
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return message;
    }

    public Message cancel()
        throws decoderException
    {
        return cancel(null);
    }

    public Message submitResponse(Message message)
        throws decoderException
    {
        if(message == null)
            message = new Message();
        String s = null;
        try
        {
            s = "id.";
            message.id = asciiz(9);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return message;
    }

    public smDL addDL(smDL smdl)
        throws decoderException
    {
        if(smdl == null)
            smdl = new smDL();
        String s = null;
        try
        {
            s = "source.";
            smdl.source = Address();
            s = "name.";
            smdl.name = asciiz(21);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return smdl;
    }

    public smDL addDL()
        throws decoderException
    {
        return addDL(null);
    }

    public Message submitResponse()
        throws decoderException
    {
        return submitResponse(null);
    }

    public messageId messageId(messageId messageid)
        throws decoderException
    {
        if(messageid == null)
            messageid = new messageId();
        String s = null;
        try
        {
            s = "id.";
            messageid.id = asciiz(9);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return messageid;
    }

    public messageId messageId()
        throws decoderException
    {
        return messageId(null);
    }

    public smppHeader smppHeader(smppHeader smppheader)
        throws decoderException
    {
        if(smppheader == null)
            smppheader = new smppHeader();
        String s = null;
        try
        {
            s = "length.";
            smppheader.length = super.int32();
            s = "command.";
            smppheader.command = super.int32();
            s = "status.";
            smppheader.status = super.int32();
            s = "sequence.";
            smppheader.sequence = super.int32();
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return smppheader;
    }

    public smppHeader smppHeader()
        throws decoderException
    {
        return smppHeader(null);
    }

    public Address Address(Address address)
        throws decoderException
    {
        if(address == null)
            address = new Address();
        String s = null;
        try
        {
            s = "ton.";
            address.ton = int8();
            s = "npi.";
            address.npi = int8();
            s = "msisdn.";
            address.msisdn = asciiz(21);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return address;
    }

    public Address Address()
        throws decoderException
    {
        return Address(null);
    }

    public listDLResponse listDLResponse(listDLResponse listdlresponse)
        throws decoderException
    {
        if(listdlresponse == null)
            listdlresponse = new listDLResponse();
        String s = null;
        try
        {
            s = "names_len.";
            listdlresponse.names_len = super.lenfix(int8());
            s = "names.";
            listdlresponse.names = new DLName[lenfix(listdlresponse.names_len)];
            for(int i = 0; i < lenfix(listdlresponse.names_len); i++)
                listdlresponse.names[i] = DLName();

        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return listdlresponse;
    }

    public listDLResponse listDLResponse()
        throws decoderException
    {
        return listDLResponse(null);
    }

    private Object recipient()
        throws decoderException
    {
        String s = null;
        Object obj;
        try
        {
            s = "the.recipient";
            byte byte0 = int8();
            switch(byte0)
            {
            case 1: // '\001'
                s = "recipient.Address.";
                obj = Address();
                break;

            case 2: // '\002'
                s = "recipient.DLName.";
                obj = DLName();
                break;

            default:
                s = null;
                throw new decoderException("unknown.case.recipient.");
            }
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return obj;
    }

    public Message queryDetailsResponse(Message message)
        throws decoderException
    {
        if(message == null)
            message = new Message();
        String s = null;
        try
        {
            s = "service.";
            message.service = asciiz(6);
            s = "from.";
            message.from = Address();
            s = "recipients_len.";
            message.recipients_len = super.lenfix(int8());
            s = "recipients.";
            message.recipients = new Object[lenfix(message.recipients_len)];
            for(int i = 0; i < lenfix(message.recipients_len); i++)
                message.recipients[i] = recipient();

            s = "pid.";
            message.pid = int8();
            s = "priority.";
            message.priority = int8() != 0;
            s = "schedule.";
            message.schedule = super.UTC();
            s = "expiry.";
            message.expiry = super.UTC();
            s = "registered.";
            message.registered = int8() != 0;
            s = "dcs.";
            message.dcs = int8();
            s = "text_len.";
            message.text_len = super.lenfix(int8());
            s = "text.";
            message.text = new byte[lenfix(message.text_len)];
            for(int j = 0; j < lenfix(message.text_len); j++)
                message.text[j] = super.int8();

            s = "id.";
            message.id = asciiz(9);
            s = "timeStamp.";
            message.timeStamp = super.UTC();
            s = "status.";
            message.status = int8();
            s = "gsmError.";
            message.gsmError = int8();
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return message;
    }

    public Message queryDetailsResponse()
        throws decoderException
    {
        return queryDetailsResponse(null);
    }

    public DLName DLName(DLName dlname)
        throws decoderException
    {
        if(dlname == null)
            dlname = new DLName();
        String s = null;
        try
        {
            s = "name.";
            dlname.name = asciiz(21);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return dlname;
    }

    public DLName DLName()
        throws decoderException
    {
        return DLName(null);
    }

    public Message submitMulti(Message message)
        throws decoderException
    {
        if(message == null)
            message = new Message();
        String s = null;
        try
        {
            s = "service.";
            message.service = asciiz(6);
            s = "from.";
            message.from = Address();
            s = "recipients_len.";
            message.recipients_len = super.lenfix(int8());
            s = "recipients.";
            message.recipients = new Object[lenfix(message.recipients_len)];
            for(int i = 0; i < lenfix(message.recipients_len); i++)
                message.recipients[i] = recipient();

            s = "esm.";
            message.esm = int8();
            s = "pid.";
            message.pid = int8();
            s = "priority.";
            message.priority = int8() != 0;
            s = "schedule.";
            message.schedule = super.UTC();
            s = "expiry.";
            message.expiry = super.UTC();
            s = "registered.";
            message.registered = int8() != 0;
            s = "replacement.";
            message.replacement = int8() != 0;
            s = "dcs.";
            message.dcs = int8();
            s = "predefined.";
            message.predefined = int8();
            s = "text_len.";
            message.text_len = super.lenfix(int8());
            s = "text.";
            message.text = new byte[lenfix(message.text_len)];
            for(int j = 0; j < lenfix(message.text_len); j++)
                message.text[j] = super.int8();

        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return message;
    }

    public Message submitMulti()
        throws decoderException
    {
        return submitMulti(null);
    }

    public modDL modDL(modDL moddl)
        throws decoderException
    {
        if(moddl == null)
            moddl = new modDL();
        String s = null;
        try
        {
            s = "dl.";
            moddl.dl = smDL();
            s = "modify.";
            moddl.modify = DLmodification();
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return moddl;
    }

    public modDL modDL()
        throws decoderException
    {
        return modDL(null);
    }

    public queryAll queryAll(queryAll queryall)
        throws decoderException
    {
        if(queryall == null)
            queryall = new queryAll();
        String s = null;
        try
        {
            s = "source.";
            queryall.source = Address();
            s = "count.";
            queryall.count = super.int8();
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return queryall;
    }

    public queryAll queryAll()
        throws decoderException
    {
        return queryAll(null);
    }

    private Object DLmodification()
        throws decoderException
    {
        String s = null;
        Object obj;
        try
        {
            s = "the.DLmodification";
            byte byte0 = int8();
            switch(byte0)
            {
            case 1: // '\001'
                s = "DLmodification.Member.";
                obj = Member();
                break;

            case 2: // '\002'
                s = "DLmodification.asciiz.";
                obj = asciiz(21);
                break;

            default:
                s = null;
                throw new decoderException("unknown.case.DLmodification.");
            }
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return obj;
    }

    public Message query(Message message)
        throws decoderException
    {
        if(message == null)
            message = new Message();
        String s = null;
        try
        {
            s = "id.";
            message.id = asciiz(9);
            s = "from.";
            message.from = Address();
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return message;
    }

    public Message query()
        throws decoderException
    {
        return query(null);
    }

    public Customer modifyCustomer(Customer customer)
        throws decoderException
    {
        if(customer == null)
            customer = new Customer();
        String s = null;
        try
        {
            s = "id.";
            customer.id = asciiz(21);
            s = "name.";
            customer.name = asciiz(21);
            s = "streetAddress.";
            customer.streetAddress = asciiz(31);
            s = "smsAddress.";
            customer.smsAddress = Address();
            s = "serviceLevel.";
            customer.serviceLevel = super.int32();
            s = "smsAllowed.";
            customer.smsAllowed = int8() != 0;
            s = "ocos.";
            customer.ocos = super.int32();
            s = "tcos.";
            customer.tcos = super.int32();
            s = "password.";
            customer.password = asciiz(9);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return customer;
    }

    public Customer modifyCustomer()
        throws decoderException
    {
        return modifyCustomer(null);
    }

    public param paramGet(param param1)
        throws decoderException
    {
        if(param1 == null)
            param1 = new param();
        String s = null;
        try
        {
            s = "name.";
            param1.name = asciiz(32);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return param1;
    }

    public param paramGet()
        throws decoderException
    {
        return paramGet(null);
    }

    public smDL viewDL(smDL smdl)
        throws decoderException
    {
        if(smdl == null)
            smdl = new smDL();
        String s = null;
        try
        {
            s = "source.";
            smdl.source = Address();
            s = "name.";
            smdl.name = asciiz(21);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return smdl;
    }

    public smDL viewDL()
        throws decoderException
    {
        return viewDL(null);
    }

    smppDecoder(byte abyte0[])
    {
        super(abyte0);
    }

    public queryAllResponse queryAllResponse(queryAllResponse queryallresponse)
        throws decoderException
    {
        if(queryallresponse == null)
            queryallresponse = new queryAllResponse();
        String s = null;
        try
        {
            s = "ids_len.";
            queryallresponse.ids_len = super.lenfix(int8());
            s = "ids.";
            queryallresponse.ids = new messageId[lenfix(queryallresponse.ids_len)];
            for(int i = 0; i < lenfix(queryallresponse.ids_len); i++)
                queryallresponse.ids[i] = messageId();

        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return queryallresponse;
    }

    public queryAllResponse queryAllResponse()
        throws decoderException
    {
        return queryAllResponse(null);
    }

    public param paramRet(param param1)
        throws decoderException
    {
        if(param1 == null)
            param1 = new param();
        String s = null;
        try
        {
            s = "value.";
            param1.value = asciiz(101);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return param1;
    }

    public Binding bind(Binding binding)
        throws decoderException
    {
        if(binding == null)
            binding = new Binding();
        String s = null;
        try
        {
            s = "sysid.";
            binding.sysid = asciiz(16);
            s = "password.";
            binding.password = asciiz(9);
            s = "systype.";
            binding.systype = asciiz(13);
            s = "version.";
            binding.version = int8();
            s = "ton.";
            binding.ton = int8();
            s = "npi.";
            binding.npi = int8();
            s = "range.";
            binding.range = asciiz(41);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return binding;
    }

    public Binding bind()
        throws decoderException
    {
        return bind(null);
    }

    public param paramRet()
        throws decoderException
    {
        return paramRet(null);
    }

    public Customer getCustomerResponse(Customer customer)
        throws decoderException
    {
        if(customer == null)
            customer = new Customer();
        String s = null;
        try
        {
            s = "id.";
            customer.id = asciiz(21);
            s = "name.";
            customer.name = asciiz(21);
            s = "streetAddress.";
            customer.streetAddress = asciiz(31);
            s = "smsAddress.";
            customer.smsAddress = Address();
            s = "serviceLevel.";
            customer.serviceLevel = super.int32();
            s = "smsAllowed.";
            customer.smsAllowed = int8() != 0;
            s = "ocos.";
            customer.ocos = super.int32();
            s = "tcos.";
            customer.tcos = super.int32();
            s = "password.";
            customer.password = asciiz(9);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return customer;
    }

    public Customer getCustomerResponse()
        throws decoderException
    {
        return getCustomerResponse(null);
    }

    public smDL deleteDL(smDL smdl)
        throws decoderException
    {
        if(smdl == null)
            smdl = new smDL();
        String s = null;
        try
        {
            s = "source.";
            smdl.source = Address();
            s = "name.";
            smdl.name = asciiz(21);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return smdl;
    }

    public smDL deleteDL()
        throws decoderException
    {
        return deleteDL(null);
    }

    public Address listDL(Address address)
        throws decoderException
    {
        if(address == null)
            address = new Address();
        String s = null;
        try
        {
            s = "ton.";
            address.ton = int8();
            s = "npi.";
            address.npi = int8();
            s = "msisdn.";
            address.msisdn = asciiz(21);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return address;
    }

    public Address listDL()
        throws decoderException
    {
        return listDL(null);
    }

    public Customer addCustomer(Customer customer)
        throws decoderException
    {
        if(customer == null)
            customer = new Customer();
        String s = null;
        try
        {
            s = "id.";
            customer.id = asciiz(21);
            s = "name.";
            customer.name = asciiz(21);
            s = "streetAddress.";
            customer.streetAddress = asciiz(31);
            s = "smsAddress.";
            customer.smsAddress = Address();
            s = "serviceLevel.";
            customer.serviceLevel = super.int32();
            s = "smsAllowed.";
            customer.smsAllowed = int8() != 0;
            s = "ocos.";
            customer.ocos = super.int32();
            s = "tcos.";
            customer.tcos = super.int32();
            s = "password.";
            customer.password = asciiz(9);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return customer;
    }

    public Customer addCustomer()
        throws decoderException
    {
        return addCustomer(null);
    }

    public Customer getCustomer(Customer customer)
        throws decoderException
    {
        if(customer == null)
            customer = new Customer();
        String s = null;
        try
        {
            s = "id.";
            customer.id = asciiz(21);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return customer;
    }

    public Customer getCustomer()
        throws decoderException
    {
        return getCustomer(null);
    }

    public viewDLresponse viewDLresponse(viewDLresponse viewdlresponse)
        throws decoderException
    {
        if(viewdlresponse == null)
            viewdlresponse = new viewDLresponse();
        String s = null;
        try
        {
            s = "members_len.";
            viewdlresponse.members_len = super.lenfix(int8());
            s = "members.";
            viewdlresponse.members = new Member[lenfix(viewdlresponse.members_len)];
            for(int i = 0; i < lenfix(viewdlresponse.members_len); i++)
                viewdlresponse.members[i] = Member();

        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return viewdlresponse;
    }

    public viewDLresponse viewDLresponse()
        throws decoderException
    {
        return viewDLresponse(null);
    }

    public AddressError AddressError(AddressError addresserror)
        throws decoderException
    {
        if(addresserror == null)
            addresserror = new AddressError();
        String s = null;
        try
        {
            s = "address.";
            addresserror.address = Address();
            s = "error.";
            addresserror.error = super.int32();
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return addresserror;
    }

    public Binding bindResponse(Binding binding)
        throws decoderException
    {
        if(binding == null)
            binding = new Binding();
        String s = null;
        try
        {
            s = "smsc.";
            binding.smsc = asciiz(16);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return binding;
    }

    public Binding bindResponse()
        throws decoderException
    {
        return bindResponse(null);
    }

    public AddressError AddressError()
        throws decoderException
    {
        return AddressError(null);
    }

    public Customer deleteCustomer(Customer customer)
        throws decoderException
    {
        if(customer == null)
            customer = new Customer();
        String s = null;
        try
        {
            s = "id.";
            customer.id = asciiz(21);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return customer;
    }

    public Customer deleteCustomer()
        throws decoderException
    {
        return deleteCustomer(null);
    }

    public Message queryDetails(Message message)
        throws decoderException
    {
        if(message == null)
            message = new Message();
        String s = null;
        try
        {
            s = "id.";
            message.id = asciiz(9);
            s = "from.";
            message.from = Address();
            s = "text_len.";
            message.text_len = super.lenfix(int8());
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return message;
    }

    public Message queryDetails()
        throws decoderException
    {
        return queryDetails(null);
    }

    public Message submitMultiResponse(Message message)
        throws decoderException
    {
        if(message == null)
            message = new Message();
        String s = null;
        try
        {
            s = "id.";
            message.id = asciiz(9);
            s = "fails_len.";
            message.fails_len = super.lenfix(int8());
            s = "fails.";
            message.fails = new AddressError[lenfix(message.fails_len)];
            for(int i = 0; i < lenfix(message.fails_len); i++)
                message.fails[i] = AddressError();

        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return message;
    }

    public Message submitMultiResponse()
        throws decoderException
    {
        return submitMultiResponse(null);
    }

    public Message submit(Message message)
        throws decoderException
    {
        if(message == null)
            message = new Message();
        String s = null;
        try
        {
            s = "service.";
            message.service = asciiz(6);
            s = "from.";
            message.from = Address();
            s = "to.";
            message.to = Address();
            s = "esm.";
            message.esm = int8();
            s = "pid.";
            message.pid = int8();
            s = "priority.";
            message.priority = int8() != 0;
            s = "schedule.";
            message.schedule = super.UTC();
            s = "expiry.";
            message.expiry = super.UTC();
            s = "registered.";
            message.registered = int8() != 0;
            s = "replacement.";
            message.replacement = int8() != 0;
            s = "dcs.";
            message.dcs = int8();
            s = "predefined.";
            message.predefined = int8();
            s = "text_len.";
            message.text_len = super.lenfix(int8());
            s = "text.";
            message.text = new byte[lenfix(message.text_len)];
            for(int i = 0; i < lenfix(message.text_len); i++)
                message.text[i] = super.int8();

        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return message;
    }

    public Message submit()
        throws decoderException
    {
        return submit(null);
    }

    public smDL smDL(smDL smdl)
        throws decoderException
    {
        if(smdl == null)
            smdl = new smDL();
        String s = null;
        try
        {
            s = "source.";
            smdl.source = Address();
            s = "name.";
            smdl.name = asciiz(21);
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return smdl;
    }

    public smDL smDL()
        throws decoderException
    {
        return smDL(null);
    }

    public Message replace(Message message)
        throws decoderException
    {
        if(message == null)
            message = new Message();
        String s = null;
        try
        {
            s = "id.";
            message.id = asciiz(9);
            s = "from.";
            message.from = Address();
            s = "schedule.";
            message.schedule = super.UTC();
            s = "expiry.";
            message.expiry = super.UTC();
            s = "registered.";
            message.registered = int8() != 0;
            s = "predefined.";
            message.predefined = int8();
            s = "text_len.";
            message.text_len = super.lenfix(int8());
            s = "text.";
            message.text = new byte[lenfix(message.text_len)];
            for(int i = 0; i < lenfix(message.text_len); i++)
                message.text[i] = super.int8();

        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return message;
    }

    public Message replace()
        throws decoderException
    {
        return replace(null);
    }

    public Message queryResponse(Message message)
        throws decoderException
    {
        if(message == null)
            message = new Message();
        String s = null;
        try
        {
            s = "id.";
            message.id = asciiz(9);
            s = "timeStamp.";
            message.timeStamp = super.UTC();
            s = "status.";
            message.status = int8();
            s = "gsmError.";
            message.gsmError = int8();
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return message;
    }

    public Message queryResponse()
        throws decoderException
    {
        return queryResponse(null);
    }

    public Member Member(Member member)
        throws decoderException
    {
        if(member == null)
            member = new Member();
        String s = null;
        try
        {
            s = "smsAddress.";
            member.smsAddress = Address();
            s = "id.";
            member.id = asciiz(21);
            s = "type.";
            member.type = int8();
        }
        catch(decoderException decoderexception)
        {
            if(s != null)
                throw new decoderException(decoderexception + s);
            else
                throw decoderexception;
        }
        return member;
    }

    public Member Member()
        throws decoderException
    {
        return Member(null);
    }
}
