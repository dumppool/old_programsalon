// FrontEnd Plus for JAD
// DeCompiled : BindResponse.class

package sms;


// Referenced classes of package sms:
//            Binding

public interface BindResponse
{

    public abstract void bindResponse(Exception exception, Binding binding);
}
