// FrontEnd Plus for JAD
// DeCompiled : messageId.class

package sms;


class messageId
{

    String id;

    messageId()
    {
    }
}
