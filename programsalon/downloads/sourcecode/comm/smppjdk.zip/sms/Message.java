// FrontEnd Plus for JAD
// DeCompiled : Message.class

package sms;

import java.io.PrintStream;
import java.util.Date;

// Referenced classes of package sms:
//            Address, DLName, AddressError, SMSException, 
//            Constants

public class Message
    implements Constants
{

    public String service;
    public short esm;
    Address from;
    Address to;
    public short pid;
    public boolean priority;
    public Date schedule;
    public Date expiry;
    public boolean registered;
    public boolean replacement;
    public short dcs;
    public short predefined;
    public String id;
    int text_len;
    byte text[];
    short gsmError;
    Date timeStamp;
    short status;
    int recipients_len;
    Object recipients[];
    int fails_len;
    AddressError fails[];

    public AddressError[] getFailedRecipients()
    {
        if(fails != null && fails_len != 0)
            return fails;
        else
            return null;
    }

    public boolean receipt()
    {
        return (esm & 0x1) != 0;
    }

    public Message()
    {
        setFrom(null);
        setTo(null);
    }

    public Message(Address address, String s)
    {
        setFrom(null);
        setTo(address);
        setText(s);
    }

    public Message(String s)
    {
        setFrom(null);
        setTo(null);
        id = s;
    }

    public Message(String s, String s1)
    {
        setFrom(null);
        setTo(s);
        setText(s1);
    }

    public Message(Address address, byte abyte0[])
    {
        setFrom(null);
        setTo(address);
        setBytes(abyte0);
    }

    public Message(String s, byte abyte0[])
    {
        setFrom(null);
        setTo(s);
        setBytes(abyte0);
    }

    public void setFrom(Address address)
    {
        from = address;
        if(from == null)
            from = new Address("", 0, 0);
    }

    public Address getFrom()
    {
        if(from != null && from.msisdn.length() != 0)
            return from;
        else
            return null;
    }

    public Object[] getCC()
    {
        Object aobj[];
        if(to != null && to.msisdn.length() != 0)
        {
            aobj = new Object[1];
            aobj[0] = (Object)to;
        } else
        {
            aobj = new Object[recipients_len];
            for(int i = 0; i < recipients_len; i++)
                if(aobj[i] instanceof DLName)
                    aobj[i] = ((DLName)recipients[i]).name;
                else
                    aobj[i] = recipients[i];

        }
        return aobj;
    }

    public void setBytes(byte abyte0[])
    {
        if(abyte0 == null)
        {
            text_len = 0;
            abyte0 = null;
        }
        text_len = abyte0.length;
        if(text_len > 255)
            text_len = 255;
        text = abyte0;
    }

    public byte[] getBytes()
    {
        return text;
    }

    public String getID()
    {
        return id;
    }

    public String setID()
    {
        return id;
    }

    public Date getTimeStamp()
    {
        return timeStamp;
    }

    private void addReceipient(Object obj)
    {
        if(recipients == null || recipients_len == 0)
        {
            recipients = new Object[10];
            recipients_len = 0;
            if(to != null && to.msisdn.length() != 0)
            {
                recipients[0] = (Object)to;
                recipients_len++;
                to = new Address("", 0, 0);
            }
        }
        if(recipients_len == recipients.length)
        {
            Object aobj[] = new Object[recipients_len + 10];
            int i;
            for(i = 0; i < recipients_len; i++)
                aobj[i] = recipients[i];

            recipients[i] = ((Object) (aobj));
        }
        recipients[recipients_len] = obj;
        recipients_len++;
    }

    public void CC(Address address)
    {
        for(int i = 0; i < recipients_len; i++)
            if((recipients[i] instanceof Address) && ((Address)recipients[i]).equals(address))
                return;

        addReceipient((Object)address);
    }

    public void CC(String s)
    {
        for(int i = 0; recipients != null && i < recipients_len; i++)
            if((recipients[i] instanceof DLName) && ((DLName)recipients[i]).name.equals(s))
                return;

        DLName dlname = new DLName();
        dlname.name = s;
        addReceipient((Object)dlname);
    }

    public void setText(String s)
    {
        if(s == null)
        {
            text_len = 0;
            text = null;
        }
        text_len = s.length();
        if(text_len > 255)
            text_len = 255;
        text = new byte[text_len];
        for(int i = 0; i < text_len; i++)
            text[i] = (byte)s.charAt(i);

    }

    public String getText()
    {
        return new String(text, 0);
    }

    public short getStatus()
    {
        return status;
    }

    public Object getTo()
    {
        if(to != null)
            return to;
        if(recipients != null && recipients.length > 0)
            return recipients[0];
        else
            return null;
    }

    public void setTo(Address address)
    {
        to = address;
        if(to == null)
            to = new Address("", 0, 0);
        recipients = null;
        recipients_len = 0;
    }

    public void setTo(String s)
    {
        to = new Address("", 0, 0);
        recipients = null;
        recipients_len = 0;
        DLName dlname = new DLName();
        dlname.name = s;
        addReceipient(dlname);
    }

    public short getGSMerror()
    {
        return gsmError;
    }

    public String toString()
    {
        String s = "To: ";
        System.out.println("  message toString recipients");
        if(recipients != null)
        {
            for(int i = 0; i < recipients_len; i++)
                if(recipients[i] instanceof DLName)
                    s += "\n  " + ((DLName)recipients[i]).name;
                else
                    s += "\n  " + recipients[i];

            s += "\n  Total " + recipients_len;
        } else
        {
            s += to;
        }
        System.out.println("  message toString recipients done");
        if(from.msisdn.length() != 0)
            s += "\nFrom: " + from;
        else
            s += "\nFrom: null";
        if(service != null)
            s += "\nSERVICE: " + service;
        s += "\nReceipt: " + (esm != 0) + "  Registered: " + registered + "  Replacement: " + replacement + "  Priority: " + priority + "\nPID: " + pid + "  DCS: " + dcs + "  Predefined: " + predefined;
        if(schedule != null)
            s += "\nSchedule:   " + schedule;
        if(expiry != null)
            s += "\nExpiry:     " + expiry;
        s += "\nText Length:" + text_len;
        System.out.println("message toString text len" + text_len);
        System.out.println("message toString text");
        if(text_len != 0 && text != null)
            if(dcs == 0)
                s += "\nText:       " + new String(text, 0, 0, text_len >= 0 ? text_len : text_len + 255);
            else
                s += "\nText:       (non-ascii)";
        System.out.println("  message toString text done");
        s += "\n" + "gsmError: " + gsmError + "  Status: " + status;
        if(timeStamp != null)
            s += "\nTime stamp" + timeStamp;
        s += "\nID: " + id;
        System.out.println("  message toString fails");
        if(fails != null && fails_len != 0)
        {
            s += "\nFailed Addresses:" + fails_len;
            for(int j = 0; j < fails_len; j++)
                s += "\n  address: " + fails[j].address + "   error: " + (new SMSException(fails[j].error)).toString();

        }
        System.out.println("  message toString fails done");
        s += "\n";
        return s;
    }
}
