// FrontEnd Plus for JAD
// DeCompiled : DelMemberResponse.class

package sms;


// Referenced classes of package sms:
//            Address, Member

public interface DelMemberResponse
{

    public abstract void delResponse(Exception exception, Address address, String s, Member member);
}
