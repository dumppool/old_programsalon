// FrontEnd Plus for JAD
// DeCompiled : smppHeader.class

package sms;


class smppHeader
{

    int length;
    int command;
    int status;
    int sequence;

    smppHeader()
    {
    }
}
