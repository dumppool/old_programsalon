// FrontEnd Plus for JAD
// DeCompiled : Receiver.class

package sms;


// Referenced classes of package sms:
//            Message

public interface Receiver
{

    public abstract boolean receive(Exception exception, Message message);
}
