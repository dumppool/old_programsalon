// FrontEnd Plus for JAD
// DeCompiled : ParameterResponse.class

package sms;


public interface ParameterResponse
{

    public abstract void parameterResponse(Exception exception, String s, String s1);
}
