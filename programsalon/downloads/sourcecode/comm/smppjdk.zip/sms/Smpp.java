// FrontEnd Plus for JAD
// DeCompiled : Smpp.class

package sms;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import utils.*;

// Referenced classes of package sms:
//            SMSException, smppEncoder, smppRequest, smDL, 
//            smDLModification, queryAll, smppDispatcher, param, 
//            smppHeader, Message, Binding, smppSyncResponse, 
//            smppCommands, Errors, Receiver, AddCustomerResponse, 
//            Customer, AddDLResponse, Address, AddMemberResponse, 
//            Member, CancelResponse, ListResponse, ParameterResponse, 
//            ModCustomerResponse, GetCustomerResponse, SendResponse, BindResponse, 
//            GetDLResponse, GetMemberResponse, DetailsResponse, ReplaceResponse, 
//            StatusResponse, DelCustomerResponse, DelDLResponse, DelMemberResponse

public class Smpp extends semaphore
    implements smppCommands, Errors
{

    public static boolean encryption;
    private String cr;
    Receiver receiverTarget;
    private boolean debugon;
    private int lastSequenceNumber;
    private OutputStream out;
    Socket socket;
    fifo pendingRequests;
    table pendingResponses;
    private static String smscHost;
    private static int smscPort;
    private int bindtype;
    smppDispatcher dispatcher;
    boolean disconnected;
    int disconnectedError;

    public void add(AddCustomerResponse addcustomerresponse, Customer customer)
        throws SMSException, IOException
    {
        if(customer == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            smppencoder.addCustomer(customer);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(17, customer, addcustomerresponse), smppencoder);
    }

    public void add(Customer customer)
        throws SMSException, IOException
    {
        add(null, customer);
        getSyncResponse();
    }

    public void add(AddDLResponse adddlresponse, Address address, String s)
        throws SMSException, IOException
    {
        if(address == null || s == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        smDL smdl = new smDL();
        smdl.source = address;
        smdl.name = s;
        try
        {
            smppencoder.addDL(smdl);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(22, smdl, adddlresponse), smppencoder);
    }

    public void add(Address address, String s)
        throws SMSException, IOException
    {
        add(null, address, s);
        getSyncResponse();
    }

    public void add(AddMemberResponse addmemberresponse, Address address, String s, Member member)
        throws SMSException, IOException
    {
        if(address == null || s == null || member == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        smDLModification smdlmodification = new smDLModification(address, s, member, false);
        try
        {
            smppencoder.modDL(smdlmodification);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(23, smdlmodification, addmemberresponse), smppencoder);
    }

    public void add(Address address, String s, Member member)
        throws SMSException, IOException
    {
        add(null, address, s, member);
        getSyncResponse();
    }

    private void log(String s)
    {
        if(debugon)
            System.out.println("" + Thread.currentThread() + "  SENDER " + s);
    }

    public void cancel(CancelResponse cancelresponse, Message message)
        throws SMSException, IOException
    {
        if(message == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            smppencoder.cancel(message);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(8, message, cancelresponse), smppencoder);
    }

    public void cancel(Message message)
        throws IOException, SMSException
    {
        cancel(null, message);
        getSyncResponse();
    }

    public Smpp(String s, int i)
        throws UnknownHostException, IOException, socksException
    {
        super("SMPP");
        cr = "$Id: SMS JDK (tm) Version 2.0.1 Copyright (C) 1998 Noctor Consulting Limited. $";
        smppInit(s, i);
    }

    public Smpp()
        throws UnknownHostException, IOException, socksException, SMSException
    {
        super("SMPP");
        cr = "$Id: SMS JDK (tm) Version 2.0.1 Copyright (C) 1998 Noctor Consulting Limited. $";
        if(smscHost == null || smscPort == 0)
        {
            throw new SMSException(10001);
        } else
        {
            smppInit(smscHost, smscPort);
            return;
        }
    }

    public void list(ListResponse listresponse, Address address, int i)
        throws SMSException, IOException
    {
        if(i <= 0)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        queryAll queryall = new queryAll();
        queryall.source = address;
        queryall.count = (byte)i;
        try
        {
            smppencoder.queryAll(queryall);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(35, address, listresponse), smppencoder);
    }

    private void putRequest(smppRequest smpprequest, smppEncoder smppencoder)
        throws SMSException, IOException
    {
        if(debugon)
            log("Sending packet... " + Thread.currentThread());
        if(smppencoder == null)
        {
            sendPacket(smpprequest, null);
        } else
        {
            if(debugon)
                log("INCLUDED BODY: " + smppencoder);
            sendPacket(smpprequest, smppencoder.getBytes());
        }
        if(debugon)
            log("sent packet");
        if(smpprequest.thread != null)
        {
            if(smpprequest.thread.equals(dispatcher.dispatcherThread))
            {
                if(debugon)
                    log("Sending from dispatcher thread");
                try
                {
                    dispatcher.smppDispatch(smpprequest.sequenceNumber);
                    return;
                }
                catch(decoderException decoderexception)
                {
                    throw new IOException("protocol error:" + decoderexception);
                }
                catch(encoderException encoderexception)
                {
                    throw new SMSException(encoderexception);
                }
            }
            if(debugon)
                log("Suspending until response is received");
            Thread thread = Thread.currentThread();
            try
            {
                while(pendingResponses.get(thread) == null) 
                    Thread.yield();
            }
            catch(InterruptedException _ex) { }
            if(debugon)
                log("Suspend over");
        }
    }

    public String[] list(Address address, int i)
        throws SMSException, IOException
    {
        list(null, address, i);
        String as[] = (String[])getSyncResponse();
        return as;
    }

    public void parameter(ParameterResponse parameterresponse, String s)
        throws SMSException, IOException
    {
        if(s == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        param param1 = new param();
        param1.name = s;
        try
        {
            smppencoder.paramGet(param1);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(34, param1, parameterresponse), smppencoder);
    }

    public String parameter(String s)
        throws SMSException, IOException
    {
        parameter(null, s);
        return (String)getSyncResponse();
    }

    public void mod(ModCustomerResponse modcustomerresponse, Customer customer)
        throws SMSException, IOException
    {
        if(customer == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            smppencoder.modifyCustomer(customer);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(19, customer, modcustomerresponse), smppencoder);
    }

    public void mod(Customer customer)
        throws SMSException, IOException
    {
        mod(null, customer);
        getSyncResponse();
    }

    public void checkLink()
        throws SMSException, IOException
    {
        putRequest(new smppRequest(21, null, null), null);
        getSyncResponse();
    }

    private synchronized void sendPacket(smppRequest smpprequest, byte abyte0[])
        throws SMSException, IOException
    {
        try
        {
            if(debugon)
                log(" *** USE");
            use();
            if(debugon)
                log(" *** USING");
            if(disconnected)
                throw new SMSException(disconnectedError);
            if(bindtype == 0)
                throw new SMSException(10002);
            if(smpprequest.command == 6)
            {
                bindtype = 0;
                disconnected = true;
                disconnectedError = 10009;
            }
            if(smpprequest.target == null)
                smpprequest.thread = Thread.currentThread();
            if(bindtype == 1 && smpprequest.command != 1 && smpprequest.command != 6 && smpprequest.command != 21)
                throw new SMSException(10003);
            smppHeader smppheader = new smppHeader();
            if((smpprequest.command & 0x80000000) == 0)
            {
                lastSequenceNumber++;
                smppheader.sequence = lastSequenceNumber;
            }
            smppheader.command = smpprequest.command;
            smppheader.status = 0;
            if(abyte0 == null)
                smppheader.length = 16;
            else
                smppheader.length = 16 + abyte0.length;
            smpprequest.sequenceNumber = smppheader.sequence;
            if((smpprequest.command & 0x80000000) == 0)
                pendingRequests.push(smpprequest);
            smppEncoder smppencoder = new smppEncoder();
            try
            {
                smppencoder.smppHeader(smppheader);
            }
            catch(encoderException encoderexception)
            {
                throw new SMSException(encoderexception);
            }
            if(debugon)
                log("HEADER: " + smppencoder);
            byte abyte1[] = smppencoder.getBytes();
            byte abyte2[];
            if(abyte0 != null)
                abyte2 = new byte[abyte1.length + abyte0.length];
            else
                abyte2 = new byte[abyte1.length];
            for(int i = 0; i < abyte1.length; i++)
                abyte2[i] = abyte1[i];

            if(abyte0 != null)
            {
                for(int j = 0; j < abyte0.length; j++)
                    abyte2[j + abyte1.length] = abyte0[j];

            }
            out.write(abyte2);
        }
        catch(IOException _ex)
        {
            bindtype = 0;
            disconnected = true;
            disconnectedError = 10010;
            throw new IOException("SMSC Connection closed (remotely)");
        }
        catch(InterruptedException _ex)
        {
            throw new SMSException(10011);
        }
        finally
        {
            if(debugon)
                log("*** FINISH");
            finished();
            if(debugon)
                log("*** FINISHED");
        }
    }

    public void get(GetCustomerResponse getcustomerresponse, Customer customer)
        throws SMSException, IOException
    {
        if(customer == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            smppencoder.getCustomer(customer);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(20, customer, getcustomerresponse), smppencoder);
    }

    public void send(SendResponse sendresponse, Message message)
        throws SMSException, IOException
    {
        if(message == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            if(message.recipients != null)
            {
                smppencoder.submitMulti(message);
                putRequest(new smppRequest(33, message, sendresponse), smppencoder);
                return;
            }
            if(debugon)
                log("encoding");
            smppencoder.submit(message);
            if(debugon)
                log("new request");
            smppRequest smpprequest = new smppRequest(4, message, sendresponse);
            if(debugon)
                log("put request");
            putRequest(smpprequest, smppencoder);
            if(debugon)
            {
                log("put request done");
                return;
            }
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
    }

    public void send(Message message)
        throws SMSException, IOException
    {
        send(null, message);
        getSyncResponse();
    }

    private void smppInit(String s, int i)
        throws UnknownHostException, IOException, socksException
    {
        log("SMPPINIT: creating socket host=" + s + ", port=" + i);
        socket = socks.Socket(s, i);
        log("SMPPINIT: creating output stream");
        out = socket.getOutputStream();
        lastSequenceNumber = 250;
        log("SMPPINIT: creating fifo and table");
        pendingRequests = new fifo();
        pendingResponses = new table();
        log("SMPPINIT: creating dispatcher");
        dispatcher = new smppDispatcher(this);
        log("SMPPINIT: returning");
        receiverTarget = null;
    }

    void write(byte abyte0[], byte abyte1[])
        throws SMSException, IOException
    {
        try
        {
            if(disconnected)
                throw new SMSException(disconnectedError);
            if(debugon)
                log(" *** USE");
            use();
            if(debugon)
                log(" *** USING");
            out.write(abyte0);
            if(abyte1 != null)
                out.write(abyte1);
        }
        catch(IOException _ex)
        {
            bindtype = 0;
            disconnected = true;
            disconnectedError = 10010;
            throw new IOException("SMSC Connection closed (remotely)");
        }
        catch(InterruptedException _ex)
        {
            throw new SMSException(10011);
        }
        finally
        {
            if(debugon)
                log("*** FINISH");
            finished();
            if(debugon)
                log("*** FINISHED");
        }
    }

    public void bind(BindResponse bindresponse, Binding binding)
        throws SMSException, IOException
    {
        if(binding == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            smppencoder.bind(binding);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        int i;
        if(binding.target != null)
        {
            i = 1;
            receiverTarget = binding.target;
        } else
        {
            i = 2;
        }
        bindtype = i;
        if(debugon)
            log("binding");
        putRequest(new smppRequest(i, binding, bindresponse), smppencoder);
    }

    public void bind(Binding binding)
        throws SMSException, IOException
    {
        if(debugon)
            log("Bind called");
        bind(null, binding);
        if(debugon)
            log("bind: get sync response");
        getSyncResponse();
    }

    public void get(Customer customer)
        throws SMSException, IOException
    {
        get(null, customer);
        getSyncResponse();
    }

    public void get(GetDLResponse getdlresponse, Address address)
        throws SMSException, IOException
    {
        if(address == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            smppencoder.listDL(address);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(32, address, getdlresponse), smppencoder);
    }

    public String[] get(Address address)
        throws SMSException, IOException
    {
        get(null, address);
        return (String[])getSyncResponse();
    }

    public void get(GetMemberResponse getmemberresponse, Address address, String s)
        throws SMSException, IOException
    {
        if(address == null || s == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        smDL smdl = new smDL();
        smdl.source = address;
        smdl.name = s;
        try
        {
            smppencoder.viewDL(smdl);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(25, smdl, getmemberresponse), smppencoder);
    }

    public Member[] get(Address address, String s)
        throws SMSException, IOException
    {
        get(null, address, s);
        return (Member[])getSyncResponse();
    }

    Object getSyncResponse()
        throws SMSException, IOException
    {
        smppSyncResponse smppsyncresponse;
        try
        {
            Thread thread = Thread.currentThread();
            smppsyncresponse = (smppSyncResponse)pendingResponses.delete(thread);
        }
        catch(InterruptedException _ex)
        {
            throw new SMSException(10011);
        }
        if(smppsyncresponse == null)
            throw new SMSException(10008);
        if(smppsyncresponse.exception != null)
        {
            if(smppsyncresponse.exception instanceof SMSException)
                throw (SMSException)smppsyncresponse.exception;
            if(smppsyncresponse.exception instanceof IOException)
                throw (IOException)smppsyncresponse.exception;
            else
                throw new SMSException(10000, smppsyncresponse.exception.toString());
        } else
        {
            return smppsyncresponse.returns;
        }
    }

    public void details(DetailsResponse detailsresponse, Message message)
        throws SMSException, IOException
    {
        if(message == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            smppencoder.queryDetails(message);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(36, message, detailsresponse), smppencoder);
    }

    public void details(Message message)
        throws SMSException, IOException
    {
        details(null, message);
        getSyncResponse();
    }

    protected void finalize()
    {
        if(debugon)
            log("Finalizing");
        close();
    }

    public void close()
    {
        Socket socket1;
        try
        {
            use();
            if(socket == null)
            {
                finished();
                return;
            }
            socket1 = socket;
            socket = null;
            finished();
        }
        catch(Exception _ex)
        {
            socket1 = socket;
            socket = null;
            finished();
        }
        try
        {
            if(debugon)
                log("sending unbind");
            if(out != null && !disconnected)
                putRequest(new smppRequest(6, null, null), null);
        }
        catch(Exception exception)
        {
            if(debugon)
                log("sending unbind failed" + exception);
        }
        try
        {
            if(out != null)
            {
                out.close();
                out = null;
            }
        }
        catch(Exception _ex)
        {
            if(debugon)
                log("Closing socket's output stream failed");
        }
        if(!Thread.currentThread().equals(dispatcher.dispatcherThread))
        {
            if(debugon)
                log("WAITING FOR READER TO FINISH");
            try
            {
                dispatcher.dispatcherThread.join();
            }
            catch(Exception exception1)
            {
                if(debugon)
                    log("Cant wait for dispatcher thread " + exception1);
            }
        }
        if(debugon)
            log("READER FINISHED");
        try
        {
            if(socket1 != null)
            {
                socket1.close();
                socket1 = null;
                return;
            }
        }
        catch(Exception _ex)
        {
            if(debugon)
                log("Closing socket failed");
            Object obj = null;
        }
    }

    public void receive(Receiver receiver)
        throws SMSException
    {
        if(bindtype != 1)
        {
            throw new SMSException(10012);
        } else
        {
            receiverTarget = receiver;
            return;
        }
    }

    public void replace(ReplaceResponse replaceresponse, Message message)
        throws SMSException, IOException
    {
        if(message == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            smppencoder.replace(message);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(7, message, replaceresponse), smppencoder);
    }

    public void replace(Message message)
        throws SMSException, IOException
    {
        replace(null, message);
        getSyncResponse();
    }

    public void status(StatusResponse statusresponse, Message message)
        throws SMSException, IOException
    {
        if(message == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            smppencoder.query(message);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(3, message, statusresponse), smppencoder);
    }

    public void status(Message message)
        throws SMSException, IOException
    {
        status(null, message);
        getSyncResponse();
    }

    public void debug(boolean flag)
    {
        debugon = flag;
    }

    public void del(DelCustomerResponse delcustomerresponse, Customer customer)
        throws SMSException, IOException
    {
        if(customer == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        try
        {
            smppencoder.deleteCustomer(customer);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(18, customer, delcustomerresponse), smppencoder);
    }

    public void del(Customer customer)
        throws SMSException, IOException
    {
        del(null, customer);
        getSyncResponse();
    }

    public void del(DelDLResponse deldlresponse, Address address, String s)
        throws SMSException, IOException
    {
        if(address == null || s == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        smDL smdl = new smDL();
        smdl.source = address;
        smdl.name = s;
        try
        {
            smppencoder.deleteDL(smdl);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(24, smdl, deldlresponse), smppencoder);
    }

    public void del(Address address, String s)
        throws SMSException, IOException
    {
        del(null, address, s);
        getSyncResponse();
    }

    public static void setSMSC(String s, int i)
    {
        smscHost = s;
        smscPort = i;
    }

    public void del(DelMemberResponse delmemberresponse, Address address, String s, Member member)
        throws SMSException, IOException
    {
        if(address == null || s == null || member == null)
            throw new SMSException(10014);
        smppEncoder smppencoder = new smppEncoder();
        smDLModification smdlmodification = new smDLModification(address, s, member, true);
        try
        {
            smppencoder.modDL(smdlmodification);
        }
        catch(encoderException encoderexception)
        {
            throw new SMSException(encoderexception);
        }
        putRequest(new smppRequest(23, smdlmodification, delmemberresponse), smppencoder);
    }

    public void del(Address address, String s, Member member)
        throws SMSException, IOException
    {
        del(null, address, s, member);
        getSyncResponse();
    }

    public void debug(boolean flag, boolean flag1)
    {
        if(dispatcher != null)
            dispatcher.debugon = flag;
        debugon = flag1;
    }
}
