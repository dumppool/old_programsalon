// FrontEnd Plus for JAD
// DeCompiled : ReplaceResponse.class

package sms;


// Referenced classes of package sms:
//            Message

public interface ReplaceResponse
{

    public abstract void replaceResponse(Exception exception, Message message);
}
