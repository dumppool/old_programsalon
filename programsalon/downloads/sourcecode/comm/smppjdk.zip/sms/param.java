// FrontEnd Plus for JAD
// DeCompiled : param.class

package sms;


class param
{

    String name;
    String value;

    param()
    {
    }
}
