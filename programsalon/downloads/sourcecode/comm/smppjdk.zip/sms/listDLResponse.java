// FrontEnd Plus for JAD
// DeCompiled : listDLResponse.class

package sms;


// Referenced classes of package sms:
//            DLName

class listDLResponse
{

    int names_len;
    DLName names[];

    listDLResponse()
    {
    }
}
