echo -n "+++" >/dev/cua1
sleep 2
cat $TOTO/part3-hang >/dev/cua1

