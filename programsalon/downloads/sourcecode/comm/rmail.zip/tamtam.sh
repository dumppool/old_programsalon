export TOTO=~/internet/tam
echo -n `echo q | (mail 2>/dev/null) | grep -E -e "^.N.+"` >>$TOTO/toto
if (test -s $TOTO/toto) then
cu -l /dev/cua1 -e </dev/tty8 >/dev/tty8 2>$TOTO/burp &
sleep 20
if (test \! -s $TOTO/burp) then
cat $TOTO/part1-dial >/dev/cua1
sleep 30
cat $TOTO/part2-shdr $TOTO/toto $TOTO/part2-sfot >/dev/cua1
rm $TOTO/toto
sleep 90
$TOTO/hangup.sh
sleep 10
killall cu
fi
fi
