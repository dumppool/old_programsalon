/*
 * A few shared definitions for the files
 */

/*
 * A lot of the includes don't work as the manual page suggests
 * hence we do this on NeXT systems
 */
#ifdef NeXT
#include <libc.h>
#endif

extern int do_call(char*);
extern int call_tcp(char*);
extern int command(char*);
extern void attach_pty(int);
extern void do_iac(unsigned char[3]);
extern void outstr(char*);
extern void telnet_byte(unsigned char);
extern void stats_init(void);
extern void stats_end(void);
extern void add_pkt(int dirn, long size);
extern void stats_call(char*);
