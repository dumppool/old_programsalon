/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/


#include <stdio.h>
#include <varargs.h>
#include "vfax.h"

extern int local,debug;
FILE *logfile;


int
atoi(s)
     char s[];
{
  int i, n, sign;

  for(i=0;s[i]==' ' || s[i]=='\n' || s[i]=='\t';i++);
  sign = 1;

  if(s[i] == '+' || s[i]=='-')
    sign = (s[i++]=='+')?1:-1;
  for(n=0;s[i]>='0' && s[i]<='9';i++)
    n=10*n+s[i]-'0';
  return(sign*n);

}


int
Debug(lvl,va_alist)
     int lvl;
     va_dcl
{
  char *fmt;
  va_list al;
  static FILE *dbg;


  if(lvl > debug)
    return;

  va_start(al);
  fmt = va_arg(al,char *);

  if(dbg == (FILE *)NULL)
    {
      if((dbg = fopen("/usr/spool/voice/DEBUG","a+")) == (FILE *)NULL)
	{
	  perror("Open debugfile");
	  exit(99);
	}
      else
	{
	  setvbuf(dbg,(char *)NULL,_IONBF,0);
	}
    }
  
  vfprintf(dbg,fmt,al);
  va_end(al);
  return;
}

FILE *
open_log()
{
  FILE *lf;
  char path[512];

    
  sprintf(path,"%s/%s",FAX_LIB,FAX_LOGFILE);
  if((lf = fopen(path,"a+")) == (FILE *)NULL)
    {
      perror("open logfile");
      return (FILE *)NULL;
    }
  setvbuf(lf,(char *)NULL,_IONBF,0);
  return lf;
}

int
close_log()
{
  if(logfile == (FILE *)NULL)
    return 0;
  else
    {
      fclose(logfile);
      return 0;
    }
}

  
int
logto(lvl,va_alist)
     int lvl;
     va_dcl
{
  va_list ap;
  char *format;
  char buf[1024];

  if(lvl > debug)
    return;

  va_start(ap);
  format = va_arg(ap, char *);
  vsprintf(buf, format, ap);
  va_end(ap);

  if(logfile == (FILE *)NULL)
    {
      if((logfile = open_log())==(FILE *)NULL)
	return -1;
    }
  else
    {
      fprintf(logfile,"%s\n",buf);
      return 0;
    }
}

