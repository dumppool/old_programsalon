/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/

#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>

#include "vfax.h"

extern int fdc,fdd;

int
queuefile(qt, qfname)
     Queue *qt;
     char *qfname;
{
  FILE *qf;
  char tmp[512];
  char template[20], *tp;
  extern char *mktemp();

  strcpy(template,"OUTXXXXXX");
  if((tp = mktemp(template)) == (char *)0)
    {
      printf("can't create tmpname %s !\n",tmp);
      exit(1);
    }
  sprintf(qfname,"%s/%s",FAX_SPOOL_OUT,tp);
  strcpy(tmp,qfname);
  strcat(tmp,".qf");
  if((qf = fopen(tmp,"w+")) == (FILE *)NULL)
    {
      printf("can't open queuefile %s !\n",tmp);
      exit(1);
    }

  strncpy(qt->g3file,qfname,Q_PATH_LEN);
  strcat(qt->g3file,".g3");

  fprintf(qf,"USER: %s\n",qt->user);
  fprintf(qf,"PHONENUMBER: %s\n",qt->phone);
  fprintf(qf,"G3FILE: %s\n",qt->g3file);
  fprintf(qf,"RETRIES: %d\n",qt->retries);
  fprintf(qf,"MAXRETRIES: %d\n",qt->maxtries);
  fprintf(qf,"MAIL: %d\n",qt->mail);
  fclose(qf);
  return(0);
}

int
set_retries(qfname,qt)
     char *qfname;
     Queue *qt;
{
  FILE *qf;

  if((qf = fopen(qfname,"r+")) == (FILE *)NULL)
    {
      logto(0,"can't open queuefile %s !\n",qfname);
      return(-1);
    }
  rewind(qf);
  fprintf(qf,"USER: %s\n",qt->user);
  fprintf(qf,"PHONENUMBER: %s\n",qt->phone);
  fprintf(qf,"G3FILE: %s\n",qt->g3file);
  fprintf(qf,"RETRIES: %d\n",qt->retries);
  fprintf(qf,"MAXRETRIES: %d\n",qt->maxtries);
  fprintf(qf,"MAIL: %d\n",qt->mail);
  fclose(qf);
  return(0);
}


int
parse_queuefile(f,qt)
     FILE *f;
     Queue *qt;
{
  rewind(f);
  if(fscanf(f,"USER: %s\n",qt->user) != 0)
    if(fscanf(f,"PHONENUMBER: %s\n",qt->phone) != 0)
      if(fscanf(f,"G3FILE: %s\n",qt->g3file) != 0)
	if(fscanf(f,"RETRIES: %d\n",&(qt->retries)) != 0)
	  if(fscanf(f,"MAXRETRIES: %d\n",&(qt->maxtries)) != 0)
	    if(fscanf(f,"MAIL: %d\n",&(qt->mail)) != 0){
	      fclose(f);
	      return 0;
	    }
  fclose(f);
  return -1;
}
