/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/

#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>

#include "vfax.h"

extern int fd;

int bc;
unsigned char obuf[1024];
FILE *faxfile;
int carrier_up;

void
faxcarrier(sig)
     int sig;
{
  reset_tty();
  logto(1,"CARRIER DOWN");
  write_obuf(faxfile,obuf,bc);
  carrier_up = FALSE;
  return;
}



int
write_obuf(f, obuf,bc)
     FILE *f;
     unsigned char *obuf;
     int bc;
{
  if(fwrite(obuf,sizeof(unsigned char),bc+1,f) != bc+1)
    {
      logto(0,"FATAL: cant write buffer");
      return(-1);
    }
  logto(5,"write_obuf: written %d bytes\n",bc+1);
  return 0;
}


int
rfax(faxno)
     int faxno;
{
  void *sigcarr;
  char tmp[20];
  char tmpfn[512];  
  Status st;
  extern char *mktemp();
  sigcarr = (void(*)())faxcarrier;

  /* init fax first */
  tty_raw_mode_out(FAX);
  if(init_fax() != 0){
    logto(0,"SPOOLER: Can't sync faxmodem\n");
    return faxno;
  }   
  reset_tty(); /* make sure bytes are received */
  st.status = 2; /* failed */

  sprintf(tmp,"IN%d.XXXXXX",faxno);
  if((mktemp(tmp)) == (char *)NULL)
    {
      logto(0,"SPOOLER: mktemp failed");
      signal(SIGHUP,SIG_IGN);
      carrier_up = TRUE;
      return faxno;
    }
  else
    {
      sprintf(tmpfn,"%s/%s",FAX_SPOOL_IN,tmp);
      strncpy(st.file,tmpfn,Q_PATH_LEN);
      if((faxfile=fopen(tmpfn,"a+")) == (FILE *)NULL)
	{
	  logto(0,"SPOOLER: can't open output file %s",tmpfn);
	  return faxno;
	}
      else
	{
	  signal(SIGHUP,sigcarr);
	  carrier_up = TRUE;
	  if(modem_answer(&st)==0) {
	    if(rec_file(&st) == 0) {
	      logto(1,"SPOOLER: got fax %s",tmp);
	      st.status = 0;
	      mastermail(&st);
	      faxno++;
	    } else {
	      if(st.size == 0)
		st.status = 2;
	      else st.status = 1; /* truncated */
	      logto(0,"SPOOLER: Error receive %s",tmp);
	      mastermail(&st);
	      goto fail;
	    }
	  } else {
	    logto(0,"SPOOLER: No remote answer, is it a FAX ?",tmp);
	    goto fail;
	  }

	  fclose(faxfile);
	  signal(SIGHUP,SIG_IGN);
	  carrier_up = TRUE;
	}
    }
  return faxno;

 fail:
  signal(SIGHUP,SIG_IGN);
  carrier_up = TRUE;
  fclose(faxfile);
/*  unlink(tmpfn);/**/
  return faxno;
}


int
rec_file(st)
     Status *st;
{
  int sbytes=0;
  unsigned char fch;
  char rcbuf[128];
  int i,ret;

  tty_block();
  while(carrier_up)
    {
      if((sbytes+=read_hang(&fch,1))< 0)
	{
	  logto(0,"rcv: read 1 failed !");
	  goto fail;
	}
      else
	{
	  if(bc < 1023)
	    {
	      obuf[bc]=fch;
	      bc++;
	    }
	  else
	    {
	      obuf[bc]=fch;
	      if(write_obuf(faxfile,obuf,bc) == 0)
		bc=0;
	      else
		goto fail;
	    }
	}
    }
  logto(5,"Got %d bytes\n",sbytes);
  st->size = sbytes;
  return get_fax_disconnect();

 fail:
  tty_unblock();
  return -1;
}

