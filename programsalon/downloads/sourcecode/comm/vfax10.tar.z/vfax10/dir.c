/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/

#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/time.h>
#include <strings.h>

#include "vfax.h"


DIR *
dir_setup()
{
  DIR *dirp;

  if (chdir(FAX_SPOOL_OUT) < 0) {
    logto(0,"can't change to spool directory: %s", FAX_SPOOL_OUT);
    return (DIR *)NULL;
  }

  if ((dirp = opendir(".")) == NULL) {
    logto(0,"can't open fax spool directory: %s", FAX_SPOOL_OUT);
    return (DIR *)NULL;
  }
  return dirp;
}


int
proc_outfile()
{
  char *ptr;
  DIR *dirp = dir_setup();
  struct dirent *dp;

  if(dirp == (DIR *)NULL)
    return -1;

  for (dp = readdir(dirp); dp != NULL; dp = readdir(dirp)) {
    if ((ptr = strrchr(dp->d_name, '.')) != NULL) {
      if (strcmp(ptr+1, "qf") == 0) {
	logto(1,"found queue file: %s", dp->d_name);
        *ptr = '\0'; /* cut extension for send_process */
        if(send_process(dp->d_name) == 0)
	  {
	    unlink(strcat(dp->d_name,".qf"));
	    closedir(dirp);
	    return (0);
	  }
      }
    }
  }
  closedir(dirp);
  return -1;
}
