#ident  "@(#)vfax  V1.0 PATCHLEVEL 0 - 01.02.1993"
