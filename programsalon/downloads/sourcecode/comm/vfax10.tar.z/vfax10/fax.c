/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/

#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>

#include "vfax.h"

extern int fd;

int
modem_dial(phone)
     char *phone;
{
  logto(1,"Dialing...%s",phone);
  fdprintf(fd,"ATDT %s\r\n",phone);
  return get_fax_connect((Status *)0);
}

int
modem_answer(st)
     Status *st;
{
  logto(1,"Answering Fax...");
  writecmd("ATA");
  return get_fax_connect(st);
}
