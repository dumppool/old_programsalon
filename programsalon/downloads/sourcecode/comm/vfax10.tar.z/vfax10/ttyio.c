/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/

/* Routines for opening the serial port tty  in various raw modes 
   routines using termio struct are in tty.c 
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <signal.h>
#include <fcntl.h>
#ifdef Linux
#include <bsd/sgtty.h>
#else
#include <sgtty.h>
#endif
#include "vfax.h"

extern void exit();
extern int local;
extern int fd;
struct sgttyb stty_mode;


int ttyread(buf,bytes)
     char *buf;
     int  bytes;
{
  int i;
  char *bp;
  unsigned char ch;

  bp = buf;

  for (i = 0; i < bytes; i++) {
    while(read(fd,&ch,1) < 1);
    *bp++ = ch;
  }
  return(i);
}

/* set the tty_modes */

int tty_raw_mode_out(mode)
int mode;
{    
  struct sgttyb stemp_mode;

  if (ioctl(fd, TIOCGETP, &stemp_mode) < 0) {
    perror("TIOCGETP: "); 
    return(-1);
  }
  stty_mode = stemp_mode;

  stemp_mode.sg_flags |= RAW & ~HUPCL;

  switch(mode){
  case VOICE:
    stemp_mode.sg_ispeed = B38400;
    stemp_mode.sg_ospeed = B38400;
    break;
  case FAX:
    stemp_mode.sg_ispeed = B19200;
    stemp_mode.sg_ospeed = B19200;
    break;
  }
  if (ioctl(fd, TIOCSETP, &stemp_mode) < 0) {
    perror("TIOCSETP: "); 
    return(-1);
  }
  /* set special reenable mode if fax */
  if(mode == FAX)
    tty_set_reenable(fd);

  return 0;
}

int restore_tty_mode()
{
  if (ioctl(fd, TIOCSETP, &stty_mode) < 0) {
    perror("TIOCSETP: "); 
    return(-1);
  }
  return 0;
}

int
open_tty(name)
     char *name;
{
  int fdd;


  if((fdd=open(name, O_RDWR|O_SYNC|O_NDELAY)) < 0)
    {
      perror("open failed");
      exit(8);
    }
  fd = fdd;
  tty_raw_mode_out(VOICE);
  return fdd;
}


int
close_tty()
{
  close(fd);
}


int
tty_unblock()
{
  int fflag;

  if(fcntl(fd,F_GETFL,&fflag) < 0)
    return -1;

  fflag |= O_NDELAY;

  if(fcntl(fd,F_SETFL,fflag) < 0)
    return -1;
  logto(9,"Unblock TTY succeded\n");
  return 0;
}

int
tty_block()
{
  int fflag;

  if(fcntl(fd,F_GETFL,&fflag) < 0)
    return -1;

  fflag &= ~O_NDELAY;

  if(fcntl(fd,F_SETFL,fflag) < 0)
    return -1;

  return 0;
}

