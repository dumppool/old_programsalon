/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/

#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <termio.h>
#include <ctype.h>
#include "vfax.h"


int
getret(expect)
     char *expect;
{
  char buf[256];
  int bytes;

  tty_unblock();

  for(;;)
    {
      bytes=fdgets(buf,sizeof(buf));
      
      if(bytes == 0) continue;

      Debug(4,"getret: got %d bytes %s expected %s\r\n",bytes,buf,expect);

      if(bytes >= strlen(expect)) /* think we got it */
	{
	  if(!strncmp(buf,expect,strlen(expect)))
	    {
	      return TRUE;
	    }
	  if(!strncmp(buf,"ERROR",5))
	    {
	      return FALSE;
	    }
	  if(!strncmp(buf,"BUSY",4))
	    {
	      return FALSE;
	    }
	  if(!strncmp(buf,"NO ANSWER",9))
	    {
	      return FALSE;
	    }
	  if(!strncmp(buf,"NO CARRIER",10))
	    {
	      return FALSE;
	    }
	  if(!strncmp(buf,"NO DIALTONE",11))
	    {
	      return FALSE;
	    }
	}
    }
  return FALSE;
}

/* ---------------------------------------------------------
   read a response with blocking read
*/
int
get_bresponse(expect)
     char *expect;
{
  char buf[256];
  int bytes;
  int ret=FALSE;

  tty_block();

  for(;;)
    {
      bytes=fdgets(buf,sizeof(buf));
      
      if(bytes == 0) continue;

      Debug(4,"blockread: got %d bytes %s expected %s\r\n",bytes,buf,expect);

      if(bytes >= strlen(expect)) /* think we got it */
	{
	  if(!strncmp(buf,expect,strlen(expect)))
	    {
	      ret = TRUE;
	      goto end;
	    }
	  if(!strncmp(buf,"ERROR",5))
	    {
	      ret = FALSE;
	      goto end;
	    }
	  if(!strncmp(buf,"BUSY",4))
	    {
	      ret = FALSE;
	      goto end;
	    }
	  if(!strncmp(buf,"NO ANSWER",9))
	    {
	      ret = FALSE;
	      goto end;
	    }
	  if(!strncmp(buf,"NO CARRIER",10))
	    {
	      ret = FALSE;
	      goto end;
	    }
	  if(!strncmp(buf,"NO DIALTONE",11))
	    {
	      ret = FALSE;
	      goto end;
	    }
	}
    }
 end:
  tty_unblock();
  return ret;
}



int
get_fax_connect(st)
     Status *st;
{
  char buf[256];
  int bytes;

  for(;;)
    {
      bytes=fdgets(buf,sizeof(buf));
      
      logto(4,"get fax con: got %d bytes %*s \n",bytes,bytes,buf);
      if(bytes >= 4) /* think we got it */
	{
	  if(!strncmp(buf,"CONNECT FAX",11)){
	    if(st != (Status *)0) { /* parse phonenumber */
	      sscanf(buf,"CONNECT FAX/S%*dV%dT%*dR%*dL%*dC%*dP[+ 0-9]",
		     &(st->resolution),
		     st->phone);
	    }
	    return 0;
	  }
	  if(!strncmp(buf,"BUSY",4))
	    return -1;
	  if(!strncmp(buf,"NO ANSWER",9))
	    return -1;
	  if(!strncmp(buf,"NO CARRIER",10))
	    return -1;
	  if(!strncmp(buf,"NO DIALTONE",11))
	    return -1;
	}
    }
}


int
get_fax_disconnect()
{
  char buf[256];
  int bytes;

  for(;;)
    {
      bytes=fdgets(buf,256);
      
      logto(4,"fax_disconn: got %d |%*s|\n",bytes,bytes,buf);
      if(bytes >2) /* think we got it */
	{
	  if(!strncmp(buf,"DISCONNECT",10))
	    {
	      if(strncmp(&buf[10],"0",1))
		return -1;
	      return 0;
	    }
	  if(!strncmp(buf,"NO ANSWER",9))
	    goto bad;
	  if(!strncmp(buf,"NO CARRIER",10))
	    goto bad;
	}
    }
 bad:
  return -1;
}

