/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/

#include <stdio.h>
#include <fcntl.h>
#include <termio.h>
#include <signal.h>
#include "vfax.h"

extern int bc;
extern FILE *f;
extern unsigned char obuf[1024];
extern int carrier_up;
extern int local;

int
recmsg(fn,msgno,faxno)
     char *fn;
     int msgno,faxno;
{
  int x, y;
  FILE *out;
  char fnam[512], path[512];
  unsigned char buf;
  void *sigcarr;
  int rmode, retcode;
  char k;
  extern void carrier_loss();

  sigcarr = (void(*)())carrier_loss;

  Debug(2,"Open spoolfile %s\r\n",fn);
  if((out = fopen(fn,"w+")) == (FILE *)NULL)
    {
      Debug(0,"Open spoolfile %s failed\r\n",fn);
      return -1;
    }

  tty_raw_mode_out(VOICE);
  rmode = record(out,DTMF_ALL);

  switch(rmode)
    {
    case QUIET:
      fclose(out);
      unlink(fn);
      retcode = ADMIN;
      break;
    case PLAYBACK:
      /* transmitt detec signal */
      Debug(1,"Playback mode %d messages\r\n",msgno);
      writecmd("AT+VTS=[933,0,10]");
      getret("OK");
      tty_raw_mode_out(VOICE);
      for(y=0;y<msgno;y++)
	{
	  sprintf(fnam,"%s/in%d",VSPOOLDIR,y);
	  Debug(1,"playing msg no %s\r\n",fnam);
	  play(fnam);
	}
      /* transmitt end of message signal */
      writecmd("AT+VTS=[933,0,5]");
      getret("OK");
      retcode = ADMIN;
      break;
    case RFAX:
      Debug(1,"Fax mode; Fax number %d \n",faxno);
      if(rfax(faxno) > faxno)
	retcode = FAX;
      else
	retcode = ADMIN;
      init_voice();
      break;
    case RESTORE_DEFAULT:
      Debug(1,"Restoring default message\r\n");
      writecmd("AT+VTS=[933,0,5]");
      getret("OK");
      sprintf(fnam,"%s/greetmsg.v",MSGDIR);
      sprintf(path,"%s/greet.default",MSGDIR);
      Debug(2,"linking %s to %s\r\n",path,fnam);
      unlink(fnam);
      link(path,fnam);
      retcode = ADMIN;
      break;
    case NEW_GREETING:
      Debug(1,"Record new greeting message\r\n");
      writecmd("AT+VTS=[933,0,5]");
      getret("OK");
      sprintf(fnam,"%s/recnew.v",MSGDIR);
      play(fnam);
      writecmd("AT+VTS=[1024,0,3]");
      getret("OK");
      sprintf(fnam,"%s/greetmsg.v",MSGDIR);
      unlink(fnam);
      if((out = fopen(fnam,"w+")) == (FILE *)NULL)
	{
	  writecmd("AT+VTS=[933,0,1]");
	  getret("OK");
	  writecmd("AT+VTS=[933,0,1]");
	  getret("OK");
	  writecmd("AT+VTS=[933,0,1]");
	  getret("OK");
	}
      else
	{
	  if(record(out,"#") != RTERM) /* oops something went wrong */
	    {
	      writecmd("AT+VTS=[933,0,5]");
	      getret("OK");
	      sprintf(fnam,"%s/greetmsg.v",MSGDIR);
	      sprintf(path,"%s/greet.default",MSGDIR);
	      Debug(2,"linking %s to %s\r\n",path,fnam);
	      unlink(fnam);
	      link(path,fnam);
	    }
	  else
	    {
	      fclose(out);
	      Debug(1,"Got new greeting\r\n");
	    }
	}
      retcode = ADMIN;
      break;
    case RTERM:
    case SILENCE:
      retcode = VOICE;
      break;
    default:
      retcode = ADMIN;
    }
  return retcode;
}
