/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/


#include "version.h"

#ifdef Linux
#define FALSE 0
#define TRUE  1

#define REENABLE 0020000
#define TIOC    ('T'<<8)
#define TCRTS   (TIOC|9)

#endif

/* timeout in reading */
#define TIMEOUT 5

/* select line */
#ifdef Linux
#define PORT "/dev/modem"  /* data port with modem ctl */
#else
#define PORT "/dev/ttyFAX"  /* data port with modem ctl */
#endif

/* define local fax number */
#if 0
#define LOCAL_FAX_NO "+49 821 706892"
#else
#define LOCAL_FAX_NO "+49 241 508115"
#endif

/* mailer program */
#define MAILER "/bin/mail"

/* faxmaster adress */
#define FAXMASTER "fax"

/* please don't touch, it's for ttyio parameter settings */
#define VOICE 0  /* used in ttyio.c and recmsg.c*/
#define FAX   1
#define ADMIN 2  /* neither voice nor fax */

/* some characters */
#define DLE '\020'
#define ETX '\003'
#define XON '\021'
#define XOF '\023'

/* set up directories */
#define VOICEDIR   "/usr/local/bin"
#define MSGDIR     "/usr/spool/voice/msg"
#define VSPOOLDIR  "/usr/spool/voice/record"
#define FSPOOLDIR  "/usr/spool/fax/incoming"
#define FAX_SPOOL_OUT "/usr/spool/fax/outgoing"
#define FAX_SPOOL_IN  "/usr/spool/fax/incoming"
#define FAX_LIB "/usr/local/lib/faxlib"
#define FAX_LOGFILE "Faxlog"
#define FAX_IPC_FILE "/usr/spool/fax/IPC"

/* set up times */

#define QUEUE_INTERVAL 5
#define MODEM_INIT_TRIES 3

#define FAX_SEND_TRIES 3
#define FAX_INIT_TIMEOUT 4

/* IPC Messages , don't touch */
#define FM_EXIT     1
#define FM_RELEASE  2
#define FM_REINIT   3
#define FM_RECFAX   4
#define FM_PLAYBACK 5

/* command file modes */
#define EX_FAX 0

/* recording modes */
#define NOOP 0
#define RFAX 1
#define RESTORE_DEFAULT 2
#define NEW_GREETING 3
#define PLAYBACK 4
#define RTERM 5
#define QUIET 6
#define SILENCE 7

/* char sets for DTMF recognition */
#define DTMF_ALL "0123456789#*"

/* message buffer struct for ipc messages */
typedef struct{
  long    mtype;           /* message type */
  char    mtext[32];       /* message text */
}FIPM;


/* define lenghts for queuefile entries */
#define Q_USER_LEN 20
#define Q_PHONE_LEN 40
#define Q_PATH_LEN 70

/* queue file structure */
typedef struct {
  char user[Q_USER_LEN];   /* user from whom the fax was */
  char phone[Q_PHONE_LEN]; /* phone number */
  char g3file[Q_PATH_LEN]; /* path of file to send */
  int retries;             /* retries done till now */
  int maxtries;            /* max count of retries */
  int mail;                /* notofication by mail */
}Queue;

/* receive fax status structure */
typedef struct {
  int status;              /* receive status [0,1,2] */
  char phone[Q_PHONE_LEN]; /* phone number */
  char file[Q_PATH_LEN];   /* path of file to send */
  int resolution;          /* resolution of transmitting fax */
  int size;                /* size of received fax */
}Status;



