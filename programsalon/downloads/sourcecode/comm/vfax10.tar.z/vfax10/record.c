/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/

#include <stdio.h>
#include "vfax.h"

int
record(out,term)
     FILE *out;
     char *term;
{
  unsigned char buf;
  int done = FALSE, rmode = NOOP;

  Debug(1,"Recording file\r\n");
  fprintf(out,"ZyXEL%c%c%c%c%c%c%c%c%c%c%c",2,0,0,0,0,1,0,0,0,0,0);
  Debug(1,"Transmitt record sequence\r\n");
  writecmd("AT+VRX");
  if(getret("CONNECT"))
    {
      Debug(1,"Entering record loop\r\n");
      while(!done)
	{
	  ttyread(&buf,1);
	    
	  if(((int)buf) == DLE ) 
	    {
	      ttyread(&buf,1);
	      switch(buf)
		{
		case XOF:
		seek:
		  ttyread(&buf,1);
		  if(buf == DLE)
		    goto seek;
		  if(buf == XON)
		    continue;
		  else
		    goto seek;
		  break;
		case DLE:
		  fputc(DLE,out);
		  fputc(DLE,out);
		  break;
		case ETX: 
		  Debug(1,"got ETX\r\n");
		  done = 1;
		  break;
		case 'q':
		  Debug(1,"QUIET detected\r\n");
		  writecmd("AT");
		  rmode = QUIET;
		  break;
		case 's':
		  Debug(1,"SILENCE detected\r\n");
		  writecmd("AT");
		  rmode = SILENCE;
		  break;
		case 'c':
		case '5':
		  Debug(1,"FAX T30 code detected\r\n");
		  writecmd("AT");
		  rmode = RFAX;
		  break;
		case 'b':
		  Debug(1,"Busy detected\r\n");
		  writecmd("AT");
		  break;
		default:
		  if(strchr(term,buf) > 0)
		    switch(buf)
		      {
		      case '0':
			break;
		      case '1':
			/* kill recording process */
			Debug(1,"DTMF %c detected\n",buf);
			tcflush();
			writecmd("AT");
			rmode = PLAYBACK;
			break;
		      case '2': /* answer fax call manually */
			Debug(1,"DTMF %c detected\n",buf);
			writecmd("AT");
			rmode = RFAX;
			break;
		      case '3': /* make last msg to current greeting */
			Debug(1,"DTMF %c detected\n",buf);
			writecmd("AT");
			rmode = NEW_GREETING;
			break;
		      case '4':
			Debug(1,"DTMF %c detected\r\n",buf);
			writecmd("AT");
			rmode = RESTORE_DEFAULT;
			break;
		      case '9':
			Debug(1,"DTMF %c detected\r\n",buf);
			writecmd("AT");
			getret("VCON");
			writecmd("AT+VTS=[933,0,5]");
			getret("OK");
			writecmd("ATH");
			getret("OK");
			sleep(1);
			exit(0);
			break;
		      case '6':
			break;
		      case '7':
			break;
		      case '8':
			break;
		      case '#':
			Debug(1,"DTMF %c detected\r\n",buf);
			writecmd("AT");
			rmode = RTERM;
			break;
		      case '*':
			Debug(1,"DTMF signal %c detected",buf);
			break;
		      default:
			fputc(DLE,out);
			fputc(buf,out);
		      }
		}
	    }
	  else
	    {
	      fputc(buf,out);
	    }
	}
    }
  getret("VCON");
  fclose(out);
  return rmode;
}
