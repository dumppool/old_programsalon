#ident  "@(#)vfax  V1.0 - 01.02.1993"
