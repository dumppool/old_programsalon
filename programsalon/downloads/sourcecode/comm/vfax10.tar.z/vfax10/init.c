/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/

#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <setjmp.h>
#include <signal.h>
#include "vfax.h"

extern int local;
static jmp_buf timeoutbuf;
extern int sigALRM();
extern int fd;

init_fax()
{
  int tries;
  void (*fu)();

  fu = signal(SIGALRM,sigALRM);

  for(tries = 0; tries < MODEM_INIT_TRIES; tries ++)
    {
      if(setjmp(timeoutbuf)==0)
	{
	  fu = signal(SIGALRM,sigALRM);
	  alarm(FAX_INIT_TIMEOUT);
	  writecmd("ATE0&N32");
	  getret("OK");
	  writecmd("AT+FCLASS=6");
	  getret("OK");      
	  fdprintf(fd,"AT#V1#T0#R0#L2#C3#B0#P%s\r\n",LOCAL_FAX_NO);
	  getret("OK");/**/
	  
	  writecmd("AT");
	  tcdrain();
	  if(getret("OK"))
	    {
	      alarm(0);
	      signal(SIGALRM, fu);
	      logto(1,"Fax is syncron");
	      return 0;
	    }
	}
      else {
	logto(1,"Timeout in sync\n");
	return -1;
      }
    }
  return (-1);
}



/* initialize voice mode */
int
init_voice()
{
  writecmd("ATZE0*P0");
  getret("OK");
  writecmd("AT+FCLASS=8");
  getret("OK");
  writecmd("AT+VSM=2");
  getret("OK");
  writecmd("AT+VSD=21,40");
  getret("OK");
}

int 
init_vdef()
{
  if(local)
    {
      writecmd("AT+VLS=8");
      Debug(1,"Set device 8\n");
    }
  else
    {
      Debug(1,"Set device 2\n");
      writecmd("AT+VLS=2");
    }
  getret("VCON");
}


int 
init_vspeaker(fd)
     int fd;
{
  writecmd("AT+VLS=2");
  Debug(3,"Set device to internal speaker\n");
  getret("VCON");
}


int 
term_vdef()
{
  writecmd("AT+VLS=0");
  Debug(1,"Set device 0\n");
  getret("OK");
}


