/*
** (c) 1992 Uwe C. Schroeder, Anwendungssysteme , Augsburg, Germany
**
** 
** Permission to use, copy, and modify this software and its
** documentation for non comercial  purpose is hereby granted 
** without fee, provided that
** the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation, and that the name of Uwe C. Schroeder not be used in
** advertising or publicity pertaining to distribution of the software without
** specific, written prior permission.  Uwe Schroeder makes no representations
** about the suitability of this software for any purpose.  It is provided
** "as is" without express or implied warranty.
** This software may not be sold or distributed with commercial products
** ( this includes distribution "for users convenience" ) without prior
** written permission by the author.
**
** UWE SCHROEDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
** INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
** EVENT SHALL UWE SCHROEDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
** CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
** DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
** TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
** PERFORMANCE OF THIS SOFTWARE.
**
**
** This is a alpha release, which means, that there are still several
** known bugs.
**
** Please report bugs to:
**
**                     usys@phoenix.abg.sub.org
**
*/


#include <stdio.h>
#include <sys/types.h>
#include <errno.h>
#include "vfax.h"

static char *masternotify[] = {
#define MN_REC_OK 0
  "I received a fax from %s with %d bytes.\nIt's in \n%s\n",
#define MN_REC_TRUNC 1
  "I received a incomplete fax from %s with %d bytes.\nIt's in \n%s\n",
#define MN_REC_FAIL 2
  "Number %s tried to send a fax.\n%d bytes spooled to\n%s\n"
};

static char *notifications[] = {
#define NOTIFICATION_OK 0
    "Your fax to %s has been successfully sent.\n",
#define NOTIFICATION_FAILED 1
    "There were problems transmitting your fax to %s, it cannot be sent.\n",
#define NOTIFICATION_RETRY  2
    "The transmission of your fax to %s failed, I will try again later.\n",
#define NOTIFICATION_TOOMANY 3
    "The transmission of your fax to %s failed, and the maximum number\n\
of retries has been exceeded.  I'm very sorry, but your fax has\n\
been deleted.\n",
#define NOTIFICATION_DENIED 4
    "I'm sorry, but you don't have long distance access.  Your fax to\n\
%s has been deleted.\n"
};


int
mail(qt,stat)
     Queue *qt;
     int stat;
{
  char program[BUFSIZ];
  FILE *fp;

  /* check stat */
  if(stat < 0 || stat > 4)
    return -1;
  
  if (qt->mail) {
    sprintf(program, "%s %s", MAILER, qt->user);
    
    if ((fp = popen(program, "w")) == NULL) {
      logto(0,"can't open mail program!");
      return;
    }
    
    fprintf(fp, "From: FAX Spooler\n");
    fprintf(fp, "Subject: FAX notification\n");
    fprintf(fp, notifications[stat], qt->phone);
    fprintf(fp, "\nSincerely yours,\nThe Fax Daemon\n");
    
    pclose(fp);
  }
}

int
mastermail(st)
     Status *st;
{
  char program[BUFSIZ];
  FILE *fp;

  sprintf(program, "%s %s", MAILER, FAXMASTER);
    
  if ((fp = popen(program, "w")) == NULL) {
    logto(0,"can't open mail program!");
    return;
  }
    
  fprintf(fp, "From: FAX Spooler\n");
  fprintf(fp, "Subject: FAX reception status\n");
  fprintf(fp, masternotify[st->status], st->phone,st->size,st->file);
  fprintf(fp, "\nSincerely yours,\nThe Fax Daemon\n");
  
  pclose(fp);
}


