/*
 *   Trans92 - programme de communication Linux-TI92
 *
 *   copyright (c) 1998  Emmanuel Beffara
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

//
// d�finition de la classe TIFile :
//   classe de gestion des fichiers .92?
//
// n�cessite la d�finition de la classe TI92 (pour les variables)

struct TIFile {
  char sign[8];
  short _1;
  char rep[8];
  char comm[40];
  short _2;
  long _3;
  char nom[8];
  long type;
  long taille;
  short _4;
  char _5[4];
  unsigned char tvar[2];

  TIFile() { constantes(); }
  TIFile(istream &f) { f.read(this,sizeof(TIFile)); }
  void constantes();                // �criture des parties constantes
  bool operator!();                 // test d'int�grit�

    // cr�ation + �criture � partir d'une variable / d'un backup
  void ecris(TI92::Variable&,ostream&);
    // lecture dans une variable / un backup + contr�le du format
  int lis(istream&,TI92::Variable&,bool nrep=true);
};
