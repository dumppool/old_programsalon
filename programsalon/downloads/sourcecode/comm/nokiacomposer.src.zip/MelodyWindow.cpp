// MelodyWindow.cpp: implementation of the MelodyWindow class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "nokiacomposer.h"
#include "MelodyWindow.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// +-------------------------------------------------------------
// |
// | Funci�n         : MelodyWindow::MelodyWindow
// | Descripci�n     : 
// |
// | pEdit           : 
// | 
// +-------------------------------------------------------------
MelodyWindow::MelodyWindow(CRichEditCtrl* pEdit) :
  pEdit_(pEdit),
  lockCount_(0)
{

}

// +-------------------------------------------------------------
// |
// | Funci�n         : MelodyWindow::~MelodyWindow
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
MelodyWindow::~MelodyWindow()
{
  while( lockCount_ )
    Unlock();
}

// +-------------------------------------------------------------
// |
// | Funci�n         : MelodyWindow::Lock
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void MelodyWindow::Lock()
{
  ++lockCount_;
  pEdit_->GetParent()->LockWindowUpdate();
}

// +-------------------------------------------------------------
// |
// | Funci�n         : MelodyWindow::Unlock
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void MelodyWindow::Unlock()
{
  --lockCount_;

  if(lockCount_ == 0)
    pEdit_->GetParent()->UnlockWindowUpdate();
}

// +-------------------------------------------------------------
// |
// | Funci�n         : MelodyWindow::MarkAllNotesGood
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void MelodyWindow::MarkAllNotesGood()
{
  CHARFORMAT cf;
  CHARRANGE  oldSelection;

  Lock();

    pEdit_->GetSel(oldSelection);
    pEdit_->GetDefaultCharFormat(cf);
    pEdit_->SetSel(0,-1);                 // select all
    pEdit_->SetSelectionCharFormat(cf);
    pEdit_->SetSel(oldSelection);

  Unlock();
}

// +-------------------------------------------------------------
// |
// | Funci�n         : MelodyWindow::MarkBadNote
// | Descripci�n     : 
// |
// | firstPos        : 
// | lastPos         : 
// | 
// +-------------------------------------------------------------
void MelodyWindow::MarkBadNote(int firstPos, int lastPos)
{
  CHARFORMAT cf;
  CHARRANGE  oldSelection;
  
  Lock();

    pEdit_->GetSel(oldSelection);
    pEdit_->GetDefaultCharFormat(cf);

    cf.crTextColor = RGB(255,0,0);

    pEdit_->SetSel(firstPos, lastPos);
    pEdit_->SetSelectionCharFormat(cf);
    pEdit_->SetSel(oldSelection);

  Unlock();
}

// +-------------------------------------------------------------
// |
// | Funci�n         : MelodyWindow::GetString
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
const CString& MelodyWindow::GetString()
{
  pEdit_->GetWindowText( string_ );
  return string_;
}