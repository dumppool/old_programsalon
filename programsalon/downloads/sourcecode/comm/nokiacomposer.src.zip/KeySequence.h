#ifndef KEYSEQUENCE_H
#define KEYSEQUENCE_H
#pragma once

#include "Note.h"

class Melody;

// +-------------------------------------------------------------
// |
// | Class           : Key
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
class Key
{
public:
  Key( char key = -1, bool dot = false) : key_(key), dot_(dot) {}
  operator char() { return key_; }

  bool HasDot() 
    { 
      Assert( IsTone() , "only tones can have dot");
      return dot_;
    }
  bool IsTone() 
    { 
      return key_ >= '0' && key_ <= '7'; 
    }
  Note::Tone GetTone() 
    { 
      Assert( IsTone(), "key is not a tone" );
      return (Note::Tone) (key_ - '1' + Note::ToneC) ; 
    }
private:
  char key_;
  bool dot_;
};

class KeySequence;

// +-------------------------------------------------------------
// |
// | Class           : KeySequenceIterator
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
class KeySequenceIterator
{
private:
  KeySequenceIterator(const KeySequence& keySequence);

  friend class KeySequence;

public:
  bool HasMoreElements();
  Key  GetNext();

private:
  const CString& keys_;
  int   position_;
};

// +-------------------------------------------------------------
// |
// | Class           : KeySequence
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
class KeySequence  
{
public:
	KeySequence(const char* keySequence = 0);
	virtual ~KeySequence();

  KeySequenceIterator GetKeySequence() const;

  void GenerateFromMelody( const Melody& melody );

  const CString& GetString() const;
  int GetKeyCount() const;

private:
  void AddKeyToSequence( Key key, bool parentheses = false);

  friend class KeySequenceIterator;
  CString keySequence_;
};

#endif //KEYSEQUENCE_H