#ifndef MELODY_H
#define MELODY_H
#pragma once

#include "Note.h"

class KeySequence;
class MelodyWindow;

// +-------------------------------------------------------------
// |
// | Class           : Melody
// | Description     : 
// | 
// +-------------------------------------------------------------
class Melody  : public CObject
{
  DECLARE_SERIAL(Melody)

public:
	Melody();
	virtual ~Melody();

  void Reset();

  void SetTitle( const char* title );
  const CString&  GetTitle() const;

  void SetTempo( int tempo );
  int GetTempo() const;

  virtual void Serialize(CArchive &ar);

  CString GetString() const;
  bool ParseString(MelodyWindow& melodyWindow);
  void ParseKeySequence(const KeySequence& keySequence);

  int GetNoteCount() const;

  const NoteSequence& GetNotes() const;

  void OctaveDown();
  void OctaveUp();
  void SemitoneDown();
  void SemitoneUp();

  bool CanOctaveUp() const;
  bool CanOctaveDown() const;
  bool CanSemitoneUp() const;
  bool CanSemitoneDown() const;


private:
  CString       title_;
  NoteSequence  notes_;
  int           tempo_;

  static DWORD PlayMIDIFile(HWND hWndNotify, LPSTR lpszMIDIFileName);
};

#endif //MELODY_H