#ifndef NOTE_H
#define NOTE_H
#pragma once

#include "Time.h"

#include <list>

using std::list;

// +-------------------------------------------------------------
// |
// | Class           : ParserException
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
class ParserException
{
public:
  ParserException( const char* description, const char* string );
  const CString& GetDescription();
  const CString& GetNoteString();
  const char* GetNextNote();

private:
  CString description_;
  CString noteString_;
  const char* nextNote_;
};

// +-------------------------------------------------------------
// |
// | Class           : Note
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
class Note : public CObject
{
  DECLARE_SERIAL(Note)

public:
  enum Tone { Silence, ToneC, ToneD, ToneE, ToneF, ToneG, ToneA, ToneB };  

  Note();
  Note(Tone tone, int duration, int octave, bool dot, bool sharp);
	Note(const Note& other);
	virtual ~Note();

  CString     GetString() const;
  const char* ParseString(const char* string);

  void GetMIDINote(int& duration, int& note) const;

  Tone  GetTone()     { return tone_; }
  int   GetDuration() { return duration_; }
  bool  HasDot()      { return dot_; }
  bool  HasSharp()    { return sharp_; }
  int   GetOctave()   { return octave_; }
  
  virtual void Serialize(CArchive &ar);

  void OctaveUp();
  void OctaveDown();
  void SemitoneUp();
  void SemitoneDown();

  bool CanOctaveUp() const;
  bool CanOctaveDown() const;
  bool CanSemitoneUp() const;
  bool CanSemitoneDown() const;
  
private:
  Tone  tone_;
  int   duration_;
  int   octave_;
  bool  dot_;
  bool  sharp_;

  virtual void AssertValid() const;
  bool IsValid(const char** reason) const;
};

typedef list<Note> NoteSequence;

#endif //NOTE_H