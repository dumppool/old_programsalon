// NokiaComposerView.cpp : implementation of the CNokiaComposerView class
//

#include "stdafx.h"
#include "NokiaComposer.h"

#include "NokiaComposerDoc.h"
#include "NokiaComposerView.h"
#include "MelodyWindow.h"

#include "Melody.h"
#include "MIDIWriter.h"
#include "KeySequence.h"
#include <mmsystem.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNokiaComposerView

IMPLEMENT_DYNCREATE(CNokiaComposerView, CFormView)

BEGIN_MESSAGE_MAP(CNokiaComposerView, CFormView)
	//{{AFX_MSG_MAP(CNokiaComposerView)
	ON_EN_CHANGE(IDC_MELODY, OnChangeMelody)
	ON_EN_CHANGE(IDC_TEMPO, OnChangeTempo)
	ON_EN_CHANGE(IDC_TITLE, OnChangeTitle)
	ON_BN_CLICKED(IDC_PARSE, OnParse)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_BN_CLICKED(IDC_PLAY, OnPlay)
	ON_WM_CLOSE()
	ON_BN_CLICKED(DIC_STOP, OnStop)
	ON_BN_CLICKED(IDC_GENERATE_KEY_SEQUENCE, OnGenerateKeySequence)
	ON_BN_CLICKED(IDC_GENERATE_NOTES, OnGenerateNotes)
	ON_COMMAND(ID_OCTAVE_DOWN, OnOctaveDown)
	ON_COMMAND(ID_OCTAVE_UP, OnOctaveUp)
	ON_COMMAND(ID_SEMITONE_DOWN, OnSemitoneDown)
	ON_COMMAND(ID_SEMITONE_UP, OnSemitoneUp)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_UPDATE_COMMAND_UI(ID_OCTAVE_DOWN, OnUpdateOctaveDown)
	ON_UPDATE_COMMAND_UI(ID_OCTAVE_UP, OnUpdateOctaveUp)
	ON_UPDATE_COMMAND_UI(ID_SEMITONE_DOWN, OnUpdateSemitoneDown)
	ON_UPDATE_COMMAND_UI(ID_SEMITONE_UP, OnUpdateSemitoneUp)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
  ON_MESSAGE(MM_MCINOTIFY, OnMCINotify)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNokiaComposerView construction/destruction

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::CNokiaComposerView
// | Description     : 
// | 
// +-------------------------------------------------------------
CNokiaComposerView::CNokiaComposerView()
	: CFormView(CNokiaComposerView::IDD),
  playingMIDI_(false)
{
	//{{AFX_DATA_INIT(CNokiaComposerView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::~CNokiaComposerView
// | Description     : 
// | 
// +-------------------------------------------------------------
CNokiaComposerView::~CNokiaComposerView()
{
}

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::DoDataExchange
// | Description     : 
// |
// | pDX             : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNokiaComposerView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::PreCreateWindow
// | Description     : 
// |
// | cs              : 
// | 
// +-------------------------------------------------------------
BOOL CNokiaComposerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::OnInitialUpdate
// | Description     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	ResizeParentToFit(FALSE);

  SetMelodyTextFormat();

  // event mask
  CRichEditCtrl* pEdit;

  pEdit = (CRichEditCtrl*) GetDlgItem(IDC_MELODY);
  pEdit->SetEventMask(ENM_CHANGE);

  pEdit = (CRichEditCtrl* ) GetDlgItem(IDC_KEY_SEQUENCE);
  pEdit->SetEventMask(ENM_CHANGE);
}

/////////////////////////////////////////////////////////////////////////////
// CNokiaComposerView printing

BOOL CNokiaComposerView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CNokiaComposerView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CNokiaComposerView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CNokiaComposerView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
}

/////////////////////////////////////////////////////////////////////////////
// CNokiaComposerView diagnostics

#ifdef _DEBUG
void CNokiaComposerView::AssertValid() const
{
	CFormView::AssertValid();
}

void CNokiaComposerView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CNokiaComposerDoc* CNokiaComposerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CNokiaComposerDoc)));
	return (CNokiaComposerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNokiaComposerView message handlers

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::OnChangeMelody
// | Description     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnChangeMelody() 
{
  OnParse();
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnChangeTempo
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnChangeTempo() 
{
  ModifyDoc md( GetDocument() );

  Melody& melody = md.GetMelody();

  melody.SetTempo( GetDlgItemInt( IDC_TEMPO )) ;
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnChangeTitle
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnChangeTitle() 
{
  ModifyDoc md( GetDocument() );

  Melody& melody = md.GetMelody();

  CString title;
  GetDlgItemText( IDC_TITLE, title );
  melody.SetTitle( title );
}


// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnUpdate
// | Descripci�n     : 
// |
// | pSender         : 
// | lHint           : 
// | pHint           : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
  CNokiaComposerDoc* pDoc = GetDocument();
  const Melody &melody = pDoc->GetMelody();
  
  int modified = pDoc->IsModified();

  SetDlgItemInt(  IDC_TEMPO, melody.GetTempo() );
  SetDlgItemText( IDC_TITLE, melody.GetTitle() );	
  SetDlgItemText( IDC_MELODY, melody.GetString() );

  SetDlgItemInt( IDC_NOTE_COUNT, melody.GetNoteCount() );  

  pDoc->SetModifiedFlag(modified);
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::UpdateDocument
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::UpdateDocument()
{
  ModifyDoc md( GetDocument() );
  
  Melody& melody = md.GetMelody();
  
  CString title;
  GetDlgItemText( IDC_TITLE, title );
  melody.SetTitle( title );

  MelodyWindow melodyWindow( (CRichEditCtrl*) GetDlgItem(IDC_MELODY) );
  melody.ParseString( melodyWindow );

  melody.SetTempo( GetDlgItemInt( IDC_TEMPO )) ;

  SetDlgItemInt( IDC_NOTE_COUNT, melody.GetNoteCount() );
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnParse
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnParse() 
{
  ModifyDoc md( GetDocument() );
  
  Melody& melody = md.GetMelody();

  MelodyWindow  melodyWindow( (CRichEditCtrl*) GetDlgItem( IDC_MELODY ) );
  melody.ParseString( melodyWindow );

  SetDlgItemInt( IDC_NOTE_COUNT, melody.GetNoteCount() );
}

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::OnEditPaste
// | Description     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnEditPaste() 
{
  CWnd* pFocusWnd = GetFocus();
  int   focusId = pFocusWnd->GetDlgCtrlID();

  pFocusWnd->SendMessage(WM_PASTE,0,0);
}

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::OnPlay
// | Description     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnPlay() 
{
  int modifiedFlag = GetDocument()->IsModified();
  UpdateDocument();
  GetDocument()->SetModifiedFlag(modifiedFlag);

  const Melody& melody = GetDocument()->GetMelody();
  
  CString tempMidiPath;
  GetTempPath( 100, tempMidiPath.GetBuffer(100) );
  tempMidiPath.ReleaseBuffer();
  tempMidiPath +=  "tmp.mid";

  {
    std::ofstream midiFile(tempMidiPath, std::ios::binary);
    MIDIwriter writer( melody, midiFile );    
    writer.WriteMIDIFile();
  }

  playingMIDI_ = true;

  PlayMIDIFile(tempMidiPath );
  
}

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::PlayMIDIFile
// | Description     : 
// |
// | hWndNotify      : 
// | lpszMIDIFileName : 
// | 
// +-------------------------------------------------------------
DWORD CNokiaComposerView::PlayMIDIFile(LPCSTR lpszMIDIFileName)
{
    DWORD dwReturn;
    MCI_OPEN_PARMS mciOpenParms;
    MCI_PLAY_PARMS mciPlayParms;
    MCI_STATUS_PARMS mciStatusParms;

    // Open the device by specifying the device and filename.
    // MCI will attempt to choose the MIDI mapper as the output port.
    mciOpenParms.lpstrDeviceType = "sequencer";   
    mciOpenParms.lpstrElementName = lpszMIDIFileName;

    if (dwReturn = mciSendCommand(NULL, MCI_OPEN,
        MCI_OPEN_TYPE | MCI_OPEN_ELEMENT,
        (DWORD)(LPVOID) &mciOpenParms))
    {
      CString errorString;

      mciGetErrorString(dwReturn, errorString.GetBuffer(300), 300);
      errorString.ReleaseBuffer();

      AfxMessageBox(CString("Error al reproducir el fichero midi: \n") + 
        CString(lpszMIDIFileName) + CString("\n") + 
        errorString , MB_ICONERROR);

      // Failed to open device. Don't close it; just return error.
      return (dwReturn);
    }

    // The device opened successfully; get the device ID.
    midiDeviceID_ = mciOpenParms.wDeviceID;

    // Check if the output port is the MIDI mapper.
    mciStatusParms.dwItem = MCI_SEQ_STATUS_PORT;
    if (dwReturn = mciSendCommand(midiDeviceID_, MCI_STATUS, 
        MCI_STATUS_ITEM, (DWORD)(LPVOID) &mciStatusParms))
    {
        mciSendCommand(midiDeviceID_, MCI_CLOSE, 0, NULL);
        return (dwReturn);
    }

    // Begin playback. The window procedure function for the parent 
    // window will be notified with an MM_MCINOTIFY message when 
    // playback is complete. At this time, the window procedure closes 
    // the device.
    mciPlayParms.dwCallback = (DWORD) GetSafeHwnd();
    if (dwReturn = mciSendCommand(midiDeviceID_, MCI_PLAY, MCI_NOTIFY, 
        (DWORD)(LPVOID) &mciPlayParms))
    {
        mciSendCommand(midiDeviceID_, MCI_CLOSE, 0, NULL);
        return (dwReturn);
    }

    return (0L);
}
 

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::OnMCINotify
// | Description     : 
// |
// | wFlags          : 
// | lDevID          : 
// | 
// +-------------------------------------------------------------
LRESULT CNokiaComposerView::OnMCINotify(WPARAM wFlags, LPARAM lDevID)
{
  mciSendCommand(lDevID, MCI_CLOSE, 0, NULL);
  playingMIDI_ = false;

  switch( wFlags )
  {
  case MCI_NOTIFY_ABORTED:
    TRACE("MCI_NOTIFY_ABORTED\n");
    break;
  case MCI_NOTIFY_FAILURE:
    TRACE("MCI_NOTIFY_FAILURE\n");
    break;
  case MCI_NOTIFY_SUCCESSFUL:
    TRACE("MCI_NOTIFY_SUCCESSFUL\n");
    break;
  case MCI_NOTIFY_SUPERSEDED:
    TRACE("MCI_NOTIFY_SUPERSEDED\n");
    break;
  }
  return 0;
}

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::OnStop
// | Description     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnStop() 
{
  mciSendCommand(midiDeviceID_, MCI_CLOSE, 0, NULL);
  playingMIDI_ = false;
}

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::OnClose
// | Description     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnClose() 
{
  if( playingMIDI_ )
  {
    OnStop();
  }
	CFormView::OnClose();
}

// +-------------------------------------------------------------
// |
// | Function        : CNokiaComposerView::SetMelodyTextFormat
// | Description     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::SetMelodyTextFormat()
{
  CRichEditCtrl* pEdit;

  CHARFORMAT cf;
  cf.cbSize = sizeof(CHARFORMAT);  

  cf.dwMask      = CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD;
  cf.dwEffects   = 0;
  cf.yHeight     = 10 * 20;
  cf.crTextColor = RGB(20,20,20);
  strcpy(cf.szFaceName, "Courier New");

  pEdit = (CRichEditCtrl*) GetDlgItem(IDC_MELODY);
  pEdit->SetDefaultCharFormat(cf);

  pEdit = (CRichEditCtrl* ) GetDlgItem(IDC_KEY_SEQUENCE);
  pEdit->SetDefaultCharFormat(cf);
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnGenerateKeySequence
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnGenerateKeySequence() 
{
  int modifiedFlag = GetDocument()->IsModified();
  UpdateDocument();
  GetDocument()->SetModifiedFlag(modifiedFlag);

  KeySequence keySequence;
  
  keySequence.GenerateFromMelody( GetDocument()->GetMelody() );
  
  SetDlgItemText( IDC_KEY_SEQUENCE, keySequence.GetString() );
  SetDlgItemInt( IDC_KEY_COUNT, keySequence.GetKeyCount() );
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnGenerateNotes
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnGenerateNotes() 
{
  CString keyString;
  
  GetDlgItemText( IDC_KEY_SEQUENCE, keyString );
  KeySequence keySequence( keyString );

  ModifyDoc md( GetDocument() );
  Melody& melody = md.GetMelody();

  melody.ParseKeySequence( keySequence );

  GetDocument()->UpdateAllViews(0,0,0);
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnOctaveDown
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnOctaveDown() 
{
  ModifyDoc md( GetDocument() );
  Melody& melody = md.GetMelody();

  if( melody.CanOctaveDown() )
  {
    melody.OctaveDown();
  }
  else
  {
    MessageBeep(MB_ICONASTERISK);
  }

  GetDocument()->UpdateAllViews(0,0,0);
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnOctaveUp
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnOctaveUp() 
{
  ModifyDoc md( GetDocument() );
  Melody& melody = md.GetMelody();

  if( melody.CanOctaveUp() )
  {
    melody.OctaveUp();
  }
  else
  {
    MessageBeep(MB_ICONASTERISK);
  }

  GetDocument()->UpdateAllViews(0,0,0);
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnSemitoneDown
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnSemitoneDown() 
{
  ModifyDoc md( GetDocument() );
  Melody& melody = md.GetMelody();

  if( melody.CanSemitoneDown() )
  {
    melody.SemitoneDown();
  }
  else
  {
    MessageBeep(MB_ICONASTERISK);
  }

  GetDocument()->UpdateAllViews(0,0,0);
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnSemitoneUp
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnSemitoneUp() 
{
  ModifyDoc md( GetDocument() );
  Melody& melody = md.GetMelody();

  if( melody.CanSemitoneUp() )
  {
    melody.SemitoneUp();
  }
  else
  {
    MessageBeep(MB_ICONASTERISK);
  }

  GetDocument()->UpdateAllViews(0,0,0);
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnEditCopy
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnEditCopy() 
{
  CWnd* pFocusWnd = GetFocus();
  int   focusId = pFocusWnd->GetDlgCtrlID();

  pFocusWnd->SendMessage(WM_COPY,0,0);
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnEditCut
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnEditCut() 
{
  CWnd* pFocusWnd = GetFocus();
  int   focusId = pFocusWnd->GetDlgCtrlID();

  pFocusWnd->SendMessage(WM_CUT,0,0);
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnEditUndo
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnEditUndo() 
{
  CWnd* pFocusWnd = GetFocus();
  int   focusId = pFocusWnd->GetDlgCtrlID();

  pFocusWnd->SendMessage(WM_UNDO,0,0);
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnUpdateOctaveDown
// | Descripci�n     : 
// |
// | pCmdUI          : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnUpdateOctaveDown(CCmdUI* pCmdUI) 
{
  const Melody &melody = GetDocument()->GetMelody();
  
  pCmdUI->Enable( melody.CanOctaveDown() );
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnUpdateOctaveUp
// | Descripci�n     : 
// |
// | pCmdUI          : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnUpdateOctaveUp(CCmdUI* pCmdUI) 
{
  const Melody &melody = GetDocument()->GetMelody();
  
  pCmdUI->Enable( melody.CanOctaveUp() );	
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnUpdateSemitoneDown
// | Descripci�n     : 
// |
// | pCmdUI          : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnUpdateSemitoneDown(CCmdUI* pCmdUI) 
{
  const Melody &melody = GetDocument()->GetMelody();
  
  pCmdUI->Enable( melody.CanSemitoneDown() );
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerView::OnUpdateSemitoneUp
// | Descripci�n     : 
// |
// | pCmdUI          : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerView::OnUpdateSemitoneUp(CCmdUI* pCmdUI) 
{
  const Melody &melody = GetDocument()->GetMelody();
  
  pCmdUI->Enable( melody.CanSemitoneUp() );
}
