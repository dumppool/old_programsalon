// MIDIwriter.cpp: implementation of the MIDIwriter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "NokiaComposer.h"
#include "MIDIwriter.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// +-------------------------------------------------------------
// |
// | Function        : MIDIwriter::MIDIwriter
// | Description     : 
// |
// | melody          : 
// | file            : 
// | 
// +-------------------------------------------------------------
MIDIwriter::MIDIwriter(const Melody& melody, std::ofstream& file) :
  melody_(melody),
  MIDIFile( file, /* format */ 1, /* tracks */ 2, /* division */ melody.GetTempo() )
{

}

// +-------------------------------------------------------------
// |
// | Function        : MIDIwriter::~MIDIwriter
// | Description     : 
// | 
// +-------------------------------------------------------------
MIDIwriter::~MIDIwriter()
{
}


// +-------------------------------------------------------------
// |
// | Function        : MIDIwriter::StartTrack
// | Description     : 
// |
// | trackno         : 
// | 
// +-------------------------------------------------------------
void MIDIwriter::StartTrack(int trackno)
{
  static int instrument = 33;

	switch (trackno)	{
		case 1:
			// ---- tempo & title track
			TextEvent(0, META_SEQTRKNAME, 21, melody_.GetTitle() );
			Tempo(0, 250000);
			break;
		case 2:
    {
			// ---- melody track
			TextEvent(0, META_SEQTRKNAME, 5, "ElectricBass");
			ProgramChange(0, 0, instrument);		// channel 0 = 33 "Electric Bass (finger)"

      const NoteSequence& notes = melody_.GetNotes();
      NoteSequence::const_iterator it;

      int delta = 0;
      int duration, note;

      for(it = notes.begin(); it != notes.end(); ++it )
      {
        it->GetMIDINote( duration, note );

        if( note == -1 )  // silence
        {
          delta += duration;
          continue;
        }

        NoteOn ( delta,    0, note, 64 );
        NoteOff( duration, 0, note, 0);
        delta = 0;
      }
			break;
    }
		default:
			break;
	}
}