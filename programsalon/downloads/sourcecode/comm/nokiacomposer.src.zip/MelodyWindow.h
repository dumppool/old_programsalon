#ifndef MELODYWINDOW_H
#define MELODYWINDOW_H
#pragma once

class MelodyWindow  
{
public:
  explicit MelodyWindow(CRichEditCtrl* pEdit);
	virtual ~MelodyWindow();

  void MarkAllNotesGood();
  void MarkBadNote(int firstPos, int lastPos);

  const CString& GetString();

  void Lock();
  void Unlock();

private:
  CRichEditCtrl* pEdit_;
  CString        string_;
  int            lockCount_;
};

#endif //MELODYWINDOW_H