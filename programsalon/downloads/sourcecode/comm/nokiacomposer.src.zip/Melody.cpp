// Melody.cpp: implementation of the Melody class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "NokiaComposer.h"
#include "Melody.h"

#include "KeySequence.h"
#include "MelodyWindow.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL(Melody, CObject, SCHEMA_VERSION)

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::Melody
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
Melody::Melody()
{
  Reset();
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::~Melody
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
Melody::~Melody()
{

}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::SetTitle
// | Descripci�n     : 
// |
// | title           : 
// | 
// +-------------------------------------------------------------
void Melody::SetTitle( const char* title )
{
  title_ = title;
}

// +-------------------------------------------------------------
// |
// | Funci�n         :  Melody::GetTitle
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
const CString&  Melody::GetTitle() const
{
  return title_;
}


// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::SetTempo
// | Descripci�n     : 
// |
// | tempo           : 
// | 
// +-------------------------------------------------------------
void Melody::SetTempo( int tempo )
{
  tempo_ = tempo;
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::GetTempo
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
int Melody::GetTempo() const
{
  return tempo_;
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::Serialize
// | Descripci�n     : 
// |
// | &ar             : 
// | 
// +-------------------------------------------------------------
void Melody::Serialize(CArchive &ar)
{
  if( ar.IsStoring() )
  {
    ar << title_;
    ar << tempo_;
    
    ar << notes_.size() ;

    NoteSequence::iterator it;
    for(it = notes_.begin() ; it != notes_.end() ; ++it )
    {
      it->Serialize(ar);
    }
  }
  else
  {
    int  notesCount;
    Note n;

    ar >> title_;
    ar >> tempo_;

    ar >> notesCount;

    while( notesCount-- )
    {
      n.Serialize(ar);
      notes_.push_back(n);
    }
  }
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::Reset
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void Melody::Reset()
{
  title_ = "sin t�tulo";
  tempo_ = 110;
  notes_.clear();
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::GetString
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
CString Melody::GetString() const
{
  CString melodyString;

  NoteSequence::const_iterator it = notes_.begin();

  while( it != notes_.end() )
  {
    melodyString += it->GetString();
    ++it;

    if( it != notes_.end() )
      melodyString += " ";
  }

  return melodyString;
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::ParseString
// | Descripci�n     : 
// |
// | melodyWindow    : 
// | 
// +-------------------------------------------------------------
bool Melody::ParseString(MelodyWindow& melodyWindow)
{
  Note note;
  const char* p = melodyWindow.GetString();
  const char* firstPos = p;
  bool foundErrors = false;

  melodyWindow.Lock();
  melodyWindow.MarkAllNotesGood();
  notes_.clear();  

  while( *p )
  {
    try
    {
      p = note.ParseString( p );
      notes_.push_back( note );
    }
    catch(ParserException& pe)
    {
      int errorPos = p - firstPos;
      int errorEnd = pe.GetNextNote() - firstPos;        

      melodyWindow.MarkBadNote(errorPos, errorEnd);

      if( *pe.GetNextNote() == 0 )
        TRACE("parece que es la ultima nota\n");

      TRACE("%s: %s [%d..%d]\n", pe.GetDescription(), pe.GetNoteString(), errorPos, errorEnd);
      p = pe.GetNextNote();

      foundErrors = true;
    }
  }
  melodyWindow.Unlock();
  return ! foundErrors;
}

// +-------------------------------------------------------------
// |
// | Function        : Melody::GetNotes
// | Description     : 
// | 
// +-------------------------------------------------------------
const NoteSequence& Melody::GetNotes() const
{
  return notes_;
}


// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::GetNoteCount
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
int Melody::GetNoteCount() const
{
  return notes_.size();
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::ParseKeySequence
// | Descripci�n     : 
// |
// | keySequence     : 
// | 
// +-------------------------------------------------------------
void Melody::ParseKeySequence(const KeySequence& keySequence)
{
  notes_.clear();

  KeySequenceIterator it = keySequence.GetKeySequence();

  int  octave   = 1;
  int  duration = 4;
  int  silenceDuration = 4;
  bool dot      = false;
  bool sharp    = false;
  Note::Tone  tone;

  // primera tecla
  if( it.HasMoreElements() )
  {
    Key key = it.GetNext();
    Assert(key.IsTone(), "la primera tecla deber�a ser una nota");
    tone = key.GetTone(); 
    
    // el resto
    while( it.HasMoreElements() )
    {
      Key key = it.GetNext();
      
      if( key.IsTone() )
      {
        // hemos terminado con una nota, y empieza la siguiente (o un silencio)
        if( tone == Note::Silence )
          notes_.push_back( Note( tone, silenceDuration, octave, dot, sharp ) ); 
        else
          notes_.push_back( Note( tone, duration, octave, dot, sharp ) ); 

        silenceDuration = duration;
        tone  = key.GetTone();
        dot   = key.HasDot();
        sharp = false;
        continue;
      }
      
      if( key == '#' )
      {
        sharp = true;
        continue;
      }
      
      if( key == '8' )
      {
        if( tone == Note::Silence )
          silenceDuration <<= 1;
        else
          duration <<= 1;
        continue;
      }
      
      if( key == '9' )
      {
        if( tone == Note::Silence )
          silenceDuration >>= 1;
        else
          duration >>= 1;
        continue;
      }

      if( key == '*' )
      {
        ++octave;
        if( octave > 3 )
          octave = 1;
        continue;

      }
    }
    notes_.push_back( Note( tone, duration, octave, dot, sharp ) ); 
  }
}


// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::OctaveDown
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void Melody::OctaveDown()
{
  NoteSequence::iterator it = notes_.begin();

  while( it != notes_.end() )
  {
    it->OctaveDown();
    ++it;
  }
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::OctaveUp
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void Melody::OctaveUp()
{
  NoteSequence::iterator it = notes_.begin();

  while( it != notes_.end() )
  {
    it->OctaveUp();
    ++it;
  }
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::SemitoneDown
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void Melody::SemitoneDown()
{
  NoteSequence::iterator it = notes_.begin();

  while( it != notes_.end() )
  {
    it->SemitoneDown();
    ++it;
  }
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::SemitoneUp
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void Melody::SemitoneUp()
{
  NoteSequence::iterator it = notes_.begin();

  while( it != notes_.end() )
  {
    it->SemitoneUp();
    ++it;
  }
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::CanOctaveUp
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
bool Melody::CanOctaveUp() const
{
  NoteSequence::const_iterator it = notes_.begin();

  bool result = true;
  while( result && it != notes_.end() )
  {
    result &= it->CanOctaveUp();
    ++it;
  }
  return result;
}

// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::CanOctaveDown
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
bool Melody::CanOctaveDown() const
{
  NoteSequence::const_iterator it = notes_.begin();

  bool result = true;
  while( result && it != notes_.end() )
  {
    result &= it->CanOctaveDown();
    ++it;
  }
  return result;
}


// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::CanSemitoneUp
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
bool Melody::CanSemitoneUp() const
{
  NoteSequence::const_iterator it = notes_.begin();

  bool result = true;
  while( result && it != notes_.end() )
  {
    result &= it->CanSemitoneUp();
    ++it;
  }
  return result;
}


// +-------------------------------------------------------------
// |
// | Funci�n         : Melody::CanSemitoneDown
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
bool Melody::CanSemitoneDown() const
{
  NoteSequence::const_iterator it = notes_.begin();

  bool result = true;
  while( result && it != notes_.end() )
  {
    result &= it->CanSemitoneDown();
    ++it;
  }
  return result;
}



