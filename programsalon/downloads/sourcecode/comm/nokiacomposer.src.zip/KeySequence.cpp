// KeySequence.cpp: implementation of the KeySequence class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "nokiacomposer.h"
#include "KeySequence.h"

#include "Melody.h"
#include "Note.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// +-------------------------------------------------------------
// |
// | Funci�n         : IsSeparator
// | Descripci�n     : 
// |
// | c               : 
// | 
// +-------------------------------------------------------------
static bool IsSeparator(char c)
{
  return c == ' ' || c == '\n' || c == '\t' || c == '\r';
}

// +-------------------------------------------------------------
// |
// | Funci�n         : KeySequence::KeySequence
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
KeySequence::KeySequence(const char* keySequence) :
  keySequence_(keySequence)
{
}

// +-------------------------------------------------------------
// |
// | Funci�n         : KeySequence::~KeySequence
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
KeySequence::~KeySequence()
{
}

// +-------------------------------------------------------------
// |
// | Funci�n         : KeySequence::GetKeySequence
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
KeySequenceIterator KeySequence::GetKeySequence() const
{
  return KeySequenceIterator( *this );
}

// +-------------------------------------------------------------
// |
// | Funci�n         : KeySequence::GenerateFromMelody
// | Descripci�n     : 
// |
// | melody          : 
// | 
// +-------------------------------------------------------------
void KeySequence::GenerateFromMelody( const Melody& melody )
{
  int octave   = 1;
  int duration = 4;

  keySequence_.Empty();

  NoteSequence notes = melody.GetNotes();
  NoteSequence::const_iterator it;

  for( it = notes.begin(); it != notes.end(); ++it )
  {
    Note n = *it;

    //
    // tone
    //
    Key toneKey;
    switch( n.GetTone() )
    {
    case Note::Silence: toneKey = '0'; break;
    case Note::ToneC:   toneKey = '1'; break;
    case Note::ToneD:   toneKey = '2'; break;
    case Note::ToneE:   toneKey = '3'; break;
    case Note::ToneF:   toneKey = '4'; break;
    case Note::ToneG:   toneKey = '5'; break;
    case Note::ToneA:   toneKey = '6'; break;
    case Note::ToneB:   toneKey = '7'; break;
    default:
      Assert(0, "invalid tone");
    }
    AddKeyToSequence( toneKey, n.HasDot() );

    //
    // duration
    //
    int lastNoteDuration = duration;

    if( n.GetDuration() >= duration )
    {
      while( n.GetDuration() > duration )
      {
        AddKeyToSequence( '8' );  // hacer la nota mas corta, por lo tanto duration mas alto
        duration <<= 1;
      }
    }
    else
    {
      while( n.GetDuration() < duration )
      {
        AddKeyToSequence( '9' ); // hacer la nota mas larga, duration mas bajo
        duration >>= 1;
      }
    }

    if( n.GetTone() == Note::Silence )
    {
      duration = lastNoteDuration;  // los silencios no cambian la duraci�n
      continue;         // el silencio no tiene sostenido, puntillo ni octava
    }

    //
    // sharp
    //
    if( n.HasSharp() )
      AddKeyToSequence( '#' );

    //
    // octave
    //
    while( n.GetOctave() != octave )
    {
      AddKeyToSequence( '*' );
      ++octave;
      if( octave > 3 )
        octave = 1;
    }
  }
}

// +-------------------------------------------------------------
// |
// | Funci�n         : KeySequence::AddToKeySequence
// | Descripci�n     : 
// |
// | key             : 
// | 
// +-------------------------------------------------------------
void KeySequence::AddKeyToSequence( Key key, bool parentheses )
{
  if( ! keySequence_.IsEmpty() )
    keySequence_ += ' ';

  if( parentheses )
    keySequence_ += "(" + CString(key) + ")";
  else
    keySequence_ += key;
}

// +-------------------------------------------------------------
// |
// | Funci�n         : KeySequence::GetString
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
const CString& KeySequence::GetString() const
{
  return keySequence_;
}

// +-------------------------------------------------------------
// |
// | Funci�n         : KeySequence::GetKeyCount
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
int KeySequence::GetKeyCount() const
{
  int count = 0;

  KeySequenceIterator it(*this);

  while( it.HasMoreElements() )
  {
    Key k = it.GetNext();
    ++count;
  }
  return count;
}

// +-------------------------------------------------------------
// +-------------------------------------------------------------
// +-------------------------------------------------------------
// +-------------------------------------------------------------
// +-------------------------------------------------------------
// +-------------------------------------------------------------



// +-------------------------------------------------------------
// |
// | Funci�n         : KeySequenceIterator::KeySequenceIterator
// | Descripci�n     : 
// |
// | keySequence     : 
// | 
// +-------------------------------------------------------------
KeySequenceIterator::KeySequenceIterator(const KeySequence& keySequence) :
  keys_( keySequence.keySequence_ ),
  position_(0)
{
}

// +-------------------------------------------------------------
// |
// | Funci�n         : KeySequenceIterator::HasMoreElements
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
bool KeySequenceIterator::HasMoreElements()
{
  return position_ != keys_.GetLength();
}

// +-------------------------------------------------------------
// |
// | Funci�n         : KeySequenceIterator::GetNext
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
Key KeySequenceIterator::GetNext()
{
  Key key;

  do
  {
    key = keys_.GetAt( position_++ );

    if( key == '(' )
    {
      key = Key(keys_.GetAt( position_++ ), true);  // with dot
      Assert( keys_.GetAt( position_) == ')' , "Nota con puntillo inv�lida");
      position_++;
    }
  }
  while( IsSeparator( key ) && position_ < keys_.GetLength() );

  return key;   
}

