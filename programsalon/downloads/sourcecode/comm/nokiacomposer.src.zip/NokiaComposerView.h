// NokiaComposerView.h : interface of the CNokiaComposerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_NOKIACOMPOSERVIEW_H__D7331B10_0CF1_11D5_8FD0_0000E8754645__INCLUDED_)
#define AFX_NOKIACOMPOSERVIEW_H__D7331B10_0CF1_11D5_8FD0_0000E8754645__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CNokiaComposerView : public CFormView
{
protected: // create from serialization only
	CNokiaComposerView();
	DECLARE_DYNCREATE(CNokiaComposerView)

public:
	//{{AFX_DATA(CNokiaComposerView)
	enum{ IDD = IDD_NOKIACOMPOSER_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CNokiaComposerDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNokiaComposerView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL
  afx_msg LRESULT OnMCINotify(WPARAM wFlags, LPARAM lDevID);

// Implementation
public:
	virtual ~CNokiaComposerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
  void UpdateDocument();

private:
  DWORD PlayMIDIFile(LPCSTR lpszMIDIFileName);
  bool playingMIDI_ ;
  UINT midiDeviceID_;

  void SetMelodyTextFormat();

// Generated message map functions
protected:
	//{{AFX_MSG(CNokiaComposerView)
	afx_msg void OnChangeMelody();
	afx_msg void OnChangeTempo();
	afx_msg void OnChangeTitle();
	afx_msg void OnParse();
	afx_msg void OnEditPaste();
	afx_msg void OnPlay();
	afx_msg void OnClose();
	afx_msg void OnStop();
	afx_msg void OnGenerateKeySequence();
	afx_msg void OnGenerateNotes();
	afx_msg void OnOctaveDown();
	afx_msg void OnOctaveUp();
	afx_msg void OnSemitoneDown();
	afx_msg void OnSemitoneUp();
	afx_msg void OnEditCopy();
	afx_msg void OnEditCut();
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateOctaveDown(CCmdUI* pCmdUI);
	afx_msg void OnUpdateOctaveUp(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSemitoneDown(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSemitoneUp(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in NokiaComposerView.cpp
inline CNokiaComposerDoc* CNokiaComposerView::GetDocument()
   { return (CNokiaComposerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NOKIACOMPOSERVIEW_H__D7331B10_0CF1_11D5_8FD0_0000E8754645__INCLUDED_)
