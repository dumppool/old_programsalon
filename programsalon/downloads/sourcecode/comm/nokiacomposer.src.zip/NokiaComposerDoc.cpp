// NokiaComposerDoc.cpp : implementation of the CNokiaComposerDoc class
//

#include "stdafx.h"
#include "NokiaComposer.h"

#include "NokiaComposerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNokiaComposerDoc

IMPLEMENT_DYNCREATE(CNokiaComposerDoc, CDocument)

BEGIN_MESSAGE_MAP(CNokiaComposerDoc, CDocument)
	//{{AFX_MSG_MAP(CNokiaComposerDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNokiaComposerDoc construction/destruction

CNokiaComposerDoc::CNokiaComposerDoc()
{
	// TODO: add one-time construction code here

}

CNokiaComposerDoc::~CNokiaComposerDoc()
{
}

BOOL CNokiaComposerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

  melody_.Reset();

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CNokiaComposerDoc serialization

void CNokiaComposerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
	melody_.Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CNokiaComposerDoc diagnostics

#ifdef _DEBUG
void CNokiaComposerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CNokiaComposerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNokiaComposerDoc commands

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerDoc::GetMelody
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
const Melody& CNokiaComposerDoc::GetMelody()
{
  return melody_;
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerDoc::GetWritableMelody
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
Melody& CNokiaComposerDoc::GetWritableMelody()
{
  return melody_;
}

// +-------------------------------------------------------------
// |
// | Funci�n         : ModifyDoc::ModifyDoc
// | Descripci�n     : 
// |
// | pDoc            : 
// | 
// +-------------------------------------------------------------
ModifyDoc::ModifyDoc( CNokiaComposerDoc* pDoc ) :
  pDoc_(pDoc)
{
}
// +-------------------------------------------------------------
// |
// | Funci�n         : ModifyDoc::~ModifyDoc
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
ModifyDoc::~ModifyDoc()
{
  pDoc_->SetTitle( pDoc_->GetMelody().GetTitle() );
  pDoc_->SetModifiedFlag();  
}

// +-------------------------------------------------------------
// |
// | Funci�n         : GetMelody
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
Melody& ModifyDoc::GetMelody()
{
  return pDoc_->GetWritableMelody();
}

// +-------------------------------------------------------------
// |
// | Funci�n         : CNokiaComposerDoc::DeleteContents
// | Descripci�n     : 
// | 
// +-------------------------------------------------------------
void CNokiaComposerDoc::DeleteContents() 
{
	melody_.Reset();
	
	CDocument::DeleteContents();
}
