#ifndef MIDIWRITER_H
#define MIDIWRITER_H
#pragma once

#include "MIDIfile\MIDIfile.h"
#include "Melody.h"

// +-------------------------------------------------------------
// |
// | Class           : MIDIwriter
// | Description     : 
// | 
// +-------------------------------------------------------------
class MIDIwriter : public MIDIFile  
{
public:
	MIDIwriter::MIDIwriter(const Melody& melody, std::ofstream& file);
	virtual ~MIDIwriter();

  virtual void StartTrack(int trackno);

private:
  const Melody& melody_;
};

#endif //MIDIWRITER_H