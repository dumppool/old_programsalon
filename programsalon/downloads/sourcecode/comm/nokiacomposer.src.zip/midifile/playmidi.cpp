// ------ playmidi.cpp
#include <fstream>
#include <iostream>

#include <windows.h>

#include "midifile.h"

class WmTellOverture : public MIDIFile {
	void StartTrack(int trackno);
	static int m_nNotes[][2];
public:
	WmTellOverture(std::ofstream& rfile) : 
					MIDIFile(rfile, 1, 2, 125) { }
};

static const int iv = 1000;	// note interval
static const int nt = 60;	// 1st note of song = C central
/*
int WmTellOverture::m_nNotes[][2] = {			// {note, delta}
	{nt,0},{nt, iv/2},{nt,iv/2},{nt,iv},{nt,iv/2},{nt,iv/2},
	{nt,iv},{nt, iv/2},{nt+5,iv/2},{nt+7,iv},{nt+9,iv},{nt,iv},
	{nt,iv/2},{nt,iv/2},{nt,iv},{nt,iv/2},{nt+5,iv/2},{nt+9,iv},
	{nt+9,iv/2},{nt+7,iv/2},{nt+4,iv},{nt,iv},{nt,iv},{nt, iv/2},
	{nt,iv/2},{nt,iv},{nt, iv/2},{nt,iv/2},{nt,iv},{nt,iv/2},
	{nt+5,iv/2},{nt+7,iv},{nt+9,iv},{nt+5,iv},{nt+9,iv/2},
	{nt+12,iv/2},{nt+10,iv*3},{nt+9,iv/2},{nt+7,iv/2},
	{nt+5,iv/2},{nt+9,iv},{nt+5,iv},
	{0,iv}
};
*/
int WmTellOverture::m_nNotes[][2] = {
  { nt+0 , iv / 4 },
  { nt+2 , iv / 4 },
  { nt+4 , iv / 4 },
  { nt+5 , iv / 4 },
  { nt+7 , iv / 4 },
  { nt+9 , iv / 4 },
  { nt+11, iv / 4 },
  
  { nt+12, iv / 4 },
/*  { nt+14, iv },
  { nt+16, iv },
  { nt+17, iv },
  { nt+19, iv },
  { nt+21, iv },
  { nt+23, iv },

  { nt+24, iv },*/
  { 0, iv / 4} // marca el final
};
// +-------------------------------------------------------------
// |
// | Function        : WmTellOverture::StartTrack
// | Description     : 
// |
// | trackno         : 
// | 
// +-------------------------------------------------------------
void WmTellOverture::StartTrack(int trackno)
{
	switch (trackno)	{
		case 1:
			// ---- tempo track
			TextEvent(0, META_SEQTRKNAME, 21, "William Tell Overture");
			Tempo(0, 250000);
			break;
		case 2:
			// ---- piano track
			TextEvent(0, META_SEQTRKNAME, 5, "Electric Bass");
			ProgramChange(0, 0, 33);		// channel 0 = 33 "Electric Bass (finger)"
			// --- play the notes
			int i;
			for (i = 0; m_nNotes[i][0] != 0; i++)	{
				if (i > 0)
					NoteOff(m_nNotes[i-1][1],0,m_nNotes[i-1][0],0);
				NoteOn(0,0,m_nNotes[i][0],64);
			}
			NoteOff(m_nNotes[i][1],0,m_nNotes[i-1][0],0);
			break;
		case 3:
		{
			// ---- drum track
			const int shot = 42;
			const int crash = 49;
			TextEvent(0, META_SEQTRKNAME, 5, "Drums");
			ProgramChange(0, 9, 0);
			for (i = 0; m_nNotes[i][0] != 0; i++)
				NoteOn(m_nNotes[i][1],9,shot,64);
			NoteOn(iv,9,crash,100);
			break;
		}
		default:
			break;
	}
}
int main()
{
	std::ofstream ifile("WTO.mid", std::ios::binary);
	WmTellOverture wto(ifile);
	wto.WriteMIDIFile();

  ShellExecute(0, "play", "WTO.mid", "", "", SW_SHOW);
	return 0;
}
