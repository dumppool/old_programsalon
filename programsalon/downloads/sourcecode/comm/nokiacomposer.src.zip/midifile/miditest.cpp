// ---- miditest.cpp
#include <iostream>
#include <iomanip>
#include <fstream>
#include "midifile.h"

// ---- application class for displaying contents of SMF file.
// +-------------------------------------------------------------
// |
// | Class           : MIDITest
// | Description     : 
// | 
// +-------------------------------------------------------------
class MIDITest : public MIDIFile	{

public:
	MIDITest(std::ifstream& rFile) : MIDIFile (rFile, false) { }

protected:
	virtual void StartTrack(int trackno);
	virtual void EndOfTrack(Long delta);

	virtual void NoteOn(Long delta,Short channel,Short note, Short velocity);
	virtual void NoteOff(Long delta,Short channel,Short note, Short velocity);

  virtual void Header(Short format, Short tracks, Short division);
	virtual void SequenceNum(Long delta,Short seqnum);
	virtual void TextEvent(Long delta,Short event,Long length,const char* text);
	virtual void Tempo(Long delta,Long tempo);
	virtual void SMPTE(Long delta,Short hour,Short min,Short sec,Short frame,Short fract);
	virtual void TimeSignature(Long delta,Short numer,Short denom,Short clocks,Short qnotes);
	virtual void KeySignature(Long delta,Short sharpflat,bool isminor);
	virtual void SequencerSpecific(Long delta,Short length, const char* text);
	virtual void Pressure(Long delta,Short channel,Short note, Short aftertouch);
	virtual void Controller(Long delta,Short channel,Short controller, Short value);
	virtual void ProgramChange(Long delta,Short channel,Short program);
	virtual void ChannelPressure(Long delta,Short channel,Short aftertouch);
	virtual void PitchBend(Long delta,Short channel,Short pitch);
	virtual void ChannelPrefix(Long delta,Short channel);
	virtual void UnknownMetaType(Long delta,Short type);
	virtual void UnknownStatus(Long delta,Short channel,Short event);
	virtual void SystemExclusive(Long delta,Long length,const char* data);
	virtual void SystemExclusivePacket(Long delta,Long length,const char* data);

private:
	void DisplayTime(Long delta)
		{ std::cout << std::setw(6) << delta << ' '; }
};

// +-------------------------------------------------------------
// |
// | Function        : MIDITest::Header
// | Description     : 
// |
// | format          : 
// | tracks          : 
// | division        : 
// | 
// +-------------------------------------------------------------
void MIDITest::Header(Short format,Short tracks,Short division)
{
	std::cout << "Header: \n";
	std::cout << "  Format:   " << format   << '\n';
	std::cout << "  Tracks:   " << tracks   << '\n';
	std::cout << "  Division: " << division << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::SequenceNum
// | Description     : 
// |
// | delta           : 
// | seqnum          : 
// | 
// +-------------------------------------------------------------
void MIDITest::SequenceNum(Long delta,Short seqnum)
{
	std::cout << std::setw(6) << delta << ' ';
	std::cout << "  Sequence: " << seqnum << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::TextEvent
// | Description     : 
// |
// | delta           : 
// | event           : 
// | len             : 
// | text            : 
// | 
// +-------------------------------------------------------------
void MIDITest::TextEvent(Long delta,Short event,Long len,const char* text)
{
	DisplayTime(delta);
	std::cout << "Text: " << event << ' ';
	for (int i = 0; i < len; i++)
		std::cout << *(text+i);
	std::cout << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::StartTrack
// | Description     : 
// |
// | trackno         : 
// | 
// +-------------------------------------------------------------
void MIDITest::StartTrack(int trackno)
{
	std::cout << "Start of Track " << trackno << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::EndOfTrack
// | Description     : 
// |
// | delta           : 
// | 
// +-------------------------------------------------------------
void MIDITest::EndOfTrack(Long delta)
{
	DisplayTime(delta);
	std::cout << "End of Track\n";
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::Tempo
// | Description     : 
// |
// | delta           : 
// | tempo           : 
// | 
// +-------------------------------------------------------------
void MIDITest::Tempo(Long delta,Long tempo)
{
	DisplayTime(delta);
	std::cout << "Tempo: " << tempo << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::SMPTE
// | Description     : 
// |
// | delta           : 
// | hour            : 
// | min             : 
// | sec             : 
// | frame           : 
// | fract           : 
// | 
// +-------------------------------------------------------------
void MIDITest::SMPTE(Long delta,Short hour,Short min,Short sec,Short frame,Short fract)
{
	DisplayTime(delta);
	std::cout << "SMPTE: " << hour << ':' << min << ':' << sec << ':' << frame << ':' << fract << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::TimeSignature
// | Description     : 
// |
// | delta           : 
// | numer           : 
// | denom           : 
// | clocks          : 
// | qnotes          : 
// | 
// +-------------------------------------------------------------
void MIDITest::TimeSignature(Long delta,Short numer,Short denom,Short clocks,Short qnotes)
{
	DisplayTime(delta);
	std::cout << "Time signature: " << numer << '/' << denom << '/' << clocks << '/' << qnotes << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::KeySignature
// | Description     : 
// |
// | delta           : 
// | sharpflat       : 
// | isminor         : 
// | 
// +-------------------------------------------------------------
void MIDITest::KeySignature(Long delta,Short sharpflat,bool isminor)
{
	DisplayTime(delta);
	std::cout << "Key signature: " << sharpflat << ", " << isminor << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::SequencerSpecific
// | Description     : 
// |
// | delta           : 
// | length          : 
// | text            : 
// | 
// +-------------------------------------------------------------
void MIDITest::SequencerSpecific(Long delta,Short length,const char* text)
{
	DisplayTime(delta);
	std::cout << "Sequencer specific: ";
	for (int i = 0; i < length; i++)
		std::cout << *(text+i);
	std::cout << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::NoteOn
// | Description     : 
// |
// | delta           : 
// | channel         : 
// | note            : 
// | velocity        : 
// | 
// +-------------------------------------------------------------
void MIDITest::NoteOn(Long delta,Short channel,Short note,Short velocity)
{
	DisplayTime(delta);
	std::cout << "Note On " << channel << ' ' << note << ' ' << velocity << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::NoteOff
// | Description     : 
// |
// | delta           : 
// | channel         : 
// | note            : 
// | velocity        : 
// | 
// +-------------------------------------------------------------
void MIDITest::NoteOff(Long delta,Short channel,Short note,Short velocity)
{
	DisplayTime(delta);
	std::cout << "Note Off " << channel << ' ' << note << ' ' << velocity << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::Pressure
// | Description     : 
// |
// | delta           : 
// | channel         : 
// | note            : 
// | aftertouch      : 
// | 
// +-------------------------------------------------------------
void MIDITest::Pressure(Long delta,Short channel,Short note,Short aftertouch)
{
	DisplayTime(delta);
	std::cout << "Pressure " << channel << ' ' << note << ' ' << aftertouch << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::Controller
// | Description     : 
// |
// | delta           : 
// | channel         : 
// | controller      : 
// | value           : 
// | 
// +-------------------------------------------------------------
void MIDITest::Controller(Long delta,Short channel,Short controller,Short value)
{
	DisplayTime(delta);
	std::cout << "Controller " << channel << ' ' << controller << ' ' << value << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::ProgramChange
// | Description     : 
// |
// | delta           : 
// | channel         : 
// | program         : 
// | 
// +-------------------------------------------------------------
void MIDITest::ProgramChange(Long delta,Short channel,Short program)
{
	DisplayTime(delta);
	std::cout << "Program " << channel << ' ' << program << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::ChannelPressure
// | Description     : 
// |
// | delta           : 
// | channel         : 
// | aftertouch      : 
// | 
// +-------------------------------------------------------------
void MIDITest::ChannelPressure(Long delta,Short channel,Short aftertouch)
{
	DisplayTime(delta);
	std::cout << "Channel Pressure " << channel << ' ' << aftertouch << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::PitchBend
// | Description     : 
// |
// | delta           : 
// | channel         : 
// | pitch           : 
// | 
// +-------------------------------------------------------------
void MIDITest::PitchBend(Long delta,Short channel,Short pitch)
{
	DisplayTime(delta);
	std::cout << "Pitch bend " << channel << ' ' << pitch << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::ChannelPrefix
// | Description     : 
// |
// | delta           : 
// | channel         : 
// | 
// +-------------------------------------------------------------
void MIDITest::ChannelPrefix(Long delta,Short channel)
{
	DisplayTime(delta);
	std::cout << "Channel Prefix " << channel << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::UnknownMetaType
// | Description     : 
// |
// | delta           : 
// | type            : 
// | 
// +-------------------------------------------------------------
void MIDITest::UnknownMetaType(Long delta,Short type)
{
	DisplayTime(delta);
	std::cout << "Unknown meta type: " << type << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::UnknownStatus
// | Description     : 
// |
// | delta           : 
// | channel         : 
// | event           : 
// | 
// +-------------------------------------------------------------
void MIDITest::UnknownStatus(Long delta,Short channel,Short event)
{
	DisplayTime(delta);
	std::cout << "Unknown status: " << channel << ' ' << event << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::SystemExclusive
// | Description     : 
// |
// | delta           : 
// | length          : 
// | data            : 
// | 
// +-------------------------------------------------------------
void MIDITest::SystemExclusive(Long delta,Long length,const char* data)
{
	DisplayTime(delta);
	std::cout << "System exclusive: ";
	for (int i = 0; i < length; i++)
		std::cout << std::hex << ((int)*(data+i)) << ' ';
	std::cout << '\n';
}
// +-------------------------------------------------------------
// |
// | Function        : MIDITest::SystemExclusivePacket
// | Description     : 
// |
// | delta           : 
// | length          : 
// | data            : 
// | 
// +-------------------------------------------------------------
void MIDITest::SystemExclusivePacket(Long delta,Long length,const char* data)
{
	DisplayTime(delta);
	std::cout << "System exclusive packet: ";
	for (int i = 0; i < length; i++)
		std::cout << std::hex << ((int)*(data+i)) << ' ';
	std::cout << '\n';
}
int main(int argc,char* argv[])
{
	if (argc > 1)	{
		try	{
			std::ifstream ifile(argv[1],std::ios::binary);
			MIDITest mt(ifile);
			mt.ReadMIDIFile();
		}
		catch (std::exception& exc)	{
			std::cout << "\nError: " << exc.what() << '\n';
		}
	}
	else
		std::cout << "\nUsage: miditest filename.mid\n";
	return 0;
}
