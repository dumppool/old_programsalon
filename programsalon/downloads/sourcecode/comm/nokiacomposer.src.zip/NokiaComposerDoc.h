#ifndef NOKIACOMPOSERDOC_H
#define NOKIACOMPOSERDOC_H
#pragma once

#include "Melody.h"

class CNokiaComposerDoc : public CDocument
{
protected: // create from serialization only
	CNokiaComposerDoc();
	DECLARE_DYNCREATE(CNokiaComposerDoc)

// Attributes
public:
  const Melody& GetMelody();

// Operations
public:


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNokiaComposerDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void DeleteContents();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CNokiaComposerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

private:
  Melody  melody_;

  Melody& GetWritableMelody();
  friend class ModifyDoc;

// Generated message map functions
protected:
	//{{AFX_MSG(CNokiaComposerDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

class ModifyDoc
{
public:
  ModifyDoc( CNokiaComposerDoc* pDoc );
  ~ModifyDoc();

  Melody& GetMelody();
private:
  CNokiaComposerDoc* pDoc_;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.



#endif //NOKIACOMPOSERDOC_H
