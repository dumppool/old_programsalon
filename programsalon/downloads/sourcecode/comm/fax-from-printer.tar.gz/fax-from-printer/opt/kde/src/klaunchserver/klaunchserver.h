

#define KLAUNCHSERVER_SOCKETNAME "/tmp/klaunchserver.socket"

static char *socketName = KLAUNCHSERVER_SOCKETNAME;

