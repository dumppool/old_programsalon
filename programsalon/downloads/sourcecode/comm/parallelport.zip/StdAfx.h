#define VC_EXTRALEAN

#include <afxwin.h>         
#include <afxext.h>         
#include <afxtempl.h>