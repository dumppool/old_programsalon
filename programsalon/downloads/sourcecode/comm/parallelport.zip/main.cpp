#include "stdafx.h"
#include "ParallelPort.h"

CWinApp theApp;




void DisplayUsage()
{
  _tprintf(_T("Usage: ParallelPort /S | /R filename\n"));
  _tprintf(_T("Remember to run the receiver side first as else\n"));
  _tprintf(_T("the sender side will timeout with error 1460 (timeout)\n"));
}


void _tmain(int argc, TCHAR* argv[])
{
  //Initialise MFC 
	if (!AfxWinInit(GetModuleHandle(NULL), NULL, NULL, SW_SHOW))
    return;

  //Validate that we have enough command line parameters
  if (argc < 3)
  {
    DisplayUsage();
    return;
  }

  try
  {
    CParallelPort port;
    port.Open(1);

    if ((_tcscmp(argv[1], _T("/S")) == 0) || (_tcscmp(argv[1], _T("/s")) == 0)) 
    {
      //Wait for the other end to become not busy
      _tprintf(_T("Waiting for other side to initialize..\n"));
      CParallelPortFileTransfer transfer(&port);

      CFileStatus fs;
      if (CFile::GetStatus(argv[2], fs))
      {
        _tprintf(_T("Sending file: %s\n"), argv[2]);

        DWORD dwStartTicks = GetTickCount();
        transfer.SendFile(argv[2]);
        DWORD dwTimeTaken = GetTickCount() - dwStartTicks;
        _tprintf(_T("Time taken was: %d Milliseconds\n"), dwTimeTaken);
        _tprintf(_T("File size was: %d bytes\n"), fs.m_size);
        _tprintf(_T("Average transfer rate was: %f Kilobytes per Second\n"), fs.m_size * 1000.0 / 1024.0 / dwTimeTaken);
      }      
      else
        _tprintf(_T("Could not find the file %s\n"), argv[2]);    
    }
    else if ((_tcscmp(argv[1], _T("/R")) == 0) || (_tcscmp(argv[1], _T("/r")) == 0))
    { 
      //Set the receive timeout to 30 seconds
      port.SetTimeout(30000);
      
      //Wait for the other end to become not busy
      _tprintf(_T("Waiting for other side to initialize..\n"));
      CParallelPortFileTransfer transfer(&port);

      //Wait for the other end to send a file
      _tprintf(_T("Waiting to receive file\n"));
    
      int S6;
      do
      {
        S6 = (port.ReadStatus() & 0x40) >> 6;
        _tprintf(_T("."));

        //Wait for a while before trying again
        Sleep(500);
      }
      while (S6 == 1);
 
      //Receive the file
      _tprintf(_T("Receiving file: %s\n"), argv[2]);
      transfer.ReceiveFile(argv[2]);
    }
    else
    {
      DisplayUsage();
      return;
    }
  }
  catch(CParallelException* pEx)
  {
    CString sError = pEx->GetErrorMessage();
    if (sError.GetLength())
      _tprintf(_T("Error: %s\n"), sError);
    else
      _tprintf(_T("Error: %d\n"), pEx->m_dwError);  
    pEx->Delete();
  }
}
