void
setTty(void);
