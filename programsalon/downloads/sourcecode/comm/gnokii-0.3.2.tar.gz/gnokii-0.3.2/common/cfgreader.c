/*

  G N O K I I

  A Linux/Unix toolset and driver for Nokia mobile phones.

  Copyright (C) 1999, 2000 Hugh Blemings & Pavel Jan�k ml.

  Released under the terms of the GNU GPL, see file COPYING for more details.

  Config file (/etc/gnokiirc and ~/.gnokiirc) reader.

  Modified from code by Tim Potter.
	
  Last modification: Mon Mar 20 21:40:04 CET 2000
  Modified by Pavel Jan�k ml. <Pavel.Janik@linux.cz>

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#include "cfgreader.h"

#ifdef WIN32

  #define index strchr

#endif

	/* Read configuration information from a ".INI" style file */
struct CFG_Header *CFG_ReadFile(char *filename)
{
    FILE *handle;
    char *line;
    char *buf;
    struct CFG_Header *cfg_info = NULL, *cfg_head = NULL;

    /* Error check */

    if (filename == NULL) {
		return NULL;
    }

    /* Initialisation */

    if ((buf = (char *)malloc(255)) == NULL) {
		return NULL;
    }
    
    /* Open file */

    if ((handle = fopen(filename, "r")) == NULL) {
#ifdef DEBUG
		fprintf( stderr, "CFG_ReadFile - open %s: %s\n", filename, strerror(errno));
#endif DEBUG
		return NULL;
    }
#ifdef DEBUG
    else
		fprintf( stderr, "Opened configuration file %s\n", filename );
#endif /* DEBUG */

    /* Iterate over lines in the file */

    while (fgets(buf, 255, handle) != NULL) {

		line = buf;
		/* Strip leading, trailing whitespace */

		while(isspace(*line))
		    	line++;

		while((strlen(line) > 0) && isspace(line[strlen(line) - 1]))
			line[strlen(line) - 1] = '\0';
	
		/* Ignore blank lines and comments */
	
		if ((*line == '\n') || (*line == '\0') || (*line == '#'))
			continue;

		/* Look for "headings" enclosed in square brackets */

		if ((line[0] == '[') && (line[strlen(line) - 1] == ']')) {
	    	struct CFG_Header *heading;

	 	   		/* Allocate new heading entry */

	    	if ((heading = (struct CFG_Header *)
		 		malloc(sizeof(*heading))) == NULL) {

				return NULL;
	    	}

	    		/* Fill in fields */

	    	memset(heading, '\0', sizeof(*heading));
	    
	    	line++;
	    	line[strlen(line) - 1] = '\0';

	    	heading->section = strdup(line);

	    		/* Add to tail of list  */

	    	heading->prev = cfg_info;

	    	if (cfg_info != NULL) {

				cfg_info->next = heading;

	    	}
			else {

				/* Store copy of head of list for return value */

				cfg_head = heading;
	    	}

	    	cfg_info = heading;

#ifdef DEBUG
	    printf("Added new section %s\n", heading->section);
#endif
	    	/* Go on to next line */

	    	continue;
		}

		/* Process key/value line */

		if ((index(line, '=') != NULL) && cfg_info != NULL) {
	    	struct CFG_Entry *entry;
	    	char *value;

	  	  		/* Allocate new entry */

	    	if ((entry = (struct CFG_Entry *)
		 		malloc(sizeof(*entry))) == NULL) {

				return NULL;
	    	}

	    		/* Fill in fields */

	    	memset(entry, '\0', sizeof(*entry));

	    	value = index(line, '=');
	  		*value = '\0';                /* Split string */
	    	value++;
	    
	    	while(isspace(*value)) {      /* Remove leading white */
				value++;
	    	}

	    	entry->value = strdup(value);

	    	while((strlen(line) > 0) && isspace(line[strlen(line) - 1])) {
				line[strlen(line) - 1] = '\0';  /* Remove trailing white */
	    	}

	    	entry->key = strdup(line);

	    		/* Add to head of list */

	    	entry->next = cfg_info->entries;

	    	if (cfg_info->entries != NULL) {
				cfg_info->entries->prev = entry;
	    	}

	    	cfg_info->entries = entry;

#ifdef DEBUG
	    printf("Adding key/value %s/%s\n", entry->key, entry->value);
#endif
	    	/* Go on to next line */

	    	continue;
		}

			/* Line not part of any heading */

		printf("Orphaned line: %s\n", line);
    }

    /* Return pointer to configuration information */

    return cfg_head;
}

/*  Write configuration information to a config file */

int CFG_WriteFile(struct CFG_Header *cfg, char *filename)
{
  /* Not implemented - tricky to do and preserve comments */

  return 0;
}

/* 
 * Find the value of a key in a config file.  Return value associated
 * with key or NULL if no such key exists. 
 */

char *CFG_Get(struct CFG_Header *cfg, char *section, char *key)
{
    struct CFG_Header *h;
    struct CFG_Entry *e;

    if ((cfg == NULL) || (section == NULL) || (key == NULL)) {
		return NULL;
    }

    /* Search for section name */

    for (h = cfg; h != NULL; h = h->next) {
		if (strcmp(section, h->section) == 0) {
	    
	    	/* Search for key within section */

	    	for (e = h->entries; e != NULL; e = e->next) {
				if (strcmp(key, e->key) == 0) {

		    	/* Found! */

		    		return e->value;
				}
	    	}
		}
    }

    /* Key not found in section */

    return NULL;
}

/*  Set the value of a key in a config file.  Return the new value if
    the section/key can be found, else return NULL.  */

char *CFG_Set(struct CFG_Header *cfg, char *section, char *key, 
		    char *value)
{
    struct CFG_Header *h;
    struct CFG_Entry *e;

    if ((cfg == NULL) || (section == NULL) || (key == NULL) || 
		(value == NULL)) {

		return NULL;
    }

    /* Search for section name */

    for (h = cfg; h != NULL; h = h->next) {
		if (strcmp(section, h->section) == 0) {
	    
	    	/* Search for key within section */

	    	for (e = h->entries; e != NULL; e = e->next) {
				if ((e->key != NULL) && strcmp(key, e->key) == 0) {

		    		/* Found - set value */

		    		free(e->key);
		    		e->key = strdup(value);

		    		return e->value;
				}
	    	}
		}
    }

    /* Key not found in section */

    return NULL;    
}

