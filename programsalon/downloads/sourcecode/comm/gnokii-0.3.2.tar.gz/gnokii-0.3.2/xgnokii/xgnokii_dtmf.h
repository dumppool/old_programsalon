/*

  X G N O K I I

  A Linux/Unix GUI for Nokia mobile phones.
  Copyright (C) 1999 Pavel Jan�k ml., Hugh Blemings
  & J�n Derfi��k <ja@mail.upjs.sk>.

  Released under the terms of the GNU GPL, see file COPYING for more details.

  Last modification: Tue Nov 27 1999
  Modified by Jan Derfinak

*/

#ifndef XGNOKII_DTMF_H
#define XGNOKII_DTMF_H

extern void GUI_CreateDTMFWindow ();

extern void GUI_ShowDTMF ();

#endif
