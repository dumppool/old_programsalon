/*

  X G N O K I I

  A Linux/Unix GUI for Nokia mobile phones.
  Copyright (C) 1999 Pavel Jan�k ml., Hugh Blemings
  & J�n Derfi��k <ja@mail.upjs.sk>.

  Released under the terms of the GNU GPL, see file COPYING for more details.

  Last modification: Sun Dec 26 1999
  Modified by Jan Derfinak

*/

#ifndef XGNOKII_SPEED_H
#define XGNOKII_SPEED_H

extern void GUI_CreateSpeedDialWindow (void);

extern void GUI_ShowSpeedDial (void);

#endif
