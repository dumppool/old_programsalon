/*
 * main.c
 *
 * Main program, spawns off all processes and then sits in a loop
 *
 * This code is without warranty of any kind and may have bugs you need to
 * fix
 *
 * In particular I have never tested it on an actual serial port; the state
 * machines and such were tested using pipes between processes on a windows
 * NT machine.  I have a test program somewhere that sends messages back
 * and forth to this...
 *
 * This x86 version has never been tested apart from the rest of the program
 * it goes with.
 *
 * Leave my name in the headers please
 *
 * Code by David Lindauer, CIMple technologies
 */
/*
 * Some of these include files have nothing to do with SEMI specs per se,
 * this secs I & II code was torn out of a larger project
 */
#include "utype.h"
#include "menus.h"
#include "units.h"
#include "unitext.h"
#include "rends.h"
#include "secs1.h"
#include "secs2.h"
#include "logic.h"

/* the following files hold the customization required to set up the secs II
 * databases used for a particular equipment setup
 */
#include "vars.cst"
#include "text.cst"
#include "secs2.cst"

/* Set this to the number of the language you want */
uint language = 0;

/* Program version number */
uint version = 10;

/* A bool for if control has been taken away from the operator */
BOOL remote_mode = FALSE;

/* metric/english units - the units code needs to be customized for whatever
 * units you are working with, what I have is a demo only */
uint metric = FALSE;

/* If resets are disallowed */
int reset_disable = FALSE;

/* holds the type of reset requested */
int reset_type;

/* This autoprogram stuff is actually left over from the larger project.
 * All it is used for here is as an example of stream 7 loads/saves
 */
// Limit for happenings
int auto_happen_limit;

// True if autostart should delay till later
BOOL autostart_hold;

// TRUE if disabled
BOOL AutostartDisable_flag;

// Year array, specifies what cycles to start when
BYTE AutoYear[DAYSPERYEAR];

// Count of items in each cycle
BYTE AutoCounts[MaxAutoCycles];

// Data for the cycle
ACYCLE AutoCycles[MaxAutoCycles][MaxItemsPerAutoCycle];

// Skip to the next string in a list of strings
// Used by modify button to get to the appropriate string for the mod value
// Used by units routines to get the appropriate string
PTEXT Skipstring( PTEXT string)
{
  // Skip through the string till after the next null
  while (*string != '\0') string++;
    return(++string);
}

/*
 * I use a version of cooperative multitasking.  Pause()  Means switch
 * to the next task
 */
void main(void)
{
  Secs1pup(TRUE);
  Secs2pup(TRUE);
	AddProcess(BtpIdle);
	AddProcess(Secs2Idle);
	while (!kbhit()) {
		Pause();
	}
}