/*
 * secs1com.c
 *
 * Stub for secs 1 byte communications, replace with routines to do
 * I/O over the serial port.  These are the functions which need to be
 * provided to SECS-I to get data communicated
 *
 * BORLAND C (16 bit) version
 *
 * Code by David Lindauer, CIMple technologies
 *
 */
#include "secs1.h"

/* Returns -1 if data not output */
/* this one is non-buffered, flush the output buffer if you are using
 * interrupts */
BOOL Secs1Charout(int data)
{
  return(data==-1);
}
/* this one is buffered */
BOOL Secs1BufferedCharout(int data)
{
  return(data==-1);
}
/* get a char from the input buffer */
int Secs1Charin(void)
{
  /* Returns -1 for no character */
    return(-1);
}
/* Clear all but last character in buffer, or last two if ACK, ENQ */
void Secs1Clearbuf(void)
{
}
/* Initialize routine
 * This routine will be called at power-up or whenever the baud rate changes
 */
void Secs1CharInit(void)
{
}