/*
 * secs1btp.c
 *
 * SECS-1 Block Transfer protocol routines
 *
 * Code by David Lindauer, CIMple technologies
 *
 */
#include "secs1.h"
#include "units.h"

#include <stdio.h>


#define LOG

#ifdef LOG
FILE *file;
BOOL cleared=FALSE;
#endif

// Define this if you want to disable all SECS-1 and SECS-2 timeouts
// #define DISABLE_SECS_TIMERS

/* Code for Block Transfer Protocol flow chart*/

extern int last_expected_block;
extern EXPECTED expected_blocks[NUMBER_EXPECTED_BLOCKS];

/* Send, receive buffer allocations */
SECS1_BLOCK send_blocks[NUMBER_SEND_BLOCKS];
SECS1_BLOCK receive_blocks[NUMBER_RECEIVE_BLOCKS];

/* Que insertion/deletion pointers */
int send_insert, send_delete;

/* Block being received into */
static int receiving_block;

// The host computer is a slave, the equipment a master.
// Should be false for equipment according to SECS1 BTP standards,
BOOL is_slave;  // TRUE for HOST COMPUTER, FALSE for equipment
BOOL is_in_wait;  // TRUE if slave is waiting for a reply to
                          // primary message
int expected_waiting; // The expected block we are waiting on

// We set this true each time after we succeed at a send
// So the SECS-2 establish will know...
BOOL send_success;

// We set this true during a receive, false afterward
BOOL btp_receiving;

// We set this true if we pass the retry limit
// SECS-2 will drop into the CR/CRA handshaking to try to establish
// communications if it goes true
BOOL secs1_retrylimit;

/* Following SECS-1 parameters must be setable, e.g. from touch-screen */

SECS_TIMER to_interchar, to_protocol;
int retries, device_id;
COMMSTATES CommStates;

NUMBER secspre_interchar = { 0.0F, UN_SECONDS };
NUMBER secspre_protocol = { 0.0F, UN_SECONDS };
NUMBER secspre_retries = { 0.0F, UN_NOUNIT | UNI_INTEGER };
NUMBER secspre_devid = { 0.0F, UN_NOUNIT | UNI_INTEGER };

// Baud rates
MODIFY secspre_baud = { 0 , 5 };
int baudlist[] = { 300, 1200, 2400, 4800, 9600 } ;

// First block allocated for this SECS2 message
// Used if SECS2 wants to deallocate everything on error
int send_first;

/* Routine to put a character out over serial port.
 * Returns TRUE if character output
 * MUST be non-buffering
*/
static BOOL BtpCharout(int data)
{
  Pause();
#ifdef LOG
  cleared = TRUE;
  fprintf(file,"\n>>%02x ",(BYTE)data);
#endif
  return(Secs1Charout(data));
}
/* Buffered version of the above.
*/
static BOOL BtpBufferedCharout(int data)
{
#ifdef LOG
  cleared = TRUE;
  fprintf(file,">>%02x ",(BYTE)data);
#endif
  Pause();
  return(Secs1BufferedCharout(data));
}
/* Routine to get a character.  Returns -1 if no character.
  * Note that binary data is being recieved, not ASCII.
*/
static int BtpCharin(void)
{
  int data=Secs1Charin();
#ifdef LOG
  if (data != BTP_NO_DATA) {
    cleared = TRUE;
    fprintf(file,"<<%02x ",(BYTE)data);
  }
#endif
  Pause();
  return(data);
}
/*
* Clear all but last char from serial buffer, or last two if they
  * are ACK and ENQ.  My interpretation of A.4.1 takes it to mean the
 * FIRST time the listen state is entered from above.
 */
static void BtpClearbuf(void)
{
#ifdef LOG
  if (!cleared)
    fprintf(file,"\n");
  cleared = TRUE;
#endif
  Secs1Clearbuf();
}
/* Start a timer
*/
void SecsTimestart(SECS_TIMER *timer)
{
  timer->startval = GetBiosTicks();
	// Timer->length is in 10ths of seconds, we convert to MS
  timer->TickLength= CvtToTicks(timer->length*100);
  timer->timing = TRUE;
}
/* Return true if timer timed out */

BOOL SecsTimeout(SECS_TIMER *timer)
{
#ifdef DISABLE_SECS_TIMERS
  // Never times out if disabled!
  return FALSE;
#else
  BOOL retval;

  // If timer is timing
  if (timer->timing) {
    int length;

    // Get length we've been going and adjust if there was a rolloever
    // This depends upon the max tick length being much less than
    // the max value GetBiosTicks returns
    length = GetBiosTicks()-timer->startval;
    if (length <0)
      length += TimerMax();
    // Now if we've gone long enough stop the timer
    if (length > timer->TickLength) {
      timer->timing = FALSE;
      retval = TRUE;
    }
    else
      // Still going
      retval = FALSE;

  }
  else
    // Stopped timers are always timed out
    retval = TRUE;

  return(retval);
#endif // DISABLE_SECS_TIMERS
}
/* Calculate checksum.  The 1992 specs indicate it should be the
* sum of all unsigned data bytes in the message excluding length and
* checksum bytes.
*/
static int BtpChecksum(SECS1_BLOCK *data)
{
  int i, checksum=0,length;

  // The length byte NEVER reflects the header length
  length = data->length + SECS1_HEADLEN + 1;

  // Notice the indice on the loop, also this is one example of why
  // the 'data' 'header' and 'length' fields must follow each other
  for (i=1; i< length; i++)
    checksum+=*(&data->length+i);

  return(checksum);
}
/*
 * handle reception, at this point we've received an ENQ
 */
static void BtpReceive(void)
{
  int checksum, read_checksum = 0, thischar, length;
  BOOL skim_chars = FALSE;

  btp_receiving = TRUE;

  // EOT and start protocol timer and clear buffer
  BtpCharout(EOT);
  SecsTimestart(&to_protocol);
  BtpClearbuf();

  // If we don't get the length before the timeout, put a NAK & exit
  while ((thischar = BtpCharin()) == BTP_NO_DATA)
    if (SecsTimeout(&to_protocol)) {
      // NO LENGTH BYTE
      BtpCharout(NAK);
      btp_receiving = FALSE;
      return;
  }

  if ((thischar >= SECS1_HEADLEN) && (thischar <= MAX_BLOCK_LEN + SECS1_HEADLEN)) {
    // Valid length byte
    if ((receiving_block = MraAllocReceive()) != MRA_ALLOC_ERR) {
      int i;
      SECS1_BLOCK *bp = &receive_blocks[receiving_block];

      // We have a block, set up the data length and receive length
      bp->length = (BYTE) (thischar - SECS1_HEADLEN);
      length = thischar + 2;

      for (i=0; i<length; i++) {
        // For each char, start the timer
        SecsTimestart(&to_interchar);
        while (TRUE) {
          // Get it and decide what to do with it.  Another reason for the
          // specific ordering of fields in the block structure
          thischar = BtpCharin();
          if (thischar != BTP_NO_DATA) {
            if (i < length-2)
              *((BYTE *)(&bp->length)+i+1) = (BYTE) thischar;
            else {
              read_checksum = (read_checksum << 8) + thischar;
            }
            break;
          }
          else
            if (SecsTimeout(&to_interchar)) {
              // IF we get here there was a timeout, NAK the block and clean up
              BtpCharout(NAK);
              MraDeallocReceive(receiving_block);
              btp_receiving = FALSE;
              return;
            }
        }
      }
      // Got the whole block, verify the checksum
      checksum = BtpChecksum(bp);
      if (checksum != read_checksum) {
        skim_chars = TRUE;
        MraDeallocReceive(receiving_block);
      }
      else {
        /* Happily got a block, do something with it and then ACK it */
        MraReceive(receiving_block);
        BtpCharout(ACK);
      }
    }
    else // No blocks to allocate, ignore the message
      // SECS-2 will time out eventually and any partial message will be purged
      skim_chars = TRUE;
  }
  else // Length out of range
    skim_chars = TRUE;

  if (skim_chars) {
    // Bad data, keep getting characters from the input stream until there
    // is an intercharacter timeout
    SecsTimestart(&to_interchar);
    BtpClearbuf();
    while (TRUE) {
      if (BtpCharin() != BTP_NO_DATA)
        SecsTimestart(&to_interchar);
      if (SecsTimeout(&to_interchar))
        break;
    }
    // Then NAK the block
    BtpCharout(NAK);
  }
  btp_receiving = FALSE;
}
/*
* Allocate a send buffer */
// Note that we've implemented this as a circular que, however, very little
// of the code presumes this is the case, so it should be fairly simple to
// modify this stuff to use another implementation if desired
int BtpAllocSend(BOOL first)
{
  int retval = send_insert;

  // Send buffers are kept in a circular que
  if (++send_insert >= NUMBER_SEND_BLOCKS)
    send_insert = 0;

  // If there are no more send blocks tell the caller
  if (send_insert == send_delete) {
    send_insert = retval;
    return(BTP_ALLOC_ERR);
  }

  // if This is the first block of a message register it
  if (first)
    send_first = retval;

  return(retval);
}
/*
 * Deallocate a single send buffer, used during transmission to lose the
 * sent block
 */
static void BtpDeallocSend(void)
{
  if (send_insert == send_delete)
    return;

  send_blocks[send_delete].ready_to_send = 0;
  if (++send_delete >= NUMBER_SEND_BLOCKS)
    send_delete = 0;
}
/*
 * Deallocate all blocks in this message, used prior to send to invalidate
 * the message we were currently working on
 */
void BtpUnallocAll(void)
{
  // Quit if none
  if (send_first == BTP_NO_FIRST)
    return;

  // Back up one block at a time until all gone
  while ((send_insert != send_delete) && (send_first != send_insert)) {
    if (--send_insert < 0)
      send_insert = NUMBER_SEND_BLOCKS - 1;
    send_blocks[send_insert].ready_to_send = 0;
  }

  // Can't do this again
  send_first = BTP_NO_FIRST;
}
// Flush all send buffers
void BtpFlushSend(void)
{
  int i;

  for (i=0; i< NUMBER_SEND_BLOCKS; i++) {
    send_blocks[i].ready_to_send = 0;
  }
  send_insert = 0;
  send_delete = 0;
  send_first = BTP_NO_FIRST;
}
/* Put data out on the line, we get here after a block has been marked
 * as ready to send
 */
static void BtpSend(void)
{
  int i,length,checksum, thischar, total_tries;
  BOOL reading_response, sending_enq;
  SECS1_BLOCK *bp = &send_blocks[send_delete];

  // We can attempt this several times
  total_tries = retries;

  // Until we succed or give up
  while (TRUE) {
    // Send ENQ, start protocol timer, clear input buffer
    BtpCharout(ENQ);
    SecsTimestart(&to_protocol);
    BtpClearbuf();

    sending_enq = TRUE;
    while (sending_enq) {
      if ((thischar = BtpCharin()) == EOT)
        // If we get an EOT the ENQ was successful
        sending_enq = FALSE;
      else {
        if (SecsTimeout(&to_protocol)) {
          // IF we get a timeout try again
          if (--total_tries < 0) {
            // too many retries, LOSE BLOCK CONTENTS of entire multiblock message
            // and exit
            secs1_retrylimit = TRUE;
						do {
							BtpDeallocSend();
            } while (!send_blocks[send_delete].h.E && (send_insert != send_delete));
            return;
          }
          else {
            // Else another retry, restart timer and send another ENQ
            SecsTimestart(&to_protocol);
            BtpCharout(ENQ);
          }
        }
        else
          if (is_slave && (thischar == ENQ)) {
            // CONTENTION, go do receive logic
            BtpReceive();
            // Then try to send the thing again
            SecsTimestart(&to_protocol);
            BtpCharout(ENQ);
          }
      }
    }

    // ENQ resulted in EOT, get length and checksum
    length = bp->length + SECS1_HEADLEN;
    checksum = BtpChecksum(bp);

    // Send length, header, data, checksum
    // Note again the reliance on the order of fields in the block structure
    BtpBufferedCharout(length);
    for (i=0; i<length; i++)
      BtpBufferedCharout(*((BYTE *)(&bp->length)+i+1));
    BtpBufferedCharout(checksum>>8);
    BtpCharout(checksum & 0xff);

    // Start timer, wait for ACK
    SecsTimestart(&to_protocol);
    BtpClearbuf();

    reading_response = TRUE;
    while (reading_response) {
      thischar = BtpCharin();
      if (thischar == ACK) {
        // ACK, block received, release it
        if (bp->h.E && bp->h.W) {
          // Register the block as expected and mark a wait
          // for reply before sending anything else if you are the slave
          // Note that this leaves us with the R and W bits set but with
          // the SECS-2 func set to the reply value in the
          // event an error is issued, which is fine, it may help diagnose
          // problems at some point in the future
          is_in_wait = is_slave;
          expected_waiting = MraRegisterExpected(bp, TRUE);
        }
        BtpDeallocSend();
        send_success = TRUE;
        return;
      }
      if (SecsTimeout(&to_protocol) || (thischar != BTP_NO_DATA)) {
        // OUT OF TIME or INVALID CHAR, do OUTER (RETRY) LOOP
        reading_response = FALSE;
        if (--total_tries < 0){
          // too many retries, LOSE BLOCK CONTENTS of entire multiblock message
          // and exit.  This algorythm is one of the few places we make an
          // assumption about the order in which blocks are allocated, if
          // the allocation routines are changed this will need it too.
          // This also depends upon the SECS-2 format not mixing the blocks
          // of different messages, which, the current implementation will not
          secs1_retrylimit = TRUE;
          while (!bp->h.E && (send_insert != send_delete))
            BtpDeallocSend();
          return;
        }
      }
    }
  }
}
// Power-up init, init anything which might be a factory preset now
void Secs1pup(BOOL power_up)
{
  int i;
  if (power_up) {

    is_slave = FALSE;

    send_insert = 0;
    send_delete = 0;
    receiving_block = 0;
    send_first = BTP_NO_FIRST;

    is_in_wait = FALSE;
    expected_waiting = 0;

    send_success = FALSE;

    secs1_retrylimit = FALSE;

    // Clear buffers
    BtpFlushSend();
    for (i=0; i< NUMBER_RECEIVE_BLOCKS; i++) {
      receive_blocks[i].ready_to_send = 0;
    }

    // Line initialization
    Secs1CharInit();
  }

  retries = DF_RETRY;
  to_interchar.timing = FALSE;
  to_interchar.length = TO_INTERCHAR;
  to_protocol.timing = FALSE;
  to_protocol.length = TO_PROTOCOL;
  device_id = DF_DEVID;

  // Low level communication params
  CommStates.BaudRate = DF_BAUD;
  CommStates.MultiDropAddress = 0;

  // This has to be done here in case the SECS menu is not included
  secspre_interchar.value = ((INTVAL) TO_INTERCHAR) /10;
  secspre_protocol.value = ((INTVAL) TO_PROTOCOL) / 10 ;
  secspre_retries.value = ((INTVAL) DF_RETRY);
  secspre_devid.value = ((INTVAL) DF_DEVID);

  secspre_baud.value = 0;
  while( baudlist[secspre_baud.value] && (baudlist[secspre_baud.value] != DF_BAUD))
    secspre_baud.value++;

#ifdef LOG
  file = fopen("data","w");
#endif
  // MRA initialization
  MraInit(power_up);
}
/* Idle routine, waits for data available either to receive from
  * the line or send from a buffer.  Note we've added code to prevent the
  * host (slave) from sending more than one primary message at a time.  Not in the
  * specs but without this we get contention.
*/
void BtpIdle(void)
{
  BOOL sent;
  while (TRUE) {
    sent = FALSE;

    // Send data if ready and not waiting for a response
    if (send_blocks[send_delete].ready_to_send) {
      if (is_in_wait)
        if (expected_blocks[expected_waiting].status == MRA_COMPLETE)
          is_in_wait = FALSE;
      if (!is_in_wait) {
      	sent = TRUE;
        BtpSend();
      }
    }

    // Specs specify that we don't try to receive while there is stuff to send
    if (!sent) {
      BtpClearbuf();
      if (BtpCharin() == ENQ)
        BtpReceive();
    }

    /* check interblock and reply timers */
    MraTimeouts();
  }
}