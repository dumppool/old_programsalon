/*
 * Stream10.c
 *
 * communication between host and operator console
 *
 * Code by David Lindauer, CIMple technologies
 *
 */
#include "secs2.h"
#include "menus.h"

extern int receive_number;

// Renditions
REND rn_secs2_text;

// This is the face the text shows to the world, a mockup of a TEXT structure
PTEXT secs2_text[MaxLanguage];

// This bool is set whenever the text is valid
BOOL secs2_valid_text;

// Text is stored here
static CTEXT theText[HostTermLen+1];

// Routine checks format and grabs the terminal id
static int GetTID(void)
{
  // Error if List specifier absent
  if (FV(FM_LIST) != 2)
    Secs2BaddataError();

  // Error if TID is only one byte or not binary
  if (FV(FM_BINARY) != 1)
    Secs2BaddataError();

  // Else return it
  return(RB());
}
// Routine grabs the text to the buffer
static BYTE GetText(void)
{
  // Error if text is not ASCII
  int i, len = FV(FM_ASCII);

  // See if length is too much to handle
  if (len > HostTermLen)
    return(ACKC10_NOTACCEPTED) ;

  // Transfer the data
  for (i=0; i<len; i++)
    theText[i] = (BYTE) RB();

  theText[len] = '\0';

  // If already a message we have to get rid of it if we want a redisplay
  // IF we add more Pauses in menus this will easily break
  // Note that SECS-2 reception is halted while we do this!
  if (secs2_valid_text) {
    secs2_valid_text = FALSE;
    for (i=0; i< NUM_TERM_PAUSES; i++)
      Pause();
  }

  // Set the display bool & exit
  secs2_valid_text = TRUE;

  return(ACKC10_OK);
}
// Routine sends the acknowledge code
static void TIDack(BYTE retcode)
{
  IF_BINARY(1);
  SB(retcode);
}
// Single line display
static void S10f3(void)
{
  // Error if non-zero TID
  if (GetTID() != 0)
    TIDack(ACKC10_NOTERMINAL);
  else
    TIDack(GetText());
}
// Multiblock display, not supported
static void S10f5(void)
{
  // Validate format and get the TID
  BYTE TID = (BYTE) GetTID();

  // We don't care about all the data
  receive_number = RECEIVE_COMPLETE;

  // Now twiddle the header to the multiblock error
  Secs2bChangeheader( ST_TERMINAL, TR_NOMULTIBLOCK);

  // Send the TID back
  IF_BINARY(1);
  SB(TID);
}
// Broadcast
static void S10f9(void)
{
  TIDack(GetText());
}
// List of all supported stream 10 functions
static PASSFUNC Stream10funcs[] = {
  { TR_DISPLAYLINE, S10f3 },
  { TR_MULTIBLOCK, S10f5 },
  { TR_BROADCAST, S10f9 },
  { 0, 0 } };
void Stream10(int number)
{
  Secs2FuncDispatch(number, Stream10funcs);
}
/* Nothing done at present
*/
void Stream10Init(BOOL power_up)
{
  if (power_up) {
    int i;

    secs2_valid_text = FALSE;

    // Initialize the text string
    for (i=0; i< MaxLanguage; i++)
      secs2_text[i] = theText;
    theText[0] = '\0';
  }
}