/*
 * mock-up for preset program save
 *
 * Code by David Lindauer, CIMple technologies
 *
 */
#include <stdio.h>

FILE *preset_bitfile;
static int readindex,writeindex;
static unsigned char presetarray[100];
PresetReadOpen()
{
	readindex = 0;
	return 1;
}
PresetWriteOpen()
{
	writeindex = 0;
	return 1;
}
PresetFileClose()
{
}
PresetFileLength()
{
	return 100;
}
int ByteIn(FILE *fil)
{
	return presetarray[readindex++];
}
void ByteOut(unsigned char byte,FILE *fil)
{
	presetarray[writeindex++] = byte;
}