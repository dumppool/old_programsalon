/*
 * Units.c
 *
 * handle units
 *
 * Code by David Lindauer, CIMple technologies
 *
 */
#include "logic.h"
#include "menus.h"
#include "units.h"

extern BOOL metric;
extern uint language;

extern PTEXT *unitext[];

// Get text for these units
PTEXT GetUnitText(int units, int flag)
{
  int skip = 0;
  PTEXT retval;

  // Decide how many strings to skip over
  if (metric)
    switch (flag) {
      case UNI_SHORT:
              skip = 3;
              break;
      case UNI_LONG:
              skip = 4;
              break;
      case UNI_SEMI:
              skip = 5;
              break;
    }
  else
    switch (flag) {
      case UNI_SHORT:
              skip = 0;
              break;
      case UNI_LONG:
              skip = 1;
              break;
      case UNI_SEMI:
              skip = 2;
              break;
    }
  // Get the text for the units && skip appropriately
  retval = (unitext[units & UNI_MASK])[language];
  while (skip--)
    retval = Skipstring(retval);
  return(retval);
}
// Routine applies conversion from metric to english
INTVAL ConvertToEnglish( PRESET *number)
{
  INTVAL retval;

  retval = number->value;
    switch (number->units & UNI_MASK) {
      case UN_FLOAT:
              break;
      case UN_BOOL:
              break;
      case UN_INT:
              break;
      case UN_NOUNIT:
              break;
      case UN_HRMIN:
              break;
      case UN_MINSEC:
              break;
      case UN_TEMP:
              retval = 1.8F * retval + 32.0F;
              break;
      case UN_DELTATEMP:
              retval = retval * 1.8F;
              break;
      case UN_FEET:
              retval = retval * 3.281F;
              break;
      case UN_FEETPERMINUTE:
              retval = retval * 3.281F;
              break;
      case UN_VOLUME:
              retval = retval / 3.7854F;
              break;
      case UN_FLOW:
              retval = retval / 3.7854F;
              break;
      case UN_MASS:
              retval = retval * 2.2046F;
              break;
      case UN_PRESSURE:
              retval = retval * 1.4504F;
              break;
      case UN_CURRENT:
              break;
      case UN_MS:
              break;
      case UN_HOURS:
              break;
      case UN_PERCENT:
              break;
      case UN_INCHES:
              retval = retval / 2.54F;
              break;
      case UN_INCHESPERSECOND:
              retval = retval / 2.54F;
              break;
      case UN_SPECIFICGRAVITY:
              retval = retval * 2.2046F;
              break;
      case UN_LBPERHOUR:
              break;
      case UN_RESISTANCE:
              break;
      case UN_SECONDS:
              break;
    }
  return retval;
}
// Routine applies conversion from english to metric
INTVAL ConvertToMetric( PRESET *number)
{
  INTVAL retval;

  retval = number->value;
    switch (number->units & UNI_MASK) {
      case UN_FLOAT:
              break;
      case UN_BOOL:
              break;
      case UN_INT:
              break;
      case UN_NOUNIT:
              break;
      case UN_HRMIN:
              break;
      case UN_MINSEC:
              break;
      case UN_TEMP:
              retval = (retval - 32.0F)/1.8F;
              break;
      case UN_DELTATEMP:
              retval = retval / 1.8F;
              break;
      case UN_FEET:
              retval = retval / 3.281F;
              break;
      case UN_FEETPERMINUTE:
              retval = retval / 3.281F;
              break;
      case UN_VOLUME:
              retval = retval * 3.7854F;
              break;
      case UN_FLOW:
              retval = retval * 3.7854F;
              break;
      case UN_MASS:
              retval = retval / 2.2046F;
              break;
      case UN_PRESSURE:
              retval = retval / 1.4504F;
              break;
      case UN_CURRENT:
              break;
      case UN_MS:
              break;
      case UN_HOURS:
              break;
      case UN_PERCENT:
              break;
      case UN_INCHES:
              retval = retval * 2.54F;
              break;
      case UN_INCHESPERSECOND:
              retval = retval * 2.54F;
              break;
      case UN_SPECIFICGRAVITY:
              retval = retval / 2.2046F;
              break;
      case UN_LBPERHOUR:
              break;
      case UN_RESISTANCE:
              break;
      case UN_SECONDS:
              break;
    }
  return retval;
}