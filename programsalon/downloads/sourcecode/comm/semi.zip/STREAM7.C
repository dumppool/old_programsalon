/*
 * Stream7.c
 *
 * process program load/save
 *
 *
 * Code by David Lindauer, CIMple technologies
 *
 */
#include <string.h>
#include <stdio.h>
#include "secs2.h"

extern char secs_model[6];
extern int receive_number;
extern PROGFUNC secs2_ppl_functions[];

/* Used during service program i/o */
static CTEXT ppid[PPID_LENGTH+1];
static PLFUNC ppl_func;

// Routine to load the PPID
static void LoadPpid(void)
{
  int i;

  // Verify data
  if (FV(FM_ASCII) != PPID_LENGTH)
    Secs2BaddataError();

  // Read in string
  for (i=0;i<PPID_LENGTH;i++)
    ppid[i] = (BYTE) RB();
  ppid[PPID_LENGTH] = '\0';
}
// Parse the function list and get the PPID func
// Return FALSE if PPID not valid
static BOOL GetPpidFunc(void)
{
  PROGFUNC *ppv = secs2_ppl_functions;

  while(ppv->validate) {
    if ((*ppv->validate)(ppid)) {
      // Get the exec routine, this being non-zero will allow it to be called
      ppl_func = ppv->exec;
      return(TRUE);
    }
    ppv++;
  }
  return(FALSE);
}

// See if we have enough space to load a program
// PROCESS PROGRAM LOAD ENQUIRE
static void S7f1(void)
{
  BYTE return_code = PPGNT_OK;
  int length;

  // Verify format
  if (FV(FM_LIST) != 2)
    Secs2BaddataError();

  // Get the PPID and the requested length
  LoadPpid();
  if (FV(FM_UINT) != 4)
    Secs2BaddataError();
  length = RI();

  // See if we recognize this PPID and there is enough buffer space
  // for reception
  if (GetPpidFunc()) {
    // Valid PPID, now see if length + FM_BYTE format is available
    if (length + 4 > MraFreeBuffers()*MAX_BLOCK_LEN)
      return_code = PPGNT_NOSPACE;
  }
  else
    return_code = PPGNT_BADPPID;

  // Now tell the host
  IF_BINARY(1);
  SB(return_code);
}
// Get a program
// PROCESS PROGRAM SEND
static void S7f3(void)
{
  BYTE return_code;

  // Verify format
  if (FV(FM_LIST) != 2)
    Secs2BaddataError();

  // Get the PPID
  LoadPpid();

  // We couldn't have gotten here if there were'nt enough buffers for
  // whatever is being sent, so no point in checking lengths & such
  // Just see if we have a valid PPID
  // if no GRANT was requested return with an error
  if (GetPpidFunc())
    return_code = (ppl_func)(PPL_SEND);
  else
    return_code = ACKC7_BADPPID;

  // Out the return_code
  IF_BINARY(1);
  SB(return_code);
}
// Send a program
// PROCESS PROGRAM LOAD REQUEST
static void S7f5(void)
{
  // Get the PPID
  LoadPpid();
  if (GetPpidFunc())
    (*ppl_func)(PP_LOAD);
  else
    IF_BINARY(0);

}
// List of all supported stream 7 functions
static PASSFUNC Stream7funcs[] = {
  { PP_INQUIRE, S7f1 },
  { PP_SEND, S7f3 },
  { PP_LOAD, S7f5 },
  { 0, 0 } };
/*
* Dispatch the function
*/
void Stream7(int number)
{
  Secs2FuncDispatch(number, Stream7funcs);
}
/*
* Initialize for the stream
  *  Count preset specifiers
*  Count command specifiers
*/
void Stream7Init(BOOL power_up)
{
}