/*
 * Bios.c
 *
 * Uses DOS bios routines to do things like set/ read the time and date
 * BORLAND C (16 bit) version
 *
 *
 * Code by David Lindauer, CIMple technologies
 *
 */
#include <bios.h>
#include <dos.h>
#include "menus.h"
#include "logic.h"

#define BIOSTICKMAX 4096
#define BIOSTICKRES 1
#define TIMER_MUL 10
#define TIMER_DIV 182

unsigned int far *bioscount = MK_FP(0x40,0x6c);
/* Bios interrupt */
#define TIMEINT 0x1a
/* BCD to decimal conversion macros */
#define FROMBCD(x) ((((x)>>4) * 10) + ( (x) & 15))
#define TOBCD(x)  ((((x)/10)<<4) + ((x) %10))

/* Set the time */
void SetBiosTime(int hr, int min, int sec)
{
  union REGS biosregs;

  biosregs.h.ah = 3;    // Set Time
  biosregs.h.ch = TOBCD(hr);
  biosregs.h.cl = TOBCD(min);
  biosregs.h.dh = TOBCD(sec);
  biosregs.h.dl = 0;		// No daylight savings option
  int86(TIMEINT, &biosregs, &biosregs);
}
/* Set the date */
void SetBiosDate(int month, int day, int year)
{
  union REGS biosregs;

  biosregs.h.ah = 5;    // Set Date
  biosregs.h.dh = TOBCD(month);
  biosregs.h.dl = TOBCD(day);
  biosregs.h.ch = TOBCD(year/100);
  biosregs.h.cl = TOBCD(year %100);
  int86(TIMEINT, &biosregs, &biosregs);
}
/* Get the time */
void GetBiosTime(int *hr, int *min, int *sec)
{
  union REGS biosregs;

  biosregs.h.ah = 2;    // Get Time
  int86(TIMEINT,&biosregs,&biosregs);
  *hr = FROMBCD(biosregs.h.ch);
  *min = FROMBCD(biosregs.h.cl);
  *sec = FROMBCD(biosregs.h.dh);
}
/* Get the date */
void GetBiosDate(int *month, int *day, int *year)
{
  union REGS biosregs;

  biosregs.h.ah = 4;    // Get Date
  int86(TIMEINT,&biosregs,&biosregs);
  *month = FROMBCD(biosregs.h.dh);
  *day = FROMBCD(biosregs.h.dl);
  *year = FROMBCD(biosregs.h.ch)*100 + FROMBCD(biosregs.h.cl);
}
/* Get the tick count, used in blinking buttons and performing
 * SEMI timeouts
 */
unsigned GetBiosTicks(void)
{
  return((unsigned)*bioscount % BIOSTICKMAX);
}
unsigned CvtToMS(uint value)
{
  return ((unsigned)((long)value *TIMER_MUL / TIMER_DIV));
}
unsigned CvtToTicks(uint value)
{
  return ((unsigned)((long) value * TIMER_DIV / TIMER_MUL));
}
unsigned TimerMax(void)
{
  return BIOSTICKMAX;
}
unsigned TimerResolution(void)
{
  return BIOSTICKRES;
}