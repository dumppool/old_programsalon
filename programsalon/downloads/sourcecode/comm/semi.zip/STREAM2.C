/*
 * Stream2.c
 *
 * preset handling, service program load/save, commands, time, reset, loopback
 *
 *
 * Code by David Lindauer, CIMple technologies
 *
 */
#include <string.h>
#include <stdio.h>
#include "menus.h"
#include "secs2.h"
#include "units.h"

extern char secs_model[6];
extern PR_STRUC secs_presetlist[];
extern BOOL *secs_cmdlist[];
extern uint language;
extern char **unitext[];
extern int enquire_list[NUMBER_ENQUIRIES];
extern int receive_number;
extern BOOL reset_disable;
extern int reset_type;
extern PROGFUNC secs2_spl_functions[];

/* Number of preset specifiers */
static int number_preset = 0;
/* Number of command specifiers */
static int number_cmd = 0;
/* Response code for changing preset values */
static int response_code;

/* Used during service program i/o */
static CTEXT spid[SPID_LENGTH+1];
static PLFUNC spl_func;

/*
* Note: a PRESET is the same as a SELECT variable;
*       an ACTUAL is the same as a STATUS variable
* Unlike the MENUS portion of the code which can only handle
* FLOATING format, secs-2 protocol can handle virtually any format.
* Thus binary, integer, and floating data can be sent intermixed
*
* the routines which put values out and get values in are largely
* untested for other than the deffault format
*/
// Service Program routines will mostly work if the data transfer routines are
// written for the specific program type
// Refer to code for stream 8 code for an idea how to do this
// Routine to load the SPID
static void LoadSpid(void)
{
  int i;

  // Verify data
  if (FV(FM_BINARY) != SPID_LENGTH)
    Secs2BaddataError();

  // Read in string
  for (i=0;i<SPID_LENGTH;i++)
    spid[i] = (BYTE) RB();
  spid[SPID_LENGTH] = '\0';
}
// Routine to parse the SPID and return a function to load/save data
static BOOL GetSpidFunc(void)
{
  PROGFUNC *spv = secs2_spl_functions;
  // Invalidate Grants whenever a new SPID comes in
  spl_func = 0;

  while(spv->validate) {
    if ((*spv->validate)(spid)) {
      // Get the exec routine, this being non-zero will allow it to be called
      spl_func = spv->exec;
      return(TRUE);
    }
    spv++;
  }
  return(FALSE);
}

// See if we have enough space to load a program
// SERVICE PROGRAM LOAD ENQUIRE
static void S2f1(void)
{
  BYTE return_code = GRANT_OK;
  int length;

  // Get the SPID and the requested length
  LoadSpid();
  if (FV(FM_UINT) != 4)
    Secs2BaddataError();
  length = RI();

  // See if we recognize this SPID and there is enough buffer space
  // for reception
  if (GetSpidFunc()) {
    // Valid SPID, now see if length + FM_BYTE format is available
    if (length + 4 > MraFreeBuffers()*MAX_BLOCK_LEN)
      return_code = GRANT_NOSPACE;
  }
  else
    return_code = GRANT_BADSPID;

  // If error, disallow grant
  if (return_code != GRANT_OK)
    spl_func = 0;

  // Now tell the host
  IF_BINARY(1);
  SB(return_code);
}
// Get a program
// SERVICE PROGRAM SEND
static void S2f3(void)
{
  BYTE return_code;

  // if no GRANT was requested return with an error
  if (spl_func == 0) {
    return_code = SPAACK_NOGRANT;
    receive_number = RECEIVE_COMPLETE;
  }
  else
    return_code = (*spl_func)(SPL_SEND);

  // Can't do it again
  spl_func = 0;

  // Out the return_code
  IF_BINARY(1);
  SB(return_code);
}
// Send a program
// SERVICE PROGRAM LOAD REQUEST
static void S2f5(void)
{
  // Get the SPID
  LoadSpid();
  if (GetSpidFunc())
    (*spl_func)(SPL_LOAD);
  else
    IF_BINARY(0);

  // Invalidate send requests
  spl_func = 0;
}
// Run a program
// SERVICE PROGRAM RUN SEND
static void S2f7(void)
{
  BYTE return_code;

  // Get the SPID and run the program

  LoadSpid();
  if (GetSpidFunc())
    return_code = (*spl_func)(SPL_RUN);
  else
    return_code = CSAACK_BADSPID;

  // Not intended for GRANTS
  spl_func = 0;

  // Send the return code
  IF_BINARY(1);
  SB(return_code);
}
/*
* Put out a preset value
*/
static void PrPutValue(int number)
{
  switch (secs_presetlist[number].units) {
    int temp;
    case UN_BINARY:
            IF_BINARY(1);
            SB(* ((BYTE *) (secs_presetlist[number].value)));
            break;
    case UN_BOOL:
            IF_BOOL(1);
            SB(* ((BYTE *) (secs_presetlist[number].value)));
            break;
    case UN_ASCII:
            IF_ASCII(temp = strlen((char *) secs_presetlist[number].value));
            SA((char *) secs_presetlist[number].value,temp);
            break;
    case UN_MODE:
            IF_INT(1);
            SI(((MODIFY *)secs_presetlist[number].value)->value);
            break;
    case UN_INT:
            IF_INT(1);
            SI(* ((int *) (secs_presetlist[number].value)));
            break;
    case UN_FLOAT:
            IF_FLOAT(1);
            SF(* ((float *) (secs_presetlist[number].value)));
            break;
    default:
            Secs2bSendValue(((PREREC *)secs_presetlist[number].value)->preset->value,
              ((PREREC *)secs_presetlist[number].value)->preset->units);
            break;
  }
}
/*
* Put out a preset low limit
*/
static void PrPutLowLim(int number)
{
  switch (secs_presetlist[number].units) {
    case UN_BINARY:
            IF_BINARY(1);
            SB(0);
            break;
    case UN_BOOL:
            IF_BOOL(1);
            SB(0);
            break;
    case UN_ASCII:
            IF_ASCII(0);
            break;
    case UN_MODE:
            IF_INT(1);
            SI(0);
            break;
    case UN_INT:
            IF_INT(1);
            SI(0);
            break;
    case UN_FLOAT:
            IF_FLOAT(1);
            SF(0.0F);
            break;
    default:
            Secs2bSendValue( (float) ((PREREC *)secs_presetlist[number].value)->lolim,
              ((PREREC *)secs_presetlist[number].value)->preset->units);
            break;
  }
}
/*
* Put out a preset high limit
*/
static void PrPuthilim(int number)
{
  switch (secs_presetlist[number].units) {
    case UN_BINARY:
            IF_BINARY(1);
            SB(255);
            break;
    case UN_BOOL:
            IF_BOOL(1);
            SB(255);
            break;
    case UN_ASCII:
            IF_ASCII(0);
            break;
    case UN_MODE:
            IF_INT(1);
            SI(((MODIFY *)secs_presetlist[number].value)->limit-1);
            break;
    case UN_INT:
            IF_INT(1);
            SI(0);
            break;
    case UN_FLOAT:
            IF_FLOAT(1);
            SF( 0.0F);
            break;
    default:
            Secs2bSendValue( (float) ((PREREC *)secs_presetlist[number].value)->hilim,
              ((PREREC *)secs_presetlist[number].value)->preset->units);
            break;
  }
}
/*
* Put out a preset default
*/
static void PrPutDefault(int number)
{
  switch (secs_presetlist[number].units) {
    case UN_BINARY:
            IF_BINARY(1);
            SB(0 );
            break;
    case UN_BOOL:
            IF_BOOL(1);
            SB(0);
            break;
    case UN_ASCII:
            IF_ASCII(0);
            break;
    case UN_MODE:
            IF_INT(1);
            SI(0);
            break;
    case UN_INT:
            IF_INT(1);
            SI(0);
            break;
    case UN_FLOAT:
            IF_FLOAT(1);
            SF(0.0F);
            break;
    default:
            Secs2bSendValue((float) ((PREREC *)secs_presetlist[number].value)->preset->value,
              ((PREREC *)secs_presetlist[number].value)->preset->units);
            break;
  }
}
/*
* Receive a preset value
* Note that receiving binary or ascii strings is dangerous because no
* limit checking is done on the incoming length
*/
static void PrGetValue(BOOL changing)
{
  uint i, len;
  int number, itemp;
  float ftemp;
  if (FV(FM_LIST) != 2)
    Secs2BaddataError();
  if (FV(FM_UWORD) != 2)
    Secs2BaddataError();
  number = RW();

  if (number >= number_preset) {
    response_code = EAC_BADCONST;
    return;
  }
  switch (secs_presetlist[number].units) {
    case UN_BINARY:
            len = FV(FM_BINARY);
            for (i=0; i<len; i++)
              if (changing)
                *(((BYTE *)secs_presetlist[number].value)+i) = (BYTE) RB();
              else
                RB();
            break;
    case UN_BOOL:
            FV(FM_BOOL);
            if (changing) {
              if (RB())
                *((BOOL *)secs_presetlist[number].value) = TRUE;
              else
                *((BOOL *)secs_presetlist[number].value) = FALSE;
            }
            else
                RB();
            break;
    case UN_ASCII:
            len = FV(FM_ASCII);
            for (i=0; i<len; i++)
              if (changing)
                *(((char *) secs_presetlist[number].value)+len) = (BYTE) RB();
              else
		RB();
	    break;
    case UN_MODE:
	    FV(FM_INT);
	    if (changing)
	      ((MODIFY *)secs_presetlist[number].value)->value = RI();
	    else {
	      itemp = RI();
	      if ((itemp < 0) || (itemp >= ((uint)((MODIFY *)secs_presetlist[number].value)->limit)))
                response_code = EAC_BADRANGE;
            }
            break;
    case UN_INT:
            FV(FM_INT);
            if (changing)
              *((int *)secs_presetlist[number].value) = RI();
            else {
              RI();
            }
            break;
    case UN_FLOAT:
            FV(FM_FLOAT);
            if (changing)
              *((float *)secs_presetlist[number].value) = RF();
            else {
              RF();
            }
            break;
    default:
            ftemp = Secs2bReceiveValue(((PREREC *) secs_presetlist[number].value)->preset->units);
            if (changing)
              *(&((PREREC *)secs_presetlist[number].value)->preset->value) = ftemp;
            else {
              if ((ftemp <= ((PREREC *)secs_presetlist[number].value)->lolim)
                || (ftemp >= ((PREREC *)secs_presetlist[number].value)->hilim))
              response_code = EAC_BADRANGE;
            }
            break;
  }
}
/* EQUIPMENT CONSTANT REQUEST */
static void S2f13(void)
{
  int i, count,itemcount, allentries = FALSE;

  // Verify format
  count = FV(FM_LIST);

  if (count > NUMBER_ENQUIRIES)
    Secs2ToomuchdataError();

  // Read in entries, if none or if any entry has zero length report all
  if (!count)
    allentries = TRUE;
  else
    for (i=0; i<count; i++) {
      itemcount = FV(FM_UWORD);
      if (!itemcount)
        allentries = TRUE;
      enquire_list[i] = RW();
    }

  if (allentries) {
    // All entries, send them
    IF_LIST(number_preset);
    for (i=0; i<number_preset; i++)
      PrPutValue(i);
  }
  else {
    // Else send the entries as requested
    IF_LIST(count);
    for (i=0; i<count; i++)
      if (enquire_list[i] >=number_preset)
        IF_BINARY(0);
      else
        PrPutValue(enquire_list[i]);
  }
}
/* NEW EQUIPMENT CONSTANT SEND */
static void S2f15(void)
{
  uint number,i;

  // Assume this is ok
  response_code = EAC_ACK;
  number = FV(FM_LIST);
  Secs2bSetBookmark();

  // Read in the values once in order to verify limits
  for (i=0; i<number; i++) {
    PrGetValue(FALSE);
    if (response_code != EAC_ACK)
      break;
  }

  // IF that was ok, read them in again to get the values
  // Don't do it if there is garbage tacked on the end!
  if (response_code == EAC_ACK) {
    if (receive_number == RECEIVE_COMPLETE) {
      Secs2bRestoreBookmark();
      for (i=0; i<number; i++)
        PrGetValue(TRUE);
    }
  }
  else
    receive_number = RECEIVE_COMPLETE;

  // Respond
  IF_BINARY(1);
  SB((BYTE)(response_code));
}
/* DATE AND TIME REQUEST */
static void S2f17(void)
{
  char timedate[13];
  int hour,min,sec, month,day,year, i;

  // Can't have more than header
  Secs2CheckHeaderOnly();

  // Get time & date to a string of appropriate format
  GetBiosTime(&hour,&min,&sec);
  GetBiosDate(&month,&day,&year);
  year %= 100;
  sprintf(timedate,"%02d%02d%02d%02d%02d%02d",year,month,day,hour,min,sec);

  // Send data
  IF_ASCII(12);
  for(i=0;i<12; i++)
    SB(timedate[i]);
}
/* RESET/INITIALIZE SEND */
static void S2f19(void)
{
  BYTE ric, rac = RAC_OK;

  // Verifiy the format
  if (FV(FM_UBYTE) != 1)
    Secs2BaddataError();

  // Get the reset code
  ric = (BYTE) RB();

  // Perform the reset
  if (reset_disable)
    rac = RAC_DENIED;
  else
    reset_type = ric;

  // Send the acknowledge
  IF_UBYTE(1);
  SB(rac);
}
/* REMOTE COMMAND SEND */
static void S2f21(void)
{
  int i,count;
  BYTE cmdack = CMD_ACK;

  // Verify format
  count = FV(FM_UBYTE);

  if ((count > NUMBER_ENQUIRIES) || (count == 0))
    Secs2BaddataError();

  // Verify that all the commands exist
  for (i=0; i<count; i++)
    if ((enquire_list[i] = RB()) > number_cmd)
      cmdack = CMD_BADCMD;

  // If so, flop all the booleans
  if (cmdack == CMD_ACK)
    for (i=0; i<count; i++)
      *secs_cmdlist[enquire_list[i]] = !(*secs_cmdlist[enquire_list[i]]) ;

   // Respond
  IF_UBYTE(1);
  SB(cmdack);
}
/* LOOPBACK DIAGNOSTIC REQUEST */
static void S2f25(void)
{
  BYTE loopback[MAX_LOOPBACK];
  int stringlength,i;

  // Get the string length
  stringlength = FV(FM_BINARY);
  stringlength = MIN(stringlength,MAX_LOOPBACK);

  // Get the string
  for (i=0;i<stringlength;i++)
    loopback[i] = (BYTE) RB();

  // Send it back
  IF_BINARY(stringlength);
  for (i=0; i<stringlength; i++)
    SB(loopback[i]);
}
/* EQUIPMENT CONSTANT NAMELIST REQUEST */
static void S2f29(void)
{
  int i, count,itemcount, allentries = FALSE, temp;

  // Verify format
  count = FV(FM_LIST);

  if (count > NUMBER_ENQUIRIES)
    Secs2ToomuchdataError();

  // Read in all requests
  // If no request or any request has zero length, send all back
  if (!count)
    allentries = TRUE;
  else
    for (i=0; i<count; i++) {
      itemcount = FV(FM_UWORD);
      if (!itemcount)
        allentries = TRUE;
      enquire_list[i] = RW();
    }

  if (allentries) {
    IF_LIST(number_preset);
    for (i=0; i<number_preset; i++) {
      // Send data as per specs
      IF_LIST(6);
      IF_UWORD(1);
      SW(i);
      IF_ASCII(temp=strlen(secs_presetlist[i].text[language]));
      SA(secs_presetlist[i].text[language],temp);
      PrPutLowLim(i);
      PrPuthilim(i);
      PrPutDefault(i);
      if (secs_presetlist[i].units == UN_USEPRESET)
        Secs2bSendUnits(((PREREC *)secs_presetlist[i].value)->preset->units);
      else
        Secs2bSendUnits(secs_presetlist[i].units);
    }
  }
  else {
    IF_LIST(count);
    for (i=0; i<count; i++) {
      int thisentry;
      IF_LIST(6);
      IF_UWORD(1);
      SW(thisentry = enquire_list[i]);
      if (thisentry  < number_preset) {
        IF_ASCII(temp=strlen(secs_presetlist[thisentry].text[language]));
        SA(secs_presetlist[thisentry].text[language],temp);
        PrPutLowLim(i);
        PrPuthilim(i);
        PrPutDefault(i);
        if (secs_presetlist[i].units == UN_USEPRESET)
          Secs2bSendUnits(((PREREC *)secs_presetlist[i].value)->preset->units);
        else
          Secs2bSendUnits(secs_presetlist[i].units);
      }
      else {
        // The 1992 specs don't say what must happen if the requested id
        // is invalid, so, send null data for every item
        IF_ASCII(0);
        IF_BINARY(0);
        IF_BINARY(0);
        IF_BINARY(0);
        IF_ASCII(0);
      }
    }
  }
}
/* DATE AND TIME SET REQUEST */
static void S2f31()
{
  char timedate[13];
  int year,month,day, hour,min,sec, i;

  // Verify data
  if (FV(FM_ASCII) != 12)
    Secs2BaddataError();

  // Read in string
  for (i=0; i<12; i++)
    timedate[i] = (BYTE) RB();
  timedate[12] = '\0';

  // Get the time & date from the string
  sscanf(timedate,"%2d%2d%2d%2d%2d%2d", &year, &month, &day,
          &hour, &min, &sec);
  if (year > 89) year += 100;
    year += 1900;

  // Set it
  SetBiosTime( hour, min, sec);
  SetBiosDate( month, day, year);

  // Respond, always assume ok
  IF_BINARY(1);
  SB(TIME_ACK);

}
// List of all supported stream 2 functions
static PASSFUNC Stream2funcs[] = {
  { PR_PROG_ENQ, S2f1 },
  { PR_PROG_SEND, S2f3 },
  { PR_PROG_LOAD, S2f5 },
  { PR_PROG_RUN, S2f7 },
  { PR_SELDATA, S2f13 },
  { PR_SELCHANGE, S2f15 },
  { PR_GETDATE, S2f17 },
  { PR_RESET, S2f19 },
  { PR_REMCMD, S2f21 },
  { PR_LOOPBACK, S2f25 },
  { PR_SELSPEC, S2f29 },
  { PR_SETDATE, S2f31 }};
/*
* Dispatch the function
*/
void Stream2(int number)
{
  Secs2FuncDispatch(number, Stream2funcs);
}
/*
* Initialize for the stream
  *  Count preset specifiers
*  Count command specifiers
*/
void Stream2Init(BOOL power_up)
{
  BOOL done = FALSE;

  if (power_up) {
    number_preset = 0;
    number_cmd = 0;
    spl_func = 0;

    while (!done)
      if (secs_presetlist[++number_preset].text == 0)
        done = TRUE;

    done = FALSE;
    while (!done)
      if (secs_cmdlist[++number_cmd] == 0)
        done = TRUE;
  }
}