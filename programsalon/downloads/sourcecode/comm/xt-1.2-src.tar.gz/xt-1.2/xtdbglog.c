/*	xtdbglog.c -- debug logging module for XT
	This file uses 4-character tabstops
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <time.h>
#define NOREDEF 1	/* prevents xt.h from redefining fprint, fputc, fputs */
#include "xt.h"

#if LOG
static FILE *dfp;

void
dbglog()
{
	time_t todnow;

	time(&todnow);
	if (!access("xt.log",0) && (dfp=fopen("xt.log","w")))
		setbuf(dfp, NIL(char)),
		fprintf(dfp,(char*)asctime(localtime(&todnow)));
	return;
}

Fputc(c, stream)
register int c;
FILE *stream;
{
	if (!capture && dfp && c != '\r')
		fputc(c,dfp);
	return(fputc(c,stream));
}

Fputs(s, stream)
register char *s;
FILE *stream;
{
	if (!capture && dfp)
		fputs(s,dfp);
	return(fputs(s,stream));
}

Fprintf(stream, format, a, b, c, d, e, f, g)
FILE *stream;
char *format;
long a, b, c, d, e, f, g;
{
	if (!capture && dfp)
		fprintf(dfp,format,a,b,c,d,e,f,g);
	return(fprintf(stream,format,a,b,c,d,e,f,g));
}

#endif
