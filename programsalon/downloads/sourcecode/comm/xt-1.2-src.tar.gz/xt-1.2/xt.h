/*	xt.h -- header  file for XT
	This file uses 4-character tabstops
*/

/* Local preferences and modems */

/*	CAPTFILE
	This is the default name given to the capture buffer in terminal mode (and
	during script processing). You can always reset this while running the
	program.
*/
#define	CAPTFILE "capture.log"	/* Default capture file */

/*	LIBDIR
	This is the default name given to a directory where PHFILE, STARTUP, and
	any XT scripts might be found. XT will search for such files
		1st) in a path in a colon-separated list of directories in
			 XT_PATH, if such an environment variable exists,
		2nd) in the current directory,
		3rd) in your HOME directory, if HOME is an environment variable,
		4th) in LIBDIR.
*/
#define LIBDIR "/u/lib/xt"

/*	STARTUP
	This is the default name of the startup script for XT. If this file is
	found it will be executed immediately on XT startup.
*/
#define STARTUP ".xtrc"			/* XT Startup Script */

/* LOG
	If this manifest is set to 1, then whenever XT is run within a
	directory that contains a file called "xt.log", XT will append to
	that file a copy of all XT output, whether to the terminal "file" or
	to standard error. This can be useful for debugging scripts, coupled
	with the "debug" script command, which causes the lines of a script
	to be echoed to the terminal as they get executed. Since often such
	output passes up the terminal screen too quickly to read, the
	"xt.log" file provides a hard-copy of the XT session.

	No echoing to a "xt.log" file is done if XT is also capturing
	incoming text to a capture file. If no "xt.log" file exists in the
	current directory, then no such echoing is done regardless of whether
	LOG is here defined as 0 or 1.
*/
#define LOG	1
#if LOG && !NOREDEF
# define fprintf Fprintf
# define fputc Fputc
# define fputs Fputs
#endif

/* NOSHELL
	Set this to 1 to disallow shell escapes. Both the "!" and "$" mechanisms
	from the XT prompt, and the analogous SHELL and PIPE keywords in scripts,
	silently do nothing. However the standard output of backquoted shell
	commands can still be assigned to a script variable.
*/
#define NOSHELL	0

/* Local Unix peculiarities */

/* The type returned by signal() */
typedef void RETSIGTYPE;

/* The reader is kindly invited to leave the rest of this just as it is! */

#ifndef ulong
#define ulong unsigned long
#endif
#ifndef ushort
#define ushort unsigned short
#endif
#ifndef unchar
#define unchar unsigned char
#endif

#ifndef TRUE
# define TRUE	1
# define FALSE	0
#endif
#define SUCCESS	1
#define FAILURE	0

#define NEWMODE	0
#define SIGMODE	1
#define OLDMODE	2

#ifdef toupper
# undef toupper
# undef tolower
#endif

#define SM_BUFF	 256
#define LG_BUFF 2048
#define S		show(1,Msg)
#define S0(x)	show(0,x)
#define S1(x)	show(1,x)
#define S2(x)	show(2,x)
#define ENQ		0x5	/* ^E */

/*	I prefer this NIL macro to present a NIL pointer than most other
	variations that I have seen (eg, NULL, 0, or (cast) 0.
	Comme ci, comme ca. - larry gensch
*/
#ifndef NIL
# define	NIL(type)	(type *) 0
#endif

/* globals in three or more files */

extern int		CO, LI, my_escape, beep(), show_bindings();
extern short	capture, cismode;
extern char		captfile[], ddsname[], word[], hostname[],
				*wptr, line[], Msg[], *lptr, Name[], *getenv(), *unctrl();
extern unsigned	sleep();
extern unchar	BS, LK;
extern void		cls(), cur_on(), cur_off(), default_bindings(), do_script(),
				drawline(), exit(), free(), getline(), getword(), mode(),
				lc_word(), purge(), send_mbyte(), send_string(),
				sendbyte(), show(), show_abort(), ttgoto();
extern FILE		*tfp,			/* the local terminal */
				*openfile(), *QueryCreate();
extern struct	termio oldmode, newmode, sigmode;

typedef enum {
    ENDCHAR = 128,		/* Higher than any valid keyboard code */
    CAPTYES,
    CAPTEND,
    DIVCHAR,
    SCRPCHR,
    HLPCHAR,
    QUITCHR,
    EMITSTR,
    DOSCRPT,
    BADFUNC = 0
} bindfunc_t;

typedef struct bindstruct {
	int					bs_c;		/* Character prefix */
	int					bs_function;/* Function code */
	char				*bs_string;	/* String/script to emit */
	struct bindstruct	*bs_next;	/* Pointer to next entry */
} binding_t;

typedef struct {
	bindfunc_t	bf_function;/* Function code */
	char		*bf_name;	/* bind_function() name */
	char		*bf_string;	/* String/script assigned */
} bindstr_t;
