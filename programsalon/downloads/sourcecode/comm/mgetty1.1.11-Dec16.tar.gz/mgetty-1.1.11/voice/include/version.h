char *version_h = "$Revision: 1.1 $";
char *vgetty_version = "experimental test release 0.7.3 / 10Aug97";
