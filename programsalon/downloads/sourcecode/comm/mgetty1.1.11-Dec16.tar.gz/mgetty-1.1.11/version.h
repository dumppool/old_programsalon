char * mgetty_version = "experimental test release 1.1.11-Dec16";
