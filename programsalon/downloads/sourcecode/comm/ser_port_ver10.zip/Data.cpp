// Data.cpp : implementation file
//

#include "stdafx.h"
#include "ver10.h"
#include "Data.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CData

IMPLEMENT_DYNAMIC(CData, CRecordset)

CData::CData(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CData)
	m_Title = _T("");
	m_ISBN = _T("");
	m_Author = _T("");
	m_Year_Published = 0;
	m_Company_Name = _T("");
	m_Au_ID = 0;
	m_Author2 = _T("");
	m_Year_Born = 0;
	m_HardCover = _T("");
	m_PaperBack = _T("");
	m_BlackWhite = _T("");
	m_Color = _T("");
	m_Grade1 = _T("");
	m_Grade2 = _T("");
	m_Grade3 = _T("");
	m_Grade4 = _T("");
	m_PubID = 0;
	m_Name = _T("");
	m_Company_Name2 = _T("");
	m_Address = _T("");
	m_City = _T("");
	m_State = _T("");
	m_Zip = _T("");
	m_Telephone = _T("");
	m_Fax = _T("");
	m_Comments = _T("");
	m_ISBN2 = _T("");
	m_Au_ID2 = 0;
	m_Title2 = _T("");
	m_Year_Published2 = 0;
	m_ISBN3 = _T("");
	m_PubID2 = 0;
	m_Description = _T("");
	m_Notes = _T("");
	m_Subject = _T("");
	m_Comments2 = _T("");
	m_Price = _T("");
	m_Pages = 0;
	m_nFields = 38;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}


CString CData::GetDefaultConnect()
{
	return _T("ODBC;DSN=publish");
}

CString CData::GetDefaultSQL()
{
	return _T("[All Titles],[Authors],[COGS],[Publishers],[Title Author],[Titles]");
}

void CData::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CData)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[All Titles].[Title]"), m_Title);
	RFX_Text(pFX, _T("[All Titles].[ISBN]"), m_ISBN);
	RFX_Text(pFX, _T("[All Titles].[Author]"), m_Author);
	RFX_Int(pFX, _T("[All Titles].[Year Published]"), m_Year_Published);
	RFX_Text(pFX, _T("[All Titles].[Company Name]"), m_Company_Name);
	RFX_Long(pFX, _T("[Authors].[Au_ID]"), m_Au_ID);
	RFX_Text(pFX, _T("[Authors].[Author]"), m_Author2);
	RFX_Int(pFX, _T("[Year Born]"), m_Year_Born);
	RFX_Text(pFX, _T("[HardCover]"), m_HardCover);
	RFX_Text(pFX, _T("[PaperBack]"), m_PaperBack);
	RFX_Text(pFX, _T("[BlackWhite]"), m_BlackWhite);
	RFX_Text(pFX, _T("[Color]"), m_Color);
	RFX_Text(pFX, _T("[Grade1]"), m_Grade1);
	RFX_Text(pFX, _T("[Grade2]"), m_Grade2);
	RFX_Text(pFX, _T("[Grade3]"), m_Grade3);
	RFX_Text(pFX, _T("[Grade4]"), m_Grade4);
	RFX_Long(pFX, _T("[Publishers].[PubID]"), m_PubID);
	RFX_Text(pFX, _T("[Name]"), m_Name);
	RFX_Text(pFX, _T("[Publishers].[Company Name]"), m_Company_Name2);
	RFX_Text(pFX, _T("[Address]"), m_Address);
	RFX_Text(pFX, _T("[City]"), m_City);
	RFX_Text(pFX, _T("[State]"), m_State);
	RFX_Text(pFX, _T("[Zip]"), m_Zip);
	RFX_Text(pFX, _T("[Telephone]"), m_Telephone);
	RFX_Text(pFX, _T("[Fax]"), m_Fax);
	RFX_Text(pFX, _T("[Publishers].[Comments]"), m_Comments);
	RFX_Text(pFX, _T("[Title Author].[ISBN]"), m_ISBN2);
	RFX_Long(pFX, _T("[Title Author].[Au_ID]"), m_Au_ID2);
	RFX_Text(pFX, _T("[Titles].[Title]"), m_Title2);
	RFX_Int(pFX, _T("[Titles].[Year Published]"), m_Year_Published2);
	RFX_Text(pFX, _T("[Titles].[ISBN]"), m_ISBN3);
	RFX_Long(pFX, _T("[Titles].[PubID]"), m_PubID2);
	RFX_Text(pFX, _T("[Description]"), m_Description);
	RFX_Text(pFX, _T("[Notes]"), m_Notes);
	RFX_Text(pFX, _T("[Subject]"), m_Subject);
	RFX_Text(pFX, _T("[Titles].[Comments]"), m_Comments2);
	RFX_Text(pFX, _T("[Price]"), m_Price);
	RFX_Long(pFX, _T("[Pages]"), m_Pages);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CData diagnostics

#ifdef _DEBUG
void CData::AssertValid() const
{
	CRecordset::AssertValid();
}

void CData::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
