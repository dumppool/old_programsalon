#if !defined(AFX_DATA_H__98854745_EEE1_11D3_84B8_0080C866EAF1__INCLUDED_)
#define AFX_DATA_H__98854745_EEE1_11D3_84B8_0080C866EAF1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Data.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CData recordset

class CData : public CRecordset
{
public:
	CData(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CData)

// Field/Param Data
	//{{AFX_FIELD(CData, CRecordset)
	CString	m_Title;
	CString	m_ISBN;
	CString	m_Author;
	int		m_Year_Published;
	CString	m_Company_Name;
	long	m_Au_ID;
	CString	m_Author2;
	int		m_Year_Born;
	CString	m_HardCover;
	CString	m_PaperBack;
	CString	m_BlackWhite;
	CString	m_Color;
	CString	m_Grade1;
	CString	m_Grade2;
	CString	m_Grade3;
	CString	m_Grade4;
	long	m_PubID;
	CString	m_Name;
	CString	m_Company_Name2;
	CString	m_Address;
	CString	m_City;
	CString	m_State;
	CString	m_Zip;
	CString	m_Telephone;
	CString	m_Fax;
	CString	m_Comments;
	CString	m_ISBN2;
	long	m_Au_ID2;
	CString	m_Title2;
	int		m_Year_Published2;
	CString	m_ISBN3;
	long	m_PubID2;
	CString	m_Description;
	CString	m_Notes;
	CString	m_Subject;
	CString	m_Comments2;
	CString	m_Price;
	long	m_Pages;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CData)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATA_H__98854745_EEE1_11D3_84B8_0080C866EAF1__INCLUDED_)
