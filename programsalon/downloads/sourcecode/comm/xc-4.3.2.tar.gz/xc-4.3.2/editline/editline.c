/*
**
**  Main editing routines for editline library.
*/
#include <ctype.h>
#include "editline.h"
#include "edlproto.h"

/*
**  Manifest constants.
*/

#define SCREEN_WIDTH	80
#define SCREEN_ROWS	24
#define NO_ARG		(-1)
#define DEL		127
#define CTL(x)		((x) & 0x1F)
#define ISCTL(x)	((x) && (x) < ' ')
#define UNCTL(x)	((x) + 64)
#define META(x)		((x) | 0x80)
#ifdef NOMETA
#define ISMETA(x)	((x) & 0x80)
#else
#define ISMETA(x)	(0)	
#endif
#define UNMETA(x)	((x) & 0x7F)
#if	!defined(HIST_SIZE)
#define HIST_SIZE	20
#endif	/* !defined(HIST_SIZE) */

/*
**  Key to command mapping.
*/
typedef struct _KEYMAP {
    CHAR	Key;
    STATUS	(*Func) (void);
} KEYMAP;

static KEYMAP MetaMap[16] ;
static KEYMAP Map[33] ; 

/*
**  Command history structure.
*/
typedef struct _HISTORY {
    int		Size;
    int		Pos;
    CHAR	*Lines[HIST_SIZE];
} HISTORY;

/*
**  Globals.
*/
int		rl_eof;
int		rl_erase;
int		rl_intr;
int		rl_kill;

static CHAR		NIL[] = "";
static CHAR		*Input = NIL;
static CHAR		*Line = NULL ;
static const CHAR 	*Prompt;
static CHAR		*Yanked;
char		*Screen;
static char	NEWLINE[]= CRLF;
/* static char	NEWLINE[]= "\r"; */
static HISTORY		H;
int		rl_quit;
static int		Repeat;
static int		End;
static int		Mark;
static int		OldPoint;
static int		Point;
static int		PushBack;
static int		Pushed;
static SIZE_T	Length;
static SIZE_T	ScreenCount;
SIZE_T			ScreenSize;
static char		*backspace = NULL ;
static int		TTYwidth;
static int		TTYrows;

/* Display print 8-bit chars as `M-x' or as the actual 8-bit char? */
#ifdef NOMETA
static int		rl_meta_chars = 0 ;
#endif

/*
**  Declarations.
*/
#ifdef __MSDOS__
static int 	getakey( CHAR *chr );
#endif

#ifndef __STDC__
static CHAR	*editinput();
extern int	read();
extern int	write();
#endif

#if 0
extern char	*getenv();
extern char	*tgetstr(char * , char ** );
extern int	tgetent( char * , char *);
extern int	tgetnum( char * ); 
#endif	/* defined(USE_TERMCAP) */

/*
**  TTY input/output functions.
*/

void
TTYflush( void )
{
    if (ScreenCount) {
	(void)write(1, Screen, ScreenCount);
	ScreenCount = 0;
    }
}

static void
TTYput( const CHAR c )
{
    Screen[ScreenCount] = c;
    if (++ScreenCount >= ScreenSize - 1) {
	ScreenSize += SCREEN_INC;
	RENEW(Screen, char, ScreenSize);
    }
}

static void
TTYputs( const CHAR *p ) 
{
    while (*p)
	TTYput(*p++);
	fflush(stdout);
}

static void
TTYshow( CHAR	c )
{
    if (c == DEL) {
	TTYput('^');
	TTYput('?');
    }
    else if (ISCTL(c)) {
	TTYput('^');
	TTYput(UNCTL(c));
    }
#ifdef NOMETA
    else if (rl_meta_chars && ISMETA(c)) {
	TTYput('M');
	TTYput('-');
	TTYput(UNMETA(c));
    }
#endif
    else
	TTYput(c);
}

static void
TTYstring( CHAR	*p ) 
{
    while (*p)
	TTYshow(*p++);
}

static UNSI 
TTYget( void )
{
    CHAR 	c;

    TTYflush();
    if (Pushed) {
	Pushed = 0;
	return PushBack;
    }
    if (*Input)
	return *Input++;
#ifndef __MSDOS__
    return  read(0, &c, (SIZE_T)1) == 1 ? c : EOF  ;
#else
    return  getakey( &c ) == 1 ? c : EOF  ;
#endif
}

#define TTYback() ((backspace != NULL) ? TTYputs((CHAR *)backspace) : TTYput('\b'))

static void
TTYbackn( int n)
{
    while (--n >= 0)
	TTYback();
}

static void
TTYinfo( void )
{
    static int		init;
#if	defined(USE_TERMCAP)
    const char		*term;
    static char		buff[2048];  /* !!!!! */
    char		*bp;
#endif	/* defined(USE_TERMCAP) */
#if	defined(TIOCGWINSZ)
    struct winsize	W;
#endif	/* defined(TIOCGWINSZ) */

    if (init) {
#if	defined(TIOCGWINSZ)
	/* Perhaps we got resized. */
	if (ioctl(0, TIOCGWINSZ, &W) >= 0
	 && W.ws_col > 0 && W.ws_row > 0) {
	    TTYwidth = (int)W.ws_col;
	    TTYrows = (int)W.ws_row;
	}
#endif	/* defined(TIOCGWINSZ) */
	return;
    }
    init++;

    TTYwidth = TTYrows = 0;
#if	defined(USE_TERMCAP)
    bp = &buff[0];
    if ((term = getenv("TERM")) == NULL)
	term = "dumb";
    if (tgetent(buff, term) < 0) {
       TTYwidth = SCREEN_WIDTH;
       TTYrows = SCREEN_ROWS;
       return;
    }
    backspace = tgetstr("le", &bp);
    TTYwidth = tgetnum("co");
    TTYrows = tgetnum("li");
#endif	/* defined(USE_TERMCAP) */

#if	defined(TIOCGWINSZ)
    if (ioctl(0, TIOCGWINSZ, &W) >= 0) {
	TTYwidth = (int)W.ws_col;
	TTYrows = (int)W.ws_row;
    }
#endif	/* defined(TIOCGWINSZ) */

    if (TTYwidth <= 0 || TTYrows <= 0) {
	TTYwidth = SCREEN_WIDTH;
	TTYrows = SCREEN_ROWS;
    }
}


/*
**  Print an array of words in columns.
*/
void
columns( int ac, CHAR **av)
{
    CHAR	*p;
    int		i;
    int		j;
    int		k;
    int		len;
    int		skip;
    int		longest;
    int		cols;

    /* Find longest name, determine column count from that. */
    for (longest = 0, i = 0; i < ac; i++)
	if ((j = strlen((char *)av[i])) > longest)
	    longest = j;
    cols = TTYwidth / (longest + 3);

    TTYputs((CHAR *)NEWLINE);
    for (skip = ac / cols + 1, i = 0; i < skip; i++) {
	for (j = i; j < ac; j += skip) {
 	    for (p = av[j], len = strlen((char *)p), k = len-1; k >= 0; k--, p++)
		TTYput(*p);
	    if (j + skip < ac)
		while (++len < longest + 3)
		    TTYput(' ');
	}
	TTYputs((CHAR *)NEWLINE);
    }
}

static void
reposition(void)
{
    int		i;
    CHAR	*p;

    TTYput('\r');
    TTYputs(Prompt);
    for (i = Point - 1, p = Line; i >= 0; i--, p++)
	TTYshow(*p);
}

static void
left( STATUS Change)
{
    TTYback();
    if (Point) {
	if (ISCTL(Line[Point - 1]))
	    TTYback();
#ifdef NOMETA     
   		else if (rl_meta_chars && ISMETA(Line[Point - 1])) {
	    TTYback();
	    TTYback();
	}
#endif
    }
    if (Change == CSmove)
	Point--;
}

static void
right( STATUS	Change )
{
    TTYshow(Line[Point]);
    if (Change == CSmove)
	Point++;
}

static STATUS
ring_bell( void )
{


    TTYput('\07');
    TTYflush();
	 
    return CSstay;
}

static STATUS
do_macro( unsigned int	c)
{
    CHAR		name[4];

    name[0] = '_';
    name[1] = c;
    name[2] = '_';
    name[3] = '\0';

    if ((Input = (CHAR *)getenv((char *)name)) == NULL) {
	Input = NIL;
	return ring_bell();
    }
    return CSstay;
}

static STATUS
do_forward( STATUS move )
{
    int		i;
    CHAR	*p;

    i = 0;
    do {
	p = &Line[Point];
	for ( ; Point < End && (*p == ' ' || !isalnum(*p)); Point++, p++)
	    if (move == CSmove)
		right(CSstay);

	for (; Point < End && isalnum(*p); Point++, p++)
	    if (move == CSmove)
		right(CSstay);

	if (Point == End)
	    break;
    } while (++i < Repeat);

    return CSstay;
}

static STATUS
do_case( CASE type)
{
    int		i;
    int		end;
    int		count;
    CHAR	*p;

    (void)do_forward(CSstay);
    if (OldPoint != Point) {
	if ((count = Point - OldPoint) < 0)
	    count = -count;
	Point = OldPoint;
	if ((end = Point + count) > End)
	    end = End;
	for (i = Point, p = &Line[i]; i < end; i++, p++) {
	    if (type == TOupper) {
		if (islower(*p))
		    *p = toupper(*p);
	    }
	    else if (isupper(*p))
		*p = tolower(*p);
	    right(CSmove);
	}
    }
    return CSstay;
}

static STATUS
case_down_word( void )
{
    return do_case(TOlower);
}

static STATUS
case_up_word( void )
{
    return do_case(TOupper);
}

static void
ceol( void )
{
    int		extras;
    int		i;
    CHAR	*p;

    for (extras = 0, i = Point, p = &Line[i]; i <= End; i++, p++) {
	TTYput(' ');
	if (ISCTL(*p)) {
	    TTYput(' ');
	    extras++;
	}
#ifdef NOMETA
	else if (rl_meta_chars && ISMETA(*p)) {
	    TTYput(' ');
	    TTYput(' ');
	    extras += 2;
	}
#endif
    }

    for (i += extras; i > Point; i--)
	TTYback();
}

static void
clear_line( void )
{
    Point = ( 0 - strlen(Prompt) ); 
    TTYput('\r');
    ceol();
    Point = 0;
    End = 0;
    Line[0] = '\0';
}

static STATUS
insert_string( CHAR *p )
{
    SIZE_T	len;
    int		i;
    CHAR	*new;
    CHAR	*q;

    len = strlen((char *)p);
    if (End + len >= Length) {
	if ((new = NEW(CHAR, Length + len + MEM_INC)) == NULL)
	    return CSstay;
	if (Length) {
	    COPYFROMTO(new, Line, Length);
	    DISPOSE(Line);
	}
	Line = new;
	Length += len + MEM_INC;
    }

    for (q = &Line[Point], i = (End - Point) - 1 ; i >= 0; i-- )
	q[len + i] = q[i];
    COPYFROMTO(&Line[Point], p, len);
    End += len;
    Line[End] = '\0';
    TTYstring(&Line[Point]);
    Point += len;

    if( Point == End )
      return CSstay ;
    else 
      return CSmove;
}


static CHAR *
next_hist( void )
{
    return H.Pos >= H.Size - 1 ? NULL : H.Lines[++H.Pos];
}

static CHAR *
prev_hist( void )
{
    return H.Pos == 0 ? NULL : H.Lines[--H.Pos];
}

static STATUS
do_insert_hist(CHAR *p)
{
    if (p == NULL)
	return ring_bell();
    Point = 0;
    reposition();
    ceol();
    End = 0;
    return insert_string(p);
}

static STATUS
do_hist( CHAR	*(*move)(void) )
{
    CHAR	*p;
    int		i;

    i = 0;
    do {
	if ((p = (*move)()) == NULL)
	    return ring_bell();
    } while (++i < Repeat);
    return do_insert_hist(p);
}

static STATUS
h_next(void)
{
    return do_hist(next_hist);
}

static STATUS
h_prev(void)
{
    return do_hist(prev_hist);
}

static STATUS
h_first(void)
{
    return do_insert_hist(H.Lines[H.Pos = 0]);
}

static STATUS
h_last(void)
{
    return do_insert_hist(H.Lines[H.Pos = H.Size - 1]);
}

/*
**  Return zero if pat appears as a substring in text.
*/
static int
substrcmp(const char *text, const char *pat, SIZE_T len)
{
    CHAR	c;

    if ((c = *pat) == '\0')
        return *text == '\0';
    for ( ; *text; text++)
        if ((CHAR) *text == c && strncmp(text, pat, len) == 0)
            return 0;
    return 1;
}

static CHAR *
search_hist( CHAR *search, CHAR *(*move)(void) )
{
    static CHAR	*old_search;
    int		len;
    int		pos;
    int		(*match)(const char *, const char *, SIZE_T );
    char	*pat;

    /* Save or get remembered search pattern. */
    if (search && *search) {
	if (old_search)
	    DISPOSE(old_search);
	old_search = (CHAR *) strdup( (char *) search );
    }
    else {
	if (old_search == NULL || *old_search == '\0')
            return NULL;
	search = old_search;
    }

    /* Set up pattern-finder. */
    if (*search == '^') {
	match = strncmp;
	pat = (char *)(search + 1);
    }
    else {
	match = substrcmp;
	pat = (char *)search;
    }
    len = strlen(pat);

    for (pos = H.Pos; (*move)() != NULL; )
	if ((*match)((char *)H.Lines[H.Pos], pat, len) == 0)
            return H.Lines[H.Pos];
    H.Pos = pos;
    return NULL;
}

static STATUS
h_search( void )
{
    static int	Searching;
    const CHAR	*old_prompt;
    CHAR	*(*move)(void);
    CHAR	*p;

    if (Searching)
	return ring_bell();
    Searching = 1;

    clear_line();
    old_prompt = Prompt;
    Prompt = "Search: ";
    TTYputs(Prompt);
    move = Repeat == NO_ARG ? prev_hist : next_hist;
    p = search_hist(editinput(), move);
    clear_line();
    Prompt = old_prompt;
    TTYputs(Prompt);

    Searching = 0;
    return do_insert_hist(p);
}

static STATUS
fd_char( void )
{
    int		i;

    i = 0;
    do {
	if (Point >= End)
	    break;
	right(CSmove);
    } while (++i < Repeat);
    return CSstay;
}

static void
save_yank( int begin, int i)
{
    if (Yanked) {
	DISPOSE(Yanked);
	Yanked = NULL;
    }

    if (i < 1)
	return;

    if ((Yanked = NEW(CHAR, (SIZE_T)i + 1)) != NULL) {
	COPYFROMTO(Yanked, &Line[begin], i);
	Yanked[i] = '\0';
    }
}

static STATUS
delete_string( int count)
{
    int		i;
    CHAR	*p;

    if (count <= 0 || End == Point)
	return ring_bell();

    if (count == 1 && Point == End - 1) {
	/* Optimize common case of delete at end of line. */
	End--;
	p = &Line[Point];
	i = 1;
	TTYput(' ');
	if (ISCTL(*p)) {
	    i = 2;
	    TTYput(' ');
	}
#ifdef NOMETA
	else if (rl_meta_chars && ISMETA(*p)) {
	    i = 3;
	    TTYput(' ');
	    TTYput(' ');
	}
#endif
	TTYbackn(i);
	*p = '\0';
	return CSmove;
    }
    if (Point + count > End && (count = End - Point) <= 0)
	return CSstay;

    if (count > 1)
	save_yank(Point, count);

    for (p = &Line[Point], i = End - (Point + count) ; i >= 0; i--, p++)
	p[0] = p[count];
    ceol();
    End -= count;
    TTYstring(&Line[Point]);
    return CSmove;
}

static STATUS
bk_char( void )
{
    int		i;

    i = 0;
    do {
	if (Point == 0)
	    break;
	left(CSmove);
    } while (++i < Repeat);

    return CSstay;
}

static STATUS
bk_del_char( void )
{
    int		i;

    i = 0;
    do {
	if (Point == 0)
	    break;
	left(CSmove);
    } while (++i < Repeat);

    return delete_string(i);
}

static STATUS
del_char(void)
{
    return delete_string(Repeat == NO_ARG ? 1 : Repeat);
}

static STATUS
redisplay(void)
{
    TTYputs((CHAR *)NEWLINE);
    TTYputs(Prompt);
    TTYstring(Line);
    return CSmove;
}

static STATUS
kill_line(void)
{
    int		i;

    if (Repeat != NO_ARG) {
	if (Repeat < Point) {
	    i = Point;
	    Point = Repeat;
	    reposition();
	    (void)delete_string(i - Point);
	}
	else if (Repeat > Point) {
	    right(CSmove);
	    (void)delete_string(Repeat - Point - 1);
	}
	return CSmove;
    }

    save_yank(Point, End - Point);
    Line[Point] = '\0';
    ceol();
    End = Point;
    return CSstay;
}

static STATUS
insert_char(int c)
{
    STATUS	s;
   static CHAR	buff[2];
    CHAR	*p;
    CHAR	*q;
    int		i;

    if (Repeat == NO_ARG || Repeat < 2) {
	buff[0] = c;
	buff[1] = '\0';
	return insert_string(buff);
    }

    if ((p = NEW(CHAR, Repeat + 1)) == NULL)
	return CSstay;
    for (i = Repeat-1, q = p; i >= 0; i-- )
	*q++ = c;
    *q = '\0';
    Repeat = 0;
    s = insert_string(p);
    DISPOSE(p);
    return s;
}

static STATUS
meta(void)
{
    UNSI        	c;
    KEYMAP		*kp;

    if ((c = TTYget()) == EOF)
	return CSeof;
#if	defined(ANSI_ARROWS)
    /* Also include VT-100 arrows. */
        if (c == '[' || c == 'O')
	switch (c = TTYget()) {
	default:	return ring_bell();
	case EOF:	return CSeof;
    case KUP:   return h_prev(); /* ansi arrow keys */
    case KDN:   return h_next();
    case KRT:   return fd_char();
    case KLT:   return bk_char();
#if 0
    case KCE:   strcpy ( (char *) Line, "N");   /* center of keypad */
		return CSdone;		
#endif
    case KF1:   strcpy ( (char *) Line, "help"); /* vt100 function keys f1 */
                return CSdone;
#if 0
    case KF2:   strcpy ( (char *) Line, "tag help"); /* f2 */
                return CSdone;
    case KF3:   strcpy ( (char *) Line, "tag list"); /* f3 */
                return CSdone;
    case KF4:   strcpy ( (char *) Line, "qlist");    /* f4 */
		return CSdone;
    case KF5: 	strcpy ( (char *) Line, "show terms");/* f5 */
 		return CSdone;
    case KF0: 	strcpy ( (char *) Line, "next");     /* f10 */
 		return CSdone;	
#endif
#ifndef linux
    case KPU:   strcpy ( (char *) Line, "-");   /* page up */
                return CSdone;
    case KPD:   strcpy ( (char *) Line, "+");   /* page down */
                return CSdone;
    case KHM:   strcpy ( (char *) Line, "1");   /* home */
                return CSdone;
    case KEN:   strcpy ( (char *) Line, "last");/* end  */
                return CSdone;
    case KIN:   return ring_bell();
    case KDL:   return  del_char(); 
#else  /* linux */ 
	case '2':   if ( ( c = TTYget() ) != '1')
					break;
		    if ( ( c = TTYget() ) != '~')
					break;
    		    strcpy ( (char *) Line, "next");    /* f10 */
					return CSdone;	
				return ring_bell();
	case '3':   if ( ( c = TTYget() ) != '\176') /* delete  */
					break;
				return  del_char();
	case '5':   if ( ( c = TTYget() ) != '\176') /* page up */
					break;
				strcpy (Line, "-");
				return CSdone;
	case '6':   if ( ( c = TTYget() ) != '\176') /* page down */
					break;
				strcpy (Line, "+");
				return CSdone;
	case '1':   if ( ( c = TTYget() ) != '\176') /* home */
					break;
	  			strcpy (Line, "1");   
				return CSdone;		
	case '4':   if ( ( c = TTYget() ) != '\176') /* end */
					break;
	  			strcpy (Line, "last");   
				return CSdone;		
        case '[':   switch ( c = TTYget() ) {   /* ansi function keys */
 				case 'A':   strcpy (Line, "help");       /* f1 */
							return CSdone;
				case 'B': 	strcpy (Line, "tag help");   /* f2 */
							return CSdone;
				case 'C': 	strcpy (Line, "tag list");   /* f3 */
							return CSdone;
				case 'D': 	strcpy (Line, "qlist");      /* f4 */
							return CSdone;
				case 'E': 	strcpy (Line, "show terms"); /* f5 */
							return CSdone;
				case 'J': 	strcpy (Line, "next");       /* f10 */
							return CSdone;
	            break ;
			}
#endif
}
#endif	/* defined(ANSI_ARROWS) */

    if (isdigit(c)) {
	for (Repeat = c - '0'; (c = TTYget()) != EOF && isdigit(c); )
	    Repeat = Repeat * 10 + c - '0';
	Pushed = 1;
	PushBack = c;
	return CSstay;
    }

    if (isupper(c))
	return do_macro(c);
    for (OldPoint = Point, kp = MetaMap; kp->Func; kp++)
	if (kp->Key == (CHAR) c)
	    return (*kp->Func)();

    return ring_bell();
}

static STATUS
emacs( unsigned int c)
{
    STATUS		s;
    KEYMAP		*kp;
#ifdef NOMETA
    if (ISMETA(c)) {
	Pushed = 1;
	PushBack = UNMETA(c);
	return meta();
    }
#endif
    for (kp = Map; kp->Func; kp++)
	if (kp->Key == c)
	    break;
    s = kp->Func ? (*kp->Func)() : insert_char((int)c);
    if (!Pushed)
	/* No pushback means no repeat count; hacky, but true. */
	Repeat = NO_ARG;
    return s;
}

static STATUS
TTYspecial( unsigned int c) 
{
#ifdef NOMETA
    if (ISMETA(c))
	return CSdispatch;
#endif
    if (c == (unsigned int) rl_erase || c == DEL)
	return bk_del_char();
    if (c == (unsigned int) rl_kill) {
	if (Point != 0) {
	    Point = 0;
	    reposition();
	}
	Repeat = NO_ARG;
	return kill_line();
    }
    if (c == (unsigned int) rl_intr || c == (unsigned int) rl_quit) {
	Point = End = 0;
	Line[0] = '\0';
	return redisplay();
    }
    if (c == (unsigned int) rl_eof && Point == 0 && End == 0)
	return CSeof;

    return CSdispatch;
}

static CHAR *
editinput(void)
{
    extern char *luxptr ;
    UNSI	c;

    Repeat = NO_ARG;
    OldPoint = Point = Mark = End = 0 ;
	Line[0] = '\0' ;
	if (luxptr != NULL ){ /* pre-load edit buffer with text */
		strcpy( (char *) Line, luxptr);
		End = strlen( (char *) Line);
		Point = End ;
    	reposition();
		Point = 0 ;
		reposition();
	}

    while ((c = TTYget()) != EOF)
	switch (TTYspecial(c)) {
	case CSdone:
	    return Line;
	case CSeof:
	    return NULL;
	case CSmove:
	    reposition();
	    break;
	case CSdispatch:
	    switch (emacs(c)) {
	    case CSdone:
		return Line;
	    case CSeof:
		return NULL;
	    case CSmove:
		reposition();
		break;
	    case CSdispatch:
	    case CSstay:
		break;
	    }
	    break;
	case CSstay:
	    break;
	}
    return NULL;
}

static void
hist_add( CHAR *p )
{
    int		i;

    if ((p = (CHAR *)strdup((char *)p)) == NULL)
	return;
    if (H.Size < HIST_SIZE)
	H.Lines[H.Size++] = p;
    else {
	DISPOSE(H.Lines[0]);
	for (i = 0; i < HIST_SIZE - 1; i++)
	    H.Lines[i] = H.Lines[i + 1];
	H.Lines[i] = p;
    }
    H.Pos = H.Size - 1;
}

/*
**  For compatibility with FSF readline.
*/
#if 0
/* ARGSUSED0 */
void
rl_reset_terminal( char *p )
{
}
#endif

char *
readline( char *prompt, int scrollflag)
{
    CHAR	*line_p;

    if (Line == NULL) {
	Length = MEM_INC;
	if ((Line = NEW(CHAR, Length)) == NULL)
	    return NULL;
    }

    TTYinfo();
    rl_ttyset(0);
    hist_add(NIL);
    ScreenSize = SCREEN_INC;
    Screen = NEW(char, ScreenSize);
    Prompt = (CHAR *) (prompt != NULL ? prompt : (char *) NIL ) ; 
    TTYputs(Prompt);
    line_p = editinput();
    if ( line_p != NULL  ) {
	line_p = (CHAR *)strdup((char *)line_p);
	if(scrollflag)
	TTYputs((CHAR *)NEWLINE);
	else
	TTYputs("\r");
      	TTYflush();   
    } 
    rl_ttyset(1);
    DISPOSE(Screen);
    DISPOSE(H.Lines[--H.Size]);
    return (char *)line_p;
}

void
add_history( char *p)
{
    if (p == NULL || *p == '\0')
	return;

#if	defined(UNIQUE_HISTORY)
    if (H.Pos && strcmp(p, (char *) (H.Lines[H.Pos - 1]) ) == 0)
        return;
#endif	/* defined(UNIQUE_HISTORY) */
    hist_add((CHAR *)p);
}


static STATUS
beg_line(void)
{
    if (Point) {
	Point = 0;
	return CSmove;
    }
    return CSstay;
}

static STATUS
end_line(void)
{
    if (Point != End) {
	Point = End;
	return CSmove;
    }
    return CSstay;
}

/*
**  Move back to the beginning of the current word and return an
**  allocated copy of it.
*/
static CHAR *
find_word(void)
{
    static char	SEPS[] = "#;&|^$=`'{}()<>\n\t ";
    CHAR	*p;
    CHAR	*new;
    SIZE_T	len;

    for (p = &Line[Point]; p > Line && strchr(SEPS, (char)p[-1]) == NULL; p--)
	continue;
    len = (Point - (p - Line)) + 1;
    if ((new = NEW(CHAR, (len+3)) ) == NULL) /* we add 3 for wild cards used by ms-dos */
	return NULL;
    COPYFROMTO(new, p, len); 
    new[len - 1] = '\0';
    return new;
}

static STATUS
c_complete(void)
{
    CHAR	*p;
    CHAR	*word_p;
    int		unique;
    STATUS	s;

    word_p = find_word();
    p = (CHAR *)rl_complete((char *)word_p, &unique);
    if (word_p)
	DISPOSE(word_p);
    if (p && *p) {
	s = insert_string(p);
	if (!unique)
	    (void)ring_bell();
	DISPOSE(p);
	return s;
    }
    return ring_bell();
}

static STATUS
c_possible(void)
{
    CHAR	**av;
    CHAR	*word_p;
    int		ac;

    word_p = find_word();
    ac = rl_list_possib((char *)word_p, (char ***)&av);
    if (word_p)
	DISPOSE(word_p);
    if (ac) {
	columns(ac, av);
	while (--ac >= 0)
	    DISPOSE(av[ac]);
	DISPOSE(av);
	return CSmove;
    }
    return ring_bell();
}

static STATUS
accept_line(void)
{
    Line[End] = '\0'; 
    return CSdone;
}

static STATUS
transpose(void)
{
    CHAR	c;

    if (Point) {
	if (Point == End)
	    left(CSmove);
	c = Line[Point - 1];
	left(CSstay);
	Line[Point - 1] = Line[Point];
	TTYshow(Line[Point - 1]);
	Line[Point++] = c;
	TTYshow(c);
    }
    return CSstay;
}

static STATUS
quote(void)
{
    UNSI    c;

    c = TTYget() ;

    if( c == EOF )
      return  CSeof;
    else
      return  insert_char((int)c );
}

static STATUS
wipe(void)
{
    int		i;

    if (Mark > End)
	return ring_bell();

    if (Point > Mark) {
	i = Point;
	Point = Mark;
	Mark = i;
	reposition();
    }

    return delete_string(Mark - Point);
}

static STATUS
mk_set(void)
{
    Mark = Point;
    return CSstay;
}

static STATUS
exchange(void)
{
    UNSI	c;

    if ((c = TTYget()) != CTL('X')){
        if( c == EOF )
           return  CSeof ;
        else
           return  ring_bell();
    }

    if ((c = Mark) <= End) {
	Mark = Point;
	Point = c;
	return CSmove;
    }
    return CSstay;
}

static STATUS
yank(void)
{
    if (Yanked && *Yanked)
	return insert_string(Yanked);
    return CSstay;
}

static STATUS
copy_region(void)
{
    if (Mark > End)
	return ring_bell();

    if (Point > Mark)
	save_yank(Mark, Point - Mark);
    else
	save_yank(Point, Mark - Point);

    return CSstay;
}

static STATUS
move_to_char(void)
{
    UNSI 		c;
    int			i;
    CHAR		*p;

    if ((c = TTYget()) == EOF)
	return CSeof;
    for (i = Point + 1, p = &Line[i]; i < End; i++, p++)
	if (*p == (CHAR) c) {
	    Point = i;
	    return CSmove;
	}
    return CSstay;
}

static STATUS
fd_word(void)
{
    return do_forward(CSmove);
}

static STATUS
fd_kill_word(void)
{
    int		i;

    (void)do_forward(CSstay);
    if (OldPoint != Point) {
	i = Point - OldPoint;
	Point = OldPoint;
	return delete_string(i);
    }
    return CSstay;
}

static STATUS
bk_word(void)
{
    int		i;
    CHAR	*p;

    i = 0;
    do {
	for (p = &Line[Point]; p > Line && !isalnum(p[-1]); p--)
	    left(CSmove);

	for (; p > Line && p[-1] != ' ' && isalnum(p[-1]); p--)
	    left(CSmove);

	if (Point == 0)
	    break;
    } while (++i < Repeat);

    return CSstay;
}

static STATUS
bk_kill_word(void)
{
    (void)bk_word();
    if (OldPoint != Point)
	return delete_string(OldPoint - Point);
    return CSstay;
}

static int
argify( CHAR *line_p, CHAR ***avp )
{
    CHAR	*c;
    CHAR	**p;
    CHAR	**new;
    int		ac;
    int		i;

    i = MEM_INC;
    if ((*avp = p = NEW(CHAR*, i))== NULL)
	 return 0;

    for (c = line_p; isspace(*c); c++)
	continue;
    if (*c == '\n' || *c == '\0')
	return 0;

    for (ac = 0, p[ac++] = c; *c && *c != '\n'; ) {
	if (isspace(*c)) {
	    *c++ = '\0';
	    if (*c && *c != '\n') {
		if (ac + 1 == i) {
		    new = NEW(CHAR*, i + MEM_INC);
		    if (new == NULL) {
			p[ac] = NULL;
			return ac;
		    }
		    COPYFROMTO(new, p, i * sizeof (char **));
		    i += MEM_INC;
		    DISPOSE(p);
		    *avp = p = new;
		}
		p[ac++] = c;
	    }
	}
	else
	    c++;
    }
    *c = '\0';
    p[ac] = NULL;
    return ac;
}

static STATUS
last_argument(void)
{
    CHAR	**av;
    CHAR	*p;
    STATUS	s;
    int		ac;

    if (H.Size == 1 || (p = H.Lines[H.Size - 2]) == NULL)
	return ring_bell();

    if ((p = (CHAR *)strdup((char *)p)) == NULL)
	return CSstay;
    ac = argify(p, &av);

    if (Repeat != NO_ARG)
	s = Repeat < ac ? insert_string(av[Repeat]) : ring_bell();
    else
	s = ac ? insert_string(av[ac - 1]) : CSstay;

    if (ac)
	DISPOSE(av);
    DISPOSE(p);
    return s;
}


#ifdef __MSDOS__
static int
getakey( CHAR *chr ) {

	static int pushed = 0 ;
	static CHAR c = 0 ;
	int t ;

	if( pushed > 1  ) {
		pushed--  ;
       *chr = '[' ;
        return 1  ;
	}
	if ( pushed ) {
		pushed = 0 ;
       *chr = c ;
        return 1 ;
	} 

    t = getch() ;
#if ( defined(DJD) && !defined(OS2) )
    if( t < 256 ) {
       *chr = (CHAR) t ;
        return 1 ;
    }
    switch( t>>8 )  {
#else
    if( t ) {
        *chr = (CHAR) t ;
        return 1 ;
    }
    t = getch();
    switch( t ) {
#endif

	case 0x3b: c = KF1 ; break ;
	case 0x3c: c = KF2 ; break ;
	case 0x3d: c = KF3 ; break ;
	case 0x3e: c = KF4 ; break ;
	case 0x3f: c = KF5 ; break ;
	case 0x40: c = KF6 ; break ;
	case 0x41: c = KF7 ; break ;
	case 0x42: c = KF8 ; break ;
	case 0x43: c = KF9 ; break ;
	case 0x44: c = KF0 ; break ;
	case 0x47: c = KHM ; break ;
	case 0x48: c = KUP ; break ;
	case 0x49: c = KPU ; break ;
	case 0x4b: c = KLT ; break ;
	case 0x4c: c = KCE ; break ;
	case 0x4d: c = KRT ; break ;
	case 0x4f: c = KEN ; break ;
	case 0x50: c = KDN ; break ;
  	case 0x51: c = KPD ; break ;
  	case 0x52: c = KIN ; break ;
	case 0x53: c = KDL ; break ;
    default: c = 0 ;
}
if ( c ) {
   pushed = 2 ;
  *chr = ESC ;
   return 1 ;
} else
   return 0 ;
}
#endif  

void
rl_initialize(void)
{
MetaMap[0].Key = CTL('H') ; MetaMap[0].Func = bk_kill_word ;
MetaMap[1].Key = DEL	; MetaMap[1].Func = bk_kill_word ;
MetaMap[2].Key = ' '	; MetaMap[2].Func = mk_set ;
MetaMap[3].Key = '.'	; MetaMap[3].Func = last_argument ;
MetaMap[4].Key = '<'	; MetaMap[4].Func = h_first ;
MetaMap[5].Key = '>'	; MetaMap[5].Func = h_last ;
MetaMap[6].Key = '?'	; MetaMap[6].Func = c_possible ; 
MetaMap[7].Key = 'b'	; MetaMap[7].Func = bk_word ; 
MetaMap[8].Key = 'd'	; MetaMap[8].Func = fd_kill_word ;
MetaMap[9].Key = 'f'	; MetaMap[9].Func = fd_word ;
MetaMap[10].Key = 'l'	; MetaMap[10].Func = case_down_word ;
MetaMap[11].Key = 'u'	; MetaMap[11].Func = case_up_word ;
MetaMap[12].Key = 'y'	; MetaMap[12].Func = yank ;
MetaMap[13].Key = 'w'	; MetaMap[13].Func = copy_region ;
MetaMap[14].Key = '\0'	; MetaMap[14].Func = NULL ;

Map[0].Key =  CTL('@');	Map[0].Func = ring_bell	;
Map[1].Key =  CTL('A');	Map[1].Func = beg_line	;
Map[2].Key =  CTL('B');	Map[2].Func = bk_char	;
Map[3].Key =  CTL('D');	Map[3].Func = del_char	;
Map[4].Key =  CTL('E');	Map[4].Func = end_line	;
Map[5].Key =  CTL('F');	Map[5].Func = fd_char	;
Map[6].Key =  CTL('G');	Map[6].Func = ring_bell	;
Map[7].Key =  CTL('H');	Map[7].Func = bk_del_char;
Map[8].Key =  CTL('I');	Map[8].Func = c_complete;
Map[9].Key =  CTL('J');	Map[9].Func = accept_line;
Map[10].Key = CTL('K');	Map[10].Func = kill_line;
Map[11].Key = CTL('L');	Map[11].Func = redisplay;
Map[12].Key = CTL('M');	Map[12].Func = accept_line;
Map[13].Key = CTL('N');	Map[13].Func = h_next	;
Map[14].Key = CTL('O');	Map[14].Func = ring_bell;
Map[15].Key = CTL('P');	Map[15].Func = h_prev	;
Map[16].Key = CTL('Q');	Map[16].Func = ring_bell;
Map[17].Key = CTL('R');	Map[17].Func = h_search	;
Map[18].Key = CTL('S');	Map[18].Func = ring_bell;
Map[19].Key = CTL('T');	Map[19].Func = transpose;
Map[20].Key = CTL('U');	Map[20].Func = ring_bell;
Map[21].Key = CTL('V');	Map[21].Func = quote ;
Map[22].Key = CTL('W');	Map[22].Func = wipe	;
Map[23].Key = CTL('X');	Map[23].Func = exchange	;
Map[24].Key = CTL('Y');	Map[24].Func = yank	;
Map[25].Key = CTL('Z');	Map[25].Func = ring_bell;
Map[26].Key = CTL('[');	Map[26].Func = meta	;
Map[27].Key = CTL(']');	Map[27].Func = move_to_char;
Map[28].Key = CTL('^');	Map[28].Func = ring_bell;
Map[29].Key = CTL('_');	Map[29].Func = ring_bell;
Map[30].Key = '\0'    ;	Map[30].Func =	NULL;
}
