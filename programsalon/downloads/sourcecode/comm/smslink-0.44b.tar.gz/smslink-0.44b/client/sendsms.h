/*==========================================================
 * Program : sendsms.h                     Project : smslink
 * Author  : Philippe Andersson.
 * Date    : 23/10/98
 * Version : 0.03b
 * Notice  : (c) Les Ateliers du Heron, 1998 for Scitex Europe, S.A.
 * Comment : Main include file for sms client.
 *
 * Modification History :
 * - 0.01a (28/09/98) : Initial release.
 * - 0.02a (21/10/98) : Added BIGBUFF define.
 * ++++ Switched to Beta ++++
 * - 0.03b (23/10/98) : Added MAXUIDLEN define.
 *========================================================*/

#ifndef _SENDSMS_H
#define _SENDSMS_H

/* Program information */
#define SMS_CLI_VERSION		"0.10b"
#define SMS_CLI_DATE		"01/03/00"
#define SERVPROMPT		"SMS> "

/* Buffer handling */
#define BUFFSIZE		400
#define MINIBUFF		80		/* for hostname, for inst. */
#define BIGBUFF			1024

/* SMS Messages-related */
#define MAXPHNUMLEN		80		/* max length for phone num */
#define MAXMSGLEN		160		/* max msg length for SMS */
#define MAXUIDLEN		12		/* max length for sender ID */
#define DEFAULTSMSC		"075/16.16.16"	/* Proximus OK */
#define DEFSMSPORT		6701		/* port server listens to */

/* Can be usefull */
#define TRUE        1
#define FALSE       0

/*==========================================================
 * Structure Declarations
 *========================================================*/

/*==========================================================
 * Function Declarations
 *========================================================*/
/* --- in "?.c" --- */

#endif                              /* #ifndef _SENDSMS_H */

/*==========================================================
 * EOF : sendsms.h
 *===================*/
