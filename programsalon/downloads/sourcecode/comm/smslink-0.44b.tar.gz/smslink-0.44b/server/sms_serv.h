/*==========================================================
 * Program : sms_serv.h                    Project : smslink
 * Author  : Philippe Andersson.
 * Date    : 29/02/00
 * Version : 0.34b
 * Notice  : (c) Les Ateliers du Heron, 1998 for Scitex Europe, S.A.
 * Comment : Main include file for SMSLink server.
 *
 * Modification History :
 * - 0.01a (13/08/98) : Initial release.
 * - 0.02a (25/08/98) : Added section for logging facility and
 *   a function declarations section. Cosmetics.
 * - 0.10a (27/08/98) : Integration of the parser module into the
 *   main sms_serv program. Merged server.h into this file.
 *   Added code to prevent double inclusion. Cosmetics.
 * - 0.11a (01/09/98) : Increased BUFFSIZE from 200 to 400.
 * - 0.12a (27/09/98) : Added MINIBUFF define.
 * - 1.13a (19/10/98) : Added GSMDEVFILE define and function
 *   definitions for gsmdevices.c. Changed 'struct modem_def'
 *   to 'struct gsms_def' and added fields.
 * ++++ Switched to Beta ++++
 * - 0.14b (23/10/98) : Added 'user' member in 'symbols' struct
 *   and defined MAXUIDLEN.
 * - 0.15b (22/11/98) : Added MBCHKINTERVAL define.
 * - 0.16b (13/12/98) : Added member "owner" to struct gsms_def.
 * - 0.17b (06/02/99) : Added support for access control.
 *   Contributed by Philipp Klaus <pklaus@access.ch>.
 * - 0.18b (11/02/99) : Start rewriting of ACL support.
 * - 0.19b (14/02/99) : Declared public functions for new ACL
 *   implementation.
 * - 0.20b (28/06/99) : Added struct mbox_item to be used by
 *   mbcheck() and friends.
 * - 0.21b (29/06/99) : Moved 3 functions to stuff.c and made
 *   them public.
 * - 0.22b (03/07/99) : Added public definition for trim().
 * - 0.23b (11/07/99) : Added mailbox files definitions.
 * - 0.24b (17/08/99) : Added checkpoint file definition for
 *   interaction with the SMS to mail gateway.
 * - 0.25b (18/08/99) : Published mailgws_death().
 * - 0.26b (20/08/99) : Adapted structure after splitting
 *   stuff.c. Mostly cosmetic.
 * - 0.27b (25/08/99) : Added MAXRETRIES define, as well as
 *   version tracking for sms2mailgw.
 * - 0.28b (28/09/99) : Created struct email_msg and inbox_line,
 *   and exported mailbox_run(). Defined DEFAULTDOMAIN.
 * - 0.29b (17/10/99) : Added FIELD_HEADERS definition.
 * - 0.30b (20/10/99) : Added GWUSER definition.
 * - 0.31b (21/10/99) : Added MAILHOST definition. Moved tellsock()
 *   definition to stuff.c.
 * - 0.32b (09/11/99) : Added nicedate() declaration (exported by
 *   stuff.c).
 * - 0.33b (02/12/99) : Changed DEFAULTSMSC to a catch-all
 *   "default" value in order to improve its handling. See
 *   send_sms() in server.y. Added public export of empty_acl_list()
 *   to accessctrl.c (for "aclist" command).
 * - 0.34b (29/02/00) : Changed struct email_msg to replace recepients
 *   fields with linked lists for easier handling by send_mail().
 *========================================================*/

#ifndef _SMS_SERV_H
#define _SMS_SERV_H

/* Program information */
#define SMS_SERV_VERSION	"0.44b"
#define SMS_SERV_DATE		"25/02/00"
#define PROMPT			"SMS> "

/* GSM devices */
#define GSMDEVFILE		"/etc/gsmdevices"
#define PINLEN			4
#define PUKLEN			8
#define MAXATTEMPTS		4        	/* 3 wrong PIN's + 1 PUK */
#define CTRL_Z			"\x1A"		/* SM end marker */

/* access control (INA) */
#define ACCESSFILE		"/etc/gsmaccess"
#define MAXACLS			10000		/* precaution */
#define ACL_ALLOW		1
#define ACL_DENY		2

/* Buffer handling */
#define BUFFSIZE		400
#define MINIBUFF		80		/* for hostname, for inst. */
#define BIGBUFF			1024

/* SMS Messages-related */
#define MAXPHNUMLEN		80		/* max length for phone num */
#define MAXMSGLEN		160		/* max msg length for SMS */
#define DEFAULTSMSC		"default"	/* device-level default */
#define MAXUIDLEN		12		/* max length for sender ID */

/* For incoming messages handling */
#define MBCHKINTERVAL		3600		/* mailbox check interv.(sec)*/
#define MBOX_FILE		"/var/spool/smslink/inbox"
#define MBOX_LOCKF		"/var/spool/smslink/LCK..inbox"
#define CHECKPOINTF		"/var/spool/smslink/checkpoint"

/* For the SMS to Mail gateway */
#define SMS_GW_VERSION		"0.07b"
#define SMS_GW_DATE		"02/03/00"
#define MAXRETRIES		5		/* max tries to lock inbox */
#define MAILHOST		"localhost"	/* SMTP relay */
#define DEFAULTDOMAIN		"."             /* set to override server's */
#define GWUSER			"smsgw"		/* local user for mail deliv. */
#define FIELD_HEADERS		"TCRBFS"        /* supported field headers */

/* For the logging calls */
#include <syslog.h>
#define FACILITY		LOG_USER	/* default */

/* Local socket options */
#define MAXCLIENTCONN		5		/* max socket queue length */
#define MAXCHILDPROC		5		/* max child processes */

/* Semaphore-related parameters */
#define MAXMODEMS		2		/* max supported modem devs */
#define M_TIMEOUT		90		/* secs wait for free modem */
#define W_STEP			5		/* secs to sleep */

/* Modem-related parameters */
#define MAXDEVLEN		40		/* max. device name length */

/* Can be usefull */
#define TRUE        1
#define FALSE       0

/*==========================================================
 * Structure Declarations
 *========================================================*/
#include <unistd.h>                  /* for pid_t typedef */
#include <netinet/in.h>            /* for struct acl_item */

/* This  structure defines an outbound SMS message */
struct symbols {
  char *smsc;                           /* message center */
  char *destgsm;                       /* destination gsm */
  char *message;                          /* message text */
  char *user;                    /* sender identification */
};

/* This structure stores an incoming message */
struct mbox_item {
  int msgid;                       /* used for SIM access */
  char fromgsm[MAXPHNUMLEN + 1];     /* sender GSM number */
  char date[9];                        /* format YYYYMMDD */
  char time[10];                      /* format xxhyymzzs */
  char text[MAXMSGLEN + 1];
  struct mbox_item *next;
  struct mbox_item *prev;
};

typedef struct mbox_list_header {
  struct mbox_item *head;
  struct mbox_item *tail;
} mbox_list;

/* This defines a gsm device instance */
struct gsms_def {
  int free;                                 /* bool value */
  pid_t owner;                    /* pid of owner process */
  char device[MAXDEVLEN + 1];              /* device name */
  char PIN[PINLEN + 1];                       /* PIN code */
  char PUK[PUKLEN + 1];                       /* PUK code */
  char addr[MAXPHNUMLEN + 1];       /* SIM calling number */
  char defsca[MAXPHNUMLEN + 1]; /* def. Service Center Addr. */
  char provider[MAXDEVLEN + 1]; /* GSM Net. provider name */
};

/* structures for access control (ACL items) */
struct acl_item {
  int action;                          /* allow or reject */
  struct in_addr network;                /* network or IP */
  unsigned long nomask;                /* net. order mask */
  struct acl_item *next;
  struct acl_item *prev;
};

typedef struct acl_list_header {
  struct acl_item *head;
  struct acl_item *tail;
} acl_list;

/*--------------------------------------------------------*/
/* Structures for the SMS to Mail gateway */
struct rcpt_item {
  char *rcpt;
  struct rcpt_item *next;
  struct rcpt_item *prev;
};

typedef struct rcpt_list_header {
  struct rcpt_item *head;
  struct rcpt_item *tail;
} rcpt_list;

struct email_msg {
  char *from;
  rcpt_list to;
  rcpt_list cc;
  rcpt_list bcc;
  char *reply_to;
  char *subject;
  char *body;
};

struct inbox_line {
  char device[MAXDEVLEN + 1];          /* GSM device file */
  int msgid;                       /* used for SIM access */
  char fromgsm[MAXPHNUMLEN + 1];     /* sender GSM number */
  char date[9];                        /* format YYYYMMDD */
  char time[10];                      /* format xxhyymzzs */
  char text[MAXMSGLEN + 1];
};

/*==========================================================
 * Function Declarations
 *========================================================*/
/* --- in "stuff.c" --- */
int shiftleft (char*, int);
int dequote (char *);
int trim (char *);
int deslashdot (char *);
char *nicedate (char *);
void tellsock (int, char *);
void syserr (char *);
void fatal (char *);

/* --- in "serv_stuff.c" --- */
void daemons_death ();           /* main exit function for sms_serv */
int gsmdevcpy (struct gsms_def *, struct gsms_def *);
int tell_gsm (int, char *);
int get_gsm_answer (int, char *, int, int);
int set_semvalue (int, int);
int sem_wait (int);
int sem_decreq (int);
int sem_signal (int);

/* --- in "gw_stuff.c" --- */
void mailgws_death ();           /* main exit function for sms2mailgw */
int mailbox_run (char *, char*);

/* --- in "mbchecker.c" --- */
void mbcheck_wrapper (void);

/* --- in "accessctrl.c" --- */
int empty_acl_list (acl_list);
void acl_list_init (acl_list *);
void free_acl_list (acl_list *);
int read_acl (acl_list *);
int check_acl (struct in_addr *, acl_list);

/* --- in "gsmdevices.c" --- */
static int open_gsmdevs (void);
static void close_gsmdevs (void);
struct gsms_def *getgsmdevbynam (char *);
int getgsmdevscount (int);
void setgsmdevs (void);
struct gsms_def *getnextgsmdev (void);
static int demangle_gsmdev_entry (struct gsms_def *, char *);

/* --- in "server.y" --- */
int parser ();                           /* parser module */
int my_yyinput (char *, int);       /* new input for flex */

/* --- in "server.l" --- */
void yyerror (const char *);

#endif                             /* #ifndef _SMS_SERV_H */

/*==========================================================
 * EOF : sms_serv.h
 *===================*/
