/*==========================================================
 * Program : gsmdevices.c                  Project : smslink
 * Author  : Philippe Andersson.
 * Date    : 19/10/98
 * Version : 0.01a
 * Notice  : Shamelessly copied from Riccardo Facchetti's modems.c
 *           in libmodem-1.0.0 (c) 1997 Riccardo Facchetti under GNU GPL.
 *           (c) Les Ateliers du Heron, 1998 for Scitex Europe, S.A.
 * Comment : Handling routines for /etc/gsmdevices database.
 *
 * Modification History :
 * - 0.01a (13/08/98) : Initial release.
 *========================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

#include <dial/modems.h>
#include <dial/mdmerrno.h>
#include <termios.h>

#include "sms_serv.h"

#define BUFSIZE		128

static int gsmdeventry = 0;
static FILE *gsmdevfp;

/*========================================================*/
static int open_gsmdevs (void)
/*
 * open/close_gsmdevs: open and close the /etc/gsmdevices file
 */
{
    if ((gsmdevfp = fopen (GSMDEVFILE, "r")) == NULL)
        return FAILURE;
    return SUCCESS;
}                                      /* open_gsmdevs () */
/*========================================================*/
static void close_gsmdevs (void)
{
    fclose (gsmdevfp);
}                                     /* close_gsmdevs () */
/*========================================================*/
struct gsms_def *getgsmdevbynam (char *line)
/*
 * getgsmdevbynam: returns a pointer to the gsmdev entry named
 *            (char *) line, NULL if line is not present in
 *            /etc/gsmdevices.
 */
{
    static struct gsms_def mdm;
    char *buffer;

    buffer = mdmalloc(BUFSIZE);

    if (!buffer) {
	mdmerrno = -EMDMEM;
	return NULL;
    }

    mdmerrno = 0;

    if (open_gsmdevs() == FAILURE) {
	mdmfree (buffer);
        mdmerrno = -ENOMDMFILE;
        return NULL;
    }

    while (fgets (buffer, BUFSIZE, gsmdevfp) != NULL) {
        buffer[strlen (buffer) - 1] = '\0';

        if (buffer[0] == '#' || buffer[0] == '\0' || buffer[0] == '\n')
            continue;

        if (demangle_gsmdev_entry (&mdm, buffer) == FAILURE) {
            mdmerrno = -EMDMBADCONF;
            continue;
        }
        if (!strcmp (mdm.device, line)) {
            close_gsmdevs ();
	    mdmfree (buffer);
            return (&mdm);
        }
    }
    close_gsmdevs ();
    mdmerrno = -ENOMDMLINE;
    return NULL;
}                                    /* getgsmdevbynam () */
/*========================================================*/
int getgsmdevscount (int validation)
/*
 * getgsmdevscount: count the number of valid (?) entries in
 *            /etc/gsmdevices.
 */
{
    static struct gsms_def mdm;
    char *buffer;
    int nvalidentries = 0;

    buffer = mdmalloc(BUFSIZE);

    if (!buffer) {
	mdmerrno = -EMDMEM;
	return (0);
    }

    mdmerrno = 0;

    if (open_gsmdevs() == FAILURE) {
	mdmfree (buffer);
        mdmerrno = -ENOMDMFILE;
        return (0);
    }

    while (fgets (buffer, BUFSIZE, gsmdevfp) != NULL) {
        buffer[strlen (buffer) - 1] = '\0';

        if (buffer[0] == '#' || buffer[0] == '\0' || buffer[0] == '\n')
            continue;

        if (validation && (demangle_gsmdev_entry (&mdm, buffer) == FAILURE)) {
            mdmerrno = -EMDMBADCONF;
            continue;
        }
	nvalidentries++;
    }
    close_gsmdevs ();
    return (nvalidentries);
}                                   /* getgsmdevscount () */
/*========================================================*/
void setgsmdevs (void)
/*
 * setgsmdevs: set the library for modem sequential search from the first to the
 *          end. See getnextgsmdev ().
 */
{
    gsmdeventry = 0;
}                                        /* setgsmdevs () */
/*========================================================*/
struct gsms_def *getnextgsmdev (void)
/*
 * getnextgsmdev: get the next modem entry in /etc/gsmdevices
 *             file returns NULL if we are over the last entry.
 */
{
    static struct gsms_def mdm;
    int i = 0;
    char *buffer;

    buffer = mdmalloc (BUFSIZE);

    if (!buffer) {
	mdmerrno = -EMDMEM;
	return NULL;
    }


    mdmerrno = 0;

    if (open_gsmdevs () == FAILURE) {
	mdmfree (buffer);
        mdmerrno = -ENOMDMFILE;
        return NULL;
    }

    while (fgets (buffer, BUFSIZE, gsmdevfp) != NULL) {
        buffer[strlen (buffer) - 1] = '\0';

        if (buffer[0] == '#' || buffer[0] == '\0' || buffer[0] == '\n')
            continue;

        if (i == gsmdeventry) {
            if (demangle_gsmdev_entry (&mdm, buffer) == FAILURE) {
                mdmerrno = -EMDMBADCONF;
                continue;
            }
            gsmdeventry++;
            close_gsmdevs ();
	    mdmfree (buffer);
            return (&mdm);
        }
        i++;
    }
    close_gsmdevs ();
    mdmfree(buffer);
    return NULL;
}                                     /* getnextgsmdev () */
/*========================================================*/
static int demangle_gsmdev_entry (struct gsms_def *mdm, char *mdmstr)
/*
 * demangle_gsmdev_entry: get a gsmdev pointer that point to an existing
 * gsm_def structure and a string to demangle. Returns FAILURE or SUCCESS.
 * The buffer pointed to by mdmstr is modified in the process.
 */
{
    char *ptr, *pptr;

    /*....................................mdm->free (int) */
    /* is left uninitialized - dynamic data */
    
    /*...............................mdm->device (char *) */
    if ((ptr = strchr (mdmstr, ':')) == NULL)
        return FAILURE;
    *ptr = '\0';
    if ((strlen (mdmstr) == 0) || (strlen (mdmstr) > MAXDEVLEN))
        return (FAILURE);
    strcpy (mdm->device, mdmstr);
    ptr++;

    /*..................................mdm->PIN (char *) */
    if (*ptr == ':') {
        /* empty field */
        mdm->PIN[0] = '\0';
        *ptr = '\0';
        ptr++;
    }
    else {
        if ((pptr = strchr (ptr, ':')) == NULL)
            return FAILURE;
        *pptr = '\0';
        if (strlen (ptr) > PINLEN)
            return (FAILURE);
	strcpy (mdm->PIN, ptr);
        ptr = pptr + 1;
    }

    /*..................................mdm->PUK (char *) */
    if (*ptr == ':') {
        /* empty field */
        mdm->PUK[0] = '\0';
        *ptr = '\0';
        ptr++;
    }
    else {
        if ((pptr = strchr (ptr, ':')) == NULL)
            return FAILURE;
        *pptr = '\0';
        if (strlen (ptr) > PUKLEN)
            return (FAILURE);
        strcpy (mdm->PUK, ptr);
        ptr = pptr + 1;
    }

    /*.................................mdm->addr (char *) */
    if (*ptr == ':') {
        /* empty field */
        mdm->addr[0] = '\0';
        *ptr = '\0';
        ptr++;
    }
    else {
        if ((pptr = strchr (ptr, ':')) == NULL)
            return FAILURE;
        *pptr = '\0';
        if (strlen (ptr) > MAXPHNUMLEN)
            return (FAILURE);
        strcpy (mdm->addr, ptr);
        ptr = pptr + 1;
    }

    /*...............................mdm->defsca (char *) */
    if (*ptr == ':') {
        /* empty field */
        mdm->defsca[0] = '\0';
        *ptr = '\0';
        ptr++;
    }
    else {
        if ((pptr = strchr (ptr, ':')) == NULL)
            return FAILURE;
        *pptr = '\0';
        if (strlen (ptr) > MAXPHNUMLEN)
            return (FAILURE);
        strcpy (mdm->defsca, ptr);
        ptr = pptr + 1;
    }

    /*.............................mdm->provider (char *) */
    /*                                 !!! Last field !!! */
    if (*ptr == '\n' || *ptr == '\0' || *ptr == ':') {
        mdm->provider[0] = '\0';
        return SUCCESS;
    }
    else
        if (strlen (ptr) > MAXDEVLEN)
            return (FAILURE);
        strcpy (mdm->provider, ptr);

    return SUCCESS;
}                             /* demangle_gsmdev_entry () */
/*==========================================================
 * EOF : gsmdevices.c
 *===================*/
