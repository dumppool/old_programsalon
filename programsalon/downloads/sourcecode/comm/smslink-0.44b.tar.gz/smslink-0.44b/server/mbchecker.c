/*==========================================================
 * Program : mbchecker.c                   Project : smslink
 * Author  : Philippe Andersson.
 * Date    : 25/02/00
 * Version : 0.10b
 * Notice  : (c) Les Ateliers du Heron, 1998 for Scitex Europe, S.A.
 * Comment : Mailbox checking functions for the smslink server.
 *
 * Modification History :
 * - 0.01a (05/12/98) : Initial release.
 * - 0.02a (16/05/99) : Added include line for errno.h, to solve
 *   compilation problem on RedHat platform.
 * - 0.03a (06/06/99) : Started building the actual mailbox
 *   check procedure.
 * - 0.04b (28/06/99) : In mbcheck(), moved the AT+CNMI command
 *   after the PIN check routine. PIN-Activated SIM is required
 *   for AT+CNMI. Solved a bug with default SMSC.
 * - 0.05a (03/07/99) : Added list managment functions.
 * - 0.06a (11/07/99) : Added dumptofile() function.
 * ++++ Switch to Beta ++++
 * - 0.07b (20/07/99) : Improved mbcheck() to also remove the
 *   messages from the SIM after having saved them to disk.
 * - 0.08b (17/08/99) : Included code to create and update the
 *   checkpoint file after each successfull mailbox check (needed
 *   for interaction with the SMS to Mail gateway).
 * - 0.09b (02/12/99) : Improved handling for default SMSC in
 *   mbcheck(). Now uses the value kept in /etc/gsmdevices.
 * - 0.10b (25/02/00) : In mbcheck_wrapper(), moved the update
 *   of the checkpoint file outside of the device-checking loop
 *   (first because there's no need to update it more than once,
 *   second because it caused sms2mailgw to fire during the
 *   device checking loop).
 *========================================================*/

#include <stdio.h>                         /* for fprintf */
#include <stdlib.h>                  /* for errno & stuff */
#include <ctype.h>                       /* for isdigit() */
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <syslog.h>
#include <signal.h>
#include <sys/time.h>           /* for the struct timeval */
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>                        /* semaphores */
#include <sys/shm.h>                     /* shared memory */
#include <sys/ioctl.h>            /* for the ioctl() call */
#include <termios.h>         /* for baudrates definitions */
#include <dial/modems.h>           /* requires 'libmodem' */

#include "sms_serv.h"

/*========================================================*/
/* For debugging purposes only - comment out for normal compile */
/* #define INCL_DEBUG_CODE */

/*-------------------------------------External variables */
/* program specific */

/*---------------------------------------Global variables */
int MBC_instance;
int MBC_instance_is_set = FALSE;

/*========================================================*/
/**********               FUNCTIONS                ********/
/*========================================================*/
void mbox_list_init (mbox_list *list)
{
  list->head = NULL;
  list->tail = NULL;
}                                    /* mbox_list_init () */
/*========================================================*/
int empty_mbox_list (mbox_list list)
{
  return (list.head == NULL);
}                                   /* empty_mbox_list () */
/*========================================================*/
void mbox_list_insert (mbox_list *list, struct mbox_item *element)
{
  /* WARNING : the order of the elements IS relevent - has to
   * be chronological => insert at tail. */
  
  /* chain the element in the list */
  if (empty_mbox_list (*list)) {
    list->head = element;
    list->tail = element;
    element->next = NULL;
    element->prev = NULL;
  }
  else {
    element->next = NULL;
    element->prev = list->tail;
    list->tail->next = element;
    list->tail = element;
  }
}                                  /* mbox_list_insert () */
/*========================================================*/
void free_mbox_list (mbox_list *list)
{
  struct mbox_item *cursor;

  if (!empty_mbox_list (*list)) {
    /* hop to element before last */
    cursor = list->tail->prev;
    /* now go back and clean behind */
    while (cursor != NULL) {
      free (cursor->next);
      cursor->next = NULL;
      list->tail = cursor;
      cursor = cursor->prev;
    }                           /* while (cursor != NULL) */
  }                          /* if (!empty_mbox_list (... */
  /* now clean last element and reset header */
  free (list->head);
  list->head = NULL;
  list->tail = NULL;
}                                    /* free_mbox_list () */
/*========================================================*/
void MBC_unlock_gsm ()
{
  extern int shmem_sem;
  extern struct gsms_def *gsmdevices;

  syslog ((FACILITY | LOG_WARNING), "MBC being hit by SIGTERM.");
  /* set the allocated GSM module back to 'free' status */
  if (MBC_instance_is_set) {
    if (sem_wait (shmem_sem) == -1)
      syserr ("sms_serv: failed to wait on shared mem. semaphore");

    /* ---- Begin Crit. Sect. #5 ---- */
    if (!gsmdevices[MBC_instance].free) {
      gsmdevices[MBC_instance].free = TRUE;
      gsmdevices[MBC_instance].owner = 0;
      syslog ((FACILITY | LOG_WARNING), "GSM instance </dev/%s> has been unlocked.",
             gsmdevices[MBC_instance].device);
    }
    /* leave crit. sect. */
    if (sem_signal (shmem_sem) == -1)
      syserr ("sms_serv: can't signal shared mem. semaphore");
    /* ---- End Crit. Sect. #5 ---- */
  }
  /* free what's need to be freed and exit */
  /*------------------------------------------------------*/
  exit (0);
}                                    /* MBC_unlock_gsm () */
/*========================================================*/
int all_done (int *array, int size)
{
  int retval = TRUE;
  int i;

  for (i = 0; i < size; i++) {
    retval = (retval && array[i]);
  }
  return (retval);
}                                          /* all_done () */
/*========================================================*/
struct mbox_item *mbparse (char *msg_string)
{
  struct mbox_item *msg;
  char *s;
  char *token;
  char date[9];
  char time[10];
  char brol[5];
  int year, month, day;
  
  /*----------------Take a local copy of the input string */
  if ((s = (char *) malloc ((strlen (msg_string) + 1) * sizeof (char))) == NULL)
    return (NULL);
  strcpy (s, msg_string);
  /*-----------------------Allocate memory for the struct */
  if ((msg = (struct mbox_item *) malloc (sizeof (struct mbox_item))) == NULL)
    return (NULL);
  /*----------------------------------------Initialize it */
  msg->msgid = 0;
  msg->fromgsm[0] = '\0';
  msg->date[0] = '\0';
  msg->time[0] = '\0';
  msg->text[0] = '\0';
  msg->next = NULL;
  msg->prev = NULL;
  /*----------------------------Parse message string copy */
  /*...........................................Message ID */
  if ((token = strtok (s, ",")) != NULL) {
    /* Message ID - extract the ID token alone and atoi it */
    while (!isdigit (token[0]) && token[0])
      token++;
    msg->msgid = atoi (token);
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "token #1, msg ID = [%d]\n", msg->msgid);
#endif
  }
  else {
    /* Internal structure error */
    return (NULL);
  }
  /*.......................................Message Status */
  if ((token = strtok (NULL, ",")) != NULL) {
    /* Message status - drop it */
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "token #2, msg status = [%s] (ignored)\n", token);
#endif
  }
  else {
    /* Internal structure error */
    return (NULL);
  }
  /*....................................Sender GSM number */
  if ((token = strtok (NULL, ",")) != NULL) {
    /* Sender GSM number - dequote it */
    dequote (token);
    strcpy (msg->fromgsm, token);
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "token #3, sender GSM = [%s]\n", msg->fromgsm);
#endif
  }
  else {
    /* Internal structure error */
    return (NULL);
  }
  /*........................................Date and Time */
  if ((token = strtok (NULL, "\r")) != NULL) {
    /* Date and Time - dequote and split */
    dequote (token);
    strncpy (date, token, 8);
    date[8] = '\0';
    token += 9;
    strncpy (time, token, 9);
    time[9] = '\0';
    /* Convert date format from DD/MM/YY to YYYYMMDD */
    strncpy (brol, date, 2);                       /* day */
    day = atoi (brol);
    shiftleft (date, 3);
    strncpy (brol, date, 2);                     /* month */
    month = atoi (brol);
    shiftleft (date, 3);
    strncpy (brol, date, 2);                      /* year */
    year = atoi (brol);
    /* take care of the missing century */
    if (year < 95)
      year += 2000;
    else
      year += 1900;
    sprintf (msg->date, "%d%02d%02d", year, month, day);
    /* Copy the time over */
    strcpy (msg->time, time);
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "token #4, message date = [%s]\n", msg->date);
    fprintf (stderr, "token #5, message time = [%s]\n", msg->time);
#endif
  }
  else {
    /* Internal structure error */
    return (NULL);
  }
  /*.........................................Message text */
  if ((token = strtok (NULL, "\r")) != NULL) {
    /* Message text - trim unwanted characters */
    trim (token);
    strcpy (msg->text, token);
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "token #6, message text = [%s]\n", msg->text);
#endif
  }
  else {
    /* Internal structure error */
    return (NULL);
  }
  /*-------------------------------------------------Exit */
  free (s);
  return (msg);
}                                           /* mbparse () */
/*========================================================*/
int dumptofile (mbox_list *list, char *device)
{
  int nline = 0;
  FILE *mbox_file;
  int lockf_desc;
  struct mbox_item *cursor;
  int save_errno;

  lockf_desc = open (MBOX_LOCKF, (O_RDWR | O_CREAT | O_EXCL), 0444);
  if (lockf_desc == -1) {
    syslog ((FACILITY | LOG_ERR), "can't lock the inbox file.");
    mdmperror ("sms_serv: can't lock the inbox file");
  }
  else {
    /* file is now locked */
    if ((mbox_file = fopen (MBOX_FILE, "a")) != NULL) {
      cursor = list->head;
      while (cursor != NULL) {
        fprintf (mbox_file, "/dev/%s,%d,%s,%s,%s,\"%s\"\n",
	        device, cursor->msgid, cursor->fromgsm,
		cursor->date, cursor->time, cursor->text);
	nline++;
	cursor = cursor->next;
      }                         /* while (cursor != NULL) */
      fclose (mbox_file);
    }
    else {
      syslog ((FACILITY | LOG_ERR), "can't open the inbox file.");
      mdmperror ("sms_serv: can't open the inbox file");
    }
    /* Now remove lock file */
    close (lockf_desc);
    if (unlink (MBOX_LOCKF) == -1) {
      syslog ((FACILITY | LOG_ERR), "can't remove the lock file.");
      mdmperror ("sms_serv: can't remove the lock file");
    }
  }                              /* if (lockf_desc == -1) */
  return (nline);
}                                        /* dumptofile () */
/*========================================================*/
int mbcheck (struct gsms_def *gsm)
{
  int fd, retval = 0;
  int nmsgin = 0;
  char *scratch;
  char *p1;
  char *p2;
  char *cmsgid;
  int nread;
  int newpin;
  int retries;
  int msgid;
  struct mbox_item *message;
  mbox_list mailbox;
  
  /*--------------------------------------Initializations */
  scratch = (char *) malloc ((BIGBUFF + 1) * sizeof (char));
  if (!scratch)
    syserr ("sms_serv: can't allocate scratch space");
  memset (scratch, 0, (BIGBUFF + 1));

  mbox_list_init (&mailbox);
  
  /* open modem line */
  fd = blopen_mdm_line (gsm->device, B9600);
  if (fd < 0) {
    syslog ((FACILITY | LOG_ERR), "call to blopen_mdm_line() failed.");
    mdmperror ("sms_serv: blopen_mdm_line() failed");
    free (scratch);
    return (-1);
  }
  
  /*------------set GSM to "verbose" error reporting mode */
  sprintf (scratch, "at+cmee=1\r");
  tell_gsm (fd, scratch);
  memset (scratch, 0, (BIGBUFF + 1));
  if (get_gsm_answer (fd, scratch, BIGBUFF, 1)) {
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "%s\n", scratch);
#endif
    /* check for "OK" */
    if (strstr (scratch, "OK") == NULL) {
      mdm_unlock (mdmopendevice);
      hangup (fd);
      free (scratch);
      syslog ((FACILITY | LOG_ERR), "error after sending AT+CMEE command.");
      mdmperror ("sms_serv: error after sending AT+CMEE command");
      return (-1);
    }
  }
  else {
    mdm_unlock (mdmopendevice);
    hangup (fd);
    free (scratch);
    syslog ((FACILITY | LOG_ERR), "GSM module not responding.");
    mdmperror ("sms_serv: GSM not responding");
    return (-1);
  }
  
  /*---------------------------then, check for SIM status */
  sprintf (scratch, "at+cpin?\r");
  tell_gsm (fd, scratch);
  memset (scratch, 0, (BIGBUFF + 1));
  if (get_gsm_answer (fd, scratch, BIGBUFF, 1)) {
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "%s\n", scratch);
#endif
    /* check for "READY" -- if not, make it so */
    retries = MAXATTEMPTS;
    while ((strstr (scratch, "READY") == NULL) && retries--) {
      /* not ready yet -> asking for PIN or PUK ? */
      if (strstr (scratch, "SIM PIN")) {
        /* send PIN */
	sprintf (scratch, "at+cpin=%s\r", gsm->PIN);
	tell_gsm (fd, scratch);
	memset (scratch, 0, (BIGBUFF + 1));
	if (get_gsm_answer (fd, scratch, BIGBUFF, 15)) {
#ifdef INCL_DEBUG_CODE
          fprintf (stderr, "%s\n", scratch);
#endif
	  /* check for "OK" */
	  if (strstr (scratch, "OK") == NULL) {
	    mdm_unlock (mdmopendevice);
	    hangup (fd);
	    free (scratch);
            syslog ((FACILITY | LOG_ERR), "can't send PIN to GSM or wrong PIN.");
	    mdmperror ("sms_serv: can't send PIN to GSM or wrong PIN");
	    return (-1);
	  }
	}
	else {
	  mdm_unlock (mdmopendevice);
	  hangup (fd);
	  free (scratch);
          syslog ((FACILITY | LOG_ERR), "GSM module not responding.");
	  mdmperror ("sms_serv: GSM not responding");
	  return (-1);
	}
      }
      else if (strstr (scratch, "SIM PUK")) {
        /* send PUK - set new random PIN */
	srand (getpid ());
	newpin = rand ();
	syslog ((FACILITY | LOG_WARNING), "I'll try to set new PIN for </dev/%s>.", gsm->device);
	sprintf (scratch, "at+cpin=\"%s\",\"%04d\"\r", gsm->PUK, newpin);
	tell_gsm (fd, scratch);
	memset (scratch, 0, (BIGBUFF + 1));
	if (get_gsm_answer (fd, scratch, BIGBUFF, 20)) {
#ifdef INCL_DEBUG_CODE
          fprintf (stderr, "%s\n", scratch);
#endif
	  /* check for "OK" */
	  if (strstr (scratch, "OK") == NULL) {
	    mdm_unlock (mdmopendevice);
	    hangup (fd);
	    free (scratch);
            syslog ((FACILITY | LOG_ERR), "can't send PUK to GSM or wrong PUK.");
	    mdmperror ("sms_serv: can't send PUK to GSM or wrong PUK");
	    return (-1);
	  }
	}
	else {
	  mdm_unlock (mdmopendevice);
	  hangup (fd);
	  free (scratch);
          syslog ((FACILITY | LOG_ERR), "GSM module not responding.");
	  mdmperror ("sms_serv: GSM not responding");
	  return (-1);
	}
	/* store new PIN in conf. file (GSMDEVFILE) */
	/* log it */
	syslog ((FACILITY | LOG_WARNING), "new PIN for </dev/%s> set to [%04d].", gsm->device, newpin);
      }
      else {                                     /* ERROR */
	mdm_unlock (mdmopendevice);
	hangup (fd);
	free (scratch);
        syslog ((FACILITY | LOG_ERR), "unable to get SIM status info.");
	mdmperror ("sms_serv: unable to get SIM status info");
	return (-1);
      }                 /* if "PIN" elseif "PUK" else ... */
      /* query the status again */
      sprintf (scratch, "at+cpin?\r");
      tell_gsm (fd, scratch);
      memset (scratch, 0, (BIGBUFF + 1));
      if (!get_gsm_answer (fd, scratch, BIGBUFF, 1)) {
	mdm_unlock (mdmopendevice);
	hangup (fd);
	free (scratch);
        syslog ((FACILITY | LOG_ERR), "GSM module not responding.");
	mdmperror ("sms_serv: GSM not responding");
	return (-1);
      }
#ifdef INCL_DEBUG_CODE
      fprintf (stderr, "%s\n", scratch);
#endif
    }                                 /* while (!"READY") */
  }
  else {
    mdm_unlock (mdmopendevice);
    hangup (fd);
    free (scratch);
    syslog ((FACILITY | LOG_ERR), "GSM module not responding.");
    mdmperror ("sms_serv: GSM not responding");
    return (-1);
  }
  
  /*------------set "no notify for incoming SMS messages" */
  sprintf (scratch, "at+cnmi=0,0,0,0,0\r");
  tell_gsm (fd, scratch);
  memset (scratch, 0, (BIGBUFF + 1));
  if (get_gsm_answer (fd, scratch, BIGBUFF, 1)) {
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "%s\n", scratch);
#endif
    /* check for "OK" */
    if (strstr (scratch, "OK") == NULL) {
      mdm_unlock (mdmopendevice);
      hangup (fd);
      free (scratch);
      syslog ((FACILITY | LOG_ERR), "error after sending AT+CNMI command.");
      mdmperror ("sms_serv: error after sending AT+CNMI command");
      return (-1);
    }
  }
  else {
    mdm_unlock (mdmopendevice);
    hangup (fd);
    free (scratch);
    syslog ((FACILITY | LOG_ERR), "GSM module not responding.");
    mdmperror ("sms_serv: GSM not responding");
    return (-1);
  }
  
  /*----------------Check stored SCA against default SMSC */
  sprintf (scratch, "at+csca?\r");
  tell_gsm (fd, scratch);
  memset (scratch, 0, (BIGBUFF + 1));
  if (get_gsm_answer (fd, scratch, BIGBUFF, 1)) {
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "%s\n", scratch);
#endif
    /* compare with default SMSC */
    if (strstr (scratch, gsm->defsca) == NULL) {
      /* let's set it then */
      sprintf (scratch, "at+csca=\"%s\"\r", gsm->defsca);
      tell_gsm (fd, scratch);
      memset (scratch, 0, (BIGBUFF + 1));
      if (get_gsm_answer (fd, scratch, BIGBUFF, 2)) {
#ifdef INCL_DEBUG_CODE
        fprintf (stderr, "%s\n", scratch);
#endif
	/* check for "OK" */
	if (strstr (scratch, "OK") == NULL) {
	  mdm_unlock (mdmopendevice);
	  hangup (fd);
	  free (scratch);
          syslog ((FACILITY | LOG_ERR), "error after sending AT+CSCA= command.");
	  mdmperror ("sms_serv: error after sending AT+CSCA= command");
	  return (-1);
	}
      }
      else {
	mdm_unlock (mdmopendevice);
	hangup (fd);
	free (scratch);
        syslog ((FACILITY | LOG_ERR), "GSM module not responding.");
	mdmperror ("sms_serv: GSM not responding");
	return (-1);
      }
    }
  }
  else {
    mdm_unlock (mdmopendevice);
    hangup (fd);
    free (scratch);
    syslog ((FACILITY | LOG_ERR), "GSM module not responding.");
    mdmperror ("sms_serv: GSM not responding");
    return (-1);
  }
  
  /*---------------------Am I registered on the network ? */
  sprintf (scratch, "at+creg?\r");
  tell_gsm (fd, scratch);
  memset (scratch, 0, (BIGBUFF + 1));
  if (get_gsm_answer (fd, scratch, BIGBUFF, 1)) {
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "%s\n", scratch);
#endif
    /* check for "0,1" status */
    if (strstr (scratch, "+CREG: 0,1") == NULL) {
      mdm_unlock (mdmopendevice);
      hangup (fd);
      free (scratch);
      syslog ((FACILITY | LOG_ERR), "not registered on the network - can't check mailbox.");
      mdmperror ("sms_serv: not registered on the network - can't check mailbox");
      return (-1);
    }
  }
  else {
    mdm_unlock (mdmopendevice);
    hangup (fd);
    free (scratch);
    syslog ((FACILITY | LOG_ERR), "GSM module not responding.");
    mdmperror ("sms_serv: GSM not responding");
    return (-1);
  }
  
  /*-----------------------Now loop and read incoming SMS */
  sprintf (scratch, "at+cmgl=0\r");
  tell_gsm (fd, scratch);
  memset (scratch, 0, (BIGBUFF + 1));
  if (get_gsm_answer (fd, scratch, BIGBUFF, 1)) {
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "%s\n", scratch);
#endif
    /*....................look for "+CMGL:" in GSM answer */
    p1 = scratch;
    while (p1 && ((p1 = strstr (p1, "+CMGL:")) != NULL)) {
      /* got new message - isolate it from the batch */
      p2 = (p1 + 6);
      if ((p2 = strstr (p2, "+CMGL:")) != NULL) {
        /* there's another one behind */
	p1[((p2 - p1) - 1)] = '\0';
      }
      if ((message = mbparse (p1)) == NULL) {
	mdm_unlock (mdmopendevice);
	hangup (fd);
	free (scratch);
	syslog ((FACILITY | LOG_ERR), "mbparse() internal error.");
	mdmperror ("sms_serv: mbparse() internal error");
	return (-1);
      }
      mbox_list_insert (&mailbox, message);
      nmsgin++;
      p1 = p2;
    }                              /* while ((msgstart... */
    if (nmsgin) {
      /*............dump all messages to the mailbox file */
      if (dumptofile (&mailbox, gsm->device) != nmsgin) {
	syslog ((FACILITY | LOG_ERR), "failed to save messages to inbox file.");
	mdmperror ("sms_serv: failed to save messages to inbox file");
      }
      /*.................remove the messages from the SIM */
      message = mailbox.head;
      while (message != NULL) {
	sprintf (scratch, "at+cmgd=%d\r", message->msgid);
	tell_gsm (fd, scratch);
	memset (scratch, 0, (BIGBUFF + 1));
	if (get_gsm_answer (fd, scratch, BIGBUFF, 1)) {
#ifdef INCL_DEBUG_CODE
	  fprintf (stderr, "%s\n", scratch);
#endif
	  /* check for "OK" */
	  if (strstr (scratch, "OK") == NULL) {
	    mdm_unlock (mdmopendevice);
	    hangup (fd);
	    free (scratch);
	    syslog ((FACILITY | LOG_ERR), "error after sending AT+CMGD command.");
	    mdmperror ("sms_serv: error after sending AT+CMGD command");
	    return (-1);
	  }
	}
	else {
	  mdm_unlock (mdmopendevice);
	  hangup (fd);
	  free (scratch);
	  syslog ((FACILITY | LOG_ERR), "GSM module not responding.");
	  mdmperror ("sms_serv: GSM not responding");
	  return (-1);
	}
        message = message->next;
      }                        /* while (message != NULL) */
      /*...............clean the mailbox list from memory */
      free_mbox_list (&mailbox);
    }                                      /* if (nmsgin) */
  }
  else {
    mdm_unlock (mdmopendevice);
    hangup (fd);
    free (scratch);
    syslog ((FACILITY | LOG_ERR), "GSM module not responding.");
    mdmperror ("sms_serv: GSM not responding");
    return (-1);
  }
  
  /*----------------------------------Close communication */
  mdm_unlock (mdmopendevice);
  hangup (fd);
  free (scratch);
  return (nmsgin);
}                                           /* mbcheck () */
/*========================================================*/
void mbcheck_wrapper ()
{
  extern int errno;
  extern int global_sem;
  extern int shmem_sem;
  extern struct gsms_def *gsmdevices;
  extern int ngsmdevs;     /* num. configured GSM devices */
  int nwaitsecs = 0;
  int last_errno;
  int retval;
  char device[MAXDEVLEN];
  struct gsms_def gsm;
  int msgin;
  int i;
  int cpfd;                     /* checkpoint file descr. */
  int gsm_done[ngsmdevs];
  int maxiterat;
  int iteration;
  char *missedg;
  struct sigaction sa_c;

  /*--------------------------------------Initializations */
  for (i = 0; i < ngsmdevs; i++) {
    gsm_done[i] = FALSE;
  }
  maxiterat = (2 * ngsmdevs);
  iteration = 0;
  
  /*--------------------------------------------Main loop */
  while ((!all_done (gsm_done, ngsmdevs)) && (iteration < maxiterat)) {
    syslog ((FACILITY | LOG_INFO), "MBC waits for a free GSM instance (pass %d)...",
           (iteration + 1));
  
    while (((retval = sem_decreq (global_sem)) == -1) &&
          (errno == EAGAIN) &&
	  (nwaitsecs < M_TIMEOUT)) {
      sleep (W_STEP);
      nwaitsecs += W_STEP;
    }                                      /* while (...) */
    last_errno = errno;
  
    if (retval == -1) {          /* failed to get a modem */
      switch (last_errno) {
        case EAGAIN: {
          syslog ((FACILITY | LOG_WARNING), "MBC timeout expired (all GSMs busy).");
          break;
        }

        default: {
          syserr ("sms_serv(MBC): can't decrease global semaphore");
	  break;
        }
      }                            /* switch (last_errno) */
    }
    else {               /* ---- Begin Crit. Sect. #1 --- */
      /* at least 1 GSM module is free - find it */
      if (sem_wait (shmem_sem) == -1)
        syserr ("sms_serv(MBC): failed to wait on shared mem. semaphore");

      /* ---- Begin Crit. Sect. #2 ---- */
      /* first catch SIGTERM to handle child being killed while GSM's locked */
      sa_c.sa_handler = MBC_unlock_gsm;
      if (sigfillset (&sa_c.sa_mask) == -1)
        syserr ("sms_serv(MBC): can't fill signal set");
      sa_c.sa_flags = 0;
      if (sigaction (SIGTERM, &sa_c, NULL) == -1)
        syserr ("sms_serv(MBC): can't catch SIGTERM");

      /* search for MBC_instance both free and not yet processed */
      MBC_instance = 0;
      while (MBC_instance < ngsmdevs) {
	if (gsmdevices[MBC_instance].free && !gsm_done[MBC_instance]) {
	  /* let's process this one */
	  break;
	}
        MBC_instance++;
      }                     /* while (MBC_instance < ngsmdevs) */
      if (MBC_instance < ngsmdevs) {
        /* got it - now lock it (device lockfile handled by libmodem) */
        MBC_instance_is_set = TRUE;
        gsmdevices[MBC_instance].free = FALSE;
        gsmdevices[MBC_instance].owner = getpid ();
      
        /* copy to "local" space, to avoid the shmem balagan */
        if (gsmdevcpy (&gsm, &gsmdevices[MBC_instance]) == -1)
          syserr ("sms_serv(MBC): error copying GSM MBC_instance");
      
        /* leave crit. sect. */
        if (sem_signal (shmem_sem) == -1)
          syserr ("sms_serv(MBC): can't signal shared mem. semaphore");
        /* ---- End Crit. Sect. #2 ---- */

        /* log it */
        syslog ((FACILITY | LOG_NOTICE), "MBC now polling device </dev/%s>.", gsm.device);
    
        /* ---->>> Actual GSM Dialogue <<<---- */
        if ((msgin = mbcheck (&gsm)) != -1) {
          /* log it */
          syslog ((FACILITY | LOG_NOTICE), "MBC check ok, got %d msg from </dev/%s>.", msgin, gsm.device);
        }
        else { /* some error occured */
          syslog ((FACILITY | LOG_WARNING), "MBC ERROR: failed to poll </dev/%s>.", gsm.device);
        }

	/* mark this GSM as "done" */
	gsm_done[MBC_instance] = TRUE;
    
        /* now free the modem again */
        if (sem_wait (shmem_sem) == -1)
          syserr ("sms_serv(MBC): failed to wait on shared mem. semaphore");

        /* ---- Begin Crit. Sect. #3 ---- */
        gsmdevices[MBC_instance].free = TRUE;
        gsmdevices[MBC_instance].owner = 0;
        MBC_instance_is_set = FALSE;
        /* leave crit. sect. */
        if (sem_signal (shmem_sem) == -1)
          syserr ("sms_serv(MBC): can't signal shared mem. semaphore");
        /* ---- End Crit. Sect. #3 ---- */

        /* leave main crit. sect. */
        if (sem_signal (global_sem) == -1)
          syserr ("sms_serv(MBC): can't signal global semaphore");
	/* ---- End Crit. Sect. #1 ---- */
      }
      else {
        /* leave crit. sect. */
        if (sem_signal (shmem_sem) == -1)
          syserr ("sms_serv(MBC): can't signal shared mem. semaphore");
        /* ---- End Crit. Sect. #2 ---- */

        /* leave main crit. sect. - release unused resource */
        if (sem_signal (global_sem) == -1)
          syserr ("sms_serv(MBC): can't signal global semaphore");
	/* ---- End Crit. Sect. #1 ---- */

        syslog ((FACILITY | LOG_WARNING), "MBC all free GSM's already processed");
      }                   /* if (MBC_instance < ngsmdevs) */
    }                                /* if (retval == -1) */
    iteration++;
  }                               /* while ((!all_done... */
  /*-------------------------------------------Conclusion */
  /* update timestamp on checkpoint file */
  if ((cpfd = open (CHECKPOINTF, O_RDWR | O_CREAT | O_TRUNC, 0644)) == -1) {
    perror ("sms_serv(MBC): can't update checkpoint file");
    syslog ((FACILITY | LOG_WARNING), "MBC can't update checkpoint file.");
  }
  close (cpfd);
  
  /* Based on gsm_done, report on missed MBC_instances */
  if (all_done (gsm_done, ngsmdevs)) {
    /* all done */
    syslog ((FACILITY | LOG_NOTICE), "MBC all devices processed.");
  }
  else {
    /* missed some */
    missedg = (char *) malloc ((MINIBUFF + 1) * sizeof (char));
    missedg[0] = '\0';
    for (i = 0; i < ngsmdevs; i++) {
      if (!gsm_done[i]) {
        strcat (missedg, gsmdevices[i].device);
	strcat (missedg, ", ");
      }
    }
    /* remove trailing ", " sequence */
    missedg[strlen (missedg) - 2] = '\0';
    syslog ((FACILITY | LOG_WARNING), "MBC poll missed {%s}.", missedg);
    free (missedg);
  }
}                                   /* mbcheck_wrapper () */
/*========================================================*/

/*==========================================================
 * EOF : mbchecker.c
 *===================*/
