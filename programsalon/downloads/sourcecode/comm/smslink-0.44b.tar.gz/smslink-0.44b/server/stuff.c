/*==========================================================
 * Program : stuff.c                       Project : smslink
 * Author  : Philippe Andersson.
 * Date    : 09/11/99
 * Version : 0.16b
 * Notice  : (c) Les Ateliers du Heron, 1998 for Scitex Europe, S.A.
 * Comment : Library of functions for the smslink servers.
 *
 * Modification History :
 * - 0.01a (25/08/98) : Initial release.
 * - 0.02a (27/08/98) : Added tellsock().
 * - 0.03a (01/09/98) : Added semaphore deletion to daemons_death().
 * - 0.04a (03/09/98) : Added shared memory release to daemons_death().
 * - 0.05a (06/09/98) : Inserted #ifdef's to have it compile under
 *   RedHat (GNU Libc 6).
 * - 0.06a (19/10/98) : Added gsmdevcpy ().
 * - 0.07a (20/10/98) : Included GSM communication functions.
 * - 0.08b (13/12/98) : Adapted gsmdevcpy() for struct gsms_def
 *   new member "owner".
 * - 0.09b (14/02/99) : Included code in daemon's death to
 *   clean ACL linked list.
 * - 0.10b (29/06/99) : Moved 3 functions from server.y to here
 *   (misc. string handling functions).
 * - 0.11b (03/07/99) : Added function trim(). Cosmetics.
 * - 0.12b (17/08/99) : Included code in deamons_death() to
 *   remove the checkpoint file before quitting.
 * - 0.13b (18/08/99) : Added an exit function specific for
 *   sms2mailgw.
 * - 0.14b (19/08/99) : Moved the server-specific functions to
 *   serv_stuff.c and the gateway-specific ones to gw-stuff.c.
 * - 0.15b (21/10/99) : Moved tellsock() over from serv_stuff.c.
 * - 0.16b (09/11/99) : Added nicedate() function.
 *========================================================*/

#include <unistd.h>
#include <stdio.h>                         /* for fprintf */
#include <stdlib.h>                  /* for errno & stuff */
#include <errno.h>
#include <string.h>
#include <syslog.h>
#include <sys/time.h>           /* for the struct timeval */
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>                        /* semaphores */
#include <sys/shm.h>                     /* shared memory */
#include <sys/ioctl.h>            /* for the ioctl() call */
#include <dial/modems.h>           /* requires 'libmodem' */

#include "sms_serv.h"

/*========================================================*/
/* For debugging purposes only - comment out for normal compile */
/* #define INCL_DEBUG_CODE */

/*========================================================*/
/*################### misc. string handling ##############*/
/*========================================================*/
int shiftleft (s, i)
char *s;
int i;
{
  int l;
  int j, k;
  
  l = strlen (s);
  if (i >= l) {
    s[0] = '\0';
    return (0);
  }
  
  for (j = 0, k = i; k < l; k++, j++) {
    s[j] = s[k];
  }
  
  s[j] = '\0';
  
  /* exit */
  return (strlen (s));
}                                         /* shiftleft () */
/*========================================================*/
int dequote (s)
char *s;
{
  int l;
  
  /* check for front quote and remove it */
  if (s[0] == '"') {
    l = shiftleft (s, 1);
  }
  else {
    l = strlen (s);
  }
  /* check for back quote and remove it (l = new strlen) */
  if (s[l - 1] == '"')
    s[l - 1] = '\0';
    
  /* exit */
  return (strlen (s));
}                                           /* dequote () */
/*========================================================*/
int trim (char *string)
{
  char *p;
  int WS = TRUE;

  p = string;
  while (*p) {
    switch (*p) {
      case '\n' : {
        if (WS)
	  shiftleft (p, 1);
	else {
	  *p = ' ';
	  WS = TRUE;
	  p++;
	}
	break;
      }

      case '\r' : {
        if (WS)
	  shiftleft (p, 1);
	else {
	  *p = ' ';
	  WS = TRUE;
	  p++;
	}
	break;
      }

      case ' ' : {
        if (WS)
	  shiftleft (p, 1);
 	else {
	  WS = TRUE;
	  p++;
	}
	break;
      }
      
      default : {
        WS = FALSE;
	p++;
	break;
      }

    }                                      /* switch (*p) */
  }                                         /* while (*p) */
  return (strlen (string));
}                                              /* trim () */
/*========================================================*/
int deslashdot (char *s)

/* Cleans phone numbers */
{
  char *ptr;
  
  ptr = s;
  while (*ptr) {
    if ((!isdigit (ptr[0])) && (ptr[0] != '+')) {
      shiftleft (ptr, 1);
    }
    else {
      ptr++;
    }
  }                                       /* while (*ptr) */
  return (strlen (s));
}                                        /* deslashdot () */
/*========================================================*/
char *nicedate (char *s)

/* takes a date in YYYYMMDD format and returns a string
   formatted as Mmm D, YYYY                               */
{
  char *out;
  char *ptr;
  char y[5];
  char m[3];
  char d[3];
  char mn[4];
  int i;
  char monthlist[37] = "JanFebMarAprMayJunJulAugSepOctNovDec";

  /*---------------------------------------Initialization */
  out = (char *) malloc (20 * sizeof (char));
  if (! out) {
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    syserr ("sms: can't malloc()");
  }
  out[0] = '\0';
  y[0] = '\0';
  m[0] = '\0';
  d[0] = '\0';
  mn[0] = '\0';

  /*-------------------------------------------Parse date */
  strncpy (y, s, 4);
  y[4] = '\0';
  ptr = s + 4;
  strncpy (m, ptr, 2);
  m[2] = '\0';
  ptr += 2;
  strncpy (d, ptr, 2);
  d[2] = '\0';
  
  /*--------------------------------------Generate string */
  i = atoi (m) - 1;
  ptr = monthlist + (3 * i);
  strncpy (mn, ptr, 3); 
  mn[3] = '\0';

  sprintf (out, "%s %d, %s", mn, atoi (d), y);

  /*-------------------------------------------Conclusion */
  return (out);
}                                          /* nicedate () */
/*========================================================*/
/*========================================================*/
/*################# Socket communication #################*/
/*========================================================*/
void tellsock (int sock, char *string)
{
  int length;
  
  length = strlen (string);
  if (write (sock, string, length) != length)
    syserr ("sms_serv: error while writing to socket");

}                                          /* tellsock () */
/*========================================================*/
/*========================================================*/
/*#################### Error Handling ####################*/
/*========================================================*/
void syserr (char *msg)
{
  extern int errno, sys_nerr;
#ifdef LINUX_LC6
  extern const char *const sys_errlist[];
#else
  extern char * sys_errlist[];
#endif                                /* #ifdef LINUX_LC6 */

  fprintf (stderr, "ERROR %s", msg);
  if (errno > 0 && errno < sys_nerr)
    fprintf (stderr, " (%d ; %s)\n", errno, sys_errlist[errno]);
  else
    fprintf (stderr, "\n");
  exit (1);
}                                            /* syserr () */
/*========================================================*/
void fatal (char *msg)
{
  fprintf (stderr, "FATAL ERROR %s\n", msg);
  exit (2);
}                                             /* fatal () */
/*==========================================================
 * EOF : stuff.c
 *===================*/
