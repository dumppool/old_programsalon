/*==========================================================
 * Program : sms2mailgw.c                  Project : smslink
 * Authors : Philippe Andersson.
 * Date    : 02/03/00
 * Version : 0.07b
 * Notice  : (c) Les Ateliers du Heron, 1998 for Scitex Europe, S.A.
 *           contributions (c) Internet Access AG, 1999.
 * Comment : SMS to Mail Gateway.
 *
 * Modification History :
 * - 0.01a (17/08/99) : Initial release.
 * - 0.02a (18/10/99) : Improved code and increased logging
 *   for default domain.
 * ++++ Switched to Beta ++++
 * - 0.03b (09/11/99) : Mail sending code added. Ready to start
 *   beta-test. No change to this file.
 * - 0.04b (24/02/00) : Finalized the transfer code to the "new"
 *   mailbox file (in gw_stuff.c). Added a syslog report of the
 *   amount of messages sent.
 * - 0.05b (26/02/00) : Added a global variable (inbox_is_locked)
 *   to control lockfile removal on server's signalled exit.
 * - 0.06b (01/03/00) : Solved a few bugs in the SMTP session
 *   handling. No change in this file.
 * - 0.07b (02/03/00) : Modified the synchronisation mechanism. In
 *   case the synch. is lost, the daemon will wait 1/10th of an
 *   interval only (to avoid loosing a full cycle before delivering
 *   the mail). After a mailbox run, the daemon goes back to sleep
 *   for the rest of the cycle _+ 1 min._. This should prevent it
 *   colliding with the next MBC.
 *========================================================*/

#ifdef HPUX
#  include <sys/unistd.h>                /* for getopt () */
#else
#  include <unistd.h>                    /* for getopt () */
#endif                                      /* ifdef HPUX */
#include <sys/stat.h>                      /* for stat () */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ipc.h>
#include <netinet/in.h>     /* for AF_INET domain sockets */
#include <arpa/inet.h>                /* for inet_addr () */
#include <netdb.h>                /* for gethostbyname () */
#include <fcntl.h>                        /* for fcntl () */
#include <time.h>                      /* for difftime () */
#include <syslog.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>               /* for strcpy & friends */

/*--------------------------------------Personal includes */
#include "sms_serv.h"

/*========================================================*/
/**********             LOCAL DEFINES              ********/
/*========================================================*/

/* For debugging purposes only - comment out for normal compile */
/* #define INCL_DEBUG_CODE */

/*========================================================*/
/**********           GLOBAL VARIABLES             ********/
/*========================================================*/

int csfd;                             /* client socket FD */
char *buffer;                    /* read and write buffer */
int inbox_is_locked = FALSE;

/*========================================================*/
/**********               FUNCTIONS                ********/
/*========================================================*/

/*========================================================*/
/**********           MAIN PROGRAM LOOP            ********/
/*========================================================*/

main ()
{
  extern int errno;
  time_t lastchked;
  struct stat filestat;              /* filled by stat () */
  int waiting;
  int sleeptime;
  int nread;
  char *localhost;
  char *defaultdomain;
  int lockf_desc;
  int ntry;
  int pid, ppid, gppid;             /* for fork() testing */
  int i;
  struct sigaction sa_f;
  int nmsg;
  
  /*-------------------------First, let's become a daemon */
  gppid = fork ();
  if (gppid == -1)
    syserr ("sms2mailgw: grand-father can't fork");
  else if (gppid != 0)
         exit (0);                /* grand-father's death */
  
  /* open connection with the syslog daemon - announce */
  openlog ("sms2mailgw", (LOG_CONS | LOG_PID), FACILITY);
  syslog ((FACILITY | LOG_INFO), "gateway process starting (v. %s)...", SMS_GW_VERSION);
  
  /* let's become group leader (thereby loosing my tty) */
  if (setpgrp () == -1)
    syserr ("sms2mailgw: can't become group leader");
  
  /*--------------------------------------Initialisations */
  /* Signal Handling - ignore some */
  sa_f.sa_handler = SIG_IGN;
  if (sigemptyset (&sa_f.sa_mask) == -1)
    syserr ("sms2mailgw: can't empty signal set");
  sa_f.sa_flags = 0;
  if (sigaction (SIGHUP, &sa_f, NULL) == -1)    /* hangup */
    syserr ("sms2mailgw: can't ignore SIGHUP");
  if (sigaction (SIGCHLD, &sa_f, NULL) == -1) 
    syserr ("sms2mailgw: can't ignore SIGCHLD");

  /* now do something meaningfull on SIGTERM */
  sa_f.sa_handler = mailgws_death;
  if (sigfillset (&sa_f.sa_mask) == -1)
    syserr ("sms2mailgw: can't fill signal set");
  sa_f.sa_flags = 0;
  if (sigaction (SIGTERM, &sa_f, NULL) == -1)
    syserr ("sms2mailgw: can't catch SIGTERM");
    
  /* first fork */
  ppid = fork ();
  if (ppid == -1)
    syserr ("sms2mailgw: father can't fork");
  else if (ppid != 0)
         exit (0);                      /* father's death */
  /*-------------------------------Start of daemon itself */
  /* set the file creation mask */
  /* umask (0); */
  /* change directory to ...? */
#ifndef INCL_DEBUG_CODE       /* we want to keep stdout for printf's */
  /* close unused file descriptors */
#endif

  /*================================Real start of program */
  /* get the hostname I'm running on (to fill in the From: part) */
  localhost = (char *) malloc ((MINIBUFF + 1) * sizeof (char));
  if (gethostname (localhost, MINIBUFF) == -1)
    syserr ("sms2mailgw: can't get host name");

  /* set the default domain (to allow for short names in To: fields) */
  defaultdomain = (char *) malloc ((MINIBUFF + 1) * sizeof (char));
  if (! defaultdomain) {
    syserr ("sms2mailgw: can't malloc()");
  }
  defaultdomain[0] = '\0';
  if (strcmp (DEFAULTDOMAIN, ".") == 0) {
    if (getdomainname (defaultdomain, MINIBUFF) == -1) {
      syserr ("sms2mailgw: can't getdomainname()");
    }
    /* spit out error if we need domain name but it's not set */
    if (strcmp (defaultdomain, "(none)") == 0) {
      syserr ("sms2mailgw: can't get domain name - not set");
    }
  }
  else {
    strcpy (defaultdomain, DEFAULTDOMAIN);
  }
  syslog ((FACILITY | LOG_INFO), "working for domain [%s]", defaultdomain);
  
  /* initialize "last checked" time */
  lastchked = 0;

  /*---------------------------Start real processing loop */
  while (TRUE) {
    waiting = TRUE;
    while (waiting) {
      /* if checkpoint file not present, wait for it */
      while (stat (CHECKPOINTF, &filestat) == -1) {
        switch (errno) {
          case ENOENT: {                  /* no such file */
	    sleep (5);
	    break;
	  }
	
          default: {                       /* real error */
            syslog ((FACILITY | LOG_WARNING), "can't stat() checkpoint file.");
            syserr ("sms2mailgw: can't stat() checkpoint file");
	  }
	
        }                               /* switch (errno) */
      }                               /* while (stat (... */
      /* I have a checkpoint file - is it worth processing ? */
      if (filestat.st_mtime > lastchked) {
        /* waited long enough - this is the one */
	waiting = FALSE;
      }
      else {
        /* sleep for the rest of the interval */
        syslog ((FACILITY | LOG_NOTICE), "sync. lost - sleeping for 1/10th interval.");
	sleep (MBCHKINTERVAL / 10);
      }
    }                                  /* while (waiting) */
    /* now process the inbox file */
    syslog ((FACILITY | LOG_INFO), "now synchronized - starting mailbox run.");
    
    /* lock inbox file */
    ntry = 0;
    while (((lockf_desc = open (MBOX_LOCKF, (O_RDWR | O_CREAT | O_EXCL), 0444)) == -1) &&
          (ntry < MAXRETRIES)) {
      ntry++;
      sleep (2);
    }
    if (lockf_desc == -1) {
      syslog ((FACILITY | LOG_ERR), "can't lock the inbox file.");
      syserr ("sms2mailgw: can't lock the inbox file");
    }
    
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
    /* Inbox file now locked */
    inbox_is_locked = TRUE;
    
    /* extract mail and send it */
    nmsg = mailbox_run (localhost, defaultdomain);
    syslog ((FACILITY | LOG_NOTICE), "mailbox run finished - %d email(s) sent.",
           nmsg);
    
    /* unlock mailbox file -- clean lockfile */
    close (lockf_desc);
    inbox_is_locked = FALSE;
    if (unlink (MBOX_LOCKF) == -1) {
      syslog ((FACILITY | LOG_ERR), "can't remove the lock file.");
      syserr ("sms2mailgw: can't remove the lock file");
    }
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
    
    /* reset "last checked" time */
    lastchked = time (NULL);

    /* give the CPU some rest - wait for next mailbox check */
    sleeptime = (MBCHKINTERVAL - (time (NULL) - filestat.st_mtime) + 60);
    if (sleeptime < 0)
      sleeptime = MBCHKINTERVAL;
    sleep (sleeptime);
  }                                          /* while (1) */
  /*------------------------------------------Conclusions */
  /* let's clean what's allocated on the heap */
  free (localhost);
  free (defaultdomain);
  /*------------------------------------------End program */
  exit (0);
}                                              /* main () */

/*==========================================================
 * EOF : sms2mailgw.c
 *===================*/
