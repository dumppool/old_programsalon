/*==========================================================
 * Program : gw_stuff.c                    Project : smslink
 * Author  : Philippe Andersson.
 * Date    : 01/03/00
 * Version : 0.16b
 * Notice  : (c) Les Ateliers du Heron, 1998 for Scitex Europe, S.A.
 * Comment : Library of functions for the smslink sms2mail gateway.
 *
 * Modification History :
 * - 0.01b (19/08/99) : Initial release. Moved the mail gateway-
 *   specific functions from stuff.c over here.
 * - 0.02b (28/09/99) : Created mailbox_run().
 * - 0.03b (29/09/99) : Extensive rework. Added tkize_ibox_line(),
 *   reset_mail_struct() and parse_smail().
 * - 0.04b (04/10/99) : Added expand_addr().
 * - 0.05b (17/10/99) : Expanded parse_smail() extensively.
 * - 0.06b (19/10/99) : Debugged tkize_ibox_line(). Increased
 *   debugging output. Created shell for send_mail().
 * - 0.07b (20/10/99) : Added mkfromfield().
 * - 0.08b (21/10/99) : Added is_dotted_quad () and resolve().
 * - 0.09b (08/11/99) : Built dialog in send_mail(). Added
 *   slurp_n_catch().
 * - 0.10b (09/11/99) : Modified parse_smail() to provide a
 *   default subject field if the SMS doesn't contain one. Involved
 *   alter the parameters passed to the function. Cosmetics.
 * - 0.11b (12/11/99) : Improved send_mail() to free() the
 *   allocated space for the nicified date.
 * - 0.12b (30/11/99) : Added temp file creation to mailbox_run().
 * - 0.13b (24/02/00) : Completed the transfer routine to the
 *   new mailbox file in mailbox_run().
 * - 0.14b (26/02/00) : Made sure the lockfile (MBOX_LOCKF) was
 *   deleted on each fatal error, as well as on SIGTERM being
 *   caught (in mailgws_death()). Improved error reporting in
 *   various functions. Cosmetics.
 * - 0.15b (29/02/00) : Added functions to handle recepients
 *   lists (as part of struct email_msg). Heavily modified most
 *   functions (send_mail(), parse_smail(), expand_addr()) and
 *   created sub_tkize_field() to account for changes in the
 *   email_msg struct.
 * - 0.16b (01/03/00) : Replaced the "old" slurp_n_catch() by
 *   a new version inspired by get_gsm_answer() (cf. serv_stuff.c).
 *   This should be more robust and less sensitive to the amount
 *   of data sent back by the server (here: sendmail). Created
 *   the clean_field() function (forgotten when split expand_addr()
 *   from sub_tkize_field()).
 *========================================================*/

#include <unistd.h>
#include <stdio.h>                         /* for fprintf */
#include <stdlib.h>                  /* for errno & stuff */
#include <errno.h>
#include <string.h>
#include <syslog.h>
#include <netdb.h>                 /* for gethostbyname() */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>           /* for the struct timeval */
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/ioctl.h>            /* for the ioctl() call */
#ifdef LINUX_LC6
#  include <limits.h>                     /* for PATH_MAX */
#  include <linux/limits.h>
#else
#  include <limits.h>
#endif

#include "sms_serv.h"

/*========================================================*/
/* For debugging purposes only - comment out for normal compile */
/* #define INCL_DEBUG_CODE */

/*========================================================*/
void mailgws_death ()
{
  extern int inbox_is_locked;
  
  /* log it... */
  syslog ((FACILITY | LOG_INFO), "gateway exiting on SIGTERM.");
  
  /* remove inbox lock file if necessary */
  if (inbox_is_locked) {
    unlink (MBOX_LOCKF);
  }

  /* closes connection to the syslog daemon */
  closelog ();
  
  /* now exits gracefully */
  exit (0);
}                                     /* mailgws_death () */
/*========================================================*/
void rcpt_list_init (rcpt_list *list)
{
  list->head = NULL;
  list->tail = NULL;
}                                    /* rcpt_list_init () */
/*========================================================*/
int empty_rcpt_list (rcpt_list list)
{
  return (list.head == NULL);
}                                   /* empty_rcpt_list () */
/*========================================================*/
void rcpt_list_insert (rcpt_list *list, char *recepient)
{
  /* WARNING : the order of the elements might be relevent - let's
   * store them as they were in the header => avoid inserting at
   * list head. Do it at the tail. */
  
  int l;
  struct rcpt_item *element;

  /* alloc memory for new element */
  element = (struct rcpt_item *) malloc (sizeof (struct rcpt_item));
  if (!element) {
    syslog ((FACILITY | LOG_ERR), "can't malloc() for new RCPT entry.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc() for new RCPT entry");
  }
  
  /* initialize fields for new element */
  l = strlen (recepient);
  element->rcpt = (char *) malloc ((l + 1) * sizeof (char));
  if (!element->rcpt) {
    syslog ((FACILITY | LOG_ERR), "can't malloc() for new recepient string.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc() for new recepient string");
  }
  strcpy (element->rcpt, recepient);
  
  /* chain it in the list */
  if (empty_rcpt_list (*list)) {
    list->head = element;
    list->tail = element;
    element->next = NULL;
    element->prev = NULL;
  }
  else {
    element->next = NULL;
    element->prev = list->tail;
    list->tail->next = element;
    list->tail = element;
  }
}                                  /* rcpt_list_insert () */
/*========================================================*/
void free_rcpt_list (rcpt_list *list)
{
  struct rcpt_item *cursor;

  if (!empty_rcpt_list (*list)) {
    /* hop to element before last */
    cursor = list->tail->prev;
    /* now go back and clean behind */
    while (cursor != NULL) {
      free (cursor->next->rcpt);
      free (cursor->next);
      cursor->next = NULL;
      list->tail = cursor;
      cursor = cursor->prev;
    }                           /* while (cursor != NULL) */
  }                          /* if (!empty_rcpt_list (... */
  /* now clean last element and reset header */
  free (list->head->rcpt);
  free (list->head);
  list->head = NULL;
  list->tail = NULL;
}                                    /* free_rcpt_list () */
/*========================================================*/
#ifdef INCL_DEBUG_CODE
void print_rcpt_list (rcpt_list list)
{
  struct rcpt_item *cursor;

  if (!empty_rcpt_list (list)) {
    cursor = list.head;
    fprintf (stderr, "<%s>\n", cursor->rcpt);
    while (cursor->next != NULL) {
      cursor = cursor->next;
      fprintf (stderr, "<%s>\n", cursor->rcpt);
    }
  }
  else {
    fprintf (stderr, "sms2mailgw: empty recepient list.\n");
  }
}                                    /* print_acl_list () */
#endif
/*========================================================*/
int is_dotted_quad (char *string)
{
  int is_dq;
  char *s;
  int ntok = 0;
  char *ptok = NULL;
  long int ip_byte;
  char **endptr;
  char *dummyp;
  
  /*--------------------------------------Initializations */
  s = (char *) malloc ((strlen (string) + 1) * sizeof (char));
  if (! s) {
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc()");
  }
  strcpy (s, string);
  /*--------------------------------------------Main Loop */
  /* no point going any further if the 1st char. is not a digit */
  is_dq = isdigit (string[0]);
  if (is_dq) {
    ptok = strtok (s, ".");
    while (ptok != NULL) {
      ntok++;
#ifdef INCL_DEBUG_CODE
      fprintf (stderr, "got token #%d : <%s>\n", ntok, ptok);
#endif
      dummyp = ptok + strlen (ptok);
      endptr = &dummyp;
      ip_byte = strtol (ptok, endptr, 10);
      if (strlen (*endptr) != 0) {
#ifdef INCL_DEBUG_CODE
	fprintf (stderr, "error on token #%d : can't convert <%s>\n", ntok, *endptr);
#endif
	is_dq = FALSE;
      }
      ptok = strtok (NULL, ".");
    }
    if (ntok != 4) {
      is_dq = FALSE;
    }
  }                                         /* if (is_dq) */
  /*------------------------------------------Conclusions */
  free (s);
  /*-------------------------------------------------Exit */
  return (is_dq);
}                                    /* is_dotted_quad () */
/*========================================================*/
unsigned long int resolve (char *host)
/* return the host ip address in network format */
{
  struct hostent *h_ent;
  struct in_addr target_ip;
  char **addrs;
  char *scratch;
  
  if (is_dotted_quad (host)) {
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "I think I got an IP address\n");
#endif
    if (inet_aton (host, &target_ip) == 0)
      syslog ((FACILITY | LOG_ERR), "invalid server IP address (%s).", host);
      scratch = (char *) malloc ((MINIBUFF + 1) * sizeof (char));
      sprintf (scratch, "sms2mailgw: invalid server IP address (%s)", host);
      herror (scratch);
      free (scratch);
      unlink (MBOX_LOCKF);
      exit (1);
  }
  else {
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "I think I got a host name\n");
#endif
    if ((h_ent = gethostbyname (host)) == NULL) {
      syslog ((FACILITY | LOG_ERR), "can't resolve hostname (%s).", host);
      scratch = (char *) malloc ((MINIBUFF + 1) * sizeof (char));
      sprintf (scratch, "sms2mailgw: can't resolve hostname (%s)", host);
      herror (scratch);
      free (scratch);
      unlink (MBOX_LOCKF);
      exit (1);
    }
    /* lines below cf. "Beginning Linux Progr.", pp. 468-473 */
    addrs = h_ent->h_addr_list;
    target_ip = *(struct in_addr *)*addrs;
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "server IP address is: [%s]\n", inet_ntoa (target_ip));
#endif
  }                             /* if (isdigit (host[0])) */
  return (target_ip.s_addr);
}                                           /* resolve () */
/*========================================================*/
int tkize_ibox_line (char *l, struct inbox_line *tkl)
{
  char *token;
  char *scratch;
  
  /*--------------------------------------Initializations */
  /* copy input string to scratch space - we can't modify it */
  scratch = (char *) malloc ((strlen (l) + 1) * sizeof (char));
  if (! scratch) {
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc()");
  }
  scratch[0] = '\0';
  strcpy (scratch, l);
  
  /*--------------------------------------Parsing routine */
  /*...............................................Device */
  if ((token = strtok (scratch, ",")) == NULL) {
    return (-1);
  }
  strcpy (tkl->device, token);
  
  /*................................................MsgID */
  if ((token = strtok (NULL, ",")) == NULL) {
    return (-1);
  }
  tkl->msgid = atoi (token);
  
  /*..............................................FromGSM */
  if ((token = strtok (NULL, ",")) == NULL) {
    return (-1);
  }
  strcpy (tkl->fromgsm, token);
  
  /*.................................................Date */
  if ((token = strtok (NULL, ",")) == NULL) {
    return (-1);
  }
  strcpy (tkl->date, token);
  
  /*.................................................Time */
  if ((token = strtok (NULL, ",")) == NULL) {
    return (-1);
  }
  strcpy (tkl->time, token);
  
  /*.................................................Text */
  /* just grab the rest of the line */
  if ((token = strtok (NULL, "\0")) == NULL) {
    return (-1);
  }
  /* remove trailing LF */
  token[strlen (token) - 1] = '\0';
  dequote (token);
  strcpy (tkl->text, token);
  
  /*-------------------------------------------------Exit */
  free (scratch);
  return 0;                                    /* success */
}                                   /* tkize_ibox_line () */
/*========================================================*/
char *expand_addr (char *field, char *defdom)
{
  char *newstring;

  /*---------------------------------------Initialization */
  newstring = (char *) malloc ((BIGBUFF + 1) * sizeof (char));
  if (! newstring) {
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc()");
  }
  newstring[0] = '\0';
  
  /*---------------------------------Main processing loop */
  if (strchr (field, '@') == NULL) {
    sprintf (newstring, "%s@%s", field, defdom);
  }
  else {
    strcpy (newstring, field);
  }
  /*------------------------------------------Conclusions */
#ifdef INCL_DEBUG_CODE
  fprintf (stderr, "expanded field: [%s]\n", newstring);
#endif
  return (newstring);
}                                       /* expand_addr () */
/*========================================================*/
char *clean_field (char *field)
/* For fields that cannot be multi-part (Reply-to:), remove
 * the field header and any additional address. */
{
  char *ptr;
  
  /* The field for sure has a field header - skip it */
  shiftleft (field, 2);
  /* If the first char now is a space, skip that as well */
  if (field[0] == ' ') {
    shiftleft (field, 1);
  }
  /* If the field contains a comma, kill it and all that follows */
  if ((ptr = strchr (field, ',')) != NULL) {
    ptr[0] = '\0';
  }
  
  return (field);
}                                       /* clean_field () */
/*========================================================*/
int sub_tkize_field (rcpt_list *list, char *field, char *defdom)
{
  int nfields = 0;
  char *s;
  char *ptr;
  char *newstring;
  char *item;
  
  /*---------------------------------------Initialization */
  /* take a local copy of "field" to avoid it being modified */
  s = (char *) malloc ((strlen (field) + 1) * sizeof (char));
  if (! s) {
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc()");
  }
  s[0] = '\0';
  strcpy (s, field);
  ptr = s;
  
  /* s for sure has a field header ("T:" for inst.) - skip it */
  ptr += 2;
  /* if there was a blank between the header and the field, skip it too */
  if (ptr[0] == ' ') {
    ptr++;
  }
  
  /*---------------------------------Main processing loop */
  if ((item = strtok (ptr, ",")) == NULL) {
    /* field header w/o contents */
    free (s);
    return (nfields);
  }
  /* process first item */
  newstring = expand_addr (item, defdom);
  rcpt_list_insert (list, newstring);
  nfields++;
  free (newstring);
  
  /* now tokenize and process the rest */
  while ((item = strtok (NULL, ",")) != NULL) {
    /* process additional item(s) */
    newstring = expand_addr (item, defdom);
    rcpt_list_insert (list, newstring);
    nfields++;
    free (newstring);
  }                                        /* while (...) */
  /*------------------------------------------Conclusions */
  free (s);
  return (nfields);
}                                   /* sub_tkize_field () */
/*========================================================*/
char *mkfromfield (char *srcgsm, char *host, char *defdom)
{
  char *fromfield;
  
  /*--------------------------------------Initializations */
  fromfield = (char *) malloc ((BUFFSIZE + 1) * sizeof (char));
  if (! fromfield) {
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc()");
  }
  fromfield[0] = '\0';
  
  /*-------------------------------------------Processing */
  sprintf (fromfield, "%s%s@%s.%s", GWUSER, srcgsm, host, defdom);
  
  /*------------------------------------------Conclusions */
  return (fromfield);
}                                       /* mkfromfield () */
/*========================================================*/
void reset_mail_struct (struct email_msg *m)
{
  if (m->from) {
    free (m->from);
    m->from = NULL;
  }
  
  if (!empty_rcpt_list (m->to))
    free_rcpt_list (&(m->to));
  if (!empty_rcpt_list (m->cc))
    free_rcpt_list (&(m->cc));
  if (!empty_rcpt_list (m->bcc))
    free_rcpt_list (&(m->bcc));
  
  if (m->reply_to) {
    free (m->reply_to);
    m->reply_to = NULL;
  }
  if (m->subject) {
    free (m->subject);
    m->subject = NULL;
  }
  if (m->body) {
    free (m->body);
    m->body = NULL;
  }
}                                 /* reset_mail_struct () */
/*========================================================*/
int parse_smail (struct inbox_line *ibl, struct email_msg *m, char *host,
                 char *domain)
{
  char *s;
  char *s_saved;
  char *ptr;
  char *s_end;
  int end_found;
  char field_header;
  char end_marker;
  
  /*--------------------------------------Initializations */
  /* struct email fields */
  m->from = NULL;
  rcpt_list_init (&(m->to));
  rcpt_list_init (&(m->cc));
  rcpt_list_init (&(m->bcc));
  m->reply_to = NULL;
  m->subject = NULL;
  m->body = NULL;
  
  /* copy sms string to scratch space - we can't modify it */
  s = (char *) malloc ((MAXMSGLEN + 1) * sizeof (char));
  if (! s) {
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc()");
  }
  s[0] = '\0';
  strcpy (s, ibl->text);
  s_saved = s;
#ifdef INCL_DEBUG_CODE
  fprintf (stderr, "\ns as received:\n[%s]\n", s);
#endif
  
  /*--------------------------------------Main Processing */
  /* First field have to be To: */
  if ((toupper (s[0]) == 'T') && (s[1] == ':')) {
    /* if space between : and address, remove it */
    if (s[2] == ' ') {
      ptr = (s + 2);
      shiftleft (ptr, 1);
    }
    end_found = FALSE;
    ptr = s;
    while (!end_found) {
      if ((ptr = strchr (ptr, ' ')) == NULL) {
        /* To: was the only field */
        syslog ((FACILITY | LOG_ERR), "can't parse, nothing more than To: field.");
	free (s_saved);
	return (-1);
      }
      if ((ptr[-1] == ',') && (ptr[0] != '\0')) {
        /* we have a multipart to: field */
	ptr++;
      }
      else {
        end_found = TRUE;
	s_end = ptr;
      }
    }                               /* while (!end_found) */
    if (ptr[0] != '\0') {
      ptr++;
    }
    s_end[0] = '\0';
    /* sub-tokenize it and save it */
#ifdef INCL_DEBUG_CODE
    fprintf (stderr, "to field: [%s]\n", s);
#endif
    sub_tkize_field (&(m->to), s, domain);
    
    /* reset s to begin of next field */
    s = ptr;
    
    /* now loop to process the rest */
    while (s[0]) {
      field_header = toupper (s[0]);
      if ((strchr (FIELD_HEADERS, field_header) != NULL) && (s[1] == ':')) {
        /* we have a valid header */
	switch (field_header) {
	  case 'T' : {
	    end_marker = ' ';
	    break;
	  }
	  
	  case 'C' : {
	    end_marker = ' ';
	    break;
	  }
	  
	  case 'R' : {
	    if (m->reply_to) {
	      free (m->reply_to);
	    }
	    end_marker = ' ';
	    break;
	  }
	  
	  case 'B' : {
	    end_marker = ' ';
	    break;
	  }
	  
	  case 'F' : {
	    if (m->from) {
	      free (m->from);
	    }
	    end_marker = ' ';
	    break;
	  }
	  
	  case 'S' : {
	    if (m->subject) {
	      free (m->subject);
	    }
	    end_marker = '#';
	    break;
	  }
	}                        /* switch (field_header) */
	/* if space between : and address, remove it */
	if (s[2] == ' ') {
	  ptr = (s + 2);
	  shiftleft (ptr, 1);
	}
	end_found = FALSE;
	ptr = s;
	while (!end_found) {
	  if ((ptr = strchr (ptr, end_marker)) == NULL) {
	    /* we reached end-of-string */
	    end_found = TRUE;
	    ptr = s + strlen (s);
	    s_end = ptr;
	  }
	  else {
	    if ((ptr[-1] == ',') && (ptr[0] != '\0')) {
	      /* multipart field */
	      ptr++;
	    }
	    else {
	      end_found = TRUE;
	      s_end = ptr;
	    }
	  }                  /* if (end_marker not found) */
	}                           /* while (!end_found) */
	if (ptr[0] != '\0') {
	  ptr++;
	}
	s_end[0] = '\0';
	/* assigns the right field */
	switch (field_header) {
	  case 'T' : {
#ifdef INCL_DEBUG_CODE
            fprintf (stderr, "field: [%s]\n", s);
#endif
            sub_tkize_field (&(m->to), s, domain);
	    break;
	  }
	  
	  case 'C' : {
#ifdef INCL_DEBUG_CODE
            fprintf (stderr, "field: [%s]\n", s);
#endif
            sub_tkize_field (&(m->cc), s, domain);
	    break;
	  }
	  
	  case 'R' : {
#ifdef INCL_DEBUG_CODE
            fprintf (stderr, "field: [%s]\n", s);
#endif
            clean_field (s);
	    m->reply_to = expand_addr (s, domain);
	    break;
	  }
	  
	  case 'B' : {
#ifdef INCL_DEBUG_CODE
            fprintf (stderr, "field: [%s]\n", s);
#endif
            sub_tkize_field (&(m->bcc), s, domain);
	    break;
	  }
	  
	  case 'F' : {
#ifdef INCL_DEBUG_CODE
            fprintf (stderr, "field: [%s]\n", s);
#endif
            clean_field (s);
            m->from = expand_addr (s, domain);
	    break;
	  }
	  
	  case 'S' : {
#ifdef INCL_DEBUG_CODE
            fprintf (stderr, "field: [%s]\n", s);
#endif
	    /* remove field header */
	    s += 2;
	    /* if ':' is followed by ' ', remove it as well */
	    if ((s[0]) && (s[0] == ' ')) {
	      s++;
	    }
	    m->subject = (char *) malloc ((strlen (s) + 1) * sizeof (char));
	    if (! m->subject) {
	      syslog ((FACILITY | LOG_ERR), "can't malloc().");
              unlink (MBOX_LOCKF);
	      syserr ("sms2mailgw: can't malloc()");
	    }
	    m->subject[0] = '\0';
	    strcpy (m->subject, s);
	    break;
	  }
	}                        /* switch (field_header) */
	s = ptr;
      }
      else {
        /* the rest is considered BODY */
	if (s[0]) {
#ifdef INCL_DEBUG_CODE
          fprintf (stderr, "body: [%s]\n", s);
#endif
	  m->body = (char *) malloc ((strlen (s) + 1) * sizeof (char));
	  if (! m->body) {
	    syslog ((FACILITY | LOG_ERR), "can't malloc().");
            unlink (MBOX_LOCKF);
	    syserr ("sms2mailgw: can't malloc()");
	  }
	  m->body[0] = '\0';
	  strcpy (m->body, s);
	  ptr = s + strlen (s);
	  s = ptr;
	}                                    /* if (s[0]) */
      }                        /* if (valid header found) */
    }                                     /* while (s[0]) */
  }
  else {
    /* can't even find To: field */
    syslog ((FACILITY | LOG_ERR), "can't parse, can't find To: field.");
    free (s_saved);
    return (-1);
  }                           /* if ('T' followed by ':') */
  
  /*--------------------------Make sure we have a subject */
  if (! m->subject) {
    m->subject = (char *) malloc ((MINIBUFF + 1) * sizeof (char));
    if (! m->subject) {
      syslog ((FACILITY | LOG_ERR), "can't malloc().");
      unlink (MBOX_LOCKF);
      syserr ("sms2mailgw: can't malloc()");
    }
    m->subject[0] = '\0';
    sprintf (m->subject, "An SMS for you from GSM number %s.", ibl->fromgsm);
  }
  /*-------------------------------------------------Exit */
  free (s_saved);
  return 0;                                    /* success */
}                                       /* parse_smail () */
/*========================================================*/
int slurp_n_catch (int fd, int resptime, char *catch)
/* slurps n_lines lines from the input stream, and return a bool
value telling whether catch was found in any of those lines. */
{
  int nread, retval, previous, found;
  fd_set inputs;
  struct timeval timeout;
  char *buffer;
  
  /*--------------------------------------Initializations */
  nread = previous = 0;
  found = FALSE;
  
  FD_ZERO (&inputs);
  FD_SET (fd, &inputs);
  
  timeout.tv_sec = 10;
  timeout.tv_usec = 0;
  
  /* wait for data to arrive on the line */
  retval = select (FD_SETSIZE, &inputs, NULL, NULL, &timeout);
  switch (retval) {
    case 0:
      syslog ((FACILITY | LOG_WARNING), "timeout while waiting for server reply.");
      break;
    
    case -1:
      syslog ((FACILITY | LOG_ERR), "call to select() failed.");
      unlink (MBOX_LOCKF);
      syserr ("sms2mailgw: call to select() failed");
      break;
      
    default:
      if (FD_ISSET (fd, &inputs)) {
        /* first wait for all data to be ready */
	ioctl (fd, FIONREAD, &nread);
	while (nread != previous) {
	  sleep (resptime);
	  previous = nread;
	  ioctl (fd, FIONREAD, &nread);
	}                    /* while (nread != previous) */
	/* we know what's the data size - alloc space for it */
	buffer = (char *) malloc ((nread + 1) * sizeof (char));
	if (!buffer) {
          syslog ((FACILITY | LOG_ERR), "can't allocate buffer space.");
          unlink (MBOX_LOCKF);
	  syserr ("sms2mailgw: can't allocate buffer space");
	}
	/* now we can finally read this data */
	nread = read (fd, buffer, nread);
	switch (nread) {
	  case 0:
	    /* EOF */
	    buffer[nread] = '\0';
	    syslog ((FACILITY | LOG_WARNING), "no data from server waiting for [%s].",
	            catch);
	    break;
	    
	  case -1:
            syslog ((FACILITY | LOG_ERR), "error while reading answer from server.");
            unlink (MBOX_LOCKF);
	    syserr ("sms2mailgw: error while reading answer from server");
	    break;
	    
	  default:
	    buffer[nread] = '\0';
#ifdef INCL_DEBUG_CODE
	    fprintf (stderr, "pid<%d> Got : [%s] (%d char)\n", getpid (), buffer, nread);
#endif
	    /* here we could pre-process it (remove Ctrl-Z) */
	    /* look for catch */
            found = (strstr (buffer, catch) != NULL);
	    break;
	}                               /* switch (nread) */
      }                                /* if (FD_ISSET... */
      free (buffer);
      break;
  }                                    /* switch (retval) */
  /*------------------------------------------------------*/
#ifdef INCL_DEBUG_CODE
  fprintf (stderr, "catch found: [%s]\n", found ? "yes" : "no");
#endif
  /*----------------------------------Conclusion and exit */
  return (found);
}                                     /* slurp_n_catch () */
/*========================================================*/
int send_mail (struct email_msg *m, struct inbox_line *ibl, char *mailhost,
               char *localhost, char *defdom)
{
  struct servent *sent;
  struct in_addr server_ip;
  struct sockaddr_in sockaddr;
  struct rcpt_item *cursor;
  int sockfd;
  int addrlen;
  char *cmdline;
  char *nd;

#ifdef INCL_DEBUG_CODE
  fprintf (stderr, "===========================================\n");
  if (m->from)
    fprintf (stderr, "From: %s\n", m->from);
  if (!empty_rcpt_list (m->to)) {
    fprintf (stderr, "To: recepients\n");
    print_rcpt_list (m->to);
  }
  if (!empty_rcpt_list (m->cc)) {
    fprintf (stderr, "CC: recepients\n");
    print_rcpt_list (m->cc);
  }
  if (!empty_rcpt_list (m->bcc)) {
    fprintf (stderr, "BCC: recepients\n");
    print_rcpt_list (m->bcc);
  }
  if (m->reply_to)
    fprintf (stderr, "Reply-To: %s\n", m->reply_to);
  if (m->subject)
    fprintf (stderr, "Subject: %s\n", m->subject);
  if (m->body)
    fprintf (stderr, "%s\n", m->body);
  fprintf (stderr, "===========================================\n");
#endif
    
  /*--------------------------------------Initializations */
  cmdline = (char *) malloc ((BUFFSIZE + 1) * sizeof (char));
  if (!cmdline) {    
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc()");
  }
  cmdline[0] = '\0';

  /* first resolve server name */
  server_ip.s_addr = resolve (mailhost);
  
  /* get the port number we should connect to */
  if ((sent = getservbyname ("smtp", "tcp")) == NULL) {
    syslog ((FACILITY | LOG_ERR), "can't get service port info.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't get service port info");
  }
#ifdef INCL_DEBUG_CODE
  fprintf (stderr, "found port <%d> for service smtp\n", ntohs (sent->s_port));
#endif
    
  /* create the socket */
  if ((sockfd = socket (AF_INET, SOCK_STREAM, 0)) == -1) {
    syslog ((FACILITY | LOG_ERR), "can't create socket.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't create socket");
  }
  
  /* build the server socket address parameters */
  sockaddr.sin_family = AF_INET;
  sockaddr.sin_port = sent->s_port;
  sockaddr.sin_addr.s_addr = server_ip.s_addr;
  addrlen = sizeof (sockaddr);
  
  /* now connect to the server */
  if (connect (sockfd, (struct sockaddr *)&sockaddr, addrlen) == -1) {
    syslog ((FACILITY | LOG_ERR), "can't connect to server.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't connect to server");
  }
    
  /*......................................Start of dialog */
  /* slurp server announce and catch prompt */
  if (!slurp_n_catch (sockfd, 1, "220")) {
    syslog ((FACILITY | LOG_ERR), "can't get server announce.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't get server announce");
  }
    
  /* set sender ID - get ok */
  sprintf (cmdline, "HELO %s.%s\n", localhost, defdom);
  tellsock (sockfd, cmdline);

  if (!slurp_n_catch (sockfd, 1, "250")) {
    syslog ((FACILITY | LOG_ERR), "failed on HELO command.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: failed on HELO command");
  }
    
  /* send from: field */
  sprintf (cmdline, "MAIL FROM: %s\n", m->from);
  tellsock (sockfd, cmdline);

  if (!slurp_n_catch (sockfd, 1, "250")) {
    syslog ((FACILITY | LOG_ERR), "failed on MAIL command.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: failed on MAIL command");
  }
  
  /*. . . . . . . . . . . . . Loop through all recepients */
  /* To: field */
  if (!empty_rcpt_list (m->to)) {
    cursor = m->to.head;
    sprintf (cmdline, "RCPT TO: %s\n", cursor->rcpt);
    tellsock (sockfd, cmdline);

    if (!slurp_n_catch (sockfd, 1, "250")) {
      syslog ((FACILITY | LOG_ERR), "failed on RCPT command.");
      unlink (MBOX_LOCKF);
      syserr ("sms2mailgw: failed on RCPT command");
    }
    while ((cursor = cursor->next) != NULL) {
      sprintf (cmdline, "RCPT TO: %s\n", cursor->rcpt);
      tellsock (sockfd, cmdline);

      if (!slurp_n_catch (sockfd, 1, "250")) {
	syslog ((FACILITY | LOG_ERR), "failed on RCPT command.");
	unlink (MBOX_LOCKF);
	syserr ("sms2mailgw: failed on RCPT command");
      }
    }                                      /* while (...) */
  }                             /* if (not empty to-list) */
  
  /* CC: field */
  if (!empty_rcpt_list (m->cc)) {
    cursor = m->cc.head;
    sprintf (cmdline, "RCPT TO: %s\n", cursor->rcpt);
    tellsock (sockfd, cmdline);

    if (!slurp_n_catch (sockfd, 1, "250")) {
      syslog ((FACILITY | LOG_ERR), "failed on RCPT command.");
      unlink (MBOX_LOCKF);
      syserr ("sms2mailgw: failed on RCPT command");
    }
    while ((cursor = cursor->next) != NULL) {
      sprintf (cmdline, "RCPT TO: %s\n", cursor->rcpt);
      tellsock (sockfd, cmdline);

      if (!slurp_n_catch (sockfd, 1, "250")) {
	syslog ((FACILITY | LOG_ERR), "failed on RCPT command.");
	unlink (MBOX_LOCKF);
	syserr ("sms2mailgw: failed on RCPT command");
      }
    }                                      /* while (...) */
  }                             /* if (not empty cc-list) */

  /* BCC: field */
  if (!empty_rcpt_list (m->bcc)) {
    cursor = m->bcc.head;
    sprintf (cmdline, "RCPT TO: %s\n", cursor->rcpt);
    tellsock (sockfd, cmdline);

    if (!slurp_n_catch (sockfd, 1, "250")) {
      syslog ((FACILITY | LOG_ERR), "failed on RCPT command.");
      unlink (MBOX_LOCKF);
      syserr ("sms2mailgw: failed on RCPT command");
    }
    while ((cursor = cursor->next) != NULL) {
      sprintf (cmdline, "RCPT TO: %s\n", cursor->rcpt);
      tellsock (sockfd, cmdline);

      if (!slurp_n_catch (sockfd, 1, "250")) {
	syslog ((FACILITY | LOG_ERR), "failed on RCPT command.");
	unlink (MBOX_LOCKF);
	syserr ("sms2mailgw: failed on RCPT command");
      }
    }                                      /* while (...) */
  }                            /* if (not empty bcc-list) */

  /*. . . . . . . . . . . . . . . . . . . . . . . . . . . */

  /* now send mail data */
  sprintf (cmdline, "DATA\n");
  tellsock (sockfd, cmdline);

  if (!slurp_n_catch (sockfd, 1, "354")) {
    syslog ((FACILITY | LOG_ERR), "failed on DATA command.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: failed on DATA command");
  }
  
  /* From: field as "comment" */
  if (m->from) {
    sprintf (cmdline, "From: %s\n", m->from);
    tellsock (sockfd, cmdline);
  }
  /* To: field as "comment" */
  if (!empty_rcpt_list (m->to)) {
    cursor = m->to.head;
    sprintf (cmdline, "To: %s", cursor->rcpt);

    while ((cursor = cursor->next) != NULL) {
      strcat (cmdline, ", ");
      strcat (cmdline, cursor->rcpt);
    }                                      /* while (...) */

    strcat (cmdline, "\n");
    tellsock (sockfd, cmdline);
  }                             /* if (not empty to-list) */
  /* CC: field as "comment" */
  if (!empty_rcpt_list (m->cc)) {
    cursor = m->cc.head;
    sprintf (cmdline, "Cc: %s", cursor->rcpt);

    while ((cursor = cursor->next) != NULL) {
      strcat (cmdline, ", ");
      strcat (cmdline, cursor->rcpt);
    }                                      /* while (...) */

    strcat (cmdline, "\n");
    tellsock (sockfd, cmdline);
  }                             /* if (not empty to-list) */
  /* BCC: field as "comment" */
  if (!empty_rcpt_list (m->bcc)) {
    cursor = m->bcc.head;
    sprintf (cmdline, "Bcc: %s", cursor->rcpt);

    while ((cursor = cursor->next) != NULL) {
      strcat (cmdline, ", ");
      strcat (cmdline, cursor->rcpt);
    }                                      /* while (...) */

    strcat (cmdline, "\n");
    tellsock (sockfd, cmdline);
  }                             /* if (not empty to-list) */
  /* Reply-to: field */
  if (m->reply_to) {
    sprintf (cmdline, "Reply-to: %s\n", m->reply_to);
    tellsock (sockfd, cmdline);
  }
  /* Subject: field */
  if (m->subject) {
    sprintf (cmdline, "Subject: %s\n", m->subject);
    tellsock (sockfd, cmdline);
  }
  /* Message Body */
  if (m->body) {
    sprintf (cmdline, "%s\n", m->body);
    tellsock (sockfd, cmdline);
  }
  
  /* add some system info */
  sprintf (cmdline, "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n");
  tellsock (sockfd, cmdline);
  sprintf (cmdline, "This mail has been relayed to you by SMSLink's sms2mailgw\n");
  tellsock (sockfd, cmdline);
  sprintf (cmdline, "ver. %s (%s) running on %s.%s.\n", SMS_GW_VERSION,
           SMS_GW_DATE, localhost, defdom);
  tellsock (sockfd, cmdline);
  nd = nicedate (ibl->date);
  sprintf (cmdline, "The original message was received on %s at %s\n",
           nd, ibl->time);
  tellsock (sockfd, cmdline);
  sprintf (cmdline, "from the GSM number [%s] through device [%s].\n", ibl->fromgsm,
           ibl->device);
  tellsock (sockfd, cmdline);
  sprintf (cmdline, "The message ID was [%d].\n", ibl->msgid);
  tellsock (sockfd, cmdline);
  
  /* now close the DATA section: one dot only */
  sprintf (cmdline, ".\n");
  tellsock (sockfd, cmdline);

  if (!slurp_n_catch (sockfd, 1, "250")) {
    syslog ((FACILITY | LOG_ERR), "failed on DATA transfer.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: failed on DATA transfer");
  }
  
  /* send the QUIT command */
  sprintf (cmdline, "QUIT\n");
  tellsock (sockfd, cmdline);

  if (!slurp_n_catch (sockfd, 1, "221")) {
    syslog ((FACILITY | LOG_ERR), "failed on QUIT command.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: failed on QUIT command");
  }
  
  /*------------------------------------------Conclusions */
  /* close socket */
  if (close (sockfd) == -1) {
    syslog ((FACILITY | LOG_ERR), "can't close socket.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't close socket");
  }
  
  /* free what's need to be */
  free (nd);
  
  /* leave */
  return (0);
}                                         /* send_mail () */
/*========================================================*/
int mailbox_run (char *localhost, char *defaultdomain)
{
  struct email_msg email;
  struct inbox_line tkline;            /* tokenized line */
  char *line;                                /* raw line */
  char *buffline;                       /* transfer line */
  FILE *inbox;
  FILE *newbox;
  int anymailfound = FALSE;
  int filecreatedyet = FALSE;
  int msg_count = 0;
  int lineismail;
  int lcursor;
  int nline = 0;
  char *cmd;
  char *newboxname;
  
  /*---------------------------------Initialize variables */
  line = (char *) malloc ((BIGBUFF + 1) * sizeof (char));
  if (! line) {
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc()");
  }
  line[0] = '\0';
  buffline = (char *) malloc ((BIGBUFF + 1) * sizeof (char));
  if (! buffline) {
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc()");
  }
  buffline[0] = '\0';
  cmd = (char *) malloc ((BUFFSIZE + 1) * sizeof (char));
  if (! cmd) {
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc()");
  }
  cmd[0] = '\0';
  newboxname = (char *) malloc ((PATH_MAX + 1) * sizeof (char));
  if (! newboxname) {
    syslog ((FACILITY | LOG_ERR), "can't malloc().");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't malloc()");
  }
  newboxname[0] = '\0';
  sprintf (newboxname, "%s.tmp.%d", MBOX_FILE, getpid());
  /*--------------------------------------------Open file */
  if ((inbox = fopen (MBOX_FILE, "r")) == NULL) {
    syslog ((FACILITY | LOG_ERR), "can't fopen() inbox file.");
    unlink (MBOX_LOCKF);
    syserr ("sms2mailgw: can't fopen() inbox file");
  }
  /*----------------------Read file and process each line */
  while (fgets (line, BIGBUFF, inbox) != NULL) {
    nline++;
    /* tokenize line to fill a struct inbox_line */
    if (tkize_ibox_line (line, &tkline) == -1) {
      syslog ((FACILITY | LOG_ERR), "inbox corruption - can't parse line %d.", nline);
      unlink (MBOX_LOCKF);
      syserr ("sms2mailgw: inbox corruption - can't parse line");
    }
    
    /* is it a mail message ? */
    if ((toupper (tkline.text[0]) == 'T') && (tkline.text[1] == ':')) {
      if (parse_smail (&tkline, &email, localhost, defaultdomain) == -1) {
        /* reject line after all */
	lineismail = FALSE;
	/* log it */
        syslog ((FACILITY | LOG_NOTICE), "inbox line #%d don't comply with protocol.",
	       nline);
      }
      else {
        lineismail = TRUE;
        anymailfound = TRUE;
	if (!email.from) {
	  email.from = mkfromfield (tkline.fromgsm, localhost, defaultdomain);
	}
        send_mail (&email, &tkline, MAILHOST, localhost, defaultdomain);
	reset_mail_struct (&email);
        msg_count++;
      }
    }
    else {
      lineismail = FALSE;
    }                              /* if (it is an email) */
    if (anymailfound) {
      if (!filecreatedyet) {
        /* open new inbox file */
	if ((newbox = fopen (newboxname, "w")) == NULL) {
	  syslog ((FACILITY | LOG_ERR), "can't fopen() temp inbox file.");
          unlink (MBOX_LOCKF);
	  syserr ("sms2mailgw: can't fopen() temp inbox file");
	}
        filecreatedyet = TRUE;
	/* transfer up to current line - current not included */
        lcursor = 1;
        /* "rewind" input file */
        if (fseek (inbox, (long) 0, SEEK_SET) == -1) {
	  syslog ((FACILITY | LOG_ERR), "can't fseek() on inbox file.");
          unlink (MBOX_LOCKF);
	  syserr ("sms2mailgw: can't fseek() on inbox file");
        }
        while (lcursor < nline) {
          if (fgets (buffline, BIGBUFF, inbox) == NULL) {
	    syslog ((FACILITY | LOG_ERR), "can't read from inbox file.");
            unlink (MBOX_LOCKF);
	    syserr ("sms2mailgw: can't read from inbox file");
          }
          if (fputs (buffline, newbox) == EOF) {
	    syslog ((FACILITY | LOG_ERR), "can't write to new inbox file.");
            unlink (MBOX_LOCKF);
	    syserr ("sms2mailgw: can't write to new inbox file");
          }
          lcursor++;
        }                      /* while (lcursor < nline) */
        /* re-read line #nline to skip it */
        if (fgets (buffline, BIGBUFF, inbox) == NULL) {
	  syslog ((FACILITY | LOG_ERR), "can't read from inbox file.");
          unlink (MBOX_LOCKF);
	  syserr ("sms2mailgw: can't read from inbox file");
        }
      }                            /* if (msg_count == 1) */
      if (! lineismail) {
        /* transfer current line to new file */
        if (fputs (line, newbox) == EOF) {
	  syslog ((FACILITY | LOG_ERR), "can't write to new inbox file.");
          unlink (MBOX_LOCKF);
	  syserr ("sms2mailgw: can't write to new inbox file");
        }
      }                              /* if (! lineismail) */
    }                                /* if (anymailfound) */
  }                                    /* while (fgets... */
  /*------------------------------Close file and conclude */
  fclose (inbox);
  if (anymailfound) {
    fclose (newbox);
    /* now mv newbox inbox */
    sprintf (cmd, "mv %s %s", newboxname, MBOX_FILE);
    if (system (cmd) != 0) {
      syslog ((FACILITY | LOG_ERR), "can't move new inbox file - system() failed.");
      unlink (MBOX_LOCKF);
      syserr ("sms2mailgw: can't move new inbox file - system() failed");
    }
  }
  
  /* free what's needs to be */
  free (line);
  free (buffline);
  free (cmd);
  free (newboxname);
  
  return (msg_count);
}                                       /* mailbox_run () */
/*==========================================================
 * EOF : gw_stuff.c
 *===================*/

