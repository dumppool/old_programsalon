/* config.h.  Generated automatically by configure.  */
#ifndef CONFIG_H
#define CONFIG_H

/* Define one of these depending on which malloc wrapper you want to use. */
/* #undef USE_GWMEM_NATIVE */
#define USE_GWMEM_CHECK 1
/* #undef USE_GWMEM_SLOW */

/* Define if you want information about lock collisions to be collected.
 * These are useful for finding performance bottlenecks. */
/* #undef MUTEX_STATS */

/* Define if you want log file timestamps in localtime instead of GMT. */
/* #undef LOG_TIMESTAMP_LOCALTIME */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if your compiler supports the __func__ magic symbol. This is
   part of C99. */
#define HAVE___FUNC__ 1

/* Define if your compiler supports the __FUNCTION__ magic symbol. */
#define HAVE___FUNCTION__ 1

/* Make sure __func__ does something useful. */
#if defined(HAVE___FUNC__)
    /* Nothing to do. Life is so wonderful. */
#elif defined(HAVE___FUNCTION__)
    #define __func__ __FUNCTION__
#else
    #define __func__ "unknown"
#endif

/* Define if you have getopt.h. */
#define HAVE_GETOPT_H 1

/* Define if you have getopt(3). */
/* #undef HAVE_GETOPT */

/* Define if you have a declaration for getopt(3) in <stdio.h>. */
/* #undef HAVE_GETOPT_IN_STDIO_H */

/* Define if you have a declaration for getopt(3) in <unistd.h>. */
#define HAVE_GETOPT_IN_UNISTD_H 1

/* Define if you have getopt_long(3). */
#define HAVE_GETOPT_LONG 1

/* the VERSION symbol - for older autoconfs */
#define VERSION "cvs"

/* WMLScript debugging. */
/* #undef WS_DEBUG */

/* Define if you have the gettimeofday function.  */
#define HAVE_GETTIMEOFDAY 1

/* Define if you have the select function.  */
#define HAVE_SELECT 1

/* Define if you have the socket function.  */
#define HAVE_SOCKET 1

/* Define if you have the <fcntl.h> header file.  */
/* #undef HAVE_FCNTL_H */

/* Define if you have the <pthread.h> header file.  */
#define HAVE_PTHREAD_H 1

/* Define if you have the <sys/ioctl.h> header file.  */
#define HAVE_SYS_IOCTL_H 1

/* Define if you have the <sys/types.h> header file.  */
#define HAVE_SYS_TYPES_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the <sys/poll.h> header file.  */
#define HAVE_SYS_POLL_H 1

/* Define if you have the m library (-lm).  */
#define HAVE_LIBM 1

/* Define if you have the nsl library (-lnsl).  */
#define HAVE_LIBNSL 1

/* Define if you have the pthread library (-lpthread).  */
#define HAVE_LIBPTHREAD 1

/* Define if you have the socket library (-lsocket).  */
/* #undef HAVE_LIBSOCKET */

/* Define if you have the xml library (-lxml).  */
/* #undef HAVE_LIBXML */

/* Define if you have the z library (-lz).  */
/* #undef HAVE_LIBZ */

/* Define if there is a socklen_t in <sys/socket.h> */
#define HAVE_SOCKLEN_T 1

/* Define if the PAM headers are on the local machine */
/* #undef HAVE_SECURITY_PAM_APPL_H */

/* Define if you want to turn off assertion checking */
/* #undef NO_GWASSERT */

/* Define if you have <syslog.h>.  */
#define HAVE_SYSLOG_H 1

/* Define if you have and want to use the ssl library (-lssl) */
#define HAVE_LIBSSL 1

/* Defined if we're using OpenSSL WTLS */
/* #undef HAVE_WTLS_OPENSSL */

#endif
