/******************************************************************************
 *
 * Copyright Jill R. Goldschneider, 1998
 *
 * This work was partially supported by a NASA Graduate Student
 * Fellowship in Global Change Research, an NSF Young Investigator Award,
 * and U.~S. Army Research Grant DAAH004-96-1-0255.
 *
 *****************************************************************************/

/******************************************************************************
 *
 * FILE          wpt.h
 * AUTHOR        Jill R. Goldschneider
 * DATE          February 1997
 * REVISIONS     February 1998 - update documentation
 * DESCRIPTION   structures, variable and function declarations, definitions
 *
 *****************************************************************************/
#include <stdio.h>
#include <math.h>

#define DATATYPE         double
#define DISTTYPE         double
#define BOOLEAN          int
#define TRUE             1
#define FALSE            0
#define NAME_MAX         100

#define DEF_treedim      4
#define DEF_treelevels   3
#define DEF_rate         0.0
#define DEF_children     4
#define DEF_depth        3

#define USAGE            "Usage:"
#define HOWTOUSE_WPT     "-c codebook_list -l decomposition_level -d tree_dimension -r rate"
#define NOTFOUND         "not found"
#define NOTOPTION        "unknown option"
#define NOMEMORY         "insufficient memory"
#define NOREAD           "error reading data"
#define NOWRITE          "error writing data"
#define NOTREE           "tree structure error"
#define NODATA           "insufficient data"
#define AND              "and"
#define ARESAME          "are identical"
#define ROUNDERROR       "possible rounding error"

#define ABORT_WPT        "codebook not generated"
#define HALT_WPT         "unable to extend tree"

#define DEF_codebookname ""
#define DEF_inputname    ""
#define DEF_outputname   ""
#define DEF_subtreename  ""

struct list_struct
{
  struct list_struct   *next;
  long                 	subtree_number;
  double               	lambda;
  double               	rate;
  double               	distortion;
  long                 	nodes;
};

/******************************************************************************
 * DOCUMENTATION ********************************************************
 ******************************************************************************
   NAME SubtreeList

   TYPE typedef

   DESCRIPTION List structure for nested PTSVQ's.

   ARGUMENTS
      ARG  next               the next PTSVQ
      ARG  subtree_number     the PTSVQ identifier
      ARG  lambda             the left slope of the PTSVQ
      ARG  rate               the rate of the PTSVQ
      ARG  distortion         the distortion of the PTSVQ
      ARG  nodes              the number of nodes in the PTSVQ

   AUTHOR Jill R. Goldschneider

******************************************************************************/

typedef struct list_struct SubtreeList
/*
{
  struct list_struct   *next;
  long                 	subtree_number;
  double               	lambda;
  double               	rate;
  double               	distortion;
  long                 	nodes;
}
 */
;
struct tree_struct
{
  struct tree_struct   *parent;
  struct tree_struct  **child;
  double                distortion;
  double                rate;
  double                lambda_min;
  BOOLEAN               split;
  int                   depth;
  int                   child_id;
  SubtreeList          *data;
};

/******************************************************************************
 * DOCUMENTATION ********************************************************
 ******************************************************************************
   NAME TreeNode

   TYPE typedef

   DESCRIPTION $M$-ary tree node structure for WPT systematic joint
   best-basis selection and optimal bit allocation.

   ARGUMENTS
      ARG  parent       the parent node
      ARG  child        the child nodes
      ARG  distortion   the branch distortion
      ARG  rate         the branch rate
      ARG  lambda_min   minimum slope of branch best-bases/optimal bit allocation
      ARG  split        whether to use the current node or the children
      ARG  depth        the tree depth of the node (root has zero depth)
      ARG  child_id     the $n$th child
      ARG  data         the list containing the node's subband's quantizer data

   AUTHOR Jill R. Goldschneider

******************************************************************************/

typedef struct tree_struct TreeNode
/* Yuck
{
  struct tree_struct   *parent;
  struct tree_struct  **child;
  double                distortion;
  double                rate;
  double                lambda_min;
  BOOLEAN               split;
  int                   depth;
  int                   child_id;
  SubtreeList          *data;
}
 */
;

/******************************************************************************
 *
 *   function calls
 *
 *****************************************************************************/

/* node_util.c */
TreeNode  *create_root();
TreeNode  *newchild(TreeNode *parent, int id);

/* wpt_util.c */
BOOLEAN    construct_tree(TreeNode *node, char *codebookname);
void       map_tree(TreeNode *node, FILE *outputfile, char *codebookname);
void       encode_tree(TreeNode *node, FILE *outputfile, char *codebookname);
void       unblock_tree(TreeNode *node, FILE *outputfile);
void       rebuild_tree(TreeNode *node, FILE *outputfile);

/* prune_util.c */
void       initialize_tree(TreeNode *node);
TreeNode  *min_slope_node(TreeNode *node);
double     prune(TreeNode *node);
void       wpt_bitalloc(TreeNode *root, double stoppingrate,
			double  *rate,  double *distortion);

/* global variables */
char 	  *programname;
int  	   treedim;
int  	   treelevel;
