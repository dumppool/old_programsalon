/******************************************************************************
 *
 * Copyright Jill R. Goldschneider, 1998
 *
 * This work was partially supported by a NASA Graduate Student
 * Fellowship in Global Change Research, an NSF Young Investigator Award,
 * and U.~S. Army Research Grant DAAH004-96-1-0255.
 *
 *****************************************************************************/

/******************************************************************************
 *
 * FILE          node_util.c
 * AUTHOR        Jill R. Goldschneider
 * DATE          February 1997
 * REVISIONS     February 1998 - update documentation
 * DESCRIPTION   WPT node creation functions
 *               TreeNode *create_root()
 *               TreeNode *newchild(parent, id)
 *
 *****************************************************************************/
#include "wpt.h"

/******************************************************************************
 * DOCUMENTATION ********************************************************
 ******************************************************************************
   NAME create_root

   DESCRIPTION create_root creates a WPT root node with depth zero.

   ARGUMENTS

   RETURN create_root returns a pointer to a TreeNode. If memory
   cannot be allocated then NULL is returned.

   ALGORITHM

   AUTHOR Jill R. Goldschneider

******************************************************************************/

TreeNode *create_root()
{
  TreeNode *n;

  if (!(n = (TreeNode *) calloc(1, sizeof(TreeNode)))) {
    fprintf(stderr, "%s: %s\n", programname, NOMEMORY);
    return(NULL);
  }

  n->parent = NULL;
  n->child = NULL;
  n->distortion = 0.0;
  n->rate = 0.0;
  n->lambda_min = 0.0;
  n->split = FALSE;
  n->depth = 0;
  n->child_id = 0;
  n->data = NULL;
  return(n);
}

/******************************************************************************
 * DOCUMENTATION ********************************************************
 ******************************************************************************
   NAME newchild

   DESCRIPTION create_root creates a WPT node with the given parent
   node and identification, and with a depth one greater than its
   parent.  All other node parameters are initialized to zero or to
   NULL.

   ARGUMENTS
      IARG  parent  the parent node of the node to be created
      IARG  id      the identification number for the node to be created

   RETURN newchild returns a pointer to a TreeNode. If memory cannot
      be allocated then NULL is returned.

   ALGORITHM

   AUTHOR Jill R. Goldschneider

******************************************************************************/

TreeNode *newchild(TreeNode *parent, int id)
{
  TreeNode *n;

  if (!(n = (TreeNode *) calloc(1, sizeof(TreeNode)))) {
    fprintf(stderr, "%s: %s\n", programname, NOMEMORY);
    return(NULL);
  }

  n->parent = parent;
  n->child = NULL;
  n->distortion = 0.0;
  n->rate = 0.0;
  n->lambda_min = 0.0;
  n->split = FALSE;
  n->depth = parent->depth + 1;
  n->child_id = id;
  n->data = NULL;
  return(n);
}
