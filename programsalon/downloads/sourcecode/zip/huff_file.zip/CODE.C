#include <stdio.h>

int array[128]={6,33,34,35,36,37,38,39,5,41,42,43,44,45,46,47,
		48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,7,65,66,67,
		68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,
		88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,
		106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,
		121,122,123,124,125,126,127,3,129,130,131,132,133,134,4,
		136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,
		151,152,153,154,155,156,157,158,159};

main( int argc,char * argv[] )
{
  FILE * input_file;
  FILE * output_file;
  unsigned char rackin;
  unsigned char rackout;
  int mask;
  int i,j,flag;
  char out_char;
  unsigned char bit[8];
  char conclude;

  if( ( input_file=fopen( argv[1],"r") )==NULL )
      { printf( "cant open the input_file " );
        exit(0); }
  output_file=fopen( argv[2],"w" );

for( ; ; ){
  mask=0x01;
  rackout=0;
  rackin=getc( input_file ) ;
  conclude=rackin;
  if( conclude==EOF ) break;
  rackout=( rackin>>1 );
  out_char=array[rackout];
  putc( out_char,output_file );
  bit[6]=rackin&mask;
  bit[6]<<=6;

  mask=0x01;
  rackout=0;
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  rackout=( rackin>>2 );
  rackout |= bit[6];
  out_char=array[rackout];
  putc( out_char,output_file );
  bit[5]=rackin&mask;
  bit[5]<<=5;
  mask<<=1;
  bit[6]=rackin&mask;
  bit[6]<<=5;

  mask=0x01;
  rackout=0;
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  rackout=( rackin>>3 );
  rackout |= bit[5];
  rackout |= bit[6];
  out_char=array[rackout];
  putc( out_char,output_file );
  bit[4]=rackin&mask;
  bit[4]<<=4;
  mask<<=1;
  bit[5]=rackin&mask;
  bit[5]<<=4;
  mask<<=1;
  bit[6]=rackin&mask;
  bit[6]<<=4;

  mask=0x01;
  rackout=0;
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  rackout=( rackin>>4 );
  rackout |= bit[4];
  rackout |= bit[5];
  rackout |= bit[6];
  out_char=array[rackout];
  putc( out_char,output_file );
  for( i=3;i<=6;i++ ){
       bit[i]=rackin&mask;
       bit[i]<<=3;
       mask<<=1;
       }

  mask=0x01;
  rackout=0;
  rackin=getc( input_file ) ;
  conclude=rackin;
  if( conclude==EOF ) break;
  rackout=( rackin>>5 );
  for( i=3;i<=6;i++ )
       rackout |= bit[i];
  out_char=array[rackout];
  putc( out_char,output_file );
  for( i=2;i<=6;i++ ){
       bit[i]=rackin&mask;
       bit[i]<<=2;
       mask<<=1;
       }

  mask=0x01;
  rackout=0;
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  rackout=( rackin>>6 );
  for( i=2;i<=6;i++ )
       rackout |= bit[i];
  out_char=array[rackout];
  putc( out_char,output_file );
  for( i=1;i<=6;i++ ){
       bit[i]=rackin& mask;
       bit[i]<<=1;
       mask<<=1;
       }

  mask=0x01;
  rackout=0;
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  rackout=( rackin>>7 );
  for( i=1;i<=6;i++ )
       rackout |= bit[i];
  out_char=array[rackout];
  putc( out_char,output_file );

  rackout=0;
  mask=0x7f;
  rackout=rackin & mask ;
  out_char=array[rackout];
  putc( out_char,output_file );
}
  fclose( output_file );
  fclose( input_file );
  printf("rackin=%dconclude=%d",rackin,conclude);
}





