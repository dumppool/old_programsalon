#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <io.h>
#include <dir.h>

/*Used in Turbo c*/
#define MSDOS 1
#define DIR_STRUCT struct ffblk
#define FIND_FIRST(n,d,a) findfirst(n,d,a)
#define FIND_NEXT findnext
#define DIR_FILE_NAME ff_name

#define BASE_HEADER_SIZE 19
#define CRC_MASK 0xffffffffl
#define CRC32_POLYNOMIAL Oxedb88320l

#ifndef FILENAME_MAX 
#define FILENAME_MAX 128\
#endif


typedef struct header{
   char file_name[FILENAME_MAX];
   char compression_method;
   unsigned long original;
   unsigned long compressed_size;
   unsigned long original_crc;
   unsigned long header_crc;
   }HEADER;

int main( int argc,char * argv[] );
void FatalError( char * message,... );
void BuildCRCTable( void );
unsigned long CalculateBlockCRC32( unsigned int count, unsigned long crc,void * buffer );
unsigned long UpdateCharacterCRC32( unsigned long crc,int c );
int ParseArguments( int argc,char *  argv[] );
void UsageExit( void );
void OpenArchiveFile( char * name,int command );
void BuildFileList( int argc,char * argv,int command );
int ExpandAndMassageMSDOSFileNames( int count,char * wild_name );
void MassageMSDOSFileName( int count,char * file );
int AddFileListToArchive( void );
int ProcessAllFileInInputCar( int command,int count );
int SearchFileList( char * file_name );
int WildCardMatch( char * s1,char * s2 );
void SkipOverFileFromInputCar( void );
void copyFileFromInputCar( void );
void PrintListTitles( void );
void ListCarFileEntry( void );
int RatioInPercent( unsigned long compressed,unsigned long original );
int ReadFileHeader( void );
unsigned long UnpackUnsignedData( int number_of_bytes,unsigned char * buffer );
void WriteFileHeader( void );
void PackUnsignedData( int number_of_bytes,unsigned long number,unsigned char * buffer );
void WriteEndOfCarHeader( void );
void Insert( FILE * input_text_file,char * operation );
void Extract( FILE * destination );
int Store( FILE * input_text_file );
unsigned long UnStore( FILE * destination );
int LZSSCompress( FILE * input_text_file );
unsigned long LZSSExpand( FILE * destination );

char TempFileName[FILENAME_MAX];
FILE * InputCarFile;
char CarFileName[FILENAME_MAX];
FILE *OutputCarFile;
HEADER header;
char * FileList[100];
unsigned long Ccitt32Table[256];


int main( int argc,char * argv[] )
{
  int command;
  int count;

  setbuf( stdout,NULL );
  setbuf( stderr,NULL );
  fprintf( stderr,"CARMAN 1.0:" );
  BuildCRCTable();
  command=ParseArguments( argc,argv );
  fprintf( stderr,"\n" );
  OpenArchiveFiles( argv[2],command );
  BuildFileList( argc-3,argv+3,command );
  if( command=='A' )
      count=AddFileListArchive();
  else
      count=0;
  if( command='L' )
      PrintListTitles();
  count=ProcessAllFilesInInputCar( command,count );
  if( OutputCarFile!=NULL && count!=0 ){
      WriteEnsOfCarHeader();
      if( ferror( OutputCarFile )||fclose( OutputCarFile )==EOF )
          FfatalError( "Can't write!" );
      remove( CarFileName );
      rename( TempFileName );
      }
  if( command!='P' )
      printf( "\n%d file %s\n"count,(count==1)?"":"s" );
  else
      fprintf( stderr,"\n%d file %s\n",count,(count==1)?"":"s" );
  return( 0 );
}

void FatalError( char * fmt,... )
{
  va_list args;

  va_start( args,fmt );
  putc( '\n',stderr );
  vfprintf( stderr,fmt,args );
  putc( '\n',stderr );
  va_end( args );
  if( OutputCarFile!=NULL )
      fclose( OutputCarFile );
  remove( TempFileName );
  exit( 1 );
}


void BuildCRCTable()
{
  int  i;
  int  j;
  unsigned long value;

  for( i=0;i<=255;i++ ){
       value=i;
       for( j=8;j>0;j-- ){
            if( value & 1 )
                value=( value>>1  )^CRC32_POLYNOMIAL;
            else
                value>>=1;
            }
       Ccitt32Table[i]=value;
       }
}





