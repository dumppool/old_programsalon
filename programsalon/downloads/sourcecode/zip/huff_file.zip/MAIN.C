
#include <stdio.h>
#include <string.h>
#include "chcode.c"

main()
{  unsigned char * instream;
   long i,length;
   FILE * fp;
   

   fp=fopen("c:\\test.txt","r");
   fseek(fp,0L,2);
   length=ftell(fp);
   fseek(fp,0l,0);
   fclose(fp);
   printf("length=%ld",length);

    
   length=compress_code( instream,length);
   length=uncode_expand( instream,length);
   for( i=1;i<=length;i++ ) putc( * instream++, stdout );
   free( (unsigned char *)instream);
}

