#include <stdio.h>
#include <stdlib.h>

int array[128]={6,33,34,35,36,37,38,39,5,41,42,43,44,45,46,47,
		48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,7,65,66,67,
		68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,
		88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,
		106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,
		121,122,123,124,125,126,127,3,129,130,131,132,133,134,4,
		136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,
		151,152,153,154,155,156,157,158,159};

main( int argc,char * argv[] )
{
  FILE * input_file;
  FILE * output_file;
  unsigned char rackin;
  unsigned char rackout;
  int mask;
  int i,j;
  unsigned char out_char;
  unsigned char bit[8];
  char conclude;

  if( ( input_file=fopen(argv[1],"r"))==NULL )
      printf( "cant open the input_file " );
  output_file=fopen( argv[2],"w" );

for( ; ; ) {
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  for( i=0;i<=127;i++ ) if( array[i]==rackin ) break;
  rackin=i;
  rackout=( rackin<<1 );
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  for( i=0;i<=127;i++ ) if( array[i]==rackin ) break;
  rackin=i;
  bit[0]=rackin & 0x40 ;
  bit[0] >>= 6;
  rackout |= bit[0];
     if( (rackout==128) || (rackout==8) ) rackout=32;   
  putc( rackout,output_file );


  rackout=( rackin<<2 );
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  for( i=0;i<=127;i++ ) if( array[i]==rackin ) break;
  rackin=i;
  bit[1]=rackin & 0x40 ;
  bit[1] >>= 5;
  bit[0]=rackin & 0x20 ;
  bit[0] >>=5 ;
  rackout |= bit[1];
  rackout |= bit[0];
     if( (rackout==128) || (rackout==8) ) rackout=32;       
  putc( rackout,output_file );

  rackout=( rackin<<3 );
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  for( i=0;i<=127;i++ ) if( array[i]==rackin ) break;
  rackin=i;
  bit[2]=rackin & 0x40 ;
  bit[2] >>= 4;
  bit[1]=rackin & 0x20 ;
  bit[1] >>=4 ;
  bit[0]=rackin & 0x10 ;
  bit[0] >>=4 ;
  rackout |= bit[2];
  rackout |= bit[1];
  rackout |= bit[0];
     if( (rackout==128) || (rackout==8) ) rackout=32;   
  putc( rackout,output_file );

  rackout=( rackin<<4 );
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  for( i=0;i<=127;i++ ) if( array[i]==rackin ) break;
  rackin=i;
  bit[3]=rackin & 0x40 ;
  bit[3] >>= 3;
  bit[2]=rackin & 0x20 ;
  bit[2] >>= 3 ;
  bit[1]=rackin & 0x10 ;
  bit[1] >>= 3 ;
  bit[0]=rackin & 0x08 ;
  bit[0] >>= 3 ;
  rackout |= bit[3];
  rackout |= bit[2];
  rackout |= bit[1];
  rackout |= bit[0];
     if( (rackout==128) || (rackout==8) ) rackout=32;     
  putc( rackout,output_file );

  rackout=( rackin<<5 );
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  for( i=0;i<=127;i++ ) if( array[i]==rackin ) break;
  rackin=i;
  bit[4]=rackin & 0x40 ;
  bit[4] >>= 2;
  bit[3]=rackin & 0x20 ;
  bit[3] >>= 2 ;
  bit[2]=rackin & 0x10 ;
  bit[2] >>= 2 ;
  bit[1]=rackin & 0x08 ;
  bit[1] >>= 2 ;
  bit[0]=rackin & 0x04 ;
  bit[0] >>= 2 ;
  rackout |= bit[4];
  rackout |= bit[3];
  rackout |= bit[2];
  rackout |= bit[1];
  rackout |= bit[0];
     if( (rackout==128) || (rackout==8) ) rackout=32;   
  putc( rackout,output_file );

  rackout=( rackin<<6 );
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  for( i=0;i<=127;i++ ) if( array[i]==rackin ) break;
  rackin=i;
  bit[5]=rackin & 0x40 ;
  bit[5] >>= 1;
  bit[4]=rackin & 0x20 ;
  bit[4] >>= 1;
  bit[3]=rackin & 0x10 ;
  bit[3] >>= 1;
  bit[2]=rackin & 0x08 ;
  bit[2] >>= 1;
  bit[1]=rackin & 0x04 ;
  bit[1] >>= 1;
  bit[0]=rackin & 0x02 ;
  bit[0] >>= 1;
  rackout |= bit[5];
  rackout |= bit[4];
  rackout |= bit[3];
  rackout |= bit[2];
  rackout |= bit[1];
  rackout |= bit[0];
     if( (rackout==128) || (rackout==8) ) rackout=32;    
  putc( rackout,output_file );

  rackout=( rackin<<7 );
  rackin=getc( input_file );
  conclude=rackin;
  if( conclude==EOF ) break;
  for( i=0;i<=127;i++ ) if( array[i]==rackin ) break;
  rackin=i;
  rackout |= rackin;
  if( (rackout==128) || (rackout==8) ) rackout=32;   
  putc( rackout,output_file );
  }
  putc(0x0d,output_file );
  putc(0x0a,output_file );
  fclose( output_file );
  fclose( input_file );

}


