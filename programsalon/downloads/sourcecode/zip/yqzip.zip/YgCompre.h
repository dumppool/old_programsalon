_declspec(dllimport) void WINAPI YgCompressFile();
_declspec(dllimport) void WINAPI YgUnCompressFile();