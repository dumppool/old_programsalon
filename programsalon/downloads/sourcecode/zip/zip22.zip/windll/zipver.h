#ifndef __zipver_h   /* prevent multiple inclusions */
#define __zipver_h

#define ZIP_DLL_VERSION "2.2\0"
#define COMPANY_NAME "Info-ZIP\0"

#endif /* __zipver_h */
