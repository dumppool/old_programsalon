/*
   crypt.c (dummy version) by Info-ZIP.      Last revised:  5 Oct 97

   This is a non-functional version of Info-ZIP's crypt.c encryption/
   decryption code for Zip, ZipCloak, UnZip and fUnZip.  This file is
   not copyrighted and may be distributed freely. :-)  See the "WHERE"
   file for sites from which to obtain the full encryption/decryption
   sources (zcrypt27.zip or later).
 */

/* something "externally visible" to shut up compiler/linker warnings */
int zcr_dummy;
