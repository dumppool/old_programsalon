//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EBook.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_EBOOK_FORM                  101
#define ID_DISPLAY                      101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_MAINFRAME                   128
#define IDR_EBOOKTYPE                   129
#define IDR_MENU_TREE                   130
#define IDB_BITMAP1                     135
#define IDD_FLASHDLG                    139
#define IDR_BEGINMENU                   140
#define IDB_BITMAP2                     143
#define IDC_TREE                        1001
#define IDC_CONTENT                     1002
#define IDC_HTTP                        1003
#define IDC_EMAIL                       1004
#define IDC_DOWNEWORD                   1005
#define IDC_WELCOMEPAGE                 1008
#define ID_RECORD_ADD                   32771
#define ID_RECORD_ADD_SUB               32772
#define ID_RECORD_EDIT                  32774
#define ID_REDORD_DELETE                32775
#define ID_ASIZEINCREASE                32776
#define ID_ASIZEDECREASE                32777
#define ID_LEFTMARGIN_INCREASE          32778
#define ID_LEFTMARGIN_DECREASE          32779
#define ID_BUTTON32780                  32780
#define ID_EBOOK                        32781
#define ID_SUPPORT                      32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
