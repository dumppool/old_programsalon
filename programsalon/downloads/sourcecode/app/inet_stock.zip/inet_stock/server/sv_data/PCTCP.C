#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <malloc.h>
#include "hq.h"
#include "pctcp.h"

HLOCAL hWSAData;

int ret;

int sdHq =-1;
int PROTO_USE =PROTO_TCP;

BOOL fInTransing =FALSE;

#define WSA_MAKEWORD(x,y)       ((y) * 256 + (x))

extern BOOL run_cancelled;

LPSTR GetError(LPSTR err_prefix);
char HostName[40];

FILE *fp =NULL;

extern BOOL GetInitString(LPSTR, LPSTR, LPSTR);
extern void PutInitString(LPSTR, LPSTR, LPSTR);
extern BOOL ErrMsg(HWND, LPSTR);
extern HWND ghWndMain;
extern HINSTANCE ghInstance;
extern HWND ghWndXlt, ghWndJlt, ghWndMaxMin;
extern HWND ghDlgJy;

//int PROTO_USE =PROTO_UDP;

void WriteMsg(LPSTR msg)
{                
	if(fp) fputs(msg, fp);
}

int PCTCPInit(void)
{
	WORD VersionReqd;        
	WSADATA myWSAData;
                      
    char tmp[80];
    
	VersionReqd=WSA_MAKEWORD(MAJOR_VERSION, MINOR_VERSION);
	hWSAData =LocalAlloc(LHND, sizeof(WSADATA));
	
	ret = WSAStartup(VersionReqd, &myWSAData);
	    
	sdHq =-1;
	if (ret != 0)
	{
		ErrMsg(NULL, GetError("WSAStartup()")); 
		return -1;
	}        
	     
	if(!GetInitString("NET", "HOST", HostName))
	{
		ErrMsg(NULL, "Not find HOST set in [NET] of init file");
		PutInitString("NET", "HOST", "172.20.1.1");
		return -1;
	}

    if(GetInitString("NET","PROTO_USE",tmp))
    {
        if(tmp[0]=='U' || tmp[0]=='u')
            PROTO_USE =PROTO_UDP;
        else
            PROTO_USE =PROTO_TCP;
    }
    else
        PutInitString("NET","PROTO_USE","TCP");
	return 0;
}

int PCTCPClose(void)
{
	int ret;

	run_cancelled =TRUE;
	
	WSACancelBlockingCall();
	if(sdHq !=-1)
	{
		closesocket(sdHq);
		sdHq =-1;
    }
	
	ret = WSACleanup();
	if (ret == SOCKET_ERROR && h_errno == WSAEINPROGRESS)
	{
		//ErrMsg(NULL, "Data transfer in progress.\nStop transfer first.");
		return -1;
	}
	
	return 0;
}
		
int PCTCPExit(void)
{
	static BOOL fExit =FALSE;
	
	if(fExit ==TRUE) return 0;
	fExit =TRUE;
	
	PCTCPClose();
	
	LocalUnlock(hWSAData);
	LocalFree(hWSAData);
	
	if(fp) fclose(fp);
	
	return 0;
}

// used for client
int ConnectHost(void)
{
	LPSTR lpHostName;
	struct  hostent FAR *hp;
	struct  sockaddr_in server_addr;
    //SOCKET  hSock;
    int hSock,i;
	int iSockType;
	long lret;
	static BOOL fFirst =TRUE;
	
	if(fFirst ==FALSE)
	{
		if(sdHq !=-1)
		{
			closesocket(sdHq);
			sdHq =-1;
		}
	}
	if(fFirst ==TRUE) fFirst =FALSE;
	lpHostName =&HostName[0];

	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_addr.s_addr =(u_long)inet_addr(lpHostName);
	
	if (server_addr.sin_addr.s_addr == (u_long) -1L || 
		server_addr.sin_addr.s_addr == 0) 
	{
		if ((hp = gethostbyname(lpHostName)) == NULL) 
		{
			//ErrMsg(NULL, "rpcinfo: server address is unknown");
			return -1;
		}
		_fmemcpy((char *)&server_addr.sin_addr, hp->h_addr, hp->h_length);
	}
	server_addr.sin_family = PF_INET;
	if (PROTO_USE == PROTO_TCP)
		iSockType = SOCK_STREAM;
	else
		iSockType = SOCK_DGRAM;
    
	server_addr.sin_port = htons((u_int) PORT_HQ);
    
	hSock = socket(PF_INET, iSockType, 0);
	if (hSock == INVALID_SOCKET)
	{
		ErrMsg(NULL, "socket() failed");
		return (SOCKET) -1;
	}
    
	lret = 1L;
    ioctlsocket(hSock, FIONBIO, (u_long FAR *) &lret);
    i=0;
    do
    {
        ret=connect(hSock,(struct sockaddr FAR *)&server_addr,sizeof(server_addr));
    }while(ret ==SOCKET_ERROR && i++<9000);

	sdHq =hSock;
	
	return hSock;
}

int PASCAL FAR WSAsperror(int errorcode, char far * buf, int len)
{
	int err_len;
    
	if (errorcode == 0)
		errorcode = WSABASEERR;
	if (errorcode < WSABASEERR)
		return 0;
	    
	err_len = LoadString(ghInstance,errorcode,buf,len);
	
	return err_len;
	
}

LPSTR GetError(LPSTR err_prefix)
{
	int wsa_err;
	char errbuf[1000];
	char prbuf[1000];
	
	wsa_err =WSAGetLastError(); 
	
	WSAsperror(wsa_err, (LPSTR)errbuf, sizeof(errbuf));
	    
	wsprintf((LPSTR)prbuf, "%s:\n%s", (LPSTR) err_prefix, (LPSTR)errbuf);
	
	return &prbuf[0];  
}

#define 	DATA_START_SIGN		-16
extern int Skip;

int UDP_SendBuff(int sd, LPSTR SendBuf, int len)
{
	int i, e;
	char  far *WriteBuf;
	static skip=0;

	if(Skip>0)
	{
		skip++;
		if(skip<Skip)
			return len;
	  	else
	  	   	skip=0;
	}
	
	WriteBuf=_fmalloc((len+10) *sizeof(char ));
	if(WriteBuf==NULL)
	{
		ErrMsg(NULL,"Alloc mem err!");
		return  -1;
	}
	memset(&WriteBuf[0],0,sizeof(WriteBuf));
	WriteBuf[0]=DATA_START_SIGN;
	*(int *)&WriteBuf[1]=len;
	memcpy(&WriteBuf[1+sizeof(int)],SendBuf,len);
	
	for(i =0; i<10; i++)
	{
		len = send(sdHq, &WriteBuf[0], len +1 +sizeof(int), 0);
		
		if (len == SOCKET_ERROR)
		{
			if ((e =h_errno) == WSAEWOULDBLOCK)
				continue;
			else if(e !=WSAENETRESET)
			{
				MessageBeep(0);
				if(ConnectHost() <0) return -1;
			}
			else
			{
				//ErrMsg(NULL, "UDP_SendBuff failed");
				return -1;
			}
		}
		break;
	}
	_ffree(WriteBuf);
	return i;
}
