#include <windows.h>
#include <malloc.h>

#include "hq.h"

extern char ZxDataFile[128];
extern HWND ghWndMain;
extern BOOL ErrMsg(HWND, LPSTR);
extern int tim;
extern void MsgLocal(LPSTR msg);

int ReadZx(void)
{
	int len;
	OFSTRUCT os;
	HFILE hFile;
	
	if(HqTime[0].fRunning ==FALSE && HqTime[1].fRunning ==FALSE)
		if(ZxData.len >0) return 0;
	
	MsgLocal("Read zx...");
	
	hFile =OpenFile(ZxDataFile, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hFile ==HFILE_ERROR)
	{
		ErrMsg(ghWndMain, "read zx failed");
		return -1;
	}
	len =(int)_llseek(hFile, 0, SEEK_END);
	if(len ==ZxData.len)
	{
		_lclose(hFile);
		return 0;
	}
	if(len >10000) len =10000;
	
	_llseek(hFile, 0, SEEK_SET);
	
	if(ZxData.lpText)
		ZxData.lpText =realloc(ZxData.lpText, len);
	else ZxData.lpText =malloc(len);
	
	if(ZxData.lpText ==NULL)
	{
		ErrMsg(ghWndMain, "alloc zxdata mem failed!");
		_lclose(hFile);
		return -1;
	}
	
	ZxData.len =_lread(hFile, ZxData.lpText, len);
	if(tim >=0) ZxData.curMin =tim;
	_lclose(hFile);
	
	return 0;
}
