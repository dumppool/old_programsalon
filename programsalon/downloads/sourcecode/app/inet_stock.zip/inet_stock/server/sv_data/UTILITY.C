
int StringComp(LPSTR lpstr1, LPSTR lpstr2)
{
	int len;
	
	if(*lpstr1 =='-' && *lpstr2 !='-') return -1;
	if(*lpstr1 !='-' && *lpstr2 =='-') return 1;
	
	len =strlen(lpstr1) -strlen(lpstr2);
	if(*lpstr1 =='-' && *lpstr2 =='-')
	{
		if(len) return 0-len;
		return (0-strcmp(lpstr1, lpstr2));
	}
	else
	{
	    if(len) return len;
		return strcmp(lpstr1, lpstr2);
	}
}

int StringSub(LPSTR lpstr1, LPSTR lpstr2, LPSTR lpres, int s_type)
{
	int n;
	double f, f1,f2;
	long l;
	
	switch(s_type)
	{
		case SSUB_FLOAT:
			f =atof(lpstr1)-atof(lpstr2);
			sprintf(lpres, "%.2f", (float)f);
		break;
		case SSUB_FLOAT100:
			f1 =atof(lpstr1);
			f2 =atof(lpstr2);
			f =f1-f2;
			if(f2 ==.0 || f1 ==.0)
			{
				strcpy(lpres, "-.-");
				break;
			}
			sprintf(lpres, "%.2f", (float)(f*100/f2));
		break;
		case SSUB_INT:
			n =atoi(lpstr1)-atoi(lpstr2);
			sprintf(lpres, "%d", n);
		break;
		case SSUB_LONG:
			l =atol(lpstr1)-atol(lpstr2);
			sprintf(lpres, "%ld", l);
		break;
		default:
		return -1;
	}
	
	return 0;
}

