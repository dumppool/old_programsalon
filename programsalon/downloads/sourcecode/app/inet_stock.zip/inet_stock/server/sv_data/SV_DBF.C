#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <io.h>
#include <time.h>
#include <errno.h>
#include <math.h>
#include <share.h>
#include <fcntl.h>
#include "sv_dbf.h"

#define TRUE  1
#define FALSE 0

extern BOOL ErrMsg(HWND, LPSTR);
extern BOOL run_cancelled;
extern void MsgLocal(LPSTR msg);

void DelayMs(int ms)
{
	extern int UDPBlockingHook(void);
	clock_t i,j;

	i=clock();
	j=clock();
	while(((j-i)*1000/CLK_TCK )< ms)
	{
		UDPBlockingHook();
		j=clock();
	}
}

int OpenDbfBase(char *file_name,int amode)
{
   int try=0;
	OFSTRUCT os;
	HFILE handle;
	
   handle=OpenFile(file_name,&os, amode|OF_SHARE_DENY_NONE);
   while(handle==HFILE_ERROR)
   {
	  handle=OpenFile(file_name,&os, amode|OF_SHARE_DENY_NONE);
	  try++;
	  if(try==OPEN_RETR)
	  return(-1);
	  DelayMs(OPEN_INTERVAL);
   }
   return(handle);
}

int CloseDbf(int hd)
{
   return(_lclose(hd));
}

int CheckDbf(int hd,DbfStruct *d_info,FieldStruct *f_info,int f_num)
{
   unsigned long flen1,flen2;
   int i,rlen,wid;

   flen1=filelength(hd);
   flen2=(*(int *)d_info->rlen)*(*(unsigned long *)d_info->recnum)+
	   *(int *)d_info->hlen;
   if((flen1!=flen2)&&(flen1!=flen2+1)) {
		return(DBF_DESTROYED);
   }

   rlen=0;
   for(i=0;i<f_num;i++)
	  rlen+=(int)f_info[i].wid;
   rlen++;

   if (*(int*)d_info->rlen!=rlen) {
	   return(DBF_DESTROYED);
   }
			/* if offset of first Field is not valid */
   if (*(int*)f_info[0].offset!=1) {
	   return(DBF_DESTROYED);
   }

   for(i=0;i<f_num-1;i++) {
	   wid=*(int*)f_info[i+1].offset-*(int*)f_info[i].offset;
	   if (wid!=(int)f_info[i].wid) {
		   return(DBF_DESTROYED);
	   }
   }
   return(SUCCEED);
}

int InitBase(int hd, DbfStruct *BaseInfo,FieldStruct **FldInfo,int *FieldNum)
{
	int ret;
	int wid;
	int i;
	
	_llseek(hd,0l,SEEK_SET);

	if((ret=_lread(hd,BaseInfo,sizeof(DbfStruct)))!=sizeof(DbfStruct)) {
	   return(READ_ERROR);
	}
	if(BaseInfo->id!=0x03 && BaseInfo->id!=0x83) {
	   return(DBF_ERR);
	}

	*FieldNum=(*(int*)(BaseInfo->hlen)-1)/32-1;
				   /**
				exclude one byte of 0x0d and 32 bytes of DBF
				structure.
				**/

	if ((*FldInfo=malloc((*FieldNum)*sizeof(FieldStruct)))==NULL)
		return(ALLOC_ERROR);


	if(_lread(hd,(void*)*FldInfo,sizeof(FieldStruct)*(*FieldNum))
	   !=sizeof(FieldStruct)*(*FieldNum)) {
	   free(*FldInfo);
	   *FldInfo =NULL;
	   return(READ_ERROR);
	}
   /////////////////////
	wid =1;
	for(i =0; i<*FieldNum; i++)
	{
		*(int *)(*FldInfo)[i].offset =wid;
		wid+=(int)(*FldInfo)[i].wid;
	}
	return(SUCCEED);
}

int ReadRecord(int hd,long no,int hlen,int rlen,char *rbuff)
{

  _llseek(hd,(long)(hlen+rlen*(no-1l)),SEEK_SET);
  if(_lread(hd,rbuff,rlen)!=(UINT)rlen)
	 return(READ_ERROR);
  return(SUCCEED);
}

long GetDbfRecCount(int hf,int hlen,int rlen)
{
	//DbfStruct dbfStruct;
	long bytes,total;
	int i=0;
	long rec;
	char tmp[10];
	
	
	total =_llseek(hf,0L,SEEK_END);
	if(total == -1)
		return 0;
	if(total <=hlen)
		return 0;
		
	_llseek(hf,4l,SEEK_SET);	
	do
	{		    
		bytes =_lread(hf,tmp,4);
		if(bytes!=4)
		{
		    MsgLocal("��ȡ���ݿ��¼��...");
			if(run_cancelled) break;
			DelayMs(4);
			_llseek(hf,4l,SEEK_SET);    
			i++;
		}
		
		if(i>5)
			return 0L; 
	}while(bytes !=4);
	
	tmp[4] =0;
	rec =*(long *)tmp;	
    
	return rec;	
}

int AppendRecord(int hDbf, DbfStruct *lpDbfInfo, char *lpDbfRecBuf)
{
   unsigned char c[5];
   char cEndOfFile;
   int i;
   
   if (*(long *)lpDbfInfo->recnum==0)
	  _llseek(hDbf,0l,2);
   else
	  _llseek(hDbf,-1l,2);
   
   if(_lwrite(hDbf,lpDbfRecBuf,*(int *)lpDbfInfo->rlen)
       ==*(UINT *)lpDbfInfo->rlen)
   {
	  cEndOfFile=ENDOFFILE;
	  _lwrite(hDbf,&cEndOfFile,1);
	  _llseek(hDbf,4L,0);
	  _lread(hDbf,c,4);
	  (*(long *)c)++;
	  _llseek(hDbf,4L,0);
	  _lwrite(hDbf,c,4);
	  for(i=0;i<4;i++)
	    lpDbfInfo->recnum[i]=c[i];
	  return 0;
   }
   return -1;
}

int FldToString(char huge*rbuff,FieldStruct *finfo,char *fstr)
{
  int offs,inc;

  offs=*(int *)(finfo->offset);    
  if(offs <0 || offs >256)
  	return -1;
  inc=0;
  while(rbuff[offs+inc]==CH_SPACE && inc <(int)finfo->wid)
	 inc++;
  strncpy(fstr,&(rbuff[offs+inc]),(int)finfo->wid-inc);
  fstr[(int)finfo->wid-inc]=0;
  return(SUCCEED);
}

int StringToFld(char *fbuff,FieldStruct finfo,char *fstr)
{
   int len,offs;

   len=strlen(fstr);
   if(len>(int)finfo.wid)
   	len =(int)finfo.wid;
   	
   offs=*(int*)finfo.offset;
   while(offs<(*(int*)finfo.offset+(int)finfo.wid-len))
	   fbuff[offs++]=CH_SPACE;
   strncpy(&(fbuff[offs]),fstr,len);
   return(SUCCEED);
}

int EndOfDbf(int hd)
{
   char id;

   _lread(hd,&id,1);
   if (id==ENDOFFILE)
	   return(TRUE);
   return(FALSE);
}

int DbfErrorPrint(int type,char _far *str,int no)
{
	char temp[256];
	
	switch(type) {
	  case OPEN_ERROR:
		sprintf(temp, "FILE OPEN ERROR: %s!",str);
		break;

	  case ALLOC_ERROR:
		sprintf(temp, "ALLOCATION ERROR: %s!",str);
		break;

	  case DBF_ERR:
		sprintf(temp, "DBF ERROR: name=%s,record=%d",str,no);
		break;

	  case READ_ERROR:
		sprintf(temp,"FILE READ ERROR: %s!",str);
		break;
	  case LOCK_FAILED:
		sprintf(temp, "FILE LOCK ERROR: %s!",str);
		break;

	  case DBF_DESTROYED:
		sprintf(temp, "DBF DESTROYED: name=%s,record=%d!",str,no);
		break;

	  case INIT_DBF_ERROR:
		sprintf(temp, "Initializing DBF Error: name=%s!",str);
		break;

	  default:
		return SUCCEED;
	 }
	ErrMsg(NULL, temp); 
	 return(SUCCEED);
}
