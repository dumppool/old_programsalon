#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <io.h>

#include "hq.h"
#include "data.h"
#include "sv_dbf.h"
#include "lzw.h"

extern BOOL run_cancelled;

extern HWND ghWndMain;
extern int date_num, tim;
HFILE hfHq[2], hfMmp[2], hfDp, hfMaxMin[2];
extern void MsgLocal(LPSTR msg);
extern BOOL ErrMsg(HWND, LPSTR);
extern int UDPBlockingHook(void);
extern long oldCjss[2];
extern BOOL IsZsRec(int, int);

//extern int RefreshHqData(int jys);

extern char szDataPath[128];
long zs_times[2][20];

BOOL fWrited[2] ={FALSE, FALSE};

int WriteHqAll(int jys)
{
	if(WriteHqData(jys) <0) return -1;
	if(WriteMmpData(jys) <0) return -1;
	if(WriteMaxMinData(jys) <0) return -1;
	
	return 0;
}

int WriteHqData(int jys)
{
	_llseek(hfHq[jys], 0, SEEK_SET);
	_lwrite(hfHq[jys], (short *)&HqData[jys].recCount, sizeof(short));
	if(_hwrite(hfHq[jys], HqData[jys].lpPreData,
			(long)HqData[jys].recCount*sizeof(HQ_PRE_DATA))
		!=(long)HqData[jys].recCount*sizeof(HQ_PRE_DATA))
	{
		ErrMsg(ghWndMain, "Error write hqdata");
		return -1;
	}
	
	if(_hwrite(hfHq[jys], HqData[jys].lpRefData,
			(long)HqData[jys].recCount*sizeof(HQ_REF_DATA))
		!=(long)HqData[jys].recCount*sizeof(HQ_REF_DATA))
	{
		ErrMsg(ghWndMain, "Error write hqdata");
		return -1;
	}	
	CreateLzwFile(jys);	
	return 0;
}

//////////////////////////////////////////////////////////////////////////
//Function:to reduce transfer time between server and client,we must build
//         compress data.this prog compress main mass data(szhq.dat.shhq.dat)
//Para    :None
//Return  :if successful return 0,otherwise return -1
//Writer  :lym
//Create  :1997/08/24
//////////////////////////////////////////////////////////////////////////
int CreateLzwFile(int jys)
{
	char temp[256]; //,tmp[256];
    OFSTRUCT os;                 
    HQ_REF_DATA_V202  DataV202;
    long i;
    int lzw;
    
    //for(jys=0;jys<2;jys++)
    //{   
		if(HqData[jys].recCount==0)
			return(-1);
		if(jys==0)
			sprintf(temp,"%s\\hqdata\\szhq.202",szDataPath);
		else
			sprintf(temp,"%s\\hqdata\\shhq.202",szDataPath);

		if((lzw=OpenFile(temp,&os,OF_WRITE|OF_SHARE_DENY_NONE))==HFILE_ERROR)
			if((lzw=OpenFile(temp,&os,OF_WRITE|OF_SHARE_DENY_NONE|OF_CREATE))==HFILE_ERROR)
				return(-1);
			
		_lwrite(lzw, (short *)&HqData[jys].recCount, sizeof(short));
		for(i=0;i<HqData[jys].recCount;i++)
		{	
			while(UDPBlockingHook());	
			if(run_cancelled) break;	
			memset((char*)&DataV202,0,sizeof(HQ_REF_DATA_V202));
	 
	 		strcpy(DataV202.zqdm,HqData[jys].lpPreData[i].zqdm);
	 		strcpy(DataV202.zqmc,HqData[jys].lpPreData[i].zqmc);
        
        	sprintf(temp,"%7.2f",HqData[jys].lpRefData[i].zdjg*100.00);
	 		DataV202.zdjg =atol(temp);
	 	
	 		sprintf(temp,"%7.2f",HqData[jys].lpPreData[i].zrsp*100.00);
	 		DataV202.zrsp =atol(temp)-DataV202.zdjg;
	 	
	 		sprintf(temp,"%7.2f",HqData[jys].lpPreData[i].jrkp*100.00);
	 		DataV202.jrkp =atol(temp)-DataV202.zdjg;
	 	
	 		sprintf(temp,"%7.2f",HqData[jys].lpRefData[i].zgjg*100.00);
	 		DataV202.zgjg =atol(temp)-DataV202.zdjg;
	 	
	 		sprintf(temp,"%7.2f",HqData[jys].lpRefData[i].zdjm*100.00);
	 		DataV202.zdjm =atol(temp)-DataV202.zdjg;
	 	
	 		sprintf(temp,"%7.2f",HqData[jys].lpRefData[i].zgjm*100.00);
	 		DataV202.zgjm =atol(temp)-DataV202.zdjg;
	 	
	 		sprintf(temp,"%7.2f",HqData[jys].lpRefData[i].zjjg*100.00);
	 		DataV202.zjjg =atol(temp)-DataV202.zdjg;
	 	
	 		sprintf(temp,"%7.2f",HqData[jys].lpRefData[i].wb*100.00);
	 		DataV202.wb =atol(temp);
	 	
	 		DataV202.cjss =HqData[jys].lpRefData[i].cjss;
	 		DataV202.npzl =HqData[jys].lpRefData[i].npzl;
	 		DataV202.cjje =HqData[jys].lpRefData[i].cjje;
			_lwrite(lzw,(char *)&DataV202,sizeof(HQ_REF_DATA_V202));
		}
		_lclose(lzw);	
		return TRUE;	
}

int WriteDpData(int jys)
{
	_llseek(hfDp, jys*sizeof(DpData[jys]), SEEK_SET);
	_lwrite(hfDp, &DpData[jys], sizeof(DpData[jys]));
	
	return 0;
}

int WriteMmpData(int jys)
{
	_llseek(hfMmp[jys], 0, SEEK_SET);
	//_lwrite(hfMmp[jys], (int *)&MmpData[jys].recCount, sizeof(int));
	if(_hwrite(hfMmp[jys], MmpData[jys].lpMmp, (long)sizeof(MMP)*HqData[jys].recCount)
			!=(long)sizeof(MMP)*HqData[jys].recCount)
	{
		ErrMsg(NULL, "Write mmp failed");
		return -1;
	}
	
	return 0;
}

int WriteMaxMinData(int jys)
{
	_llseek(hfMaxMin[jys], 0, SEEK_SET);
	_lwrite(hfMaxMin[jys], &MaxMinData[jys], sizeof(MaxMinData[jys]));
	
	return 0;
}

long max_l(long val1, long val2)
{
	return (val1>val2)? val1:val2;
}
long min_l(long val1, long val2)
{
	return (val1<val2)? val1:val2;
}
float max_f(float val1, float val2)
{
	return (val1>val2)? val1:val2;
}
float min_f(float val1, float val2)
{
	return (val1<val2)? val1:val2;
}

extern void MsgRecv(char far *msg);
//////////////////////////////////////////////////
//����		����ȡ��ʱ�����ļ�����ʼ���ڴ��ʱ����ͷ����Ϣ
//����		��
//		   jys---����������
//������	��
//		   0  ---�ɹ�
//         -1 ---ʧ��
//�޸�����	��1997/10/15
	  
int CheckGraHead(int jys)
{
	int i;
	char temp[128];
	HFILE hFile;
	OFSTRUCT os;

	wsprintf(temp, "����ʱ����ͷ:%d", jys);
	MsgLocal(temp);
	for(i =0; i<HqData[jys].recCount; i++)
	{
		while(UDPBlockingHook());
		if(run_cancelled) break;
		
		wsprintf(temp, "%s\\%s.dat",
			GraphData[jys].szGraPath,
			HqData[jys].lpPreData[i].zqdm);
		hFile =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READ);
		//���ļ�ʧ�ܣ��������³�ʼ���ڴ��ʱ����ͷ����Ϣ
		if(hFile ==HFILE_ERROR)
			goto reset_values;
		else
		{
			//���ڴ��ʱ����ͷ����Ϣ���������������³�ʼ��
			if(_lread(hFile, &GraphData[jys].lpGraHead[i],
					sizeof(GRA_HEAD)) !=sizeof(GRA_HEAD))
				goto reset_values;
			//���ڴ��ʱ����ͷ����Ϣ���ڴ����������³�ʼ��
			if(GraphData[jys].lpGraHead[i].dateNum !=date_num)
				goto reset_values;
			_lclose(hFile);
			//����˵�����ڴ��ʱ����ͷ����Ϣ��ȷ��������ڳɽ����飬��������
			//�ڴ��������ݵ���������
			HqData[jys].lpRefData[i].npzl =GraphData[jys].lpGraHead[i].npzl
					+(HqData[jys].lpRefData[i].cjss-GraphData[jys].lpGraHead[i].npzl
						-GraphData[jys].lpGraHead[i].wpzl)/2;
			continue;
		}
		reset_values:
		HqData[jys].lpRefData[i].npzl =HqData[jys].lpRefData[i].cjss/2;
		memset(&GraphData[jys].lpGraHead[i], 0, sizeof(GRA_HEAD));
		GraphData[jys].lpGraHead[i].dateNum =date_num;
		GraphData[jys].lpGraHead[i].zrsp =HqData[jys].lpPreData[i].zrsp;
		GraphData[jys].lpGraHead[i].zgjg =GraphData[jys].lpGraHead[i].zdjg
				=HqData[jys].lpRefData[i].zjjg-HqData[jys].lpPreData[i].zrsp;
		if(hFile ==HFILE_ERROR)
		{
			hFile =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_READWRITE);
			if(hFile ==HFILE_ERROR) continue;
		}
		_lclose(hFile);
	}
	return 0;
}

BOOL WriteGraData(int jys,int i)
{ 
	char tmp[50];
	HFILE hFile;
	OFSTRUCT os;
		 
	wsprintf(tmp, "%s\\%s.dat", GraphData[jys].szGraPath,
		HqData[jys].lpPreData[i].zqdm);
	//GraphData[jys].lpGraHead[i].dateNum =date_num;
	//GraphData[jys].lpGraHead.zrsp =HqData[jys].lpRefData[i].zrsp;
	//GraphData[jys].lpGraData[i].tim =tim;
	hFile =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);
	if(hFile ==HFILE_ERROR)
		return FALSE;
	if(_llseek(hFile, sizeof(GRA_HEAD)+(GraphData[jys].lpGraHead[i].minCount-1)*sizeof(GRA_DATA),
						SEEK_SET) ==HFILE_ERROR)
		return FALSE;
	_lwrite(hFile, &GraphData[jys].lpGraData[i],sizeof(GRA_DATA));
	_llseek(hFile, 0, SEEK_SET);
	_lwrite(hFile, &GraphData[jys].lpGraHead[i],sizeof(GRA_HEAD));
	_lclose(hFile);
	
	return TRUE;
}

int WriteMinData(int jys)
{
	return 0;
}

BOOL WriteDayData(int jys)
{
	int i;
	long day_cur;
	char tmp[128];
	DAY_DATA dayData;
	HFILE hFile;
	OFSTRUCT os;
	time_t ltime;
	struct tm *ptm;
	//static BOOL fWrited[2] ={FALSE, FALSE};
	long len;
    
	if(fWrited[jys])
	{
		MsgLocal("history data already writed!");
		return TRUE;
	}
	
	MsgLocal("Write day data...");
    
	time(&ltime);
	ptm =localtime(&ltime);
	day_cur =(long)(1900+ptm->tm_year)*10000+(long)(ptm->tm_mon+1)*100+ptm->tm_mday;
	
	for (i=0;i<HqData[jys].recCount;i++) 
	{         
		while(UDPBlockingHook());
		if(run_cancelled) break;
		
		if(GraphData[jys].lpGraHead[i].minCount <=0) continue;
		
		wsprintf(tmp, "%s\\%s\\%s.day", szDataPath, (jys ==0)?"SZDAY":"SHDAY",
					HqData[jys].lpPreData[i].zqdm);                          
		hFile =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);
		if(hFile ==HFILE_ERROR)
		{
			hFile =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_READWRITE);
			if(hFile ==HFILE_ERROR)
			{
				ErrMsg(NULL, "Create file failed");
				ErrMsg(NULL, tmp);
				continue;
			}
		}
		else
		{
			_llseek(hFile, 0, SEEK_SET);
			len =_llseek(hFile, 0, SEEK_END);
			if(len!=0)
			{
				if(_llseek(hFile, len-sizeof(dayData), SEEK_SET) ==HFILE_ERROR)
				{
					_llseek(hFile, 0, SEEK_SET);
				}
				else if(_lread(hFile, &dayData, sizeof(dayData))
						!=sizeof(dayData))
				{
					ErrMsg(NULL, "Read file failed");
					ErrMsg(NULL, tmp);
					_lclose(hFile);
					continue;
				}
				else if(dayData.day ==day_cur)
				{
					_lclose(hFile);
					continue;
				}
			}
		}
		dayData.day =day_cur;
		dayData.kpjg =HqData[jys].lpPreData[i].jrkp;
		dayData.spjg =HqData[jys].lpRefData[i].zjjg;
		dayData.zgjg =HqData[jys].lpRefData[i].zgjg;
		dayData.zdjg =HqData[jys].lpRefData[i].zdjg;
		dayData.cjss =HqData[jys].lpRefData[i].cjss;
		dayData.cjje =HqData[jys].lpRefData[i].cjje;
		
		_lwrite(hFile,&dayData,sizeof(DAY_DATA));
			
		_lclose(hFile);
	}    
	
	MsgLocal("Write day data ok");
	fWrited[jys] =TRUE;
	
	return TRUE;
}

BOOL WriteWeekData(int jys)
{
	int i,j;
	char tmp[100];
	HISTORY_DATA WeekData,DayData,NextDayData;
	HFILE hWeekFile,hDayFile;
	OFSTRUCT os;
	time_t c_time1,c_time2;
	static BOOL fWrited[2] ={FALSE, FALSE};
    
	if(fWrited[jys])
	{
		MsgLocal("week data already writed");
		return TRUE;
	}
	MsgLocal("Write week data...");
	for (i=0;i<HqData[jys].recCount;i++) 
	{   
		while(UDPBlockingHook());
		if(run_cancelled) break;
		//�������ļ�
		memset(tmp,0,100);                                                              
		if(jys==0)
			wsprintf(tmp, "%s%s.day","szase\\day\\" ,
				HqData[jys].lpPreData[i].zqdm);                          
		else
			wsprintf(tmp, "%s%s.day","shase\\day\\" ,
				HqData[jys].lpPreData[i].zqdm);                          
		
		//MsgLocal(HqData[jys].lpPreData[i].zqdm);      
		hDayFile =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);
		if(hDayFile ==HFILE_ERROR)
		{
			_lclose(hDayFile);
			continue;               
		}
		_llseek(hDayFile,-1*(long)(sizeof(HISTORY_DATA)),SEEK_END);
		if(_lread(hDayFile,&DayData,sizeof(HISTORY_DATA))!=
			sizeof(HISTORY_DATA))
		{          
			_lclose(hDayFile);      
		continue;
	}        

	memcpy(&WeekData,&DayData,sizeof(HISTORY_DATA));        
	memcpy(&c_time1,DayData.date+6,sizeof(time_t));
	
		j=2;            
		while(TRUE)
		{   
			if(j>7) break;
		    _llseek(hDayFile,-j*(long)(sizeof(HISTORY_DATA)),SEEK_END);
			if(_lread(hDayFile,&NextDayData,sizeof(HISTORY_DATA))!=
				sizeof(HISTORY_DATA))                           
				break;                          
			memcpy(&c_time2,NextDayData.date+6,sizeof(time_t));      
			if((int)(difftime(c_time1,c_time2)/(24.00*60.00))>=7)
				break;
			//��������  
			WeekData.ks=NextDayData.ks;
			WeekData.cj+=NextDayData.cj;
			if(WeekData.zg<NextDayData.zg)  WeekData.zg=NextDayData.zg;
			if(WeekData.zd>NextDayData.zd)  WeekData.zg=NextDayData.zd;                     
			j++;    
		}               
		//д�����ļ�            
		if(jys==0)
			wsprintf(tmp, "%s%s.wek","szase\\week\\",
				HqData[jys].lpPreData[i].zqdm);
		else
			wsprintf(tmp, "%s%s.wek","shase\\week\\",
				HqData[jys].lpPreData[i].zqdm);
		hWeekFile =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);
		if(hWeekFile ==HFILE_ERROR)
		{
			hWeekFile =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_READWRITE);
		}  
		_llseek(hWeekFile,0L,SEEK_END);
		_lwrite(hWeekFile,&WeekData,sizeof(HISTORY_DATA));
		_lclose(hWeekFile);
		_lclose(hDayFile);
    }
	MsgLocal("Write week data ok");
	fWrited[jys] =TRUE;
	return TRUE;
}

BOOL WriteMonthData(int jys)
{
    int i,j;
    char tmp[100];
    HISTORY_DATA WeekData,MonthData,NextWeekData;
	HFILE hWeekFile,hMonthFile;
	OFSTRUCT os;
	static BOOL fWrited[2] ={FALSE, FALSE};

	if(fWrited[jys])
	{
		MsgLocal("month data already writed!");
		return TRUE;
	}
	MsgLocal("Write month data...");
	for (i=0;i<HqData[jys].recCount;i++) 
	{   
		while(UDPBlockingHook());
		if(run_cancelled) break;
		//�������ļ�
	    if(jys==0)
			wsprintf(tmp, "%s%s.wek","szase\\week\\" ,
				HqData[jys].lpPreData[i].zqdm);                          
		else
			wsprintf(tmp, "%s%s.wek","shase\\week\\" ,
				HqData[jys].lpPreData[i].zqdm);                          
		
		//MsgLocal(HqData[jys].lpPreData[i].zqdm);      
		hWeekFile =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);
		if(hWeekFile ==HFILE_ERROR)
		{
			_lclose(hWeekFile);
			continue;               
		}
		_llseek(hWeekFile,-1*(long)(sizeof(HISTORY_DATA)),SEEK_END);
		if(_lread(hWeekFile,&WeekData,sizeof(HISTORY_DATA))!=
			sizeof(HISTORY_DATA))
		{          
			_lclose(hWeekFile);     
		continue;
	}        
	
	memcpy(&MonthData,&WeekData,sizeof(HISTORY_DATA));        
	
		j=2;            
		while(TRUE)
		{   
			if(j>31)        break;
		    _llseek(hWeekFile,-j*(long)(sizeof(HISTORY_DATA)),SEEK_END);
			if(_lread(hWeekFile,&NextWeekData,sizeof(HISTORY_DATA))!=
				sizeof(HISTORY_DATA))                           
				break;                  
			if(!strncmp(WeekData.date+2,NextWeekData.date+2,2))
				break;
			//��������  
			MonthData.ks=NextWeekData.ks;
			MonthData.cj+=NextWeekData.cj;
			if(MonthData.zg<NextWeekData.zg)  MonthData.zg=NextWeekData.zg;
			if(MonthData.zd>NextWeekData.zd)  MonthData.zg=NextWeekData.zd;                 
			j++;    
		}               
		//д�����ļ�            
		if(jys==0)
			wsprintf(tmp, "%s%s.mot","szase\\month\\",
				HqData[jys].lpPreData[i].zqdm);
		else
			wsprintf(tmp, "%s%s.mot","shase\\month\\",
				HqData[jys].lpPreData[i].zqdm);
		hMonthFile =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);
		if(hMonthFile ==HFILE_ERROR)
		{
			hMonthFile =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_READWRITE);
		}  
		_llseek(hMonthFile,0L,SEEK_END);
		_lwrite(hMonthFile,&MonthData,sizeof(HISTORY_DATA));
		_lclose(hMonthFile);
		_lclose(hWeekFile);
    }
	MsgLocal("Write month data ok");
	fWrited[jys] =TRUE;
	return TRUE;
}
