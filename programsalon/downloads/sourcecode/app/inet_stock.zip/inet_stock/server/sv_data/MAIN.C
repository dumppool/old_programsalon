/* sv_data:���ݲɼ�����ֱ�ӽ��仯���ݷ��͵�ͨѶ��
*  by lgd/Paladin.InetSoft guangzhou,1996.9
*  modify by lym(�޸ĺ�������ȴ��Ըд��ԭ���ߵ�һ����) guangzhou,1997.4-1998
*/
#include <windows.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
//#include "ctl3d.h"
#include "resource.h"
#include "hq.h"
#include "sv_hq.h"
#include "data.h"
#include "lzw.h"

#define WND_CAPTION     (LPSTR)"���ݲɼ�������"
LRESULT CALLBACK MainDlgProc(HWND, UINT, WPARAM, LPARAM);

HWND ghWndMain =NULL;
HINSTANCE ghInstance =NULL;
int WinVer;
extern int Idel;

BOOL ErrMsg(HWND hWnd, LPSTR msg);
BOOL AppInit(void);
void AppExit(void);
int CheckTime(BOOL fRead);
extern BOOL JyOpen(int);
void MsgRecv(char far *msg);
void MsgLocal(LPSTR msg);
HBRUSH DrawChild(HDC hDC, HWND hWnd);
BOOL PASCAL DrawDlgFrame(HWND,int, int);
BOOL run_cancelled =FALSE;
BOOL IsWeekEnd(struct tm*);
BOOL IsMonthEnd(struct tm*);

int DoHq(void);

extern int UDPBlockingHook(void);
extern BOOL IsTodayHq(int);
extern BOOL ReadHqDat(int);
extern BOOL WriteDayData(int);
extern BOOL RemoveGDataFile(int);
extern BOOL ResetHqData(int);
extern BOOL WriteWeekData(int);
extern BOOL WriteMonthData(int);
			
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hInstPre,
					LPSTR lpszCmdLine, int nCmdShow)
{
	HWND hwnd;
	FARPROC lpDlgProc;
	
	if(hInstPre)
	{
		hwnd =FindWindow(NULL, WND_CAPTION);
		if(hwnd)
			SetFocus(hwnd);
		return FALSE;
	}
    
	ghInstance =hInstance;
		
	if(!AppInit())
	{
		ErrMsg(NULL, "AppInit failed!");
		goto appexit;
	}
	
	lpDlgProc =(FARPROC)MakeProcInstance((FARPROC)MainDlgProc, hInstance);
	if(lpDlgProc ==NULL)
	{
		ErrMsg(NULL, "MakeProcInstance failed!");
		goto appexit;
	}
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, lpDlgProc);
	FreeProcInstance(lpDlgProc);
	
appexit:
	AppExit();
	
	return 0;
}

HANDLE hLibCtl3d =NULL;
BOOL AppInit(void)
{
	extern int PCTCPInit();
//	FARPROC fpTemp;
	
	WinVer =LOBYTE(LOWORD(GetVersion()));
	
	//if(WinVer <4)
	//{
	//	hLibCtl3d =LoadLibrary("CTL3DV2.DLL");
	//	if((UINT)hLibCtl3d <=32)
	//		hLibCtl3d =LoadLibrary("CTL3D.DLL");
	//	if((UINT)hLibCtl3d >32)
	//	{
	//		fpTemp =GetProcAddress(hLibCtl3d, "Ctl3dRegister");
	//		if(fpTemp)
	//			(*fpTemp)(ghInstance);
	//		fpTemp =GetProcAddress(hLibCtl3d, "Ctl3dAutoSubclass");
	//		if(fpTemp)
	//			(*fpTemp)(ghInstance);
	//	}
	//}
	
	SetHandleCount(100);
	
	if(PCTCPInit()<0)
	{
		ErrMsg(NULL, "PCTCPInit failed!");
		//return FALSE;
	}
	if(HqInit() <0)
	{
		ErrMsg(NULL, "HqInit() failed!");
		return FALSE;
	}
	return TRUE;
}

void AppExit(void)
{
	extern void PCTCPExit();
	static BOOL fExit =FALSE;
//	FARPROC fpTemp;
	
	if(fExit) return;
	fExit =TRUE;
	
	HqExit();
	PCTCPExit();
	//if((UINT)hLibCtl3d >32)
	//{
	//	fpTemp =GetProcAddress(hLibCtl3d, "Ctl3dUnregister");
	//	if(fpTemp)
	//		(*fpTemp)(ghInstance);
	//	FreeLibrary(hLibCtl3d);
	//}
}

extern int Hq_Refresh_Time;

BOOL fAuto =TRUE;
extern BOOL fWrited[2];

extern int SendJyStart(int);
extern int ConnectHost(void);
extern int WriteHqAll(int);


LRESULT CALLBACK MainDlgProc(HWND hDlg, UINT message,
					WPARAM wParam, LPARAM lParam)
{
	char dt[40];
	static BOOL fHq_Running =FALSE, fJy_Running =FALSE;
	HWND hctl;
	char temp[300];
	DWORD dw;
			
	switch(message)
	{
		case WM_INITDIALOG:
			fHq_Running =fJy_Running =FALSE;
			SetWindowText(hDlg, WND_CAPTION);
			ghWndMain =hDlg;
			_strdate(dt);
			strcat(dt, " ");
			_strtime(&dt[strlen(dt)]);
			SetDlgItemText(hDlg, IDC_STARTTIME, dt);
			CheckDlgButton(hDlg, IDC_AUTO, fAuto);
			if(ConnectHost() <0)
				ErrMsg(hDlg, "warning: Comm server not start");
			PostMessage(hDlg, WM_USER+1, 0, 0L);
		return TRUE;
		case WM_TIMER:
			if(wParam==1)
            {
            	KillTimer(hDlg,1);
            	DoHq();
            	if(!run_cancelled)
            		SetTimer(hDlg,1,Idel,NULL);
			}
		break;
		case WM_USER+1:
			CheckTime(TRUE);
			SetTimer(hDlg,1,Idel,NULL);
		break;
		
		case WM_COMMAND:
			switch(wParam)
			{
				case IDC_AUTO:
					if(HIWORD(lParam) ==BN_CLICKED)
					{
						if(IsDlgButtonChecked(hDlg, IDC_AUTO))
						{
							hctl =GetDlgItem(hDlg, IDC_DAY);
							EnableWindow(hctl, FALSE);
							hctl =GetDlgItem(hDlg, IDC_WEEK);
							EnableWindow(hctl, FALSE);
							hctl =GetDlgItem(hDlg, IDC_MONTH);
							EnableWindow(hctl, FALSE);
						}
					}
				break;

				case IDC_MANU:
					if(HIWORD(lParam) ==BN_CLICKED)
					{
						if(IsDlgButtonChecked(hDlg, IDC_MANU))
						{
							hctl =GetDlgItem(hDlg, IDC_DAY);
							EnableWindow(hctl, TRUE);
							hctl =GetDlgItem(hDlg, IDC_WEEK);
							EnableWindow(hctl, TRUE);
							hctl =GetDlgItem(hDlg, IDC_MONTH);
							EnableWindow(hctl, TRUE);
						}
					}
				break;
				
				case IDC_DAY:
					if(HqTime[0].fRunning ==FALSE
						&& HqTime[1].fRunning ==FALSE)
					{         
						WriteDayData(0);
						WriteDayData(1);
					}
				break;
				case IDC_WEEK:
					if(HqTime[0].fRunning ==FALSE
						&& HqTime[1].fRunning ==FALSE)
					{         
					if(!fAuto && MessageBox(hDlg,"�Ǳ������������","����ע��",MB_YESNO|MB_DEFBUTTON2)==IDYES)
					{
							WriteWeekData(0);
							WriteWeekData(1);
						}
					}
				break;
				case IDC_MONTH:
					if(HqTime[0].fRunning ==FALSE
						&& HqTime[1].fRunning ==FALSE)
					{         
					if(!fAuto && MessageBox(hDlg,"�Ǳ������������","����ע��",MB_YESNO|MB_DEFBUTTON2)==IDYES)
					{
							WriteMonthData(0);
							WriteMonthData(1);
						}
							
					}       
				break;
				case IDCANCEL:
					if(MessageBox(hDlg, "��Ҫ�˳���?", "����ע��",
							MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2) ==IDNO)
						break;
					KillTimer(hDlg,1);
					EndDialog(hDlg, 0);
					ghWndMain =NULL;
					PostQuitMessage(0);
				break;
				case IDOK:
					dw =SendDlgItemMessage(hDlg, IDL_MSG, LB_GETCURSEL, 0, 0L);
					if(dw !=LB_ERR)
					{
						SendDlgItemMessage(hDlg, IDL_MSG, LB_GETTEXT, (int)dw, (LPARAM)(LPSTR)temp);
						MessageBox(hDlg, temp, "Message", MB_OK);
					}
				break;
			}
		break;
	}
	
	return FALSE;
}

BOOL ErrMsg(HWND hWnd, LPSTR msg)
{
	//char tmp[256];
	DWORD dw;
	
	//if(ghWndMain)
	{
		if((dw =SendDlgItemMessage(ghWndMain, IDC_LISTERR,
				LB_ADDSTRING, 0, (LPARAM)(LPSTR)msg))==LB_ERR)
			SendDlgItemMessage(ghWndMain, IDC_LISTERR,
				LB_RESETCONTENT, 0, (LPARAM)(LPSTR)msg);
		else
			SendDlgItemMessage(ghWndMain, IDC_LISTERR,
				LB_SETCURSEL, (int)dw, 0L);
	}
	
	//msgbox_exist =TRUE;
	//if(strlen(msg)>=250) *(msg+250) =0;
	//wsprintf(tmp, "Error message:\n %s", msg);
	//MessageBox(hWnd, tmp, WND_CAPTION, MB_OK|MB_ICONSTOP);
	
	return FALSE;
}

void DelSpaces(LPSTR lpstr)
{
	return;
}

BOOL GetInitString(char *Entry, char *Item, char *buf)
{
	GetPrivateProfileString(Entry, Item, "", buf, 256, "sv_data.ini");
	if(*buf ==0) return FALSE;
	return TRUE;
}

void PutInitString(char *Entry, char *Item, char *buf)
{
	WritePrivateProfileString(Entry, Item, buf, "sv_data.ini");
}

int GetInitInt(char *Entry, char *Item)
{
	return GetPrivateProfileInt(Entry, Item, -1, "sv_data.ini");
}

void MsgSend(char far *msg)
{
	SetDlgItemText(ghWndMain, IDC_STATUS_SEND, msg);
}

void MsgRecv(char far *msg)
{
	SetDlgItemText(ghWndMain, IDC_STATUS_RECV, msg);
}

void MsgLocal(LPSTR msg)
{
	SetDlgItemText(ghWndMain, IDC_STATE_LOCAL, msg);
}

int date_num =-1, tim =-1;
long tim_seconds =0;
int CheckTime(BOOL fRead)
{
	char tmp[40], tmp1[41];
	LPSTR tok;
	int jys, ret;
	static long time_start =-1;
	//struct tm *ptm;
	
	//HFILE hFile;
	//OFSTRUCT os;

	_strdate(tmp);
	date_num =100*atoi(strtok(tmp, "/"));
	tok =strtok(NULL, "/");
	date_num +=atoi(tok);
		
	_strtime(tmp);		//hh:mm:ss
	strcpy(tmp1, tmp);
	tok =strtok(tmp, ":");
	tim =atoi(tok)*60;
	tim +=atoi(strtok(NULL, ":"));
	tim_seconds =(long)tim*60+atoi(strtok(NULL, ":"));
	
	if(time_start ==-1) time_start =tim_seconds;
	else if(tim_seconds >time_start)
		MsgLocal(tmp1);
	
	for(jys =0; jys <2; jys++)
	{    
		//�˴����з���������
		if(tim<HqTime[jys].am_min_start-1
				|| (tim-5) >HqTime[jys].pm_min_end
				|| (tim <HqTime[jys].pm_min_start 
					&& tim >HqTime[jys].am_min_end))
		{
			if(HqTime[jys].fRunning ==TRUE)
			{
				HqTime[jys].fRunning =FALSE;
				CloseDbfFile(jys);
				//SendJyStart(jys);
				if(fAuto && tim-5 >HqTime[jys].pm_min_end)
					SendMessage(ghWndMain, WM_COMMAND, IDC_DAY, 0L);
				
			}
		}
		else if(HqTime[jys].fRunning ==FALSE)
		{   
			if(OpenDbfFile(jys))
			{
				if(JyOpen(jys))
				{
					if(ReadHqFirst(jys))
					{				
						HqTime[jys].fRunning =TRUE;     
						fWrited[jys]=FALSE;				
						//ReadHqFirst(jys);
						WriteHqData(jys);
						WriteMmpData(jys);
						WriteMaxMinData(jys);
						WriteDpData(jys);
						//SendJyStart(jys);
					}
					else
					{   
					    MsgLocal("CheckTime:���г�ʼ��ʧ��");
						CloseDbfFile(jys);
					}
				}
				else
				{
				    MsgLocal("CheckTime:δ����");
					CloseDbfFile(jys);
				}
				
			}
			else
			{
				MsgLocal("CheckTime:�򿪽����������ļ���");
				CloseDbfFile(jys);
			}
		}
	}
	ret =(int)(tim_seconds-time_start);
	time_start =tim_seconds;
	
	return ret;
}

int RefreshHqData(int jys);

int DoHq(void)
{
	BOOL fWritedSz =FALSE;
	
		while(UDPBlockingHook());

		if(CheckTime(TRUE) >=0&&!run_cancelled)
		{
			if(HqTime[0].fRunning)
			{
				if(!RefreshHqData(0))
				{
					MsgLocal("��������ˢ��ʧ�ܣ���������");
				 	HqTime[0].fRunning =FALSE;
				 	CloseDbfFile(0);
				}
			}
			if(HqTime[1].fRunning)  
			{
				if(!RefreshHqData(1))
				{
					MsgLocal("�Ϻ�����ˢ��ʧ�ܣ���������");
				 	HqTime[1].fRunning =FALSE;
				 	CloseDbfFile(1);				
				}
			}
		}	
	return 0;
}

int RefreshHqData(int jys)
{
	if(HqRefresh(jys))
	{
		WriteHqData(jys);
		WriteMmpData(jys);
		WriteMaxMinData(jys);
		WriteDpData(jys);
		
		return TRUE;
	}
	else
		return FALSE;
}

BOOL IsWeekEnd(struct tm *ptm)
{
	return TRUE;
}

BOOL IsMonthEnd(struct tm *ptm)
{
	return TRUE;
}

