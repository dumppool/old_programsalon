#include <windows.h>
#include <windowsx.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>                 
#include <sys\stat.h>   
#include <fcntl.h>              
#include <time.h>

#include "dbf_data.h"
#include "sv_jy.h"
#include "jydest.h"
#include "rsa.h"


#define MAX_PATH_LEN		128
#define	START_REC_NO		100


DBF_DATA CommFile;

typedef struct  tag_ANSFILE
{
	int hf[MAX_ZQS_COUNT];
	int recnum[MAX_ZQS_COUNT];
	char path[MAX_ZQS_COUNT][MAX_PATH_LEN];
}ANSFILE;
ANSFILE AnsFile;

typedef struct  tag_REQFILE
{
	int hf[MAX_ZQS_COUNT];
	int recnum[MAX_ZQS_COUNT];
	int currec[MAX_ZQS_COUNT];
}REQFILE;
REQFILE ReqFile;

int ZqsCount;
char * CommBuffer;
short rlen,hlen;

char RetFilePath[80];
BOOL fUseJy =FALSE,fTestJy=FALSE,fRsa=FALSE;
int Thrd_SendJycx(int sd, int reqType, void *lpBuf, int);


extern int sdJy;

extern BOOL GetInitString(LPSTR, LPSTR, LPSTR);
extern BOOL PutInitString(LPSTR, LPSTR, LPSTR);
extern BOOL ErrMsg(HWND, LPSTR);

//extern int UDP_SendBuff(LPSTR, int, LPSTR, int, LPDEST_INFO );


int JyInit(void)
{       
		int i;
	    char tmp[256], temp[256],temp1[256];
		char * prt;

		memset(&ReqFile,0,sizeof(REQFILE));
		memset(&AnsFile,0,sizeof(ANSFILE));

		CommBuffer =NULL;
		CommFile.hf =-1;
		
		if(GetInitString("JY", "RUN", tmp))
		{
			if(tmp[0] =='N' || tmp[0] =='n')
			{
				fUseJy =FALSE;
				return 0;
			}
			else
				fUseJy =TRUE;
		}


		if(GetInitString("JY", "TEST", tmp))
		{
			if(tmp[0] =='Y' || tmp[0] =='y')
				fTestJy =TRUE;
			else
				fTestJy =FALSE;
		}
		else 
			fTestJy =FALSE;
         
		if(GetInitString("JY", "RSA", tmp))
		{
			if(tmp[0] =='Y' || tmp[0] =='y')
			{
				fRsa =TRUE;
				if(!ReadRsaFile(R,PK,SK))
					ErrMsg(NULL,"��RSA���ܲ���ʧ�ܣ�����ϵͳ������[Init]");
			}
		}

		ZqsCount=0;

		for(i=0;i<MAX_ZQS_COUNT;i++)
		{
			wsprintf(temp,"%s%d","COMMFILE",i);
			if(!GetInitString("JY", temp, tmp))
			{
				if(ZqsCount==0)
				{
					wsprintf(temp, "���ܷ�������%s:\n %s",
						(LPSTR)"COMMFILE", (LPSTR)tmp);
					ErrMsg(NULL, temp);
				}
				break;
			}
			else
			{
				ZqsCount++;
				prt=strstr(tmp,";");
				if(prt==NULL) 
				{
					ErrMsg(NULL,"format Reqfile;AnsFile");
					return -1;
				}
				else *prt=0;

				strcpy(temp1,tmp);
				if(access(temp1,_S_IREAD|_S_IWRITE) <0)
				{
					wsprintf(temp, "���ܴ�ȡ%s:\n %s",
					(LPSTR)"COMMFILE", (LPSTR)temp1);
					ErrMsg(NULL, temp);
					return -1;
				}  
                
				ReqFile.hf[i]=OpenDbfBase(temp1,O_RDWR);
				if(i==0)
					CommFile.hf=ReqFile.hf[0];
				
				if (ReqFile.hf[i]==-1)
				{
					wsprintf(temp, "���ܴ�%s:\n %s",
						(LPSTR)"COMMFILE", (LPSTR)temp1);
					ErrMsg(NULL, temp);
					return -1;
				} 
				if(i==0)
				{
					if (InitBase(CommFile.hf,&CommFile.dbfStruct,
					&CommFile.fldStruct,&CommFile.fldCount)
					!=SUCCEED) 
					{
						wsprintf(temp, "���ܴ�ʼ��%s:\n %s",
							(LPSTR)"COMMFILE", (LPSTR)temp1);
						ErrMsg(NULL, temp);
						return -1;
					}
					rlen=*(short *)CommFile.dbfStruct.rlen;
					hlen=*(short *)CommFile.dbfStruct.hlen;
				}

				ReqFile.recnum[i]=GetRecNum(ReqFile.hf[i]);

				strcpy(temp1,++prt);
				AnsFile.hf[i]=OpenDbfBase(temp1,O_RDWR);				
				if (ReqFile.hf[i]==-1)
				{
					wsprintf(temp, "���ܴ�%s:\n %s",
						(LPSTR)"COMMFILE", (LPSTR)temp1);
					ErrMsg(NULL, temp);
					return -1;
				} 

				prt =strrchr(temp1,'\\');
				++prt; *prt =0;
				strcpy(&AnsFile.path[i][0],temp1);

				AnsFile.recnum[i]=GetRecNum(AnsFile.hf[i]);
				AnsFile.recnum[i]=min(AnsFile.recnum[i],ReqFile.recnum[i]);
				ReqFile.recnum[i]=AnsFile.recnum[i];
			}
		}

		if(ZqsCount)
		if((CommBuffer =GlobalAllocPtr(GHND,*(short*)CommFile.dbfStruct.rlen))==NULL)
		{
		      ErrMsg(NULL, "���ܷ��佻���ļ���¼�ڴ�!");
		      return -1;
		}
		return 0;		
}

int JyExit(void)
{
	int i;

		for(i=0;i<ZqsCount;i++)
		{
			if(ReqFile.hf[i]!=-1)
				CloseDbf(ReqFile.hf[i]);
			if(AnsFile.hf[i]!=-1)
				CloseDbf(AnsFile.hf[i]);
		}
		if(CommFile.fldStruct)
		GlobalFreePtr(CommFile.fldStruct);
		if(CommBuffer)
        GlobalFreePtr(CommBuffer);		

		return 0;
}

int Jy_Zqsxx(int sd)
{
	int len;

	BYTE SendBuff[1024];

	strcpy(SendBuff, JY_ZQSXX_HEAD);
	len =strlen(JY_ZQSXX_HEAD);
	//memcpy(&SendBuff[len],&Zqsxx,sizeof(ZQSXX));
	//len+=sizeof(Zqsxx);
	
	memcpy(&SendBuff[len],R,DATALENGTH);
	len +=DATALENGTH;
	memcpy(&SendBuff[len],PK,DATALENGTH);
	len +=DATALENGTH;
	UDP_SendBuff("RSA.R.PK", sd, SendBuff, len,NULL);
	return 0;
}

void ClearAns(LPJY_DEST lpJyDest)
{
	char* buff;
    HANDLE hd;    
	if((hd =GlobalAlloc(GHND,rlen))==NULL)	return;
    if((buff=GlobalLock(hd))==NULL)	return;
	memset(buff,' ',rlen);
	WriteRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,buff);
	GlobalUnlock(hd);
	GlobalFree(hd);
}


void ClearReq(LPJY_DEST lpJyDest)
{
	char* buff;
    HANDLE hd;    
	if((hd =GlobalAlloc(GHND,rlen))==NULL)	return;
    if((buff=GlobalLock(hd))==NULL)	return;
	memset(buff,' ',rlen);
	buff[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]='0';
	WriteRecord(ReqFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,buff);
	GlobalUnlock(hd);
	GlobalFree(hd);
}

int Jy_ChkUsr(int sd, int jyNum, LPJY_ASK_CHKUSR AskChkUser)
{
	int ret;
	LPJY_DEST lpJyDest;
    char temp[20];  
	short Qsid;

	if(ZqsCount ==1)
		Qsid =1;
	else
	Qsid =AskChkUser->zqsid;

	if(ReqFile.hf[Qsid -1] ==-1)
		return ANS_SYS_ERR;

	ret =CheckJyDest(sd,REQ_CHKUSR, AskChkUser->jys,
			AskChkUser->gddm, -1, &lpJyDest);
	memset(CommBuffer,' ',rlen);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_GDDM],AskChkUser->gddm);
	CommBuffer[*(short*)(CommFile.fldStruct[fld_STKNO].offset)]
		=(AskChkUser->jys ==0)?'Z':'H';
	StringToFld(CommBuffer,CommFile.fldStruct[fld_JYMM],AskChkUser->jymm);      
	CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_CHKUSR;
	CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';

	wsprintf(temp,"%d",sd);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_ADDR],temp);
	wsprintf(temp,"%d",jyNum);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);

	if(lpJyDest==NULL)
		lpJyDest=GetFirstIdelRec();
	if(lpJyDest==NULL)
	{
		ReqFile.currec[Qsid-1]++;
		if(ReqFile.currec[Qsid-1]>ReqFile.recnum[Qsid-1])
		{
			ErrMsg(NULL, "�޿��н��ױ���!");      
			return ANS_SYS_ERR;
		}
		lpJyDest=AddJyDest(sd, REQ_CHKUSR, AskChkUser->jys,
				ReqFile.currec[Qsid-1], AskChkUser->gddm, jyNum,Qsid-1);

		if(lpJyDest ==NULL)
		{
			ErrMsg(NULL, "���ܼӽ��ױ���!");
			return ANS_SYS_ERR;
		}
		ClearAns(lpJyDest);
		if(WriteRecord(ReqFile.hf[Qsid-1],lpJyDest->recNum,
				hlen,rlen,CommBuffer) !=0)
		{
			ErrMsg(NULL, "����д�����ļ�!");      
			return ANS_SYS_ERR;
		}
	}
	else
	{
		ClearAns(lpJyDest);
		if(WriteRecord(ReqFile.hf[Qsid-1],lpJyDest->recNum,
				hlen,rlen,CommBuffer)!=0)
		{
			ErrMsg(NULL, "����д�����ļ�1!");      
			return ANS_SYS_ERR;
		}
		strcpy(lpJyDest->gddm,AskChkUser->gddm);
		ChangeJyDest(sd, lpJyDest, REQ_CHKUSR, AskChkUser->jys,
			Qsid -1,jyNum);
	}

	if(fTestJy)
	{
		Sleep(1000);
		CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_NULL;
		CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)]=ANS_SUCC;
		CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
		wsprintf(temp,"%d",jyNum);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);

		WriteRecord(AnsFile.hf[Qsid-1],lpJyDest->recNum,hlen,
			rlen,CommBuffer);
	}
	return 0;
}

int Jy_ChgPwd(int sd, int jyNum, LPJY_ASK_CHGPWD AskChgPwd)
{
	LPJY_DEST lpJyDest=NULL;
	int ret;
	char temp[20];

	ret =CheckJyDest(sd, REQ_CHGPWD, AskChgPwd->jys, AskChgPwd->gddm,
			AskChgPwd->userId, &lpJyDest);

	if(ret==-1)
		return ANS_SYS_ERR;
	if(ret==-2)
		return ANS_SUSP_REQ;
	if(ret==-3)
		return ANS_NO_PRIV;

	if(ReqFile.hf[lpJyDest->zqsid] ==-1)
		return ANS_SYS_ERR;

	memset(CommBuffer,' ',*(short *)CommFile.dbfStruct.rlen);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_GDDM],AskChgPwd->gddm);
	CommBuffer[*(short*)(CommFile.fldStruct[fld_STKNO].offset)]
		=(AskChgPwd->jys ==0)?'Z':'H';
	StringToFld(CommBuffer,CommFile.fldStruct[fld_JYMM],AskChgPwd->xmm);      
	CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_CHGPWD;
	CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';

	wsprintf(temp,"%d",sd);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_ADDR],temp);
	wsprintf(temp,"%d",jyNum);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);

	ClearAns(lpJyDest);	
	if(WriteRecord(ReqFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,CommBuffer)!=0)
	{
		ErrMsg(NULL, "����д�����ļ�!");
		return ANS_SYS_ERR;
	}
	ChangeJyDest(sd, lpJyDest, REQ_CHGPWD, AskChgPwd->jys, -1, jyNum);

	if(fTestJy)
	{
		Sleep(1000);
		CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_NULL;
		CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)]=ANS_SUCC;
		CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
		wsprintf(temp,"%d",jyNum);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);

		WriteRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,CommBuffer);
	}

	return 0;
}

int Jy_BuySell(int sd, int jyNum, LPJY_ASK_BUYSELL AskBuySell)
{
	LPJY_DEST lpJyDest;
	int ret;
	char temp[20];

	ret =CheckJyDest(sd, REQ_BUYSEL, AskBuySell->jys, AskBuySell->gddm,
				AskBuySell->userId, &lpJyDest);

	if(ret==-1)
		return ANS_SYS_ERR;
	if(ret==-2)
		return ANS_SUSP_REQ;
	if(ret==-3)
		return ANS_NO_PRIV;
	
	if(ReqFile.hf[lpJyDest->zqsid] ==-1)
		return ANS_SYS_ERR;

	memset(CommBuffer,' ',*(short *)CommFile.dbfStruct.rlen);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_GDDM],AskBuySell->gddm);
	CommBuffer[*(short*)(CommFile.fldStruct[fld_STKNO].offset)]
		=(AskBuySell->jys ==0)?'Z':'H';                         
	StringToFld(CommBuffer,CommFile.fldStruct[fld_GPDM],AskBuySell->gpdm);
	sprintf(temp,"%12ld",AskBuySell->wtgs);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_WTGS],temp);            
	sprintf(temp,"%12.2f",(double)(AskBuySell->wtjg/100.00));
	StringToFld(CommBuffer,CommFile.fldStruct[fld_WTJG],temp);      
	if(AskBuySell->bs =='B')
		CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_BUY;
	else if(AskBuySell->bs =='S')
		CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_SELL;
	else
		CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]='E';

	CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';	
 	wsprintf(temp,"%d",sd);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_ADDR],temp);
	wsprintf(temp,"%d",jyNum);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);

	ClearAns(lpJyDest);	
	if(WriteRecord(ReqFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,CommBuffer)!=0)
	{
		ErrMsg(NULL, "����д�����ļ�!");      
		return ANS_SYS_ERR;
	}
	if(ChangeJyDest(sd, lpJyDest, REQ_BUYSEL, AskBuySell->jys, -1, jyNum)<0)
		return ANS_SYS_ERR;

	if(fTestJy)
	{
		Sleep(1000);
		CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_NULL;
		CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)]=ANS_SUCC;
		CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
		StringToFld(CommBuffer,CommFile.fldStruct[fld_HTHM],"000068");
		wsprintf(temp,"%d",jyNum);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);
	    WriteRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,CommBuffer);
	}

	return 0;
}

int Jy_Cancel(int sd, int jyNum, LPJY_ASK_CANCEL AskCancel)
{
	LPJY_DEST lpJyDest;
	int ret,i;
	char temp[20];
	HFILE hFile;
	OFSTRUCT os;

	ret =CheckJyDest(sd, REQ_CANCEL, AskCancel->jys, 
			AskCancel->gddm, AskCancel->userId,	&lpJyDest);
	if(ret==-1)
		return ANS_SYS_ERR;
	if(ret==-2)
		return ANS_SUSP_REQ;
	if(ret==-3)
		return ANS_NO_PRIV;
	
	if(ReqFile.hf[lpJyDest->zqsid] ==-1)
		return ANS_SYS_ERR;
	
	for(i=0;i<AskCancel->cancelCount;i++)
	{
		memset(CommBuffer,' ',*(short *)CommFile.dbfStruct.rlen);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_GDDM],AskCancel->gddm);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_HTHM],AskCancel->Cancel[i].hthm);          
		CommBuffer[*(short*)(CommFile.fldStruct[fld_STKNO].offset)]
			=(AskCancel->jys ==0)?'Z':'H';                      
		CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_CANCEL;
		CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
 		wsprintf(temp,"%d",sd);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_ADDR],temp);
		wsprintf(temp,"%d",jyNum);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);

		ClearAns(lpJyDest);		
		if(WriteRecord(ReqFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,
			CommBuffer)!=0)
		{
			ErrMsg(NULL, "����д�����ļ�!");      
			return ANS_SYS_ERR;
		}
	}
	ChangeJyDest(sd, lpJyDest, REQ_CANCEL, AskCancel->jys, -1, jyNum);
	lpJyDest->recCount =AskCancel->cancelCount;

	if(fTestJy)
	{
		Sleep(1000);
		CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)]=ANS_SUCC;
		CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
		wsprintf(temp,"%d",AskCancel->cancelCount);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_JYMM],temp);

		wsprintf(temp,"%d",jyNum);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);

	    WriteRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,
			CommBuffer);

		wsprintf(temp,"%s%d%s",AnsFile.path[lpJyDest->zqsid],lpJyDest->recNum,".ANS");
		hFile =OpenFile(temp, &os, OF_CREATE|OF_SHARE_DENY_NONE|OF_WRITE);
		if(hFile ==HFILE_ERROR)
			return ANS_SYS_ERR;

		for(i=0;i<AskCancel->cancelCount;i++)
		{
			memset(CommBuffer,' ',*(short *)CommFile.dbfStruct.rlen);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_GDDM],AskCancel->gddm);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_HTHM],AskCancel->Cancel[i].hthm);          
			CommBuffer[*(short*)(CommFile.fldStruct[fld_STKNO].offset)]
				=(AskCancel->jys ==0)?'Z':'H';                      
			CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_CANCEL;

			CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)]=ANS_SUCC;
			CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';

 			wsprintf(temp,"%d",sd);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_ADDR],temp);
			wsprintf(temp,"%d",jyNum);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);
			_lwrite(hFile,&CommBuffer[1], rlen-1);
			_lwrite(hFile,"\r\n",2);		
		}
		_lclose(hFile);
	}

	return 0;
}

int Jy_Yecx(int sd, int jyNum, LPJY_ASK_YECX AskYecx)
{
	LPJY_DEST lpJyDest;
	int ret,i=0;
	char temp[20];
	HFILE hFile;
	OFSTRUCT os;

	ret =CheckJyDest(sd, REQ_YECX, AskYecx->jys, AskYecx->gddm,
				AskYecx->userId, &lpJyDest);
	if(ret==-1)
		return ANS_SYS_ERR;
	if(ret==-2)
		return ANS_SUSP_REQ;
	if(ret==-3)
		return ANS_NO_PRIV;
	
	if(ReqFile.hf[lpJyDest->zqsid] ==-1)
		return ANS_SYS_ERR;

	memset(CommBuffer,' ',*(short *)CommFile.dbfStruct.rlen);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_GDDM],AskYecx->gddm);
	CommBuffer[*(short*)(CommFile.fldStruct[fld_STKNO].offset)]
		=(AskYecx->jys ==0)?'Z':'H';                        
	StringToFld(CommBuffer,CommFile.fldStruct[fld_GPDM],AskYecx->gpdm);      
	CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_YECX;
	CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
 	wsprintf(temp,"%d",sd);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_ADDR],temp);
	wsprintf(temp,"%d",jyNum);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);

	ClearAns(lpJyDest);	
    wsprintf(temp,"%s%d%s",AnsFile.path[lpJyDest->zqsid],lpJyDest->recNum,".ANS");
    remove(temp);
	if(WriteRecord(ReqFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,
		CommBuffer)!=0)
	{
		ErrMsg(NULL, "����д�����ļ�!");
		return ANS_SYS_ERR;
	}
	if(ChangeJyDest(sd, lpJyDest, REQ_YECX, AskYecx->jys, -1, jyNum) <0)
		return ANS_SYS_ERR;

	if(fTestJy)
	{
		Sleep(1000);
		wsprintf(temp,"%s%d%s",AnsFile.path[lpJyDest->zqsid],lpJyDest->recNum,".ANS");
		hFile =OpenFile(temp, &os, OF_CREATE|OF_SHARE_DENY_NONE|OF_WRITE);
		if(hFile ==HFILE_ERROR)
			return 0;

		for(i=0;i<22;i++)
		{
			memset(CommBuffer,0,sizeof(CommBuffer));
			wsprintf(temp,"%04d",i+1);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_GPDM],temp);      

			wsprintf(temp,"%8d",(i+1)*10);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_WTGS],temp);      

			wsprintf(temp,"%8d",(i+1)*20);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_WTJG],temp);      

			StringToFld(CommBuffer,CommFile.fldStruct[fld_DATE],"111111");      
			CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
			_lwrite(hFile,&CommBuffer[1], rlen-1);
			_lwrite(hFile,"\r\n",2);
		}
		_lclose(hFile);

		CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)]=ANS_SUCC;
		CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
		StringToFld(CommBuffer,CommFile.fldStruct[fld_JYMM],"22");

		StringToFld(CommBuffer,CommFile.fldStruct[fld_WTGS],"9000000.12");
		StringToFld(CommBuffer,CommFile.fldStruct[fld_WTJG],"2000000.99");
		wsprintf(temp,"%d",jyNum);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);

	    WriteRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,
			CommBuffer);
	}	
	
	return 0;
}

int Jy_Cjcx(int sd, int jyNum, LPJY_ASK_CJCX AskCjcx)
{
	LPJY_DEST lpJyDest;
	int ret,i=0;
	char temp[20];
	HFILE hFile;
	OFSTRUCT os;

	ret =CheckJyDest(sd, REQ_CJCX, AskCjcx->jys, AskCjcx->gddm, AskCjcx->userId, &lpJyDest);

	if(ret==-1)
		return ANS_SYS_ERR;
	if(ret==-2)
		return ANS_SUSP_REQ;
	if(ret==-3)
		return ANS_NO_PRIV;
	
	if(ReqFile.hf[lpJyDest->zqsid] ==-1)
		return ANS_SYS_ERR;
      
	memset(CommBuffer,' ',*(short *)CommFile.dbfStruct.rlen);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_GDDM],AskCjcx->gddm);
	CommBuffer[*(short*)(CommFile.fldStruct[fld_STKNO].offset)]
		=(AskCjcx->jys ==0)?'Z':'H';                        
	StringToFld(CommBuffer,CommFile.fldStruct[fld_DATE],AskCjcx->cjrq);      
	StringToFld(CommBuffer,CommFile.fldStruct[fld_HTHM],AskCjcx->hthm);      
	CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_CJCX;
	CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
 	wsprintf(temp,"%d",sd);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_ADDR],temp);
	wsprintf(temp,"%d",jyNum);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);
	
	ClearAns(lpJyDest);
    wsprintf(temp,"%s%d%s",AnsFile.path[lpJyDest->zqsid],lpJyDest->recNum,".ANS");
    remove(temp);
	if(WriteRecord(ReqFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,
		CommBuffer)!=0)
	{
		ErrMsg(NULL, "����д�����ļ�!");
		return ANS_SYS_ERR;
	}
	if(ChangeJyDest(sd, lpJyDest, REQ_CJCX, AskCjcx->jys, -1, jyNum) <0)
	{
		ErrMsg(NULL,"����Jy_Cjcx:ChangeJyDest");
		return ANS_SYS_ERR;
	}
	if(fTestJy)
	{
		Sleep(1000);

		CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)]=ANS_SUCC;
		CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
		StringToFld(CommBuffer,CommFile.fldStruct[fld_JYMM],"22");
		wsprintf(temp,"%d",jyNum);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);

	    WriteRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,
			CommBuffer);

		wsprintf(temp,"%s%d%s",AnsFile.path[lpJyDest->zqsid],lpJyDest->recNum,".ANS");
		hFile =OpenFile(temp, &os, OF_CREATE|OF_SHARE_DENY_NONE|OF_WRITE);
		if(hFile ==HFILE_ERROR)
			return ANS_SYS_ERR;

		for(i=0;i<22;i++)
		{
			CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)]=i-(int)(i/2)*2==0 ?'B':'S';
			wsprintf(temp,"%04d",i+1);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_GPDM],temp);      

			wsprintf(temp,"%8d",(i+1)*100);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_WTGS],temp);      

			wsprintf(temp,"%8d",i+10);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_WTJG],temp);      

			wsprintf(temp,"%06d",i+100);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_HTHM],temp);      

			StringToFld(CommBuffer,CommFile.fldStruct[fld_DATE],"111111");      
			CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
		
			_lwrite(hFile,&CommBuffer[1], rlen-1);
			_lwrite(hFile,"\r\n",2);
		}
		_lclose(hFile);
	}	
	return 0;
}

int Jy_Wtcx(int sd, int jyNum, LPJY_ASK_WTCX AskWtcx)
{
	LPJY_DEST lpJyDest;
	int ret,i=0;
	char temp[20];
	HFILE hFile;
	OFSTRUCT os;

	ret =CheckJyDest(sd, REQ_WTCX, AskWtcx->jys, AskWtcx->gddm,
		AskWtcx->userId, &lpJyDest);
	if(ret==-1)
		return ANS_SYS_ERR;
	if(ret==-2)
		return ANS_SUSP_REQ;
	if(ret==-3)
		return ANS_NO_PRIV;
	
	if(ReqFile.hf[lpJyDest->zqsid] ==-1)
		return ANS_SYS_ERR;

	memset(CommBuffer,' ',*(short *)CommFile.dbfStruct.rlen);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_GDDM],AskWtcx->gddm);
	CommBuffer[*(short*)(CommFile.fldStruct[fld_STKNO].offset)]
		=(AskWtcx->jys ==0)?'Z':'H';                        
	StringToFld(CommBuffer,CommFile.fldStruct[fld_DATE],AskWtcx->wtrq);      
	StringToFld(CommBuffer,CommFile.fldStruct[fld_HTHM],AskWtcx->hthm);      
	CommBuffer[*(short*)(CommFile.fldStruct[fld_ASKNO].offset)]=REQ_WTCX;
	CommBuffer[*(short*)(CommFile.fldStruct[fld_JYMM].offset)]=AskWtcx->cdcx;
	CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
	wsprintf(temp,"%d",sd);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_ADDR],temp);
	wsprintf(temp,"%d",jyNum);
	StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);
	
	ClearAns(lpJyDest);
    wsprintf(temp,"%s%d%s",AnsFile.path[lpJyDest->zqsid],lpJyDest->recNum,".ANS");
    remove(temp);
	if(WriteRecord(ReqFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,rlen,
		CommBuffer)!=0)
	{
		ErrMsg(NULL, "����д�����ļ�!");
		return ANS_SYS_ERR;
	}

	if(ChangeJyDest(sd, lpJyDest, REQ_WTCX, AskWtcx->jys, -1, jyNum) <0)
		return ANS_SYS_ERR;

	if(fTestJy)
	{
		Sleep(1000);

		CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)]=ANS_SUCC;
		CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';
		StringToFld(CommBuffer,CommFile.fldStruct[fld_JYMM],"22");
		wsprintf(temp,"%d",jyNum);
		StringToFld(CommBuffer,CommFile.fldStruct[fld_SERI],temp);

	    WriteRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,
			rlen,CommBuffer);

		wsprintf(temp,"%s%d%s",AnsFile.path[lpJyDest->zqsid],lpJyDest->recNum,".ANS");
		hFile =OpenFile(temp, &os, OF_CREATE|OF_SHARE_DENY_NONE|OF_WRITE);
		if(hFile ==HFILE_ERROR)
			return ANS_SYS_ERR;
		for(i=0;i<22;i++)
		{
			CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)]=i-(int)(i/2)*2==0 ?'B':'S';
			wsprintf(temp,"%04d",i+1);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_GPDM],temp);      

			wsprintf(temp,"%8d",(i+1)*100);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_WTGS],temp);

			wsprintf(temp,"%8d",i+10);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_WTJG],temp);      

			wsprintf(temp,"%06d",i+100);
			StringToFld(CommBuffer,CommFile.fldStruct[fld_HTHM],temp);      

			StringToFld(CommBuffer,CommFile.fldStruct[fld_DATE],"111111");      
			CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)]=';';

			_lwrite(hFile,&CommBuffer[1], rlen-1);
			_lwrite(hFile,"\r\n",2);
		}
		_lclose(hFile);
	}

	return 0;
}

int JyDest_ChkUsr(LPJY_DEST lpJyDest)
{
	BYTE SendBuff[2048];
	int ret, len;
	char stat,temp[10];
    JY_ANS_CHKUSR AnsUser;

	ReadRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,
		rlen,CommBuffer);
	stat=CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)];
	if(stat !=';') 
		return 0;

	FldToString(CommBuffer,&CommFile.fldStruct[fld_SERI],temp);	
	if(lpJyDest->jyNum!=atoi(temp)) 
		return 0;

	ret=CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)];
	if(ret==' ')
		return 0;
	strcpy(SendBuff, JY_CHKUSR_HEAD);
	len =strlen(SendBuff);
	*(short *)&SendBuff[len] =lpJyDest->jyNum;
	len +=sizeof(short);

	AnsUser.jys=lpJyDest->curJys;
    AnsUser.userId=lpJyDest->userId;
	strcpy(AnsUser.gddm,lpJyDest->gddm);
	AnsUser.flag=(char)ret;
	memcpy(&SendBuff[len],&AnsUser,sizeof(JY_ANS_CHKUSR));
	len+=sizeof(AnsUser);
	UDP_SendBuff("��齻���û�", lpJyDest->sd, SendBuff, len,NULL);  	
	lpJyDest->isReqEnd =TRUE;
	
	ClearReq(lpJyDest);
	return 0;
}
	       
int JyDest_ChgPwd(LPJY_DEST lpJyDest)
{
	BYTE SendBuff[100];
	int ret, stat, len;
	JY_ANS_CHGPWD AnsChgPwd;
    char temp[10];

	ReadRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,hlen,
		rlen,CommBuffer);
	stat=CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)];                     
	if(stat !=';') 
		return 0;

	FldToString(CommBuffer,&CommFile.fldStruct[fld_SERI],temp);	
	if(lpJyDest->jyNum!=atoi(temp)) 
		return 0;

	ret=CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)];
	if(ret==' ')
		return 0;
	AnsChgPwd.flag =(char)ret;
	AnsChgPwd.jys =lpJyDest->curJys;
	
	strcpy(SendBuff, JY_CHGPWD_HEAD);
	len =strlen(SendBuff);
	*(short *)&SendBuff[len] =lpJyDest->jyNum;
	len +=sizeof(short);

	strcpy(AnsChgPwd.gddm, lpJyDest->gddm);
	memcpy(&SendBuff[len], &AnsChgPwd, sizeof(AnsChgPwd));
	len +=sizeof(AnsChgPwd);

	UDP_SendBuff("�޸Ľ�������", lpJyDest->sd, SendBuff, len, NULL);

	lpJyDest->isReqEnd =TRUE;
	ClearReq(lpJyDest);
	return 0;
}
	       
int JyDest_BuySell(LPJY_DEST lpJyDest)
{
	char hthm[20],temp[10];
	BYTE SendBuff[100];
	int stat, ret, len;
    JY_ANS_BUYSELL AnsBuySell; 

	ReadRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,
		hlen,rlen,CommBuffer);
	stat=CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)];                     
	if(stat !=';') 
		return 0;
	
	FldToString(CommBuffer,&CommFile.fldStruct[fld_SERI],temp);	
	if(lpJyDest->jyNum!=atoi(temp)) 
		return 0;

	ret=CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)];
	if(ret==' ')
		return 0;
	hthm[0] =0;
	if(ret==ANS_SUCC)
	{
		FldToString(CommBuffer,&CommFile.fldStruct[fld_HTHM],hthm);
		memset(temp,' ',(short)CommFile.fldStruct[fld_HTHM].wid);
		if(strncmp(hthm,temp,(short)CommFile.fldStruct[fld_HTHM].wid)==0)
			return 0;
	}
	AnsBuySell.jys=lpJyDest->curJys;
	strcpy(AnsBuySell.gddm,lpJyDest->gddm);
	strcpy(AnsBuySell.hthm,hthm);
	AnsBuySell.bs=REQ_BUYSEL;
	AnsBuySell.flag=(char)ret;

	strcpy(SendBuff, JY_BUYSELL_HEAD);
	len =strlen(SendBuff);
	*(short *)&SendBuff[len] =lpJyDest->jyNum;
	len +=sizeof(short);
	
	memcpy(&SendBuff[len],&AnsBuySell,sizeof(AnsBuySell));
	len+=sizeof(AnsBuySell);
	
	UDP_SendBuff("����ί��", lpJyDest->sd, SendBuff, len, NULL);

	lpJyDest->isReqEnd =TRUE;
	ClearReq(lpJyDest);
	return 0;
}

	       
int JyDest_Cancel(LPJY_DEST lpJyDest)
{
	BYTE SendBuff[600];
	int ret, stat, len, i,retnum;
	JY_ANS_CANCEL AnsCancel;
	char temp[20],tmp[13];
	HFILE hFile;
	OFSTRUCT os;

	ReadRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,
		hlen,rlen,CommBuffer);

	stat=CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)];
	if(stat!=';') 
		return 0;

	FldToString(CommBuffer,&CommFile.fldStruct[fld_SERI],temp);	
	if(lpJyDest->jyNum!=atoi(temp)) 
		return 0;

	ret=CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)];
	if(ret==' ')
		return 0;

	FldToString(CommBuffer,&CommFile.fldStruct[fld_JYMM],temp);
	memset(tmp,' ',(short)CommFile.fldStruct[fld_JYMM].wid);
	if(ret==ANS_SUCC&&strncmp(temp,tmp,(short)CommFile.fldStruct[fld_JYMM].wid)==0)
		return 0;
	retnum=atoi(temp);
	
	if(ret!=ANS_SUCC)
		AnsCancel.flag[0] =ret;
	else
	{
		if(retnum==1)
		{
			ret=CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)];
			AnsCancel.flag[0] =ret;
		}
		else
		{
			wsprintf(temp,"%s%d%s",AnsFile.path[lpJyDest->zqsid],lpJyDest->recNum,".ANS");
			hFile =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READ);

			if(hFile ==HFILE_ERROR)
				return 0;

			i=_llseek(hFile, 0L, FILE_END);
			if(i==HFILE_ERROR)
			{
				_lclose(hFile);
				return 0;
			}
			if((i-1)/(rlen+1)!=retnum)
			{
				_lclose(hFile);
				return 0;
			}
			_llseek(hFile, 0L, FILE_BEGIN);

			for(i =0; i<retnum; i++)
			{
				if((short)_lread(hFile,&CommBuffer[1],rlen -1)!=rlen -1)
					break;

				ret=CommBuffer[*(int*)(CommFile.fldStruct[fld_ANSNO].offset)];		
				AnsCancel.flag[i] =ret;
				_llseek(hFile, 2L, FILE_CURRENT);
			}
			_lclose(hFile);
			remove(temp);
		}
	}
	AnsCancel.jys =lpJyDest->curJys;
	strcpy(AnsCancel.gddm, lpJyDest->gddm);
	
	strcpy(SendBuff, JY_CANCEL_HEAD);
	len =strlen(SendBuff);
	*(short *)&SendBuff[len] =lpJyDest->jyNum;
	len +=sizeof(short);

	memcpy(&SendBuff[len], &AnsCancel, sizeof(AnsCancel));
	len +=sizeof(AnsCancel);

	UDP_SendBuff("����ί��", lpJyDest->sd, SendBuff, len,NULL);
	lpJyDest->isReqEnd =TRUE;
	ClearReq(lpJyDest);
	return 0;
}
	       
int JyDest_Yecx(LPJY_DEST lpJyDest)
{
	char temp[40],tmp[40];
	JY_ANS_YECX AnsYecx;
	int ret, i,retnum;
	char stat;
	HFILE hFile;
	OFSTRUCT os;
    HANDLE hd;

	ReadRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,
		hlen,rlen,CommBuffer);
	stat=CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)];                     
	if(stat !=';') 
		return 0;

	FldToString(CommBuffer,&CommFile.fldStruct[fld_SERI],temp);	
	if(lpJyDest->jyNum!=atoi(temp)) 
		return 0;

	ret=CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)];
	if(ret==' ')
		return 0;

	FldToString(CommBuffer,&CommFile.fldStruct[fld_JYMM],temp);
	memset(tmp,' ',(short)CommFile.fldStruct[fld_JYMM].wid);
	if(ret==ANS_SUCC&&strncmp(temp,tmp,(short)CommFile.fldStruct[fld_JYMM].wid)==0)
		return 0;
	retnum=atoi(temp);

	if(ret==ANS_SUCC&&retnum>0)
	{
		wsprintf(tmp,"%s%d%s",AnsFile.path[lpJyDest->zqsid],lpJyDest->recNum,".ANS");
		hFile =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_READ);

		if(hFile ==HFILE_ERROR)
			return 0;

		i=_llseek(hFile, 0L, FILE_END);
		if(i==HFILE_ERROR)
		{
			_lclose(hFile);
			return 0;
		}
		if((i)/(rlen+1)<retnum)
		{
			_lclose(hFile);
			return 0;
		}
		_llseek(hFile, 0L, FILE_BEGIN);
	}

	if(ret==ANS_SUCC)
	{
		FldToString(CommBuffer,&CommFile.fldStruct[fld_WTJG],temp);
		AnsYecx.kys=atof(temp);      
		FldToString(CommBuffer,&CommFile.fldStruct[fld_WTGS],temp);
		AnsYecx.zjye=atof(temp);	    

		if(retnum>0)
		{
			//AnsYecx.lpGptg=(LPJY_GPTG)malloc(sizeof(JY_GPTG)*retnum);
			hd =GlobalAlloc(GHND,sizeof(JY_GPTG)*retnum);
			AnsYecx.lpGptg=GlobalLock(hd);
			memset(&AnsYecx.lpGptg[0],0,sizeof(JY_GPTG)*retnum);
		}
		for(i=0;i<retnum;i++)
		{
			memset(CommBuffer,0,sizeof(CommBuffer));
			if((short)_lread(hFile,&CommBuffer[1],rlen -1)!=rlen -1)
				break;

			FldToString(CommBuffer,&CommFile.fldStruct[fld_GPDM],
				&AnsYecx.lpGptg[i].gpdm[0]);

			FldToString(CommBuffer,&CommFile.fldStruct[fld_WTGS],
				&AnsYecx.lpGptg[i].kys[0]);

			FldToString(CommBuffer,&CommFile.fldStruct[fld_WTJG],
				&AnsYecx.lpGptg[i].gpye[0]);

			FldToString(CommBuffer,&CommFile.fldStruct[fld_DATE],
				&AnsYecx.lpGptg[i].ghrq[0]);
			_llseek(hFile, 2L, FILE_CURRENT);
		}
		if(retnum>0)
		{
			_lclose(hFile);
			remove(tmp);
		}
		AnsYecx.recnum=retnum;
		AnsYecx.flag=ret;
		if(AnsYecx.recnum >=0)
		{
			lpJyDest->isSending =TRUE;
			Thrd_SendJycx(REQ_YECX, lpJyDest->sd, &AnsYecx, lpJyDest->jyNum);
			if(retnum>0)
			{
				//free(AnsYecx.lpGptg);
				GlobalUnlock(hd);
				GlobalFree(hd);
			}
			lpJyDest->isSending =FALSE;
		}
	}
	else
	{
		lpJyDest->isReqEnd =TRUE;
        ClearReq(lpJyDest);
    	return ret;
	}
	lpJyDest->isReqEnd =TRUE;
	ClearReq(lpJyDest);
	return 0;
}
	       
int JyDest_Cjcx(LPJY_DEST lpJyDest)
{
	JY_ANS_CJCX AnsCjcx;
	int i, ret,retnum;
	char stat, temp[40],tmp[40];
	HFILE hFile;
	OFSTRUCT os;
	HANDLE hd;

	ReadRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,
		hlen,rlen,CommBuffer);
	stat=CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)];                     
	if(stat !=';') 
		return 0;
	FldToString(CommBuffer,&CommFile.fldStruct[fld_SERI],temp);	
	if(lpJyDest->jyNum!=atoi(temp)) 
		return 0;

	ret=CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)];
	if(ret==' ')
		return 0;
	FldToString(CommBuffer,&CommFile.fldStruct[fld_JYMM],temp);
	memset(tmp,' ',(short)CommFile.fldStruct[fld_JYMM].wid);
	if(ret==ANS_SUCC&&strncmp(temp,tmp,(short)CommFile.fldStruct[fld_JYMM].wid)==0)
		return 0;
	retnum=atoi(temp);

	if(ret==ANS_SUCC&&retnum>0)
	{
		wsprintf(tmp,"%s%d%s",AnsFile.path[lpJyDest->zqsid],lpJyDest->recNum,".ANS");	
		hFile =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_READ);

		if(hFile ==HFILE_ERROR)
			return 0;

		i=_llseek(hFile, 0L, FILE_END);
		if(i==HFILE_ERROR)
		{
			_lclose(hFile);
			return 0;
		}
		if((i)/(rlen+1)<retnum)
		{
			_lclose(hFile);
			return 0;
		}
		_llseek(hFile, 0L, FILE_BEGIN);
	}

	if(ret==ANS_SUCC)
	{ 
		if(retnum>0)
		{
			//AnsCjcx.lpCj=(LPJY_CJ)malloc(sizeof(JY_CJ)*retnum);
			hd =GlobalAlloc(GHND,sizeof(JY_CJ)*retnum);
			AnsCjcx.lpCj=GlobalLock(hd);
			memset(&AnsCjcx.lpCj[0],0,sizeof(JY_CJ)*retnum);
		}
		for(i=0;i<retnum;i++)
		{
			memset(CommBuffer,0,sizeof(CommBuffer));
			if((short)_lread(hFile,&CommBuffer[1],rlen -1)!=rlen -1)
				break;

			FldToString(CommBuffer,&CommFile.fldStruct[fld_HTHM],
				&AnsCjcx.lpCj[i].hthm[0]);

			FldToString(CommBuffer,&CommFile.fldStruct[fld_DATE],
				&AnsCjcx.lpCj[i].cjsj[0]);

			AnsCjcx.lpCj[i].mmbz=
				CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)];

			FldToString(CommBuffer,&CommFile.fldStruct[fld_GPDM],
				&AnsCjcx.lpCj[i].gpdm[0]);

			FldToString(CommBuffer,&CommFile.fldStruct[fld_WTGS],
				&AnsCjcx.lpCj[i].cjgs[0]);
			FldToString(CommBuffer,&CommFile.fldStruct[fld_WTJG],
				&AnsCjcx.lpCj[i].cjjg[0]);

			_llseek(hFile, 2L, FILE_CURRENT);
		}
		if(retnum>0)
		{
			_lclose(hFile);
			remove(tmp);
		}
		AnsCjcx.recnum=retnum;
		AnsCjcx.flag =ret;
		if(AnsCjcx.recnum >=0)
		{
			lpJyDest->isSending =TRUE;
			Thrd_SendJycx(REQ_CJCX, lpJyDest->sd, &AnsCjcx, lpJyDest->jyNum);
			if(retnum>0)
			{
				//free(AnsCjcx.lpCj);
				GlobalUnlock(hd);
				GlobalFree(hd);
			}
			lpJyDest->isSending =FALSE;
		}
	}
	else
	{
		lpJyDest->isReqEnd =TRUE;
		ClearReq(lpJyDest);
		return ret;
	}
	lpJyDest->isReqEnd =TRUE;
	ClearReq(lpJyDest);
	return 0;
}

int JyDest_Wtcx(LPJY_DEST lpJyDest)
{
	JY_ANS_WTCX AnsWtcx;
	int ret, i,retnum;
	char stat, temp[40],tmp[40];
	HFILE hFile;
	OFSTRUCT os;
	HANDLE hd;

	ReadRecord(AnsFile.hf[lpJyDest->zqsid],lpJyDest->recNum,
		hlen,rlen,CommBuffer);
	stat=CommBuffer[*(short*)(CommFile.fldStruct[fld_STAT].offset)];
	if(stat !=';') 
		return 0;

	FldToString(CommBuffer,&CommFile.fldStruct[fld_SERI],temp);	
	if(lpJyDest->jyNum!=atoi(temp)) return 0;

	ret=CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)];
	if(ret==' ')
		return 0;
	FldToString(CommBuffer,&CommFile.fldStruct[fld_JYMM],temp);
	memset(tmp,' ',(short)CommFile.fldStruct[fld_JYMM].wid);
	if(ret==ANS_SUCC&&strncmp(temp,tmp,(short)CommFile.fldStruct[fld_JYMM].wid)==0)
		return 0;
	retnum=atoi(temp);

	if(ret==ANS_SUCC&&retnum>0)
	{
		wsprintf(temp,"%s%d%s",AnsFile.path[lpJyDest->zqsid],lpJyDest->recNum,".ANS");
		hFile =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READ);

		if(hFile ==HFILE_ERROR)
			return 0;

		i=_llseek(hFile, 0L, FILE_END);
		if(i==HFILE_ERROR)
		{
			_lclose(hFile);
			return 0;
		}
		if((i)/(rlen+1)<retnum)
		{
			_lclose(hFile);
			return 0;
		}
		_llseek(hFile, 0L, FILE_BEGIN);
	}

	if(ret==ANS_SUCC)
	{ 
		if(retnum>0)
		{
			//AnsWtcx.lpWt=(LPJY_WT)malloc(sizeof(JY_WT)*retnum);
			hd =GlobalAlloc(GHND,sizeof(JY_WT)*retnum);
			AnsWtcx.lpWt =GlobalLock(hd);
			memset(&AnsWtcx.lpWt[0], 0, sizeof(JY_WT)*retnum);
		}
		for(i=0;i<retnum;i++)
		{
			memset(CommBuffer,0,sizeof(CommBuffer));
			if((short)_lread(hFile,&CommBuffer[1],rlen -1)!=rlen -1)
				break;
			FldToString(CommBuffer,&CommFile.fldStruct[fld_HTHM],
				&AnsWtcx.lpWt[i].hthm[0]);

			FldToString(CommBuffer,&CommFile.fldStruct[fld_DATE],
				&AnsWtcx.lpWt[i].wtsj[0]);

			AnsWtcx.lpWt[i].mmbz=
				CommBuffer[*(short*)(CommFile.fldStruct[fld_ANSNO].offset)];

			FldToString(CommBuffer,&CommFile.fldStruct[fld_GPDM],
				&AnsWtcx.lpWt[i].gpdm[0]);

			FldToString(CommBuffer,&CommFile.fldStruct[fld_WTGS],
				&AnsWtcx.lpWt[i].wtgs[0]);
			FldToString(CommBuffer,&CommFile.fldStruct[fld_WTJG],
				&AnsWtcx.lpWt[i].wtjg[0]);
			_llseek(hFile, 2L, FILE_CURRENT);
		}
		if(retnum>0)
		{
			_lclose(hFile);
			remove(tmp);
		}
		AnsWtcx.recnum=retnum;
		AnsWtcx.flag =ret;
		if(AnsWtcx.recnum >=0)
		{
			lpJyDest->isSending =TRUE;
			Thrd_SendJycx(REQ_WTCX, lpJyDest->sd, &AnsWtcx, lpJyDest->jyNum);
			if(AnsWtcx.recnum>0)
			{
				//free(AnsWtcx.lpWt);
				GlobalUnlock(hd);
				GlobalFree(hd);
			}
			lpJyDest->isSending =FALSE;
		}
	}
	else
	{
		lpJyDest->isReqEnd =TRUE;
		ClearReq(lpJyDest);
		return ret;
	}
	lpJyDest->isReqEnd =TRUE;
	ClearReq(lpJyDest);
	return 0;
}

int Thrd_SendJycx(int reqType, int sd, char *lpBuf, int jyNum)
{
	char SendBuff[2048];
	LPJY_ANS_YECX lpAnsYecx;
	LPJY_ANS_CJCX lpAnsCjcx;
	LPJY_ANS_WTCX lpAnsWtcx;
	int i, len, recCount, sendCount, sendNum;

	sendNum =0;
	sendCount =MAX_CX_SENDCOUNT;
	switch(reqType)
	{
	case REQ_YECX:
		lpAnsYecx =(LPJY_ANS_YECX)lpBuf;
		recCount =lpAnsYecx->recnum;
		for(i =0; i<=recCount/MAX_CX_SENDCOUNT; i++)
		{
			sendNum =i*MAX_CX_SENDCOUNT;
			if(sendNum+sendCount >recCount)
				sendCount =recCount-sendNum;

			strcpy(SendBuff, JY_YECX_HEAD);
			len =strlen(SendBuff);
			*(short *)&SendBuff[len] =jyNum;
			len +=sizeof(short);
			lpAnsYecx->recnum=sendCount;	
			memcpy(&SendBuff[len],lpAnsYecx,sizeof(JY_ANS_YECX)-sizeof(LPJY_GPTG));
            len+=sizeof(JY_ANS_YECX)-sizeof(LPJY_GPTG);

			if(sendCount==0&&sendNum!=0)
				break;

			if(sendCount>0)
			{
				memcpy(&SendBuff[len], &lpAnsYecx->lpGptg[sendNum],
					sizeof(JY_GPTG)*sendCount);
				len +=sizeof(JY_GPTG)*sendCount;
			}
			if(UDP_SendBuff("����ѯ", sd, SendBuff, len,NULL)<0)
				return -1;
		}
		break;
	case REQ_CJCX:
		lpAnsCjcx =(LPJY_ANS_CJCX)lpBuf;
		recCount =lpAnsCjcx->recnum;
		sendCount =MAX_CX_SENDCOUNT;
		for(i =0; i<=recCount/MAX_CX_SENDCOUNT; i++)
		{
			sendNum =i*MAX_CX_SENDCOUNT;
			if(sendNum+sendCount >recCount)
				sendCount =recCount-sendNum;

			strcpy(SendBuff, JY_CJCX_HEAD);
			len =strlen(SendBuff);
			*(short *)&SendBuff[len] =jyNum;
			len +=sizeof(short);

			lpAnsCjcx->recnum=sendCount;
            memcpy(&SendBuff[len],lpAnsCjcx,sizeof(JY_ANS_CJCX)-sizeof(LPJY_CJ));
            len+=sizeof(JY_ANS_CJCX)-sizeof(LPJY_CJ);

			if(sendCount==0&&sendNum!=0)
				break;
			if(sendCount>0)
			{
 				memcpy(&SendBuff[len], &lpAnsCjcx->lpCj[sendNum],
					sizeof(JY_CJ)*sendCount);
				len +=sizeof(JY_CJ)*sendCount;
			}
			if(UDP_SendBuff("�ɽ���ѯ", sd, SendBuff, len,NULL)<0)
					return -1; 
		}
		break;
	case REQ_WTCX:
		lpAnsWtcx =(LPJY_ANS_WTCX)lpBuf;
		recCount =lpAnsWtcx->recnum;
		sendCount =MAX_CX_SENDCOUNT;
		for(i =0; i<=recCount/MAX_CX_SENDCOUNT; i++)
		{
			sendNum =i*MAX_CX_SENDCOUNT;
			if(sendNum+sendCount >recCount)
				sendCount =recCount-sendNum;
			strcpy(SendBuff, JY_WTCX_HEAD);
			len =strlen(SendBuff);
			*(short *)&SendBuff[len] =jyNum;
			len +=sizeof(short);

			lpAnsWtcx->recnum=sendCount;
			memcpy(&SendBuff[len],lpAnsWtcx,sizeof(JY_ANS_WTCX)-sizeof(LPJY_WT));
            len+=sizeof(JY_ANS_WTCX)-sizeof(LPJY_WT);
			if(sendCount>0)
			{
				memcpy(&SendBuff[len], &lpAnsWtcx->lpWt[sendNum],
					sizeof(JY_WT)*sendCount);
				len +=sizeof(JY_WT)*sendCount;
			}
			if(sendCount==0&&sendNum!=0)
				break;
			if(UDP_SendBuff("ί�в�ѯ", sd, SendBuff, len,NULL)<0)
				return -1;
		}
		break;
	}
	strcpy(SendBuff, JY_CXEND_HEAD);
	len =strlen(SendBuff);

	UDP_SendBuff("��ѯ�ɹ�", sd, SendBuff, len,NULL);
	return 0;
}

int Jy_SendRet(int sd, char reqType, char ret, int jyNum)
{
	int len;
	BYTE SendBuff[100];
	LPSTR lpHead;
	
	if(ret ==ANS_TIME_OUT)
		lpHead =JY_TIMEOUT_HEAD;
	else
	switch(reqType)
	{
	case REQ_CHKUSR:
		lpHead =JY_CHKUSR_HEAD;
		break;
	case REQ_CHGPWD:
		lpHead =JY_CHGPWD_HEAD;
		break;
	case REQ_BUYSEL:
		lpHead =JY_BUYSELL_HEAD;
		break;
	case REQ_CANCEL:
		lpHead =JY_CANCEL_HEAD;
		break;
	case REQ_YECX:
		lpHead =JY_YECX_HEAD;
		break;
	case REQ_CJCX:
		lpHead =JY_CJCX_HEAD;
		break;
	case REQ_WTCX:
		lpHead =JY_WTCX_HEAD;
		break;
	}
	strcpy(SendBuff, lpHead);
	len =strlen(SendBuff);
	*(short *)&SendBuff[len] =jyNum;
	len +=sizeof(short);
	SendBuff[len++] =(char)ret;

	UDP_SendBuff("���ͽ��", sd, SendBuff, len,NULL);

	return 0;
}
