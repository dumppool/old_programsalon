#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>
#include <sys\stat.h>
#include <share.h>
#include <fcntl.h>
#include <time.h>

#include "main.h"
#include "hq.h"
#include "sv_hq.h"

#include "dbf_data.h"
#include "data.h"

#include "cl_hq.h"
#include "cl_data.h"
                              
DBF_DATA HqkData[2], GpkData[2], SzZskData, SzMmpkData;
ZX_DATA ZxData;


extern void DelSpaces(LPSTR);

extern BOOL clGetInitString(LPSTR, LPSTR, LPSTR);
extern void clPutInitString(LPSTR, LPSTR, LPSTR);

extern int GetInitInt(LPSTR, LPSTR);

extern int UDPBlockingHook(void);

extern BOOL run_cancelled;
extern BOOL gfIsNewsSrcDel;

extern int date_num,tim;
extern char *HqItems[];

LPDBF_DATA lpDbfDatas[]={&HqkData[0], &HqkData[1],
						&GpkData[0],/* &GpkData[1],*/
						&SzZskData,
						&SzMmpkData,NULL};

LPDBF_DATA 	lpDbfFile[2][5] ={
								{&HqkData[0],&GpkData[0],&SzZskData,&SzMmpkData,NULL},
								{&HqkData[1],NULL,       NULL,      NULL,       NULL}
							};

long oldDpCjss2[2][20];
int gnHqRefreshTime =5;
int Skip = -1,Idel;
  
int clHqInit(void)
{
	int i, jys;
	char tmp[256], temp[256];
	OFSTRUCT os;
	
	memset(&oldDpCjss2, 0, sizeof(oldDpCjss2));
	memset(&zs_times, 0, sizeof(zs_times));

	if(GetInitString("HQ", "RUN", tmp))
	{
		if(tmp[0]=='N')
		{
			HqIsRun=FALSE;
			return 0;
		}
	}

	for(i =0; i<2; i++)
	{
		memset(&HqData[i], 0, sizeof(HqData[i]));
		memset(&MmpData[i], 0, sizeof(MmpData[i]));
		memset(&HqTime[i], 0, sizeof(HqTime[i]));
		memset(&GraphData[i], 0, sizeof(GraphData[i]));
		memset(&DpData[i], 0, sizeof(DpData[i]));
		hfHq[i] =HFILE_ERROR;
		hfMmp[i] =HFILE_ERROR;
		hfMaxMin[i] =HFILE_ERROR;
	}
	hfDp =HFILE_ERROR;

	//��ʼ����������
	memset(&ZxData, 0, sizeof(ZxData));
	if(!GetInitString("ZX", "FILE0", ZxDataFile))
	{
		ErrMsg(ghWndMain, "get zx init failed!");
		PutInitString("ZX", "FILE0", "");
		return -1;
	}
	strupr(ZxDataFile);
	hfZx =OpenFile(ZxDataFile, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hfZx ==HFILE_ERROR)
	{
		ErrMsg(ghWndMain, "open zx file failed");
		return -1;
	}

	szNewsPath[0] =0;
	if(!GetInitString("NEWS", "DIR", szNewsPath))
	{
		ErrMsg(ghWndMain, "get news init failed!");
		PutInitString("NEWS", "DIR", "");
	}

	szNewsSrc[0] =0;
	if(!GetInitString("NEWS", "SRC", szNewsSrc))
	{
		ErrMsg(ghWndMain, "get news init failed!");
		PutInitString("NEWS", "SRC", "");
	}
	if(GetInitString("NEWS", "DELSRC", tmp))
	{
		if(tmp[0]=='Y')
			gfIsNewsSrcDel =TRUE;
		else
			gfIsNewsSrcDel =FALSE;
	}
	else
		gfIsNewsSrcDel =FALSE;

	i=0;
	while(HqItems[i])
	{
		memset(lpDbfDatas[i], 0, sizeof(DBF_DATA));
		lpDbfDatas[i]->hf =-1;
		i++;
	}
	
    memset(tmp,0,sizeof(tmp));
	if(clGetInitString("GLOBAL", "IDEL", tmp))
	{
		Idel= atoi(tmp);
	}
	else
	{
		clPutInitString("GLOBAL", "IDEL", "0");
		Idel=10;
	}
	
	//���ÿ�����ʱ��
	for(jys =0; jys <2; jys++)
	{
		for(i =0; i<4; i++)
		{
			if(!GetInitString("TIME", HqTimeItems[i+4*jys], tmp))
			{
				strcpy(tmp, HqTimeDefs[i+4*jys]);
				PutInitString("TIME", HqTimeItems[i+4*jys], tmp);
			}
			else
			{
				if(strlen(tmp) > 12 || strlen(tmp) <3)
				{
					ErrMsg(ghWndMain, "time set error!");
					return -1;
				}
			}
			*lpHqTimes[i+4*jys] =atoi(strtok(tmp, ":"))*60;
			*lpHqTimes[i+4*jys] +=atoi(strtok(NULL, ":"));
		}
	
	}
    
    //��ʼ��DBF�ļ�
	i =0;
	while(HqItems[i])
	{
		if(!clGetInitString("DBF", HqItems[i], tmp))
		{
			wsprintf(temp, "can not find %s:\n %s",
					(LPSTR)HqItems[i], (LPSTR)tmp);
			ErrMsg(ghWndMain, temp);
			clPutInitString("DBF", HqItems[i], NULL);
			return -1;
		}
		
		if(access(tmp,_S_IREAD) <0)
		{
			wsprintf(temp, "can not read %s:\n %s",
					(LPSTR)HqItems[i], (LPSTR)tmp);
			ErrMsg(ghWndMain, temp);
			return -1;
		}  
		lpDbfDatas[i]->hf=OpenDbfBase(tmp,OF_READ);
		if (lpDbfDatas[i]->hf==-1)
		{
			wsprintf(temp, "can not open %s:\n %s",
					(LPSTR)HqItems[i], (LPSTR)tmp);
			ErrMsg(ghWndMain, temp);
			return -1;
		}
		strcpy(lpDbfDatas[i]->file,tmp); 
		
		if (InitBase(lpDbfDatas[i]->hf,&lpDbfDatas[i]->dbfStruct,
				&lpDbfDatas[i]->fldStruct,&lpDbfDatas[i]->fldCount)
			!=SUCCEED) 
		{
			wsprintf(temp, "can not init %s:\n %s",
					(LPSTR)HqItems[i], (LPSTR)tmp);
			ErrMsg(ghWndMain, temp);
			return -1;
		}
		
		i++;
	}
	
    //��ʼ����ʱ���ݽṹ
	if(!clGetInitString("HQ", "DATAPATH", szDataPath))
	{
		ErrMsg(ghWndMain, "not set datapath in [graph]");
		PutInitString("HQ", "DATAPATH", NULL);
		return -1;
	}
	i =strlen(szDataPath);
	if(szDataPath[i] =='\\')
		szDataPath[i] =0;
	
	wsprintf(HqDataPath, "%s\\HQDATA", szDataPath);
	wsprintf(GraphData[0].szGraPath, "%s\\SZDATA", szDataPath);
	wsprintf(GraphData[1].szGraPath, "%s\\SHDATA", szDataPath);
	
	//��ʼ�����������ļ�
	i =0;
	while(HqDataFileName[i])
	{
		wsprintf(tmp, "%s\\%s.dat", HqDataPath, HqDataFileName[i]);
		if(access(tmp,_S_IREAD) <0)
		{
			*HqDataFile[i] =OpenFile(tmp,&os, OF_SHARE_DENY_NONE|OF_CREATE|OF_READWRITE);
			if(*HqDataFile[i] ==-1)
			{
				wsprintf(temp, "can not create hq_data_file %s:", tmp);
				ErrMsg(ghWndMain, temp);
				return -1;
			}
		}  
		else 
			*HqDataFile[i] =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);

		if (*HqDataFile[i] ==HFILE_ERROR)
		{
			wsprintf(temp, "can not open hq_data_file %s:", tmp);
			ErrMsg(ghWndMain, temp);
			return -1;
		} 
		i++;
	}

	//gnHqRefreshTime =GetInitInt("HQ", "REF_TIME");
	//if(gnHqRefreshTime <5 || gnHqRefreshTime >60) 
	gnHqRefreshTime =5;
    
    
	for(jys =0; jys <2; jys++)
	{
		CloseDbfFile(jys);
	}
	
	return 0;
}

void clHqExit(void)
{
	static BOOL fExit =FALSE;
	int jys, i;
	
	if(fExit ==TRUE) return;
	fExit =TRUE;
	for(jys =0; jys <2; jys++)
	{
		if(HqData[jys].lpPreData !=NULL) 
			GlobalFreePtr(HqData[jys].lpPreData);
		if(HqData[jys].lpRefData !=NULL) 
			GlobalFreePtr(HqData[jys].lpRefData);
		if(HqData[jys].lpbChanged !=NULL) 
			GlobalFreePtr(HqData[jys].lpbChanged);
		if(MmpData[jys].lpMmp) 
			GlobalFreePtr(MmpData[jys].lpMmp);
		if(GraphData[jys].lpGraData) 
			GlobalFreePtr(GraphData[jys].lpGraData);
		if(GraphData[jys].lpGraHead) 
			GlobalFreePtr(GraphData[jys].lpGraHead);
		if(LzwData202[jys].recCount)
			GlobalFreePtr(LzwData202[jys].recCount);
			
		if(hfHq[jys] !=HFILE_ERROR) _lclose(hfHq[jys]);
		if(hfMmp[jys] !=HFILE_ERROR) _lclose(hfMmp[jys]);
		if(hfMaxMin[jys] !=HFILE_ERROR) _lclose(hfMaxMin[jys]);
	}
	if(hfDp !=HFILE_ERROR) _lclose(hfDp);
	i =0;
	while(HqItems[i])
	{
		if(lpDbfDatas[i]->hf!=-1)
		{
			CloseDbf(lpDbfDatas[i]->hf);
		}
		if(lpDbfDatas[i]->fldStruct)
			GlobalFreePtr(lpDbfDatas[i]->fldStruct);
		i++;
	}
	
	if(ZxData.lpText) free(ZxData.lpText);
}


BOOL OpenDbfFile(int jys)
{
	int i =0;
	
	while(lpDbfFile[jys][i]!=NULL)
	{   
		if(lpDbfFile[jys][i]->hf==-1)
			lpDbfFile[jys][i]->hf =OpenDbfBase(lpDbfFile[jys][i]->file,OF_READ);
		if(lpDbfFile[jys][i]->hf == -1)
			return FALSE;
		i++;
	}
	return TRUE;
}


void CloseDbfFile(int jys)
{
	int i=0;
	
    while(lpDbfFile[jys][i]!=NULL)
    {
    	if(lpDbfFile[jys][i]->hf!=-1)
    	{
 			CloseDbf(lpDbfFile[jys][i]->hf);
 			lpDbfFile[jys][i]->hf =-1; 			
 		}
 		i++;
 	} 	
}



//zqdm,zrsp,jrkp,zgjg,zdjg,zgjm,zdjm,zjjg,zd,cjss,lc,npzl,wb,cjje
int HqFldLens[HQ_FLDS_COUNT]=
{
	MAX_ZQDM_SIZE, sizeof(float),sizeof(float), sizeof(float), sizeof(float),
	sizeof(float), sizeof(float), sizeof(float), sizeof(float),sizeof(int),
	sizeof(int), sizeof(int), sizeof(float), sizeof(int)
};

int HqFldTypes[HQ_FLDS_COUNT]=
{
	FLD_TYPE_STRING, FLD_TYPE_FLOAT, FLD_TYPE_FLOAT, FLD_TYPE_FLOAT,
	FLD_TYPE_FLOAT, FLD_TYPE_FLOAT, FLD_TYPE_FLOAT, FLD_TYPE_FLOAT,
	FLD_TYPE_FLOAT, FLD_TYPE_LONG,  FLD_TYPE_LONG, FLD_TYPE_LONG,
	FLD_TYPE_FLOAT, FLD_TYPE_LONG
};

int HqFldPoss[2][HQ_FLDS_COUNT] =
{
	//0zqdm,1zrsp,2jrkp,3zgjg,4zdjg,5zgjm,6zdjm,7zjjg,8zd,9cjss,0lc,11npzl,
	//12wb,13cjje
	//{0, 2, 3, 5, 6, 8, 9, 7, -1,  4, -1,-1, -1, 15},
	{0, 1, 2, 4, 5, 7, 8, 6, -1,  3, -1,-1, -1, 14},
	{0, 2, 3, 5, 6, 8, 9, 7, -1, 10, -1, -1, -1, 4},
};

BOOL IsTodayHq(int jys)
{
    struct _stat buff;
    char tmp[10];
    
    _strdate(tmp);    
    _fstat(HqkData[jys].hf,&buff);
    
	return TRUE;
}

#define	_hread	hRead
#define	PER_READ_LEN	1024L

long hRead(HFILE hf,char * buff,long len)
{                             
	long rlen=0;
	UINT ret,plen ;
	
	if(len<=PER_READ_LEN)
	{
		ret =_lread(hf,buff,(UINT)(len));
		rlen =(long)(ret);
	}
	else
	{
		rlen =0;
		do
		{
			if(len -rlen>=	PER_READ_LEN)
			{
				plen =(UINT)(PER_READ_LEN);
			}
			else
			{
				plen =(UINT)(len -rlen);
			}
			
			ret =_lread(hf,buff,plen);
			if(ret!=HFILE_ERROR)			
			{                   
				buff+=ret;
				rlen +=ret;
			}
			else
			{   
				return -1;
			}
		}while(rlen<len&&ret!=HFILE_ERROR);
	}
	
	return rlen;	
}

//////////////////////////////////////////////////////////////////
//����		����ʼ���ڴ��������ݶ����ڴ������̶����ڴ��ʱ����ͷ����Ϣ ��       
//          ͬʱ�������Ӧ���ڴ��������ݵĹ�Ʊ�����ֶΣ� �����ڴ���������
//          �������ڴ��������ݵļ�¼��Ϊ������ �����Ե��������ݵļ�¼���б仯
//          ʱ��һ��Ҫ����������ڴ���󣬲�����������䡣������ͬʱ��ʼ������
//          �ڴ��������а��ڴ����
//����		��
//     		jys---����������
//������	��
//			TRUE---�ɹ�
//          FALSE--ʧ��
//�޸�����	��1997/10/15
//�޸Ľ���	���ɽ��ڴ��������ݷ���BTREE��BTREE�ڰ�����������ڴ����ݶ����Թ�Ʊ
//			����������


int ReadHqFirst(int jys)
{
	int i, j ;
	short reclen, headlen;

	long recCount,bytes;
	char *buffer;
	char *lpTmp;
	LPSTR lpFld;
	char tmp[100];
	static BOOL fFirst[2] ={TRUE, TRUE};
		
	if(HqkData[jys].hf <0)
	{ 
	  	ErrMsg(ghWndMain, "ReadHqFirst ���ܴ��������!");
		return FALSE;
    }
	if(jys ==0) MsgLocal("��ȡ��������");
	else MsgLocal("��ȡ�Ϻ�����");
	
	reclen=*(short *)HqkData[jys].dbfStruct.rlen;
	headlen=*(short *)HqkData[jys].dbfStruct.hlen;

	//�����������Ч��¼		
	//recCount =GetDbfRecCount(HqkData[jys].hf,headlen,reclen);
	recCount =GetValidRecNum(jys);	
	
	if(jys ==1)
	{
		recCount --;
	}
	if(recCount <=0) 
	{
		ErrMsg(ghWndMain, "ReadHqFirst ������¼��Ϊ��!");
		return FALSE;
	}
	// �����ڴ棬ͬʱ����ʱ���ݽṹ�����㼰��ʼ��              
	if(clHqAllocMem(jys, (int)recCount) <0) 
	{
		ErrMsg(ghWndMain, "ReadHqFirst:HqAllocMem��!");
		return FALSE;
	}

	HqData[jys].recCount =(short)recCount; 

	//�������������ļ�

	buffer =(char *)GlobalAllocPtr(GHND, recCount*reclen+1);
	if (buffer==NULL) 
	{
		ErrMsg(ghWndMain, "ReadHqFirst:alloc buffer ��!");
		return FALSE;
    }
	_llseek(HqkData[jys].hf,(long)headlen,SEEK_SET);
	if(jys ==1)
		_llseek(HqkData[jys].hf, reclen, SEEK_CUR);
		
	bytes =hRead(HqkData[jys].hf, buffer, recCount*reclen);
	
	if(bytes == -1)
	{
		ErrMsg(ghWndMain,"ReadHqFirst:hRead bytes =-1��");
		GlobalFreePtr(buffer);  
		return FALSE;
	} 
	
	if(bytes !=recCount*reclen)
	{
	 	ErrMsg(ghWndMain, "ReadHqFirst:bytes !=recCount*reclen");
	 	GlobalFreePtr(buffer);  
	 	return FALSE;
	}
	    
	//��ʼ���������ݽṹ    
	lpTmp =buffer;
	for (i=0;i<recCount;i++) 
	{
		for(j =0; j<HQ_FLDS_COUNT; j++)
		{
			lpFld =GetHqFldPos(jys, i, j);
			if(HqFldPoss[jys][j] >=0)
			{
				FldToString(lpTmp,
					(FieldStruct *)&HqkData[jys].fldStruct[HqFldPoss[jys][j]],
					tmp);
				switch(HqFldTypes[j])
				{
					case FLD_TYPE_STRING:
						strcpy(lpFld, tmp);
					break;
					case FLD_TYPE_FLOAT:
						*(float *)lpFld =(float)atof(tmp);
					break;
					case FLD_TYPE_LONG:
						*(int *)lpFld =atol(tmp);
					break;
				}
			}
		}
		
		if(IsGuoZhai(jys, i))
			HqData[jys].lpRefData[i].cjss /=10;     //��λ����
		else
			HqData[jys].lpRefData[i].cjss /=100;    //��λ����
		HqData[jys].lpRefData[i].cjje /=1000;       //��λ����
		
		HqData[jys].lpRefData[i].lc =0;
		
		if(HqData[jys].lpPreData[i].zrsp ==0
			||HqData[jys].lpRefData[i].zjcj ==0)
			HqData[jys].lpRefData[i].zdf =0;
		else
			HqData[jys].lpRefData[i].zdf =
					(HqData[jys].lpRefData[i].zjcj
					- HqData[jys].lpPreData[i].zrsp)
					/HqData[jys].lpPreData[i].zrsp*100;
				
		if(clIsZsRec(jys, i))
		{
			if(jys ==1)
			{
				GetShZsFirst(lpTmp, DpData[jys].zsCount);
				DpData[jys].zsCount++;
			}
		}
		
		if(jys ==1)
		{               
			FldToString(lpTmp,(FieldStruct *)&HqkData[jys].fldStruct[1],
				HqData[jys].lpPreData[i].zqmc);
			GetShMmp(TRUE, i, lpTmp);
		}
		lpTmp +=reclen;
	}
	 
	GlobalFreePtr(buffer);  
	CheckGraHead(jys);
	
	if(jys ==0)
	{
		if(!GetSzZqmc(jys)) 
		{
			ErrMsg(ghWndMain,"ReadHqFirst:GetSzZqmc(jys)��");
			return FALSE;
		}
		if(!ReadSzZsFirst()) 
		{
		    ErrMsg(ghWndMain,"ReadHqFirst:ReadSzZsFirst()��");
			return FALSE;
		}
		if(!ReadSzMmp(TRUE))		
		{
		    ErrMsg(ghWndMain,"ReadHqFirst:ReadSzZsFirst()��");
			return FALSE;
		}
	}

	i =GetMaxMin10(jys);
	
	GetDpData(jys, TRUE);

	MsgLocal("OK.");
	fFirst[jys] =FALSE;
	
	return TRUE;
}

////////////////////////////////////////////////////////
//����		�����ݹ�Ʊ���롢��¼�Ż�ȡ��Ʊ���ƣ��ù���ֻ֧�����
//����		��
//			jys---���������
//          rec---��¼��ţ�0-->��¼��-1)
//          gpdm--��Ʊ����
//          gpmc--��Ʊ����
//������	��
//			0   --�ɹ�
//			-1  --ʧ��
//�޸�����	��1997/10/15

int GetZqmc(int jys,int rec,char *gpdm,char *gpmc)
{
	int i;
	short reclen, headlen, fldnum;
	int rec_count;

	char *buffer;
	char tmp[40];
	
	if(GpkData[jys].hf ==-1)
		return -1;
	if(jys==1)	
		return -1;	
		
	reclen=*(short *)GpkData[jys].dbfStruct.rlen;
	headlen=*(short *)GpkData[jys].dbfStruct.hlen;
		
	rec_count =(int)GetDbfRecCount(GpkData[jys].hf,headlen,reclen);

	if(rec_count <=0) return -1;
	fldnum =GpkData[jys].fldCount;
	
	buffer =(char *)malloc(reclen+1);
	if (buffer==NULL) 
	{
		ErrMsg(ghWndMain, "GetZqmc:alloc buffer failed!");
		return -1;
    }
    //�ü�¼����λ
	if(rec<rec_count)
	{
		_llseek(GpkData[jys].hf,(long)(headlen+reclen*rec),SEEK_SET);
		if(_lread(GpkData[jys].hf,buffer,reclen) ==(UINT)reclen)
		{
			FldToString(buffer,(FieldStruct *)&GpkData[jys].fldStruct[0], tmp);
			if(!strcmp(tmp, gpdm))
			{
				FldToString(buffer,(FieldStruct *)&GpkData[jys].fldStruct[1],gpmc);
		    	free(buffer);
				return 0;		
			}
		}
	}
	//��������
	_llseek(GpkData[jys].hf,(long)headlen,SEEK_SET);
	for (i=0;i<rec_count;i++) 
	{
		if(_lread(GpkData[jys].hf,buffer,reclen) !=(UINT)reclen) break;
		
		FldToString(buffer,(FieldStruct *)&GpkData[jys].fldStruct[0], tmp);
		if(!strcmp(tmp, gpdm))
		{
			FldToString(buffer,(FieldStruct *)&GpkData[jys].fldStruct[1],gpmc);		    	
		    free(buffer);
			return 0;
		}
	}
	free(buffer);
	return -1;
}

/////////////////////////////////////////////////
//����		��ˢ����������
//����		��
//     		jys---����������
//������	��
//			0---�ɹ�
//          -1--ʧ��
//�޸�����	��1997/10/15

int HqRefresh(int jys)
{
	int i, j;
	short reclen, headlen ;
	int zs_num[2] ={0, 0};

	char *buffer;
	char *lpTmp;
	LPSTR lpFld;
	char tmp[50];
	long l,bytes;
	HQ_REF_DATA LastHq;
	char LastZqdm[MAX_ZQDM_SIZE];
	
    int recCount;
		
	if(HqkData[jys].hf ==-1)
	{   
		ErrMsg(ghWndMain, "HqRefresh:���ܴ�������ļ����");
		return FALSE;
    }
	if(jys ==0) MsgLocal("ˢ����������");
	else MsgLocal("ˢ���Ϻ�����");
	
	reclen=*(short *)HqkData[jys].dbfStruct.rlen;
	headlen=*(short *)HqkData[jys].dbfStruct.hlen;
	
	//recCount =(int)GetDbfRecCount(HqkData[jys].hf,headlen,reclen);	
	recCount =GetValidRecNum(jys);

	//���������¼����������,����Ч��¼�������仯����Ӧ���µ����ڴ� ��
	if(recCount ==0)
	{
		ErrMsg(ghWndMain,"HqRefresh:GetDbfRecCount =0");		
		return FALSE;
	}
	
	//�Ϻ�������ٲɼ�һ����¼	
	if(jys ==1) recCount --;
	
	if(recCount <=0)
	{	
		ErrMsg(ghWndMain,"HqRefresh:����recCount <=0");		
		return FALSE;		
	}

	//HqData[jys].recCount =recCount;  ///add for deal with GetV function
	if(recCount!=HqData[jys].recCount)
	{
		MsgLocal("HqRefresh:��¼����ƥ�䣬���³�ʼ��");
		return FALSE;
	}

	if(HqData[jys].recCount <=0)
	{   
	    ErrMsg(ghWndMain, "HqRefresh:������¼����");
	 	return FALSE;
	}
	l =HqData[jys].recCount;
	if ((buffer=(char *)GlobalAllocPtr(GHND, l*reclen+1))==NULL) 
	{
		ErrMsg(ghWndMain, "HqRefresh:����ɼ����仺������!");
		return FALSE;
	}
	
	_llseek(HqkData[jys].hf,(long)headlen,SEEK_SET);
    
    //�Ϻ�������һ����¼���ܲɼ�
	if(jys ==1)
		_llseek(HqkData[jys].hf, reclen, SEEK_CUR);
		
	bytes =hRead(HqkData[jys].hf, buffer, l*reclen);
	
	if(bytes == -1)
	{
		ErrMsg(ghWndMain,"HqRefresh:bytes == -1");		
		GlobalFreePtr(buffer);
		return FALSE;
	}
	
	if(bytes!=l*reclen)
	{
		ErrMsg(ghWndMain, "HqRefresh:bytes!=l*reclen");
		GlobalFreePtr(buffer);
		return FALSE;
	}	
	else
	{
		lpTmp =buffer;
		for (i=0;i<HqData[jys].recCount;i++) 
		{    
			while(UDPBlockingHook());
			if(run_cancelled) break;
			//�������������ݣ��������ж�
			memcpy(&LastHq,&HqData[jys].lpRefData[i],
				sizeof(HQ_REF_DATA));
			//������Ʊ���룬�������ڹ�Ʊ�����Ӽ��ж�
			strcpy(LastZqdm,HqData[jys].lpPreData[i].zqdm);
		
			for(j =0; j<HQ_FLDS_COUNT; j++)
			{
				lpFld =GetHqFldPos(jys, i, j);
				if(HqFldPoss[jys][j] >=0)
				{
					FldToString(lpTmp,(FieldStruct *)&HqkData[jys].fldStruct[HqFldPoss[jys][j]],
								tmp);
					switch(HqFldTypes[j])
					{
						case FLD_TYPE_STRING:
							strcpy(lpFld, tmp);
						break;
						case FLD_TYPE_FLOAT:
							*(float *)lpFld =(float)atof(tmp);
						break;
						case FLD_TYPE_LONG:
							*(int *)lpFld =atol(tmp);
						break;
					}
				}
			}
			//�жϹ�Ʊ�������޸ı䣬��ı䣬��Ӧ��ȡ��ȷ������������
			//���Ʊ�����иı䣬����Ӧ������ҲӦ�ı�
			if(strcmp(HqData[jys].lpPreData[i].zqdm,LastZqdm)!=0)
			{
		    	//�ض���Ʊ����
				if(jys==0)
				{
					if(GetZqmc(jys,i,HqData[jys].lpPreData[i].zqdm,
						HqData[jys].lpPreData[i].zqmc)!=0)
					{
						strcpy(HqData[jys].lpPreData[i].zqmc,
							HqData[jys].lpPreData[i].zqdm);
					}
				}
				if(jys==1)
				{
					FldToString(lpTmp,(FieldStruct *)&HqkData[jys].fldStruct[1],
						HqData[jys].lpPreData[i].zqmc);			
				}
				//�����ôβɼ���������һ��
				lpTmp +=reclen;
				continue;
			}		
			if(IsGuoZhai(jys, i))
				HqData[jys].lpRefData[i].cjss /=10;     //��λ����
			else
				HqData[jys].lpRefData[i].cjss /=100;    //��λ����
			HqData[jys].lpRefData[i].cjje /=1000;       //��λ����
			if(jys ==1)
			{
				//FldToString(lpTmp,(FieldStruct *)&HqkData[jys].fldStruct[1],
				//	HqData[jys].lpPreData[i].zqmc);
		
				if(clIsZsRec(jys, i))
				{
					RefreshShZs(lpTmp, zs_num[1]);
					zs_num[1] ++;
				}
				else GetShMmp(FALSE, i, lpTmp);
			}
			HqData[jys].lpRefData[i].lc =
				HqData[jys].lpRefData[i].cjss -LastHq.cjss;
			//û�гɽ�	��������һ��
			if(HqData[jys].lpRefData[i].lc <=0)
			{
				lpTmp +=reclen;
				continue;
			}		
			//�гɽ��������ǵ�              
			if(HqData[jys].lpPreData[i].zrsp ==0
				||HqData[jys].lpRefData[i].zjcj ==0)
				HqData[jys].lpRefData[i].zdf =0;
			else
				HqData[jys].lpRefData[i].zdf =
						(HqData[jys].lpRefData[i].zjcj
						- HqData[jys].lpPreData[i].zrsp)
						/HqData[jys].lpPreData[i].zrsp*100;
		
			//�����ָ�����򲻴���
			if(!clIsZsRec(jys, i))
			{
				GetGraData(jys, i, &LastHq);
				if(HqData[jys].lpRefData[i].lc >0)
					WriteGraData(jys, i);
			}
		
			lpTmp +=reclen;
		}       
	}
	GlobalFreePtr(buffer);
	MsgLocal("OK.");
	
	if(jys ==0)
	{
		ReadSzMmp(FALSE);
		RefreshSzZs();
	}
	
	GetMaxMin10(jys);
	GetDpData(jys, FALSE);
	
	return TRUE;
}

int ReadSzZsFirst(void)
{
	int i ; 
	short reclen, headlen;
	char *buffer;
    char tmp[100];
    
	if(SzZskData.hf <0)
	{	
	    ErrMsg(ghWndMain, "ReadSzZsFirst:SzZskData.hf <0!");
		return FALSE;
    }
	DpData[0].zsCount =*(int *)SzZskData.dbfStruct.recnum;	
	if(DpData[0].zsCount >15) DpData[0].zsCount =15;
	
	reclen=*(short *)SzZskData.dbfStruct.rlen;
	headlen=*(short *)SzZskData.dbfStruct.hlen;
	
	if(DpData[0].zsCount <=0) 
	{
	    ErrMsg(ghWndMain, "ReadSzZsFirst:DpData[0].recCount <=0!");
		return FALSE;
	}
	
	buffer =(char *)malloc(reclen*DpData[0].zsCount+1);
	if (buffer==NULL) 
	{
		ErrMsg(ghWndMain, "ReadSzZsFirst:alloc buffer failed!");
		return FALSE;
    }
	memset(buffer, 0, reclen*DpData[0].zsCount+1);
	
	_llseek(SzZskData.hf,(long)headlen,SEEK_SET);
	_lread(SzZskData.hf,buffer, reclen*DpData[0].zsCount);
	for (i=0;i<DpData[0].zsCount;i++) 
	{
		FldToString(buffer+i*reclen,
			(FieldStruct *)&SzZskData.fldStruct[2],tmp);
		DpData[0].sp[i] =(float)atof(tmp);
		FldToString(buffer+i*reclen,
			(FieldStruct *)&SzZskData.fldStruct[6],
			tmp);
		DpData[0].zs[i] =(float)atof(tmp);
		DpData[0].zd[i] =DpData[0].zs[i] -DpData[0].sp[i];
	}
	free(buffer);
	return TRUE;
}

int GetShZsFirst(LPSTR lpbuf, int zsnum)
{
	char tmp[100];
	
	if(zsnum >15) return 0;
	FldToString(lpbuf,(FieldStruct *)&HqkData[1].fldStruct[7],
				tmp);
	DpData[1].zs[zsnum] =(float)atof(tmp);

	FldToString(lpbuf,(FieldStruct *)&HqkData[1].fldStruct[2],
				tmp);
	DpData[1].sp[zsnum] =(float)atof(tmp);

	//FldToString(lpbuf,(FieldStruct *)&HqkData[1].fldStruct[3],
	//			tmp);
	//if((float)atof(tmp)!=0.00)
	//	DpData[1].zd[zsnum] =(float)atof(tmp)-DpData[1].sp[zsnum];
    //else
		DpData[1].zd[zsnum] =DpData[1].zs[zsnum]-DpData[1].sp[zsnum];    
	return 0;
}

int GetShMmp(BOOL fFirst, int rec_num, LPSTR buffer)
{
	int i;
	char tmp[100];
    double f1, f2;
	MMP LastMmp;
    long tmpl;
    float tmpf;
    
	memcpy(&LastMmp, &MmpData[1].lpMmp[rec_num], sizeof(MMP));
	MmpData[1].lpMmp[rec_num].jwBuy[0]
		=HqData[1].lpRefData[rec_num].zgjm;
	MmpData[1].lpMmp[rec_num].jwSell[0]
		=HqData[1].lpRefData[rec_num].zdjm;
	f1 =f2 =0;
	for(i =0; i<3; i++)
	{
		FldToString(buffer,(FieldStruct *)&HqkData[1].fldStruct[12+i*2],
			tmp);
		MmpData[1].lpMmp[rec_num].slBuy[i] =atol(tmp)/100;
		if(i !=2)
		{
			FldToString(buffer,(FieldStruct *)&HqkData[1].fldStruct[12+i*2+1],
				tmp);
			MmpData[1].lpMmp[rec_num].jwBuy[i+1] =(float)atof(tmp);
		}
		f2+=MmpData[1].lpMmp[rec_num].slBuy[i];
	}
	for(i =0; i<3; i++)
	{
		FldToString(buffer,(FieldStruct *)&HqkData[1].fldStruct[17+i*2],
			tmp);
		MmpData[1].lpMmp[rec_num].slSell[i] =atol(tmp)/100;
		if(i !=2)
		{
			FldToString(buffer,(FieldStruct *)&HqkData[1].fldStruct[17+i*2+1],
				tmp);
			MmpData[1].lpMmp[rec_num].jwSell[i+1] =(float)atof(tmp);
		}
		f1+=MmpData[1].lpMmp[rec_num].slSell[i];
	}
	
	tmpl=MmpData[1].lpMmp[rec_num].slSell[0];
	tmpf=MmpData[1].lpMmp[rec_num].jwSell[0];

	MmpData[1].lpMmp[rec_num].slSell[0]=
		MmpData[1].lpMmp[rec_num].slSell[2];
	MmpData[1].lpMmp[rec_num].jwSell[0]=
		MmpData[1].lpMmp[rec_num].jwSell[2];

	MmpData[1].lpMmp[rec_num].slSell[2]=tmpl;
	MmpData[1].lpMmp[rec_num].jwSell[2]=tmpf;

	                                       
	if(f1+f2 ==0)
		HqData[1].lpRefData[rec_num].wb =0;
	else
		HqData[1].lpRefData[rec_num].wb =(float)((f2-f1)/(f2+f1));                                               
	
	if(memcmp(&LastMmp, &MmpData[1].lpMmp[rec_num], sizeof(MMP)))
		MmpData[1].lpChanged[rec_num] =TRUE;
	else MmpData[1].lpChanged[rec_num] =FALSE;

	return 0;
}

int ReadSzMmp(BOOL fFirst)
{
	int i, j ;
	short reclen, headlen;
	char *buffer;
	char *lpTmp;
	char tmp[100];
	double f1, f2;
	int rec_count;
	MMP LastMmp;
	long bytes;
	
	if(SzMmpkData.hf <0)
	{
	    ErrMsg(ghWndMain, "ReadSzMmp:SzMmpkData.hf <0!");
		return FALSE;
	}
	
	MsgLocal("read Sz_Mmp...");
	
	rec_count =HqData[0].recCount*6;
	
	reclen=*(short *)SzMmpkData.dbfStruct.rlen;
	headlen=*(short *)SzMmpkData.dbfStruct.hlen;
	
	//�������´��봦�������̿���δ��������
	i=(int)GetDbfRecCount(SzMmpkData.hf,headlen,reclen);
	if(rec_count>i) rec_count =i;
		
	buffer =(char *)GlobalAllocPtr(GHND, (long)rec_count*reclen+1);
	if (buffer==NULL) 
	{
		ErrMsg(ghWndMain, "ReadSzMmp:alloc buffer failed!");
		return FALSE;
	}	
	_llseek(SzMmpkData.hf,(long)headlen,SEEK_SET);
	
	bytes =hRead(SzMmpkData.hf, buffer, (long)rec_count*reclen);
	
	if(bytes ==-1)
	{	
		MsgLocal("HqRefresh:���³���szmmpk");
		GlobalFreePtr(buffer);
		return FALSE;	
	}
	
	if(bytes !=(long)rec_count*reclen)
	{
		ErrMsg(ghWndMain, "error read sz_mmpk");
	}
	else
	{
		lpTmp =buffer;
	for(i =0; i<rec_count/6; i++)
	{
		while(UDPBlockingHook());
		if(run_cancelled) break;
		
		if(clIsZsRec(0, i)) continue;
		memcpy(&LastMmp, &MmpData[0].lpMmp[i], sizeof(MMP));
		f1 =f2 =0;
		//Ӧ�����Ʊ������
		for(j =0; j<3; j++)
		{
			//if(_lread(SzMmpkData.hf,buffer, reclen) !=(UINT)reclen) break;
			//if(fFirst && j==0)
			//      FldToString(lpTmp,
			//              (FieldStruct *)&SzMmpkData.fldStruct[0],
			//              MmpData[0].lpMmp[i].zqdm);
			FldToString(lpTmp,(FieldStruct *)&SzMmpkData.fldStruct[2],
				tmp);
			MmpData[0].lpMmp[i].jwSell[j] =(float)atof(tmp);
			FldToString(lpTmp,(FieldStruct *)&SzMmpkData.fldStruct[4],
				tmp);
			MmpData[0].lpMmp[i].slSell[j] =atol(tmp)/100;
			f1+=(double)MmpData[0].lpMmp[i].slSell[j];
			lpTmp +=reclen;
		}
		if(j !=3) break;
		for(j =0; j<3; j++)
		{
			//if(_lread(SzMmpkData.hf,buffer, reclen) !=(UINT)reclen) break;;
			FldToString(lpTmp,(FieldStruct *)&SzMmpkData.fldStruct[2],
				tmp);
			MmpData[0].lpMmp[i].jwBuy[j] =(float)atof(tmp);
			FldToString(lpTmp,(FieldStruct *)&SzMmpkData.fldStruct[3],
				tmp);
			MmpData[0].lpMmp[i].slBuy[j] =atol(tmp)/100;
			f2+=(double)MmpData[0].lpMmp[i].slBuy[j];
			lpTmp +=reclen;
		}                                               
		if(j !=3) break;
		if(f1+f2 !=0)
			HqData[0].lpRefData[i].wb
					=(float)((f2-f1)/(f1+f2));
		else HqData[0].lpRefData[i].wb =0;
		if(memcmp(&LastMmp, &MmpData[0].lpMmp[i], sizeof(MMP)))
			MmpData[0].lpChanged[i] =TRUE;
		else MmpData[0].lpChanged[i] =FALSE;
		//rec_num++;
	}
	}
	//û�г�ʼ��������������
	if(rec_count/6<HqData[0].recCount)
	{         
		memset(&MmpData[0].lpMmp[rec_count/6],0,
			sizeof(MMP)*(HqData[0].recCount -rec_count/6));
	}
	GlobalFreePtr(buffer);
	MsgLocal("OK.");
	return TRUE;
}

int RefreshSzZs(void)
{
	int i ;
	short reclen, headlen;

	char *buffer;
	char tmp[100];
	static int times =0;

	if(SzZskData.hf <0)
		return 0;
	
	reclen=*(short *)SzZskData.dbfStruct.rlen;
	headlen=*(short *)SzZskData.dbfStruct.hlen;
	
	buffer =(char *)malloc(reclen*DpData[0].zsCount+1);
	if (buffer==NULL) 
	{
		ErrMsg(ghWndMain, "RefreshSzZs:alloc buffer failed!");
		return -1;
	}
	memset(buffer, 0, reclen*DpData[0].zsCount+1);
	
	_llseek(SzZskData.hf,(long)headlen,SEEK_SET);
	_lread(SzZskData.hf,buffer, reclen*DpData[0].zsCount);
	for (i=0;i<DpData[0].zsCount;i++) 
	{
		FldToString(buffer+i*reclen,
			(FieldStruct *)&SzZskData.fldStruct[6],
			tmp);
		DpData[0].zs[i] =(float)atof(tmp);
		DpData[0].zd[i] =DpData[0].zs[i]-DpData[0].sp[i];
	}
	free(buffer);
	return 0;
}

int RefreshShZs(LPSTR lpbuf, int zsnum)
{
	char tmp[100];
	
	if(zsnum >15) return 0;
	FldToString((char *)lpbuf,(FieldStruct *)&HqkData[1].fldStruct[7],
				tmp);
	DpData[1].zs[zsnum] =(float)atof(tmp);
    
	FldToString((char *)lpbuf,(FieldStruct *)&HqkData[1].fldStruct[2],
				tmp);
	DpData[1].sp[zsnum] =(float)atof(tmp);
    
	DpData[1].zd[zsnum] =DpData[1].zs[zsnum]-DpData[1].sp[zsnum];

	return 0;
}

int GetSzZqmc(int jys)
{
	int i, j ;
	short reclen, headlen, fldnum;
	int rec_count;

	char *buffer;
	char tmp[40];
	
	if(GpkData[jys].hf ==-1)
	{
		ErrMsg(ghWndMain, "GetSzZqmc:GpkData[jys].hf ==-1!");
		return FALSE;
	}
	rec_count =*(int *)GpkData[jys].dbfStruct.recnum;
	if(rec_count <HqData[jys].recCount) rec_count =HqData[jys].recCount;
	
	fldnum =GpkData[jys].fldCount;
	reclen=*(short *)GpkData[jys].dbfStruct.rlen;
	headlen=*(short *)GpkData[jys].dbfStruct.hlen;
	if(rec_count <=0)
	{   
	     ErrMsg(ghWndMain, "GetSzZqmc:rec_count <=0!");
		 return FALSE;
	}
	buffer =(char *)malloc(reclen+1);
	if (buffer==NULL) 
	{
		ErrMsg(ghWndMain, "GetSzZqmc:alloc buffer failed!");
		return FALSE;
    }
	
	_llseek(GpkData[jys].hf,(long)headlen,SEEK_SET);
	for (i=0;i<rec_count;i++) 
	{
		if(_lread(GpkData[jys].hf,buffer,reclen) !=(UINT)reclen) break;
		
		// get zqdm
		FldToString(buffer,(FieldStruct *)&GpkData[jys].fldStruct[0], tmp);
		for(j =0; j<HqData[jys].recCount; j++)
			if(!strcmp(tmp, HqData[jys].lpPreData[j].zqdm))
				break;
		if(j <HqData[jys].recCount)
			FldToString(buffer,(FieldStruct *)&GpkData[jys].fldStruct[1],
						HqData[jys].lpPreData[j].zqmc);
	}
	if(i <rec_count)
	{
		for(; i<HqData[jys].recCount; i++)
		{
			strcpy(HqData[jys].lpPreData[i].zqmc,
					HqData[jys].lpPreData[i].zqdm);
		}
	}
	free(buffer);
	
	return TRUE;
}

int CheckZqdm(LPSTR lpzqdm)
{
	return 0;
}

extern long tim_seconds;
//ȡ��������
int GetDpData(int jys, BOOL fFirst)
{
	int i;
	//int jys;
	float oldjg;
	long b_lc =0L, s_lc =0L;
	HQ_REF_DATA LastHq;
	DP_DATA LastDp;
	int rec_num;
	
	memcpy(&LastDp, &DpData[jys], sizeof(DP_DATA));

	DpData[jys].cjzje =CalcCjzje(jys);
	DpData[jys].npbl =CalcNpbl(jys);
	DpData[jys].cjss =CalcCjss(jys);
	DpData[jys].upCount =DpData[jys].downCount =DpData[jys].equalCount =0;
	
	for(i =0; i<HqData[jys].recCount; i++)
	{
		oldjg =HqData[jys].lpRefData[i].zjcj;
		//�������ָ�����������������
		if(!clIsZsRec(jys, i))
		{
			if(HqData[jys].lpRefData[i].zdf >0)
				DpData[jys].upCount ++;
			else if(HqData[jys].lpRefData[i].zdf <0)
				DpData[jys].downCount ++;
			else DpData[jys].equalCount ++;
		}
		else
		{
			memcpy(&LastHq, &HqData[jys].lpRefData[i], sizeof(HQ_REF_DATA));
				
			HqData[jys].lpRefData[i].cjss =DpData[jys].cjss;
			HqData[jys].lpRefData[i].cjje =DpData[jys].cjzje;
			HqData[jys].lpRefData[i].npzl 
					=(int)((double)DpData[jys].npbl*(double)DpData[jys].cjss);
			HqData[jys].lpRefData[i].wb =0;
			HqData[jys].lpRefData[i].lc =DpData[jys].cjss-LastDp.cjss;
			if(HqData[jys].lpRefData[i].lc <0)
				HqData[jys].lpRefData[i].lc =0L;
				
				
			if(jys ==0) rec_num =HqData[jys].recCount-i;
			else rec_num =i;
			if(!fFirst)
			{
				if(tim_seconds -zs_times[jys][rec_num] >gnHqRefreshTime)
				{
					GraphData[jys].lpGraData[i].lc =
							DpData[jys].cjss-oldDpCjss2[jys][rec_num];
					GetDpGraData(jys, i);
					if(GraphData[jys].lpGraData[i].lc)
						WriteGraData(jys, i);
					zs_times[jys][rec_num] =tim_seconds;
					oldDpCjss2[jys][rec_num] =DpData[jys].cjss;
				}
			}
			else
			{
				zs_times[jys][rec_num] =tim_seconds;
				oldDpCjss2[jys][rec_num] =DpData[jys].cjss;
			}
		}
	}
	
	if(memcmp(&LastDp, &DpData[jys], sizeof(DP_DATA))) return 1;
	
	return 0;
}

int GetMaxMin10(int jys)
{
	int ret =0;
	MAXMIN_DATA LastMaxMin[2];
	
	memcpy(&LastMaxMin[0], &MaxMinData[jys][0], sizeof(MAXMIN_DATA));
	memcpy(&LastMaxMin[1], &MaxMinData[jys][1], sizeof(MAXMIN_DATA));

	GetMaxZd10(jys);
	GetMaxZdf10(jys);
	GetMaxCjss10(jys);
	GetMaxCjje10(jys);
	if(memcmp(&MaxMinData[jys][0], &LastMaxMin[0], sizeof(MAXMIN_DATA)))
		ret++;
	GetMinZd10(jys);
	GetMinZdf10(jys);
	GetMinCjss10(jys);
	GetMinCjje10(jys);
	if(memcmp(&MaxMinData[jys][1], &LastMaxMin[1], sizeof(MAXMIN_DATA)))
		ret+=2;
	
	return ret;
}

void GetMaxZdf10(int jys)
{
	GetFloatSort10(jys, 8, SORT_UP, &MaxMinData[jys][0].recNum[0][0]);
}

void GetMinZdf10(int jys)
{
	GetFloatSort10(jys, 8, SORT_DOWN, &MaxMinData[jys][1].recNum[0][0]);
}

void GetMaxCjss10(int jys)
{
	GetLongSort10(jys, 9, SORT_UP, &MaxMinData[jys][0].recNum[2][0]);
}

void GetMinCjss10(int jys)
{
	GetLongSort10(jys, 9, SORT_DOWN, &MaxMinData[jys][1].recNum[2][0]);
}

void GetMaxCjje10(int jys)
{
	GetLongSort10(jys, 13, SORT_UP, &MaxMinData[jys][0].recNum[3][0]);
}

void GetMinCjje10(int jys)
{
	GetLongSort10(jys, 13, SORT_DOWN, &MaxMinData[jys][1].recNum[3][0]);
}

void GetMaxZd10(int jys)
{
	int key, i, j, n;
	float fval, f1, f;
	int count =0;
	int fldNum =8;
			
	for(i =0; i<10; i++)
		MaxMinData[jys][0].recNum[1][i] =i;
		
	for(i =0; i<HqData[jys].recCount; i++)
		keys[i] =i;
	
	for(i =0; i<HqData[jys].recCount; i++)
	{
		if(!IsMaxMin(jys, keys[i])) continue;
		if(HqData[jys].lpRefData[keys[i]].zjcj ==0) continue;
		key =i;
		if(HqData[jys].lpPreData[keys[key]].zrsp)
			fval =HqData[jys].lpRefData[keys[key]].zjcj
					-HqData[jys].lpPreData[keys[key]].zrsp;
		else fval =-100;
		for(j =i+1; j<HqData[jys].recCount; j++)
		{
			if(!IsMaxMin(jys, keys[j])) continue;
			if(HqData[jys].lpRefData[keys[j]].zjcj ==0) continue;
			if(HqData[jys].lpPreData[keys[j]].zrsp)
				f1 =HqData[jys].lpRefData[keys[j]].zjcj
						-HqData[jys].lpPreData[keys[j]].zrsp;
			else f1 =-100;
			f =f1-fval;
			if(f1>fval)
			{
				key =j;
				fval =f1;
			}
		}
		if(key >i)
		{
			n =keys[i];
			keys[i] =keys[key];
			keys[key] =n;
		}
		MaxMinData[jys][0].recNum[1][count] =key;
		if(++count >=10) break;
	}
}

void GetMinZd10(int jys)
{
	int key, i, j, n;
	float fval, f1, f;
	int count =0;
	int fldNum =8;
			
	for(i =0; i<10; i++)
		MaxMinData[jys][1].recNum[1][i] =i;
		
	for(i =0; i<HqData[jys].recCount; i++)
		keys[i] =i;
	
	for(i =0; i<HqData[jys].recCount; i++)
	{
		if(!IsMaxMin(jys, keys[i])) continue;
		if(HqData[jys].lpRefData[keys[i]].zjcj ==0) continue;
		key =i;
		if(HqData[jys].lpPreData[keys[key]].zrsp)
			fval =HqData[jys].lpRefData[keys[key]].zjcj
					-HqData[jys].lpPreData[keys[key]].zrsp;
		else fval =100;
		for(j =i+1; j<HqData[jys].recCount; j++)
		{
			if(!IsMaxMin(jys, keys[j])) continue;
			if(HqData[jys].lpRefData[keys[j]].zjcj ==0) continue;
			if(HqData[jys].lpPreData[keys[j]].zrsp)
				f1 =HqData[jys].lpRefData[keys[j]].zjcj
						-HqData[jys].lpPreData[keys[j]].zrsp;
			else f1 =100;
			f =f1-fval;
			if(f1<fval)
			{
				key =j;
				fval =f1;
			}
		}
		if(key >i)
		{
			n =keys[i];
			keys[i] =keys[key];
			keys[key] =n;
		}
		MaxMinData[jys][1].recNum[1][count] =key;
		if(++count >=10) break;
	}
}

BOOL CheckTpbz(int jys, LPSTR buffer)
{
	return FALSE;
}

BOOL clIsZsRec(int jys, int rec_num)
{
	if(jys ==0)
	{
		if(!strncmp(HqData[jys].lpPreData[rec_num].zqdm, "99", 2))
			return TRUE;
	}
	else
		if(!strncmp(HqData[jys].lpPreData[rec_num].zqdm, "0000", 4)
			&& (HqData[jys].lpPreData[rec_num].zqdm[4] =='0'
				||HqData[jys].lpPreData[rec_num].zqdm[4] =='1'))
			return TRUE;
	
	return FALSE;
}

LPSTR GetHqFldPos(int jys, int rec_num, int fld_num)
{
	switch(fld_num)
	{
		case 0:
		return (LPSTR)&HqData[jys].lpPreData[rec_num].zqdm[0];
		case 1:
		return (LPSTR)&HqData[jys].lpPreData[rec_num].zrsp;
		case 2:
		return (LPSTR)&HqData[jys].lpPreData[rec_num].jrkp;
		case 3:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zgjg;
		case 4:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zdjg;
		case 5:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zgjm;
		case 6:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zdjm;
		case 7:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zjcj;
		case 8:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zdf;
		case 9:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].cjss;
		case 10:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].lc;
		case 11:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].npzl;
		case 12:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].wb;
		case 13:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].cjje;
	}
}

int GetFloatSort10(int jys, short fldNum, int type, short *lpKeys)
{
	int key, i, j, n;
	float fval, f1, f;
	int count =0;
		
	for(i =0; i<10; i++)
		lpKeys[i] =i;
		
	for(i =0; i<HqData[jys].recCount; i++)
		keys[i] =i;
	
	for(i =0; i<HqData[jys].recCount; i++)
	{
		if(!IsMaxMin(jys, keys[i])) continue;
		if(HqData[jys].lpRefData[keys[i]].zjcj ==0) continue;
		key =i;
		fval =*(float*)GetHqFldPos(jys, keys[key], fldNum);
		for(j =i+1; j<HqData[jys].recCount; j++)
		{
			if(!IsMaxMin(jys, keys[j])) continue;
			if(HqData[jys].lpRefData[keys[j]].zjcj ==0) continue;
			f1 =*(float *)GetHqFldPos(jys, keys[j], fldNum);
			f =f1-fval;
			if(type ==SORT_UP && f>.0)
			{
				key =j;
				fval =f1;
			}
			else if(type ==SORT_DOWN && f<.0)
			{
				key =j;
				fval =f1;
			}
		}
		if(key >i)
		{
			n =keys[i];
			keys[i] =keys[key];
			keys[key] =n;
		}
		lpKeys[count] =key;
		if(++count >=10) break;
	}
	return 0;
}

int GetLongSort10(int jys, short fldNum, int type, short *lpKeys)
{
	int key, i, j, n;
	int lval, l1, l;
	int count =0;
	
	for(i =0; i<10; i++)
		lpKeys[i] =i;
		
	for(i =0; i<HqData[jys].recCount; i++)
		keys[i] =i;
	
	for(i =0; i<HqData[jys].recCount; i++)
	{
		if(!IsMaxMin(jys, keys[i])) continue;
		if(HqData[jys].lpRefData[keys[i]].zjcj ==0) continue;
		key =i;
		lval =*(int*)GetHqFldPos(jys, keys[key], fldNum);
		for(j =i+1; j<HqData[jys].recCount; j++)
		{
			if(!IsMaxMin(jys, keys[j])) continue;
			if(HqData[jys].lpRefData[keys[j]].zjcj ==0) continue;
			l1 =*(int *)GetHqFldPos(jys, keys[j], fldNum);
			l =l1-lval;
			if(type ==SORT_UP && l>.0)
			{
				key =j;
				lval =l1;
			}
			else if(type ==SORT_DOWN && l<.0)
			{
				key =j;
				lval =l1;
			}
		}
		if(key >i)
		{
			n =keys[i];
			keys[i] =keys[key];
			keys[key] =n;
		}
		lpKeys[count] =key;
		if(++count >=10) break;
	}
	return 0;
}

long CalcCjzje(int jys)
{
	int i;
	long l =0;
	
	for(i =0; i<HqData[jys].recCount; i++)
	{   
		if(jys==0)
		{
			if(HqData[jys].lpPreData[i].zqdm[0]=='1'||HqData[jys].lpPreData[i].zqdm[0]=='9')
				continue;
			if(HqData[jys].lpPreData[i].zqdm[0]=='3'||HqData[jys].lpPreData[i].zqdm[0]=='8')
				continue;				
		}
		if(jys==1)
		{   
			//if(strncmp(HqData[jys].lpPreData[i].zqdm,"70",2)!=0&&strncmp(HqData[jys].lpPreData[i].zqdm,"71",2)!=0)
            {
				if(HqData[jys].lpPreData[i].zqdm[0]=='0'||HqData[jys].lpPreData[i].zqdm[0]=='1'||
					HqData[jys].lpPreData[i].zqdm[0]=='2'||HqData[jys].lpPreData[i].zqdm[0]=='7')
				continue;		
			}
		}
		if(!clIsZsRec(jys, i))			   	
			l +=HqData[jys].lpRefData[i].cjje;
	}
	
	return l;
}

float CalcNpbl(int jys)
{
	int i;
	long double lfbuy =0, lftotal =0;
	float lf;
	
	for(i =0; i<HqData[jys].recCount; i++)
	{   
		if(jys==0)
		{
			if(HqData[jys].lpPreData[i].zqdm[0]=='1'||HqData[jys].lpPreData[i].zqdm[0]=='9')
				continue;
			if(HqData[jys].lpPreData[i].zqdm[0]=='3'||HqData[jys].lpPreData[i].zqdm[0]=='8')
				continue;				
		}
		if(jys==1)
		{ 
			//if(strncmp(HqData[jys].lpPreData[i].zqdm,"70",2)!=0&&strncmp(HqData[jys].lpPreData[i].zqdm,"71",2)!=0)
		    {
				if(HqData[jys].lpPreData[i].zqdm[0]=='0'||HqData[jys].lpPreData[i].zqdm[0]=='1'||
					HqData[jys].lpPreData[i].zqdm[0]=='2'||HqData[jys].lpPreData[i].zqdm[0]=='7')
				continue;		
			}
		}
		if(!clIsZsRec(jys, i))
		{
			lfbuy +=(long double)HqData[jys].lpRefData[i].npzl;
			lftotal +=(long double)HqData[jys].lpRefData[i].cjss;
		}
	}	
	if(lftotal ==0) return (float)0;
	
	lf =(float)(lfbuy/lftotal);
	return lf;
}

long CalcCjss(int jys)
{
	int i;
	long l =0;
	
	for(i =0; i<HqData[jys].recCount; i++)
	{
		if(jys==0)
		{
			if(HqData[jys].lpPreData[i].zqdm[0]=='1'||HqData[jys].lpPreData[i].zqdm[0]=='9')
				continue;
			if(HqData[jys].lpPreData[i].zqdm[0]=='3'||HqData[jys].lpPreData[i].zqdm[0]=='8')
				continue;			
		}
		if(jys==1)
		{    
			//if(strncmp(HqData[jys].lpPreData[i].zqdm,"70",2)!=0&&strncmp(HqData[jys].lpPreData[i].zqdm,"71",2)!=0)
			{
				if(HqData[jys].lpPreData[i].zqdm[0]=='0'||HqData[jys].lpPreData[i].zqdm[0]=='1'||
					HqData[jys].lpPreData[i].zqdm[0]=='2'||HqData[jys].lpPreData[i].zqdm[0]=='7')
				continue;		
			}
		}	
		if(!clIsZsRec(jys, i))
			l +=HqData[jys].lpRefData[i].cjss;
	}
	return l;
}

int UDPBlockingHook(void)
{
	MSG msg;

	if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
	{
		if(!ghWndMain || !IsDialogMessage(ghWndMain, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);   
			if(msg.message ==WM_QUIT)
			{
				PostQuitMessage(0);
				run_cancelled =TRUE;               
				return FALSE;
			}
		}            
		return TRUE;
	}
	return FALSE;
}

int clHqAllocMem(int jys, int recCount)
{
	static MAX_REC_NUM =1000;
	unsigned int ReqBytes;

	if(recCount>MAX_REC_NUM)
		return -1;

	if(HqData[jys].recCount ==0)
	{
		HqData[jys].recCount =recCount;

		ReqBytes =MAX_REC_NUM*sizeof(HQ_PRE_DATA);
		HqData[jys].lpPreData =(LPHQ_PRE_DATA)GlobalAllocPtr(GHND, 
						ReqBytes);

		ReqBytes =MAX_REC_NUM*sizeof(HQ_REF_DATA);
		HqData[jys].lpRefData =(LPHQ_REF_DATA)GlobalAllocPtr(GHND, 
						ReqBytes);

		ReqBytes =MAX_REC_NUM*HQ_REF_ITEM_COUNT;
		HqData[jys].lpbChanged =(BYTE *)GlobalAllocPtr(GHND, 
						ReqBytes);

		ReqBytes =MAX_REC_NUM*sizeof(GRA_DATA);
		GraphData[jys].lpGraData =(LPGRA_DATA)GlobalAllocPtr(GHND,
						HqData[jys].recCount*sizeof(GRA_DATA));

		ReqBytes =MAX_REC_NUM*sizeof(GRA_HEAD);
		GraphData[jys].lpGraHead =(LPGRA_HEAD)GlobalAllocPtr(GHND,
						ReqBytes);
		
		ReqBytes =MAX_REC_NUM*sizeof(MMP);
		MmpData[jys].lpMmp =(LPMMP)GlobalAllocPtr(GHND,
				ReqBytes);
		
		ReqBytes =MAX_REC_NUM;
		MmpData[jys].lpChanged =(BYTE *)GlobalAllocPtr(GHND,
						ReqBytes);

		ReqBytes =MAX_REC_NUM*sizeof(HQ_REF_DATA_V202)+sizeof(short);
		LzwData202[jys].recCount =(short *)GlobalAllocPtr(GHND,
		 		ReqBytes);
		LzwData202[jys].lpData202 =(LPHQ_REF_DATA_V202)(LzwData202[jys].recCount +1);
	}
	/*
	else if(HqData[jys].recCount <recCount)
	{
		HqData[jys].recCount =recCount;
		HqData[jys].lpPreData =(LPHQ_PRE_DATA)GlobalReAllocPtr(HqData[jys].lpPreData,
					HqData[jys].recCount*sizeof(HQ_PRE_DATA), GMEM_MOVEABLE);
		HqData[jys].lpRefData =(LPHQ_REF_DATA)GlobalReAllocPtr(HqData[jys].lpRefData,
					HqData[jys].recCount*sizeof(HQ_REF_DATA), GMEM_MOVEABLE);
		HqData[jys].lpbChanged =(BYTE *)GlobalReAllocPtr(HqData[jys].lpbChanged,
					HqData[jys].recCount*HQ_REF_ITEM_COUNT, GMEM_MOVEABLE);
		GraphData[jys].lpGraHead =(LPGRA_HEAD)GlobalReAllocPtr(GraphData[jys].lpGraHead,
					HqData[jys].recCount*sizeof(GRA_HEAD),GMEM_MOVEABLE);
		GraphData[jys].lpGraData =(LPGRA_DATA)GlobalReAllocPtr(GraphData[jys].lpGraData,
					HqData[jys].recCount*sizeof(GRA_DATA),GMEM_MOVEABLE);
		MmpData[jys].lpMmp =(LPMMP)GlobalReAllocPtr(MmpData[jys].lpMmp,
					HqData[jys].recCount*sizeof(MMP), GMEM_MOVEABLE);
		MmpData[jys].lpChanged =(BYTE *)GlobalReAllocPtr(MmpData[jys].lpChanged,
					HqData[jys].recCount, GHND);

		LzwData202[jys].recCount =(short *)GlobalReAllocPtr(LzwData202[jys].recCount,
			HqData[jys].recCount*sizeof(HQ_REF_DATA_V202)+sizeof(short), GMEM_MOVEABLE);

		LzwData202[jys].lpData202 =(LPHQ_REF_DATA_V202)( LzwData202[jys].recCount+1);
	}
	*/

	if(HqData[jys].lpPreData ==NULL)
	{
		ErrMsg(ghWndMain, "alloc mem pre data failed!");
		return -1;
	}
		
	if(HqData[jys].lpRefData ==NULL)
	{
		ErrMsg(ghWndMain, "alloc mem ref data failed!");
		return -1;
	}
	if(HqData[jys].lpbChanged ==NULL)
	{
		ErrMsg(ghWndMain, "alloc mem chg data failed!");
		return -1;
	}
	if(GraphData[jys].lpGraData ==NULL || GraphData[jys].lpGraHead ==NULL)
	{
		ErrMsg(ghWndMain, "alloc mem graph data failed!");
		return -1;
	}
	if(MmpData[jys].lpMmp ==NULL)
	{
		ErrMsg(ghWndMain, "alloc mem mmp failed!");
		return -1;
	}
	if(MmpData[jys].lpChanged ==NULL)
	{
		ErrMsg(ghWndMain, "alloc mem mmp changed failed!");
		return -1;
	}
	if(LzwData202[jys].recCount==NULL)
	{
		ErrMsg(ghWndMain, "alloc mem DataV202 failed!");
		return -1;
	}
	return 0;       
}

BOOL IsMaxMin(int jys, int rec_num)
{
	char c;
	c =HqData[jys].lpPreData[rec_num].zqdm[0];      
	
	if(clIsZsRec(jys, rec_num)) return FALSE;
	if(jys ==0)
	{
		if(c =='0' || c =='4') return TRUE;             
	}
	else if((c =='0' && !clIsZsRec(jys, rec_num))
			|| c =='5' || c=='6')
		return TRUE;
	
	return FALSE;
}

BOOL IsB(int jys, int rec_num)
{
	if((jys ==0 && HqData[jys].lpPreData[rec_num].zqdm[0] =='2')
		|| (jys ==1 && HqData[jys].lpPreData[rec_num].zqdm[0] =='2'))
		return TRUE;
	return FALSE;
}

BOOL IsGuoZhai(int jys, int rec_num)
{
	return FALSE;
}

int GetGraData(int jys, int i, LPHQ_REF_DATA lpLastHq)
{
	float jg1, jg2;
	
	if(HqData[jys].lpRefData[i].lc>0)
	{
		//��������
		//GraphData[jys].lpGraHead[i].dateNum==date_num;
		GraphData[jys].lpGraData[i].tim=tim;                                    
		if(GraphData[jys].lpGraHead[i].recCount==0)
		{
			//��һ������������г�ʼ��
			//HqData[jys].lpPreData[i].jrkp=lpLastHq->zjcj;
			//��ʼ����ʱ�����
			HqData[jys].lpRefData[i].npzl=HqData[jys].lpRefData[i].cjss/2;
			
			GraphData[jys].lpGraHead[i].zglc=GraphData[jys].lpGraHead[i].zdlc       
				=0;//HqData[jys].lpRefData[i].lc;
			//GraphData[jys].lpGraHead[i].zrsp =HqData[jys].lpPreData[i].zrsp;
			GraphData[jys].lpGraData[i].cjjg=HqData[jys].lpRefData[i].zjcj-HqData[jys].lpPreData[i].zrsp;
			GraphData[jys].lpGraData[i].lc=0;//HqData[jys].lpRefData[i].lc;
			GraphData[jys].lpGraData[i].zl=HqData[jys].lpRefData[i].cjss;
			GraphData[jys].lpGraHead[i].zgjg =GraphData[jys].lpGraHead[i].zdjg
					=HqData[jys].lpRefData[i].zjcj-HqData[jys].lpPreData[i].zrsp;
		}
		else
		{       
			jg1 =lpLastHq->zdjm-HqData[jys].lpRefData[i].zjcj;
			if(jg1 <0) jg1 *=-1;
			jg2 =HqData[jys].lpRefData[i].zjcj-lpLastHq->zgjm;
			if(jg2 <0) jg2 *=-1;
			
			if(jg1 <=jg2)
			{   
				HqData[jys].lpRefData[i].npzl
					+=HqData[jys].lpRefData[i].lc;
				GraphData[jys].lpGraData[i].BS=TRUE;
			}
			else
				GraphData[jys].lpGraData[i].BS=FALSE;                                                           
			
			if(GraphData[jys].lpGraHead[i].zglc< HqData[jys].lpRefData[i].lc)
				GraphData[jys].lpGraHead[i].zglc =HqData[jys].lpRefData[i].lc;  
			if(GraphData[jys].lpGraHead[i].zdlc >HqData[jys].lpRefData[i].lc)
				GraphData[jys].lpGraHead[i].zdlc =HqData[jys].lpRefData[i].lc;  
		}
		GraphData[jys].lpGraHead[i].npzl =HqData[jys].lpRefData[i].npzl;
		GraphData[jys].lpGraHead[i].wpzl =HqData[jys].lpRefData[i].cjss
				-HqData[jys].lpRefData[i].npzl;
		GraphData[jys].lpGraData[i].lc =HqData[jys].lpRefData[i].lc;
		GraphData[jys].lpGraData[i].zl =HqData[jys].lpRefData[i].cjss;
		GraphData[jys].lpGraData[i].cjjg =HqData[jys].lpRefData[i].zjcj
									-HqData[jys].lpPreData[i].zrsp;
		if(GraphData[jys].lpGraHead[i].zgjg <GraphData[jys].lpGraData[i].cjjg)
			GraphData[jys].lpGraHead[i].zgjg =GraphData[jys].lpGraData[i].cjjg;
		if(GraphData[jys].lpGraHead[i].zdjg >GraphData[jys].lpGraData[i].cjjg)
			GraphData[jys].lpGraHead[i].zdjg =GraphData[jys].lpGraData[i].cjjg;
		
		GraphData[jys].lpGraHead[i].recCount++;
		return 0;
	}
	else GraphData[jys].lpGraData[i].lc =0;
	
	return 1;
}

int GetDpGraData(int jys, int i)
{
	if(HqData[jys].lpRefData[i].lc <=0 || tim <=0) return 0;
	
	GraphData[jys].lpGraData[i].tim=tim;                                    
	
	if(GraphData[jys].lpGraHead[i].recCount==0)
	{
		HqData[jys].lpRefData[i].npzl=HqData[jys].lpRefData[i].cjss/2;
			
		GraphData[jys].lpGraHead[i].zglc=GraphData[jys].lpGraHead[i].zdlc       
				=GraphData[jys].lpGraData[i].lc;
		GraphData[jys].lpGraData[i].cjjg=HqData[jys].lpRefData[i].zjcj-HqData[jys].lpPreData[i].zrsp;
		//GraphData[jys].lpGraData[i].lc=0;//HqData[jys].lpRefData[i].lc;
		GraphData[jys].lpGraData[i].zl=HqData[jys].lpRefData[i].cjss;
		GraphData[jys].lpGraHead[i].zgjg =GraphData[jys].lpGraHead[i].zdjg
			=HqData[jys].lpRefData[i].zjcj-HqData[jys].lpPreData[i].zrsp;
	}
	else
	{       
		if(GraphData[jys].lpGraHead[i].zglc< GraphData[jys].lpGraData[i].lc)
			GraphData[jys].lpGraHead[i].zglc =GraphData[jys].lpGraData[i].lc;       
		if(GraphData[jys].lpGraHead[i].zdlc >GraphData[jys].lpGraData[i].lc)
			GraphData[jys].lpGraHead[i].zdlc =GraphData[jys].lpGraData[i].lc;       
	}
	GraphData[jys].lpGraHead[i].npzl =HqData[jys].lpRefData[i].npzl;
	GraphData[jys].lpGraHead[i].wpzl =HqData[jys].lpRefData[i].cjss
			-HqData[jys].lpRefData[i].npzl;
	GraphData[jys].lpGraData[i].zl =HqData[jys].lpRefData[i].cjss;
	GraphData[jys].lpGraData[i].cjjg =HqData[jys].lpRefData[i].zjcj
						-HqData[jys].lpPreData[i].zrsp;
	if(GraphData[jys].lpGraHead[i].zgjg <GraphData[jys].lpGraData[i].cjjg)
		GraphData[jys].lpGraHead[i].zgjg =GraphData[jys].lpGraData[i].cjjg;
	if(GraphData[jys].lpGraHead[i].zdjg >GraphData[jys].lpGraData[i].cjjg)
		GraphData[jys].lpGraHead[i].zdjg =GraphData[jys].lpGraData[i].cjjg;
		
	GraphData[jys].lpGraHead[i].recCount++;
	
	return 0;
}


//////////////////////////////////////////////////////////////////
//����		����ȡ��������Ч��¼��
//           �����Ĺ�Ʊ�����ǰ������Ĵ������У�����ֵݼ�������򽫵ݼ��㴦��
//           ��Ʊ�ų��ڲɼ�֮��
//����		��jys---������
//������	����������Ч��¼��
//�޸�����	��1997/10/15

int GetValidRecNum(int jys)
{
	int i;
	short reclen,headlen;

	long recCount;
	char *buffer;
	char *lpTmp;
	char zqdm[MAX_ZQDM_SIZE],temp[MAX_ZQDM_SIZE];
	long bytes;

	reclen=*(short *)HqkData[jys].dbfStruct.rlen;
	headlen=*(short *)HqkData[jys].dbfStruct.hlen;	
	
    recCount =GetDbfRecCount(HqkData[jys].hf,headlen,reclen);
    if(recCount <=0)	
    {
    	MsgLocal("GetVali..:recCount<=0");
    	return 0;
    }
    	
	if ((buffer=(char *)GlobalAllocPtr(GHND, recCount*reclen+1))==NULL) 
	{
		ErrMsg(ghWndMain, "GetValidRecNum:alloc buffer failed!");
		return -1;
	}
	
	_llseek(HqkData[jys].hf,(long)headlen,SEEK_SET);
    
    bytes =hRead(HqkData[jys].hf, buffer, recCount*reclen);
    if(bytes ==-1)
    {    
		ErrMsg(ghWndMain, "GetValidRecNum:hRead==-1");		
		GlobalFreePtr(buffer);  
		return 0;
    }
    
	if(bytes !=recCount*reclen)
	{
		ErrMsg(ghWndMain, "read hqk error");
		GlobalFreePtr(buffer);  
		return -1;
	}
	
	lpTmp =buffer;
	memset(zqdm,0,MAX_ZQDM_SIZE);
	for(i=0;i<recCount;i++)	
	{

		FldToString(lpTmp,(FieldStruct *)&HqkData[jys].fldStruct[0],temp);
		if(zqdm[0]==0)
		{
			strcpy(zqdm,temp);
		}
		else
		{
			if(atol(zqdm)<atol(temp))
				strcpy(zqdm,temp);
			else
				break;
		}
		lpTmp +=reclen;
	}
	GlobalFreePtr(buffer);  
	return i;
}

BOOL JyOpen(int jys)
{
	char *buffer =NULL, tmp[30];
	short reclen,headlen,i;
	long recCount;
	static float zs_old[2] ={-1, -1};
	float zs;
		
	if(jys ==0)
	{		
		reclen =*(short *)HqkData[jys].dbfStruct.rlen;
		headlen=*(short *)HqkData[jys].dbfStruct.hlen;
		
		buffer =(char *)malloc(reclen+1);
		if (buffer==NULL) 
		{
			ErrMsg(ghWndMain, "JyOpen:alloc buffer failed!");
			return	FALSE;
		}
		//recCount =GetDbfRecCount(HqkData[jys].hf,headlen,reclen);
		recCount =GetValidRecNum(jys);

		if(recCount ==0)
			return FALSE;
		for(i=0;i<recCount;i++)
		{
			_llseek(HqkData[jys].hf,(long)*(short *)HqkData[jys].dbfStruct.hlen+(long)reclen*(long)((recCount-1-i)),SEEK_SET);
			if(_lread(HqkData[jys].hf, buffer, reclen)!=(UINT)reclen)
				break;
			FldToString(buffer,(FieldStruct *)&HqkData[jys].fldStruct[0], tmp);
			if(strncmp(tmp,"9902",4)==0||strncmp(tmp,"9901",4)==0)
			{
			    FldToString(buffer,(FieldStruct *)&HqkData[jys].fldStruct[6], tmp);
				break;
			}
		}
	}
	else if(jys ==1)
	{
		reclen=*(short *)HqkData[1].dbfStruct.rlen;
		buffer =(char *)malloc(reclen+1);
		if (buffer==NULL) 
		{
			ErrMsg(ghWndMain, "JyOpen:alloc buffer failed!");
			return	FALSE;
		}
		_llseek(HqkData[1].hf,(long)*(short *)HqkData[1].dbfStruct.hlen,SEEK_SET);
		_lread(HqkData[jys].hf, buffer, reclen);
		FldToString(buffer,(FieldStruct *)&HqkData[1].fldStruct[11], tmp);
	}
	else 
		return FALSE;
	
	zs =(float)atof(tmp);
	if(zs_old[jys] !=-1 && zs_old[jys] !=zs && zs !=0.0)
	{
		zs_old[jys] =zs;
		free(buffer);
		DelayMs(5);
		return TRUE;
	}
	else zs_old[jys] =zs;
	
	if(buffer) free(buffer);
	
	return FALSE;
}
