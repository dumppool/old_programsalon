#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lzw.h"

#define         BITS            15
#define         MAX_CODE        ((1L<<BITS) -1 )        //32767
#define         TABLE_SIZE      35023                   //137*256=35072
#define         TABLE_BANKS     ((TABLE_SIZE >> 8) +1)  //137
#define         END_OF_STREAM   256
#define         BUMP_CODE       257
#define         FLUSH_CODE      258
#define         FIRST_CODE      259
#define         UNUSED          -1


typedef struct tag_dictionary
{
	short code_value;
	short parent_code;
	char character;
}dictionary;

int find_child_node(short parent_code,short child_character,dictionary *dict);

//unsigned short decode_string(unsigned short offset,unsigned short code);

void Writelog(char *msg);

//char *CompressionName ="lzw 15 bit Encode";
//char *Usage         ="in-file out-file\n\n";
//this package inlude file:bitio.c/lzw15.c/lzw.h


#define DICT(i) dict[i >> 8][i&0xff]

//char *decode_stack=NULL;

BOOL CompressFile(char * infile,char *outfile)
{
	short character;
	short string_code;
	unsigned short index;
	HANDLE hd;
	BIT_FILE * output;
	FILE * input;
	int ret;

	unsigned short next_code;
	short current_code_bits;
	unsigned short next_bump_code;
	unsigned short i;

	dictionary *dict;

	input = fopen(infile,"rb");
	if(input==NULL)
	{
		fatal_error("Can not open input file");
		return FALSE;
	}
	output =OpenOutputBitFile(outfile);
	if(output ==NULL)
	{
		fatal_error("Can not open output file");
		fclose(input);
		return FALSE;
	 }

	hd=HeapCreate((DWORD)0,TABLE_BANKS*256*sizeof(dictionary),(DWORD)0);
	if(hd==NULL)
	{
		CloseOutputBitFile(output);
		fclose(input);
		return FALSE;
	}

	//if(!InitializeStorage(hd))
	//{
	//	CloseOutputBitFile(output);
	//	fclose(input);
	//	HeapDestroy(hd);
	//	return FALSE;
	//}

	dict=HeapAlloc(hd,HEAP_ZERO_MEMORY,TABLE_BANKS*256*sizeof(dictionary));
	if(dict== NULL)
	{
		CloseOutputBitFile(output);
		fclose(input);
		HeapDestroy(hd);
		return FALSE;
	}
	if(HeapSize(hd,0,dict)<TABLE_BANKS*256*sizeof(dictionary))
	{
		CloseOutputBitFile(output);
		fclose(input);
		HeapDestroy(hd);
		return FALSE;
	}

	//InitializeDictionary();
	for(i=0;i<TABLE_SIZE;i++)
		dict[i].code_value = UNUSED;
	next_code =FIRST_CODE;
	current_code_bits =9;
	next_bump_code =511;

	if((string_code = getc(input)) == EOF)
		string_code = END_OF_STREAM;

	while((character = getc(input))!=EOF)
	{
		ret =find_child_node(string_code,character,dict);
		if(ret<0)
		{
			CloseOutputBitFile(output);
			fclose(input);
			HeapDestroy(hd);
			return FALSE;
		}
		index =(unsigned short)ret;

		if(dict[index].code_value !=-1)
			string_code =dict[index].code_value;
		else
		{
			dict[index].code_value =next_code++;
			dict[index].parent_code=string_code;
			dict[index].character=(char)character;

			OutputBits(output,(unsigned int)string_code,current_code_bits);
			string_code =character;
			if(next_code>MAX_CODE)
			{
				OutputBits(output,(unsigned int)FLUSH_CODE,current_code_bits);

				//InitializeDictionary();
				for(i=0;i<TABLE_SIZE;i++)
					dict[i].code_value = UNUSED;
				next_code =FIRST_CODE;
				current_code_bits =9;
				next_bump_code =511;
			}
			else if(next_code>next_bump_code)
			{
				OutputBits(output,(unsigned int)BUMP_CODE,current_code_bits);
				current_code_bits++;
				next_bump_code<<=1;
				next_bump_code|=1;
			}
		}
	}
	OutputBits(output,(unsigned short)string_code,current_code_bits);
	OutputBits(output,(unsigned short)END_OF_STREAM,current_code_bits);

	CloseOutputBitFile(output);
	fclose(input);
	//ExitLzw(hd);
	HeapDestroy(hd);
	return TRUE;
}

int find_child_node(short parent_code ,short child_character,dictionary *dict)
{
	unsigned short index;
	unsigned short offset;

	index =(child_character <<(BITS-8)) ^parent_code;
	if(index ==0)
		offset =1;
	else
		offset =TABLE_SIZE -index;
	for(;;)
	{

		if(IsBadStringPtr((char *)&dict[index],(UINT)sizeof(short)))
			return -1;
		if(dict[index].code_value ==UNUSED)
			return(int)index;
		if(dict[index].parent_code ==parent_code &&
				dict[index].character ==(char)child_character)
			return(int)index;
		if(index >=offset)
			index =index -offset;
		else
			index=index +TABLE_SIZE-offset;
	}
}

//unsigned short decode_string(unsigned short count,unsigned short code)
//{
//	while(code>255)
//	{
//		decode_stack[count++] =dict[code].character;
//		code =dict[code].parent_code;
//	}
//	decode_stack[count++] =(char)code;
//	return(count);
//}

void Writelog(char *msg)
{
	OFSTRUCT os;
	HFILE hf;
    
    hf=OpenFile("\\sv_com32.log",&os,OF_WRITE);
	if(hf ==HFILE_ERROR)
		hf =OpenFile("\\sv_com32.log",&os,OF_WRITE|OF_CREATE);
	else
		_llseek(hf,0L,SEEK_END);
	_lwrite(hf,msg,strlen(msg));
	_lclose(hf);
	return;
}

short  getmemc(char *buff,int *ylen,int len)
{
	unsigned char ret;
	if(*ylen<len)
	{
		ret =buff[*ylen];
		*ylen =*ylen +1;
	}
	else
		return EOF;
	return ret;
}

BOOL CompressMemFile(char *buff,int len,char *outfile)
{
	short character;
	short string_code;
	unsigned short index;
	HANDLE hd;
	BIT_FILE * output;
	int ylen =0;
	char * input;
	int ret;

	unsigned short next_code;
	short current_code_bits;
	unsigned short next_bump_code;
	unsigned short i;

	dictionary *dict;

	input = buff;
	if(input==NULL||len<0)
	{
		fatal_error("Can not open mem data");
		return FALSE;
	}
	output =OpenOutputBitFile(outfile);
	if(output ==NULL)
	{
		fatal_error("Can not open output file");
		return FALSE;
	}

	hd=HeapCreate((DWORD)0,TABLE_BANKS*256*sizeof(dictionary),(DWORD)0);
	if(hd==NULL)
	{
		CloseOutputBitFile(output);
		return FALSE;
	}

	//if(!InitializeStorage(hd))
	//{
	//	CloseOutputBitFile(output);
	//	HeapDestroy(hd);
	//	return FALSE;
	//}
	dict=HeapAlloc(hd,HEAP_ZERO_MEMORY,TABLE_BANKS*256*sizeof(dictionary));
	if(dict== NULL)
	{
		CloseOutputBitFile(output);
		HeapDestroy(hd);
		return FALSE;
	}
	if(HeapSize(hd,0,dict)<TABLE_BANKS*256*sizeof(dictionary))
	{
		CloseOutputBitFile(output);
		HeapDestroy(hd);
		return FALSE;
	}

	//InitializeDictionary();
	for(i=0;i<TABLE_SIZE;i++)
		dict[i].code_value = UNUSED;
	next_code =FIRST_CODE;
	current_code_bits =9;
	next_bump_code =511;

	if((string_code = getmemc(input,&ylen,len)) == EOF)
		string_code = END_OF_STREAM;
	while((character = getmemc(input,&ylen,len))!=EOF)
	{
		ret =find_child_node(string_code,character,dict);
		if(ret<0)
		{
			CloseOutputBitFile(output);
			HeapDestroy(hd);
			return FALSE;
		}
		index =(unsigned short)ret;

		if(dict[index].code_value !=-1)
			string_code =dict[index].code_value;
		else
		{
			dict[index].code_value =next_code++;
			dict[index].parent_code=string_code;
			dict[index].character=(char)character;

			OutputBits(output,(unsigned int)string_code,current_code_bits);
			string_code =character;
			if(next_code>MAX_CODE)
			{
				OutputBits(output,(unsigned int)FLUSH_CODE,current_code_bits);

				//InitializeDictionary();
				for(i=0;i<TABLE_SIZE;i++)
					dict[i].code_value = UNUSED;
				next_code =FIRST_CODE;
				current_code_bits =9;
				next_bump_code =511;
			}
			else if(next_code>next_bump_code)
			{
				OutputBits(output,(unsigned int)BUMP_CODE,current_code_bits);
				current_code_bits++;
				next_bump_code<<=1;
				next_bump_code|=1;
			}
		}
	}
	OutputBits(output,(unsigned short)string_code,current_code_bits);
	OutputBits(output,(unsigned short)END_OF_STREAM,current_code_bits);

	CloseOutputBitFile(output);
	HeapDestroy(hd);
	return TRUE;
}
