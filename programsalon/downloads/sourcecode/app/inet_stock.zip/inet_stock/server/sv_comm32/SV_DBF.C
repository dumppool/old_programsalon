#include <windows.h>
#include <windowsx.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <math.h>
#include "sv_dbf.h"

#define TRUE  1
#define FALSE 0

void DelayMs(int ms)
{
   Sleep(ms);
}

HFILE OpenDbfBase(char *file_name,int amode)
{
   int try=0;
	HFILE hf;
   OFSTRUCT os;

	hf=OpenFile(file_name, &os, amode|OF_SHARE_DENY_NONE);
   while(hf==-1) {
	  hf=OpenFile(file_name,&os, amode|OF_SHARE_DENY_NONE);
	  try++;
	  if(try==OPEN_RETR)
	  return(-1);
	  DelayMs(OPEN_INTERVAL);
   }
   return(hf);
}

int CloseDbf(int hd)
{
   return(_lclose(hd));
}

int CheckDbf(int hd,DbfStruct *d_info,FieldStruct *f_info,short f_num)
{
   int flen1,flen2;
   short i,rlen,wid;

   _llseek(hd, 0, FILE_BEGIN);
   flen1 =(int)_llseek(hd, 0, FILE_END);
   _llseek(hd, 0, FILE_BEGIN);
   flen2=(int)(*(short *)d_info->rlen)*((int)*(unsigned short *)d_info->recnum)+
	   (int)*(short *)d_info->hlen;
   if((flen1!=flen2)&&(flen1!=flen2+1)) {
		return(DBF_DESTROYED);
   }

   rlen=0;
   for(i=0;i<f_num;i++)
	  rlen+=(short)f_info[i].wid;
   rlen++;

   if (*(short*)d_info->rlen!=rlen) {
	   return(DBF_DESTROYED);
   }
			/* if offset of first Field is not valid */
   if (*(short*)f_info[0].offset!=1) {
	   return(DBF_DESTROYED);
   }

   for(i=0;i<f_num-1;i++) {
	   wid=*(short*)f_info[i+1].offset-*(short*)f_info[i].offset;
	   if (wid!=(short)f_info[i].wid) {
		   return(DBF_DESTROYED);
	   }
   }
   return(SUCCEED);
}

int InitBase(int hd, DbfStruct *BaseInfo,FieldStruct **FldInfo,short *FieldNum)
{
	int ret;
	short wid;
	int i;
	
	_llseek(hd,0l,SEEK_SET);

	if((ret=_lread(hd,BaseInfo,sizeof(DbfStruct)))!=sizeof(DbfStruct)) {
	   return(READ_ERROR);
	}
	if(BaseInfo->id!=0x03 && BaseInfo->id!=0x83) {
	   return(DBF_ERR);
	}

	*FieldNum=(*(short*)(BaseInfo->hlen)-1)/32-1;
				   /**
				exclude one byte of 0x0d and 32 bytes of DBF
				structure.
				**/

	if ((*FldInfo=GlobalAllocPtr(GHND,(*FieldNum)*sizeof(FieldStruct)))==NULL)
		return(ALLOC_ERROR);
	if(_lread(hd,(void*)*FldInfo,sizeof(FieldStruct)*(*FieldNum))
	   !=(UINT)sizeof(FieldStruct)*(*FieldNum)) {
		GlobalFreePtr(*FldInfo);
	   *FldInfo =NULL;
	   return(READ_ERROR);
	}
   /////////////////////
	wid =1;
	for(i =0; i<*FieldNum; i++)
	{
		*(short *)(*FldInfo)[i].offset =wid;
		wid+=(short)(*FldInfo)[i].wid;
	}
	return(SUCCEED);
}

int GetRecNum(int hd)
{
	char c[5];

	_llseek(hd,4L,SEEK_SET);	  
	_lread(hd,c,4);

	return *(int *)c;
}

long GetDbfRecCount(int hf,short hlen,short rlen)
{
	long bytes,total;
	int i=0;
	long rec;
	char tmp[10];
	
	
	total =_llseek(hf,0L,SEEK_END);
	if(total == -1)
		return 0;
	if(total <=hlen)
		return 0;
		
	_llseek(hf,4l,SEEK_SET);	
	do
	{		    
		bytes =_lread(hf,tmp,4);
		if(bytes!=4)
		{
			DelayMs(4);
			_llseek(hf,4l,SEEK_SET);    
			i++;
		}
		
		if(i>5)
			return 0L; 
	}while(bytes !=4);
	
	tmp[4] =0;
	rec =*(int *)tmp;	

    return rec;	
}

int ReadRecord(int hd,int no,short hlen,short rlen,char *rbuff)
{

  _llseek(hd,(int)hlen+(int)rlen*(no-1l),SEEK_SET);
  if(_lread(hd,rbuff,rlen)!=(UINT)rlen)
	 return(READ_ERROR);
  return(SUCCEED);
}

int AppendRecord(int hDbf, DbfStruct *lpDbfInfo, char *lpDbfRecBuf)
{
   unsigned char c[5];
   char cEndOfFile;
   int i;
   int recnum;

   recnum =GetRecNum(hDbf);
//   if (*(short *)lpDbfInfo->recnum==0)
//	  _llseek(hDbf,0l,2);
//   else
//	  _llseek(hDbf,-1l,2);
  
   //if(recnum==0&&_filelength(hDbf)==*(short *)lpDbfInfo->hlen)
   if(recnum==0)
		_llseek(hDbf,0l,2);
   else
	   _llseek(hDbf,-1l,2);

   if(_lwrite(hDbf,lpDbfRecBuf,*(short *)lpDbfInfo->rlen)
       ==(UINT)*(short *)lpDbfInfo->rlen)
   {
	  cEndOfFile=ENDOFFILE;
	  _lwrite(hDbf,&cEndOfFile,1);
	  _llseek(hDbf,4L,0);
	  _lread(hDbf,c,4);
	  (*(int *)c)++;
	  _llseek(hDbf,4L,0);
	  _lwrite(hDbf,c,4);
	  for(i=0;i<4;i++)
	    lpDbfInfo->recnum[i]=c[i];
	  return 0;
   }
   return -1;
}

int WriteRecord(int hd,int no,short hlen,short rlen,char  *rbuff)
{
  _llseek(hd,(long)(hlen+rlen*(no-1l)),FILE_BEGIN);
  if (_lwrite(hd,rbuff,rlen)!=(UINT)rlen)
	 return -1;
  return 0;
}

int FldToString(char *rbuff,FieldStruct *finfo,char *fstr)
{
  short offs,inc;

  offs=*(short *)(finfo->offset);
  if(offs <0 || offs >256)
	return -1;
  inc=0;
  while(rbuff[offs+inc]==CH_SPACE && inc <(short)finfo->wid)
	 inc++;
  strncpy(fstr,&(rbuff[offs+inc]),(short)finfo->wid-inc);
  fstr[(short)finfo->wid-inc]=0;
  return(SUCCEED);
}

int StringToFld(char *fbuff,FieldStruct finfo,char *fstr)
{
   short len,offs;

   len=strlen(fstr);
   if(len>(short)finfo.wid)
	   len =(short)finfo.wid;

   offs=*(short*)finfo.offset;
   while(offs<(*(short*)finfo.offset+(short)finfo.wid-len))
	   fbuff[offs++]=CH_SPACE;
   strncpy(&(fbuff[offs]),fstr,len);
   return(SUCCEED);
}

int EndOfDbf(int hd)
{
   char id;

   _lread(hd,&id,1);
   if (id==ENDOFFILE)
	   return(TRUE);
   return(FALSE);
}

void ErrPrint(char *);
int DbfErrorPrint(int type,char *str,int no)
{
	char temp[256];
	
	switch(type) {
	  case OPEN_ERROR:
		sprintf(temp, "FILE OPEN ERROR: %s!",str);
		break;

	  case ALLOC_ERROR:
		sprintf(temp, "ALLOCATION ERROR: %s!",str);
		break;

	  case DBF_ERR:
		sprintf(temp, "DBF ERROR: name=%s,record=%d",str,no);
		break;

	  case READ_ERROR:
		sprintf(temp,"FILE READ ERROR: %s!",str);
		break;
	  case LOCK_FAILED:
		sprintf(temp, "FILE LOCK ERROR: %s!",str);
		break;

	  case DBF_DESTROYED:
		sprintf(temp, "DBF DESTROYED: name=%s,record=%d!",str,no);
		break;

	  case INIT_DBF_ERROR:
		sprintf(temp, "Initializing DBF Error: name=%s!",str);
		break;

	  default:
		return SUCCEED;
	 }
	ErrPrint(temp); 
	 return(SUCCEED);
}
