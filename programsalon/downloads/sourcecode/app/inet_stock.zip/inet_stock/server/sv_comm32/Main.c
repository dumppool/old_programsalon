/* sv_comm:����ͨѶ�������仯�����������͵�ÿ��client�ˡ����߳�
*  by lgd/Paladin.InetSoft guangzhou��1996.9
*  modify by lym(�޸ĺ�������ȴ��Ըд��ԭ���ߵ�һ����) guangzhou��1997.4-1998
*/
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include "resource.h"
#include "main.h"
#include "pctcp.h"
#include "hq.h"
#include "hqdest.h"
#include "jydest.h"
#include "sv_hq.h"
#include "sv_jy.h"
#include "sv_tcp.h"
#include "zx.h"
#include "data.h"
#include "monitor.h"
#include "rsa.h"

#include "cl_hq.h"
#include "cl_main.h"
#include "cl_data.h"

#define WND_CAPTION	(LPSTR)"����ͨѶ����"
							 
extern CRITICAL_SECTION hqCriticalSection;

LRESULT CALLBACK MainDlgProc(HWND, UINT, WPARAM, LPARAM);

HWND ghWndMain =NULL;
HINSTANCE ghInstance =NULL;

extern MONITOR Monitor;
extern BOOL HqIsRun;

extern long TF_AnaRecvData(int sd);
extern long TF_ScanJyDest(void);


extern DEST_INFO dest_info[];
extern int dest_info_count;
extern int DesInit(void);
extern HINSTANCE hDesDll;

void SetHqUsers(int count);
void SetJyUsers(int count);

extern BOOL fUseJy,fTestJy,fRsa;
extern LPSTR GetError(LPSTR err_prefix);
extern char szNewsPath[128],szNewsSrc[128];

extern int CreateNewsManagerThread(void);

//LONG	g_lNumReaders =-1;
//HANDLE g_hEventDataReady;
//HANDLE g_hSemReaders;

HANDLE g_hEventDataWrite;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hInstPre,
					LPSTR lpszCmdLine, int nCmdShow)
 {
	HWND hwnd;
	FARPROC lpDlgProc;
	
	if(hInstPre)
	{
		hwnd =FindWindow(NULL, WND_CAPTION);
		if(hwnd)
			SetFocus(hwnd);
		return FALSE;
	}
    
	ghInstance =hInstance;

	InitializeCriticalSection(&hqCriticalSection);
	if(!AppInit())
	{
		ErrMsg(NULL, "Ӧ�ó�ʼ��ʧ��!");
		goto appexit;
	}
	
	lpDlgProc =(FARPROC)MakeProcInstance((FARPROC)MainDlgProc, hInstance);
	if(lpDlgProc ==NULL)
	{
		ErrMsg(NULL, "���ܽ����Ի���!");
		goto appexit;
	}
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, lpDlgProc);
	FreeProcInstance(lpDlgProc);
	
appexit:
	AppExit();
	DeleteCriticalSection(&hqCriticalSection);
	
	return 0;
}

FILE *fpMsg =NULL;
BOOL AppInit(void)
{
	SetHandleCount(110);

	GlobalVaryInit();
	
	if(!DestInit())
	{
		ErrMsg(NULL, "����Ŀ���ַ����ʼ��ʧ��!");
		return FALSE;
	}
	if(!JyDestInit())
	{
		ErrMsg(NULL, "����Ŀ���ַ����ʼ��ʧ��!");
		return FALSE;
	}

	if(IsClectRun)
	{
		if(clHqInit() <0)
		{
			ErrMsg(NULL, "���ݲɼ���ʼ��ʧ��!");
			return FALSE;
		}
	}
	else
	{
		if(HqInit() <0)
		{
			ErrMsg(NULL, "�����ʼ��ʧ��!");
			return FALSE;
		}
	}

	if(JyInit() <0)
	{
		ErrMsg(NULL, "���׳�ʼ��ʧ��!");
		//return FALSE;
	}
	if(MonitorInit()<0)
    {
		ErrMsg(NULL,"�û����ӳ�ʼ��ʧ��!");
	}
	if(PCTCPInit() !=0)
	{
		ErrMsg(NULL, "ͨѶ��ʼ��ʧ��!");
		return FALSE;
	}
	return TRUE;
}

void AppExit(void)
{
	static BOOL fExit =FALSE;
	
	if(fExit) return;
	fExit =TRUE;

	if(IsClectRun)	
		clHqExit();
	else	
		HqExit();

	JyExit();
	MonitorExit();
	DestExit();
	JyDestExit();
	PCTCPExit();
}

short total_times =0;
extern int sdHq, sdJy;
extern int BindSocket(HWND);
extern void HqDestSendClose(void);

LRESULT CALLBACK MainDlgProc(HWND hDlg, UINT message,
					WPARAM wParam, LPARAM lParam)
{
	char dt[40];
	DWORD dw;
	char temp[400];
	int sdTmp =-1,sdTmp1;
	int i;
//	static int j=0;
//	static time_t ScanTim=0;

	//HANDLE hThrd;
	//LONG lThreadId;

	switch(message)
	{
		case WM_INITDIALOG:
			remove("\\sv_com32.log");
			SetWindowText(hDlg, WND_CAPTION);
			ghWndMain =hDlg;
			g_hEventDataWrite =CreateEvent(NULL,TRUE,FALSE,NULL);
			_strdate(dt);
			strcat(dt, " ");
			_strtime(&dt[strlen(dt)]);
			SetDlgItemText(hDlg, IDC_STARTTIME, dt);
			SetDlgItemText(hDlg, IDC_STATIC1,"����ʱ��");
			SetDlgItemText(hDlg, IDC_STATIC2,"����״̬");
			SetDlgItemText(hDlg, IDC_STATIC3,"������Ϣ");
			SetDlgItemText(hDlg, IDC_STATIC4,"������Ϣ");
			SetDlgItemText(hDlg, IDC_STATIC5,"�����û�");
			SetDlgItemText(hDlg, IDC_STATIC6,"�����û�");
			SetDlgItemText(hDlg, IDC_STATIC7,"������Ϣ");
			if(BindSocket(hDlg) <0)
			{
				ErrMsg(hDlg, "BindSocketʧ��!");
				EndDialog(hDlg, 0);
				return FALSE;
			}

			ReadySysFile();
			PostMessage(hDlg, WM_HQ_INIT, 0, 0L);

			//if(Monitor.IsRun)
			//	SetTimer(hDlg,1,Monitor.CheckPoint*60*1000,NULL);

			if(fUseJy||fTestJy)
				SetTimer(hDlg,4,9000,NULL);
		return TRUE;
		case WM_TIMER:			
			/*
			if(wParam==1)
			{
				for(j =0; j<dest_info_count; j++)
				{
					lpDestTmp=&dest_info[j];
					if(!lpDestTmp) break;
					if(lpDestTmp->isDead)
						continue;
					if(strlen(lpDestTmp->userID)==0||lpDestTmp->recNum==0)
						continue;

					rtime=WriteUserStatus(lpDestTmp->recNum,
					(int)(difftime(time(NULL),lpDestTmp->startTime)/60),'F',"CHECKPOINT");
					lpDestTmp->startTime=time(NULL);
					if(rtime<=0)
					{
						SendMsg(lpDestTmp->sd,"���ʱ������!");
						HqDestSetDeadByPrt(lpDestTmp);
					}
				}
			}
			*/

			if(wParam ==4)
			{
				//MsgLocal("ɨ�轻���û�...");
				KillTimer(hDlg,4);
				TF_ScanJyDest();
				SetTimer(hDlg,4,500,NULL);
				//MsgLocal("ɨ��ɹ�");
			}
		break;
		case WM_HQ_INIT:
			MsgLocal("��ʼ������...");

			if(fUseJy) DesInit();

			ReadHq(0);
			ReadHq(1);
			CreateLzwMemData(0);
			CreateLzwMemData(1);

			if(IsClectRun)
			{
				if(CreateClectThread()<0)
					ErrMsg(ghWndMain, "CreateClectThreadʧ��!");
			}		
			else
				SetEvent(g_hEventDataWrite);

			//CheckTime();

			if(HqIsRun)
			{
				if(CreateScanDestThread() <0)
					ErrMsg(ghWndMain, "CreateScanDestThreadʧ��!");
			}
			if(fUseJy)
			{
				if(CreateScanJyDestThread() <0)
					ErrMsg(ghWndMain, "CreateScanJyDestThreadʧ��!");
			}
			if(szNewsPath[0]!=0 &&szNewsSrc[0]!=0)
			{
				if(CreateNewsManagerThread()<0)
					ErrMsg(ghWndMain, "Failed to CreateNewsManagerThread!");
			}
			if(fRsa)
				EnableWindow(GetDlgItem(hDlg,IDC_RSA_INIT),TRUE);
			MsgLocal("��ʼ������ɹ�");

			if(HqIsRun)
			{
				sdTmp1 =listen(sdHq,SOMAXCONN);
				if(sdTmp1 ==SOCKET_ERROR)
				{
					ErrMsg(NULL, GetError("����BindSocket:listen()"));
					return -1;
				}
			}
			if(fUseJy)
			{
				sdTmp1=listen(sdJy,SOMAXCONN); //SOMAXCONN);
				if(sdTmp1==SOCKET_ERROR)
					ErrMsg(ghWndMain,GetError("����Main:JY/listen()"));
			}
			break;		
		case WM_UDP_HQ:
			sdTmp =(int)wParam;
			if(!HqIsRun) break;
			switch(lParam)
			{
			case FD_ACCEPT:
				sdTmp1=accept(sdHq, NULL, NULL);
				if(sdTmp1==INVALID_SOCKET)
				{
					ErrMsg(ghWndMain,GetError("����Main:HQ/accept()"));
					break;
				}
				else
				{
					i =WSAAsyncSelect(sdTmp1, hDlg, WM_UDP_HQ, FD_READ);
				}
				//sdTmp1=listen(sdHq, 0);
				//if(sdTmp1==SOCKET_ERROR)
				//	ErrMsg(ghWndMain,GetError("����Main:HQ/listen()"));
				break;
			case FD_READ:
				AnaRecvData(sdTmp,0);
				break;
			}
			break;
		
		case WM_UDP_JY:
			sdTmp =(int)wParam;
			switch(lParam)
			{
			case FD_ACCEPT:
				sdTmp1=accept(sdJy, NULL, NULL);
				if(sdTmp1==INVALID_SOCKET)
				{
					ErrMsg(ghWndMain,GetError("����Main:JY/accept()"));
					break;
				}
				//else
				//{
				//	i =WSAAsyncSelect(sdTmp1, hDlg, WM_UDP_JY, FD_READ);
				//}
				//sdTmp1=listen(sdJy,SOMAXCONN);
				//if(sdTmp1==SOCKET_ERROR)
				//	ErrMsg(ghWndMain,GetError("����Main:JY/listen()"));
				break;
			case FD_READ:
				AnaRecvData(sdTmp,1);
				break;
			}
		break;
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					if(GetFocus() ==GetDlgItem(hDlg, IDL_MSG))
					{
						dw =SendDlgItemMessage(hDlg, IDL_MSG, LB_GETCURSEL, 0, 0L);
						if(dw !=LB_ERR)
						{
							SendDlgItemMessage(hDlg, IDL_MSG, LB_GETTEXT, (int)dw, (LPARAM)(LPSTR)temp);
							MessageBox(hDlg, temp, "����ע��", MB_OK);
						}
					}
				break;
				case IDC_RSA_INIT:
					if(fRsa)
					{
						if(MessageBox(hDlg, "��Ҫ���кܳ�ʱ�䣬��Ҫ������?", WND_CAPTION,
							MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2) ==IDNO)
						break;
						MsgLocal("��ʼ��RSA���ܲ���");
						EnableWindow(GetDlgItem(hDlg,IDC_RSA_INIT),FALSE);
						if(RsaPrepare(SK,PK,R))
						{
							WriteRsaFile(R,PK,SK);
						}
						EnableWindow(GetDlgItem(hDlg,IDC_RSA_INIT),TRUE);
					}
				break;
				case IDCANCEL:
					if(MessageBox(hDlg, "��Ҫ�˳���?", WND_CAPTION,
							MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2) ==IDNO)
						run_cancelled =FALSE;
					else
					{
						run_cancelled =TRUE;
						HqDestSendClose();

						if(fUseJy || fTestJy)
							KillTimer(hDlg,4);

						Sleep(2000);

//						WaitForSingleObject(g_hEventDataWrite,INFINITE);
						CloseHandle(g_hEventDataWrite);

						EndDialog(hDlg, 0);
						if(fUseJy) FreeLibrary(hDesDll);
						ghWndMain =NULL;
						PostQuitMessage(0);   // not used
					}
				break;
			}
		break;
	}
	
	return FALSE;
}

extern void WriteMsg(LPSTR msg);

BOOL ErrMsg(HWND hWnd, LPSTR msg)
{
//	char tmp[256];
	static BOOL msgbox_exist =FALSE;
	DWORD dw;
	
	//WriteMsg(msg);
	//if(ghWndMain)
	//{
		if((dw =SendDlgItemMessage(ghWndMain, IDL_MSG,
				LB_ADDSTRING, 0, (LPARAM)(LPSTR)msg))>1000)
			SendDlgItemMessage(ghWndMain, IDL_MSG,
				LB_RESETCONTENT, 0, (LPARAM)(LPSTR)msg);
		else SendDlgItemMessage(ghWndMain, IDL_MSG,
				LB_SETCURSEL, (int)dw, 0L);
	//}
	//else
	//if(!msgbox_exist)
	//{
	//	msgbox_exist =TRUE;
	//	if(strlen(msg)>=250) *(msg+250) =0;
	//	wsprintf(tmp, "����: %s", msg);
	//	MessageBox(hWnd, tmp, WND_CAPTION, MB_OK|MB_ICONSTOP);
	//	msgbox_exist =FALSE;
	//}

	return FALSE;
}

void ErrPrint(char *msg)
{
	ErrMsg(ghWndMain, msg);
}

void DelSpaces(LPSTR lpstr)
{
	return;
}

BOOL GetInitString(char *Entry, char *Item, char *buf)
{
	GetPrivateProfileString(Entry, Item, "", buf, 256, "sv_com32.ini");
	if(*buf ==0) return FALSE;
	return TRUE;
}

BOOL PutInitString(char *Entry, char *Item, char *buf)
{
	return WritePrivateProfileString(Entry, Item, buf, "sv_com32.ini");
}

void MsgSend(char far *msg)
{
	SetDlgItemText(ghWndMain, IDC_STATUS_SEND, msg);
}

void MsgRecv(char far *msg)
{
	SetDlgItemText(ghWndMain, IDC_STATUS_RECV, msg);
}

void MsgLocal(LPSTR msg)
{
	SetDlgItemText(ghWndMain, IDC_STATE_LOCAL, msg);
}

short date_num =-1, tim =-1;
short CheckTime(void)
{
	char tmp[40];
	LPSTR tok;
	short jys;

	if(date_num <0)
	{
		_strdate(tmp);
		strtok(tmp, "/");
		tok =strtok(NULL, "/");
		date_num =atoi(tok);
	}
	_strtime(tmp);
	MsgLocal(tmp);
	tok =strtok(tmp, ":");
	tim =atoi(tok)*60;
	tim +=atoi(strtok(NULL, ":"));
	if(tim <5 && tim >0) date_num =-1;
	
	for(jys =0; jys <2; jys++)
	{
		if(tim-1 <HqTime[jys].am_min_start
				|| tim >HqTime[jys].pm_min_end
				|| (tim <HqTime[jys].pm_min_start 
					&& tim >HqTime[jys].am_min_end))
		{
			if(HqTime[jys].fRunning ==TRUE)
			{
				HqTime[jys].fRunning =FALSE;
				MsgLocal("Jy is closed");
			}
		}
		else if(HqTime[jys].fRunning ==FALSE)
			HqTime[jys].fRunning =TRUE;	

	}
	return 0;
}

void SetHqUsers(int count)
{
	char tmp[20];

	wsprintf(tmp, "%d", count);
	SetDlgItemText(ghWndMain, IDC_HQUSERS, tmp);
}

void SetJyUsers(int count)
{
	char tmp[20];

	wsprintf(tmp, "%d", count);
	SetDlgItemText(ghWndMain, IDC_JYUSERS, tmp);
}

void GlobalVaryInit(void)
{
	char temp[50];

   	if(GetInitString("GLOBAL", "READDATA", temp))
	{
		if(temp[0] =='Y' || temp[0] =='y')
			gfReadData =TRUE;
		else
			gfReadData =FALSE;
	}
	else PutInitString("GLOBAL", "READDATA", "No");

   	if(GetInitString("GLOBAL", "CLRUN", temp))
	{
		if(temp[0] =='Y' || temp[0] =='y')
			IsClectRun =TRUE;
		else
			IsClectRun =FALSE;
	}
	else PutInitString("GLOBAL", "CLRUN", "No");
}
