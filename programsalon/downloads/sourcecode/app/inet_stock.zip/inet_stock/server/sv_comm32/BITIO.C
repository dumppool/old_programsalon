#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct tag_bit_file
{
	FILE *file;
	unsigned char mask;
	char rack;
	short pacifier_counter;
	char *buffer;
	int len,ylen;
	unsigned short ptr;
}BIT_FILE;

BIT_FILE *OpenInputBitFile(char *filename);
BIT_FILE *OpenOutputBitFile(char *filename);
void OutputBit(BIT_FILE *bit_file,short bit);
void OutputBits(BIT_FILE *bit_file,unsigned int code,short count);
short InputBit(BIT_FILE *bit_file);
unsigned int InputBits(BIT_FILE *bit_file,short count);
void CloseInputBitFile(BIT_FILE *bit_file);
void CloseOutputBitFile(BIT_FILE *bit_file);
void FilePrintBinary(FILE *file,unsigned short code,short bits);

BOOL ErrMsg(HWND hWnd, LPSTR msg);
void fatal_error(char *fmt);

#define		PACIFIER_COUNT	2047
#define   	BUFFER_SIZE 1024*2

void fatal_error(char *fmt)
{
	ErrMsg(NULL,fmt);
}

BIT_FILE *OpenOutputBitFile(char *name)
{
	BIT_FILE *bit_file;

	bit_file=GlobalLock(GlobalAlloc(GHND,sizeof(BIT_FILE)));
	if(bit_file ==NULL)
		return (bit_file);
	bit_file->file =fopen(name,"wb");
	bit_file->rack =0;
	bit_file->mask =0x80;
	bit_file->pacifier_counter =0;

	bit_file->buffer = GlobalLock(GlobalAlloc(GHND,BUFFER_SIZE));
	bit_file->ptr =0;
	return (bit_file);
}

BIT_FILE *OpenInputBitFile(char *name)
{
	BIT_FILE *bit_file;

	bit_file=GlobalLock(GlobalAlloc(GHND,sizeof(BIT_FILE)));
	if(bit_file ==NULL)
		return (bit_file);
	bit_file->file =fopen(name,"rb");
	bit_file->rack =0;
	bit_file->mask =0x80;
	bit_file->pacifier_counter =0;
	return (bit_file);
}

BIT_FILE *OpenInputMemFile(char *name,int len)
{
	BIT_FILE *bit_file;

	bit_file=GlobalLock(GlobalAlloc(GHND,sizeof(BIT_FILE)));
	if(bit_file ==NULL)
		return (bit_file);

	bit_file->file =NULL;

	bit_file->rack =0;
	bit_file->mask =0x80;
	bit_file->pacifier_counter =0;

	bit_file->buffer =name;
	bit_file->len =len;
	bit_file->ylen =0;

	return (bit_file);
}

void CloseOutputBitFile(BIT_FILE *bit_file)
{
  if(bit_file->ptr>0)
  {
    if(fwrite((void *)&bit_file->buffer[0],sizeof(char),bit_file->ptr,
	bit_file->file)!=bit_file->ptr)
      fatal_error("Fatal error in write CloseBitFile!\n");
    bit_file->ptr=0;
  }
  if(bit_file->mask !=0x80)
	   if(putc(bit_file->rack,bit_file->file) !=bit_file->rack)
			fatal_error("Fatal error in CloseBitFile!\n");
  fclose(bit_file->file);

  if(bit_file->buffer!=NULL)
	  GlobalFree(GlobalHandle(bit_file->buffer));
  GlobalFree(GlobalHandle(bit_file));
}

void CloseInputBitFile(BIT_FILE *bit_file)
{
	fclose(bit_file->file);
	GlobalFree(GlobalHandle(bit_file));
}

void CloseInputMenFile(BIT_FILE *bit_file)
{
	GlobalFree(GlobalHandle(bit_file));
}

void OutPutBit(BIT_FILE *bit_file,short bit)
{
	if(bit)
		bit_file->rack |=bit_file->mask;
	bit_file->mask >>=1;
	if(bit_file->mask==0)
	{

		if(bit_file->ptr<BUFFER_SIZE)
		{
			bit_file->buffer[bit_file->ptr]=bit_file->rack;
			bit_file->ptr++;
		}
		if(bit_file->ptr == BUFFER_SIZE)
		{
			if(fwrite((void *)&bit_file->buffer[0],sizeof(char),bit_file->ptr,
					bit_file->file)!=bit_file->ptr)
				fatal_error("Fatal error in write CloseBitFile!\n");
			bit_file->ptr=0;
		}

		bit_file->rack =0;
		bit_file->mask =0x80;
	}
}

void OutputBits(BIT_FILE *bit_file,unsigned int code,short count)
{
	unsigned int mask;

	mask =1 << (count -1);
	while(mask!=0)
	{
		if( mask & code)
			bit_file->rack |=bit_file->mask;
		bit_file->mask >>=1;
		if(bit_file->mask ==0)
		{
		      if(bit_file->ptr<BUFFER_SIZE)
		      {
				bit_file->buffer[bit_file->ptr]=bit_file->rack;
				bit_file->ptr++;
		      }
		      if(bit_file->ptr ==BUFFER_SIZE)
		      {
				if(fwrite((void *)&bit_file->buffer[0],sizeof(char),bit_file->ptr,
					bit_file->file)!=bit_file->ptr)
				{
					fatal_error("Fatal error in write OutputBits");
				}
				bit_file->ptr=0;
		      }

		      bit_file->rack=0;
		      bit_file->mask=0x80;
		}
		mask >>=1;
	}
}

short InputMenBit(BIT_FILE *bit_file)
{
	short value;

	if(bit_file->mask == 0x80)
	{
		bit_file->rack =bit_file->buffer[bit_file->ylen++];	//getc(bit_file->file);
		if(bit_file->rack ==EOF)
			fatal_error("Fatal error in InputBit!\n");
	}
	value=bit_file->rack &bit_file->mask;
	bit_file->mask >>=1;
	if(bit_file->mask==0)
		bit_file->mask =0x80;
	return (value ? 1:0);
}

unsigned int InputBits(BIT_FILE *bit_file,short bit_count)
{
	unsigned int mask;
	unsigned int return_value;

	mask =1 <<(bit_count -1);
	return_value =0;
	while(mask !=0)
	{
		if(bit_file->mask ==0x80)
		{
			bit_file->rack =bit_file->buffer[bit_file->ylen++]; //getc(bit_file->file);
			if(bit_file->rack==EOF)
				fatal_error("Fatal error in InputBit!\n");
		}
		if(bit_file->rack&bit_file->mask)
			return_value|=mask;
		mask>>=1;
		bit_file->mask>>=1;
		if(bit_file->mask ==0)
			bit_file->mask =0x80;
	}
	return (return_value);
}

void FilePrintBinary(FILE *file,unsigned short code,short bits)
{
	unsigned short mask;

	mask =1<<(bits-1);
	while(mask!=0)
	{
		if(code&mask)
			fputc('1',file);
		else
			fputc('0',file);
		mask >>=1;
	}
}

