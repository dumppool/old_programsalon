#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "resource.h"
#include "main.h"
#include "pctcp.h"

#include "hq.h"
#include "sv_hq.h"

#include "hqdest.h"
#include "jydest.h"
#include "sv_jy.h"
#include "sv_tcp.h"
#include "monitor.h"
#include "lzw.h"
#include "rsa.h"

#include "zlib.h"


extern BOOL fUseJy, gfUseThrd;

int sdHq =-1, sdJy =-1;
extern HFILE hfZx;

#define WSA_MAKEWORD(x,y)       ((y) * 256 + (x))

int PROTO_USE =PROTO_TCP;
BOOL gfReadData =FALSE;
BOOL running =FALSE, run_cancelled =FALSE;
BOOL FileTranLock=FALSE;

extern MONITOR Monitor;
extern char ZxDataFile[128], szDataPath[128],HqDataPath[128];
extern char szNewsPath[128],szNewsSrc[128];
extern int check_socket_status(int sd);

FILE *fp;
int gnDestCount =0;
long TF_SendBuff(HANDLE phMem);
BOOL IsZsRec(int, short);

extern int Jy_SendRet(int sd, char, char, int);
extern void JyDest_Exit(int sd);

JUNK_PACK JunkPack[MAX_JUNK_PACK_COUNT];

typedef unsigned char uchar;
typedef int (CALLBACK* lpfnDES_INIT)(uchar *);
typedef int (CALLBACK* lpfnDES_ECB3)(uchar *,uchar *);
HINSTANCE hDesDll;
lpfnDES_INIT desinit;
lpfnDES_ECB3 ecbdecode;

void WriteMsg(LPSTR msg)
{                
	if(fp) fputs(msg, fp);
}

BOOL fPctcpInited =FALSE;

int PCTCPInit(void)
{
	int ret;

	WSADATA WSAData;

	fPctcpInited =TRUE;
	ret = WSAStartup(0x0101, &WSAData);
	sdHq =sdJy =-1;
	if (ret != 0)
	{
		ErrMsg(ghWndMain, GetError("����WSAStartup()")); 
		return -1;
	}        
	return 0;
}

int PCTCPClose(void)
{
	static BOOL fClosed =FALSE;
	int ret;
	
	if(!fPctcpInited) return 0;

	if(fClosed ==TRUE) return 0;
	fClosed =TRUE;

	WSACancelBlockingCall();
	if(sdHq !=-1)
	{
		closesocket(sdHq);
		sdHq =-1;
    }
	if(sdJy !=-1)
	{
		closesocket(sdJy);
		sdJy =-1;
    }
	ret = WSACleanup();
	if (ret == SOCKET_ERROR && h_errno == WSAEINPROGRESS)
	{
		return -1;
	}
	return 0;
}
		
int PCTCPExit(void)
{
	static BOOL fExit =FALSE;
	
	if(fExit ==TRUE) return 0;
	fExit =TRUE;    
	PCTCPClose();
	
	if(fp) fclose(fp);
	return 0;
}

BOOL can_read =TRUE;

int PCTCPStop(void)
{
	run_cancelled =TRUE;
	can_read =FALSE;
	
	return 0;
}

void PCTCPPause(BOOL fPause)
{
	can_read =!fPause;
}                  

//// used for server or broadcast client
int BindSocket(HWND hWnd)
{
	struct sockaddr_in local;
	int iSockType;
    int ret;
//    long lret;       
    int hSock;
    
	memset(&local, '\0', sizeof (local));
	iSockType = SOCK_STREAM;

	local.sin_family = PF_INET;
	local.sin_port = htons((u_short)PORT_HQ);
	//local.sin_addr.s_addr =INADDR_ANY;//BROADCAST;
    
	hSock = socket(PF_INET, iSockType, 0); 
	if (hSock == INVALID_SOCKET) 
	{
		ErrMsg (hWnd, GetError("����BindSocket:socket()"));
		return -1;
	}
    
	ret = bind(hSock, (struct sockaddr FAR *) &local, sizeof(local));
	if (ret == SOCKET_ERROR)
	{
		ErrMsg(hWnd, GetError("����BindSocket:bind()")); 
		return -1;
	}
    
	/*if(PROTO_USE ==PROTO_TCP)
	{
		lret = 1L;
		ioctlsocket(hSock, FIONBIO, (u_long FAR *) &lret); 
	}
	*/
	sdHq =hSock;

	ret =WSAAsyncSelect(sdHq, hWnd, WM_UDP_HQ, FD_ACCEPT); //FD_READ|
	if(ret <0)
	{
		ErrMsg(hWnd, GetError("����BindSocket:asyncselect"));
		return -1;
	}
	
//	ret =listen(sdHq, SOMAXCONN);
//	if(ret ==SOCKET_ERROR)
//	{
//		ErrMsg(NULL, GetError("����BindSocket:listen()"));
//		return -1;
//	}

	local.sin_port = htons((u_short)PORT_JY);
	hSock = socket(PF_INET, iSockType, 0); 
	if (hSock == INVALID_SOCKET) 
	{
		ErrMsg (hWnd, GetError("����BindSocket:socket()1"));
		return -1;
	}
    
	ret = bind(hSock, (struct sockaddr FAR *) &local, sizeof(local));
	if (ret == SOCKET_ERROR)
	{
		ErrMsg(hWnd, GetError("����BindSocket:bind()1")); 
		return -1;
	}

	//if(PROTO_USE ==PROTO_TCP)
	//{
	//	lret = 1L;
	//	ioctlsocket(hSock, FIONBIO, (u_long FAR *) &lret); 
	//}

	sdJy =hSock;
	ret =WSAAsyncSelect(sdJy, hWnd, WM_UDP_JY, FD_ACCEPT|FD_READ); //FD_READ|
	if(ret <0)
	{
		ErrMsg(hWnd, GetError("����BindSocket:asyncselect1"));
		return -1;
	}
	
//	ret =listen(sdJy, 0);
//	if(ret ==SOCKET_ERROR)
//	{
//		ErrMsg(NULL, GetError("����BindSocket:listen()"));
//		return -1;
//	}
	return 0;
}

int DesInit(void)
{
	hDesDll = LoadLibrary("DES3W32.DLL");
	if(hDesDll==NULL)
	{
		ErrMsg(ghWndMain, "can not load DES dll"); 
		return -1;
	}
	desinit= (lpfnDES_INIT)GetProcAddress(hDesDll,"desinit");
	ecbdecode =(lpfnDES_ECB3)GetProcAddress(hDesDll,"ecbdecode");
	if(!desinit||!ecbdecode)
	{
		ErrMsg(ghWndMain, "can not load DES FUNC"); 
		FreeLibrary(hDesDll);
		return -1;
	}
	return 0;
}

#define         DATA_START_SIGN         -16
 
typedef struct tag_RECV_PARA
{
	int sd;
	int len;
	char *para;
	HANDLE hThread;
}RECV_PARA, *LPRECV_PARA;

long TF_ReadHq(HANDLE hMem)
{
	int sd,len;
    char *RecvBuf;
	struct sockaddr_in dest;
    DEST_INFO *lpDest;

	int len1,ret;
	BYTE FAR *lpTmp;

	HANDLE hThrd =NULL;
	LPRECV_PARA lpRecvPara =NULL;

	lpRecvPara =GlobalLock(hMem);
	if(lpRecvPara ==NULL)
	{
		ErrMsg(ghWndMain, "����TF_ReadHq:Ŀ����Ϣָ��Ϊ��!");
		goto thread_exit;
	}
	
	len1 = sizeof(dest);
	sd =lpRecvPara->sd;
	len =lpRecvPara->len;
	RecvBuf =lpRecvPara->para;

	if(len <=0)
	{
		ErrMsg(ghWndMain,"���ݳ��ȴ�1");
		goto thread_exit;
	}
		
	lpTmp =&RecvBuf[0];
	
	if(strncmp(HQ00_HEAD, RecvBuf, strlen(HQ00_HEAD)) ==0)
	{
		MsgRecv("����00");
		if(UDP_Server_Send_Hq01(sd, &RecvBuf[strlen(HQ00_HEAD)],
							(struct sockaddr* )&dest)<0)
		{
			SendMsg(sd,"��������00��");
		}
	}       
	else if(strncmp(GRA00_HEAD, lpTmp, strlen(GRA00_HEAD)) ==0)
	{
		MsgRecv("��ʱͼ00");
		UDP_Server_Send_Gra01(sd, &RecvBuf[strlen(GRA00_HEAD)],
				(struct sockaddr *)&dest);
	}
	else if(strncmp(HQREF_HEAD, lpTmp, strlen(HQREF_HEAD)) ==0)
	{
		MsgRecv("���ݲɼ�����Ϣ");
		//Data_RefHq(lpTmp+strlen(HQREF_HEAD));
	}
	else if(strncmp(CLNT_EXIT, lpTmp, strlen(CLNT_EXIT)) ==0)
	{
		MsgRecv("�˳�");
		HqDestStopBySd(sd);
	}
	else if(!strncmp(ZX_HEAD, lpTmp, strlen(ZX_HEAD)))
	{
		MsgRecv("��Ѷ");
		UDP_Server_Send_Zx(sd, lpTmp+strlen(ZX_HEAD), (struct sockaddr *)&dest);
	}
	else if(!strncmp(DATA_DAY_HEAD, lpTmp, strlen(DATA_DAY_HEAD)))
	{
		MsgRecv("����");
		SendDataDay(sd, lpTmp+strlen(DATA_DAY_HEAD), (struct sockaddr *)&dest);
	}
	else if(!strncmp(GETZQMC_HEAD, lpTmp, strlen(GETZQMC_HEAD)))
	{
		MsgRecv("��Ʊ����");
		UDP_Server_Send_GetZqmc(sd, lpTmp+strlen(GETZQMC_HEAD), (struct sockaddr *)&dest);
	}
	else if(!strncmp(HQ_CHKUSR_HEAD, lpTmp, strlen(HQ_CHKUSR_HEAD)))
	{
		MsgRecv("Ч�������û�");
		UDP_Server_Send_HqChkUsr(sd, lpTmp+strlen(HQ_CHKUSR_HEAD), (struct sockaddr *)&dest);
	}
	else if(!strncmp(STOCK_INFO_HEAD,lpTmp, strlen(STOCK_INFO_HEAD)))
	{
		MsgRecv("��������");
        UDP_Send_File(sd,(FILE_INFO_FRAME *)(lpTmp+strlen(STOCK_INFO_HEAD)));
	}
	else if(!strncmp("SETENV",lpTmp,6))
	{
		if(Monitor.IsRun)
		{
            lpDest =GetDestBySd(sd);
			if(lpDest!=NULL)
			{
				MsgRecv("��������");
				ret =SetUserEnv(lpDest->recNum,(TCP_FRAME_HQ_ENV *)lpTmp,len);
				if(ret ==SET_SUCC)
					SendMsg(sd,"�޸������û�����ɹ�");
				if(ret ==SET_PWD_ERROR)
					SendMsg(sd,"�����ԭ�����,�����޸������û�����");
				if(ret ==SET_DATA_ERROR)
					SendMsg(sd,"�������������,�����޸������û�����");
				if(ret ==SET_SYS_ERROR)
					SendMsg(sd,"����ϵͳ����,�����޸������û�����");
			}
			else
			{
				SendMsg(sd,"�û���¼���󣬲����޸������û�����");
			}
		}
	}
	else
	{
		SendMsg(sd,"δʶ�������ݰ�");
    }
thread_exit:
	if(lpRecvPara!=NULL)
	{
		hThrd =lpRecvPara->hThread;
		GlobalFreePtr(lpRecvPara->para);
		GlobalFreePtr(lpRecvPara);
	}
	if(hThrd!=NULL)
		CloseHandle(hThrd);
	ExitThread(0);
	return 0;
}

int AnaRecvData(int sd,int type)
{
	short prt,len,try_times,dataNum;
	char temp[MAX_RECV_BUF_SIZE+1];  
	char ReadBuf[MAX_RECV_BUF_SIZE+1];
	struct sockaddr_in dest;
	int len1,i;

    prt=len=try_times=dataNum=0;
	memset((char *)&temp[0],0,MAX_RECV_BUF_SIZE*sizeof(char));
	
	len = recvfrom(sd,(char *) temp,sizeof(temp),
			0, (struct sockaddr *) &dest, (int FAR *) &len1);

	if (len == SOCKET_ERROR) 
	{
		MessageBeep(0);
		return -1;
	}
	
	if(len <=0)
	{
        ErrMsg(ghWndMain,"�������ݳ���С����");
		return -1;
	}

    while(prt<len)
    {
		if(temp[prt]!=DATA_START_SIGN)
		{
			for(i=0;i<MAX_JUNK_PACK_COUNT;i++)
			{
				if(JunkPack[i].sd==sd)
					break;
			}	
			if(JunkPack[i].sd==sd&&JunkPack[i].junk[0]==DATA_START_SIGN)
			{
				while(JunkPack[i].len<1+sizeof(short))
				{
					JunkPack[i].junk[JunkPack[i].len]=temp[prt];
					JunkPack[i].len++;						
					prt++;
					if(prt>=len)
						return 0;
				}
				if(JunkPack[i].len+(len-prt)>=*(short*)&JunkPack[i].junk[1]+3)	
				{
					memcpy(&JunkPack[i].junk[JunkPack[i].len],&temp[prt],
						*(short*)&JunkPack[i].junk[1]-(JunkPack[i].len-3));
					prt+=*(short*)&JunkPack[i].junk[1]-(JunkPack[i].len-3);
					memset(&ReadBuf[0],0,MAX_RECV_BUF_SIZE);
					memcpy(&ReadBuf[0],&JunkPack[i].junk[1+sizeof(short)],
						*(short*)&JunkPack[i].junk[1]);
					dataNum=*(short*)&JunkPack[i].junk[1];
					memset(&JunkPack[i],0,sizeof(JUNK_PACK));						
				}
				else
				{
					memcpy(&JunkPack[i].junk[JunkPack[i].len],&temp[prt],
						len-prt);
					JunkPack[i].len+=len-prt;
					return 0;
				}
			}
			else
			{
//				ErrMsg(ghWndMain,"���������ݰ�");
				return -1;
			}
		}                       
		else
		{
			if(prt+1+2>=len)
			{
				do
				{
					for(i=0;i<MAX_JUNK_PACK_COUNT;i++)
					{
						if(JunkPack[i].sd==0||
								difftime(time(NULL),JunkPack[i].ltime)>MAX_JUNK_VALID_TIME)
							break;
					}
					ShoutBlockingHook();						
				}while(i>=MAX_JUNK_PACK_COUNT);

				JunkPack[i].sd=sd;
				JunkPack[i].ltime=time(NULL);
				memcpy(&JunkPack[i].junk[JunkPack[i].len],
					&temp[prt],len-prt);
				JunkPack[i].len=len-prt;
				return 0;
			}
			dataNum=*(short *)&temp[prt+1];
			if(dataNum<=0)
			{
				ErrMsg(ghWndMain,"���ݳ��ȴ�");
				return -1;
			}
			if(prt+1+2+dataNum>len)
			{
				do
				{
					for(i=0;i<MAX_JUNK_PACK_COUNT;i++)
					{
						if(JunkPack[i].sd==0||
								difftime(time(NULL),JunkPack[i].ltime)>MAX_JUNK_VALID_TIME)
							break;
					}
					if(i>=MAX_JUNK_PACK_COUNT)
						ShoutBlockingHook();						
				}while(i>=MAX_JUNK_PACK_COUNT);

				JunkPack[i].sd=sd;
				JunkPack[i].ltime=time(NULL);
				memcpy(&JunkPack[i].junk[JunkPack[i].len],
					&temp[prt],len-prt);
				JunkPack[i].len=len-prt;
				return 0;
			}
			else
			{
				memset(&ReadBuf[0],0,MAX_RECV_BUF_SIZE);
				memcpy(&ReadBuf[0],&temp[prt+1+sizeof(short)],dataNum);
				prt+=1+sizeof(short)+dataNum;
			}
		}       
	
		if(type==0)
			UDP_ReadHq(sd,&ReadBuf[0],(int )dataNum,dest);
		else
			UDP_ReadJy(sd,&ReadBuf[0],(int )dataNum,dest);
		dataNum=0;
	
		if(prt>=len)
		{
			dataNum=0;
			return 0;               
		}       
    }

    return 0;        
}

long TF_AnaRecvData(int sd)
{
	short prt,len,try_times,dataNum;
	char temp[MAX_RECV_BUF_SIZE+1];  
	char ReadBuf[MAX_RECV_BUF_SIZE+1];
	struct sockaddr_in dest;
	int len1,i;
	int type =0;

    prt=len=try_times=dataNum=0;
	memset((char *)&temp[0],0,MAX_RECV_BUF_SIZE*sizeof(char));
	
	len = recvfrom(sd,(char *) temp,sizeof(temp),
			0, (struct sockaddr *) &dest, (int FAR *) &len1);

	if (len == SOCKET_ERROR) 
	{
		MessageBeep(0);
		return -1;
	}
	
	if(len <=0)
	{
        ErrMsg(ghWndMain,"�������ݳ���С����");
		return -1;
	}

    while(prt<len)
    {
		if(temp[prt]!=DATA_START_SIGN)
		{
			for(i=0;i<MAX_JUNK_PACK_COUNT;i++)
			{
				if(JunkPack[i].sd==sd)
					break;
			}	
			if(JunkPack[i].sd==sd&&JunkPack[i].junk[0]==DATA_START_SIGN)
			{
				while(JunkPack[i].len<1+sizeof(short))
				{
					JunkPack[i].junk[JunkPack[i].len]=temp[prt];
					JunkPack[i].len++;						
					prt++;
					if(prt>=len)
						return 0;
				}
				if(JunkPack[i].len+(len-prt)>=*(short*)&JunkPack[i].junk[1]+3)	
				{
					memcpy(&JunkPack[i].junk[JunkPack[i].len],&temp[prt],
						*(short*)&JunkPack[i].junk[1]-(JunkPack[i].len-3));
					prt+=*(short*)&JunkPack[i].junk[1]-(JunkPack[i].len-3);
					memset(&ReadBuf[0],0,MAX_RECV_BUF_SIZE);
					memcpy(&ReadBuf[0],&JunkPack[i].junk[1+sizeof(short)],
						*(short*)&JunkPack[i].junk[1]);
					dataNum=*(short*)&JunkPack[i].junk[1];
					memset(&JunkPack[i],0,sizeof(JUNK_PACK));						
				}
				else
				{
					memcpy(&JunkPack[i].junk[JunkPack[i].len],&temp[prt],
						len-prt);
					JunkPack[i].len+=len-prt;
					return 0;
				}
			}
			else
			{
				ErrMsg(ghWndMain,"���������ݰ�");
				return -1;
			}
		}                       
		else
		{
			if(prt+1+2>=len)
			{
				do
				{
					for(i=0;i<MAX_JUNK_PACK_COUNT;i++)
					{
						if(JunkPack[i].sd==0||
								difftime(time(NULL),JunkPack[i].ltime)>MAX_JUNK_VALID_TIME)
							break;
					}
					if(i>=MAX_JUNK_PACK_COUNT)
						ShoutBlockingHook();						
				}while(i>=MAX_JUNK_PACK_COUNT);

				JunkPack[i].sd=sd;
				JunkPack[i].ltime=time(NULL);
				memcpy(&JunkPack[i].junk[JunkPack[i].len],
					&temp[prt],len-prt);
				JunkPack[i].len=len-prt;
				return 0;
			}
			dataNum=*(short *)&temp[prt+1];
			if(dataNum<=0)
			{
				ErrMsg(ghWndMain,"���ݳ��ȴ�");
				return -1;
			}
			if(prt+1+2+dataNum>len)
			{
				do
				{
					for(i=0;i<MAX_JUNK_PACK_COUNT;i++)
					{
						if(JunkPack[i].sd==0||
								difftime(time(NULL),JunkPack[i].ltime)>MAX_JUNK_VALID_TIME)
							break;
					}
					if(i>=MAX_JUNK_PACK_COUNT)
						ShoutBlockingHook();						
				}while(i>=MAX_JUNK_PACK_COUNT);

				JunkPack[i].sd=sd;
				JunkPack[i].ltime=time(NULL);
				memcpy(&JunkPack[i].junk[JunkPack[i].len],
					&temp[prt],len-prt);
				JunkPack[i].len=len-prt;
				return 0;
			}
			else
			{
				memset(&ReadBuf[0],0,MAX_RECV_BUF_SIZE);
				memcpy(&ReadBuf[0],&temp[prt+1+sizeof(short)],dataNum);
				prt+=1+sizeof(short)+dataNum;
			}
		}       
	
		UDP_ReadHq(sd,&ReadBuf[0],(int )dataNum,dest);
		dataNum=0;
	
		if(prt>=len)
		{
			dataNum=0;
			return 0;               
		}       
    }

    return 0;        
}


int UDP_ReadHq(int sd,char * RecvBuf,int len,struct sockaddr_in dest)
{
	int len1,ret;
	BYTE FAR *lpTmp;
    DEST_INFO *lpDest;
									
	len1 = sizeof(dest);
	
	if(len <=0)
	{
		ErrMsg(ghWndMain,"���ݳ��ȴ�1");
		return -1;
	}
		
	lpTmp =&RecvBuf[0];
	
	if(strncmp(HQ00_HEAD, RecvBuf, strlen(HQ00_HEAD)) ==0)
	{
		MsgRecv("����00");
		ret =UDP_Server_Send_Hq01(sd, &RecvBuf[strlen(HQ00_HEAD)],
							(struct sockaddr* )&dest);
		//if(ret <0)
		//{
		//	SendMsg(sd,"��������00��");
		//	return -1;
		//}
	}       
	else if(strncmp(XHQ00_HEAD, RecvBuf, strlen(XHQ00_HEAD)) ==0)
	{
		MsgRecv("����00");

		ret =Send_Hq01(sd, &RecvBuf[strlen(XHQ00_HEAD)],
							(struct sockaddr* )&dest);
		if(ret <0)
		{
			SendMsg(sd,"��������00��");
			return -1;
		}
	}       
	else if(strncmp(GRA00_HEAD, lpTmp, strlen(GRA00_HEAD)) ==0)
	{
		MsgRecv("��ʱͼ00");		

		ret =UDP_Server_Send_Gra01(sd, &RecvBuf[strlen(GRA00_HEAD)],
				(struct sockaddr *)&dest);
        if(ret <0)
			SendMsg(sd,"������ʱͼ00��");
	}
	else if(strncmp(XGRA00_HEAD, lpTmp, strlen(GRA00_HEAD)) ==0)
	{
		Send_Gra01(sd, &RecvBuf[strlen(XGRA00_HEAD)],
				(struct sockaddr *)&dest);
	}
	else if(strncmp(HQREF_HEAD, lpTmp, strlen(HQREF_HEAD)) ==0)
	{
		MsgRecv("���ݲɼ�����Ϣ");
		//Data_RefHq(lpTmp+strlen(HQREF_HEAD));
	}
	else if(strncmp(CLNT_EXIT, lpTmp, strlen(CLNT_EXIT)) ==0)
	{
		MsgRecv("�˳�");
		HqDestStopBySd(sd);
	}
	else if(!strncmp(ZX_HEAD, lpTmp, strlen(ZX_HEAD)))
	{
		MsgRecv("��Ѷ");
		UDP_Server_Send_Zx(sd, lpTmp+strlen(ZX_HEAD), (struct sockaddr *)&dest);
	}
	else if(!strncmp(DATA_DAY_HEAD, lpTmp, strlen(DATA_DAY_HEAD)))
	{
		SendDataDay(sd, lpTmp+strlen(DATA_DAY_HEAD), (struct sockaddr *)&dest);
	}
	else if(!strncmp(DAY_DATA_HEAD, lpTmp, strlen(DAY_DATA_HEAD)))
	{
		SendDayData(sd, lpTmp+strlen(DAY_DATA_HEAD), (struct sockaddr *)&dest);
	}
	else if(!strncmp(GETZQMC_HEAD, lpTmp, strlen(GETZQMC_HEAD)))
	{
		UDP_Server_Send_GetZqmc(sd, lpTmp+strlen(GETZQMC_HEAD), (struct sockaddr *)&dest);
	}
	else if(!strncmp(HQ_CHKUSR_HEAD, lpTmp, strlen(HQ_CHKUSR_HEAD)))
	{
		MsgRecv("Ч�������û�");
		UDP_Server_Send_HqChkUsr(sd, lpTmp+strlen(HQ_CHKUSR_HEAD), (struct sockaddr *)&dest);
	}
	else if(!strncmp(STOCK_INFO_HEAD,lpTmp, strlen(STOCK_INFO_HEAD)))
	{
		MsgRecv("��������");
        UDP_Send_File(sd,(FILE_INFO_FRAME *)(lpTmp+strlen(STOCK_INFO_HEAD)));
	}
	else if(!strncmp("SETENV",lpTmp,6))
	{
		if(Monitor.IsRun)
		{
            lpDest =GetDestBySd(sd);
			if(lpDest!=NULL)
			{
				MsgRecv("��������");
				ret =SetUserEnv(lpDest->recNum,(TCP_FRAME_HQ_ENV *)lpTmp,len);
				if(ret ==SET_SUCC)
					SendMsg(sd,"�޸������û�����ɹ�");
				if(ret ==SET_PWD_ERROR)
					SendMsg(sd,"�����ԭ�����,�����޸������û�����");
				if(ret ==SET_DATA_ERROR)
					SendMsg(sd,"�������������,�����޸������û�����");
				if(ret ==SET_SYS_ERROR)
					SendMsg(sd,"����ϵͳ����,�����޸������û�����");
			}
			else
			{
				SendMsg(sd,"�û���¼���󣬲����޸������û�����");
			}
		}
	}
	else
	{
		SendMsg(sd,"δʶ�������ݰ�");
    }
	return 0;
}

extern short date_num;
int UDP_Server_Send_Hq00(int sd, int jys, struct sockaddr *lpdest)
{
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	int len;
	time_t ltime;
	
	memset(&SendBuff[0],0, sizeof(SendBuff));
	strcpy(SendBuff, HQ00_HEAD);
	len =strlen(HQ00_HEAD)+sizeof(short);
	
	SendBuff[len++] =(BYTE)jys;
	*(short *)&SendBuff[len] =HqData[jys].recCount;
	len +=sizeof(short);
	memcpy(&SendBuff[len], &HqTime[jys], sizeof(HqTime[jys])-sizeof(BOOL));
	len +=sizeof(HqTime[jys])-sizeof(BOOL);
	time(&ltime);
	memcpy(&SendBuff[len], &ltime, sizeof(ltime));
	len +=sizeof(ltime);
	SendBuff[len++] =(BYTE)date_num;
	*(short *)&SendBuff[strlen(HQ00_HEAD)] =len;
	return UDP_SendBuff("����00", sd, SendBuff, len, NULL);
}

int UDP_Server_Send_Hq01(int sd, LPSTR lpTmp, struct sockaddr *lpdest)
{
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	short jys, recCount, recNum, sendCount, sendCount1, sendNum;
	short recList[MAX_PARA_COUNT+1];
	short i, j, len, len1;
	BYTE client_version;
	BOOL fRefresh, fSel, fFirstTime;
	
	memset(&SendBuff[0],0, sizeof(SendBuff));

	client_version =*lpTmp++;
	if(client_version <SERVER_VERSION)
	{
		SendMsg(sd, "�汾��!");
		return 0;
	}
	jys =*lpTmp++;
	fFirstTime =(BOOL)*lpTmp++;
	if(fFirstTime)
	{
		if(UDP_Server_Send_Hq00(sd, jys, lpdest)<0)
			return 0;
	}
	fRefresh =*lpTmp++;
	fSel =*lpTmp++;
	strcpy(SendBuff, HQ01_HEAD); 
	len =strlen(HQ01_HEAD)+sizeof(short);
	SendBuff[len++] =(BYTE)jys;
	SendBuff[len++] =(BYTE)fRefresh;
	SendBuff[len++] =(BYTE)fSel;
	len1 =len;
	recCount =*(short *)lpTmp;
	if(recCount <=0 || recCount >MAX_PARA_COUNT) return -1;
	lpTmp +=2;
	*(short *)&SendBuff[len] =0;
	len +=sizeof(short);
	
	memset(recList, 0, sizeof(short)*MAX_PARA_COUNT);
	recList[0] =recCount;

	if(!fSel)
	{
		recNum =*(short *)lpTmp;
		if(recNum >=HqData[jys].recCount)
		{
			ErrMsg(ghWndMain,"����Send_Hq01����¼��Ŵ�����������");
			return -1;
		}

		if(recNum <0)
		{
			ErrMsg(ghWndMain,"����Send_Hq01����¼���С����");
			return -1;
		}

		lpTmp+=2;
		//����Ŵ�
		if(recNum +recCount-1 >=HqData[jys].recCount)
		{
			recCount =HqData[jys].recCount -recNum;
			recList[0] =recCount;
		}
		for(i =0; i<recCount; i++)
			recList[i+1] =recNum+i;
	}
	else            
	{
		memcpy(&recList[1], lpTmp, sizeof(short)*recCount);
		lpTmp +=sizeof(short)*recCount;
	}
///////////////
if(!fFirstTime)	goto check_dest;

	sendCount1 =0;
	for(i =0; i <=recCount/MAX_HQ_SEND_COUNT; i++)
	{
		sendCount =MAX_HQ_SEND_COUNT;
		recNum =i*MAX_HQ_SEND_COUNT;
		if(recNum+sendCount >recCount)
			sendCount =recCount-recNum;
		for(j =0; j<sendCount; j++)
		{
			sendNum =recList[1+recNum+j];
			if(sendNum <0 || sendNum >=HqData[jys].recCount)
			{
				ErrMsg(ghWndMain,"����Send_Hq01:�б�������");
				return -1;
			}
			if(!fRefresh)
			{
				*(short *)&SendBuff[len] =sendNum;
				len+=2;
				memcpy(&SendBuff[len], &HqData[jys].lpPreData[sendNum],
					sizeof(HQ_PRE_DATA));
				len +=sizeof(HQ_PRE_DATA);
				memcpy(&SendBuff[len], &HqData[jys].lpRefData[sendNum],
					sizeof(HQ_REF_DATA));
				len +=sizeof(HQ_REF_DATA);
				sendCount1++;
			}
			else
			{
				if(HqData[jys].lpRefData[sendNum].cjss !=*(int *)lpTmp)
				{
					*(short *)&SendBuff[len] =sendNum;
					len+=2;
					memcpy(&SendBuff[len], &HqData[jys].lpRefData[sendNum],
						sizeof(HQ_REF_DATA));
					len +=sizeof(HQ_REF_DATA);
					sendCount1++;
				}
				lpTmp +=sizeof(int);
			}
			if(sendCount1 >=MAX_HQ_SEND_COUNT)
			{
				*(short *)&SendBuff[len1] =sendCount1;
				*(short *)&SendBuff[strlen(HQ01_HEAD)] =len;
				if(UDP_SendBuff("����01", sd, SendBuff, len, NULL)<0)
					return -1;
				sendCount1 =0;
				len =len1+sizeof(short);
			}
		}
		if(sendCount1)
		{
			*(short *)&SendBuff[len1] =sendCount1;
			*(short *)&SendBuff[strlen(HQ01_HEAD)] =len;
			if(UDP_SendBuff("����01", sd, SendBuff, len, NULL)<0)
				return -1;
		}
	}
check_dest:
	if(fFirstTime)
		CheckDest(sd, lpdest, jys, REQ_HQ10, recList, (short)(recCount+1),client_version);
	else
		CheckDest(sd, lpdest, jys, REQ_HQ01, recList, (short)(recCount+1),client_version);
		
	if(fFirstTime)
		UDP_Server_Send_Dp(sd, lpdest, TRUE, NULL);

	return recCount;
}

int Delay_Send_Hq01(LPDEST_INFO lpDest)
{
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	short jys, recCount, recNum, sendCount, sendCount1, sendNum;
	short recList[MAX_PARA_COUNT+1];
	short i, j, len, len1;
	BYTE client_version;
	BOOL fRefresh, fSel, fFirstTime;
	int sd;
	
	memset(&SendBuff[0],0, sizeof(SendBuff));
	sd =lpDest->sd;
	client_version =lpDest->version;

	if(client_version <SERVER_VERSION)
	{
		SendMsg(sd, "�汾��!");
		return 0;
	}

	jys =lpDest->curJys;
	fFirstTime =FALSE;

	fRefresh =FALSE;

	fSel =TRUE; //*lpTmp++;

	strcpy(SendBuff, HQ01_HEAD); 
	len =strlen(HQ01_HEAD)+sizeof(short);
	SendBuff[len++] =(BYTE)jys;
	SendBuff[len++] =(BYTE)fRefresh;
	SendBuff[len++] =(BYTE)fSel;
	len1 =len;
	recCount =lpDest->params[0];

	if(recCount <=0 || recCount >MAX_PARA_COUNT) return -1;
	*(short *)&SendBuff[len] =0;
	len +=sizeof(short);
	
	memset(recList, 0, sizeof(short)*MAX_PARA_COUNT);
	recList[0] =recCount;

	if(!fSel)
	{
		recNum =lpDest->params[1];
		if(recNum >=HqData[jys].recCount)
		{
			ErrMsg(ghWndMain,"����Send_Hq01����¼��Ŵ�����������");
			return -1;
		}

		if(recNum <0)
		{
			ErrMsg(ghWndMain,"����Send_Hq01����¼���С����");
			return -1;
		}

		//����Ŵ�
		if(recNum +recCount-1 >=HqData[jys].recCount)
		{
			recCount =HqData[jys].recCount -recNum;
			recList[0] =recCount;
		}
		for(i =0; i<recCount; i++)
			recList[i+1] =recNum+i;
	}
	else            
	{
		memcpy(&recList[1], &lpDest->params[1], sizeof(short)*recCount);
//		lpTmp +=sizeof(short)*recCount;
	}
	
	sendCount1 =0;
	for(i =0; i <=recCount/MAX_HQ_SEND_COUNT; i++)
	{
		sendCount =MAX_HQ_SEND_COUNT;
		recNum =i*MAX_HQ_SEND_COUNT;
		if(recNum+sendCount >recCount)
			sendCount =recCount-recNum;
		for(j =0; j<sendCount; j++)
		{
			sendNum =recList[1+recNum+j];
			if(sendNum <0 || sendNum >=HqData[jys].recCount)
			{
				ErrMsg(ghWndMain,"����Send_Hq01:�б�������");
				return -1;
			}
			//if(!fRefresh)
			//{
				*(short *)&SendBuff[len] =sendNum;
				len+=2;
				memcpy(&SendBuff[len], &HqData[jys].lpPreData[sendNum],
					sizeof(HQ_PRE_DATA));
				len +=sizeof(HQ_PRE_DATA);
				memcpy(&SendBuff[len], &HqData[jys].lpRefData[sendNum],
					sizeof(HQ_REF_DATA));
				len +=sizeof(HQ_REF_DATA);
				sendCount1++;
			//}
			//else
			//{
			//	if(HqData[jys].lpRefData[sendNum].cjss !=*(int *)lpTmp)
			//	{
			//		*(short *)&SendBuff[len] =sendNum;
			//		len+=2;
			//		memcpy(&SendBuff[len], &HqData[jys].lpRefData[sendNum],
			//			sizeof(HQ_REF_DATA));
			//		len +=sizeof(HQ_REF_DATA);
			//		sendCount1++;
			//	}
			//}
			if(sendCount1 >=MAX_HQ_SEND_COUNT)
			{
				*(short *)&SendBuff[len1] =sendCount1;
				*(short *)&SendBuff[strlen(HQ01_HEAD)] =len;
				if(UDP_SendBuff("����01", sd, SendBuff, len, NULL)<0)
				{
					lpDest->reqType =REQ_HQ10;		
					return -1;
				}
				sendCount1 =0;
				len =len1+sizeof(short);
			}
		}
		if(sendCount1)
		{
			*(short *)&SendBuff[len1] =sendCount1;
			*(short *)&SendBuff[strlen(HQ01_HEAD)] =len;
			if(LOW_UDP_SendBuff("����01", sd, SendBuff, len, NULL,lpDest)<0)
			{
				lpDest->reqType =REQ_HQ10;		
				return -1;
			}
		}
	}
	lpDest->reqType =REQ_HQ10;		

	return j;
}

int Send_Hq01(int sd, LPSTR lpTmp, struct sockaddr *lpdest)
{
	char * SendBuff;
	short jys, recCount, recNum, sendCount, sendCount1, sendNum;
	short recList[MAX_PARA_COUNT+1];
	short i, j, len, len1;
	BYTE client_version;
	BOOL fRefresh, fSel, fFirstTime;
	
	client_version =*lpTmp++;
	if(client_version <SERVER_VERSION)
	{
		SendMsg(sd, "�汾��!");
		return 0;
	}
	jys =*lpTmp++;
	fFirstTime =(BOOL)*lpTmp++;
	if(fFirstTime)
	{
		if(UDP_Server_Send_Hq00(sd, jys, lpdest)<0)
			return 0;
	}
	fRefresh =*lpTmp++;
	fSel =*lpTmp++;

	recCount =*(short *)lpTmp;
	if(recCount <=0 || recCount >MAX_PARA_COUNT) 
		return -1;
	lpTmp +=2;
	
	SendBuff =GlobalAllocPtr(GHND,strlen(HQ01_HEAD)+7+
		(2+sizeof(HQ_PRE_DATA)+sizeof(HQ_REF_DATA))*recCount);
	if(SendBuff ==NULL)
		return -1;

	strcpy(SendBuff, HQ01_HEAD); 
	len =strlen(HQ01_HEAD)+sizeof(short);	//2
	SendBuff[len++] =(BYTE)jys;				//1
	SendBuff[len++] =(BYTE)fRefresh;		//1
	SendBuff[len++] =(BYTE)fSel;			//1
	len1 =len;

	*(short *)&SendBuff[len] =0;
	len +=sizeof(short);					//2
	
	memset(recList, 0, sizeof(short)*MAX_PARA_COUNT);
	recList[0] =recCount;

	if(!fSel)
	{
		recNum =*(short *)lpTmp;
		if(recNum >=HqData[jys].recCount)
		{
			ErrMsg(ghWndMain,"����Send_Hq01����¼��Ŵ�����������");
			goto exit_send;
		}

		if(recNum <0)
		{
			ErrMsg(ghWndMain,"����Send_Hq01����¼���С����");
			goto exit_send;
		}

		lpTmp+=2;
		//����Ŵ�
		if(recNum +recCount-1 >=HqData[jys].recCount)
		{
			recCount =HqData[jys].recCount -recNum;
			recList[0] =recCount;
		}
		for(i =0; i<recCount; i++)
			recList[i+1] =recNum+i;
	}
	else            
	{
		memcpy(&recList[1], lpTmp, sizeof(short)*recCount);
		lpTmp +=sizeof(short)*recCount;
	}
	
	sendCount1 =0;

	sendCount =recCount;
	recNum =0;
	for(j =0; j<sendCount; j++)
	{
		sendNum =recList[1+j];
		if(sendNum <0 || sendNum >=HqData[jys].recCount)
		{
			ErrMsg(ghWndMain,"����Send_Hq01:�б�������");
			goto exit_send;
		}
		if(!fRefresh)
		{
			*(short *)&SendBuff[len] =sendNum;
			len+=2;
			memcpy(&SendBuff[len], &HqData[jys].lpPreData[sendNum],
				sizeof(HQ_PRE_DATA));
			len +=sizeof(HQ_PRE_DATA);
			memcpy(&SendBuff[len], &HqData[jys].lpRefData[sendNum],
				sizeof(HQ_REF_DATA));
			len +=sizeof(HQ_REF_DATA);
			sendCount1++;
		}
		else
		{
			if(HqData[jys].lpRefData[sendNum].cjss !=*(int *)lpTmp)
			{
				*(short *)&SendBuff[len] =sendNum;
				len+=2;
				memcpy(&SendBuff[len], &HqData[jys].lpRefData[sendNum],
					sizeof(HQ_REF_DATA));
				len +=sizeof(HQ_REF_DATA);
				sendCount1++;
			}
		}
	}
	if(sendCount1>0)
	{
		*(short *)&SendBuff[len1] =sendCount1;
		*(short *)&SendBuff[strlen(HQ01_HEAD)] =len;
		if(SendMemData(sd,SendBuff,len)<0)
			goto exit_send;
	}

	CheckDest(sd, lpdest, jys, REQ_HQ10, recList, (short)(recCount+1),client_version);
		
	if(fFirstTime)
		UDP_Server_Send_Dp(sd, lpdest, TRUE, NULL);

exit_send:
	GlobalFreePtr(SendBuff);
	return j;
}

int Send_Hq10(LPDEST_INFO lpDest)
{
	char * SendBuff;
	short recFirst =0, recCount =0,sendNum,sendCount1;
	int j, len =0, len1;
	int jys =lpDest->curJys;

	if(lpDest->paramsCount <=1)
	{
		UnlockDest(lpDest);
		return -1;
	}
	if(lpDest->params[0]+lpDest->params[1]-1>=HqData[lpDest->curJys].recCount)
	{
		UnlockDest(lpDest);
		return 0;
	}
	if(lpDest->params[0]==0) 
	{
		UnlockDest(lpDest);
		return 0;
	}

	recCount =lpDest->params[0];

	SendBuff =GlobalAllocPtr(GHND,
		strlen(HQ10_HEAD)+5+(2+sizeof(HQ_REF_DATA))*recCount);

	strcpy(SendBuff, HQ10_HEAD);
	len =strlen(HQ10_HEAD)+sizeof(short);	//2
	SendBuff[len++] =(char)lpDest->curJys;	//1
	*(short *)&SendBuff[len] =0;

	len1 =len;
	len +=sizeof(short);					//2

	sendCount1 =0;

	for(j =0; j<recCount; j++)
	{
		sendNum =lpDest->params[1+j];
		if(HqData[jys].lpRefData[sendNum].cjss
				!=lpDest->lpCjss[j])
		{
			*(short *)&SendBuff[len] =sendNum;
			len+=2;									//2
			memcpy(&SendBuff[len], &HqData[jys].lpRefData[sendNum],
				sizeof(HQ_REF_DATA));
			len +=sizeof(HQ_REF_DATA);				//sizeof(HQ_REF_DATA)
			lpDest->lpCjss[j] =HqData[jys].lpRefData[sendNum].cjss;
			sendCount1++;
		}
	}

	UnlockDest(lpDest);

	if(sendCount1)
	{
		*(short *)&SendBuff[len1] =sendCount1;
		*(short *)&SendBuff[strlen(HQ10_HEAD)] =len;
		SendMemData(lpDest->sd, SendBuff, len);
	}
	GlobalFreePtr(SendBuff);
	return 0;
}

int UDP_Server_Send_Hq10(LPDEST_INFO lpDest)
{
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	short recFirst =0, recCount =0, recNum, sendNum, sendCount, sendCount1;
	int i, j, len =0, len1;
	int jys =lpDest->curJys;

	memset(&SendBuff[0],0, sizeof(SendBuff));
	if(lpDest->paramsCount <=1) return -1;
	recCount =lpDest->params[0];

	if(lpDest->params[0]+lpDest->params[1]-1>=HqData[lpDest->curJys].recCount)
		return  0;
	strcpy(SendBuff, HQ10_HEAD);
	len =strlen(HQ10_HEAD)+sizeof(short);
	SendBuff[len++] =(char)lpDest->curJys;
	*(short *)&SendBuff[len] =0;

	len1 =len;
	len +=sizeof(short);

	sendCount =MAX_HQ_SEND_COUNT;
	sendCount1 =0;
	if(recCount==0) return 0;

	if(recCount<MAX_HQ_SEND_COUNT)
	{
		for(i=0;i<recCount;i++)
		{
			sendNum=lpDest->params[1+i];
			if(sendNum<0||sendNum>=HqData[lpDest->curJys].recCount)
			{
				ErrMsg(ghWndMain,"����Send_Hq10:�б�������");
				return 0;
			}
			if(recCount>MAX_PARA_COUNT)
			{
				ErrMsg(ghWndMain,"����Send_Hq10:���ͼ�¼����");
				return 0;
			}
			if(HqData[jys].lpRefData[sendNum].cjss
					!=lpDest->lpCjss[i])
			{
				*(short *)&SendBuff[len] =sendNum;
				len+=2;
				memcpy(&SendBuff[len], &HqData[jys].lpRefData[sendNum],
					sizeof(HQ_REF_DATA));
				len +=sizeof(HQ_REF_DATA);
				lpDest->lpCjss[i] =HqData[jys].lpRefData[sendNum].cjss;
				sendCount1++;
			}
		}
		if(sendCount1>0)
		{
			*(short *)&SendBuff[len1] =sendCount1;
			*(short *)&SendBuff[strlen(HQ10_HEAD)] =len;

			if(LOW_UDP_SendBuff("����10", lpDest->sd, SendBuff, len,NULL,NULL)<0)
			{
				return -1;
			}
		}
		return 0;
	}

	sendCount =MAX_HQ_SEND_COUNT;
	sendCount1 =0;

	for(i =0; i<recCount/MAX_HQ_SEND_COUNT ; i++)
	{
		recNum =i*MAX_HQ_SEND_COUNT;
		if(recNum+sendCount >recCount)
			sendCount =recCount-recNum;
		for(j =0; j<sendCount; j++)
		{
			sendNum =lpDest->params[1+recNum+j];
			if(HqData[jys].lpRefData[sendNum].cjss
					!=lpDest->lpCjss[recNum+j])
			{
				*(short *)&SendBuff[len] =sendNum;
				len+=2;
				memcpy(&SendBuff[len], &HqData[jys].lpRefData[sendNum],
					sizeof(HQ_REF_DATA));
				len +=sizeof(HQ_REF_DATA);
				lpDest->lpCjss[recNum+j] =HqData[jys].lpRefData[sendNum].cjss;
				sendCount1++;
			}
			if(sendCount1 >=MAX_HQ_SEND_COUNT)
			{
				*(short *)&SendBuff[len1] =sendCount1;
				*(short *)&SendBuff[strlen(HQ10_HEAD)] =len;
				if(LOW_UDP_SendBuff("����10", lpDest->sd, SendBuff, len, NULL, lpDest)<0)
				{
					return -1;
				}
				sendCount1 =0;
				len =len1+sizeof(short);
			}
		}
		if(sendCount1)
		{
			*(short *)&SendBuff[len1] =sendCount1;
			*(short *)&SendBuff[strlen(HQ10_HEAD)] =len;
			if(LOW_UDP_SendBuff("����10", lpDest->sd, SendBuff, len, NULL, lpDest)<0)
			{
				return -1;
			}
			sendCount1 =0;
			len =len1+sizeof(short);
			break;
		}
		else
		{
			if(recCount<MAX_HQ_SEND_COUNT)
				break;
		}
	}
	
	return 0;
}


int UDP_Server_Send_LitHq(int sd, int jys, short rec_num, int cjss, struct sockaddr *lpdest, BOOL fThrd, LPDEST_INFO lpDestInfo)
{
	char SendBuff[200];
	int len;

	memset(&SendBuff[0],0, sizeof(SendBuff));
	strcpy(SendBuff, HQ10_HEAD);
	len =strlen(HQ10_HEAD)+sizeof(short);
	SendBuff[len ++] =jys;
	*(short *)&SendBuff[len] =1;
	len +=sizeof(short);
	*(short *)&SendBuff[len] =rec_num;
	len +=sizeof(short);
	memcpy(&SendBuff[len], &HqData[jys].lpRefData[rec_num],
			sizeof(HQ_REF_DATA));
	len +=sizeof(HQ_REF_DATA);
	*(short *)&SendBuff[strlen(HQ10_HEAD)] =len;

	if(UDP_SendBuff("����ɽ���ϸ", sd, SendBuff, len, lpDestInfo)<0)
			return -1;

	return 0;
}

int UDP_Server_Send_Gra00(int sd, int jys, short gp_rec_num,GRA_HEAD *GraHead)
{                                                     
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	int len;
	
	memset(&SendBuff[0],0, sizeof(SendBuff));
	strcpy(SendBuff, GRA00_HEAD);
	len =strlen(GRA00_HEAD)+sizeof(short);
	SendBuff[len++] =(BYTE)jys;
	memcpy(&SendBuff[len] ,GraHead, sizeof(GRA_HEAD));
	len +=sizeof(GRA_HEAD);
	*(short *)&SendBuff[strlen(GRA00_HEAD)] =len;
	return UDP_SendBuff("��ʱͼ00", sd, SendBuff, len, NULL);
}

typedef struct tag_INIT_TEMP_INFO
{ 
	char head[7];
	unsigned short id;		//���ݶ��������
	unsigned short total;	//���ݶ�����ܳ�
	unsigned short expand;	//��ѹ������ݳ���
}INIT_TEMP_INFO,MEM_HEAD_INFO;

int SendMemData(int sd,char *mem,int memlen)
{
	int j =0,	//һ�η��͵Ľ��
		e,      //SOCKET ������
		x=0,    //�ѷ������ݰ���
		k,
		complen, //ѹ����İ��ܳ�
		sended, //�Ѵ��ֽ��� 
		len,    //��lpBuf�ֶϺ�����ݳ�
		tlen;   //�������ݰ�������ܳ�

	char SendBuf[1+sizeof(short)+sizeof(INIT_TEMP_INFO)+MAX_SEND_BUF_SIZE];
	char *lpBuf;
	INIT_TEMP_INFO InitTempInfo;
	static unsigned short id=1;
	
	lpBuf =GlobalAllocPtr(GHND,memlen);
	if(lpBuf ==NULL) return -1;
	if(memlen>512)
	{
		complen =memlen;
		e=compress(lpBuf,&complen,mem,memlen);
		if(e!=Z_OK)
		{
			memcpy(lpBuf,mem,memlen);
			complen =memlen;
		}
	}
	else
	{
		memcpy(lpBuf,mem,memlen);
		complen =memlen;
	}

	strncpy(InitTempInfo.head,"MOVEMEM",7);
	InitTempInfo.id =id++; if(id>=65534) id=1;
	InitTempInfo.total =complen;
	InitTempInfo.expand =memlen;

	for(sended =0;sended<complen;)
	{
		if(complen-sended>MAX_SEND_BUF_SIZE)
			len =MAX_SEND_BUF_SIZE;
		else
			len =complen-sended;

		memset(SendBuf,0,1+sizeof(short)+sizeof(INIT_TEMP_INFO)+MAX_SEND_BUF_SIZE);
		SendBuf[0]=START_SIGN;		
		*(short *)&SendBuf[1]=(short )len+sizeof(INIT_TEMP_INFO);
		memcpy(&SendBuf[1+sizeof(short)],&InitTempInfo,sizeof(INIT_TEMP_INFO));
		memcpy(&SendBuf[1+sizeof(short)+sizeof(INIT_TEMP_INFO)],&lpBuf[sended],len);
		sended +=len;
		tlen = len+1+sizeof(short)+sizeof(INIT_TEMP_INFO);

		for(k=0,x=0;k<400;)
		{
			j =send(sd, &SendBuf[x], tlen -x, 0);
			if (j == SOCKET_ERROR)
			{
				e =WSAGetLastError();
				switch(e)
				{
					case WSANOTINITIALISED : 
					//A successful WSAStartup must occur 
					//before using this function. 
						ErrMsg(ghWndMain,"WSANOTINITIALISED");
						goto exit_send;
					break;
					case WSAENETDOWN :
					//The network subsystem has failed. 
						ErrMsg(ghWndMain,"WSAENETDOWN");
						goto exit_send;
					break;
					case WSAEACCES:
					//The requested address is a broadcast
					//address, but the appropriate flag was not set. 
						ErrMsg(ghWndMain,"WSAEACCES");
						goto exit_send;
					break;
					case WSAEINTR:
					//The (blocking) call was canceled through 
					//WSACancelBlockingCall. 
						goto exit_send;
					break;
					case WSAEINPROGRESS:
					//A blocking Windows Sockets 1.1 call is
					//in progress, or the service provider is still 
					//processing a callback function. 
						ShoutBlockingHook();
						Sleep(10);
					break;
					case WSAEFAULT:
					//The buf parameter is not totally contained in
					//a valid part of the user address space.
						goto exit_send;
					break;
					case WSAENETRESET:
					//The connection has been broken due to the 
					//remote host resetting. 
						HqDestStopBySd(sd);
						goto exit_send;
					break;	
					case WSAENOBUFS:
					//No buffer space is available. 
						goto exit_send;
					break;
					case WSAENOTCONN:
					//The socket is not connected.
						HqDestStopBySd(sd);
						goto exit_send;
					break;
					case WSAENOTSOCK:
					//The descriptor is not a socket. 
						goto exit_send;
					break;
					case WSAEOPNOTSUPP:
					//MSG_OOB was specified, but the socket
					//is not stream style such as type SOCK_STREAM, out-of-band data is not supported in the communication domain associated with this socket, or the socket is unidirectional and supports only receive operations. 
						goto exit_send;
					break;
					case WSAESHUTDOWN:
					//The socket has been shut down; it is not 
					//possible to send on a socket after 
					//shutdown has been invoked with how set 
					//to SD_SEND or SD_BOTH. 
						goto exit_send;
					break;
					case WSAEWOULDBLOCK:
					//The socket is marked as nonblocking and 
					//the requested operation would block. 
						ShoutBlockingHook();
						Sleep(10);
					break;
					case WSAEMSGSIZE:
					//The socket is message oriented, and the 
					//message is larger than the 
					//maximum supported by the underlying transport. 
						goto exit_send;
					break;
					case WSAEHOSTUNREACH:					
					//The remote host cannot be reached from this 
					//host at this time. 
						goto exit_send;
					break;
					case WSAEINVAL:
					//The socket has not been bound with bind, or 
					//an unknown flag was specified,
						goto exit_send;
					break;
					case WSAECONNABORTED:
					//The virtual circuit was terminated due to a 
					//time-out or other failure. The application 
					//should close the socket as it is no longer usable. 
						HqDestStopBySd(sd);
						goto exit_send;
					break;
					case WSAECONNRESET:
					//The virtual circuit was reset by the remote 
					//side executing a "hard" or "abortive" close. For 
					//UPD sockets, the remote host was unable to deliver
					//a previously sent UDP datagram and responded with 
					//a "Port Unreachable" ICMP packet. The application 
					//should close the socket as it is no longer usable. 
						HqDestStopBySd(sd);
						goto exit_send;
					break;
					case WSAETIMEDOUT:
					//The connection has been dropped, because of a network
					//failure or because the system on the other end went down 
					//without notice. 
						HqDestStopBySd(sd);
						goto exit_send;
					break;
					default:
						goto exit_send;
				}
			}
			else
			{
				if(x+j !=tlen)
				{
					ShoutBlockingHook();
					x+=j;
				}
				else
					break;
			}
		}
	}
exit_send:
	GlobalFreePtr(lpBuf);
	return sended;
}


int Send_Gra01(int sd, LPSTR lpTmp,struct sockaddr *lpdest)
{
	int jys,len;
	char fileName[128];
	HANDLE hd;
	char *lpGraData =NULL;

	HFILE hFile;
	OFSTRUCT os;
	short recList[5];
	short gp_rec_num, gra_rec_count, gra_rec_end;
	short dateNum;
    GRA_HEAD tmpHead;

	jys =*lpTmp++;
	if(jys > 1) return -1;
	dateNum =*lpTmp++;
	gp_rec_num =*(short *)lpTmp;
	if(gp_rec_num >=HqData[jys].recCount)
	{
		ErrMsg(ghWndMain,"����Send_Gra01:��¼β���ڼ�¼����");
		return -1;
	}
	lpTmp +=sizeof(short);
	gra_rec_end =*(short *)lpTmp;
	lpTmp +=sizeof(short);

	wsprintf(fileName, "%s\\%s.dat", GraphData[jys].szGraPath,
			HqData[jys].lpPreData[gp_rec_num].zqdm);
	hFile =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hFile ==HFILE_ERROR) return -1;

	if(_lread(hFile, &tmpHead, sizeof(GRA_HEAD))
			!=sizeof(GRA_HEAD))
	{
		_lclose(hFile);
		return -1;
	}

	if(IsZsRec(jys, gp_rec_num))
	{
		UDP_Server_Send_MaxMin10(sd, jys, 0, NULL, TRUE, NULL);
		UDP_Server_Send_MaxMin10(sd, jys, 1, NULL, TRUE, NULL);
	}
	else
	{
		UDP_Server_Send_Mmp(sd, jys, gp_rec_num, lpdest, TRUE, NULL);
		if(gra_rec_end <tmpHead.recCount)
			UDP_Server_Send_LitHq(sd, jys, gp_rec_num, 0, lpdest, TRUE, NULL);
	}

	if(gra_rec_end ==tmpHead.recCount)
	{
		_lclose(hFile);
		goto check_dest;
	}

	if(gra_rec_end >tmpHead.recCount)
		gra_rec_end =0;
		
	UDP_Server_Send_Gra00(sd, jys, gp_rec_num, &tmpHead);

	if(_llseek(hFile, sizeof(GRA_HEAD)+gra_rec_end*sizeof(GRA_DATA), FILE_BEGIN)
			==HFILE_ERROR)
	{
		_lclose(hFile);
		return -1;
	}
	gra_rec_count =tmpHead.recCount-gra_rec_end;

	hd =GlobalAlloc(GHND,strlen(GRA01_HEAD)+9+(int)sizeof(GRA_DATA)*gra_rec_count);
	if(hd ==NULL)
	{
		ErrMsg(ghWndMain,"����Send_Gra01:�����ڴ�ʧ��");
		_lclose(hFile);
		return(-1);
	}

	lpGraData=GlobalLock(hd);
	if(lpGraData ==NULL)
	{
		ErrMsg(ghWndMain, "����Send_Gra01:�����ڴ�ʧ��");
		_lclose(hFile);
		return -1;
	}
	
	strcpy(lpGraData, GRA01_HEAD); 
	len =strlen(GRA01_HEAD)+sizeof(short);		//2
	lpGraData[len++] =(char)jys;				//1

	*((short *)&lpGraData[len]) =gp_rec_num;	//2
	len +=sizeof(short);
	*((short *)&lpGraData[len]) =gra_rec_count;	//2
	len +=sizeof(short);
	*((short *)&lpGraData[len]) =0;				//2
	len +=sizeof(short);
	
	if(_lread(hFile, &lpGraData[len], sizeof(GRA_DATA)*gra_rec_count)
			!=gra_rec_count*sizeof(GRA_DATA))
	{
		GlobalUnlock(hd);
		GlobalFree(hd);
		_lclose(hFile);
		return -1;
	}
	_lclose(hFile);

	len +=gra_rec_count*sizeof(GRA_DATA);

	*(short *)&lpGraData[strlen(GRA01_HEAD)] =len;
	SendMemData(sd, lpGraData, len);

	GlobalUnlock(GlobalHandle(lpGraData));
	GlobalFree(GlobalHandle(lpGraData));

check_dest:

	recList[0] =gp_rec_num;
	recList[1] =gra_rec_end+gra_rec_count;
	CheckDest(sd, lpdest, jys, REQ_GRA10, &recList[0], 2, 0);

	return 0;
}

int UDP_Server_Send_Gra01(int sd, LPSTR lpTmp, struct sockaddr *lpdest)
{
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	int jys, i, len;
	char fileName[128];
	HANDLE hd;
	LPGRA_DATA lpGraData =NULL;
	HFILE hFile;
	OFSTRUCT os;
	short recList[5];
	short gp_rec_num, gra_rec_count, gra_rec_end, sendCount, sendNum;
	short dateNum;
    GRA_HEAD tmpHead;

	memset(&SendBuff[0],0, sizeof(SendBuff));
	jys =*lpTmp++;
	if(jys > 1) return -1;
	dateNum =*lpTmp++;
	gp_rec_num =*(short *)lpTmp;
	if(gp_rec_num >=HqData[jys].recCount)
	{
		ErrMsg(ghWndMain,"����Send_Gra01:��¼β���ڼ�¼����");
		return -1;
	}
	lpTmp +=sizeof(short);
	gra_rec_end =*(short *)lpTmp;
	lpTmp +=sizeof(short);

	wsprintf(fileName, "%s\\%s.dat", GraphData[jys].szGraPath,
			HqData[jys].lpPreData[gp_rec_num].zqdm);
	hFile =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hFile ==HFILE_ERROR) return -1;

	if(_lread(hFile, &tmpHead, sizeof(GRA_HEAD))
			!=sizeof(GRA_HEAD))
	{
		_lclose(hFile);
		return -1;
	}

	if(IsZsRec(jys, gp_rec_num))
	{
		UDP_Server_Send_MaxMin10(sd, jys, 0, lpdest, TRUE, NULL);
		UDP_Server_Send_MaxMin10(sd, jys, 1, lpdest, TRUE, NULL);
	}
	else
	{
		UDP_Server_Send_Mmp(sd, jys, gp_rec_num, lpdest, TRUE, NULL);
		if(gra_rec_end <tmpHead.recCount)
			UDP_Server_Send_LitHq(sd, jys, gp_rec_num, 0, lpdest, TRUE, NULL);
	}

	if(gra_rec_end ==tmpHead.recCount)
	{
		_lclose(hFile);
		goto check_dest;
	}

	if(gra_rec_end >tmpHead.recCount)
		gra_rec_end =0;
		
	UDP_Server_Send_Gra00(sd, jys, gp_rec_num, &tmpHead);
	
	if(_llseek(hFile, sizeof(GRA_HEAD)+gra_rec_end*sizeof(GRA_DATA), FILE_BEGIN)
			==HFILE_ERROR)
	{
		ErrMsg(ghWndMain, "����Send_Gra01:��λ�����ļ���");
		ErrMsg(ghWndMain, fileName);
		_lclose(hFile);
		return -1;
	}
	gra_rec_count =tmpHead.recCount-gra_rec_end;
	hd =GlobalAlloc(GHND,(int)sizeof(GRA_DATA)*gra_rec_count);
	if(hd ==NULL)
	{
		ErrMsg(ghWndMain,"����Send_Gra01:�����ڴ�ʧ��");
		_lclose(hFile);
		return(-1);
	}
	lpGraData=GlobalLock(hd);
	if(lpGraData ==NULL)
	{
		ErrMsg(ghWndMain, "����Send_Gra01:�����ڴ�ʧ��");
		_lclose(hFile);
		return -1;
	}
	
	if(_lread(hFile, lpGraData, sizeof(GRA_DATA)*gra_rec_count)
			!=gra_rec_count*sizeof(GRA_DATA))
	{
		ErrMsg(ghWndMain, "����Send_Gra01:�������ļ���1");
		ErrMsg(ghWndMain, fileName);
		GlobalUnlock(hd);
		GlobalFree(hd);
		_lclose(hFile);
		return -1;
	}
	_lclose(hFile);
	
	sendCount =MAX_GRA_SEND_COUNT;
	for(i =0; i<=gra_rec_count/MAX_GRA_SEND_COUNT; i++)
	{
		sendNum =i*MAX_GRA_SEND_COUNT;
		if(sendCount+sendNum >gra_rec_count)
			sendCount =gra_rec_count-sendNum;

		strcpy(SendBuff, GRA01_HEAD); 
		len =strlen(GRA01_HEAD)+sizeof(short);
		SendBuff[len++] =(char)jys;

		*((short *)&SendBuff[len]) =gp_rec_num;
		len +=sizeof(short);
		*((short *)&SendBuff[len]) =sendCount;
		len +=sizeof(short);
		*((short *)&SendBuff[len]) =sendNum;
		len +=sizeof(short);
	
		memcpy(&SendBuff[len], &lpGraData[sendNum], sendCount*sizeof(GRA_DATA));
		len +=sendCount*sizeof(GRA_DATA);
		if(sendCount)
		{
			*(short *)&SendBuff[strlen(GRA01_HEAD)] =len;
			if(UDP_SendBuff("��ʱͼ01", sd, SendBuff, len, NULL)<0)
			{
				GlobalUnlock(GlobalHandle(lpGraData));
				GlobalFree(GlobalHandle(lpGraData));
				return -1;
			}
		}
	}
	GlobalUnlock(GlobalHandle(lpGraData));
	GlobalFree(GlobalHandle(lpGraData));

check_dest:

	recList[0] =gp_rec_num;
	recList[1] =gra_rec_end+gra_rec_count;
	CheckDest(sd, lpdest, jys, REQ_GRA10, &recList[0], 2, 0);

	return 0;
}

int Send_Gra10(LPDEST_INFO lpDest)
{
	char * SendBuff =NULL;
	int jys,len;
	char fileName[128];

	HFILE hFile;
	OFSTRUCT os;
	short gp_rec_num, gra_rec_count, gra_rec_end;
	short j;
    GRA_HEAD tmpHead;
	BOOL sdMax1 =FALSE,sdMax2 =FALSE,sdMmp=FALSE,
		 sdLit=FALSE;

	jys =lpDest->curJys;
	if(lpDest->paramsCount<2)
	{
		UnlockDest(lpDest);
		return -1;
	}
	gp_rec_num =lpDest->graNo; //lpDest->params[0];
	if(gp_rec_num>=HqData[jys].recCount||
		gp_rec_num<0)
	{
		UnlockDest(lpDest);
		return 0;
	}
	gra_rec_end =lpDest->graEnd; //lpDest->params[1];
	if(gra_rec_end<0)
	{
		UnlockDest(lpDest);
		return 0;
	}

	if(IsZsRec(jys, gp_rec_num))
	{
		if(memcmp(&lpDest->lpZsGraph->Maxmin[0], &MaxMinData[lpDest->curJys][0],
				sizeof(MAXMIN_DATA)))
		{
			memcpy(&lpDest->lpZsGraph->Maxmin[0], &MaxMinData[lpDest->curJys][0],
				sizeof(MAXMIN_DATA));
			sdMax1 =TRUE;
		}
		if(memcmp(&lpDest->lpZsGraph->Maxmin[1], &MaxMinData[lpDest->curJys][1],
				sizeof(MAXMIN_DATA)))
		{
			memcpy(&lpDest->lpZsGraph->Maxmin[1], &MaxMinData[lpDest->curJys][1],
				sizeof(MAXMIN_DATA));
			sdMax2 =TRUE;
		}
	}
	else
	{
		if(memcmp(&lpDest->lpGraph->mmp, &MmpData[lpDest->curJys].lpMmp[gp_rec_num],
				sizeof(MMP)))
		{
			memcpy(&lpDest->lpGraph->mmp, &MmpData[lpDest->curJys].lpMmp[gp_rec_num],
				sizeof(MMP));
			sdMmp =TRUE;
		}
	}

	if(lpDest->cjss !=HqData[lpDest->curJys].lpRefData[gp_rec_num].cjss)
	{
		lpDest->cjss =HqData[lpDest->curJys].lpRefData[gp_rec_num].cjss;
		sdLit =TRUE;
	}

	wsprintf(fileName, "%s\\%s.dat", GraphData[jys].szGraPath,
			HqData[jys].lpPreData[gp_rec_num].zqdm);
	hFile =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hFile ==HFILE_ERROR)
	{
		UnlockDest(lpDest);
		return 0;
    }
	if(_lread(hFile,&tmpHead, sizeof(GRA_HEAD))
			!=sizeof(GRA_HEAD))
	{
		UnlockDest(lpDest);
		_lclose(hFile);
		return 0;
	}
    j=tmpHead.recCount;

	gra_rec_count =j-gra_rec_end;
    if(gra_rec_count<=0)
	{
		UnlockDest(lpDest);
		_lclose(hFile);
		return 0;
	}

	if(_llseek(hFile, sizeof(GRA_HEAD)+gra_rec_end*sizeof(GRA_DATA), FILE_BEGIN)
			==HFILE_ERROR)
	{
		UnlockDest(lpDest);
		_lclose(hFile);
		return 0;
	}
	SendBuff =GlobalAllocPtr(GHND,
		strlen(GRA10_HEAD)+9+sizeof(GRA_DATA)*gra_rec_count);
	if(SendBuff ==NULL)
	{
		UnlockDest(lpDest);
		_lclose(hFile);
		return 0;
	}

	strcpy(SendBuff,GRA10_HEAD);
	len =strlen(GRA01_HEAD)+sizeof(short);	//2
	SendBuff[len++] =(char)jys;				//1
	*((short *)&SendBuff[len]) =gp_rec_num;
	len +=sizeof(short);					//2
	*((short *)&SendBuff[len]) =gra_rec_count;
	len +=sizeof(short);					//2
	*((short *)&SendBuff[len]) =gra_rec_end;
	len +=sizeof(short);					//2
	
	if(_lread(hFile,&SendBuff[len], sizeof(GRA_DATA)*gra_rec_count)
			==sizeof(GRA_DATA)*gra_rec_count)
	{
		len +=gra_rec_count*sizeof(GRA_DATA);
		_lclose(hFile);
	
		*(short *)&SendBuff[strlen(GRA10_HEAD)] =len;
		if(SendMemData(lpDest->sd, SendBuff, len)>0)
		{
			//lpDest->params[1] +=gra_rec_count;	
			lpDest->graEnd +=gra_rec_count;	
		}
	}
	UnlockDest(lpDest);
	_lclose(hFile);
	GlobalFreePtr(SendBuff);

	if(sdMax1)
	UDP_Server_Send_MaxMin10(lpDest->sd, jys, 0, NULL, FALSE, lpDest);
	if(sdMax2)
	UDP_Server_Send_MaxMin10(lpDest->sd, jys, 1, NULL, FALSE, lpDest);
	if(sdMmp)
	UDP_Server_Send_Mmp(lpDest->sd, jys, gp_rec_num, NULL, FALSE, lpDest);
	if(sdLit)
	UDP_Server_Send_LitHq(lpDest->sd, jys, gp_rec_num, 0, NULL, FALSE, lpDest);

	return 0;
}

int UDP_Server_Send_Gra10(LPDEST_INFO lpDest)
{
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	int jys, i, len;
	char fileName[128];
	LPGRA_DATA lpGraData =NULL;
	HFILE hFile;
	OFSTRUCT os;
	short gp_rec_num, gra_rec_count, gra_rec_end, sendCount, sendNum;
	short j;
    GRA_HEAD tmpHead;
	HANDLE hd;

	memset(&SendBuff[0],0, sizeof(SendBuff));
	jys =lpDest->curJys;
	if(lpDest->paramsCount<2)
	{
		ErrMsg(ghWndMain,"����Send_Gra10:����������");
		return -1;
	}
	gp_rec_num =lpDest->graNo; //params[0];
	if(gp_rec_num>=HqData[jys].recCount||
		gp_rec_num<0)
	{
		return 0;
	}
	gra_rec_end =lpDest->graEnd; //params[1];
	if(gra_rec_end<0)
		return 0;

	if(IsZsRec(jys, gp_rec_num))
	{
		if(memcmp(&lpDest->lpZsGraph->Maxmin[0], &MaxMinData[lpDest->curJys][0],
				sizeof(MAXMIN_DATA)))
		{
			memcpy(&lpDest->lpZsGraph->Maxmin[0], &MaxMinData[lpDest->curJys][0],
				sizeof(MAXMIN_DATA));
			if(UDP_Server_Send_MaxMin10(lpDest->sd, jys, 0, NULL, FALSE, lpDest) <0)
			{
				ErrMsg(ghWndMain,"����Send_Gra10:��MaxMin��");
				return -1;
			}
		}
		if(memcmp(&lpDest->lpZsGraph->Maxmin[1], &MaxMinData[lpDest->curJys][1],
				sizeof(MAXMIN_DATA)))
		{
			memcpy(&lpDest->lpZsGraph->Maxmin[1], &MaxMinData[lpDest->curJys][1],
				sizeof(MAXMIN_DATA));
			if(UDP_Server_Send_MaxMin10(lpDest->sd, jys, 1, NULL, FALSE, lpDest) <0)
			{
				ErrMsg(ghWndMain,"����Send_Gra10:��MaxMin��1");
				return -1;
			}
		}
	}
	else
	{
		if(memcmp(&lpDest->lpGraph->mmp, &MmpData[lpDest->curJys].lpMmp[gp_rec_num],
				sizeof(MMP)))
		{
			memcpy(&lpDest->lpGraph->mmp, &MmpData[lpDest->curJys].lpMmp[gp_rec_num],
				sizeof(MMP));
			if(UDP_Server_Send_Mmp(lpDest->sd, jys, gp_rec_num, NULL, FALSE, lpDest) <0)
			{
				ErrMsg(ghWndMain,"����Send_Gra10:��Mmp��");
				return -1;
			}
		}
	}
	if(lpDest->cjss !=HqData[lpDest->curJys].lpRefData[gp_rec_num].cjss)
	{
		lpDest->cjss =HqData[lpDest->curJys].lpRefData[gp_rec_num].cjss;
		if(UDP_Server_Send_LitHq(lpDest->sd, jys, gp_rec_num, 0, NULL, FALSE, lpDest) <0)
		{
			ErrMsg(ghWndMain,"����Send_Gra10:��LitHq��");
			return -1;
		}
	}
	wsprintf(fileName, "%s\\%s.dat", GraphData[jys].szGraPath,
			HqData[jys].lpPreData[gp_rec_num].zqdm);
	hFile =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hFile ==HFILE_ERROR)
		return 0;
    
	if(_lread(hFile,&tmpHead, sizeof(GRA_HEAD))
			!=sizeof(GRA_HEAD))
	{
		ErrMsg(ghWndMain,"����Send_Gra10:�������ļ���");
		ErrMsg(ghWndMain, fileName);
		_lclose(hFile);
		return 0;
	}
    j=tmpHead.recCount;

	if(gra_rec_end >=j)
	{
		_lclose(hFile);
		return 0;
	}
	gra_rec_count =j-gra_rec_end;
    
	if(gra_rec_count<=0)
	{
		_lclose(hFile);
		return 0;
	}
	if(_llseek(hFile, sizeof(GRA_HEAD)+gra_rec_end*sizeof(GRA_DATA), FILE_BEGIN)
			==HFILE_ERROR)
	{
		//ErrMsg(ghWndMain,"����Send_Gra10:��λ�����ļ���");
		//ErrMsg(ghWndMain, fileName);
		_lclose(hFile);
		return 0;
	}
	hd =GlobalAlloc(GHND,(int)sizeof(GRA_DATA)*gra_rec_count);
	if(hd ==NULL)
	{
		ErrMsg(ghWndMain,"����Send_Gra10:�����ڴ�ʧ��");
		_lclose(hFile);
		return 0;
	}
	lpGraData =GlobalLock(hd);
	if(lpGraData ==NULL)
	{
		ErrMsg(ghWndMain,"����Send_Gra10:�����ڴ�ʧ��");
		_lclose(hFile);
		return 0;
	}
	
	if(_lread(hFile, lpGraData, sizeof(GRA_DATA)*gra_rec_count)
			!=sizeof(GRA_DATA)*gra_rec_count)
	{
		ErrMsg(ghWndMain,"����Send_Gra10:�������ļ���1");
		GlobalUnlock(hd);
		GlobalFree(hd);
		_lclose(hFile);
		return 0;
	}
	_lclose(hFile);
	
	if(gra_rec_count<MAX_GRA_SEND_COUNT)
	{
		strcpy(SendBuff,GRA10_HEAD);
		len =strlen(GRA01_HEAD)+sizeof(short);
		SendBuff[len++] =(char)jys;

		*((short *)&SendBuff[len]) =gp_rec_num;
		len +=sizeof(short);
		*((short *)&SendBuff[len]) =gra_rec_count;
		len +=sizeof(short);
		*((short *)&SendBuff[len]) =gra_rec_end;
		len +=sizeof(short);
	
		memcpy(&SendBuff[len], &lpGraData[0], gra_rec_count*sizeof(GRA_DATA));
		len +=gra_rec_count*sizeof(GRA_DATA);

		if(LOW_UDP_SendBuff("��ʱͼ10", lpDest->sd, SendBuff, len,NULL,lpDest)<0)
		{
			if(lpGraData!=NULL) 
			{
				GlobalUnlock(hd);
				GlobalFree(hd);
			}
			return -1;
		}
		else
		{
			if(lpGraData!=NULL)
			{
				GlobalUnlock(hd);
				GlobalFree(hd);
			}
			//lpDest->params[1] +=gra_rec_count;	
			  lpDest->graEnd+=gra_rec_count;
			return 0;
		}
	}

	sendCount =MAX_GRA_SEND_COUNT;
	for(i =0; i<gra_rec_count/MAX_GRA_SEND_COUNT; i++)
	{
		sendNum =i*MAX_GRA_SEND_COUNT;
		if(sendCount+sendNum >gra_rec_count)
			sendCount =gra_rec_count-sendNum;

		strcpy(SendBuff, GRA10_HEAD); 
		len =strlen(GRA01_HEAD)+sizeof(short);
		SendBuff[len++] =(char)jys;

		*((short *)&SendBuff[len]) =gp_rec_num;
		len +=sizeof(short);
		*((short *)&SendBuff[len]) =sendCount;
		len +=sizeof(short);
		*((short *)&SendBuff[len]) =sendNum+gra_rec_end;
		len +=sizeof(short);
	
		memcpy(&SendBuff[len], &lpGraData[sendNum], sendCount*sizeof(GRA_DATA));
		len +=sendCount*sizeof(GRA_DATA);
		if(sendCount)
		{
			*(short *)&SendBuff[strlen(GRA10_HEAD)] =len;
			if(LOW_UDP_SendBuff("��ʱͼ10", lpDest->sd, SendBuff, len, NULL,lpDest)<0)
			{
				if(lpGraData!=NULL) 
				{
					GlobalUnlock(hd);
					GlobalFree(hd);
				}
				return -1;
			}
		}
	}

	if(lpGraData!=NULL)
	{
		GlobalUnlock(hd);
		GlobalFree(hd);
	}
	//lpDest->params[1] +=gra_rec_count;	
	lpDest->graEnd+=gra_rec_count;
	return 0;
}


int UDP_Server_Send_Dp(int sd, struct sockaddr *lpdest, BOOL fThrd, LPDEST_INFO lpDest)
{
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	int len;
	
	memset(&SendBuff[0],0, sizeof(SendBuff));
	strcpy(SendBuff, DP_HEAD);
	len =strlen(DP_HEAD)+sizeof(short);
	
	memcpy(&SendBuff[len], &DpData, sizeof(DpData));
	len +=sizeof(DpData);
	
	*(short *)&SendBuff[strlen(DP_HEAD)] =len;
	
	return UDP_SendBuff("��������", sd, SendBuff, len,lpDest);
}

int UDP_Server_Send_Mmp(int sd, int jys, short rec_num,
						struct sockaddr *lpdest, BOOL fThrd, LPDEST_INFO lpDestInfo)
{
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	int len;

	memset(&SendBuff[0],0, sizeof(SendBuff));
	strcpy(SendBuff, MMP_HEAD); 
	len =strlen(MMP_HEAD)+sizeof(short);
	SendBuff[len++] =jys;

	*((short *)&SendBuff[len]) =rec_num;
	len +=sizeof(short);
	
	memcpy(&SendBuff[len], &MmpData[jys].lpMmp[rec_num],
			sizeof(MMP));
	len +=sizeof(MMP);
	*(short *)&SendBuff[strlen(MMP_HEAD)] =len;
	return UDP_SendBuff("����������", sd, SendBuff, len,lpDestInfo);
}

int UDP_Server_Send_MaxMin10(int sd, int jys, int maxmin,
							 struct sockaddr *lpdest, BOOL fThrd, LPDEST_INFO lpDestInfo)
{
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	int len;
	
	if(jys > 1 || maxmin >1) return -1;
	
	memset(&SendBuff[0],0, sizeof(SendBuff));
	MaxMinFillData(jys, maxmin);
	strcpy(SendBuff, MAXMIN10_HEAD); 
	len =strlen(MAXMIN10_HEAD)+sizeof(short);
	SendBuff[len++] =jys;
	SendBuff[len] =maxmin; 
	len++;

	memcpy(&SendBuff[len], &MaxMinData[jys][maxmin], sizeof(MAXMIN_DATA));
	len +=sizeof(MAXMIN_DATA);
	
	*(short *)&SendBuff[strlen(MAXMIN10_HEAD)] =len;
	return UDP_SendBuff("���а�", sd, SendBuff, len, lpDestInfo);
}

int UDP_Server_Send_GetZqmc(int sd, LPSTR lpTmp, struct sockaddr *lpdest)
{
	int jys, len, i, recCount, recNum;
	char SendBuff[2048];

	memset(&SendBuff[0],0, sizeof(SendBuff));
	jys =*lpTmp++;
	recCount =*(short *)lpTmp;
	lpTmp +=sizeof(short);
	strcpy(SendBuff, GETZQMC_HEAD);
	len =strlen(GETZQMC_HEAD)+sizeof(short);
	SendBuff[len++] =jys;
	*(short *)&SendBuff[len] =0;
	len +=sizeof(short);
	for(i =0; i<recCount; i++)
	{
		recNum =*(short *)lpTmp;
		lpTmp +=sizeof(short);
		if(recNum >=HqData[jys].recCount) 
			break;
		*(short *)&SendBuff[len] =recNum;
		len +=sizeof(short);
		memcpy(&SendBuff[len], HqData[jys].lpPreData[recNum].zqmc, MAX_ZQMC_SIZE);
		len +=MAX_ZQMC_SIZE;
	}
	*(short *)&SendBuff[strlen(GETZQMC_HEAD)+sizeof(short)+1] =i;
	*(short *)&SendBuff[strlen(GETZQMC_HEAD)] =len;
	if(UDP_SendBuff("��Ʊ����", sd, SendBuff, len, NULL)<0)
		return -1;
	return 0;
}

int UDP_Server_Send_Zx(int sd, LPSTR lpTmp, struct sockaddr *lpdest)
{
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	int len, file_len, read_len, read_total, start_pos;
	
	//if(FileTranLock)
	//	return 0;
	if(hfZx ==HFILE_ERROR)
		return 0;

	memset(&SendBuff[0],0, sizeof(SendBuff));
	start_pos =*(int *)lpTmp;

	_llseek(hfZx, 0, SEEK_SET);
	file_len =(int)_llseek(hfZx, 0, SEEK_END)-start_pos;
	if(file_len <=0)
		return 0;
	_llseek(hfZx, start_pos, SEEK_SET);

	read_len =1024;
	read_total =0;
	while(read_total <file_len)
	{
		while(ShoutBlockingHook());
		if(run_cancelled) break;
		if(file_len-read_total <read_len)
			read_len =file_len-read_total;
		strcpy(SendBuff, ZX_HEAD);
		len =strlen(ZX_HEAD)+sizeof(short);
		if(_lread(hfZx, &SendBuff[len], read_len)!=(UINT)read_len)
			return read_total;
		len +=read_len;
		*(short *)&SendBuff[strlen(ZX_HEAD)] =len;

		if(UDP_SendBuff("��Ѷ", sd, SendBuff, len,NULL)<0)
			return -1;
		read_total+=read_len;
	}
	return 0;
}

int SendDataDay(int sd, LPSTR lpTmp, struct sockaddr *lpdest)
{
	BYTE SendBuff[MAX_SEND_BUF_SIZE+1];
	int jys, i, len;
	char fileName[128];
	HFILE hFile;
	OFSTRUCT os;
	short gp_rec_num, data_rec_count, data_rec_end, sendCount, sendNum;

	jys =*lpTmp++;
	if(jys > 1) return -1;

	memset(&SendBuff[0],0, sizeof(SendBuff));
	gp_rec_num =*(short *)lpTmp;
	if(gp_rec_num >=HqData[jys].recCount)
		return -1;
	lpTmp +=sizeof(short);
	data_rec_end =*(int *)lpTmp;
	lpTmp +=sizeof(int);

	wsprintf(fileName, "%s\\%s\\%s.day", szDataPath, (jys ==0)?"SZDAY":"SHDAY",
			HqData[jys].lpPreData[gp_rec_num].zqdm);
	hFile =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hFile ==HFILE_ERROR)
	{
		return -1;
	}
    data_rec_count=(int) _llseek(hFile, 0l, FILE_END)/sizeof(DAY_DATA)-data_rec_end;
	if(data_rec_count<=0)
	{
		_lclose(hFile);
		return -1;
	}
	if(data_rec_count>500)
		data_rec_count =500;

	if(_llseek(hFile, data_rec_end*sizeof(DAY_DATA), FILE_BEGIN)
			==HFILE_ERROR)
	{
		ErrMsg(ghWndMain, "��λ�����ļ�ʧ��!");
		ErrMsg(ghWndMain, fileName);
		_lclose(hFile);
		return -1;
	}
	sendCount =MAX_GRA_SEND_COUNT;
	for(i =0; i<=data_rec_count/MAX_GRA_SEND_COUNT; i++)
	{
		sendNum =i*MAX_GRA_SEND_COUNT;
		if(sendCount+sendNum >data_rec_count)
			sendCount =data_rec_count-sendNum;

		strcpy(SendBuff, DATA_DAY_HEAD); 
		len =strlen(DATA_DAY_HEAD)+sizeof(short);
		SendBuff[len++] =(char)jys;

		*((short *)&SendBuff[len]) =gp_rec_num;
		len +=sizeof(short);
		*((short *)&SendBuff[len]) =sendCount;
		len +=sizeof(short);
		*((short *)&SendBuff[len]) =sendNum;
		len +=sizeof(short);
	
		if(_lread(hFile, &SendBuff[len], sizeof(DAY_DATA)*sendCount)
				!=sizeof(DAY_DATA)*sendCount)
		{
			ErrMsg(ghWndMain, "�������ļ�ʧ��!");
			_lclose(hFile);
			return -1;
		}
	
		len +=sendCount*sizeof(DAY_DATA);
		*(short *)&SendBuff[strlen(DATA_DAY_HEAD)] =len;
		
		if(sendCount)
		if(UDP_SendBuff("����01", sd, SendBuff, len,NULL)<0)
				break;
		ShoutBlockingHook();
	}
	_lclose(hFile);

	return 0;
}

int SendDayData(int sd, LPSTR lpTmp, struct sockaddr *lpdest)
{
	char *SendBuff;
	int jys,len,day;
	char fileName[128];
	HFILE hFile;
	OFSTRUCT os;
	short gp_rec_num, data_rec_count, data_rec_end, 
		  send_rec_count,sendCount, sendNum;
	char  IsAll =0,range=0; 
	DAY_DATA DayData; 

	jys =*lpTmp++;
	if(jys > 1) return -1;

	gp_rec_num =*(short *)lpTmp;
	if(gp_rec_num >=HqData[jys].recCount)
		return -1;
	lpTmp +=sizeof(short);

	data_rec_end =*(int *)lpTmp;
	if(data_rec_end<0)
		return -1;
	lpTmp +=sizeof(int);

	day =*(int *)lpTmp;

	wsprintf(fileName, "%s\\%s\\%s.day", szDataPath, (jys ==0)?"SZDAY":"SHDAY",
			HqData[jys].lpPreData[gp_rec_num].zqdm);
	hFile =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hFile ==HFILE_ERROR)
		return -1;
	data_rec_count=(int) _llseek(hFile, 0l, FILE_END)/sizeof(DAY_DATA);
	if(data_rec_count <=0)
		goto exit_send;

	if(data_rec_end ==0)
		IsAll =1;
	else if(data_rec_end>0)
	{
		if(data_rec_end>data_rec_count)
			IsAll =1;		
		else
		{
			_llseek(hFile, (data_rec_end-1)*sizeof(DAY_DATA), FILE_BEGIN);
			if(_lread(hFile, &DayData, sizeof(DAY_DATA))==sizeof(DAY_DATA))
			{
				if(DayData.day!=day)
					IsAll=1;
			}
			else
				IsAll =1;
		}
	}

	if(IsAll)
	{
		send_rec_count=data_rec_count;
		_llseek(hFile, 0L, FILE_BEGIN);	
	}
	else
	{
		send_rec_count=data_rec_count-data_rec_end;
		_llseek(hFile, data_rec_end*sizeof(DAY_DATA), FILE_BEGIN);	
	}
	if(send_rec_count>1500)
		send_rec_count=1500;

	SendBuff =GlobalAllocPtr(GHND,
		strlen(DATA_DAY_HEAD)+11+sizeof(DAY_DATA)*send_rec_count);
	if(SendBuff ==NULL)
	{
		_lclose(hFile);
		return -1;
	}

	sendCount =send_rec_count;
	sendNum =0;

	strcpy(SendBuff, DATA_DAY_HEAD);		  //7
	len =strlen(DATA_DAY_HEAD)+sizeof(short); //2
	SendBuff[len++] =(char)jys;				  //1	

	*((short *)&SendBuff[len]) =gp_rec_num;	   	
	len +=sizeof(short);                      //2 
	*((short *)&SendBuff[len]) =sendCount;	  
	len +=sizeof(short);                      //2 
	*((short *)&SendBuff[len]) =sendNum;      
	len +=sizeof(short);                      //2  
	SendBuff[len++] =IsAll;					  //1	
    SendBuff[len++] =range;					  //1	

	if(sendCount)
	if(_lread(hFile, &SendBuff[len], sizeof(DAY_DATA)*sendCount)
			!=sizeof(DAY_DATA)*sendCount)
	goto exit_send;
	
	len +=sendCount*sizeof(DAY_DATA);
	*(short *)&SendBuff[strlen(DATA_DAY_HEAD)] =len;
		
	if(sendCount)
	SendMemData(sd,SendBuff, len);

exit_send:
	GlobalFreePtr(SendBuff);
	_lclose(hFile);
	return 0;
}


typedef struct tag_UDP_SEND_INFO
{
	int sd;
	int len;
	BYTE version;
	LPDEST_INFO lpDestInfo;
	struct sockaddr dest;
	char SendBuf[MAX_SEND_BUF_SIZE+1];
	char filename[80];
	HANDLE hThread;
}UDP_SEND_INFO, *LPUDP_SEND_INFO;

//////////////////////////////////////////////////////
//Function : send data pack to client
//Return   :
//         return value >0,return send data number
//         return value =0,no data send
//         return value <0,a net error come,we must
//         close the socket or stop commuate
//Modi date:
//         1998/03/23 

int UDP_SendBuff(LPSTR lpMsg, int sd, LPSTR lpBuf,
		int len, LPDEST_INFO lpDestInfo)
{
	int j =0,	//һ�η��͵Ľ��
		e,      //SOCKET ������
		x=0,    //�ѷ������ݰ���
		k,
		tlen;   //���ݰ��ܳ�
	char SendBuf[MAX_SEND_BUF_SIZE+sizeof(short)+1];

	MsgSend(lpMsg);

	if(len+sizeof(short)+1>MAX_SEND_BUF_SIZE)
	{
		ErrMsg(ghWndMain, "����UDP_SendBuff:���ͼ�¼̫��");
		return (-1);
	}

	memset(SendBuf,0,MAX_SEND_BUF_SIZE+1+sizeof(short));
    SendBuf[0]=START_SIGN;
    *(short *)&SendBuf[1]=(short )len;
	memcpy(&SendBuf[1+sizeof(short)],lpBuf,len);

	if(lpDestInfo!=NULL)
	{
		if(lpDestInfo->isDead) 
			return 0;
	}
    tlen = len+1+sizeof(short);

	for(k=0;k<200;k++)
	{
		if(run_cancelled)
			break;
		j =send(sd, &SendBuf[x], tlen -x, 0);
		if (j == SOCKET_ERROR)
		{
			e =WSAGetLastError();
			switch(e)
			{
				case WSANOTINITIALISED : 
					//A successful WSAStartup must occur 
					//before using this function. 
					ErrMsg(ghWndMain,"WSANOTINITIALISED");
					return 0;
				break;
				case WSAENETDOWN :
					//The network subsystem has failed. 
					ErrMsg(ghWndMain,"WSAENETDOWN");
					return x;
				break;
				case WSAEACCES:
					//The requested address is a broadcast
					//address, but the appropriate flag was not set. 
					ErrMsg(ghWndMain,"WSAEACCES");
					return 0;
				break;
				case WSAEINTR:
					//The (blocking) call was canceled through 
					//WSACancelBlockingCall. 
					return x;
				break;
				case WSAEINPROGRESS:
					//A blocking Windows Sockets 1.1 call is
					//in progress, or the service provider is still 
					//processing a callback function. 
					ShoutBlockingHook();
					Sleep(30);
				break;
				case WSAEFAULT:
					//The buf parameter is not totally contained in
					//a valid part of the user address space.
					return x;
				break;
				case WSAENETRESET:
					//The connection has been broken due to the 
					//remote host resetting. 
					HqDestStopBySd(sd);
					return -1;
				break;	
                case WSAENOBUFS:
					//No buffer space is available. 
					return x;
				break;
				case WSAENOTCONN:
					//The socket is not connected.
					HqDestStopBySd(sd);
					return -1;
				break;
				case WSAENOTSOCK:
					//The descriptor is not a socket. 
					return -1;
				break;
				case WSAEOPNOTSUPP:
					//MSG_OOB was specified, but the socket
					//is not stream style such as type SOCK_STREAM, out-of-band data is not supported in the communication domain associated with this socket, or the socket is unidirectional and supports only receive operations. 
					return x;
				break;
				case WSAESHUTDOWN:
					//The socket has been shut down; it is not 
					//possible to send on a socket after 
					//shutdown has been invoked with how set 
					//to SD_SEND or SD_BOTH. 
					return -1;
				break;
				case WSAEWOULDBLOCK:
					//The socket is marked as nonblocking and 
					//the requested operation would block. 
					ShoutBlockingHook();
					if(lpDestInfo!=NULL)
					{
						if(lpDestInfo->isDead) return 0;
					}
					Sleep(30);
				break;
				case WSAEMSGSIZE:
					//The socket is message oriented, and the 
					//message is larger than the 
					//maximum supported by the underlying transport. 
					return x;
				break;
				case WSAEHOSTUNREACH:					
					//The remote host cannot be reached from this 
					//host at this time. 
					return x;
				break;
				case WSAEINVAL:
					//The socket has not been bound with bind, or 
					//an unknown flag was specified,
					return -1;
				break;
				case WSAECONNABORTED:
					//The virtual circuit was terminated due to a 
					//time-out or other failure. The application 
					//should close the socket as it is no longer usable. 
					HqDestStopBySd(sd);
					return -1;
				break;
				case WSAECONNRESET:
					//The virtual circuit was reset by the remote 
					//side executing a "hard" or "abortive" close. For 
					//UPD sockets, the remote host was unable to deliver
					//a previously sent UDP datagram and responded with 
					//a "Port Unreachable" ICMP packet. The application 
					//should close the socket as it is no longer usable. 
					HqDestStopBySd(sd);
					return -1;
				break;
				case WSAETIMEDOUT:
					//The connection has been dropped, because of a network
					//failure or because the system on the other end went down 
					//without notice. 
					HqDestStopBySd(sd);
					return -1;
				break;
				default:
					return -1;
			}
		}
		else
		{
			x+=j;
			if(x!=tlen)
				ShoutBlockingHook();
			else
			break;
		}
	}
	return x;
}

int LOW_UDP_SendBuff(LPSTR lpMsg, int sd, LPSTR lpBuf,
	int len, struct sockaddr *lpdest, LPDEST_INFO lpDestInfo)
{
	int j =0,e,x=0,tlen,k;
	char SendBuf[sizeof(short)+1+MAX_SEND_BUF_SIZE];

	MsgSend(lpMsg);

	if(len+sizeof(short)+1>MAX_SEND_BUF_SIZE)
	{
		ErrMsg(ghWndMain, "����UDP_SendBuff:���ͼ�¼̫��");
		return (-1);
	}

	memset(SendBuf,0,MAX_SEND_BUF_SIZE);
    SendBuf[0]=(char)0xf0;
    *(short *)&SendBuf[1]=(short )len;
	memcpy(&SendBuf[1+sizeof(short)],lpBuf,len);

	if(lpDestInfo!=NULL)
	{
		if(lpDestInfo->isDead) return 0;
	}
    tlen = len+1+sizeof(short);
	for(k=0;k<20;k++)
	{
		if(run_cancelled)
			break;
		j =send(sd, &SendBuf[x], tlen -x, 0);
		if (j == SOCKET_ERROR)
		{
			e =WSAGetLastError();
			switch(e)
			{
				case WSANOTINITIALISED : 
					//A successful WSAStartup must occur 
					//before using this function. 
					return 0;
				break;
				case WSAENETDOWN :
					//The network subsystem has failed. 					
					return x;
				break;
				case WSAEACCES:
					//The requested address is a broadcast
					//address, but the appropriate flag was not set. 
					return 0;
				break;
				case WSAEINTR:
					//The (blocking) call was canceled through 
					//WSACancelBlockingCall. 
					return x;
				break;
				case WSAEINPROGRESS:
					//A blocking Windows Sockets 1.1 call is
					//in progress, or the service provider is still 
					//processing a callback function. 
					ShoutBlockingHook();
					Sleep(40);
				break;
				case WSAEFAULT:
					//The buf parameter is not totally contained in
					//a valid part of the user address space.
					return x;
				break;
				case WSAENETRESET:
					//The connection has been broken due to the 
					//remote host resetting. 
					HqDestStopBySd(sd);
					return -1;
				break;	
                case WSAENOBUFS:
					//No buffer space is available. 
					return x;
				break;
				case WSAENOTCONN:
					//The socket is not connected.
					HqDestStopBySd(sd);
					return -1;
				break;
				case WSAENOTSOCK:
					//The descriptor is not a socket. 
					return -1;
				break;
				case WSAEOPNOTSUPP:
					//MSG_OOB was specified, but the socket
					//is not stream style such as type SOCK_STREAM, out-of-band data is not supported in the communication domain associated with this socket, or the socket is unidirectional and supports only receive operations. 
					return x;
				break;
				case WSAESHUTDOWN:
					//The socket has been shut down; it is not 
					//possible to send on a socket after 
					//shutdown has been invoked with how set 
					//to SD_SEND or SD_BOTH. 
					return -1;
				break;
				case WSAEWOULDBLOCK:
					//The socket is marked as nonblocking and 
					//the requested operation would block. 
					ShoutBlockingHook();
					if(lpDestInfo!=NULL)
					{
						if(lpDestInfo->isDead) return 0;
					}
					Sleep(40);
//					k++;
				break;
				case WSAEMSGSIZE:
					//The socket is message oriented, and the 
					//message is larger than the 
					//maximum supported by the underlying transport. 
					return x;
				break;
				case WSAEHOSTUNREACH:					
					//The remote host cannot be reached from this 
					//host at this time. 
					return x;
				break;
				case WSAEINVAL:
					//The socket has not been bound with bind, or 
					//an unknown flag was specified,
					return -1;
				break;
				case WSAECONNABORTED:
					//The virtual circuit was terminated due to a 
					//time-out or other failure. The application 
					//should close the socket as it is no longer usable. 
					HqDestStopBySd(sd);
					return -1;
				break;
				case WSAECONNRESET:
					//The virtual circuit was reset by the remote 
					//side executing a "hard" or "abortive" close. For 
					//UPD sockets, the remote host was unable to deliver
					//a previously sent UDP datagram and responded with 
					//a "Port Unreachable" ICMP packet. The application 
					//should close the socket as it is no longer usable. 
					HqDestStopBySd(sd);
					return -1;
				break;
				case WSAETIMEDOUT:
					//The connection has been dropped, because of a network
					//failure or because the system on the other end went down 
					//without notice. 
					HqDestStopBySd(sd);
					return -1;
				break;
				default:
					HqDestStopBySd(sd);
					return -1;
			}
		}
		else
		{
			x+=j;
			if(x !=tlen)
				ShoutBlockingHook();
			else
			break;
		}
	}
	return x;
}

int Thrd_SendBuff(LPSTR lpMsg, int sd, LPSTR lpBuf,
				  int len, struct sockaddr *lpdest, LPDEST_INFO lpDestInfo)
{
	HANDLE hThrd;
	HANDLE hMem;
	LPUDP_SEND_INFO lpSendInfo;
	LONG lThreadId;
	
	MsgSend(lpMsg);

	if(lpDestInfo!=NULL)
	{
		if(lpDestInfo->isDead)
		{
			ErrMsg(ghWndMain, "����Thrd_SendBuff:Ŀ���Ѳ��");
			return 0;
		}
	}

	hMem =GlobalAlloc(GHND, sizeof(UDP_SEND_INFO));
	if(hMem ==NULL)
	{
		ErrMsg(ghWndMain, "����Thrd_SendBuff:���ܷ��䷢�ͻ�����!");
		return -1;
	}
	lpSendInfo =(LPUDP_SEND_INFO)GlobalLock(hMem);
	if(lpSendInfo ==NULL)
	{
		ErrMsg(ghWndMain, "����Thrd_SendBuff:�����������ͻ�����!");
		GlobalFree(hMem);
		return -1;
	}
	memcpy(&lpSendInfo->dest, lpdest, sizeof(struct sockaddr));

	memset(&lpSendInfo->SendBuf[0],0,sizeof(lpSendInfo->SendBuf));
    lpSendInfo->SendBuf[0]=(char)0xf0;
	*(short*)&lpSendInfo->SendBuf[1]=(short )len;

	memcpy(&lpSendInfo->SendBuf[1+sizeof(short )], lpBuf, len);

	lpSendInfo->len =len;
	lpSendInfo->lpDestInfo =lpDestInfo;
	lpSendInfo->sd =sd;
	GlobalUnlock(hMem);
	
	hThrd =CreateThread(NULL, 0,
		(LPTHREAD_START_ROUTINE)TF_SendBuff,
		hMem, CREATE_SUSPENDED, (LPDWORD)&lThreadId);
	if(!hThrd)
	{
		GlobalUnlock(hMem);
		GlobalFree(hMem);
		ErrMsg(ghWndMain, "����Thrd_SendBuff:���ܽ����߳�!");
		return -1;
	}
	lpSendInfo->hThread =hThrd;

	SetThreadPriority(hThrd, THREAD_PRIORITY_NORMAL);
	ResumeThread(hThrd);
	
	return 0;
}


long TF_SendBuff(HANDLE phMem)
{
	static BOOL fSending =FALSE;
	int j =0,x=0,tlen;
	HANDLE hThrd =NULL;
	LPUDP_SEND_INFO lpSendInfo =NULL;
	HANDLE hMem =phMem;
	
	lpSendInfo =GlobalLock(hMem);
	if(lpSendInfo ==NULL)
	{
		ErrMsg(ghWndMain, "����TF_SendBuff:Ŀ����Ϣָ��Ϊ��!");
		goto thread_exit;
	}
	fSending =TRUE;
	tlen =lpSendInfo->len+1+sizeof(short);
	for(;;)
	{
		if(lpSendInfo->lpDestInfo!=NULL)
			if(lpSendInfo->lpDestInfo->isDead) 
		{
				ErrMsg(ghWndMain, "����TF_SendBuff:Ŀ���Ѳ��");
				break;
		}
		if(PROTO_USE ==PROTO_UDP)
			j =sendto(lpSendInfo->sd, &lpSendInfo->SendBuf[x],
				tlen -x, 0, &lpSendInfo->dest,
				sizeof(struct sockaddr));
		else
			j =send(lpSendInfo->sd, &lpSendInfo->SendBuf[x],tlen -x, 0);
		if (j == SOCKET_ERROR)
		{
			if (h_errno == WSAEWOULDBLOCK)
			{
				Sleep(10);
				continue;
			}
			else
			{
				ErrMsg(NULL, lpSendInfo->SendBuf);
				ErrMsg(ghWndMain, GetError("����TF_SendBuff():sendto(),������Ϣ"));
			}
			j =-1;
			break;
		}
		if(x+j!=tlen)
			x+=j;
		else
			break;
	}
thread_exit:
	fSending =FALSE;
	if(lpSendInfo)
	{
		hThrd =lpSendInfo->hThread;
		GlobalUnlock(hMem);
	}
	if(hMem) GlobalFree(hMem);	
	if(hThrd!=NULL)
		CloseHandle(hThrd);

	ExitThread(0);
	return 0;
}

char de[43]={'E','A','W','S','8',':','J','>','Z','M','V','Q','@','1','P','D',
       'I','0','=','L','N','5','K','O','R','X','T','U','F','Y','G','?',
       '7','<','6',';','H','2','B','9','3','C','4'};

uchar key[9];
int UDP_ReadJy(int sd,char * RecvBuf,int len,struct sockaddr_in dest)
{               
	int i,j=0,ret;
	uchar *lpTmp;
	static uchar *b; 
	LPJY_DEST lpDestTmp;
	signed char buf1[DATALENGTH];

	//if(!fUseJy) return 0;

	for(i=0;i<len;i++)
	{
		if(RecvBuf[i]>='0'&&RecvBuf[i]<='Z')
		{
			RecvBuf[i]=de[RecvBuf[i]-'0'];
		}
	}

	if(len ==0) return 0;	
	lpTmp =&RecvBuf[0];

	if(len>=6+100&&strncmp("RSAKEY", &lpTmp[len -6], 6) ==0)
	{
		lpTmp[len -6] =0;
		StrToByt(&lpTmp[len -6 -100],buf1);
		DecipherDesKey(buf1,R,SK,key);
		lpTmp[len -6 -100]=0;
		len -=(6+100);
	}
	else
		strcpy(key,"98124325");	

	for(j=0;j<2;j++)
	{
		if(strncmp(JY_CHKUSR_HEAD, lpTmp, strlen(JY_CHKUSR_HEAD)) ==0)
		{
			MsgRecv("��齻���û�");
			lpTmp +=strlen(JY_CHKUSR_HEAD);
			len -=strlen(JY_CHKUSR_HEAD);
			if(len <sizeof(JY_ASK_CHKUSR))
			{
				SendMsg(sd,"�������׵�¼��");
				return -1;
			}
			if((ret =Jy_ChkUsr(sd, *(short *)lpTmp,(LPJY_ASK_CHKUSR)(lpTmp+2))) <0)
			{
				Jy_SendRet(sd, REQ_CHKUSR, (char)ret, *(short *)lpTmp);
				return -1;
			}
			break;
		}
		else if(strncmp(JY_ZQSXX_HEAD, lpTmp, strlen(JY_ZQSXX_HEAD)) ==0)
		{
			Jy_Zqsxx(sd);
			break;
		}
		else if(strncmp(JY_CHGPWD_HEAD, lpTmp, strlen(JY_CHGPWD_HEAD)) ==0)
		{
			MsgRecv("�Ľ�������");
			lpTmp +=strlen(JY_CHGPWD_HEAD);
			len -=strlen(JY_CHGPWD_HEAD);
			if(len <sizeof(JY_ASK_CHGPWD))
				return -1;
		
			if((ret =Jy_ChgPwd(sd, *(short *)lpTmp,(LPJY_ASK_CHGPWD)(lpTmp+2))) <0)
			{
				Jy_SendRet(sd, REQ_CHGPWD, (char)ret, *(short *)lpTmp);
				return -1;
			}
			break;
		}               
		else if(strncmp(JY_BUYSELL_HEAD, lpTmp, strlen(JY_BUYSELL_HEAD)) ==0)
		{
			MsgRecv("��Ʊ����");
			lpTmp +=strlen(JY_BUYSELL_HEAD);
			len -=strlen(JY_BUYSELL_HEAD);
			if(len <sizeof(JY_ASK_BUYSELL))
			{
				//SendError(sd, (struct sockaddr *)&dest);
				return -1;
			}
	
			if((ret =Jy_BuySell(sd,*(short *)lpTmp,(LPJY_ASK_BUYSELL)(lpTmp+2))) <0)
			{
				Jy_SendRet(sd, REQ_BUYSEL, (char)ret, *(short *)lpTmp);
				return -1;
			}
			break;
		}       
		else if(strncmp(JY_CANCEL_HEAD, lpTmp, strlen(JY_CANCEL_HEAD)) ==0)
		{
			MsgRecv("����ί��");
			lpTmp +=strlen(JY_CANCEL_HEAD);
			len -=strlen(JY_CANCEL_HEAD);
			if(len <sizeof(JY_ASK_CANCEL))
			{
				return -1;
			}
	
			if((ret =Jy_Cancel(sd, *(short *)lpTmp,(LPJY_ASK_CANCEL)(lpTmp+2))) <0)
			{
				Jy_SendRet(sd, REQ_CANCEL, (char)ret, *(short *)lpTmp);
				return -1;
			}
			break;
		}       
		else if(strncmp(JY_YECX_HEAD, lpTmp, strlen(JY_YECX_HEAD)) ==0)
		{
			MsgRecv("����ѯ");
			lpTmp +=strlen(JY_YECX_HEAD);
			len -=strlen(JY_YECX_HEAD);
			if(len <sizeof(JY_ASK_YECX))
			{
				return -1;
			}
		
			if((ret =Jy_Yecx(sd, *(short *)lpTmp,(LPJY_ASK_YECX)(lpTmp+2))) !=0)
			{
				Jy_SendRet(sd, REQ_YECX, (char)ret, *(short *)lpTmp);
				return -1;
			}
			break;
		}
		else if(strncmp(JY_CJCX_HEAD, lpTmp, strlen(JY_CJCX_HEAD)) ==0)
		{
			MsgRecv("�ɽ���ѯ");
			lpTmp +=strlen(JY_CJCX_HEAD);
			len -=strlen(JY_CJCX_HEAD);
			if(len <sizeof(JY_ASK_CJCX))
			{
				return -1;
			}
		
			if((ret =Jy_Cjcx(sd, *(short *)lpTmp,(LPJY_ASK_CJCX)(lpTmp+2))) !=0)
			{
				Jy_SendRet(sd, REQ_CJCX, (char)ret, *(short *)lpTmp);
				return -1;
			}
			break;
		}                               
		else if(strncmp(JY_WTCX_HEAD, lpTmp, strlen(JY_WTCX_HEAD)) ==0)
		{
			MsgRecv("ί�в�ѯ");
			lpTmp +=strlen(JY_WTCX_HEAD);
			len -=strlen(JY_WTCX_HEAD);
			if(len <sizeof(JY_ASK_WTCX))
			{
				return -1;
			}
		
			if((ret =Jy_Wtcx(sd, *(short *)lpTmp,(LPJY_ASK_WTCX)(lpTmp+2)))!=0)
			{
				Jy_SendRet(sd, REQ_WTCX, (char)ret, *(short *)lpTmp);
				return -1;
			}
			break;
		}
		else if(strncmp(JY_EXIT, lpTmp, strlen(JY_EXIT)) ==0)
		{
			MsgRecv("�����û��˳�");
			JyDest_Exit(sd);
			break;
		}
		else
		{
		  lpDestTmp =GetJyDestBySd(sd);	
		  if(lpDestTmp !=NULL)
		  {
			  if(lpDestTmp->DesKey[0]!=0)
			  {
					strncpy(key,lpDestTmp->DesKey,8);
					key[8]=0;
			  }
		  }
  		  if(desinit(key)!=0) 
		  {
				ErrMsg(ghWndMain,"���ܳ�ʼ��KEY");
				return(0);
		  }

  		  for(b=lpTmp,i=len;i>0;i-=8,b+=8)
		  {
  			if(i<8) break;
  			if(ecbdecode(b,b)!=0)
			{
				ErrMsg(ghWndMain,"ecbdecode()��");
				return(0);
			}
		  }
		}
	}
	return 0;
}

int ShoutBlockingHook(void)
{
	MSG msg;

	if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
	{
		if(!ghWndMain || !IsDialogMessage(ghWndMain, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);   
			if(msg.message ==WM_QUIT)
			{
				PostQuitMessage(0);
				run_cancelled =TRUE;               
				return FALSE;
			}
		}            
		return TRUE;
	}
	return FALSE;
}

int PASCAL FAR WSAsperror(int errorcode, char far * buf, int len)
{
	int err_len;
    
	if (errorcode == 0)
		errorcode = WSABASEERR;
	if (errorcode < WSABASEERR)
		return 0;
	    
	err_len = LoadString(ghInstance,errorcode,buf,len);
	
	return err_len;
}

LPSTR GetError(LPSTR err_prefix)
{
	int wsa_err;
	char errbuf[500];
	static char prbuf[600];
	
	wsa_err =WSAGetLastError(); 
	
	WSAsperror(wsa_err, (LPSTR)errbuf, 500);
	    
	wsprintf((LPSTR)prbuf, "%s:%s", (LPSTR) err_prefix, (LPSTR)errbuf);
	
	return &prbuf[0];  
}

void SendError(int sd, struct sockaddr * lpdest)
{
	int len;
	char SendBuff[20];
	
	memset(SendBuff,0,sizeof(SendBuff));
	strcpy(SendBuff, ERROR_HEAD);
	len =strlen(ERROR_HEAD)+sizeof(short);
	SendBuff[len++] =0;
	*(short *)&SendBuff[strlen(ERROR_HEAD)] =len;
	UDP_SendBuff("���ʹ���", sd, SendBuff, len, NULL);
}

int SendMsg(int sd, LPSTR lpMsg)
{
	char SendBuff[400];
	int len;
	
	memset(SendBuff,0,sizeof(SendBuff));
	strcpy(SendBuff, MSG_HEAD);
	len =strlen(MSG_HEAD)+sizeof(short);
	strcat(&SendBuff[len], lpMsg);
	len +=strlen(lpMsg);
	SendBuff[len++] =0;
	*(short *)&SendBuff[strlen(MSG_HEAD)] =len;

	return(UDP_SendBuff(lpMsg, sd, SendBuff, len, NULL));
}

int MaxMinFillData(int jys, int maxmin)
{
	int i, j;
	
	for(i =0; i<4; i++)
		for(j =0; j<10; j++)
		{
			/////////////
			if(MaxMinData[jys][maxmin].recNum[i][j] >=HqData[jys].recCount) return -1;
			MaxMinData[jys][maxmin].MaxMin[i][j].zjcj
				=HqData[jys].lpRefData[MaxMinData[jys][maxmin].recNum[i][j]].zjcj;
			MaxMinData[jys][maxmin].MaxMin[i][j].zdf
				=HqData[jys].lpRefData[MaxMinData[jys][maxmin].recNum[i][j]].zdf;
			MaxMinData[jys][maxmin].MaxMin[i][j].cjss
				=HqData[jys].lpRefData[MaxMinData[jys][maxmin].recNum[i][j]].cjss;
		}
	return 0;
}

BOOL IsZsRec(int jys, short rec_num)
{
	if(jys ==0)
	{
		if(!strncmp(HqData[jys].lpPreData[rec_num].zqdm, "99", 2))
			return TRUE;
	}
	else
		if(!strncmp(HqData[jys].lpPreData[rec_num].zqdm, "0000", 4)
			&&(HqData[jys].lpPreData[rec_num].zqdm[4] =='0'
				||HqData[jys].lpPreData[rec_num].zqdm[4] =='1'))
			return TRUE;
	
	return FALSE;
}

BOOL ZlibCompressFile(char *infile,char *outfile)
{
	gzFile out;
	char buf[4096];
	int bytes;
	HFILE hFile;
	OFSTRUCT os;
	
	hFile =OpenFile(infile, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hFile==HFILE_ERROR)
		return FALSE;
	out = gzopen(outfile, "wb6 ");
	for(;;)
	{
		bytes =_lread(hFile, buf, sizeof(buf));
		if(bytes <=0) break;
		if (gzwrite(out, buf, (unsigned)bytes) != bytes) 
		{
			ErrMsg(NULL,"ZLIBѹ���ļ�ʧ�ܣ�");
			gzclose(out);
			return FALSE;
		}		
		if(bytes<sizeof(buf))
			break;
	}
	_lclose(hFile);
	if (gzclose(out) != Z_OK) 
		ErrMsg(NULL,"failed gzclose");
	return TRUE;
}

BOOL ZlibCompressMemFile(char *buf,int len,char *outfile)
{
	gzFile out;

    out = gzopen(outfile, "wb6 ");
    if (out == NULL)
	{
        ErrMsg(NULL,"zlib can not open out file");
		return FALSE;
    }
	if (gzwrite(out, buf, (unsigned)len) != len) 
	{
		ErrMsg(NULL,"ZLIBѹ���ļ�ʧ�ܣ�");
		gzclose(out);
		return FALSE;
	}
	if (gzclose(out) != Z_OK) 
		ErrMsg(NULL,"failed gzclose");
	return TRUE;
}

void ReadySysFile(void)
{
	char src[128],tag[128];

	sprintf(src,"%s\\sys\\sysinfo.dat",szDataPath);
	sprintf(tag,"%s\\sys\\sysinfo.lzw",szDataPath);

	if(!CompressFile(src,tag))
	{
		ErrMsg(NULL,"compress Config file Failed");
	}
	sprintf(tag,"%s\\sys\\sysinfo.gz",szDataPath);
	if(!ZlibCompressFile(src,tag))
	{
		ErrMsg(NULL,"zlib compress Config file Failed");
	}

	sprintf(src,"%s\\sys\\help.txt",szDataPath);
	sprintf(tag,"%s\\sys\\help.lzw",szDataPath);

	if(!CompressFile(src,tag))
	{
		ErrMsg(NULL,"compress help file Failed");
	}
	sprintf(tag,"%s\\sys\\help.gz",szDataPath);
	if(!ZlibCompressFile(src,tag))
	{
		ErrMsg(NULL,"compress help file Failed");
	}
}

#define		MPAK_BEGIN	'B'

#define		SPAK_NOCOM	'e'
#define		MPAK_NOCOM	'E'

#define		SPAC_COMPE	'f'	
#define		MPAC_COMPE	'F'  


#define		GZ_STAR		1
#define		GZ_SING		2
#define		GZ_CONT		3
#define		GZ_OVER		4

long TF_Send_Clt_Init_Files(HANDLE hMem)
{
	HANDLE hThrd =NULL;
	LPUDP_SEND_INFO lpSendInfo =NULL;
	SEND_FILE_FRAME	SendFileFrame;
	char sendBuff[2048],filename[80],temp[80];
    UINT tlen,  //���ݰ��ܳ�
		 alen,  //һ�������ݰ�������
		 slen,  //�������ݰ���
		 len;   //���ݰ��Ѵ����
    int i,status,mlen;
	long j;
	HFILE hFile;
	OFSTRUCT os;
	BOOL comp;

	lpSendInfo =GlobalLock(hMem);
	if(lpSendInfo ==NULL)
	{
		ErrMsg(ghWndMain, "����TF_Send_Clt_Init_Files:Ŀ����Ϣָ��Ϊ��!");
		goto thread_exit;
	}
	for(i=0;i<4;i++)
	{
		if(i==0)
		{
			//�������ļ�
			if(lpSendInfo->version<11)
				continue;
			if(lpSendInfo->version==11)
				sprintf(filename, "%s\\sys\\sysinfo.lzw",szDataPath);
			if(lpSendInfo->version==12)
				sprintf(filename, "%s\\sys\\sysinfo.gz",szDataPath);
			if(access(filename,0)!=0)
				continue;
		}
		if(i==1)
		{
			//����������
			if(lpSendInfo->version==11)
			{
				sprintf(filename, "%s\\%d.lzw.comp", szDataPath,lpSendInfo->sd);
				sprintf(temp, "%s\\szhq.202", HqDataPath);
				if(access(temp,0)!=0)
					sprintf(temp, "%s\\szhq.dat", HqDataPath);

				mlen =*LzwData202[0].recCount*sizeof(HQ_REF_DATA_V202)+sizeof(short);
				comp =CompressMemFile((char *)LzwData202[0].recCount,mlen,filename);
				if(!comp)
				{
					sprintf(filename, "%s\\szhq.dat", HqDataPath);
					lpSendInfo->version=10;
				}
			}
			if(lpSendInfo->version>11)
			{
				sprintf(filename, "%s\\%d.lzw.comp", szDataPath,lpSendInfo->sd);
				sprintf(temp, "%s\\szhq.202", HqDataPath);
				if(access(temp,0)!=0)
					sprintf(temp, "%s\\szhq.dat", HqDataPath);

				mlen =*LzwData202[0].recCount*sizeof(HQ_REF_DATA_V202)+sizeof(short);
				comp =ZlibCompressMemFile((char *)LzwData202[0].recCount,mlen,filename);
				if(!comp)
				{
					sprintf(filename, "%s\\szhq.dat", HqDataPath);
					lpSendInfo->version=10;
				}
			}
			if(lpSendInfo->version<11)
			{
				sprintf(filename, "%s\\szhq.dat", HqDataPath);
			}
		}
		if(i==2)
		{
			//���Ϻ�����
			if(lpSendInfo->version==11)
			{
				sprintf(filename, "%s\\%d.lzw.comp", szDataPath,lpSendInfo->sd);
				sprintf(temp, "%s\\shhq.202", HqDataPath);
				if(access(temp,0)!=0)
					sprintf(temp, "%s\\shhq.dat", HqDataPath);

				mlen =*LzwData202[1].recCount*sizeof(HQ_REF_DATA_V202)+sizeof(short);
				comp =CompressMemFile((char *)LzwData202[1].recCount,mlen,filename);
				if(!comp)
				{
					sprintf(filename, "%s\\shhq.dat", HqDataPath);
					lpSendInfo->version=10;
				}
			}
			if(lpSendInfo->version>11)
			{
				sprintf(filename, "%s\\%d.lzw.comp", szDataPath,lpSendInfo->sd);
				sprintf(temp, "%s\\shhq.202", HqDataPath);
				if(access(temp,0)!=0)
					sprintf(temp, "%s\\shhq.dat", HqDataPath);

				mlen =*LzwData202[1].recCount*sizeof(HQ_REF_DATA_V202)+sizeof(short);
				comp =ZlibCompressMemFile((char *)LzwData202[1].recCount,mlen,filename);				if(!comp)
				{
					sprintf(filename, "%s\\shhq.dat", HqDataPath);
					lpSendInfo->version=10;
				}
			}
			if(lpSendInfo->version<11)
			{
				sprintf(filename, "%s\\shhq.dat", HqDataPath);
			}
		}
		if(i==3)
		{
			//�Ͱ����ļ�
			if(lpSendInfo->version==11)
				sprintf(filename, "%s\\sys\\help.lzw",szDataPath);
			if(lpSendInfo->version<11)
				sprintf(filename, "%s\\sys\\help.txt",szDataPath);
			if(lpSendInfo->version==12)
				sprintf(filename, "%s\\sys\\help.gz",szDataPath);
		}

		hFile =OpenFile(filename, &os, OF_SHARE_DENY_NONE|OF_READ);
		if(hFile==HFILE_ERROR)
			continue;
		if((tlen=(UINT)_llseek(hFile, 0, FILE_END))==HFILE_ERROR)
		{
			ErrMsg(ghWndMain, "����TF_Send_Clt_Init_Files:���ܶ�λ���ļ�β!");
			_lclose(hFile);
			goto thread_exit;
		}
		if(_llseek(hFile, 0, FILE_BEGIN)==HFILE_ERROR)
		{
			ErrMsg(ghWndMain, "����TF_Send_Clt_Init_Files:���ܶ�λ���ļ�ͷ!");
			_lclose(hFile);
			goto thread_exit;
		}

		if(i==0)
			strcpy(SendFileFrame.filename,"sysinfo.dat");
		if(i==1)
			strcpy(SendFileFrame.filename,"szhq.dat");
        if(i==2)
			strcpy(SendFileFrame.filename,"shhq.dat");
		if(i==3)
			strcpy(SendFileFrame.filename,"help.txt");

		if(tlen<=2000)                 //С���ݰ� 
		{
			SendFileFrame.filelen=tlen;
			strcpy(sendBuff,SEND_FILE_HEAD);
			len =strlen(SEND_FILE_HEAD);
			if(lpSendInfo->version>10) //ѹ��
				SendFileFrame.sign ='f';
			else                       //��ѹ��  
				SendFileFrame.sign ='e';
			if(lpSendInfo->version==12)
				SendFileFrame.sign =GZ_SING;
			memcpy(&sendBuff[len],&SendFileFrame,sizeof(SEND_FILE_FRAME));
			len+=sizeof(SEND_FILE_FRAME);
			if(_lread(hFile, &sendBuff[len], tlen)
				!=tlen)
			{
				ErrMsg(ghWndMain,"����TF_Send_Clt_Init_Files:���ļ���!");
				_lclose(hFile);
				goto thread_exit;
			}
			len+=tlen;
            if(UDP_SendBuff("�����ļ�", lpSendInfo->sd, sendBuff, len, NULL)<0)
			{
				_lclose(hFile);
				goto thread_exit;
			}
			_lclose(hFile);
		}
		else
		{
			alen=2000;
			slen=0;
			for(;;)
			{
				if(tlen-slen>2000)
					alen=2000;
				else
					alen=tlen-slen;
				slen+=alen;
				if(slen==tlen)
				{
					if(lpSendInfo->version>10)
						SendFileFrame.sign ='F';
					else
						SendFileFrame.sign ='E';
					if(lpSendInfo->version==12)
						SendFileFrame.sign =GZ_OVER;
				}
				if(slen>2000&&slen<tlen)
				{
					SendFileFrame.sign ='S';
					if(lpSendInfo->version==12)
						SendFileFrame.sign =GZ_CONT;
				}
				if(slen<=2000)
				{
					SendFileFrame.sign ='B';
					if(lpSendInfo->version==12)
						SendFileFrame.sign =GZ_STAR;
				}

				SendFileFrame.filelen=alen;

				strcpy(sendBuff,SEND_FILE_HEAD);
				len =strlen(SEND_FILE_HEAD);
				memcpy(&sendBuff[len],&SendFileFrame,sizeof(SEND_FILE_FRAME));
				len+=sizeof(SEND_FILE_FRAME);
				if(_lread(hFile, &sendBuff[len], alen)
					!=alen)
				{
					ErrMsg(ghWndMain,"����TF_Send_Clt_Init_Files:���ļ���!");
					_lclose(hFile);
					goto thread_exit;
				}
				len+=alen;
				if(UDP_SendBuff("�����ļ�", lpSendInfo->sd, sendBuff, len,NULL)<0)
				{
					_lclose(hFile);
					goto thread_exit;
				}
				if(slen==tlen)
				{
					_lclose(hFile);
					break;
				}

				for(j=0;j<200;j++)
				{
					status=check_socket_status(lpSendInfo->sd);

					if(status ==-1||status == -2)
					{
						_lclose(hFile);
						goto thread_exit;
					}
					if(status==0) 
						break;
					Sleep(40);
				}
				if(j>=200)
				{
					_lclose(hFile);
					goto thread_exit;
				}
			}
		}
		if((i==1||i==2)&&lpSendInfo->version>10)
			unlink(filename);
	}
thread_exit:
	if(strstr(filename,".comp")!=NULL)
		unlink(filename);

	if(lpSendInfo!=NULL)
	{
		hThrd =lpSendInfo->hThread;
		GlobalUnlock(hMem);
	}
	if(hMem) GlobalFree(hMem);
	if(hThrd!=NULL)
		CloseHandle(hThrd);
	ExitThread(0);
	return 0;
}

int UDP_Server_Send_HqChkUsr(int sd, LPSTR lpTmp, struct sockaddr *lpdest)
{
	int len,ret;
	char SendBuff[100];
    char Id[HQ_USERID_SIZE+1],Pass[HQ_USERPWD_SIZE+1];
    LPDEST_INFO	lpDestTmp;
	BYTE version;

	HANDLE hMem;
	LPUDP_SEND_INFO lpSendInfo;
	HANDLE hThrd;
	LONG lThreadId;

	memset(SendBuff,0,100);
	strcpy(SendBuff, HQ_CHKUSR_HEAD);
	len =strlen(HQ_CHKUSR_HEAD)+sizeof(short);

    strncpy(Id,lpTmp,HQ_USERID_SIZE);
	Id[HQ_USERID_SIZE]=0;
    strncpy(Pass,lpTmp+HQ_USERID_SIZE,HQ_USERPWD_SIZE);
	Pass[HQ_USERPWD_SIZE] =0;

    if(Monitor.IsRun)
	{		
        lpDestTmp=GetAnotherUserById(Id,sd);
		if(lpDestTmp==NULL||lpDestTmp->isDead)
		{
			ret=RegisterUser(Id,Pass);
			if(ret>0)
			{
				version=(BYTE)HqDestActiveUsr(sd, lpdest, Id,ret);
				ret=LOGIN_SUCC;
			}
		}
		else
		{
			ret=RegisterUser(Id,Pass);
            if(ret>0)
			{	
				if(SendMsg(lpDestTmp->sd,"����ע�⣬�б���û���ͼ�������ʺŵ�¼")<0)
				{
					version=(BYTE)HqDestActiveUsr(sd, lpdest, Id,ret);
					ret=LOGIN_SUCC;
				}
				else
					ret=LOGIN_ANOTHER;
			}
        }
	}
	else 
	{
		version =(BYTE)11;
		ret =LOGIN_SUCC;
	}

	SendBuff[len++] =ret;
	*(short *)&SendBuff[strlen(HQ_CHKUSR_HEAD)] =len;
	UDP_SendBuff("Ч���û�", sd, SendBuff, len, NULL);

	if(ret==LOGIN_SUCC)
	{	 	
        //��������ʼ���û����߳�
		hMem =GlobalAlloc(GHND, sizeof(UDP_SEND_INFO));
		if(hMem ==NULL)
		{
			ErrMsg(ghWndMain, "����HqChkUsr:���ܷ��䷢�ͻ�����!");
			return -1;
		}
		lpSendInfo =(LPUDP_SEND_INFO)GlobalLock(hMem);
		if(lpSendInfo ==NULL)
		{
			ErrMsg(ghWndMain, "����HqChkUsr:�����������ͻ�����!");
			GlobalFree(hMem);
			return -1;
		}
		lpSendInfo->sd =sd;
		lpSendInfo->version =version;				
		hThrd =CreateThread(NULL, 200*1024,
			(LPTHREAD_START_ROUTINE)TF_Send_Clt_Init_Files,
			hMem, CREATE_SUSPENDED, (LPDWORD)&lThreadId);
		if(!hThrd)
		{
			GlobalUnlock(hMem);
			GlobalFree(hMem);
			ErrMsg(ghWndMain, "����HqChkUsr:���ܽ����߳�!");
		}
		else
		{
			lpSendInfo->hThread =hThrd;
			GlobalUnlock(hMem);
			SetThreadPriority(hThrd, THREAD_PRIORITY_NORMAL);
			ResumeThread(hThrd);
		}
	}
	return 0;
}

#define		FILE_STOCK_INFO		0	//������Ϣ
#define		FILE_LIST_DIR		1   //����Ŀ¼
#define		FILE_NORMAL			2   //�����ļ�
#define		FILE_SZ_ALL_MINUTE	3   //���ʱ����
#define		FILE_SZ_ALL_DAY     4   //����������
#define		FILE_SH_ALL_MINUTE	5   //����ʱ����
#define		FILE_SH_ALL_DAY     6   //����������
#define		FILE_WINPY			7

DWORD WINAPI TF_Send_DownLoad(LPVOID hMem)
{
	HANDLE hThrd =NULL;
	LPUDP_SEND_INFO lpSendInfo =NULL;
	SEND_FILE_FRAME	SendFileFrame;
	char sendBuff[1024],filename[80],temp[80],search[128];
    UINT tlen,
		 alen,
		 slen,
		 len;
	int j,status,type;
	HFILE hFile=HFILE_ERROR;
	OFSTRUCT os;
    WIN32_FIND_DATA FindData;
    HANDLE hFindFile;
	BOOL fFind;

	lpSendInfo =GlobalLock(hMem);
	if(lpSendInfo ==NULL)
	{
		ErrMsg(ghWndMain, "����TF_SendFile:Ŀ����Ϣָ��Ϊ��!");
		goto thread_exit;
	}

    type =lpSendInfo->filename[0];
	switch(type)
	{
		case FILE_SZ_ALL_MINUTE:
			sprintf(search,"%s\\szdata\\*.dat",szDataPath);
		break;
		case FILE_SZ_ALL_DAY:
			sprintf(search,"%s\\szday\\*.day",szDataPath);
		break;
		case FILE_SH_ALL_MINUTE:
			sprintf(search,"%s\\shdata\\*.dat",szDataPath);
		break;
		case FILE_SH_ALL_DAY:
			sprintf(search,"%s\\shday\\*.day",szDataPath);
		break;
	}
	hFindFile =FindFirstFile(search,&FindData);
	if(hFindFile!=INVALID_HANDLE_VALUE)
	{
		do
		{
			if(FindData.cFileName[0]>='0'&&FindData.cFileName[0]<='9')
			{
				switch(type)
				{
					case FILE_SZ_ALL_MINUTE:
						sprintf(filename,"%s\\szdata\\%s",szDataPath,FindData.cFileName);
					break;
					case FILE_SZ_ALL_DAY:
						sprintf(filename,"%s\\szday\\%s",szDataPath,FindData.cFileName);
					break;
					case FILE_SH_ALL_MINUTE:
						sprintf(filename,"%s\\shdata\\%s",szDataPath,FindData.cFileName);
					break;
					case FILE_SH_ALL_DAY:
						sprintf(filename,"%s\\shday\\%s",szDataPath,FindData.cFileName);
					break;
				}
				sprintf(temp,"%s.lzw.%d",filename,lpSendInfo->sd);
				if(ZlibCompressFile(filename,temp))
					hFile =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READ);
				else goto thread_exit;

				if(hFile==HFILE_ERROR)
				{
					ErrMsg(ghWndMain, "����TF_Send_Day:���ܴ��ļ�!");
					goto thread_exit;
				}
				if((tlen=(UINT)_llseek(hFile, 0, FILE_END))==HFILE_ERROR)
				{
					ErrMsg(ghWndMain, "����TF_SendFile:���ܶ�λ���ļ�β!");
					goto thread_exit;
				}
				if(_llseek(hFile, 0, FILE_BEGIN)==HFILE_ERROR)
				{
					ErrMsg(ghWndMain, "����TF_SendFile:���ܶ�λ���ļ�ͷ!");
					goto thread_exit;
				}

				strcpy(SendFileFrame.filename,FindData.cFileName);

				if(tlen<=900)
				{
					SendFileFrame.filelen=tlen;
					strcpy(&sendBuff[0],SEND_FILE_HEAD);
					len =strlen(SEND_FILE_HEAD);

					SendFileFrame.sign =GZ_SING;
					memcpy(&sendBuff[len],&SendFileFrame,sizeof(SEND_FILE_FRAME));
					len+=sizeof(SEND_FILE_FRAME);
					if(_lread(hFile, &sendBuff[len], tlen)
						!=tlen)
					{
						ErrMsg(ghWndMain,"����TF_SendFile:���ļ���!");
						goto thread_exit;
					}
					len+=tlen;
					if(UDP_SendBuff("�����ļ�", lpSendInfo->sd, sendBuff, len, NULL)<0)
					{
						ErrMsg(ghWndMain,"����TF_SendFile:�����ļ���!");
						goto thread_exit;
					}
				}
				else
				{
					alen=900;
					slen=0;
					for(;;)
					{
						if(tlen-slen>900)
							alen=900;
						else alen=tlen-slen;
						slen+=alen;
						if(slen==tlen)
							SendFileFrame.sign =GZ_OVER;
						if(slen>900&&slen<tlen)
							SendFileFrame.sign =GZ_CONT;
						if(slen<=900)
							SendFileFrame.sign =GZ_STAR;

						SendFileFrame.filelen=alen;
						strcpy(&sendBuff[0],SEND_FILE_HEAD);
						len =strlen(SEND_FILE_HEAD);
						memcpy(&sendBuff[len],&SendFileFrame,sizeof(SEND_FILE_FRAME));
						len+=sizeof(SEND_FILE_FRAME);
						if(_lread(hFile, &sendBuff[len], alen)
							!=alen)
						{
							ErrMsg(ghWndMain,"����TF_SendFile:���ļ���!");
							goto thread_exit;
						}
						len+=alen;
						if(UDP_SendBuff("�����ļ�", lpSendInfo->sd, sendBuff, len, NULL)<0)
							goto thread_exit;
						if(slen==tlen) break;
						for(j=0;j<250;j++)
						{
							status=check_socket_status(lpSendInfo->sd);
							if(status ==-1||status ==-2)
								goto thread_exit;
							if(status==0) 
								break;
							Sleep(40);
						}
						if(j>=250) goto thread_exit;
					}
				}
				_lclose(hFile);
				unlink(temp);
			}
			fFind =FindNextFile(hFindFile,&FindData);
			if(fFind)
			{
				for(j=0;j<250;j++)
				{
					status=check_socket_status(lpSendInfo->sd);
					if(status ==-1||status ==-2)
						goto thread_exit;
					if(status==0) 
						break;
					Sleep(40);
				}
				if(j>=250) goto thread_exit;
			}
		}while(fFind);
	}
thread_exit:
	FindClose(hFindFile);
	unlink(temp);
	if(lpSendInfo!=NULL)
	{
		hThrd =lpSendInfo->hThread;
		GlobalUnlock(hMem);
	}
	if(hMem) GlobalFree(hMem);
	if(hThrd !=NULL)
		CloseHandle(hThrd);
	ExitThread(0);
	return 0;
}

DWORD WINAPI TF_SendFile(LPVOID hMem)
{
	HANDLE hThrd =NULL;
	LPUDP_SEND_INFO lpSendInfo =NULL;
	SEND_FILE_FRAME	SendFileFrame;
	char sendBuff[1024],filename[80],*ptr,temp[80];
    UINT tlen,
		 alen,
		 slen,
		 len;
	int j,status;
	HFILE hFile=HFILE_ERROR;
	OFSTRUCT os;

	lpSendInfo =GlobalLock(hMem);
	if(lpSendInfo ==NULL)
	{
		ErrMsg(ghWndMain, "����TF_SendFile:Ŀ����Ϣָ��Ϊ��!");
		goto thread_exit;
	}

	strcpy(filename,lpSendInfo->filename);

	if(access(filename,0)!=0)
		goto thread_exit;

	if(lpSendInfo->version==11)
	{
		/*
			��ȡѹ���ļ���
		*/
		sprintf(temp,"%s.lzw.%d",filename,lpSendInfo->sd);
		/*
			ѹ���ļ�
		*/
		if(CompressFile(filename,temp))
			hFile =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READ);
		else
			lpSendInfo->version=10;
	}
	if(lpSendInfo->version==12)
	{
		sprintf(temp,"%s.lzw.%d",filename,lpSendInfo->sd);
		if(ZlibCompressFile(filename,temp))
			hFile =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READ);
		else lpSendInfo->version=10;
	}
	if(lpSendInfo->version<11)
	hFile =OpenFile(filename, &os, OF_SHARE_DENY_NONE|OF_READ);


	if(hFile==HFILE_ERROR)
	{
			ErrMsg(ghWndMain, "����TF_SendFile:���ܴ��ļ�!");
			goto thread_exit;
	}
	if((tlen=(UINT)_llseek(hFile, 0, FILE_END))==HFILE_ERROR)
	{
			ErrMsg(ghWndMain, "����TF_SendFile:���ܶ�λ���ļ�β!");
			goto thread_exit;
	}
	if(_llseek(hFile, 0, FILE_BEGIN)==HFILE_ERROR)
	{
			ErrMsg(ghWndMain, "����TF_SendFile:���ܶ�λ���ļ�ͷ!");
			goto thread_exit;
	}

	ptr=strrchr(filename,'\\');	
	strcpy(SendFileFrame.filename,++ptr);

	if(tlen<=900)
	{
		SendFileFrame.filelen=tlen;
		strcpy(&sendBuff[0],SEND_FILE_HEAD);
		len =strlen(SEND_FILE_HEAD);

		if(lpSendInfo->version<11)
			SendFileFrame.sign ='e';
		if(lpSendInfo->version==11)
			SendFileFrame.sign ='f';
		if(lpSendInfo->version>11)
			SendFileFrame.sign =GZ_SING;

		memcpy(&sendBuff[len],&SendFileFrame,sizeof(SEND_FILE_FRAME));
		len+=sizeof(SEND_FILE_FRAME);
		if(_lread(hFile, &sendBuff[len], tlen)
			!=tlen)
		{
			ErrMsg(ghWndMain,"����TF_SendFile:���ļ���!");
			goto thread_exit;
		}
		len+=tlen;
        if(UDP_SendBuff("�����ļ�", lpSendInfo->sd, sendBuff, len, NULL)<0)
		{
			ErrMsg(ghWndMain,"����TF_SendFile:�����ļ���!");
			goto thread_exit;
		}
	}
	else
	{
		alen=900;
		slen=0;
		for(;;)
		{
			if(tlen-slen>900)
				alen=900;
			else
				alen=tlen-slen;
			slen+=alen;
			if(slen==tlen)
			{
				if(lpSendInfo->version<11)
					SendFileFrame.sign ='E';
				if(lpSendInfo->version==11)
					SendFileFrame.sign ='F';
				if(lpSendInfo->version>11)
					SendFileFrame.sign =GZ_OVER;
			}
			if(slen>900&&slen<tlen)
			{	
				if(lpSendInfo->version>11)
					SendFileFrame.sign =GZ_CONT;
				else
				SendFileFrame.sign ='S';
			}
			if(slen<=900)
			{
				if(lpSendInfo->version>11)
					SendFileFrame.sign =GZ_STAR;
				else
				SendFileFrame.sign ='B';
			}

			SendFileFrame.filelen=alen;

			strcpy(&sendBuff[0],SEND_FILE_HEAD);
			len =strlen(SEND_FILE_HEAD);
			memcpy(&sendBuff[len],&SendFileFrame,sizeof(SEND_FILE_FRAME));
			len+=sizeof(SEND_FILE_FRAME);
			if(_lread(hFile, &sendBuff[len], alen)
				!=alen)
			{
				ErrMsg(ghWndMain,"����TF_SendFile:���ļ���!");
				goto thread_exit;
			}
			len+=alen;
			if(UDP_SendBuff("�����ļ�", lpSendInfo->sd, sendBuff, len, NULL)<0)
				goto thread_exit;
			if(slen==tlen) break;

			for(j=0;j<200;j++)
			{
				status=check_socket_status(lpSendInfo->sd);

				if(status ==-1||status ==-2)
					goto thread_exit;
				if(status==0) 
					break;
				Sleep(40);
			}

			if(j>=200) goto thread_exit;			

			if(FileTranLock)
			{
					SendMsg(lpSendInfo->sd,"ϵͳ���ڳ�ʼ�������Ժ�");
					goto thread_exit;
			}
		}
	}
thread_exit:
	if(hFile!=HFILE_ERROR)
		_lclose(hFile);
	if(lpSendInfo->version>10)
		unlink(temp);
	if(lpSendInfo!=NULL)
	{
		hThrd =lpSendInfo->hThread;
		GlobalUnlock(hMem);
	}
	if(hMem) GlobalFree(hMem);
	if(hThrd !=NULL)
		CloseHandle(hThrd);
	ExitThread(0);
	return 0;
}

BOOL CreateSendThread(int sd, char *filename,BYTE type)
{
	 HANDLE hMem=0;
	 LPUDP_SEND_INFO lpSendInfo;
	 HANDLE hThrd;
	 LONG lThreadId;
	 DEST_INFO *lpDestInfo;

	hMem =GlobalAlloc(GHND, sizeof(UDP_SEND_INFO));
	if(hMem ==NULL)
	{
		ErrMsg(ghWndMain, "����SendFile:���ܷ��䷢�ͻ�����!");
		return -1;
	}
	lpSendInfo =(LPUDP_SEND_INFO)GlobalLock(hMem);
	if(lpSendInfo ==NULL)
	{
		ErrMsg(ghWndMain, "����SendFile:�����������ͻ�����!");
		GlobalFree(hMem);
		return -1;
	}
	lpSendInfo->sd =sd;
	lpDestInfo =GetDestBySd(sd);
	if(lpDestInfo!=NULL)
		lpSendInfo->version =lpDestInfo->version;
	else
		lpSendInfo->version =10;
	
	if(type ==FILE_WINPY)
		lpSendInfo->version =12;

    lpSendInfo->lpDestInfo =lpDestInfo;

//    strcpy(lpSendInfo->filename,filename);
	if(type >=FILE_SZ_ALL_MINUTE && type <=FILE_SH_ALL_DAY)
	{
		lpSendInfo->filename[0] =type;
		hThrd =CreateThread(NULL, 200*1024,
			(LPTHREAD_START_ROUTINE)TF_Send_DownLoad,
			(LPVOID)hMem, CREATE_SUSPENDED, (LPDWORD)&lThreadId);
	}
	else
	{
		strcpy(lpSendInfo->filename,filename);
		hThrd =CreateThread(NULL, 200*1024,
			(LPTHREAD_START_ROUTINE)TF_SendFile,
			(LPVOID)hMem, CREATE_SUSPENDED, (LPDWORD)&lThreadId);
	}
	if(!hThrd)
	{
		GlobalUnlock(hMem);
		GlobalFree(hMem);
		ErrMsg(ghWndMain, "����SendFile:���ܽ����߳�!");
	}
	else
	{
		lpSendInfo->hThread =hThrd;
		GlobalUnlock(hMem);
		SetThreadPriority(hThrd, THREAD_PRIORITY_NORMAL);
		ResumeThread(hThrd);
	}
	return 0;
}

int UDP_Send_File(int sd,STOCK_INFO_FRAME	*FileInfo)
{
	HFILE hFile;
	OFSTRUCT os;
	char temp[80];

	FileInfo->gpdm[MAX_FILE_NAME_SIZE-1]=0;
	if(FileInfo->type == FILE_STOCK_INFO)
	{
		sprintf(temp,"%s\\ggxx\\%s",szDataPath,FileInfo->gpdm);
		if(strchr(temp,'.') ==NULL)
			strcat(temp,".txt");
		if(access(temp,0)!=0)
		{
			hFile=OpenFile(temp,&os,OF_CREATE|OF_WRITE);
			if(hFile==HFILE_ERROR)
				return -1;
			if(_lwrite(hFile,"�޴˸�����Ϣ ",13)!=13)	
			{
				_lclose(hFile);
				return -1;
			}
			_lclose(hFile);
		}
	}
     
	if(FileInfo->type == FILE_LIST_DIR)
	{
		if(szNewsPath[0]!=0 &&szNewsSrc[0]!=0)
		{
			if(FileInfo->gpdm[0] ==0)
				sprintf(temp,"%s\\news.idx",szDataPath);
			else
				sprintf(temp,"%s\\%s",szDataPath,FileInfo->gpdm);
		}
		else return 0;

	}
	if(FileInfo->type ==FILE_NORMAL)  //FILE_NEWS_FILE
	{
		if(FileTranLock)
		{
			SendMsg(sd,"ϵͳ���ڳ�ʼ�������Ժ�");
			return 0;
		}
		else
			sprintf(temp,"%s\\%s",szNewsPath,FileInfo->gpdm);
	}
	if(FileInfo->type ==FILE_WINPY)
		sprintf(temp,"%s\\sys\\%s",szDataPath,FileInfo->gpdm);

	CreateSendThread(sd,temp,(BYTE)FileInfo->type);

	return 0;
}