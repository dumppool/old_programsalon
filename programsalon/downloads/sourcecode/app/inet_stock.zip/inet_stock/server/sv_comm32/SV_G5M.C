extern char szDataPath[128];

int UDP_Server_Write_G5M(int jys, int rec_num, int day_start, struct sockaddr *lpdest)
{
	int i, j, len;
	char fileName[128];
	G5M_HEAD G5MHead;
	G5M_DATE_HEAD G5MDateHead;
	LPGMIN_DATA lpGMinData =NULL;
	HFILE hFile;
	OFSTRUCT os;
	
	if(jys ==0)
		lpszTmp ="SZMIN5";
	else if(jys ==1)
		lpszTmp ="SHMIN5";
	else return -1;
		
	wsprintf(fileName, "%s\\%s\\%s.dat", szDataPath, lpszTmp,
				HqData[jys].lpRecData[rec_num].zqdm);
	hFile =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hFile ==HFILE_ERROR)
	{
		ErrMsg(ghWndMain, "open data file failed!");
		return -1;
	}
	if(_lread(hFile, &G5MHead, sizeof(G5MHead)) !=sizeof(G5MHead))
	{
		ErrMsg(ghWndMain, "read data file failed!");
		_lclose(hFile);
		return -1;
	}
	if(G5MHead.dateCount <=0 || G5MHead.dataCount <=0
		|| G5MHead.firstDate <day_start	|| G5MHead.firstDate >day_start)
		
	if(min_num >=GMinHead.minCount) min_count =0;
	else
	{
		if(min_num+min_count >GMinHead.minCount)
			min_count =GMinHead.minCount-min_num;
		if(min_count >MAX_GMIN_SENDCOUNT) min_count =MAX_GMIN_SENDCOUNT;
	
		lpGMinData =(LPGMIN_DATA)malloc(sizeof(GMIN_DATA)*min_count);
		if(lpGMinData ==NULL)
		{
			ErrMsg(ghWndMain, "alloc mem failed!");
			_lclose(hFile);
			return -1;
		}
	
		_llseek(hFile, sizeof(GMIN_HEAD)+sizeof(GMIN_DATA)*min_num, SEEK_SET);
		if(_lread(hFile, lpGMinData, sizeof(GMIN_DATA)*min_count)
				!=min_count*sizeof(GMIN_DATA))
		{
			ErrMsg(ghWndMain, "read data file failed!");
			_lclose(hFile);
			return -1;
		}
	}
	_lclose(hFile);
	
	strcpy(WriteBuf, GMIN01_HEAD); 
	len =strlen(GMIN01_HEAD);
	if(jys ==0) WriteBuf[len] ='Z';
	else WriteBuf[len] ='H';
	len++;

	*((int *)&WriteBuf[len]) =rec_num;
	len +=sizeof(int);
	*((int *)&WriteBuf[len]) =min_num;
	len +=sizeof(int);
	*((int *)&WriteBuf[len]) =min_count;
	len +=sizeof(int);
	
	if(lpGMinData)
	{
		memcpy(&WriteBuf[len], lpGMinData, min_count*sizeof(GMIN_DATA));
		len +=min_count*sizeof(GMIN_DATA);
		free(lpGMinData);
	}
	
	
	for(i =0; i<10; i++)
	{
		if(jys ==0)
			MsgSend("Send GMIN01_DATA:SZ");
		else MsgSend("Send GMIN01_DATA:SH");
		j =sendto(sdHq, (LPSTR)WriteBuf, len, 0, lpdest,
				sizeof(struct sockaddr));
		if (j == SOCKET_ERROR) 
		{
			if (h_errno == WSAEWOULDBLOCK)
				continue;
			else
				ErrMsg(ghWndMain, GetError("sendto()"));
			continue;
		}
		break;
	}
	                
	return j;
}

// GMIN10_HEAD, jys, zgjg, zdjg, min_num, min_count, (GMinData)...
int UDP_Server_Write_GMin10(int jys, int rec_num, int min_num, struct sockaddr *lpdest)
{
	int i, j, len, min_count;
	char fileName[128];
	GMIN_HEAD GMinHead;
	LPGMIN_DATA lpGMinData =NULL;
	HFILE hFile;
	OFSTRUCT os;
	
	if(jys > 1) return -1;
	
	if(HqTime[jys].fRunning)
	{
		wsprintf(fileName, "%s\\%s.dat", GraphData[jys].szGMinDataPath,
					HqData[jys].lpRecData[rec_num].zqdm);
		hFile =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
		if(hFile ==HFILE_ERROR)
		{
			ErrMsg(ghWndMain, "open data file failed!");
			return -1;
		}
		
		if((int)_lread(hFile, &GMinHead, sizeof(GMIN_HEAD)) !=i)
		{
			ErrMsg(ghWndMain, "read data file failed!");
			_lclose(hFile);
			return -1;
		}
		min_count =MAX_GMIN_SENDCOUNT;
		if(min_num >=GMinHead.minCount) min_count =0;
		else
		{
			if(min_num+min_count >GMinHead.minCount)
				min_count =GMinHead.minCount-min_num;
	
			lpGMinData =(LPGMIN_DATA)malloc(sizeof(GMIN_DATA)*min_count);
			if(lpGMinData ==NULL)
			{
				ErrMsg(ghWndMain, "alloc mem failed!");
				_lclose(hFile);
				return -1;
			}
	
			_llseek(hFile, sizeof(GMIN_HEAD)+sizeof(GMIN_DATA)*min_num, SEEK_SET);
			if(_lread(hFile, lpGMinData, sizeof(GMIN_DATA)*min_count)
					!=min_count*sizeof(GMIN_DATA))
			{
				ErrMsg(ghWndMain, "read data file failed!");
				_lclose(hFile);
				return -1;
			}
		}
		_lclose(hFile);
	
		strcpy(WriteBuf, GMIN10_HEAD); 
		len =strlen(GMIN10_HEAD);
		if(jys ==0) WriteBuf[len] ='Z';
		else WriteBuf[len] ='H';
		len++;

		*((int *)&WriteBuf[len]) =rec_num;
		len +=sizeof(int);
		*((int *)&WriteBuf[len]) =min_num;
		len +=sizeof(int);
		*((int *)&WriteBuf[len]) =min_count;
		len +=sizeof(int);
		*((float *)&WriteBuf[len]) =(float)GMinHead.zgjg;
		len +=sizeof(float);
		*((float *)&WriteBuf[len]) =(float)GMinHead.zdjg;
		len +=sizeof(float);
		*((long *)&WriteBuf[len]) =GMinHead.zglc;
		len +=sizeof(long);
		//*((long *)&WriteBuf[len]) =GMinHead.zdlc;
		//len +=sizeof(long);
	
		if(lpGMinData)
		{
			memcpy(&WriteBuf[len], lpGMinData, min_count*sizeof(GMIN_DATA));
			len +=min_count*sizeof(GMIN_DATA);
			free(lpGMinData);
		}
	}
	else
	{
		strcpy(WriteBuf, NOTRUN_HEAD);
		len =strlen(NOTRUN_HEAD);
	}
	// try 10 times
	for(i =0; i<10; i++)
	{
		if(jys ==0)
			MsgSend("Send GMIN10_DATA");
		else MsgSend("Send GMIN10_DATA");
		j =sendto(sdHq, (LPSTR)WriteBuf, len, 0, lpdest,
				sizeof(struct sockaddr));
		if (j == SOCKET_ERROR) 
		{
			if (h_errno == WSAEWOULDBLOCK)
				continue;
			else
				ErrMsg(ghWndMain, GetError("sendto()"));
			continue;
		}
		break;
	}	
	return j;
}
