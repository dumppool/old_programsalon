#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "main.h"
#include "hq.h"
#include "data.h"

#include "cl_hq.h"
#include "cl_data.h"

HFILE hfHq[2], hfMmp[2], hfDp, hfMaxMin[2], hfGraHead[2];

extern void MsgLocal(LPSTR msg);
extern HWND ghWndMain;

int ReadHqAll(int jys)
{
	if(ReadHqData(jys)<0)
	{
		ErrMsg(NULL, "ReadHqData failed!");
		return -1;
	}
	if(jys ==0)
	{
		if(ReadDpData()<0)
		{
			ErrMsg(NULL, "ReadDpData failed!");
			return -1;
		}
	}
	if(ReadMmpData(jys)<0)
	{
		ErrMsg(NULL, "ReadMmpData failed!");
		//return -1;
	}
	if(ReadMaxMinData(jys)<0)
	{
		ErrMsg(NULL, "ReadMaxMinData failed!");
		return -1;
	}
	if(ReadGraHead(jys)<0)
	{
		ErrMsg(NULL, "ReadGraHead failed!");
		return -1;
	}

	return 0;
}

int RefreshHq(int jys)
{

	short recCount;
//	int ret;
//	static seri =0;

	if(hfHq[jys] <0)
		return 0;

	_llseek(hfHq[jys], 0, SEEK_SET);
	if(_lread(hfHq[jys], &recCount,
				sizeof(short)) !=sizeof(short))
	{
		ErrMsg(ghWndMain, "����RefreshHq():�����������ļ�ͷ��");
		return -1;
	}
	
	if(recCount<=0||recCount>1000)
		return -1;

	//if(HqData[jys].recCount ==0||HqData[jys].recCount <recCount)
	//{
	//	ret =HqAllocMem(jys, recCount);
	//	if(ret<0)	return -1;
	//}

	if(ReadHqData(jys)<0)
		return -1;
	if(jys ==0)
	{
		if(ReadDpData()<0)
			return -1;
	}
	ReadMmpData(jys);
	ReadMaxMinData(jys);

//	if(seri ==0)
//	{
		CreateLzwMemData(jys);
//		seri++;
//		if(seri ==2) seri =0;
//	}
	return 0;
}

extern short date_num;
int ReadGraHead(int jys)
{
	int i;
	char temp[128];
	HFILE hFile;
	OFSTRUCT os;

	for(i =0; i<HqData[jys].recCount; i++)
	{
		wsprintf(temp, "%s\\%s.dat",
			GraphData[jys].szGraPath,
			HqData[jys].lpPreData[i].zqdm);
		hFile =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READ);
		if(hFile ==HFILE_ERROR)
			goto reset_values;
		else
		{
			if(_lread(hFile, &GraphData[jys].lpGraHead[i],
					sizeof(GRA_HEAD)) !=sizeof(GRA_HEAD))
				goto reset_values;
			//else
			//	if(GraphData[jys].lpGraHead[i].dateNum !=date_num)
			//		goto reset_values;
			_lclose(hFile);
			continue;
		}
reset_values:
		memset(&GraphData[jys].lpGraHead[i], 0, sizeof(GRA_HEAD));
		GraphData[jys].lpGraHead[i].dateNum =date_num;
		GraphData[jys].lpGraHead[i].zrsp =HqData[jys].lpPreData[i].zrsp;
		//GraphData[jys].lpGraHead[i].zl =HqData[jys].lpRefData[i].cjss;
		GraphData[jys].lpGraHead[i].zgjg =HqData[jys].lpRefData[i].zgjg;
		GraphData[jys].lpGraHead[i].zdjg =HqData[jys].lpRefData[i].zdjg;
		if(hFile !=HFILE_ERROR) _lclose(hFile);
	}
	return 0;
}

int ReadHqData(int jys)
{
	char tmp[100],temp[100];
//	int i;

	sprintf(tmp, "��ȡ��������:%s", (jys==0)?"����":"�Ϻ�");
	MsgLocal(tmp);
	
	_llseek(hfHq[jys], 0, FILE_BEGIN);
	if(_lread(hfHq[jys], &HqData[jys].recCount, sizeof(short))
			!=sizeof(short))
	{
		wsprintf(temp,"%s:%s",(jys==0)?"����":"�Ϻ�","����ReadHqData:���ļ�ͷʧ��");
		ErrMsg(ghWndMain,temp);
		return -1;
	}

	//for(i=0;i<HqData[jys].recCount;i++)
	//{
	if(_lread(hfHq[jys], HqData[jys].lpPreData, (UINT)HqData[jys].recCount*sizeof(HQ_PRE_DATA))
			!=(UINT)HqData[jys].recCount*sizeof(HQ_PRE_DATA))
	{
		wsprintf(temp,"%s:%s",(jys==0)?"����":"�Ϻ�","����ReadHqData:���ļ��̶�����ʧ��");
		ErrMsg(ghWndMain,temp);
		return -1;
	}
	//_lread(hfHq[jys], &HqData[jys].lpPreData[i], sizeof(HQ_PRE_DATA));
	//}

    //for(i=0;i<HqData[jys].recCount;i++)
	//{
	if(_lread(hfHq[jys], HqData[jys].lpRefData, (UINT)HqData[jys].recCount*sizeof(HQ_REF_DATA))
			!=(UINT)HqData[jys].recCount*sizeof(HQ_REF_DATA))
	{
		wsprintf(temp,"%s:%s",(jys==0)?"����":"�Ϻ�","����ReadHqData:���ļ�ˢ�²���ʧ��");
		ErrMsg(ghWndMain,temp);
		return -1;
	}
	//_lread(hfHq[jys], &HqData[jys].lpRefData[i], sizeof(HQ_REF_DATA));
	//}

	return 0;
}

int ReadDpData(void)
{
	MsgLocal("��ȡ��������");
	
	_llseek(hfDp, 0, SEEK_SET);
	if(_lread(hfDp, &DpData, sizeof(DpData)) !=sizeof(DpData))
	{
		ErrMsg(ghWndMain,"����ReadDpData:���ļ�ʧ��");
		return -1;
	}
	return 0;
}

int ReadMmpData(int jys)
{
	char tmp[100];
//	int i;

	sprintf(tmp, "��ȡ����������:%s", (jys==0)?"����":"�Ϻ�");
	MsgLocal(tmp);
	
	_llseek(hfMmp[jys], 0, SEEK_SET);

	//for(i=0;i<HqData[jys].recCount;i++)
	//{
	if(_lread(hfMmp[jys], MmpData[jys].lpMmp, sizeof(MMP)*HqData[jys].recCount)
			!=(UINT)sizeof(MMP)*HqData[jys].recCount)
	{
	//	ErrMsg(ghWndMain,"����ReadMmpData:���ļ�ʧ��");
		return -1;
	}
	//_lread(hfMmp[jys], &MmpData[jys].lpMmp[i], sizeof(MMP));
	//}

	return 0;
}
                     	
int ReadMaxMinData(int jys)
{
	//char temp[100];

	_llseek(hfMaxMin[jys], 0, SEEK_SET);
	if(_lread(hfMaxMin[jys], &MaxMinData[jys], sizeof(MaxMinData[jys]))
			!=sizeof(MaxMinData[jys]))
	{
		//wsprintf(temp,"%s:%s",(jys==0)?"����":"�Ϻ�",
		//		"����ReadMaxMinData:���ļ�ʧ��");
		//ErrMsg(ghWndMain,temp);
		return -1;
	}
	return 0;
}

int HqAllocMem(int jys, short recCount)
{
	return clHqAllocMem(jys,(int)recCount);
}
