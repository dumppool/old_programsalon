#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>			// read lseek access
#include <sys\stat.h>	// _S_IREAD
#include <share.h>
#include <fcntl.h>		//O_RDONLY
#include <time.h>

#include "hq.h"
#include "sv_hq.h"
#include "data.h"

HQ_DATA HqData[2];
DP_DATA DpData[2];
MMP_DATA MmpData[2];
HQ_TIME HqTime[2];
GRAPH_DATA GraphData[2];
MAXMIN_DATA MaxMinData[2][2];  //jys, 0:max, 1:min
HQSEL_DATA HqSelData;
LZW_DATA_202 LzwData202[2];

short keys[600];     // must init first

BOOL gfUseThrd =FALSE;
BOOL HqIsRun=TRUE;

extern BOOL fReadUDPData;
extern BOOL gfIsNewsSrcDel;
extern HWND ghWndMain;                           

extern void MsgLocal(LPSTR msg);
extern void	DelSpaces(LPSTR);
extern BOOL GetInitString(LPSTR, LPSTR, LPSTR);
extern BOOL PutInitString(LPSTR, LPSTR, LPSTR);
extern BOOL ErrMsg(HWND, LPSTR);
extern short ShoutBlockingHook(void);

char *HqItems[] ={"HQK_SZ", "HQK_SH", "GPK_SZ", /*"GPK_SH",*/
					"ZSK_SZ", "MMPK_SZ", NULL};

LPSTR HqTimeItems[] ={"SZ_AM_START", "SZ_AM_END", "SZ_PM_START", "SZ_PM_END",
					"SH_AM_START", "SH_AM_END", "SH_PM_START", "SH_PM_END",
};

LPSTR HqTimeDefs[] ={"9:30", "11:30", "13:00", "15:00",
					"9:30", "11:30", "13:00", "15:00",
};

short *lpHqTimes[] ={&HqTime[0].am_min_start, &HqTime[0].am_min_end,
				&HqTime[0].pm_min_start, &HqTime[0].pm_min_end,
				&HqTime[1].am_min_start, &HqTime[1].am_min_end,
				&HqTime[1].pm_min_start, &HqTime[1].pm_min_end
};

short zsRecNum[2][50];
short zsRecCount[2] ={0,0};
char ZxDataFile[128], szDataPath[128] ,szNewsPath[128] ,szNewsSrc[128];
char HqDataPath[128];

HFILE hfZx;

int *HqDataFile[] ={
	&hfHq[0], &hfHq[1], &hfMmp[0], &hfMmp[1], &hfDp,
	&hfMaxMin[0], &hfMaxMin[1], NULL
};

LPSTR HqDataFileName[] ={
	"SZHQ", "SHHQ", "SZMMP", "SHMMP", "DPDATA", "MAXMINSZ", "MAXMINSH", NULL
};

int HqInit(void)
{
	short i, jys;
	char tmp[256], temp[256];
	OFSTRUCT os;
	
	if(GetInitString("HQ", "RUN", tmp))
	{
		if(tmp[0]=='N')
		{
			HqIsRun=FALSE;
			return 0;
		}
	}
	for(i =0; i<2; i++)
	{
		memset(&HqData[i], 0, sizeof(HqData[i]));
		memset(&MmpData[i], 0, sizeof(MmpData[i]));
		memset(&HqTime[i], 0, sizeof(HqTime[i]));
		memset(&GraphData[i], 0, sizeof(GraphData[i]));
		memset(&DpData[i], 0, sizeof(DpData[i]));
		hfHq[i] =HFILE_ERROR;
		hfMmp[i] =HFILE_ERROR;
		hfMaxMin[i] =HFILE_ERROR;
	}
	hfDp =HFILE_ERROR;	
	ZxDataFile[0] =0;

	if(!GetInitString("ZX", "FILE0", ZxDataFile))
	{
		ErrMsg(ghWndMain, "get zx init failed!");
		PutInitString("ZX", "FILE0", "");
		return -1;
	}
	strupr(ZxDataFile);
	hfZx =OpenFile(ZxDataFile, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hfZx ==HFILE_ERROR)
	{
		ErrMsg(ghWndMain, "open zx file failed");
		return -1;
	}

	szNewsPath[0] =0;
	if(!GetInitString("NEWS", "DIR", szNewsPath))
	{
		ErrMsg(ghWndMain, "get news init failed!");
		PutInitString("NEWS", "DIR", "");
	}

	szNewsSrc[0] =0;
	if(!GetInitString("NEWS", "SRC", szNewsSrc))
	{
		ErrMsg(ghWndMain, "get news init failed!");
		PutInitString("NEWS", "SRC", "");
	}
	if(GetInitString("NEWS", "DELSRC", tmp))
	{
		if(tmp[0]=='Y')
			gfIsNewsSrcDel =TRUE;
		else
			gfIsNewsSrcDel =FALSE;
	}
	else
		gfIsNewsSrcDel =FALSE;

	for(jys =0; jys <2; jys++)
	{
		for(i =0; i<4; i++)
		{
			if(!GetInitString("TIME", HqTimeItems[i+4*jys], tmp))
			{
				strcpy(tmp, HqTimeDefs[i+4*jys]);
				PutInitString("TIME", HqTimeItems[i+4*jys], tmp);
			}
			else
			{
				if(strlen(tmp) > 12 || strlen(tmp) <3)
				{
					ErrMsg(ghWndMain, "time set error!");
					return -1;
				}
			}
			*lpHqTimes[i+4*jys] =atoi(strtok(tmp, ":"))*60;
			*lpHqTimes[i+4*jys] +=atoi(strtok(NULL, ":"));
		}
	
	}


	if(!GetInitString("HQ", "DATAPATH", szDataPath))
	{
		ErrMsg(ghWndMain, "get datapath of [hq] init failed!");
		PutInitString("HQ", "DATAPATH", "");
		return -1;
	}

	i =strlen(szDataPath);
	if(szDataPath[i-1] =='\\')
		szDataPath[i-1] =0;
	
	wsprintf(GraphData[0].szGraPath, "%s\\SZDATA", szDataPath);
	wsprintf(GraphData[1].szGraPath, "%s\\SHDATA", szDataPath);
	wsprintf(HqDataPath, "%s\\HQDATA", szDataPath);

	i =0;
	while(HqDataFileName[i])
	{
		sprintf(tmp, "%s\\%s.dat", HqDataPath, HqDataFileName[i]);
		
		if(access(tmp,_S_IREAD) <0)
		{
			wsprintf(temp, "can not access hq_data_file %s:", tmp);
			ErrMsg(ghWndMain, temp);
			return -1;
		}  
		*HqDataFile[i] =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_READ);
		if (*HqDataFile[i] ==HFILE_ERROR)
		{
			wsprintf(temp, "can not open hq_data_file %s:", tmp);
			ErrMsg(ghWndMain, temp);
			return -1;
		} 
		i++;
	}	
	return 0;
}

void HqExit(void)
{
	static BOOL fExit =FALSE;
	short jys;
	
	if(fExit ==TRUE) return;
	fExit =TRUE;
	for(jys =0; jys <2; jys++)
	{
		if(HqData[jys].lpRefData !=NULL)
			GlobalFreePtr(HqData[jys].lpRefData);
		if(HqData[jys].lpPreData !=NULL)
			GlobalFreePtr(HqData[jys].lpPreData);
		//if(HqData[jys].lpbChanged !=NULL)
		//	GlobalFreePtr(HqData[jys].lpbChanged);
		if(MmpData[jys].lpMmp)
			GlobalFreePtr(MmpData[jys].lpMmp);
		if(GraphData[jys].lpGraHead) GlobalFreePtr(GraphData[jys].lpGraHead);
		if(GraphData[jys].lpGraData) GlobalFreePtr(GraphData[jys].lpGraData);
		if(hfHq[jys] !=HFILE_ERROR) _lclose(hfHq[jys]);
		if(hfMmp[jys] !=HFILE_ERROR) _lclose(hfMmp[jys]);
		if(hfMaxMin[jys] !=HFILE_ERROR) _lclose(hfMaxMin[jys]);
	}
	if(hfDp !=HFILE_ERROR) _lclose(hfDp);
	//if(hfZx !=HFILE_ERROR) _lclose(hfZx);
}


int ReadHq(short jys)
{
	short recCount;
		
	if(hfHq[jys] <0)
		return 0;

	_llseek(hfHq[jys], 0, SEEK_SET);
	if(_lread(hfHq[jys], &recCount,
				sizeof(short)) !=sizeof(short))
	{
		ErrMsg(ghWndMain, "Error read hqdata file");
		return -1;
	}
		
	if(HqAllocMem(jys, recCount)<0) return -1;
	
	if(ReadHqAll(jys) <0) return -1;

	return 0;
}

