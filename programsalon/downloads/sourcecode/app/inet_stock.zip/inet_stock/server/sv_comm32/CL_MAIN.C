#include <windows.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#include "main.h"
#include "resource.h"
#include "hq.h"
#include "sv_hq.h"
#include "data.h"

#include "cl_hq.h"
#include "cl_data.h"
#include "cl_main.h"

BOOL fAuto =TRUE;
BOOL IsClectRun =FALSE;
HANDLE hThrdClect =NULL;


extern BOOL run_cancelled;

BOOL clAppInit(void)
{
	if(clHqInit() <0)
	{
		ErrMsg(NULL, "HqInit() failed!");
		return FALSE;
	}
	return TRUE;
}

void clAppExit(void)
{
	static BOOL fExit =FALSE;
	
	if(fExit) return;
	fExit =TRUE;
	
	clHqExit();
}

BOOL clGetInitString(char *Entry, char *Item, char *buf)
{
	GetPrivateProfileString(Entry, Item, "", buf, 256, "sv_data.ini");
	if(*buf ==0) return FALSE;
	return TRUE;
}

void clPutInitString(char *Entry, char *Item, char *buf)
{
	WritePrivateProfileString(Entry, Item, buf, "sv_data.ini");
}

int clGetInitInt(char *Entry, char *Item)
{
	return GetPrivateProfileInt(Entry, Item, -1, "sv_data.ini");
}


extern int date_num;
extern int tim;

long tim_seconds =0;
int clCheckTime(BOOL fRead)
{
	char tmp[40], tmp1[41];
	LPSTR tok;
	int jys, ret;
	static long time_start =-1;
	//struct tm *ptm;
	
	//HFILE hFile;
	//OFSTRUCT os;

	_strdate(tmp);
	date_num =100*atoi(strtok(tmp, "/"));
	tok =strtok(NULL, "/");
	date_num +=atoi(tok);
		
	_strtime(tmp);		//hh:mm:ss
	strcpy(tmp1, tmp);
	tok =strtok(tmp, ":");
	tim =atoi(tok)*60;
	tim +=atoi(strtok(NULL, ":"));
	tim_seconds =(long)tim*60+atoi(strtok(NULL, ":"));
	
	if(time_start ==-1) time_start =tim_seconds;
	else if(tim_seconds >time_start)
		MsgLocal(tmp1);
	
	for(jys =0; jys <2; jys++)
	{    
		//�˴����з���������
		if(tim<HqTime[jys].am_min_start
				|| (tim-5) >HqTime[jys].pm_min_end
				|| (tim <HqTime[jys].pm_min_start 
					&& tim >HqTime[jys].am_min_end))
		{
			if(HqTime[jys].fRunning ==TRUE)
			{
				HqTime[jys].fRunning =FALSE;
				CloseDbfFile(jys);

				if(tim-5 >HqTime[jys].pm_min_end)
				{
					if(HqTime[0].fRunning ==FALSE
						&& HqTime[1].fRunning ==FALSE)
					{         
						WriteDayData(0);
						WriteDayData(1);
					}
				}
			}
		}
		else if(HqTime[jys].fRunning ==FALSE)
		{   
			if(OpenDbfFile(jys))
			{
				if(JyOpen(jys))
				{
					if(ReadHqFirst(jys))
					{				
						HqTime[jys].fRunning =TRUE;     
						fWrited[jys]=FALSE;				
						//ReadHqFirst(jys);
						WriteHqData(jys);
						WriteMmpData(jys);
						WriteMaxMinData(jys);
						WriteDpData(jys);
						//SendJyStart(jys);
					}
					else
					{   
					    MsgLocal("CheckTime:���г�ʼ��ʧ��");
						CloseDbfFile(jys);
					}
				}
				else
				{
				    MsgLocal("CheckTime:δ����");
					CloseDbfFile(jys);
				}
				
			}
			else
			{
				MsgLocal("CheckTime:�򿪽����������ļ���");
				CloseDbfFile(jys);
			}
		}
	}
	ret =(int)(tim_seconds-time_start);
	time_start =tim_seconds;
	
	return ret;
}

int DoHq(void)
{
	BOOL fWritedSz =FALSE;
	
		if(clCheckTime(TRUE) >=0&&!run_cancelled)
		{
			if(HqTime[0].fRunning)
			{
				if(!RefreshHqData(0))
				{
					MsgLocal("��������ˢ��ʧ�ܣ���������");
				 	HqTime[0].fRunning =FALSE;
				 	CloseDbfFile(0);
				}
			}
			if(HqTime[1].fRunning)  
			{
				if(!RefreshHqData(1))
				{
					MsgLocal("�Ϻ�����ˢ��ʧ�ܣ���������");
				 	HqTime[1].fRunning =FALSE;
				 	CloseDbfFile(1);				
				}
			}
		}	
	return 0;
}

int RefreshHqData(int jys)
{
	if(HqRefresh(jys))
	{
	//	WriteHqData(jys);
	//	WriteMmpData(jys);
	//	WriteMaxMinData(jys);
	//	WriteDpData(jys);
	//	
		return TRUE;
	}
	else
		return FALSE;
}

BOOL IsWeekEnd(struct tm *ptm)
{
	return TRUE;
}

BOOL IsMonthEnd(struct tm *ptm)
{
	return TRUE;
}

long TF_ClectData(void)
{

	BOOL fWritedSz =FALSE;
	int jys =0;

	while(1)
	{
		if(run_cancelled) break;	

		if(clCheckTime(TRUE) >=0)
		{
			if(HqTime[0].fRunning)
			{
				if(!RefreshHqData(0))
				{
					MsgLocal("��������ˢ��ʧ�ܣ���������");
				 	HqTime[0].fRunning =FALSE;
				 	CloseDbfFile(0);
				}
				CreateLzwMemData(0);
			}
			if(HqTime[1].fRunning)  
			{
				if(!RefreshHqData(1))
				{
					MsgLocal("�Ϻ�����ˢ��ʧ�ܣ���������");
				 	HqTime[1].fRunning =FALSE;
				 	CloseDbfFile(1);				
				}
				CreateLzwMemData(1);
			}
		}	
		Sleep(Idel);
	}

	for(jys =0;jys<2;jys++)
	{
		WriteHqData(jys);
		WriteMmpData(jys);
		WriteMaxMinData(jys);
		WriteDpData(jys);
	}
	SetEvent(g_hEventDataWrite);
	if(hThrdClect!=NULL)
		CloseHandle(hThrdClect);

	ExitThread(0);
	return 0;
}

int CreateClectThread(void)
{
    //LONG lThreadId;
	//
	//hThrdClect =CreateThread(NULL, 0,
	//      (LPTHREAD_START_ROUTINE)TF_ClectData,
	//      NULL, CREATE_SUSPENDED, (LPDWORD)&lThreadId);
	//if(!hThrdClect) 
	//	return -1;
	//SetThreadPriority(hThrdClect, THREAD_PRIORITY_NORMAL);
	//ResumeThread(hThrdClect);
	
	return 0;
}
