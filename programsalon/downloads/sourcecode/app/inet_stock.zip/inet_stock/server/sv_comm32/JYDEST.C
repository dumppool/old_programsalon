#include <windows.h>
#include <time.h>
#include "hq.h"
#include "pctcp.h"
#include "sv_jy.h"
#include "jydest.h"

JY_DESTS jy_dests;
#define MAX_JY_USER_COUNT		100

#define MAX_JY_TIME		800

JY_DEST	jy_dest[MAX_JY_USER_COUNT];
int jy_dest_count=0;

BOOL fJyDestInited =FALSE;
void FreeJyDest(void);
LPJY_DEST GetJyDest(char *);
HANDLE hThrdScanJyDest =NULL;


extern HWND ghWndMain;
extern BOOL run_cancelled;
extern void ErrMsg(HWND, LPSTR);
extern char key[9];

BOOL JyDestInit(void)
{
	fJyDestInited =TRUE;
	memset(&jy_dests, 0, sizeof(jy_dests));
	memset(&jy_dest, 0, sizeof(JY_DEST)*MAX_JY_USER_COUNT);
	jy_dests.lpDestHead =&jy_dest[0];
	jy_dest_count=0;
	return TRUE;
}

void JyDestExit(void)
{
	if(!fJyDestInited) return;
	fJyDestInited =FALSE;
	//FreeJyDest();
	if(hThrdScanJyDest) CloseHandle(hThrdScanJyDest);
}

int GetJyDestCount(void)
{
	return jy_dest_count;
}

LPJY_DEST  AddJyDest(int sd,
			int reqType, char curJys, int recNum, char *lpgddm, int jyNum,int zqsid)
{

	LPJY_DEST lpDestNext, lpDestTmp;	
	lpDestNext =jy_dests.lpDestHead;	
	if(jy_dest_count>MAX_JY_USER_COUNT)
		return NULL;

	lpDestTmp=&jy_dest[jy_dest_count];
	if(jy_dest_count>0)
		jy_dest[jy_dest_count-1].lpNext=&jy_dest[jy_dest_count];
	jy_dest_count++;

	strcpy(lpDestTmp->gddm, lpgddm);
	lpDestTmp->reqType =reqType;
	lpDestTmp->zqsid =zqsid;
	lpDestTmp->sd =sd;
	lpDestTmp->isReqEnd =FALSE;
	lpDestTmp->userId =rand();
	lpDestTmp->recNum =recNum;
	lpDestTmp->curJys =(char)curJys;
	lpDestTmp->jyNum =jyNum;

	time(&lpDestTmp->startTime);
	strcpy(lpDestTmp->DesKey,key);

	if(lpDestNext !=jy_dests.lpDestHead)
		lpDestNext->lpNext =lpDestTmp;
	else jy_dests.lpDestHead =lpDestTmp;
	jy_dests.destCount ++;
	
	return lpDestTmp;
}

int ChangeJyDest(int sd, LPJY_DEST lpJyDest, int reqType, char curJys,
				 int userId, int jyNum)
{
	lpJyDest->isReqEnd =TRUE;
	if(reqType ==REQ_CHKUSR)
	{
		lpJyDest->userId =rand();
		lpJyDest->zqsid = userId;
		strcpy(lpJyDest->DesKey,key);
	}
	lpJyDest->sd =sd;
	lpJyDest->reqType =reqType;
	lpJyDest->curJys =curJys;
	lpJyDest->jyNum =jyNum;
	time(&lpJyDest->startTime);
	lpJyDest->isReqEnd =FALSE;

	return 0;
}

int CheckJyDest(int sd, int reqType, char curJys,
				char *gddm,	int userId, LPJY_DEST *lpDestTmp)
{
	*lpDestTmp =GetJyDestBySd(sd);
	if(reqType ==REQ_CHKUSR)
	{
		if(*lpDestTmp ==NULL)
			return 0;
		else
			return 1;
	}
	else
	{
		if(*lpDestTmp ==NULL) 
			return -1;
		if((*lpDestTmp)->isReqEnd ==FALSE) 
			return -2;
		if((*lpDestTmp)->userId !=userId) 
			return -3;
	}

	return 1;
}

void JyDest_Exit(int sd)
{

	LPJY_DEST lpJyDest;

	lpJyDest=GetJyDestBySd(sd);
	if(lpJyDest!=NULL)	
	{
		lpJyDest->sd=0;
		memset(lpJyDest->DesKey,0,9);
		lpJyDest->isReqEnd =TRUE;
	}
}

LPJY_DEST GetJyDest(char *lpgddm)
{
	int i;
 	LPJY_DEST lpDestTmp;
	
	for(i=0;i<jy_dest_count;i++)
	{
		lpDestTmp = &jy_dest[i];
		if(!lpDestTmp) break;
		if(!strncmp(lpDestTmp->gddm,lpgddm,strlen(lpgddm)))
			return lpDestTmp;
	}
	return NULL;
}

LPJY_DEST GetJyDestBySd(int sd)
{
	int i;
 	LPJY_DEST lpDestTmp;
	
	for(i=0;i<jy_dest_count;i++)
	{
		lpDestTmp = &jy_dest[i];
		if(!lpDestTmp) break;
		if(lpDestTmp->sd==sd)
			return lpDestTmp;
	}
	return NULL;
}

void FreeJyDest(void)
{
	LPJY_DEST lpDestNext, lpDestTmp;
	int i;

	return ;
	lpDestNext =lpDestTmp =jy_dests.lpDestHead;

	for(i =0; i<jy_dests.destCount; i++)
	{
		if(lpDestTmp ==NULL) break;
		lpDestNext =lpDestTmp->lpNext;
		free(lpDestTmp);
		lpDestTmp =lpDestNext;
	}

	jy_dests.destCount =0;
}

LPJY_DEST GetFirstIdelRec(void)
{
	int i;
 	LPJY_DEST lpDestTmp;
	
	for(i=0;i<jy_dest_count;i++)
	{
		lpDestTmp = &jy_dest[i];
		if(!lpDestTmp) break;
		if(lpDestTmp->sd==0)
			return lpDestTmp;
	}
	return NULL;
}

long TF_ScanJyDest(void)
{
	int i;
	LPJY_DEST lpDestNext;
	time_t time_now;

	//while(1)
	//{
		//if(run_cancelled) return 0;
		for(i =0; i<jy_dest_count; i++)
		{
			if(run_cancelled) break;
			ShoutBlockingHook();
			lpDestNext =&jy_dest[i];
			if(!lpDestNext) break;

			if(lpDestNext->sd==0)
				continue;
			time(&time_now);
			if(difftime(time_now, lpDestNext->startTime)>MAX_JY_TIME)
			{
				lpDestNext->sd=0;
				memset(lpDestNext->DesKey,0,9);
				lpDestNext->isReqEnd =TRUE;
				continue;
			}
			if(lpDestNext->isReqEnd ||lpDestNext->isSending) 
				continue;
			if(difftime(time_now, lpDestNext->startTime)>MAX_WAIT_TIME)
			{
				lpDestNext->isReqEnd =TRUE;
				Jy_SendRet(lpDestNext->sd, lpDestNext->reqType, ANS_TIME_OUT, lpDestNext->jyNum);
				continue;
			}

			switch(lpDestNext->reqType)
			{
			case REQ_CHKUSR:
				if(JyDest_ChkUsr(lpDestNext)<0)
					goto err_find;
				break;
			case REQ_CHGPWD:
				if(JyDest_ChgPwd(lpDestNext)<0)
					goto err_find;
				break;
			case REQ_BUYSEL:
				if(JyDest_BuySell(lpDestNext)<0)
					goto err_find;
				break;
			case REQ_CANCEL:
				if(JyDest_Cancel(lpDestNext)<0)
					goto err_find;
				break;
			case REQ_YECX:
				if(JyDest_Yecx(lpDestNext)<0)
					goto err_find;
				break;
			case REQ_CJCX:
				if(JyDest_Cjcx(lpDestNext)<0)
					goto err_find;
				break;
			case REQ_WTCX:
				if(JyDest_Wtcx(lpDestNext)<0)
					goto err_find;
				break;
			case REQ_EXIT:
				lpDestNext->isReqEnd =TRUE;
				break;
			default: 
				continue;
			}
			continue;
			err_find:
			lpDestNext->isReqEnd =TRUE;
		}
	//	Sleep(1000);
	//}
	//ExitThread(0);

	return 0;
}

int CreateScanJyDestThread(void)
{
//	LONG lThreadId;
//	
//	hThrdScanJyDest =CreateThread(NULL, 0,
//		(LPTHREAD_START_ROUTINE)TF_ScanJyDest,
//		NULL, CREATE_SUSPENDED, (LPDWORD)&lThreadId);
//	if(!hThrdScanJyDest) return -1;
//	SetThreadPriority(hThrdScanJyDest, THREAD_PRIORITY_NORMAL);
//	
//	ResumeThread(hThrdScanJyDest);
	
	return 0;
}

