#include <windows.h>
#include <time.h>

#include "main.h"

#include "hq.h"
#include "pctcp.h"
#include "hqdest.h"
#include "monitor.h"

#include "cl_hq.h"
#include "cl_data.h"
#include "cl_main.h"

CRITICAL_SECTION hqCriticalSection;

DEST_INFOS dest_infos;

DEST_INFO dest_info[MAX_USER_COUNT];
int  dest_info_count=0;

BOOL fDestInited =FALSE;
BOOL gfIsNewsSrcDel=FALSE;

HANDLE hThrdScanDest =NULL;
HANDLE hNewsManager =NULL;      

void FreeDest(void);

LPDEST_INFO GetDestByUser(LPSTR userID);
LPDEST_INFO GetFirstDeadDest(void);
int FillDpMain(LPDP_MAIN lpDpMain);

extern BOOL run_cancelled,gfReadData;

extern int Delay_Send_Hq01(LPDEST_INFO lpDest);

extern int UDP_Server_Send_Hq10(LPDEST_INFO);
extern int Send_Hq10(LPDEST_INFO lpDest);

extern int UDP_Server_Send_Gra10(LPDEST_INFO);
extern int Send_Gra10(LPDEST_INFO lpDest);

extern int UDP_Server_Send_Dp(int sd, struct sockaddr *lpdest, BOOL fThrd, LPDEST_INFO lpDest);
extern int UDP_ReadHq(int sd,char * RecvBuf,int len,struct sockaddr_in dest);

extern void HqResetChangedTimes(void);
extern void SetHqUsers(int);
extern BOOL IsZsRec(int, short);
extern int sdHq;
extern MONITOR Monitor;

extern int RefreshHq(int jys);

extern char szDataPath[128],szNewsPath[128],szNewsSrc[128];
extern char ZxDataFile[128];
extern HFILE hfZx;

extern int SendMsg(int sd, LPSTR);
extern BOOL ZlibCompressFile(char *infile,char *outfile);

BOOL DestInit(void)
{
	fDestInited =TRUE;
	memset(&dest_infos, 0, sizeof(dest_infos));
	memset(&dest_info[0],0,sizeof(DEST_INFO)*MAX_USER_COUNT);
	dest_infos.lpDestHead =&dest_info[0];
	dest_info_count=0;
	return TRUE;
}

void DestExit(void)
{
	if(!fDestInited) return;
	fDestInited =FALSE;
	if(hThrdScanDest) CloseHandle(hThrdScanDest);
	FreeDest();
}

long GetDestCount(void)
{
	return MAKELONG(dest_infos.destCount, dest_infos.aliveCount);
}

int LockDest(LPDEST_INFO lpDestTmp,int num)
{
	int i;

	i=0;

	lpDestTmp->isUsing = TRUE;
	return TRUE;
/*
	EnterCriticalSection(&hqCriticalSection);
	do
	{
		if(!lpDestTmp->isUsing)
		{
			lpDestTmp->isUsing = TRUE;
			LeaveCriticalSection(&hqCriticalSection);
			return TRUE;
		}
		LeaveCriticalSection(&hqCriticalSection);
		ShoutBlockingHook();
		Sleep(40);
		EnterCriticalSection(&hqCriticalSection);
		i++;
	}while(lpDestTmp->isUsing&&i<num);
	LeaveCriticalSection(&hqCriticalSection);
	return FALSE;
*/
}

int xLockDest(LPDEST_INFO lpDestTmp,int num)
{
	int i =0;

	do
	{
		if(!lpDestTmp->isUsing)
		{
			lpDestTmp->isUsing = TRUE;
			return TRUE;
		}
		i++;
	}while(lpDestTmp->isUsing&&i<num);
	return FALSE;
}

void UnlockDest(LPDEST_INFO lpDestTmp)
{
//	EnterCriticalSection(&hqCriticalSection);
		lpDestTmp->isUsing=FALSE;
//	LeaveCriticalSection(&hqCriticalSection);
}

int HqDestActiveUsr(int sd, struct sockaddr *lpdest, LPSTR userID,int ret)
{
	LPDEST_INFO lpDestTmp;  //lpDestTmp1;
	
	lpDestTmp =GetDestBySd(sd);

	if(lpDestTmp ==NULL) return -1;
	if(!LockDest(lpDestTmp,10))
	{
		ErrMsg(ghWndMain,"����HqDestActiveUsr:����ʧ��!");
		return -1;
	}
	strcpy(lpDestTmp->userID, userID);
	lpDestTmp->isDead =FALSE;
	lpDestTmp->recNum=ret;
	time(&lpDestTmp->startTime);
	lpDestTmp->inactive =0;
	dest_infos.aliveCount++;
	UnlockDest(lpDestTmp);
	return ((int)(lpDestTmp->version));
}

int AddDest(int sd, struct sockaddr *dest, int curJys,
			int reqType, short *params, short paramsCount,BYTE version)
{
	int i;
	LPDEST_INFO lpDestNext, lpDestTmp;
	LPDEST_INFO *lpDestNew =NULL;

	lpDestNext =dest_infos.lpDestHead;
	lpDestNew =&dest_infos.lpDestHead;

    if(paramsCount<0||paramsCount>MAX_PARA_COUNT)
	{
		ErrMsg(ghWndMain,"����AddDest:����Ĳ�������!");
		return -1;
	}

	if(dest_info_count>MAX_USER_COUNT)
	{
		ErrMsg(ghWndMain,"����AddDest:�޿��еĵ�ַ����!");
		return -1;
	}
	lpDestTmp=&dest_info[dest_info_count];
	if(dest_info_count>0)
		dest_info[dest_info_count-1].lpNext=&dest_info[dest_info_count];
	dest_info_count++;

	lpDestTmp->isUsing=FALSE;
	if(!LockDest(lpDestTmp,10)) 
	{
		ErrMsg(ghWndMain,"����AddDest:����ʧ��!");
		return -1;
	}

	memset(lpDestTmp, 0, sizeof(DEST_INFO));
	lpDestTmp->sd =sd;
	lpDestTmp->curJys =curJys;
	lpDestTmp->reqType =reqType;
	lpDestTmp->isDead =FALSE;
	lpDestTmp->inactive =0;

	if(lpDestTmp->params==NULL)
		lpDestTmp->params =GlobalLock(GlobalAlloc(GHND,(MAX_PARA_COUNT+1)*sizeof(short)));

	if(lpDestTmp->params ==NULL)
	{
		ErrMsg(ghWndMain,"����AddDest:���ܷ�������ڴ���!");
		UnlockDest(lpDestTmp);
		return -1;
	}
	if(reqType ==REQ_GRA10)
	{
		lpDestTmp->graNo =params[0];
		lpDestTmp->graEnd =params[1];
	}
	else
	memcpy(lpDestTmp->params, params, sizeof(short)*paramsCount);

	if(lpDestTmp->lpCjss ==NULL)
		lpDestTmp->lpCjss =GlobalLock(GlobalAlloc(GHND,MAX_PARA_COUNT*sizeof(int)));
	if(lpDestTmp->lpCjss ==NULL)
	{
		GlobalUnlock(GlobalHandle(lpDestTmp->params));
		GlobalFree(GlobalHandle(lpDestTmp->params));
		lpDestTmp->params ==NULL;

		ErrMsg(ghWndMain,"����AddDest:���ܷ���lpCjss�����ڴ���!");
		UnlockDest(lpDestTmp);
		return -1;
	}

	if(reqType ==REQ_HQ10||reqType ==REQ_HQ01)
	{
		for(i =0; i<params[0]; i++)
		{
			lpDestTmp->lpCjss[i] =HqData[curJys].lpRefData[params[i+1]].cjss;
		}
	}
	else if(reqType ==REQ_GRA10)
	{
		if(IsZsRec(curJys, params[0]))
		{
			lpDestTmp->lpZsGraph =GlobalLock(GlobalAlloc(GHND,sizeof(ZS_GRAPH)));   
			if(lpDestTmp->lpZsGraph ==NULL)
			{
				ErrMsg(ghWndMain,"����AddDest:���ܷ���ZS_RGAPH�ڴ���!");
				UnlockDest(lpDestTmp);
				return -1;
			}
			memcpy(lpDestTmp->lpZsGraph->Maxmin, MaxMinData[curJys],
					sizeof(MAXMIN_DATA)*2);
		}
		else
		{
			lpDestTmp->lpGraph =GlobalLock(GlobalAlloc(GHND,sizeof(GRAPH)));
			if(lpDestTmp->lpGraph ==NULL)
			{
				ErrMsg(ghWndMain,"����AddDest:���ܷ���GRAPH�ڴ���!");
				UnlockDest(lpDestTmp);
				return -1;
			}
			memcpy(&lpDestTmp->lpGraph->mmp, &MmpData[curJys].lpMmp[params[0]],
					sizeof(MMP));
		}
		lpDestTmp->cjss =HqData[curJys].lpRefData[params[0]].cjss;
	}
	else
	{
		ErrMsg(ghWndMain, "����AddDest:���������!");
		UnlockDest(lpDestTmp);
		return -1;
	}

	FillDpMain(&lpDestTmp->DpData[0]);
	
	if(version!=0)
		lpDestTmp->version =version;

	lpDestTmp->paramsCount =paramsCount;
	*lpDestNew =lpDestTmp;
	dest_infos.destCount ++;
	UnlockDest(lpDestTmp);
	return 0;
}

int ChangeDest(int sd, LPDEST_INFO lpDestTmp, struct sockaddr *dest, int curJys,
			int reqType, short *params, short paramsCount,BYTE version)
{
	int i;
	
	if(lpDestTmp ==NULL) return 0;
	if(!LockDest(lpDestTmp,10)) return -1;     

	lpDestTmp->isDead =FALSE;
	lpDestTmp->sd =sd;
	lpDestTmp->curJys =curJys;
	lpDestTmp->reqType =reqType;
	lpDestTmp->inactive =0;
	if(version!=0)
		lpDestTmp->version=version;
	if(paramsCount<0||paramsCount>MAX_PARA_COUNT||lpDestTmp->params ==NULL)
	{
		ErrMsg(ghWndMain,"����ChangeDest:����Ĳ�������!");
		UnlockDest(lpDestTmp);
		return -1;
	}

	if(reqType ==REQ_HQ10||reqType ==REQ_HQ01)
	{
		if(params[0]+params[1]+1>HqData[curJys].recCount)
		{
			params[0]=HqData[curJys].recCount-params[1];
		}       
		for(i =0; i<params[0]; i++)
		{
			if(params[i+1]<0||params[i+1]>=HqData[curJys].recCount)
			{
				ErrMsg(NULL,"����ChangeDest:������б�����!");
				UnlockDest(lpDestTmp);
				return -1;
			}
			lpDestTmp->lpCjss[i] =HqData[curJys].lpRefData[params[i+1]].cjss;
		}
	}
	else if(reqType ==REQ_GRA10)
	{
		if(IsZsRec(curJys, params[0]))
		{
			if(lpDestTmp->lpZsGraph ==NULL)
			{
				lpDestTmp->lpZsGraph =GlobalLock(GlobalAlloc(GHND,sizeof(ZS_GRAPH)));
				if(lpDestTmp->lpZsGraph ==NULL)
				{
					ErrMsg(ghWndMain, "����ChangeDest:����ZS_GARPH�ڴ�ʧ��!");
					UnlockDest(lpDestTmp);
					return -1;
				}
			}
			memcpy(lpDestTmp->lpZsGraph->Maxmin, MaxMinData[curJys],
					sizeof(MAXMIN_DATA)*2);
		}
		else
		{
			if(lpDestTmp->lpGraph ==NULL)
			{
				lpDestTmp->lpGraph =GlobalLock(GlobalAlloc(GHND,sizeof(GRAPH)));
				if(lpDestTmp->lpGraph ==NULL)
				{
					ErrMsg(ghWndMain, "����ChangeDest:����GARPH�ڴ�ʧ��!");
					UnlockDest(lpDestTmp);      
					return -1;
				}
			}
			memcpy(&lpDestTmp->lpGraph->mmp, &MmpData[curJys].lpMmp[params[0]],
					sizeof(MMP));
		}
		lpDestTmp->cjss =HqData[curJys].lpRefData[params[0]].cjss;
	}
	else
	{
		UnlockDest(lpDestTmp);
		ErrMsg(ghWndMain, "����ChangeDest:���������!");
		return -1;
	}
	if(reqType ==REQ_GRA10)
	{
		lpDestTmp->graNo =params[0];
		lpDestTmp->graEnd =params[1];
	}
	else
	memcpy(lpDestTmp->params, params, sizeof(short)*paramsCount);
	
	FillDpMain(&lpDestTmp->DpData[0]);
	
	lpDestTmp->paramsCount =paramsCount;
	UnlockDest(lpDestTmp);
	return 0;
}

int CheckDest(int sd, struct sockaddr *dest, int curJys,
			int reqType, short *params, short paramsCount,BYTE version)
{
	int ret;
	LPDEST_INFO lpDestTmp;

	lpDestTmp=GetDestBySd(sd);

	if(lpDestTmp ==NULL)
	{
		lpDestTmp =GetFirstDeadDest();
		if(!lpDestTmp) goto add_dest;
	}
	ret=ChangeDest(sd, lpDestTmp, dest, curJys, reqType,
			params, paramsCount,version);
	return ret;

add_dest:
	ret=AddDest(sd, dest, curJys, reqType, params, paramsCount,version);

	return ret;
}

int HqDestSetDeadByPrt(LPDEST_INFO lpDestTmp)
{

	if(lpDestTmp->isDead ==FALSE)
	{
		if(--dest_infos.aliveCount <0) dest_infos.aliveCount =0;
	}
	shutdown(lpDestTmp->sd,2);
	closesocket(lpDestTmp->sd);

	lpDestTmp->sd=0;
	strcpy(lpDestTmp->userID,"");
	lpDestTmp->recNum=0;
	lpDestTmp->isDead =TRUE;
	lpDestTmp->isUsing=FALSE;
	lpDestTmp->inactive =0;

	return 0;
}

int HqDestSetDeadBySd(int sd)
{
	LPDEST_INFO lpDestTmp;
//	int i;

	lpDestTmp=GetDestBySd(sd);
	if(lpDestTmp!=NULL)
	{
		//if(!LockDest(lpDestTmp))
		//{
		//      ErrMsg(ghWndMain,"����HqDestSetDeadBySd:����ʧ��!");
		//      return -1;
		//}
		if(lpDestTmp->isDead ==FALSE)
		{
			if(--dest_infos.aliveCount <0) dest_infos.aliveCount =0;
		}
		shutdown(lpDestTmp->sd,2);

		//for(i=0;i<10;i++)
		//{
		//	if(closesocket(lpDestTmp->sd)==0)
		//		break;
		//	Sleep(100);
		//}
		closesocket(lpDestTmp->sd);

		lpDestTmp->sd=0;
		strcpy(lpDestTmp->userID,"");
		lpDestTmp->recNum=0;
		lpDestTmp->isDead =TRUE;
		lpDestTmp->isUsing=FALSE;
		lpDestTmp->inactive =0;
		//UnlockDest(lpDestTmp);
	}
	return 0;
}

int HqDestStopBySd(sd)
{
	LPDEST_INFO lpDestTmp;
//	int i;

	lpDestTmp=GetDestBySd(sd);
	if(lpDestTmp!=NULL)
	{
		if(lpDestTmp->isDead ==FALSE)
		{
			if(--dest_infos.aliveCount <0) dest_infos.aliveCount =0;
		}
		shutdown(lpDestTmp->sd,2);
		//for(i=0;i<10;i++)
		//{
		//	if(closesocket(lpDestTmp->sd)==0)
		//		break;
		//	Sleep(100);
		//}
		closesocket(lpDestTmp->sd);

		lpDestTmp->isDead =TRUE;
		lpDestTmp->sd=0;
		strcpy(lpDestTmp->userID,"");
		lpDestTmp->recNum=0;
		lpDestTmp->isUsing=FALSE;
		lpDestTmp->inactive =0;
	}
	return 0;
}

LPDEST_INFO GetDestByUser(LPSTR userID)
{
	int i;
	LPDEST_INFO lpDestTmp;
	
	lpDestTmp =dest_infos.lpDestHead;

	for(i =0; i<dest_infos.destCount; i++)
	{
		if(!lpDestTmp) break;
		if(strcmp(lpDestTmp->userID, userID) ==0)
		{
			return lpDestTmp; 
		}
		lpDestTmp =lpDestTmp->lpNext;
	}
	
	return NULL;
}

LPDEST_INFO GetDestBySd(int sd)
{
	int i;
	LPDEST_INFO lpDestTmp;
	
	for(i =0; i<dest_info_count; i++)
	{
		lpDestTmp=&dest_info[i];
		if(!lpDestTmp) break;
		if(lpDestTmp->sd==sd)
		{
			return lpDestTmp;
		}
	}
	
	return NULL;
}

LPDEST_INFO GetAnotherUserById(char *Id,int sd)
{
	int i;
	LPDEST_INFO lpDestTmp;
	
	for(i =0; i<dest_info_count; i++)
	{
		lpDestTmp=&dest_info[i];
		if(!lpDestTmp) break;
		if(lpDestTmp->sd!=sd&&strncmp(Id,lpDestTmp->userID,6)==0)
		{
			return lpDestTmp;
		}
	}
	
	return NULL;
}
LPDEST_INFO HqDestSendClose()
{
	int i;
	LPDEST_INFO lpDestTmp;
	
	for(i =0; i<dest_infos.destCount; i++)
	{
		lpDestTmp=&dest_info[i];
		if(lpDestTmp)
		{
			if(!lpDestTmp->isDead)
				SendMsg(lpDestTmp->sd, "��������ʼ�ر�!");
		}
	}

	for(i =0; i<dest_infos.destCount; i++)
	{
		lpDestTmp=&dest_info[i];

		if(lpDestTmp)
		HqDestSetDeadByPrt(lpDestTmp);
	}
	return lpDestTmp;
}

LPDEST_INFO GetFirstDeadDest(void)
{
	int i;
	LPDEST_INFO lpDestTmp;
	
	for(i =0; i<dest_info_count; i++)
	{
		lpDestTmp=&dest_info[i];
		if(!lpDestTmp) break;
		if(lpDestTmp->isDead ==TRUE && lpDestTmp-> isUsing==FALSE)
		{
			lpDestTmp->recNum =0;
			strcpy(lpDestTmp->userID,"");
			return lpDestTmp;
		}
	}
	return NULL;
}

void DelDeads(void)
{
	LPDEST_INFO lpDestPrev, lpDestNext, lpDestTmp;
	int i, count =0;
	if(dest_infos.aliveCount ==dest_infos.destCount)
		return;
	lpDestNext =lpDestTmp =dest_infos.lpDestHead;
	if(lpDestTmp ==NULL) return;

	for(i =0; i<dest_infos.destCount; i++)
	{
		if(!lpDestTmp) break;
		if(!LockDest(lpDestTmp,10)) return ;
		lpDestNext =lpDestTmp->lpNext;
		if(!LockDest(lpDestNext,10)) return ;
		if(lpDestTmp->isDead)
		{
			lpDestTmp->isDead =TRUE;
			if(lpDestTmp ==dest_infos.lpDestHead)
				dest_infos.lpDestHead =lpDestNext;
			else lpDestPrev->lpNext =lpDestNext;
			GlobalUnlock(GlobalHandle(lpDestTmp->params));
			GlobalFree(GlobalHandle(lpDestTmp->params));
			lpDestTmp->paramsCount =0;
			if(lpDestTmp->lpCjss)
			{                               
				GlobalUnlock(GlobalHandle(lpDestTmp->lpCjss));
				GlobalFree(GlobalHandle(lpDestTmp->lpCjss));
			}
			lpDestTmp->lpCjss =NULL;
			if(lpDestTmp->lpGraph)
			{
				GlobalUnlock(GlobalHandle(lpDestTmp->lpGraph));
				GlobalFree(GlobalHandle(lpDestTmp->lpGraph));
			}
			lpDestTmp->lpGraph =NULL;
			if(lpDestTmp->lpZsGraph)
			{
				GlobalUnlock(GlobalHandle(lpDestTmp->lpZsGraph));
				GlobalFree(GlobalHandle(lpDestTmp->lpZsGraph));
			}
			lpDestTmp->lpZsGraph =NULL;
			count++;
		}
		else
			lpDestPrev =lpDestTmp;
		UnlockDest(lpDestTmp);
		UnlockDest(lpDestNext);
		lpDestTmp =lpDestNext;
	}
	dest_infos.destCount -=count;
}

void FreeDest(void)
{
	LPDEST_INFO lpDestTmp;
	int i;

	for(i =0; i<MAX_USER_COUNT; i++)
	{
		lpDestTmp =&dest_info[i];       
		if(lpDestTmp ==NULL) 
			continue;
		if(lpDestTmp->params)
		{
			GlobalUnlock(GlobalHandle(lpDestTmp->params));
			GlobalFree(GlobalHandle(lpDestTmp->params));
		}
		if(lpDestTmp->lpCjss) 
		{
			GlobalUnlock(GlobalHandle(lpDestTmp->lpCjss));
			GlobalFree(GlobalHandle(lpDestTmp->lpCjss));
		}
		if(lpDestTmp->lpGraph)
		{
			GlobalUnlock(GlobalHandle(lpDestTmp->lpGraph));
			GlobalFree(GlobalHandle(lpDestTmp->lpGraph));
		}
		if(lpDestTmp->lpZsGraph)
		{
			GlobalUnlock(GlobalHandle(lpDestTmp->lpZsGraph));
			GlobalFree(GlobalHandle(lpDestTmp->lpZsGraph));
		}
	}
	dest_info_count =0;
}

int check_socket_status(int sd)
{
	struct timeval wait;
	fd_set send_ready,except;

	wait.tv_sec =wait.tv_usec=0;
	FD_ZERO(&send_ready);
	FD_ZERO(&except);
	FD_SET(sd,&send_ready);
	FD_SET(sd,&except);
	if(select(FD_SETSIZE,(fd_set *)0,&send_ready,
			&except,&wait)<0)
		return(-1);
	if(FD_ISSET(sd,&send_ready))
		return(0);
	else if(FD_ISSET(sd,&except))
		return(-2);
	else
		return(-3);
}


long TF_ScanDest(void)
{
	int i,j,ret,jys;
	LPDEST_INFO lpDestNext;
	DP_MAIN DpMain[2];

	while(1)
	{
		if(run_cancelled) break;

		if(IsClectRun)
		{
			if(clCheckTime(TRUE) >=0)
			{
				if(HqTime[0].fRunning)
				{
					if(!RefreshHqData(0))
					{
						MsgLocal("��������ˢ��ʧ�ܣ���������");
						HqTime[0].fRunning =FALSE;
						CloseDbfFile(0);
					}
					CreateLzwMemData(0);
				}
				if(HqTime[1].fRunning)  
				{
					if(!RefreshHqData(1))
					{
						MsgLocal("�Ϻ�����ˢ��ʧ�ܣ���������");
						HqTime[1].fRunning =FALSE;
						CloseDbfFile(1);                                
					}
					CreateLzwMemData(1);
				}
			}       
		}
		else
		{
			RefreshHq(0);
			RefreshHq(1);
		}

		MsgLocal("ɨ�������û�...");
		for(i =0,j=0; i<dest_info_count; i++)
		{
			if(run_cancelled) break;
			lpDestNext=&dest_info[i];

			if(!lpDestNext) 
				break;
			if(lpDestNext->isDead)
				continue;

			lpDestNext->inactive++;
			ret =check_socket_status(lpDestNext->sd);
			if(ret ==0)
			{
				if(!xLockDest(lpDestNext,3))
					continue;

				switch(lpDestNext->reqType)
				{
				case REQ_HQ01:
					Delay_Send_Hq01(lpDestNext);
					UnlockDest(lpDestNext);
				break;
				case REQ_HQ10:
					if(lpDestNext->version <12)
					{
						ret =UDP_Server_Send_Hq10(lpDestNext);
						UnlockDest(lpDestNext);
					}
					if(lpDestNext->version ==12)
						ret =Send_Hq10(lpDestNext);
					if(ret<0) continue;
					break;
				case REQ_GRA10:
					if(lpDestNext->version <12)
					{
						ret =UDP_Server_Send_Gra10(lpDestNext);
						UnlockDest(lpDestNext);
					}
					if(lpDestNext->version ==12)
						ret =Send_Gra10(lpDestNext);
					if(ret<0) continue;
					break;
				default:
					UnlockDest(lpDestNext);
					break;
				}       
			//}
			    FillDpMain(&DpMain[0]);
			//if(ret ==0)
			//{
				if(memcmp(&lpDestNext->DpData, &DpMain, sizeof(DpMain))||
					lpDestNext->inactive>10)
				{
					if(UDP_Server_Send_Dp(lpDestNext->sd,NULL, FALSE,lpDestNext) >0)
						memcpy(&lpDestNext->DpData, &DpMain, sizeof(DpMain));                   
					if(lpDestNext->inactive>10)
						lpDestNext->inactive =0;
				}
			}
			else
			{
				if(ret == -2) HqDestStopBySd(lpDestNext->sd);
			}

			j++;
		}
		SetHqUsers(j);
		Sleep(2000);
	}

	if(IsClectRun)
	{
		for(jys =0;jys<2;jys++)
		{
			WriteHqData(jys);
			WriteMmpData(jys);
			WriteMaxMinData(jys);
			WriteDpData(jys);
		}
		SetEvent(g_hEventDataWrite);
	}

	ExitThread(0);
	return 0;
}


int CreateScanDestThread(void)
{
      LONG lThreadId;
	
	hThrdScanDest =CreateThread(NULL, 0,
	      (LPTHREAD_START_ROUTINE)TF_ScanDest,
	      NULL, CREATE_SUSPENDED, (LPDWORD)&lThreadId);
	if(!hThrdScanDest) return -1;
	//SetThreadPriority(hThrdScanDest, THREAD_PRIORITY_NORMAL);
	SetThreadPriority(hThrdScanDest, THREAD_PRIORITY_ABOVE_NORMAL);

	ResumeThread(hThrdScanDest);
	
	return 0;
}

int FillDpMain(LPDP_MAIN lpDpMain)
{
	int jys;

	for(jys =0; jys<2; jys++)
	{
		lpDpMain[jys].zs =DpData[jys].zs[0];
		lpDpMain[jys].zd =DpData[jys].zd[0];
		lpDpMain[jys].cjzje =DpData[jys].cjzje;
		lpDpMain[jys].npbl =DpData[jys].npbl;
		lpDpMain[jys].cjss =DpData[jys].cjss;
		lpDpMain[jys].upCount =DpData[jys].upCount;
		lpDpMain[jys].downCount =DpData[jys].downCount;
		lpDpMain[jys].equalCount =DpData[jys].equalCount;
	}
	
	return 0;
}

extern BOOL FileTranLock;

BOOL GetNewsIndex(char * szNewsDir)
{
	HFILE hFile;
	OFSTRUCT os;
	char file[80],search[128],content[200];
    WIN32_FIND_DATA FindData;
    HANDLE hFindFile;
	BOOL fFind;
	SYSTEMTIME SysTime;
	BOOL ret =FALSE;

	sprintf(file,"%s\\news.idx",szDataPath);
	hFile =OpenFile(file, &os, OF_SHARE_DENY_READ|OF_WRITE|OF_CREATE);
	if(hFile ==HFILE_ERROR) 
		return ret;
	sprintf(search,"%s\\*.*",szNewsDir);
	hFindFile =FindFirstFile(search,&FindData);
	if(hFindFile!=INVALID_HANDLE_VALUE)
	{
		FileTimeToSystemTime((FILETIME *)&FindData.ftLastWriteTime,
			(SYSTEMTIME*)&SysTime);
		sprintf(content,"%12s %ld.%02ld.%02ld %02ld.%02ld:%02ld %ld\n",
			FindData.cFileName,
			SysTime.wYear,
			SysTime.wMonth,
			SysTime.wDay,
			SysTime.wHour,
			SysTime.wMinute,
			SysTime.wSecond,
			FindData.nFileSizeLow +FindData.nFileSizeHigh *256);
		if(FindData.dwFileAttributes!=FILE_ATTRIBUTE_DIRECTORY) 
		{
			_lwrite(hFile,content,strlen(content));
			ret =TRUE;
		}
		do
		{
			fFind =FindNextFile(hFindFile,&FindData);
			if(fFind)
			{
				FileTimeToSystemTime((FILETIME *)&FindData.ftLastWriteTime,
					(SYSTEMTIME*)&SysTime);
				sprintf(content,"%12s %ld.%02ld.%02ld %02ld.%02ld:%02ld %ld\n",
					FindData.cFileName,
					SysTime.wYear,
					SysTime.wMonth,
					SysTime.wDay,
					SysTime.wHour,
					SysTime.wMinute,
					SysTime.wSecond,
					FindData.nFileSizeLow +FindData.nFileSizeHigh *256);                    
				if(FindData.dwFileAttributes!=FILE_ATTRIBUTE_DIRECTORY) 
				{
					_lwrite(hFile,content,strlen(content));
					ret =TRUE;
				}
			}
		}while(fFind);
		FindClose(hFindFile);
	}
	_lclose(hFile);
	return ret;
}

void DelNews(LPSTR szNewsDir)
{
	char file[128],search[128];
    WIN32_FIND_DATA FindData;
    HANDLE hFindFile;
	BOOL fFind;

	sprintf(search,"%s\\*.*",szNewsDir);
	hFindFile =FindFirstFile(search,&FindData);
	if(hFindFile!=INVALID_HANDLE_VALUE)
	{
		sprintf(file,"%s\\%s",szNewsDir,FindData.cFileName);
		if(FindData.dwFileAttributes!=FILE_ATTRIBUTE_DIRECTORY) 
				DeleteFile(file);
		do
		{
			fFind =FindNextFile(hFindFile,&FindData);
			if(fFind)
			{
				sprintf(file,"%s\\%s",szNewsDir,FindData.cFileName);
				if(FindData.dwFileAttributes!=FILE_ATTRIBUTE_DIRECTORY) 
					DeleteFile(file);
			}
		}while(fFind);
		FindClose(hFindFile);
	}
}

void MoveNews(LPSTR szNewsTo,LPSTR szNewsFrom)
{

	char to[128],search[128],from[128],temp[128];
    WIN32_FIND_DATA FindData;
    HANDLE hFindFile;
	BOOL fFind;
	OFSTRUCT os;
	SYSTEMTIME CurDate,FileDate;

	if(szNewsTo[0]==0||szNewsFrom[0]==0) 
		return;
	GetSystemTime(&CurDate);
	sprintf(search,"%s\\*.*",szNewsFrom);
	hFindFile =FindFirstFile(search,&FindData);
	if(hFindFile!=INVALID_HANDLE_VALUE)
	{
		sprintf(to,"%s\\%s",szNewsTo,FindData.cFileName);
		sprintf(from,"%s\\%s",szNewsFrom,FindData.cFileName);
		FileTimeToSystemTime((FILETIME *)&FindData.ftLastWriteTime,
			(SYSTEMTIME*)&FileDate);

		if(FindData.dwFileAttributes!=FILE_ATTRIBUTE_DIRECTORY &&
				FileDate.wMonth ==CurDate.wMonth &&
				FileDate.wDay ==CurDate.wDay) 
		{
			strcpy(temp,FindData.cFileName);
			strupr(temp);
			if(strstr(temp,".DBF")==NULL&&strstr(temp,".EXE")==NULL)
			{
				if(strstr(ZxDataFile,temp)==NULL)
				{
					CopyFile(from,to,TRUE);                 
					if(gfIsNewsSrcDel) DeleteFile(from);
				}
				else
				{
					_lclose(hfZx);
					CopyFile(from,ZxDataFile,TRUE);
					DeleteFile(from);
					hfZx =OpenFile(ZxDataFile, &os, OF_SHARE_DENY_NONE|OF_READ);
				}
			}
		}

		do
		{
			fFind =FindNextFile(hFindFile,&FindData);
			if(fFind)
			{
				sprintf(to,"%s\\%s",szNewsTo,FindData.cFileName);
				sprintf(from,"%s\\%s",szNewsFrom,FindData.cFileName);

				FileTimeToSystemTime((FILETIME *)&FindData.ftLastWriteTime,
					(SYSTEMTIME*)&FileDate);

				if(FindData.dwFileAttributes!=FILE_ATTRIBUTE_DIRECTORY &&
					FileDate.wMonth==CurDate.wMonth &&
					FileDate.wDay ==CurDate.wDay) 
				{
					strcpy(temp,FindData.cFileName);
					strupr(temp);
					if(strstr(temp,".DBF")==NULL&&strstr(temp,".EXE")==NULL)
					{
						if(strstr(ZxDataFile,temp)==NULL)
						{
							CopyFile(from,to,TRUE);
							if(gfIsNewsSrcDel) DeleteFile(from);
						}
						else
						{
							_lclose(hfZx);
							CopyFile(from,ZxDataFile,TRUE);
							DeleteFile(from);
							hfZx =OpenFile(ZxDataFile, &os, OF_SHARE_DENY_NONE|OF_READ);
						}
					}
				}
			}
		}while(fFind);
		FindClose(hFindFile);
	}
}

void RefreshNews(LPSTR szNewsTo,LPSTR szNewsFrom)
{
	char to[128],search[128],from[128],temp[200];
    WIN32_FIND_DATA FindData;
    HANDLE hFindFile ;
	HFILE hFile;
	BOOL fFind;
	OFSTRUCT os;
	SYSTEMTIME CurDate,FileDate;

	if(szNewsTo[0]==0||szNewsFrom[0]==0) 
		return;
	sprintf(temp,"%s\\news.idx",szDataPath);
	hFile =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_WRITE);
	if(hFile ==HFILE_ERROR)
		return;
	if(_llseek(hFile, 0, SEEK_END)==HFILE_ERROR)
	{
		_lclose(hFile);
		return;
	}

	GetSystemTime(&CurDate);
	sprintf(search,"%s\\*.*",szNewsFrom);
	hFindFile =FindFirstFile(search,&FindData);
	if(hFindFile!=INVALID_HANDLE_VALUE)
	{
		sprintf(to,"%s\\%s",szNewsTo,FindData.cFileName);
		sprintf(from,"%s\\%s",szNewsFrom,FindData.cFileName);
		FileTimeToSystemTime((FILETIME *)&FindData.ftLastWriteTime,
			(SYSTEMTIME*)&FileDate);

		if(FileDate.wMonth ==CurDate.wMonth &&
				FileDate.wDay ==CurDate.wDay) 
		{
			strcpy(temp,FindData.cFileName);
			strupr(temp);                   
			if(strstr(ZxDataFile,temp)==NULL&&strstr(temp,".DBF")==NULL
				&&strstr(temp,".EXE")==NULL)
			{
				if(CopyFile(from,to,TRUE))
				{
					sprintf(temp,"%12s %ld.%02ld.%02ld %02ld.%02ld:%02ld %ld\n",
						FindData.cFileName,
						FileDate.wYear,
						FileDate.wMonth,
						FileDate.wDay,
						FileDate.wHour,
						FileDate.wMinute,
						FileDate.wSecond,
						FindData.nFileSizeLow +FindData.nFileSizeHigh *256);
					_lwrite(hFile,temp,strlen(temp));
				}
				if(gfIsNewsSrcDel) DeleteFile(from);
			}
		}
		do
		{
			fFind =FindNextFile(hFindFile,&FindData);
			if(fFind)
			{
				sprintf(to,"%s\\%s",szNewsTo,FindData.cFileName);
				sprintf(from,"%s\\%s",szNewsFrom,FindData.cFileName);

				FileTimeToSystemTime((FILETIME *)&FindData.ftLastWriteTime,
					(SYSTEMTIME*)&FileDate);

				if(FileDate.wMonth==CurDate.wMonth &&
					FileDate.wDay ==CurDate.wDay) 
				{
					strcpy(temp,FindData.cFileName);
					strupr(temp);
					if(strstr(ZxDataFile,temp)==NULL&&strstr(temp,".DBF")==NULL
						&&strstr(temp,".EXE")==NULL)
					{
						if(CopyFile(from,to,TRUE))
						{
							sprintf(temp,"%12s %ld.%02ld.%02ld %02ld.%02ld:%02ld %ld\n",
								FindData.cFileName,
								FileDate.wYear,
								FileDate.wMonth,
								FileDate.wDay,
								FileDate.wHour,
								FileDate.wMinute,
								FileDate.wSecond,
								FindData.nFileSizeLow +FindData.nFileSizeHigh *256);
							_lwrite(hFile,temp,strlen(temp));
						}
						if(gfIsNewsSrcDel) DeleteFile(from);
					}
				}
			}
		}while(fFind);
		FindClose(hFindFile);           
	}       
	_lclose(hFile);
}

long TF_NewsManager(void)
{
	SYSTEMTIME SysTime;
	static BOOL IsInit =FALSE;
	int minute ;

	while(1)
	{
		if(run_cancelled) break;
		GetLocalTime(&SysTime);
		minute = SysTime.wHour*60+SysTime.wMinute;
		if(minute<HqTime[0].am_min_start)
			IsInit =FALSE;
		else
		{
			if(!IsInit)
			{
				if(!FileTranLock)
				{
					FileTranLock =TRUE;
					Sleep(3000);
					DelNews(szNewsPath);
				}
				MoveNews(szNewsPath,szNewsSrc);
				if(GetNewsIndex(szNewsPath))
				{
					IsInit =TRUE;   
					FileTranLock =FALSE;
				}
			}
			else
			{
				RefreshNews(szNewsPath,szNewsSrc);
			}
		}
		Sleep(1000*60);
	}
	CloseHandle(hNewsManager);
	ExitThread(0);
	return 0;
}

int CreateNewsManagerThread(void)
{
      LONG lThreadId;
	
	hNewsManager =CreateThread(NULL, 0,
	      (LPTHREAD_START_ROUTINE)TF_NewsManager,
	      NULL, CREATE_SUSPENDED, (LPDWORD)&lThreadId);
	if(!hNewsManager) return -1;
	SetThreadPriority(hNewsManager, THREAD_PRIORITY_NORMAL);
	
	ResumeThread(hNewsManager);
	
	return 0;
}
