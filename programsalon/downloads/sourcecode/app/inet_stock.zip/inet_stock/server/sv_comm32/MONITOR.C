#include <windows.h>
#include <windowsx.h>
#include "monitor.h"
extern BOOL GetInitString(LPSTR, LPSTR, LPSTR);
extern BOOL ErrMsg(HWND, LPSTR);

MONITOR Monitor;
unsigned int StartNo;

typedef struct tag_HQ_USER
{
	unsigned int id;
	char pass[6+1];
	char priv;
}USER,*LPUSER;

LPUSER User=NULL;
int user_rec_num =0;

BOOL MonitorInit()
{
	char temp[200],tmp[100];
	char MonitorBuf[100];
    int i;

	memset(&Monitor.File,0,sizeof(DBF_DATA));
	Monitor.File.hf =-1;

	if(GetInitString("MONITOR", "RUN", temp))
	{
		if(temp[0] =='N' || temp[0] =='n')
		{
			Monitor.IsRun =FALSE;
			return TRUE;
		}
		else
			Monitor.IsRun=TRUE;
	}
	else
	{
		Monitor.IsRun=FALSE;
		return TRUE;
	}

	if(!GetInitString("MONITOR","FILE",temp))
	{
		ErrMsg(NULL,"Can not find file item in init file!");
		Monitor.IsRun=FALSE;
		return FALSE;
	}
    
	if(access(temp,_S_IREAD|_S_IWRITE) <0)
	{
		wsprintf(tmp, "can not read %s:\n %s",
			(LPSTR)"MONITORFILE", (LPSTR)temp);
		ErrMsg(NULL, tmp);
		Monitor.IsRun=FALSE;
		return FALSE;
	}

	Monitor.File.hf=OpenDbfBase(temp,O_RDWR);
	if (Monitor.File.hf==-1)
	{
			wsprintf(tmp, "can not open %s:\n %s",
					(LPSTR)"COMMFILE", (LPSTR)&temp[0]);
			ErrMsg(NULL, tmp);
			return FALSE;
		}
	if (InitBase(Monitor.File.hf,&Monitor.File.dbfStruct,
		&Monitor.File.fldStruct,&Monitor.File.fldCount)
			!=SUCCEED)
	{
		wsprintf(tmp, "can not init %s:\n %s",
					(LPSTR)"COMMFILE", (LPSTR)temp);
		ErrMsg(NULL, temp);
		return FALSE;
	}

	user_rec_num =*(int *)(Monitor.File.dbfStruct.recnum);
	User =GlobalAllocPtr(GHND,(DWORD)(user_rec_num*sizeof(USER)));
	if(User ==NULL)
	{
		ErrMsg(NULL, "Can not alloc user info memory");
		return FALSE;
	}
	for(i=0;i<user_rec_num;i++)	
	{
		ReadRecord(Monitor.File.hf,i+1L,*(short *)Monitor.File.dbfStruct.hlen,
			*(short *)Monitor.File.dbfStruct.rlen,MonitorBuf);

		FldToString(MonitorBuf,&Monitor.File.fldStruct[fld_CODE],temp);	
		User[i].id =atoi(temp);
		if(i==0)
		StartNo=User[0].id;

		FldToString(MonitorBuf,&Monitor.File.fldStruct[fld_PASS],temp);	
		strncpy(User[i].pass,temp,6);
		User[i].priv =MonitorBuf[*(short*)Monitor.File.fldStruct[fld_PRIV].offset];   
	}

	if(!GetInitString("MONITOR","CHECKPOINT",temp))
	{
		Monitor.CheckPoint=5;
	}
    else
	{
		Monitor.CheckPoint=atoi(temp);
	}
	return TRUE;
}

BOOL MonitorExit()
{
	if(Monitor.File.hf!=-1)
	{
		CloseDbf(Monitor.File.hf);
		if(Monitor.File.fldStruct)
			GlobalFreePtr(Monitor.File.fldStruct);
	}

	if(User!=NULL)
	GlobalFreePtr(User);

	return TRUE;
}

/*
int RegisterUser(char *UserId,char *Pass)
{
	int pos=1,priv,lock,recnum;
	char pass[7],userid[7],temp[10];
	char MonitorBuf[100];

	if(Monitor.File.hf ==-1) 
		return LOGIN_SYS_ERR;

	pos=atoi(UserId) - StartNo +1;
	if(pos>*(int *)(Monitor.File.dbfStruct.recnum)+1)
		recnum =GetRecNum(Monitor.File.hf);
	else
		recnum =*(int *)(Monitor.File.dbfStruct.recnum);

	if(pos<=recnum)
	{
		ReadRecord(Monitor.File.hf,pos,*(short *)Monitor.File.dbfStruct.hlen,
			*(short *)Monitor.File.dbfStruct.rlen,MonitorBuf);
	
		FldToString(MonitorBuf,&Monitor.File.fldStruct[fld_CODE],userid);
	}
	else
		userid[0]=0;

	if(strncmp(userid,UserId,6))
	{
		pos =1;
		do
		{
			ReadRecord(Monitor.File.hf,pos,*(short *)Monitor.File.dbfStruct.hlen,
				*(short *)Monitor.File.dbfStruct.rlen,MonitorBuf);
				
			FldToString(MonitorBuf,&Monitor.File.fldStruct[fld_CODE],userid);
			if(!(strncmp(userid,UserId,6)))
				break;
			else
			{
				if(pos>recnum)
				{
					return LOGIN_NO_THIS_ID;
				}
			}
			ShoutBlockingHook();
			pos++;
		}while(strncmp(userid,UserId,6));
	}

	FldToString(MonitorBuf,&Monitor.File.fldStruct[fld_PASS],pass);
	FldToString(MonitorBuf,&Monitor.File.fldStruct[fld_TIME],temp);
	lock=MonitorBuf[*(short*)Monitor.File.fldStruct[fld_LOCK].offset];   
	if(lock=='T')
		return LOGIN_LOCKED;
	priv=MonitorBuf[*(short*)Monitor.File.fldStruct[fld_PRIV].offset];   
    if(atoi(temp)==0&&priv!='9')
		return LOGIN_NO_TIME;
	if(atoi(temp)==-1&&priv!='9')
		return LOGIN_NO_THIS_ID;
	if(strncmp(Pass,pass,6))
		return LOGIN_NO_PRIV;
	else
		return pos;
}
*/

int RegisterUser(char *UserId,char *Pass)
{
	int pos=0;
	unsigned int ReqId;

	if(Monitor.File.hf ==-1) 
		return LOGIN_SYS_ERR;

	ReqId =atoi(UserId);

	pos=ReqId - StartNo;

	if(pos>=user_rec_num)
	{
		pos =0;
		for(;;)
		{
			if(User[pos].id==ReqId)
				break;
			pos++;
			if(pos>=user_rec_num)
				return LOGIN_NO_THIS_ID;
		}
	}
	else
	{
		if(User[pos].id!=ReqId)
		{
			pos =0;
			for(;;)
			{
				if(User[pos].id==ReqId)
					break;

				pos++;
				if(pos>=user_rec_num)
					return LOGIN_NO_THIS_ID;
			}
		}
	}

	if(strncmp(Pass,User[pos].pass,strlen(User[pos].pass)))
		return LOGIN_NO_PRIV;
	else
	{
		pos++;
		return pos;
	}
}

int WriteUserStatus(int Pos,int Utime,int Lstatus,char * ReqHead)
{
	char temp[20];
	char MonitorBuf[100];
	int rtime,priv;

	if(Monitor.File.hf ==-1) 
		return 0;

	memset(MonitorBuf,' ',100);

	ReadRecord(Monitor.File.hf,Pos,*(short *)Monitor.File.dbfStruct.hlen,
		*(short *)Monitor.File.dbfStruct.rlen,MonitorBuf);
	FldToString(MonitorBuf,&Monitor.File.fldStruct[fld_TIME],temp);
	rtime=atoi(temp);
	rtime-=Utime;
	if(rtime<0) rtime=0;
	sprintf(temp,"%d",rtime);
	StringToFld(MonitorBuf,Monitor.File.fldStruct[fld_TIME],temp);
	MonitorBuf[*(short*)Monitor.File.fldStruct[fld_LSTA].offset]=Lstatus;
	MonitorBuf[*(short*)Monitor.File.fldStruct[fld_USED].offset]='T';
	priv=MonitorBuf[*(short*)Monitor.File.fldStruct[fld_PRIV].offset];
	if(priv=='9')
		rtime=600;

	//strncpy(temp,ReqHead,strlen(ReqHead));
	//StringToFld(MonitorBuf,Monitor.File.fldStruct[fld_ADDR],temp);

	WriteRecord(Monitor.File.hf,Pos,*(short *)Monitor.File.dbfStruct.hlen,
		*(short *)Monitor.File.dbfStruct.rlen,MonitorBuf);

	return rtime;
}

char ReadLockControl(int Pos)
{
	char MonitorBuf[100];

	if(Monitor.File.hf ==-1) return 0;

	ReadRecord(Monitor.File.hf,Pos,*(short *)Monitor.File.dbfStruct.hlen,
		*(short *)Monitor.File.dbfStruct.rlen,MonitorBuf);
	return MonitorBuf[*(short*)Monitor.File.fldStruct[fld_LOCK].offset];
}

int SetUserEnv(int Pos,TCP_FRAME_HQ_ENV * lpPara,int len)
{
	char temp[10];
	char MonitorBuf[100];

	if(Monitor.File.hf ==-1) 
		return SET_SYS_ERROR;
	if(len!=sizeof(TCP_FRAME_HQ_ENV))
		return SET_DATA_ERROR;

	memset(MonitorBuf,' ',100);

	ReadRecord(Monitor.File.hf,Pos,*(short *)Monitor.File.dbfStruct.hlen,
		*(short *)Monitor.File.dbfStruct.rlen,MonitorBuf);
	FldToString(MonitorBuf,&Monitor.File.fldStruct[fld_PASS],temp);
    if(strncmp(temp,lpPara->pwd,6)!=0)
		return SET_PWD_ERROR;
	StringToFld(MonitorBuf,Monitor.File.fldStruct[fld_PASS],lpPara->newpwd);
	WriteRecord(Monitor.File.hf,Pos,*(short *)Monitor.File.dbfStruct.hlen,
		*(short *)Monitor.File.dbfStruct.rlen,MonitorBuf);

	if(Pos>0 &&Pos <=user_rec_num)
		strncpy(User[Pos-1].pass ,lpPara->newpwd,strlen(lpPara->newpwd));

	return SET_SUCC;
}