#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <winsock.h>
#include <time.h>
#include <dos.h>
#include <io.h>

#include "appmain.h"
#include "pctcp.h"
#include "hq.h"
#include "hq_cl.h"
#include "hq_tcp.h" 
#include "caption.h"
#include "msg.h"

#include "fx.h"
#include "lzw.h"
#include "zlib.h"

extern BOOL ErrMsg(HWND, LPSTR);
extern HWND ghWndMain, ghWndHq, ghWndXlt, ghWndJlt, ghWndCj, ghWndLitHq,
			ghWndMmp, ghWndMaxMin, ghWndStatus, ghWndCaption;
extern HWND ghDlgJy, ghDlgChkUsr, ghDlgChgPwd, ghDlgBuySell, ghDlgCancel,
			ghDlgYecx, ghDlgWtcx, ghDlgCjcx;

extern BOOL run_cancelled;
extern int sdHq, sdJy;
extern char * ReadBuf;	//[MAX_READ_BUF_SIZE+1];  

extern char szDataPath[128];

extern BOOL IsZsRec(int, int);
extern LPSTR GetError(LPSTR);
extern HFILE hfZx;
extern int FxInit(LPFX Fx);
extern LPFX Fx;
extern BOOL gfOnLine,gfConnecting;

BOOL HqAllocMem(int);

int date_num =-1;
int GraRecalcJgMax();
int GraRecalcLcMax();
int MaxMinChangeHqData(int jys, int maxmin);
int GraGetMinPos(void);
void WriteMsg(LPSTR msg);
int UDP_Read_GetZqmc(LPSTR lpTmp, int len);
int UDP_Read_DataDay(LPSTR lpTmp, int len);
int UDP_Read_ChkUsr(LPSTR lpTmp, int len);

#define 	DATA_START_SIGN 	-16

extern char *IpSendBuffer,*IpCommitBuffer;
extern unsigned int IpSendLen,IpCommitLen;

void Ip_Commit_Pack(int len,char *buff)
{   
	IpCommitLen =len;
	memcpy(IpCommitBuffer,buff,len);	
}
	
BOOL  Ip_Send_Pack()
{   
	int x,k,this;
    char tmp[100];
	
	if(IpCommitLen ==0)	
		return TRUE;
	if(IpSendLen!=0)	
		return TRUE;
	//if((x=check_socket_status(sdHq))!=0)
	//	return TRUE;
	
	memcpy(IpSendBuffer,IpCommitBuffer,IpCommitLen);
	IpSendLen = IpCommitLen;
	IpCommitLen =0;
	
	for(k=0,x=0;k<1000;k++)
	{
		this = send(sdHq,IpSendBuffer, IpSendLen-x, 0);
		if (this == SOCKET_ERROR)
		{                          
			if ((this =h_errno) != WSAEWOULDBLOCK)
			{
				strcpy(tmp,"���ܽ���������Ϣ��");
				ErrMsg(ghWndMain, GetError(tmp));
				gfOnLine=FALSE;
				return FALSE;
			}
		}
		if(x+this!=(int)IpSendLen)
			x+=this;
		else
			break;		
	}
	IpSendLen =0;
	return	TRUE;
}   

int UDP_Send_Hq(LPSTR lpString, LPSTR lpHead, int len)
{
	char tmp2[MAX_WRITE_BUF_SIZE+1];
	int x=0,tlen;
	
	if(!gfOnLine||gfConnecting) return 0;
    
    memset(&tmp2[0],0,sizeof(MAX_WRITE_BUF_SIZE));
    tmp2[0]=DATA_START_SIGN;
    *(int *)&tmp2[1]=len;    
	memcpy(&tmp2[1+sizeof(int)], lpString, len);
	
	tlen = 1+sizeof(int) + len;
	
	Ip_Commit_Pack(tlen, &tmp2[0]);
	return len;
}

extern FILE *fp;

#define		DATA_HEAD_SIZE	3

char dataHead[DATA_HEAD_SIZE+1];
int  HeadPrt=0,dataPrt=0 ;
 
int AnaRecvData(void)
{
  int prt,len,try_times,dataNum,ret;
  char temp[MAX_READ_BUF_SIZE+1];  

   prt=len=try_times=dataNum=0;
   
retry_read:
	if(try_times ++>MAX_UDP_TRY_TIMES)
	{
		ErrMsg(ghDlgJy, "recv error");
		DrawTime(RED_SIGN);
		return -1;
	}	
	DrawTime(GREEN_SIGN);
	memset((char *)&temp[0],0,MAX_READ_BUF_SIZE*sizeof(char));
	len = recv(sdHq,(char *)&temp[0],MAX_READ_BUF_SIZE*sizeof(char),0);
	if (len == SOCKET_ERROR) 
	{
		ret =h_errno;
		if (ret == WSAEWOULDBLOCK)
			goto retry_read;
		else if(ret ==WSAEINPROGRESS)
			return 0;
		else
		{
			ErrMsg(ghDlgJy, GetError("recv cancel error"));
			if(ConnectHost(0, -1)<0)
			{
				ErrMsg(ghDlgJy, "Reconnect failed");
				DrawTime(RED_SIGN);
				return -1;
			}
		}
	}
	if(len <=0) 
	{
		DrawTime(RED_SIGN);
		return -1;
    } 
    if(len>4)
    {
    	if(temp[0]==DATA_START_SIGN && HeadPrt!=0 &&temp[3]>='A' && temp[3]<='Z')
    	{
     		dataPrt=0; 
     		HeadPrt=0;
    	}
    }	
    while(prt<len)
    {
     	if(HeadPrt<DATA_HEAD_SIZE)
     	{
     		if(HeadPrt==0)
     		{
     			if(temp[prt]!=DATA_START_SIGN)
     			{
     				prt++;         //Data frame lose its start mark!
					DrawTime(RED_SIGN);
     				continue;
     			}     			
     			else
     			{
					DrawTime(GREEN_SIGN);
     			    dataHead[HeadPrt]=temp[prt];
     			    HeadPrt++;
     				prt++;
     			}	
     		}
     		if(prt>=len)
     		{                      //Data frame just include its start mark
     			DrawTime(YELLOW_SIGN);
     			return 0;
     		}	
     		if(DATA_HEAD_SIZE - HeadPrt	>len-prt)
     		{                      //data frame not total head info
     			memcpy((char*)&dataHead[HeadPrt],(char*)&temp[prt],len-prt);
     			HeadPrt+=len-prt;
				DrawTime(YELLOW_SIGN);
		   		return 0;
     		}
     		else
     		{
     			memcpy((char*)&dataHead[HeadPrt],(char*)&temp[prt],DATA_HEAD_SIZE - HeadPrt);
     			prt+=DATA_HEAD_SIZE - HeadPrt;
     			HeadPrt=DATA_HEAD_SIZE;
     		}     			
     	}
     	
     	if(prt>=len)
     	{                          //Just head info
			DrawTime(YELLOW_SIGN);
     		return 0;
     	}	
     	dataNum=*(int *)&dataHead[1];
     	if(dataNum<=0)
     	{                          //Data Error,we must lose this bad data frame!
			DrawTime(RED_SIGN);
     		return -1;
     	}
     	if(dataNum-dataPrt  > len - prt)
     	{                          //Not total data frame
     		memcpy((char FAR *)&ReadBuf[dataPrt],(char*)&temp[prt],len-prt);
     		dataPrt+=len-prt;
			DrawTime(YELLOW_SIGN);
     		return 0;
     	}
     	else
     	{
     		memcpy((char FAR *)&ReadBuf[dataPrt],(char*)&temp[prt],dataNum-dataPrt);
     		prt+=dataNum-dataPrt;
     		dataPrt=dataNum;

     		UDP_Client_ReadHq();
     		dataPrt=0; 
     		HeadPrt=0;
     		dataNum=0;
     	}
     	
     	if(prt>=len)
     	{
     		dataPrt=0; 
     		HeadPrt=0;
     		dataNum=0;
			DrawTime(BLACK_SIGN);
     		return 0;     		
     	}	
    }
    DrawTime(BLACK_SIGN);
    return 0;    
    
}

int curPos =0, curLen =0;;
int UDP_Client_ReadHq(void)
{
	LPSTR lpTmp;
	int len;        
    
    len=dataPrt;
    
	lpTmp =&ReadBuf[0];
	
	if(!strnicmp(HQ00_HEAD, lpTmp, strlen(HQ00_HEAD)))
		UDP_Read_Hq00(lpTmp+strlen(HQ00_HEAD)+sizeof(short), len -strlen(HQ00_HEAD)-sizeof(short));
	else if(!strnicmp(HQ01_HEAD, lpTmp, strlen(HQ01_HEAD)))
		UDP_Read_Hq01(lpTmp+strlen(HQ01_HEAD)+sizeof(short), len -strlen(HQ01_HEAD)-sizeof(short));
	else if(!strnicmp(HQ10_HEAD, lpTmp, strlen(HQ10_HEAD)))
		UDP_Read_Hq10(lpTmp+strlen(HQ10_HEAD)+sizeof(short), len -strlen(HQ10_HEAD)-sizeof(short));
	else if(!strnicmp(GRA00_HEAD, lpTmp, strlen(GRA00_HEAD)))
		UDP_Read_Gra00(lpTmp+strlen(GRA00_HEAD)+sizeof(short), len -strlen(GRA00_HEAD)-sizeof(short));
	else if(!strnicmp(GRA01_HEAD, lpTmp, strlen(GRA01_HEAD)))
		UDP_Read_Gra01(lpTmp+strlen(GRA01_HEAD)+sizeof(short), len -strlen(GRA01_HEAD)-sizeof(short));
	else if(!strnicmp(GRA10_HEAD, lpTmp, strlen(GRA10_HEAD)))
		UDP_Read_Gra10(lpTmp+strlen(GRA10_HEAD)+sizeof(short), len -strlen(GRA10_HEAD)-sizeof(short));
	else if(!strnicmp(MMP_HEAD, lpTmp, strlen(MMP_HEAD)))
		UDP_Read_Mmp(lpTmp+strlen(MMP_HEAD)+sizeof(short), len -strlen(MMP_HEAD)-sizeof(short));
	else if(!strnicmp(MAXMIN10_HEAD, lpTmp, strlen(MAXMIN10_HEAD)))
		UDP_Read_MaxMin10(lpTmp+strlen(MAXMIN10_HEAD)+sizeof(short), len -strlen(MAXMIN10_HEAD)-sizeof(short));
	else if(!strnicmp(DP_HEAD, lpTmp, strlen(DP_HEAD)))
		UDP_Read_Dp(lpTmp+strlen(DP_HEAD)+sizeof(short), len -strlen(DP_HEAD)-sizeof(short));
	else if(!strnicmp(ZX_HEAD, lpTmp, strlen(ZX_HEAD)))
		UDP_Read_Zx(lpTmp+strlen(ZX_HEAD)+sizeof(short), len -strlen(ZX_HEAD)-sizeof(short));
	else if(!strnicmp(MSG_HEAD, lpTmp, strlen(MSG_HEAD)))
		MessageBox(NULL, lpTmp+strlen(MSG_HEAD)+sizeof(short),"������Ϣ", MB_OK);
	else if(!strnicmp(GETZQMC_HEAD, lpTmp, strlen(GETZQMC_HEAD)))
		UDP_Read_GetZqmc(lpTmp+strlen(GETZQMC_HEAD)+sizeof(short), len -strlen(GETZQMC_HEAD)-sizeof(short));
	else if(!strnicmp(DATA_DAY_HEAD,lpTmp,strlen(DATA_DAY_HEAD)))
		UDP_Read_DataDay(lpTmp+strlen(DATA_DAY_HEAD)+sizeof(short),len -strlen(DATA_DAY_HEAD)-sizeof(short));
	else if(!strnicmp(HQ_CHKUSR_HEAD, lpTmp, strlen(HQ_CHKUSR_HEAD)))
		UDP_Read_ChkUsr(lpTmp+strlen(HQ_CHKUSR_HEAD)+sizeof(short),len -strlen(HQ_CHKUSR_HEAD)-sizeof(short));
	else if(!strnicmp(RECV_FILE_HEAD, lpTmp, strlen(RECV_FILE_HEAD)))
		UDP_Recv_File(lpTmp+strlen(RECV_FILE_HEAD),len-strlen(RECV_FILE_HEAD));	
	else if(!strnicmp(ERROR_HEAD, lpTmp, strlen(ERROR_HEAD)))
		MessageBeep(0);
	else
	{
		DrawTime(3);
		MessageBeep(0);
	}       
	curPos =len-curLen;
	
	return 0;
}

int UDP_Read_NotRun(LPSTR lpTmp, int len)
{
	HqTime[HqPaintData.jys].fRunning =FALSE;
	
	return 0;
}

extern int CheckTime(BOOL);
int hq_state =-1, hq_jys =0, hq_rec_first =0, hq_rec_count =0;
int UDP_Read_Hq00(LPSTR lpTmp, int len)
{
	int i, j, jys;
	static int fFirst[2];
	time_t ltime;
	//struct tm *ptm;
	//struct _dostime_t dtime;
	
	jys =*lpTmp;

	lpTmp +=1;          
	len -=1;
	if(len <=0) goto readhq00Err;
	
	HqData[jys].recCount =*(short *)lpTmp;
	if(jys ==HqPaintData.jys)
		HqPaintData.recCount =HqData[jys].recCount;
	
	if(HqData[jys].recCount >MAX_HQ_REC_COUNT) goto readhq00Err;
	lpTmp +=sizeof(short);
	len -=sizeof(short);
		
	if(len <sizeof(short)*4) goto readhq00Err;
		
	memcpy(&HqTime[jys], lpTmp, sizeof(HqTime[jys])-sizeof(BOOL));
		
	len -=sizeof(HqTime[jys])-sizeof(BOOL);
	lpTmp +=sizeof(HqTime[jys])-sizeof(BOOL);
	
	if(jys ==0 && len >0)
	{
		memcpy(&ltime, lpTmp, sizeof(time_t));
		len -=sizeof(time_t);
		lpTmp +=sizeof(time_t);
		//ptm =gmtime(&ltime);
		//dtime.hour =ptm->tm_hour;
		//dtime.minute =ptm->tm_min;
		//dtime.second =ptm->tm_sec;
		//_dos_settime(&dtime);
		date_num =*lpTmp;
		lpTmp ++;
		len --;
	}
	
	HqTime[jys].am_min_count -=HqTime[jys].am_min_start;
	HqTime[jys].pm_min_count -=HqTime[jys].pm_min_start;
		
	i =HqTime[0].am_min_count+HqTime[0].pm_min_count+2;
	j =HqTime[1].am_min_count+HqTime[1].pm_min_count+2;
	if(j>i) i =j;

	if(GraphData.lpMinPos ==NULL)
		GraphData.lpMinPos =(short *)GlobalAllocPtr(GHND, i*sizeof(short));
	else
		GraphData.lpMinPos =(short *)GlobalReAllocPtr(GraphData.lpMinPos,
					i*sizeof(short), GMEM_MOVEABLE);

	if(GraphData.lpMinPos ==NULL)
	{
		GraphData.minEnd =0;
		ErrMsg(NULL,"alloc record data memory failed!");
		return FALSE;
	}
		
	if(GraphData.lpMinLc ==NULL)
		GraphData.lpMinLc =(long *)GlobalAllocPtr(GHND, i*sizeof(long));
	else
		GraphData.lpMinLc =(long *)GlobalReAllocPtr(GraphData.lpMinLc,
					i*sizeof(long), GHND);

	if(GraphData.lpMinLc ==NULL)
	{
		GraphData.minEnd =0;
		ErrMsg(NULL,"alloc record data memory failed!");
		return FALSE;
	}
		
	if(!HqAllocMem(jys))
		goto readhq00Err;
		
	if(HqPaintData.fldCount <=0)
	{
		HqPaintData.fldCount =HQ_FLDS_COUNT;
		for(i =0; i<HqPaintData.fldCount; i++)
			HqPaintData.fldNum[i] =i;
	}
	for(i =0; i<HqData[jys].recCount; i++)
		HqPaintData.sortData.key[i] =i;
		
	fFirst[jys] =0;
	CheckTime(FALSE);
	hq_state =1;
	return 0;
readhq00Err:
	DrawTime(3);
	MessageBeep(0);
	return -1;
}

int UDP_Read_Hq01(LPSTR lpTmp, int len)
{
	int i, jys;
	int recCount, recNum;
	BOOL isRefresh =FALSE, isSel =FALSE;
	
	jys =(BOOL)*lpTmp;
	lpTmp +=1; len -=1;
	if(len <=0)
	{
		KillTimer(ghWndHq, 5);	
		ErrMsg(ghWndMain, "��HQ01�������ݰ����Ȳ���!");	
	 	goto readhq01Err;		 	
	}
	if(HqData[jys].recCount <=0)
	{ 
		KillTimer(ghWndHq, 5);	
		ErrMsg(ghWndMain, "��HQ01�������ݰ���¼������");
		goto readhq01Err;
	}
	isRefresh =(BOOL)*lpTmp;
	lpTmp++; len --;
	isSel =(BOOL)*lpTmp;
	lpTmp++; len --;
	recCount =*(short *)lpTmp; 
	if(recCount <=0)
	{
		KillTimer(ghWndHq, 5);
		ErrMsg(ghWndMain, "��HQ01��������¼��Ϊ��!");
		goto readhq01Err;
	}
	lpTmp +=sizeof(short);
	len -=sizeof(short);
	if(len <=0) goto readhq01Err;   
	
	for(i =0; i<recCount; i++)
	{
		if(len <0) break;
		recNum =*(short *)lpTmp;
		len-=2; lpTmp +=2;
		if(recNum >=HqData[jys].recCount)
		{
			ErrMsg(ghWndMain, "��HQ01��������¼��Ŵ��ڼ�¼��!");
			goto readhq01Err;
		}   	
		if(!isRefresh)
		{
			memcpy(&HqData[jys].lpPreData[recNum],
				lpTmp, sizeof(HQ_PRE_DATA));
			len -=sizeof(HQ_PRE_DATA);
			lpTmp +=sizeof(HQ_PRE_DATA);
		}
		memcpy(&HqData[jys].lpRefData[recNum],
			lpTmp, sizeof(HQ_REF_DATA));
		len -=sizeof(HQ_REF_DATA);
		lpTmp +=sizeof(HQ_REF_DATA);
		HqData[jys].isReadOK[recNum] =TRUE;
	}
	if(IsWindowVisible(ghWndHq))
		SendMessage(ghWndHq, WM_HQ_REFRESH, jys, 0L);
	return 0;
readhq01Err:
	DrawTime(3);
	MessageBeep(0);
	return -1;
}

int UDP_Read_Hq10(LPSTR lpTmp, int len)
{
	int i, jys;
	int rec_count, rec_num;
	float oldjg;
	//long lc;
	
	jys =*lpTmp++;
	len --;
	if(jys >1) goto readhq10Err;
	
	rec_count =*(short *)lpTmp; 
	lpTmp+=2; len -=2;
	if(rec_count >HqData[jys].recCount || rec_count <=0) goto readhq10Err;
	//if(rec_count >MAX_HQ_SENDCOUNT) goto readhq10Err;
	if(len <rec_count*(int)sizeof(HQ_REF_DATA))
		goto readhq10Err;
		
	//memcpy(&HqData[jys].lpRefData[rec_first], rec_count*sizeof(HQ_REF_DATA));
	
	for(i =0; i<rec_count; i++)
	{
		if(len <=0) break;
		rec_num =*(short *)lpTmp;
		if(rec_num >HqData[jys].recCount) break;
		lpTmp+=sizeof(short);
		len -=sizeof(short);
		oldjg =HqData[jys].lpRefData[rec_num].zjjg;
		memcpy(&HqData[jys].lpRefData[rec_num], lpTmp, sizeof(HQ_REF_DATA));
		HqData[jys].isJgChanged[rec_num] =(BOOL)((HqData[jys].lpRefData[rec_num].zjjg-oldjg)*100);
		if(HqData[jys].isJgChanged[rec_num])    MessageBeep(0);
		len -=sizeof(HQ_REF_DATA);
		lpTmp +=sizeof(HQ_REF_DATA);

		HqData[jys].isLcChanged[rec_num] =TRUE;
	}
	
	if(IsWindowVisible(ghWndHq))
		SendMessage(ghWndHq, WM_HQ_REFRESH, jys, 0L);
	else if(IsWindowVisible(ghWndLitHq))
	{
		SendMessage(ghWndLitHq, WM_READ_OK, jys, 0L);
	}
	
	return 0;

readhq10Err:
	DrawTime(3);
	return -1;
}
////////////////////////////////////////////////////////////////////////////
//Function:This func receive deatial pricr voulmn file head information data
//         from server,then get memory according to minTotal data.
//
int UDP_Read_Gra00(LPSTR lpTmp, int len)
{
	int jys;
	
	jys =*lpTmp;
	if(GraphData.jys !=jys) return 0;

	lpTmp +=1; len -=1;
	if(len <=0) return -1;

	memcpy(&GraphData.GraHead, lpTmp, sizeof(GRA_HEAD));
	//GraphData.GraHead.zrsp =HqData[jys].lpPreData[GraphData.recNum].zrsp;

	if(GraphData.lpGraData ==NULL)
		GraphData.lpGraData =(GRA_DATA huge *)GlobalAllocPtr(GHND,
				(long)GraphData.GraHead.minTotal*sizeof(GRA_DATA));
	else
		GraphData.lpGraData =(GRA_DATA huge *)GlobalReAllocPtr(
			GraphData.lpGraData,(long)GraphData.GraHead.minTotal*sizeof(GRA_DATA),
			GMEM_MOVEABLE);
			
	if(GraphData.lpGraData ==NULL)
	{
		ErrMsg(NULL, "���ܷ���ɽ���ϸ�����ڴ�!");
		return -1;
	}
	
	GraRecalcJgMax();
	GraRecalcLcMax();
	return 0;
}

////////////////////////////////////////////////////////////////////////
//This func to get data info from server,then compute it
//
int UDP_Read_Gra01(LPSTR lpTmp, int len)
{
	int min_num, min_count;
	char temp[128];
	HFILE hf;
	OFSTRUCT os;
		
	if(GraphData.lpGraData ==NULL)
		return 0;
	if(*lpTmp++ !=GraphData.jys)
		return -1;	
	len -=1;
	if(len <=0) return -1;

	if(*(int *)lpTmp !=GraphData.recNum)
		return -1;
	lpTmp +=sizeof(int);
	len -=sizeof(int);
	if(len <=0) return -1;
		
	min_count =*(int *)lpTmp; //data num this times
	lpTmp +=sizeof(int);
	len -=sizeof(int);
	if(len <=0) return -1;
		
	min_num =*(int *)lpTmp;	  //Last data tail
	lpTmp +=sizeof(int);
	len -=sizeof(int);
	if(len <=0) return -1;
	if(min_num +min_count >GraphData.GraHead.minTotal) return -1;
		
	min_count =len/sizeof(GRA_DATA);
	memcpy(&GraphData.lpGraData[min_num], lpTmp, min_count*sizeof(GRA_DATA));
	//GraphData.GraHead.zrsp =HqData[GraphData.jys].lpPreData[GraphData.recNum].zrsp;

	GraphData.minEndPrev =min_num;
	GraphData.minEnd =min_num+min_count;
	GraphData.fRefreshDraw =TRUE;

	GraGetMinPos();	
	wsprintf(temp, "%s\\%s.dat", szDataPath, HqData[GraphData.jys].lpPreData[GraphData.recNum].zqdm);
	hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);
	if(hf ==HFILE_ERROR)
		hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_WRITE);
	if(hf !=HFILE_ERROR)
	{
		if(_lwrite(hf, &GraphData.GraHead, sizeof(GraphData.GraHead))
				==sizeof(GraphData.GraHead))
		{
			if(_llseek(hf, (long)sizeof(GRA_HEAD)
					+(long)sizeof(GRA_DATA)*min_num, SEEK_SET)
					==HFILE_ERROR)
			{
				_llseek(hf, sizeof(GRA_HEAD), SEEK_SET);
				_hwrite(hf, &GraphData.lpGraData[0],
						(long)sizeof(GRA_DATA)*min_num);
			}
			_hwrite(hf, &GraphData.lpGraData[min_num],
					(long)sizeof(GRA_DATA)*min_count);
		}
		_lclose(hf);
	}

	GraphData.fRefreshDraw =FALSE;
	if(IsWindowVisible(ghWndXlt))
	{
		if(GraRecalcJgMax() ==0)
			SendMessage(ghWndXlt, WM_READ_OK, 1, 0L);
		else SendMessage(ghWndXlt, WM_READ_OK, 0, 0L);
		
		if(GraRecalcLcMax() ==0)
			InvalidateRect(ghWndJlt, NULL, TRUE);
		else
			InvalidateRect(ghWndJlt, NULL, FALSE);
		SendMessage(ghWndCj, WM_READ_OK, 0, 0L);
	}
	return 0;
}

int UDP_Read_Gra10(LPSTR lpTmp, int len)
{
	int min_num, min_count;
	char temp[128];
	HFILE hf;
	OFSTRUCT os;
	GRA_HEAD GraHead;
		
	if(GraphData.lpGraData ==NULL) return 0;
	if(*lpTmp++ !=GraphData.jys !=0) goto readgra10Err;
    
	len -=1;
	if(len <=0) goto readgra10Err;
		
	if(*(int *)lpTmp !=GraphData.recNum) goto readgra10Err;
	lpTmp+=sizeof(int);
	len-=sizeof(int);
		
	min_count =*(int *)lpTmp;
	lpTmp +=sizeof(int);
	len -=sizeof(int);
	if(len <=0) goto readgra10Err;
	
	min_num =*(int *)lpTmp;
	if(min_num !=GraphData.minEnd)
	{
		MessageBeep(0);
		//goto readgra10Err;
	}
	lpTmp +=sizeof(int);
	len -=sizeof(int);
	if(len <=0) goto readgra10Err;
		
	//memcpy(&GraHead, lpTmp, sizeof(GRA_HEAD));
	//lpTmp +=sizeof(GRA_HEAD);
	//len -=sizeof(GRA_HEAD);
		
	min_count =len/sizeof(GRA_DATA);
	GraphData.lpGraData =(GRA_DATA huge *)GlobalReAllocPtr(
				GraphData.lpGraData,
				(long)(min_num+min_count)*sizeof(GRA_DATA),
				GMEM_MOVEABLE);
	if(GraphData.lpGraData ==NULL)
	{
		ErrMsg(NULL, "Gra10: alloc mem failed");
		return -1;
	}
	memcpy(&GraphData.lpGraData[min_num], lpTmp, min_count*sizeof(GRA_DATA));
		
	GraphData.minEndPrev =min_num;
	GraphData.GraHead.minTotal =GraphData.minEnd =min_num+min_count;
	
	GraphData.fRefreshDraw =TRUE;
	
	GraGetMinPos();
	
	if(IsWindowVisible(ghWndXlt))
	{
		if(GraRecalcJgMax() ==0)
			SendMessage(ghWndXlt, WM_READ_OK, 1, 0L);
		else SendMessage(ghWndXlt, WM_READ_OK, 0, 0L);
		
		if(GraRecalcLcMax() ==0)
			InvalidateRect(ghWndJlt, NULL, TRUE);
		else
			InvalidateRect(ghWndJlt, NULL, FALSE);
		InvalidateRect(ghWndCj, NULL, TRUE);
	}
	
	wsprintf(temp, "%s\\%s.dat", szDataPath, HqData[GraphData.jys].lpPreData[GraphData.recNum].zqdm);
	hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hf !=HFILE_ERROR)
	{
		memcpy(&GraHead, &GraphData.GraHead, sizeof(GraHead));
		GraHead.minTotal =GraphData.minEnd;
		if(_lwrite(hf, &GraHead, sizeof(GraHead)) ==sizeof(GraHead))
		{
			if(_llseek(hf, (long)sizeof(GRA_HEAD)
					+(long)sizeof(GRA_DATA)*min_num, SEEK_SET)
					==HFILE_ERROR)
			{
				_llseek(hf, sizeof(GRA_HEAD), SEEK_SET);
				_hwrite(hf, &GraphData.lpGraData[0],
						(long)sizeof(GRA_DATA)*min_num);
			}
			_hwrite(hf, &GraphData.lpGraData[min_num],
					(long)sizeof(GRA_DATA)*min_count);
		}
		_lclose(hf);
	}
	GraphData.fRefreshDraw =FALSE;
	
	if(IsWindowVisible(ghWndXlt))
	{
		if(GraRecalcJgMax() ==0)
			SendMessage(ghWndXlt, WM_READ_OK, 1, 0L);
		else SendMessage(ghWndXlt, WM_READ_OK, 0, 0L);
		
		if(GraRecalcLcMax() ==0)
			InvalidateRect(ghWndJlt, NULL, TRUE);
		else
			InvalidateRect(ghWndJlt, NULL, FALSE);
		InvalidateRect(ghWndCj, NULL, TRUE);
	}

	return 0;

readgra10Err:
	DrawTime(3);
	return -1;      
}

int UDP_Read_Mmp(LPSTR lpTmp, int len)
{
	int jys;
	
	jys =*lpTmp;
	
	lpTmp ++;          
	len --;
	if(len <=0) goto readmmpErr;
		
	//if(*(int *)lpTmp !=rec_num) goto sendmmp;
	len -=sizeof(int);
	lpTmp +=sizeof(int);
	    
	if(len !=sizeof(MMP_DATA)-2*sizeof(int)) goto readmmpErr;
	memcpy(&MmpData.jwBuy[0], lpTmp, sizeof(MMP_DATA)-2*sizeof(int));
	
	InvalidateRect(ghWndMmp, NULL, TRUE);
	return 0;

readmmpErr:
	DrawTime(3);
	return -1;
}

int UDP_Read_MaxMin10(LPSTR lpTmp, int len)
{
	int jys, i, j, recCount;
	int maxmin;
	char  WriteBuf[MAX_WRITE_BUF_SIZE+1];
		   
	jys =*lpTmp;
	if(jys !=GraphData.jys) return 0;
	lpTmp +=1;          
	len -=1;

	maxmin =*lpTmp;
	if(maxmin >1)
	{
		MessageBeep(0);
		return -1;
	}

	lpTmp++;
	len --;
	if(len <sizeof(MAXMIN_DATA)) goto readmaxmin10Err;

	memcpy(&MaxMinData[jys][maxmin], lpTmp, sizeof(MAXMIN_DATA));
	MaxMinChangeHqData(jys, maxmin);
	strcpy(WriteBuf, GETZQMC_HEAD);
	len =strlen(WriteBuf);
	WriteBuf[len++] =jys;
	*(short *)&WriteBuf[len] =0;
	len +=sizeof(short);
	
	recCount =0;
	for(i =0; i<4; i++)
	{
		for(j =0; j<10; j++)
		{
			if(HqData[jys].lpPreData[MaxMinData[jys][maxmin].recNum[i][j]].zqmc[0] ==0)
			{
				*(short *)&WriteBuf[len] =MaxMinData[jys][maxmin].recNum[i][j];
				len +=sizeof(short);
				recCount ++;
			}
		}
	}
	if(recCount)
	{
		*(short *)&WriteBuf[strlen(GETZQMC_HEAD)+1] =recCount;
		UDP_Send_Hq(WriteBuf, GETZQMC_HEAD, len);
	}       
	InvalidateRect(ghWndMaxMin, NULL, TRUE);
	
	return 0;

readmaxmin10Err:
	DrawTime(3);
	return -1;
}

int UDP_Read_GetZqmc(LPSTR lpTmp, int len)
{
	int jys, i, recCount, recNum;
	
	jys =*lpTmp++;
	recCount =*(short *)lpTmp;
	lpTmp +=sizeof(short);
	for(i =0; i<recCount; i++)
	{
		recNum =*(short *)lpTmp;
		lpTmp+=sizeof(short);
		if(recNum >HqData[jys].recCount) return -1;
		strncpy(HqData[jys].lpPreData[recNum].zqmc, lpTmp, MAX_ZQMC_SIZE);
		lpTmp +=MAX_ZQMC_SIZE;
	}
	if(IsWindowVisible(ghWndMaxMin))
		InvalidateRect(ghWndMaxMin, NULL, FALSE);
		
	return 0;
}

int UDP_Read_Dp(LPSTR lpTmp, int len)
{
	int jys;
	
	if(len <sizeof(DpData)) goto readdpErr;
	memcpy(&DpData, lpTmp, sizeof(DpData));
	for(jys =0; jys<2; jys ++)
		if(DpData[jys].npbl >(float)1 || DpData[jys].npbl <(float)0)
			DpData[jys].npbl =(float)0.5;
	if(ghWndStatus) InvalidateRect(ghWndStatus, NULL, FALSE);
	return 0;
	
readdpErr:
	DrawTime(3);
	return -1;
}

int UDP_Send_Zx(void)
{
	int len;
	char  WriteBuf[MAX_WRITE_BUF_SIZE+1];
	
	strcpy(WriteBuf, ZX_HEAD);
	len =strlen(WriteBuf);
	*(long *)&WriteBuf[len] =ZxData.len;
	len +=sizeof(long);
	return UDP_Send_Hq(WriteBuf, ZX_HEAD, len);
}

int UDP_Send_Stock_Info(STOCK_INFO_FRAME *StockInfoFrame)
{
   int len;
   char  WriteBuf[MAX_WRITE_BUF_SIZE+1];
   
   strcpy(WriteBuf,STOCK_INFO_HEAD);
   len=strlen(STOCK_INFO_HEAD);
   memcpy(&WriteBuf[len],StockInfoFrame,sizeof(STOCK_INFO_FRAME));
   len+=sizeof(STOCK_INFO_FRAME);
   return UDP_Send_Hq(WriteBuf,STOCK_INFO_HEAD,len);
}

int UDP_Read_Zx(LPSTR lpTmp, int len)
{
    char temp[80];
    OFSTRUCT os;
    
	strcpy(temp, szDataPath);
	strcat(temp, "\\zx.txt");
	hfZx =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);
	if(hfZx ==HFILE_ERROR) return(-1);
	if(len <=0)
	{
		_lclose(hfZx);
		return(-1);
	}	
	_llseek(hfZx, 0, SEEK_END);
	ZxData.len +=len;
	_lwrite(hfZx, lpTmp, len);
	_lclose(hfZx);
	SendMessage(ghWndCaption, WM_USER+1, 0, (LPARAM)(ZxData.len-len));
	return 0;
}

int UDP_Send_Hq00(int jys, BOOL fFirst, int fRefresh, int fSel, int recCount, short *recList)
{
	int i, len, rec_num, list_count;
	char WriteBuf[MAX_WRITE_BUF_SIZE+1];
	
	//hq_state =0;
	//hq_jys =jys;
	KillTimer(ghWndHq, 5);
	SetTimer(ghWndHq, 5, 5000, NULL);
	
	strcpy(WriteBuf, HQ00_HEAD);
	len =strlen(HQ00_HEAD);
	WriteBuf[len++] =CLIENT_VERSION;
	WriteBuf[len++] =(BYTE)jys;
	if(HqData[jys].isReadOK ==NULL || HqData[jys].isReadOK[0] ==FALSE)
		fFirst =TRUE;
	WriteBuf[len++] =(BYTE)fFirst;
	WriteBuf[len++] =(BYTE)fRefresh;
	WriteBuf[len++] =(BYTE)fSel;
	*(short *)&WriteBuf[len] =recCount;
	len +=sizeof(short);
	
	if(!fSel) list_count =1;
	else list_count =recCount;
	
	memcpy(&WriteBuf[len], recList, sizeof(short)*list_count);
	len +=sizeof(short)*list_count;
	if(fRefresh)
	{
		for(i =0; i<recCount; i++)
		{
			if(fSel) rec_num =recList[i];
			else rec_num =recList[0]+i;
			*(long *)&WriteBuf[len] =HqData[jys].lpRefData[rec_num].cjss;
			len +=sizeof(long);
		}
	}
	return UDP_Send_Hq(&WriteBuf[0], HQ00_HEAD, len);
}

////////////////////////////////////////////////////////////////////////
//Function	:to draw price-volumn diagram per min,This func open deatail 
//           data file according to stock code,compute it,biuld integer
//			 set diagram data.then send a requst to server to get other 
//           deatail voulmn file on server
//
//

int UDP_Send_Gra00(int jys, int rec_num)
{
	HFILE hf;
	OFSTRUCT os;
	char temp[100];
	int len = 0;   
	char  WriteBuf[MAX_WRITE_BUF_SIZE+1];
                
	KillTimer(ghWndHq, 5);
	
	GraphData.jys =jys;
	GraphData.recNum =rec_num;

	GraphData.minEndPrev =0;
	GraphData.minEnd =0;
	GraphData.GraHead.dateNum =date_num;
	    
	wsprintf(temp, "%s\\%s.dat", szDataPath, HqData[jys].lpPreData[rec_num].zqdm);
	hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hf !=HFILE_ERROR)
	{
		if(_lread(hf, &GraphData.GraHead, sizeof(GraphData.GraHead))
				==sizeof(GraphData.GraHead))
		{
			if(gfOnLine && GraphData.GraHead.dateNum !=date_num)
			{
				GraphData.GraHead.dateNum =date_num;
				GraphData.minEnd =GraphData.minEndPrev =GraphData.GraHead.minTotal =0;
				goto read_ok;
			}
			if(GraphData.GraHead.minTotal)
			{
				if(GraphData.lpGraData ==NULL)
					GraphData.lpGraData =(GRA_DATA huge *)GlobalAllocPtr(GHND,
							(long)GraphData.GraHead.minTotal*sizeof(GRA_DATA));
				else
					GraphData.lpGraData =(GRA_DATA huge *)GlobalReAllocPtr(
							GraphData.lpGraData,
							(long)GraphData.GraHead.minTotal*sizeof(GRA_DATA),
							GHND);
			
				if(GraphData.lpGraData !=NULL)
				{
					if(_hread(hf, &GraphData.lpGraData[0],
							(long)GraphData.GraHead.minTotal*sizeof(GRA_DATA))
							!=(long)GraphData.GraHead.minTotal*sizeof(GRA_DATA))
					{
						GraphData.GraHead.dateNum =date_num;
						GraphData.minEndPrev =GraphData.minEnd =0;
					}
					else
					{
						GraphData.minEndPrev =0;
						GraphData.minEnd =GraphData.GraHead.minTotal;
						GraGetMinPos();
						GraRecalcJgMax();
						GraRecalcLcMax();

						if(IsWindowVisible(ghWndXlt))
						{
							SendMessage(ghWndJlt, WM_READ_OK, 0, 0L);
							if(!IsZsRec(GraphData.jys, GraphData.recNum))
								SendMessage(ghWndCj, WM_READ_OK, 0, 0L);
						}
					}
				}
				else
				{
					ErrMsg(NULL, "Alloc mem failed!");
					_lclose(hf);
					return -1;
				}
			}
		}
read_ok:
		_lclose(hf);
	}                       
	//GraphData.GraHead.zrsp =HqData[jys].lpPreData[rec_num].zrsp;

	strcpy(WriteBuf, GRA00_HEAD);
	len =strlen(WriteBuf);
	WriteBuf[len++] =jys;
	WriteBuf[len++] =(BYTE)GraphData.GraHead.dateNum;
	*((int *)&WriteBuf[len]) =rec_num;
	len +=sizeof(int);
	*(short *)&WriteBuf[len] =GraphData.minEnd;
	len +=sizeof(short);
	
	return UDP_Send_Hq(&WriteBuf[0], GRA00_HEAD, len);
}

int UDP_Send_Gra01(void)//int min_first, int min_count)
{
	int len= 0;   
	char  WriteBuf[MAX_WRITE_BUF_SIZE+1];

	strcpy(WriteBuf, GRA01_HEAD);
	len =strlen(WriteBuf);
	WriteBuf[len++] =(BYTE)GraphData.jys;
	*((int *)&WriteBuf[len]) =GraphData.recNum;
	len +=sizeof(int);
	*((int *)&WriteBuf[len]) =GraphData.minEnd;
	len +=sizeof(int);
		
	return UDP_Send_Hq(&WriteBuf[0], GRA00_HEAD, len);
}

/////////////////////////////////////////////////////////
int CompString(LPSTR lpstr1, LPSTR lpstr2)
{
	int len;
	
	if(*lpstr1 =='-' && *lpstr2 !='-') return -1;
	if(*lpstr1 !='-' && *lpstr2 =='-') return 1;
	
	len =strlen(lpstr1) -strlen(lpstr2);
	if(*lpstr1 =='-' && *lpstr2 =='-')
	{
		if(len) return 0-len;
		return (0-strcmp(lpstr1, lpstr2));
	}
	else
	{
	    if(len) return len;
		return strcmp(lpstr1, lpstr2);
	}
}

int StringSub(LPSTR lpstr1, LPSTR lpstr2, LPSTR lpres, int s_type)
{
	int n;
	double f;
	long l;
	
	switch(s_type)
	{
		case SSUB_FLOAT:
			f =atof(lpstr1)-atof(lpstr2);
			wsprintf(lpres, "%f", (float)f);
		break;
		case SSUB_INT:
			n =atoi(lpstr1)-atoi(lpstr2);
			wsprintf(lpres, "%d", n);
		break;
		case SSUB_LONG:
			l =atol(lpstr1)-atol(lpstr2);
			wsprintf(lpres, "%ld", l);
		break;
		default:
		return -1;
	}
	
	return 0;
}

int GraGetMinPos(void)
{
	int i, j;
	int tim, tim1;
	long lc;
	
	if(GraphData.minEnd <=0)
	{
		GraphData.minCount =0;
		return 0;
	}
	
	tim =GraphData.lpGraData[0].tim;

	tim1 =tim;
	
	GraphData.minCount =0;
	GraphData.lpMinPos[0] =0;

	for(i =0; i<GraphData.minEnd;)
	{      
	    
		lc =0;
		while(i<GraphData.minEnd)
		{
			tim1 =GraphData.lpGraData[i].tim;
			if(tim1 >tim)
			{
				//i++;
				//tim=tim1;
				break;
			}
			lc +=GraphData.lpGraData[i].lc;
			i++;
		}
		if(i-1<GraphData.minEnd && tim >0)
		{
			j =i-1;
			GraphData.lpMinLc[GraphData.minCount] =lc;
			GraphData.lpMinPos[GraphData.minCount++] =j;
		}
		tim =tim1;
	}
	return 0;
}

int GraRecalcJgMax()
{
	int i;
	float min_val, max_val, f1;
	
	if(GraphData.minCount <=0) return 0;

	min_val =max_val =GraphData.lpGraData[0].zjjg;
	//max_val =GraphData.GraHead.zgjg;
	
	for(i =1; i<GraphData.minCount && i<GraphData.minEnd; i++)
	{
		if(min_val >GraphData.lpGraData[GraphData.lpMinPos[i]].zjjg)
			min_val =GraphData.lpGraData[GraphData.lpMinPos[i]].zjjg;
		if(max_val <GraphData.lpGraData[GraphData.lpMinPos[i]].zjjg)
			max_val =GraphData.lpGraData[GraphData.lpMinPos[i]].zjjg;
	}
	if(min_val ==0) min_val -=(float)0.001;
	if(max_val ==0) max_val +=(float)0.001;
	//min_val =(float)(min_val*(1-0.001)-0.01);
	//max_val =(float)(max_val*(1+0.001)+0.01);
	
	if(max_val <0) max_val *=-1;
	if(min_val <0) min_val *=-1;
	if(min_val >max_val) max_val =min_val;
	
	f1 =0;
	/*while(1)
	{
		if((f1+0.05)*5>max_val)
		{
			max_val =(float)((f1+0.05)*5);
			f1+=(float)0.05;
			break;
		}
		f1+=(float)0.05;
	}
	*/
	max_val =max_val+GraphData.GraHead.zrsp*(float)0.002;
	
	GraphData.GraHead.zgjg =max_val;
	GraphData.GraHead.zdjg =0-max_val;
	
	return 0;
}

int GraRecalcLcMax()
{
	int i;
	
	long max_val =GraphData.lpMinLc[0];
	
	if(GraphData.minCount <=0) return 0;
	
	for(i =1; i<GraphData.minCount && i<GraphData.minEnd; i++)
	{
		if(max_val <GraphData.lpMinLc[i])
			max_val =GraphData.lpMinLc[i];
	}
	max_val =(long)((double)max_val*(1+0.2)+5);
	
	GraphData.GraHead.zglc =max_val;
	
	return 0;
}

int MaxMinChangeHqData(int jys, int maxmin)
{
	int i, j;
	
	for(i =0; i<4; i++)
		for(j =0; j<10; j++)
		{
			/////////////
			if(MaxMinData[jys][maxmin].recNum[i][j] >=HqData[jys].recCount)
				return -1;
			HqData[jys].lpRefData[MaxMinData[jys][maxmin].recNum[i][j]].zjjg
					=MaxMinData[jys][maxmin].MaxMin[i][j].zjjg;
			HqData[jys].lpRefData[MaxMinData[jys][maxmin].recNum[i][j]].zdf
					=MaxMinData[jys][maxmin].MaxMin[i][j].zdf;
			HqData[jys].lpRefData[MaxMinData[jys][maxmin].recNum[i][j]].cjss
					=MaxMinData[jys][maxmin].MaxMin[i][j].cjss;
		}
	return 0;
}

void UDP_Send_Exit(void)
{
	int i, len,x,tlen;
	char temp[40];
	
	temp[0]=DATA_START_SIGN;
	*(int*)&temp[1]=strlen(CLNT_EXIT);
	memcpy(&temp[1+sizeof(int)],CLNT_EXIT,strlen(CLNT_EXIT));	
	tlen =1+sizeof(int)+strlen(CLNT_EXIT);
	for(i =0,x=0; i<10; i++)
	{
		len =send(sdHq, &temp[x],tlen -x, 0);
		if (len == SOCKET_ERROR)
		{
			if (h_errno == WSAEWOULDBLOCK)
				continue;
			else 
				return;
		}
		if(x+len!=tlen)
			x+=len;
		else
			break;
	}
}


int UDP_Read_DataDay(LPSTR lpTmp, int len)
{

	char temp[128];
	char jys;
	int gp_rec_num,sendCount,sendNum,i;
	HFILE hf;
	OFSTRUCT os;
	DAY_DATA DataDayBuff;

	jys=*lpTmp++;
	len -=1;
	if(len <=0) goto ReadDataDayErr;

	gp_rec_num=*(int *)lpTmp;
	lpTmp +=sizeof(int);
	len -=sizeof(int);
	if(len <=0) goto ReadDataDayErr;

	sendCount=*(int *)lpTmp;
	lpTmp +=sizeof(int);
	len -=sizeof(int);
	if(len <=0) goto ReadDataDayErr;

	sendNum=*(int *)lpTmp;
	lpTmp +=sizeof(int);
	len -=sizeof(int);
	if(len <=0) goto ReadDataDayErr;

	wsprintf(temp, "%s\\%s.day",szDataPath, HqData[GraphData.jys].lpPreData[GraphData.recNum].zqdm);
	hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);
	if(hf ==HFILE_ERROR)
		hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_WRITE);
	if(hf !=HFILE_ERROR)
	{
		for(i=0;i<sendCount;i++) 
		{
		       memset(&DataDayBuff,0,sizeof(DAY_DATA));
		       memcpy(&DataDayBuff,lpTmp,sizeof(DAY_DATA));
		       lpTmp+=sizeof(DAY_DATA);
		       len-=sizeof(DAY_DATA);
		       if(len<0)
		       {
			    goto  ReadDataDayErr;
		       }
		       _llseek(hf, 0l, SEEK_END);
		       _lwrite(hf, &DataDayBuff, sizeof(DAY_DATA));
		}
		_lclose(hf);
	}

	if(IsWindowVisible(ghWndFx))
	{   
	    Fx->IsDataOk=FALSE;
		InvalidateRect(ghWndFx, NULL, TRUE);

	}
	
	return TRUE;
	
	ReadDataDayErr:
	
	return FALSE;
}


int UDP_Send_DataDay(int jys, int rec_num)
{
	int len = 0,data_rec_end;   
    char temp[128];
	char  WriteBuf[MAX_WRITE_BUF_SIZE+1];
    
	HFILE hf;
	OFSTRUCT os;
	wsprintf(temp, "%s\\%s.day", szDataPath,HqData[GraphData.jys].lpPreData[GraphData.recNum].zqdm);
	hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);
	if(hf ==HFILE_ERROR)
	data_rec_end=0;
    else
    {
	data_rec_end=(int)_llseek(hf, 0l, SEEK_END)/sizeof(DAY_DATA);
    }           
    _lclose(hf);
	strcpy(WriteBuf, DATA_DAY_HEAD);
	len=strlen(DATA_DAY_HEAD);
	WriteBuf[len]=jys;
	len++;
	*((int *)&WriteBuf[len]) =rec_num;
	len +=sizeof(int);
	*((int *)&WriteBuf[len]) =data_rec_end;        
	len +=sizeof(int);

	return UDP_Send_Hq(&WriteBuf[0], DATA_DAY_HEAD, len);
}

int HqCheckUser(char *userID, char *userPwd)
{
	int len;
	char  WriteBuf[MAX_WRITE_BUF_SIZE+1];
	               
	               
	strcpy(WriteBuf, HQ_CHKUSR_HEAD);
	len=strlen(HQ_CHKUSR_HEAD);
	memcpy(&WriteBuf[len], userID, HQ_USERID_SIZE);
	len +=HQ_USERID_SIZE;
	memcpy(&WriteBuf[len], userPwd, HQ_USERPWD_SIZE);
	len +=HQ_USERPWD_SIZE;

	return UDP_Send_Hq(&WriteBuf[0], HQ_CHKUSR_HEAD, len);
}

extern HWND ghDlgChkUsr;
int UDP_Read_ChkUsr(LPSTR lpTmp, int len)
{
	SendMessage(ghDlgChkUsr, WM_COMMAND, 100, (LPARAM)(int)*lpTmp);	
	return 0;
}

BOOL HqAllocMem(int jys)
{
	if(HqData[jys].lpPreData ==NULL)
		HqData[jys].lpPreData =(LPHQ_PRE_DATA)GlobalAllocPtr(GHND,
			HqData[jys].recCount*sizeof(HQ_PRE_DATA));
	else
		HqData[jys].lpPreData =(LPHQ_PRE_DATA)GlobalReAllocPtr(HqData[jys].lpPreData,
			HqData[jys].recCount*sizeof(HQ_PRE_DATA), GMEM_MOVEABLE);
		
	if(HqData[jys].lpRefData ==NULL)
		HqData[jys].lpRefData =(LPHQ_REF_DATA)GlobalAllocPtr(GHND,
			HqData[jys].recCount*sizeof(HQ_REF_DATA));
	else
		HqData[jys].lpRefData =(LPHQ_REF_DATA)GlobalReAllocPtr(HqData[jys].lpRefData,
			HqData[jys].recCount*sizeof(HQ_REF_DATA), GMEM_MOVEABLE);

	if(HqData[jys].lpPreData ==NULL || HqData[jys].lpRefData ==NULL)
	{
		HqData[jys].recCount =0;
		ErrMsg(NULL,"alloc record data memory failed!");
		return FALSE;
	}
	if(HqData[jys].isLcChanged ==NULL)
		HqData[jys].isLcChanged =(BOOL *)GlobalAllocPtr(GHND,
			HqData[jys].recCount*sizeof(BOOL));
	else
		HqData[jys].isLcChanged =(BOOL *)GlobalReAllocPtr(HqData[jys].isLcChanged,
			HqData[jys].recCount*sizeof(BOOL), GHND);

	if(HqData[jys].isJgChanged ==NULL)
		HqData[jys].isJgChanged =(BOOL *)GlobalAllocPtr(GHND,
			HqData[jys].recCount*sizeof(BOOL));
	else
		HqData[jys].isJgChanged =(BOOL *)GlobalReAllocPtr(HqData[jys].isJgChanged,
			HqData[jys].recCount*sizeof(BOOL), GHND);

	if(HqData[jys].isJgChanged ==NULL || HqData[jys].isLcChanged ==NULL)
	{
		HqData[jys].recCount =0;
		ErrMsg(NULL,"alloc changed data memory failed!");
		return FALSE;
	}

	if(HqData[jys].isReadOK ==NULL)
		HqData[jys].isReadOK =(BOOL *)GlobalAllocPtr(GHND,
			HqData[jys].recCount*sizeof(BOOL));
	else
		HqData[jys].isReadOK =(BOOL *)GlobalReAllocPtr(HqData[jys].isReadOK,
			HqData[jys].recCount*sizeof(BOOL), GHND);

	if(HqData[jys].isReadOK ==NULL)
	{
		HqData[jys].recCount =0;
		ErrMsg(NULL,"alloc readok data memory failed!");
		return FALSE;
	}

	return TRUE;
}

/*
int UDP_Recv_File(LPSTR lpTmp,int len)
{
    RECV_FILE_FRAME RecvFileFrame;
    char temp[80],tmp[80],*ptr,file[14];
    HFILE hf;
    OFSTRUCT os;
    
    if(len<sizeof(RECV_FILE_FRAME))
    {
    	ErrMsg(NULL,"�����ļ�֡ͷ���Ȳ���"); 
    	return FALSE;
    }
    memcpy(&RecvFileFrame,lpTmp,sizeof(RECV_FILE_FRAME));
    lpTmp+=sizeof(RECV_FILE_FRAME);
    len-=sizeof(RECV_FILE_FRAME);
    if(len!=RecvFileFrame.filelen)
    {
    	ErrMsg(NULL,"�����ļ����������Ȳ���"); 
    	return FALSE;    
    }
    
    memset(file,0,14);
    strncpy(file,RecvFileFrame.filename,12);
    file[12] =0;

    strcpy(tmp,file);
    ptr=strchr(tmp,'.');
    if(ptr!=NULL)
    	*ptr=0;
	wsprintf(temp, "%s\\%s.tmp",szDataPath,tmp);
    if(RecvFileFrame.sign=='B'||RecvFileFrame.sign=='e'||
    		RecvFileFrame.sign=='f')
		unlink(temp);		
	if(access(temp,0)==0)
		hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_WRITE);
	else
		hf =OpenFile(temp, &os, OF_CREATE|OF_SHARE_DENY_NONE|OF_WRITE);
	if(hf==HFILE_ERROR)
	{
		sprintf(tmp,"���ܽ��������ļ�:%s",temp);
    	ErrMsg(NULL,tmp); 
    	return FALSE;	
	}
		
	if(_lseek(hf,0L,SEEK_END)==-1)
	{
    	ErrMsg(NULL,"�����ļ����ܶ�λ��β��!");
    	return FALSE;	
	}
	if(_lwrite(hf,lpTmp,len)!=(UINT)len)
	{
    	ErrMsg(NULL,"�����ļ�������ȷд������!");	
    	return FALSE;		
	}	
	_lclose(hf);
	if(RecvFileFrame.sign=='E'||RecvFileFrame.sign=='e')
	{	
		sprintf(tmp,"%s\\%s",szDataPath,file);
		unlink(tmp);
		rename(temp,tmp);
		
		_strlwr(tmp);
		if(strstr(tmp,"szhq.dat")!=NULL)
			PostMessage(ghWndMain,WM_USER +5,0,0L);
		if(strstr(tmp,"shhq.dat")!=NULL)
			PostMessage(ghWndMain,WM_USER +6,0,0L);		
	}	

	if(RecvFileFrame.sign=='F'||RecvFileFrame.sign=='f')
	{	
		sprintf(tmp,"%s\\%s",szDataPath,file);
		unlink(tmp);
		ExpandFile(temp,tmp);
		unlink(temp);
		
		_strlwr(tmp);
		if(strstr(tmp,"szhq.dat")!=NULL)
			PostMessage(ghWndMain,WM_USER +5,0,0L);
		if(strstr(tmp,"shhq.dat")!=NULL)
			PostMessage(ghWndMain,WM_USER +6,0,0L);
			
	}	
	
	return TRUE;
}
*/

int UDP_Recv_File(LPSTR lpTmp,int len)
{
    RECV_FILE_FRAME RecvFileFrame;
    char temp[80],tmp[80],*ptr,file[14];
    
    char buf[4096];
    int bytes;
    gzFile in;   
    
    HFILE hf;
    OFSTRUCT os;
    
    if(len<sizeof(RECV_FILE_FRAME))
    {
    	ErrMsg(NULL,"�����ļ�֡ͷ���Ȳ���"); 
    	return FALSE;
    }
    memcpy(&RecvFileFrame,lpTmp,sizeof(RECV_FILE_FRAME));
    lpTmp+=sizeof(RECV_FILE_FRAME);
    len-=sizeof(RECV_FILE_FRAME);
    if(len!=RecvFileFrame.filelen)
    {
    	ErrMsg(NULL,"�����ļ����������Ȳ���"); 
    	return FALSE;    
    }
    
    memset(file,0,14);
    strncpy(file,RecvFileFrame.filename,12);
    file[12] =0;

    if(RecvFileFrame.sign<=GZ_OVER)
    {   
    	wsprintf(temp, "%s\\temp.tmp",szDataPath);    	
    	switch(RecvFileFrame.sign)
    	{
    		case GZ_STAR:
    			hf =OpenFile(temp, &os, OF_CREATE|OF_SHARE_DENY_NONE|OF_WRITE);
    		break;
    		case GZ_SING:
    		    hf =OpenFile(temp, &os, OF_CREATE|OF_SHARE_DENY_NONE|OF_WRITE);
    		break; 
    		case GZ_CONT:
    			hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_WRITE);    		
    		break;
    		case GZ_OVER:
    			hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_WRITE);    		
    		break;
    	}
		if(hf==HFILE_ERROR)
		{
			sprintf(tmp,"���ܽ��������ļ�:%s",temp);
    		ErrMsg(NULL,tmp); 
    		return FALSE;	
		}
    	_lseek(hf,0L,SEEK_END);
		if(_lwrite(hf,lpTmp,len)!=(UINT)len)
		{
    		ErrMsg(NULL,"�����ļ�������ȷд������!");	
    		return FALSE;		
		}	
    	_lclose(hf);
    	if(RecvFileFrame.sign ==GZ_SING ||RecvFileFrame.sign ==GZ_OVER)
    	{    		
    	     in = gzopen(temp, "rb");
    	     if(in ==NULL)
    	     {
    	        ErrMsg(NULL,"���ܴ�ѹ���ļ�!");	
    			return FALSE;
    	     }            
    	     
    	     _strlwr(file);
    	     if(strstr(file,"winpy.dat")!=NULL)
    	     	strcpy(tmp,file);
    	     else
    	     wsprintf(tmp, "%s\\%s",szDataPath,file);    	     
    	     
    	     hf =OpenFile(tmp, &os, OF_CREATE|OF_SHARE_DENY_NONE|OF_WRITE);


    		 for (;;) 
    		 {
        		bytes = gzread(in, buf, sizeof(buf));
        		if (bytes < 0)
        		{
    				ErrMsg(NULL,"���ܽ�ѹ�����ļ�!");	
    				break;
        		}
        		if (bytes == 0) break;
				if(_lwrite(hf,buf,bytes)!=(UINT)bytes)
				{
    				ErrMsg(NULL,"��ѹ���ݲ�����ȷд���ļ�!");	
    				break;
				}	

    		 }
    		 
    		 _lclose(hf);
    		 if (gzclose(in) != Z_OK)
    		 {
    			ErrMsg(NULL,"ѹ���ļ����������ر�!");	
    			return FALSE;    		 
    		 }    		 
			if(strstr(tmp,"szhq.dat")!=NULL)
				PostMessage(ghWndMain,WM_USER +5,0,0L);
			else if(strstr(tmp,"shhq.dat")!=NULL)
				PostMessage(ghWndMain,WM_USER +6,0,0L);
			else if(strstr(tmp,"winpy.dat")!=NULL)
				PostMessage(ghWndMain,WM_USER +7,0,0L);
			else
			{
				sprintf(tmp,"�����ļ�%s",file);
				Msg(tmp,MSG_VERT);	
			}	
    	}
    	return 0;
    }

    strcpy(tmp,file);
    ptr=strchr(tmp,'.');
    if(ptr!=NULL)
    	*ptr=0;
	wsprintf(temp, "%s\\%s.tmp",szDataPath,tmp);
    if(RecvFileFrame.sign=='B'||RecvFileFrame.sign=='e'||
    		RecvFileFrame.sign=='f')
		unlink(temp);		
	if(access(temp,0)==0)
		hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_WRITE);
	else
		hf =OpenFile(temp, &os, OF_CREATE|OF_SHARE_DENY_NONE|OF_WRITE);
	if(hf==HFILE_ERROR)
	{
		sprintf(tmp,"���ܽ��������ļ�:%s",temp);
    	ErrMsg(NULL,tmp); 
    	return FALSE;	
	}
		
	if(_lseek(hf,0L,SEEK_END)==-1)
	{
    	ErrMsg(NULL,"�����ļ����ܶ�λ��β��!");
    	return FALSE;	
	}
	if(_lwrite(hf,lpTmp,len)!=(UINT)len)
	{
    	ErrMsg(NULL,"�����ļ�������ȷд������!");	
    	return FALSE;		
	}	
	_lclose(hf);
	if(RecvFileFrame.sign=='E'||RecvFileFrame.sign=='e')
	{	
		sprintf(tmp,"%s\\%s",szDataPath,file);
		unlink(tmp);
		rename(temp,tmp);
		
		_strlwr(tmp);		
		if(strstr(tmp,"szhq.dat")!=NULL)
			PostMessage(ghWndMain,WM_USER +5,0,0L);
		if(strstr(tmp,"shhq.dat")!=NULL)
			PostMessage(ghWndMain,WM_USER +6,0,0L);		
	}	

	if(RecvFileFrame.sign=='F'||RecvFileFrame.sign=='f')
	{	
		sprintf(tmp,"%s\\%s",szDataPath,file);
		unlink(tmp);
		ExpandFile(temp,tmp);
		unlink(temp);
		
		_strlwr(tmp);		
		if(strstr(tmp,"szhq.dat")!=NULL)
			PostMessage(ghWndMain,WM_USER +5,0,0L);
		if(strstr(tmp,"shhq.dat")!=NULL)
			PostMessage(ghWndMain,WM_USER +6,0,0L);		
	}	
	return TRUE;
}
