#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "hq.h"
#include "hq_cl.h"
#include "zs.h"
#include "toolbar.h"

#define ZS_CLASS	"CZS"

extern HINSTANCE ghInstance;
extern HWND ghWndMain, ghWndZs;
extern BOOL ErrMsg(HWND, LPSTR);
extern BOOL IsZsRec(int jys, int rec_num);

BOOL RegisterZs(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	
	wc.lpfnWndProc =ZsWndProc;
	wc.lpszClassName =ZS_CLASS;
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = ghInstance;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

BOOL CreateWndZs(HWND hWnd)
{                          
	int x ,x0,y0,x1,y1;
	HWND hwnd;
	HDC hDC;
	TEXTMETRIC tm;
	RECT rc;
		
	x =GetSystemMetrics(SM_CXSCREEN);
	
	hDC =GetDC(hWnd);
	GetTextMetrics(hDC, &tm);
	ReleaseDC(hWnd, hDC);
	GetWindowRect(ghWndXlt,&rc);
	
    x0 =rc.right;
    y0 =STATUS_HEIGHT +TOOLBAR_HEIGHT;
    x1 =x*1/3-30-1;
    y1 =tm.tmHeight*8; //+STATUS_HEIGHT;
    
    if(ghWndZs==NULL)
    {
		hwnd =CreateWindow(ZS_CLASS, NULL, WS_CHILD|WS_CLIPSIBLINGS,
					x0, y0, x1, y1,hWnd, NULL, ghInstance, NULL);
    
		if(hwnd ==NULL)
		{
			ErrMsg(hWnd, "Error create zs window");
			return FALSE;
		}
	
		ghWndZs =hwnd;	
	}
	else
	{
		SetWindowPos(ghWndZs, (HWND) NULL,x0, y0, x1, y1,NULL);
	}
	return TRUE;
}

LPSTR SzZsTitles[]=
{
	"�ɷ�", "��A", "��B", "��ҵ", "��ҵ", "����", "�ز�",
	"����", "����", "�ۺ�", "A��", "B��", "����", NULL	
};

LPSTR ShZsTitles[]=
{
	"��֤", "A��", "B��", "��ҵ", "��ҵ", "�ز�",
	"����", "�ۺ�", "��30", NULL	
};

//LPSTR ZsTitles[2] ={(LPSTR)&SzZsTitles[0], (LPSTR)&ShZsTitles[0]};

extern HFONT ghFontSmall;

LRESULT CALLBACK ZsWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	char tmp[256];
	PAINTSTRUCT ps;
	DWORD dw;
	int i, j, k, m, y, height;
	RECT rc;
	HPEN hPen;
	static int showSd =0;
	
	switch(message)
	{
		case WM_SETFOCUS:
			SetFocus(ghWndMain);
		break;
		case WM_KEYDOWN:
			switch(wParam)
			{
				case VK_UP:
				case VK_DOWN:
					showSd =(showSd+1)%2;
					InvalidateRect(hWnd, NULL, TRUE);
				break;
			}
		break;
		case WM_SIZE:
			if(IsWindowVisible)
             	InvalidateRect(hWnd, NULL, TRUE);
		break;
		case WM_PAINT:
			GetClientRect(hWnd, &rc);
			
			if(GraphData.jys ==0)
				j =13;
			else
				j =9;
			
			BeginPaint(hWnd, &ps);
			hPen =CreatePen(PS_SOLID, 2, RGB(180, 180, 180));
			SelectObject(ps.hdc, hPen);
			SelectObject(ps.hdc, GetStockObject(NULL_BRUSH));
			Rectangle(ps.hdc, 2, 2, rc.right-2, rc.bottom-1);
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
			MoveTo(ps.hdc, rc.right, 0);
			LineTo(ps.hdc, 0, 0);
			LineTo(ps.hdc, 0, rc.bottom);
			hPen =CreatePen(PS_SOLID, 2, RGB(80, 80, 80));
			SelectObject(ps.hdc, hPen);
			LineTo(ps.hdc, rc.right-1, rc.bottom-1);
			LineTo(ps.hdc, rc.right-1, 0);
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
			
			strcpy(tmp, "ָ��");
			SelectObject(ps.hdc, ghFontSmall);
			dw =GetTextExtent(ps.hdc, tmp, strlen(tmp));
			height =HIWORD(dw)-1;
			
			SetBkMode(ps.hdc, TRANSPARENT);
			SetTextColor(ps.hdc, RGB(255, 255, 0));
			
			SetTextAlign(ps.hdc, TA_LEFT|TA_TOP);
			
			k =	GraphData.recNum;
			y =3;
			m =0;
			for(i =0; i<j; i++)
			{
				SetTextAlign(ps.hdc, TA_LEFT|TA_TOP);
				SetTextColor(ps.hdc, RGB(255, 255, 0));
				if(y+height >rc.bottom -3){ m =1; y=3;}
				//TextOut(ps.hdc, rc.right*m/2+5, y,
				//		((LPSTR *)ZsTitles[GraphData.jys])[i],
				//		strlen(((LPSTR *)ZsTitles[GraphData.jys])[i]));
				if(GraphData.jys ==0)
					TextOut(ps.hdc, rc.right*m/2+5, y,
						SzZsTitles[i], strlen(SzZsTitles[i]));
				else
					TextOut(ps.hdc, rc.right*m/2+5, y,
						ShZsTitles[i], strlen(ShZsTitles[i]));
				
				if(showSd)
					sprintf(tmp, "%.2f", DpData[GraphData.jys].sd[i]);
				else
					sprintf(tmp, "%.2f", DpData[GraphData.jys].zs[i]);
				SetTextAlign(ps.hdc, TA_RIGHT|TA_TOP);
				if(DpData[GraphData.jys].sd[i] >0)
					SetTextColor(ps.hdc, RGB(255, 0, 0));
				else if(DpData[GraphData.jys].sd[i] <0)
					SetTextColor(ps.hdc, RGB(0, 255, 0));
				else
					SetTextColor(ps.hdc, RGB(255, 255, 255));
				TextOut(ps.hdc, rc.right/2+rc.right*m/2-5, y,
						tmp, strlen(tmp));
				y +=height;
			}
			EndPaint(hWnd, &ps);
		break;
		
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}
