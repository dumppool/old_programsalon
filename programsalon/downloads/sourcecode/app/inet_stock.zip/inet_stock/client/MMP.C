#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "hq.h"
#include "hq_cl.h"
#include "mmp.h"
#include "toolbar.h"

#define MMP_CLASS	"CMMP"

extern HINSTANCE ghInstance;
extern HWND ghWndMain, ghWndMmp;
extern BOOL ErrMsg(HWND, LPSTR);
extern BOOL IsZsRec(int jys, int rec_num);

BOOL RegisterMmp(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	
	wc.lpfnWndProc =MmpWndProc;
	wc.lpszClassName =MMP_CLASS;
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = ghInstance;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

BOOL CreateWndMmp(HWND hWnd)
{                          
	int x ;
	HWND hwnd;
	HDC hDC;
	TEXTMETRIC tm;
	int x0,y0,x1,y1;
	RECT rc;
		
	x =GetSystemMetrics(SM_CXSCREEN);

	hDC =GetDC(hWnd);
	GetTextMetrics(hDC, &tm);
	ReleaseDC(hWnd, hDC);
	              
	GetWindowRect(ghWndXlt,&rc);	
	x0 =rc.right;
	y0 =STATUS_HEIGHT +TOOLBAR_HEIGHT;
	
	x1 =x*1/3-30-1;
	y1 = tm.tmHeight*6+STATUS_HEIGHT;

    if(ghWndMmp ==NULL)
   	{
		hwnd =CreateWindow(MMP_CLASS, NULL, WS_CHILD|WS_CLIPSIBLINGS,
						x0, y0, x1, y1,hWnd, NULL, ghInstance, NULL);	
		if(hwnd ==NULL)
		{
			ErrMsg(hWnd, "Error create mmp window");
			return FALSE;
		}	
		ghWndMmp =hwnd;
	}
	else
	{  
		SetWindowPos(ghWndMmp, (HWND) NULL,x0, y0, x1, y1,NULL);	
	}
	return TRUE;
}

LPSTR MmpTitles[]=
{
	"�������", "��λ", "����", NULL
};

extern int UDP_Send_Mmp(int, int);

LRESULT CALLBACK MmpWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	char tmp[256];
	PAINTSTRUCT ps;
	DWORD dw;
	int i, j, x, y;
	RECT rc;
	HPEN hPen;
	//TEXTMETRIC tm;	
	
	switch(message)
	{
		case WM_SETFOCUS:
			SetFocus(ghWndMain);
		break;
		case WM_SIZE:
			if(IsWindowVisible(ghWndMmp))
				InvalidateRect(hWnd, NULL, TRUE);
		break;
		case WM_READ_OK:
			InvalidateRect(hWnd, NULL, FALSE);
		break;

		case WM_PAINT:
			BeginPaint(hWnd, &ps);
			GetClientRect(hWnd, &rc);
						
			hPen =CreatePen(PS_SOLID, 2, RGB(180, 180, 180));
			SelectObject(ps.hdc, hPen);
			SelectObject(ps.hdc, GetStockObject(NULL_BRUSH));
			Rectangle(ps.hdc, 2, 2, rc.right-2, rc.bottom-1);
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
			MoveTo(ps.hdc, rc.right, 0);
			LineTo(ps.hdc, 0, 0);
			LineTo(ps.hdc, 0, rc.bottom);
			hPen =CreatePen(PS_SOLID, 2, RGB(80, 80, 80));
			SelectObject(ps.hdc, hPen);
			LineTo(ps.hdc, rc.right-1, rc.bottom-1);
			LineTo(ps.hdc, rc.right-1, 0);
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);

			strcpy(tmp, "������");
			dw =GetTextExtent(ps.hdc, tmp, strlen(tmp));
			x =LOWORD(dw); y =HIWORD(dw);
			
			//SetTextColor(ps.hdc, RGB(255, 255, 255));
			SetBkMode(ps.hdc, TRANSPARENT);
			//TextOut(ps.hdc, (rc.right-x)/2, 3, tmp, strlen(tmp));
			
			SetTextAlign(ps.hdc, TA_RIGHT|TA_BOTTOM);
			for(i =0; i<3; i++)
			{
				wsprintf(tmp, "%d", 3-i);
				SetTextColor(ps.hdc, RGB(255, 255, 0));
				TextOut(ps.hdc, rc.right*2/7, (y+2)*(i+1),
						tmp, strlen(tmp));
				SetTextColor(ps.hdc, RGB(180, 0, 0));
				if(MmpData.jys ==0) j=i; else j=2-i;
				if(MmpData.jwSell[i] >HqData[MmpData.jys].lpPreData[MmpData.recNum].zrsp)
					SetTextColor(ps.hdc, RGB(255, 0, 0));
				else if(MmpData.jwSell[i] <HqData[MmpData.jys].lpPreData[MmpData.recNum].zrsp)
					SetTextColor(ps.hdc, RGB(0, 255, 0));
				else SetTextColor(ps.hdc, RGB(255, 255, 0));
				sprintf(tmp, "%.2f", MmpData.jwSell[i]);
				TextOut(ps.hdc, rc.right*3/5, (y+2)*(i+1),
						tmp, strlen(tmp));
				SetTextColor(ps.hdc, RGB(0, 255, 255));
				sprintf(tmp, "%ld", MmpData.slSell[i]);
				TextOut(ps.hdc, rc.right-8, (y+2)*(i+1),
						tmp, strlen(tmp));
			}
			SetTextColor(ps.hdc, RGB(255, 255, 0));
			TextOut(ps.hdc, rc.right/7, (y+2)*3, "��:", 3);
			
			hPen =CreatePen(PS_SOLID, 2, RGB(180, 180, 180));
			SelectObject(ps.hdc, hPen);
			
			MoveTo(ps.hdc, 3, (y+2)*3+1);
			LineTo(ps.hdc, rc.right-3, (y+2)*3+1);
			
			SetTextAlign(ps.hdc, TA_TOP|TA_RIGHT);
			TextOut(ps.hdc, rc.right/7, (y+2)*4+2, "��:", 3);
			
			MoveTo(ps.hdc, 3, (y+2)*4+1);
			LineTo(ps.hdc, rc.right-3, (y+2)*4+1);

			SetTextAlign(ps.hdc, TA_TOP|TA_LEFT);            

            //i =HqPaintData.sortData.key[HqPaintData.curSelRec+HqPaintData.curRecNum];
			sprintf(tmp,"%s%.2f","���:",HqData[MmpData.jys].lpRefData[MmpData.recNum].zgjm);
			if(HqData[MmpData.jys].lpRefData[MmpData.recNum].zgjm>=
					HqData[MmpData.jys].lpPreData[MmpData.recNum].zrsp)
				SetTextColor(ps.hdc, RGB(255, 0, 255));	
			else
			   	SetTextColor(ps.hdc, RGB(0, 255, 255));			   
			TextOut(ps.hdc, 6, (y+2)*3+2, tmp, strlen(tmp));
		
			sprintf(tmp,"%s%.2f","����:",HqData[MmpData.jys].lpRefData[MmpData.recNum].zdjm);
			if(HqData[MmpData.jys].lpRefData[MmpData.recNum].zdjm>=
					HqData[MmpData.jys].lpPreData[MmpData.recNum].zrsp)
				SetTextColor(ps.hdc, RGB(255, 0, 255));	
			else
			   	SetTextColor(ps.hdc, RGB(0, 255, 255));
			TextOut(ps.hdc, 2+(int)(rc.right-rc.left)/2, (y+2)*3+2, tmp, strlen(tmp));
            
			MoveTo(ps.hdc, (int)(rc.right-rc.left)/2, (y+2)*3+1);
			LineTo(ps.hdc, (int)(rc.right-rc.left)/2, (y+2)*4+1);
            
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
						
			SetTextAlign(ps.hdc, TA_TOP|TA_RIGHT);
			for(i =0; i<3; i++)
			{
				wsprintf(tmp, "%d", i+1);
				SetTextColor(ps.hdc, RGB(255, 255, 0));
				TextOut(ps.hdc, rc.right*2/7, (y+2)*(i+3+1)+2, tmp, strlen(tmp));
				if(MmpData.jwBuy[i] >HqData[MmpData.jys].lpPreData[MmpData.recNum].zrsp)
					SetTextColor(ps.hdc, RGB(255, 0, 0));
				else if(MmpData.jwBuy[i] <HqData[MmpData.jys].lpPreData[MmpData.recNum].zrsp)
					SetTextColor(ps.hdc, RGB(0, 255, 0));
				else SetTextColor(ps.hdc, RGB(255, 255, 0));
				sprintf(tmp, "%.2f", MmpData.jwBuy[i]);
				TextOut(ps.hdc, rc.right*3/5, (y+2)*(i+3+1)+2,
						tmp, strlen(tmp));
				SetTextColor(ps.hdc, RGB(0, 255, 255));
				sprintf(tmp, "%ld", MmpData.slBuy[i]);
				TextOut(ps.hdc, rc.right-8, (y+2)*(i+3+1)+2,
						tmp, strlen(tmp));
			}
			EndPaint(hWnd, &ps);
		break;
		
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

