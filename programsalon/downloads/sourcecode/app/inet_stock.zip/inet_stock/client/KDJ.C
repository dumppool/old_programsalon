#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "fx.h"

int CreateKdjData(K_DATA *lpKData,int RNum,DATA *Data,PARA *Para)
{
	int  i,j,k;
    double jia1,jia2;
    double Ttr;
	KDJ_DATA *KdjData;
	
	KdjData=(KDJ_DATA*)_fmalloc(sizeof(KDJ_DATA)*RNum);
	memset(KdjData,0,sizeof(KDJ_DATA)*RNum);
	for(j=0;j<RNum;j++)
	{
    	    if(j==0)
    	    {
    	    	KdjData[j].k=0;
    	    	KdjData[j].d=0;
    	    	KdjData[j].j=0;
    	    }    	    
    	    else
    	    {
    	    	if(j<Para->periods[0]-1)
    	    	{
    	    	 	KdjData[j].k=KdjData[j].d=KdjData[j].j=0;
    	    	}
    	    	if(j>=Para->periods[0]-1)
    	    	{
    	    		for(k=1;k<=Para->periods[0];k++)
    	    		{   
    	    		    if(k==1)
    	    		    {       
    			 			jia1=lpKData[k+j-Para->periods[0]].zg;
    			 			jia2=lpKData[k+j-Para->periods[0]].zd;    	    		    
    	    		    }
    	    		    else
    	    		    {
    	    				if(jia1<lpKData[j+k-Para->periods[0]].zg)
    	    					jia1=lpKData[j+k-Para->periods[0]].zg;
    	    				if(jia2>lpKData[j+k-Para->periods[0]].zd)
    	    					jia2=lpKData[j+k-Para->periods[0]].zd;		
    	    			}	
    	    		}
    	    		Ttr=(lpKData[j].ss-jia2)/(jia1-jia2);
    	    		KdjData[j].k=Ttr/3+KdjData[j-1].k*2/3;
    	    		KdjData[j].d=KdjData[j].k/3+KdjData[j-1].d*2/3;
    	    		KdjData[j].j=KdjData[j].k*3-KdjData[j].d*2;
    	    	}
    	    }    	    
    }
    for(j=0;j<10;j++)
    {
        if(Data->v==NULL) 
        	break;
    	if(Data->v[j]!=NULL)
    	{
    		_ffree(Data->v[j]);
    		Data->v[j]=NULL;
    	}
    }    
    Data->v==NULL;     
    Data->num =Para->dnum; 
    Data->no =Para->no;
    strcpy(Data->gpdm,Fx->gpdm);
    Data->type =Fx->type;
    Data->range =Fx->range;
    Data->size =RNum;
    for(j=0;j<Data->num;j++)
    	Data->v[j]=(double *)_fmalloc(sizeof(double)*RNum);
    for(i=0;i<Data->num;i++)
    {
    	for(j=0;j<RNum&&i==0;j++) 
    		Data->v[i][j]=KdjData[j].k*100.00;
    	for(j=0;j<RNum&&i==1;j++) 
    		Data->v[i][j]=KdjData[j].d*100.00;    		
    	for(j=0;j<RNum&&i==2;j++) 
    		Data->v[i][j]=KdjData[j].j*100.00;
    	Data->method[i]=CURVE_METHOD;
    }
    Para->price[0] =100;
    Para->price[1] =0;
    Para->feature |=DW_ALL;
    Para->feature &=~DW_MAX;
    Para->feature &=~DW_MIN;    
    
    _ffree(KdjData);
	return TRUE;
}

