#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "fx.h"

extern LPFX Fx;

int CreatePsyData(K_DATA *lpKData,int RNum,DATA *Data,PARA *Para)
{
	int i,j;
    int l;
    long m;
    int Trise;
    PSY_DATA *PsyData;
    
	PsyData=(PSY_DATA*)_fmalloc(sizeof(PSY_DATA)*RNum);
	memset(PsyData,0,sizeof(PSY_DATA)*RNum);
    for(j=0;j<RNum;j++) 
    {
    		if(j==0)
    		{
    			Trise=0;
    			PsyData[j].psy=0;
    		}
    		else
    		{
    			if(j<=Para->periods[0]-1)
    			{ 
    				if(lpKData[j-1].ss<lpKData[j].ss) Trise++;
    				PsyData[j].psy=0;    			
    			}
    			if(j>Para->periods[0]-1)
    			{  
    				Trise=0;
    				for(l=1;l<=Para->periods[0];l++)
    				{
    					m=j+l-Para->periods[0];
    					if(lpKData[m-1].ss<lpKData[m].ss) Trise++;
    				}
    			}
    			if(j>=Para->periods[0]-1)
    			{
    			    PsyData[j].psy=Trise*100/Para->periods[0];
    			}    			
    		}
     }
    for(j=0;j<10;j++)
    {
        if(Data->v==NULL) 
        	break;
    	if(Data->v[j]!=NULL)
    	{
    		_ffree(Data->v[j]);
    		Data->v[j]=NULL;
    	}
    }
    Data->v==NULL;     
    Data->num =Para->dnum; 
    Data->no =Para->no;
    strcpy(Data->gpdm,Fx->gpdm);
    Data->type =Fx->type;
    Data->range =Fx->range;
    Data->size =RNum;
    for(j=0;j<Data->num;j++)
    	Data->v[j]=(double *)_fmalloc(sizeof(double)*RNum);
    for(i=0;i<Data->num;i++)
    {
    	for(j=0;j<RNum&&i==0;j++) 
    		Data->v[i][j]=PsyData[j].psy;
    	Data->method[i]=CURVE_METHOD;
    }
    Para->price[0] =100;
    Para->price[1] =0;
    Para->price[2] =10;
    Para->price[3] =90;
    Para->feature |=DW_ALL;
    Para->feature &=~DW_MAX;
    Para->feature &=~DW_MIN;
    _ffree(PsyData);
	return TRUE;
}

