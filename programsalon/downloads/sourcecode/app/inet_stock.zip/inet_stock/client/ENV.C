#include <windows.h>
#include <commdlg.h>
#include <string.h>
#include <stdio.h>
#include <malloc.h>
#include <ctype.h>
#include <stdlib.h>
#include <io.h>
#include "resource.h"
#include "appmain.h"
#include "hq.h"
#include "hq_tcp.h"
#include "hq_cl.h"
#include "jy_cl.h"
#include "jy_tcp.h"
#include "msg.h"
#include "pctcp.h"
#include "fx.h"
       
extern BOOL IsZsRec(int jys, int recNum);
extern BOOL ErrMsg(HWND, LPSTR);
extern char szDataPath[128];

LRESULT CALLBACK SetHqEnvProc(HWND hDlg, UINT msg,
	WPARAM wParam, LPARAM lParam);


extern void Ip_Commit_Pack(int len,char *buff);

#define		SET_SUCC		0
#define		SET_NO_THIS_ID	-1
#define		SET_PWD_ERROR	-2
#define		SET_DATA_ERROR	-3

#define 	DATA_START_SIGN -16

#define		MAX_UCODE_SIZE	6
#define		MAX_PWD_SIZE	6

typedef struct tag_TCP_FRAME_HQ_ENV
{
    char sign;
    int len;
 	char head[6];
	char ucode[MAX_UCODE_SIZE];
	char pwd[MAX_PWD_SIZE];
	char newpwd[MAX_PWD_SIZE+1];
}TCP_FRAME_HQ_ENV;

int SetHqEnv(void)
{
	FARPROC lpDlgProc =NULL;

	lpDlgProc =MakeProcInstance((FARPROC)SetHqEnvProc, ghInstance);
	DialogBox(ghInstance, MAKEINTRESOURCE(IDD_ENV_HQ), ghWndMain,
				lpDlgProc);
	FreeProcInstance(lpDlgProc);
	return TRUE;	
}


LRESULT CALLBACK SetHqEnvProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	char tmp[80];
	HWND hctl;
	int i,j;
	//int idFocus;
	//LPDRAWITEMSTRUCT lpdis;
	LOGFONT tmplf;	
	//static HBRUSH hBrush;	    
	//RECT rc;
	//HDC hDC;
	OFSTRUCT os;
	HANDLE hf;	
	TCP_FRAME_HQ_ENV TcpFrameHqEnv;
	CHOOSEFONT cf;
	STOCK_INFO_FRAME StockInfo;
		    
	switch(msg)
	{
		case WM_INITDIALOG:
			SendDlgItemMessage(hDlg, IDC_ENV_IP, EM_LIMITTEXT, 16, 0L);
			SendDlgItemMessage(hDlg, IDC_ENV_USEPWD, EM_LIMITTEXT, 6, 0L);
			SendDlgItemMessage(hDlg, IDC_ENV_NEWPWD, EM_LIMITTEXT, 6, 0L);
			
			GetInitString("NET", "HOST", tmp);
			SetDlgItemText(hDlg, IDC_ENV_IP, tmp);
			
			sprintf(tmp,"%d",ITEM_SPACE_X);
			SetDlgItemText(hDlg, IDC_ENV_SPACE, tmp);			
			sprintf(tmp,"%d",X0_TITLE);
			SetDlgItemText(hDlg, IDC_ENV_ZQMC, tmp);
			
            sprintf(tmp,"%d",Fx->range+1);
            SetDlgItemText(hDlg, IDC_ENV_PERI, tmp);
			CenterWindow(hDlg);
			//hBrush=CreateSolidBrush(RGB(0,255,255));
		return TRUE;
		
		case WM_PAINT:
			BeginPaint(hDlg, &ps);
			DrawFrame(ps.hdc, hDlg);
			
			//GetClientRect(hDlg, &rc);
			EndPaint(hDlg, &ps);
		break;
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
				   	GetDlgItemText(hDlg, IDC_ENV_IP, tmp,16);
					PutInitString("NET", "HOST", tmp);
				    
				    strncpy(TcpFrameHqEnv.ucode,UserID,6);
				    
                    GetDlgItemText(hDlg, IDC_ENV_USEPWD, tmp,7);
				    if(strlen(tmp)>0)
				    {
				    	strncpy(TcpFrameHqEnv.pwd,tmp,6);
				    }
				    
					GetDlgItemText(hDlg, IDC_ENV_NEWPWD, tmp,7);					
					if(strlen(tmp)>0)
					{        
						strncpy(TcpFrameHqEnv.newpwd,tmp,6);
					 	TcpFrameHqEnv.newpwd[MAX_PWD_SIZE] =0;

						TcpFrameHqEnv.sign =DATA_START_SIGN;
						TcpFrameHqEnv.len =sizeof(TCP_FRAME_HQ_ENV) -3;
					    strncpy(TcpFrameHqEnv.head,"SETENV",6); 
					 	
					 	GetDlgItemText(hDlg, IDC_ENV_PWDAGAIN, tmp,7);
					 	if(strncmp(tmp,TcpFrameHqEnv.newpwd,6)!=0)
					 	{               
					 	    MessageBox(hDlg, "��������������벻ͬ","��������", MB_OK);
					 	    hctl =GetDlgItem(hDlg, IDC_ENV_PWDAGAIN);
							SetFocus(hctl);
							break;
					 	}
					 	else
					 	{
					 		Ip_Commit_Pack(sizeof(TCP_FRAME_HQ_ENV),(char *)&TcpFrameHqEnv);
					 		Msg("�����޸������û�����������ѷ���",MSG_VERT);		 	
					 	}
					}   
					
					GetDlgItemText(hDlg, IDC_ENV_SPACE, tmp,10);
					i =atoi(tmp);
					GetDlgItemText(hDlg, IDC_ENV_ZQMC, tmp,10);
					j =atoi(tmp);

					if((unsigned short)i!=ITEM_SPACE_X||(unsigned short)j!=X0_TITLE)
					{
						if(i>=1 &&i<=20)
						{
							ITEM_SPACE_X =i;
							sprintf(tmp,"%d",ITEM_SPACE_X);
							PutInitString("HQ", "ITEM_SPACE_X", tmp);
						}
						if(j>=40 &&j<=90)
						{
							X0_TITLE =j;
							sprintf(tmp,"%d",X0_TITLE);
							PutInitString("HQ", "X0_TITLE", tmp);
						}
						PostMessage(ghWndHq,WM_USER+5,0,0L);
						InvalidateRect(ghWndHq, NULL, TRUE);
					} 
					GetDlgItemText(hDlg, IDC_ENV_PERI, tmp,10);
            		i=atoi(tmp);
            		if(i>0&&i<8)
            		{   
            			i--;
						CheckMenuItem(ghMenuMain,RANGE_MENU[Fx->range], MF_BYCOMMAND|MF_UNCHECKED);
						CheckMenuItem(ghMenuMain,RANGE_MENU[i], MF_BYCOMMAND|MF_CHECKED);
            			Fx->range =i;
            			sprintf(tmp,"%d",i);
            			PutInitString("FX", "RANGE", tmp);
            		}
					EndDialog(hDlg, 1);
				break;
				case IDCANCEL:
					EndDialog(hDlg, 1);
				break;
				case IDC_FONT:
					memset(&cf, 0, sizeof(CHOOSEFONT));
					cf.lStructSize = sizeof(CHOOSEFONT);
					cf.hwndOwner = ghWndMain;
					cf.lpLogFont = &tmplf;
					cf.Flags = CF_SCREENFONTS | CF_EFFECTS;
					cf.rgbColors = RGB(0, 255, 255); /* light blue */
					cf.nFontType = SCREEN_FONTTYPE;					
					if(ChooseFont(&cf))
					{   
						memcpy(&lf,&tmplf,sizeof(LOGFONT));
						strcpy(tmp,"font.dat");
						hf =OpenFile(tmp, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_WRITE);
						_lwrite(hf,&lf,sizeof(LOGFONT));
						_lclose(hf);
						PostMessage(ghWndHq,WM_USER+1,0,0L);
						InvalidateRect(ghWndHq, NULL, TRUE);
					}
				break;
				case IDC_SZ_MINUTE:
				    StockInfo.type=FILE_SZ_ALL_MINUTE;
				    strcpy(StockInfo.name,"");
			    	UDP_Send_Stock_Info(&StockInfo);
			    	hctl =GetDlgItem(hDlg, IDC_SZ_MINUTE);
			    	EnableWindow(hctl, FALSE);
			    	hctl =GetDlgItem(hDlg, IDC_SZ_DAY);
			    	EnableWindow(hctl, FALSE);			    	
			    	hctl =GetDlgItem(hDlg, IDC_SH_MINUTE);
			    	EnableWindow(hctl, FALSE);
			    	hctl =GetDlgItem(hDlg, IDC_SH_DAY);
			    	EnableWindow(hctl, FALSE);				
			    break;
				case IDC_SZ_DAY:
				    StockInfo.type=FILE_SZ_ALL_DAY;
				    strcpy(StockInfo.name,"");
			    	UDP_Send_Stock_Info(&StockInfo);
			    	hctl =GetDlgItem(hDlg, IDC_SZ_MINUTE);
			    	EnableWindow(hctl, FALSE);
			    	hctl =GetDlgItem(hDlg, IDC_SZ_DAY);
			    	EnableWindow(hctl, FALSE);			    	
			    	hctl =GetDlgItem(hDlg, IDC_SH_MINUTE);
			    	EnableWindow(hctl, FALSE);
			    	hctl =GetDlgItem(hDlg, IDC_SH_DAY);
			    	EnableWindow(hctl, FALSE);				
				break;
				case IDC_SH_MINUTE:
				    StockInfo.type=FILE_SH_ALL_MINUTE;
				    strcpy(StockInfo.name,"");
			    	UDP_Send_Stock_Info(&StockInfo);
			    	hctl =GetDlgItem(hDlg, IDC_SZ_MINUTE);
			    	EnableWindow(hctl, FALSE);
			    	hctl =GetDlgItem(hDlg, IDC_SZ_DAY);
			    	EnableWindow(hctl, FALSE);			    	
			    	hctl =GetDlgItem(hDlg, IDC_SH_MINUTE);
			    	EnableWindow(hctl, FALSE);
			    	hctl =GetDlgItem(hDlg, IDC_SH_DAY);
			    	EnableWindow(hctl, FALSE);				
				break;
				case IDC_SH_DAY:
				    StockInfo.type=FILE_SH_ALL_DAY;
				    strcpy(StockInfo.name,"");
			    	UDP_Send_Stock_Info(&StockInfo);
			    	hctl =GetDlgItem(hDlg, IDC_SZ_MINUTE);
			    	EnableWindow(hctl, FALSE);
			    	hctl =GetDlgItem(hDlg, IDC_SZ_DAY);
			    	EnableWindow(hctl, FALSE);			    	
			    	hctl =GetDlgItem(hDlg, IDC_SH_MINUTE);
			    	EnableWindow(hctl, FALSE);
			    	hctl =GetDlgItem(hDlg, IDC_SH_DAY);
			    	EnableWindow(hctl, FALSE);			    	
				break;
			}
		break;
	}
	return FALSE;
}
       