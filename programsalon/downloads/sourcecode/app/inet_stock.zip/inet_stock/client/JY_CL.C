#include <windows.h>
#include <string.h>
#include <stdio.h>
#include <malloc.h>
#include <ctype.h>
#include <stdlib.h>
#include <io.h>
#include "resource.h"
#include "hq.h"
#include "hq_cl.h"
#include "jy_cl.h"
#include "jy_tcp.h"
#include "msg.h"
#include "pctcp.h"
#include "des.h"

JY_ANS_CHKUSR curChkUsrRes;
JY_ASK_CHKUSR curChkUsrData;

ZQSXX Qsxx;
char Addr[MAX_ZQS_COUNT][15];
extern BOOL gfTest;
extern int STATUS_HEIGHT;
int JyFunc=0,JyOffLineTime=250,JyQs=0;

#define NULL_FUNC		0	          
#define BUY_FUNC		1
#define SELL_FUNC		2
#define CANCEL_FUNC		3          
#define	CJCX_FUNC		4
#define WTCX_FUNC		5
#define YECX_FUNC		6
#define CHGPWD_FUNC		7	
#define EXIT_FUNC		8

#define MAX_IDEL_TIME	120

void CenterWindow(HWND hDlg);

int gnTimers =0;

extern BOOL udpread_stop;
extern HINSTANCE ghInstance;
extern HWND ghWndMain, ghWndHq, ghWndStatus, hWndInput;

extern BOOL IsZsRec(int jys, int recNum);
extern BOOL ErrMsg(HWND, LPSTR);
void FAR PASCAL JyDlgDrawEntireItem(LPDRAWITEMSTRUCT lpdis, int inflate);
int ShowBitmap(HDC hDC, int left, int top, HBITMAP hBmp);
void DrawFrame(HDC hDC, HWND hWnd);
extern void DrawTime(int ret);
extern char szDataPath[128];
extern int ConnectToJyHost(char *HostName);

HBITMAP hBmpBrush =NULL;
HBRUSH hBrushBkGround =NULL;
HWND ghDlgJy =NULL;
extern HWND ghWndXlt, ghWndJlt, ghWndCj, ghWndMmp, ghWndLitHq;

extern int sdHq;

#define JY_BTN_COUNT	14

HBITMAP hBmpSel =NULL, hBmpFoc =NULL;

void FAR PASCAL BtnDrawEntireItem(LPDRAWITEMSTRUCT lpdis);
void FAR PASCAL BtnFocusState(LPDRAWITEMSTRUCT lpdis);
void FAR PASCAL BtnSelectionState(LPDRAWITEMSTRUCT lpdis);
void DrawBtnNormal(LPDRAWITEMSTRUCT lpdis, BOOL fDrawFrame);
void DrawBtnFocus(LPDRAWITEMSTRUCT lpdis);
void DrawBtnUnFocus(LPDRAWITEMSTRUCT lpdis);
void DrawBtnSelected(LPDRAWITEMSTRUCT lpdis);
HBRUSH DrawChild(HDC hDC, HWND hWnd);
BOOL isWndClass(HWND hWnd,LPSTR ClassName);

extern int WinVer;
extern char  *JyReadBuf;
extern unsigned char DesKey[9];

BOOL JyInit(void)
{   
	
	JyReadBuf  =(char *)_fmalloc(MAX_READ_BUF_SIZE+1);
	
	memset(&curChkUsrRes, 0, sizeof(curChkUsrRes));
	curChkUsrRes.flag =-1;
	memset(&curChkUsrData, 0, sizeof(curChkUsrData));
	memset(&Qsxx,0,sizeof(ZQSXX));
	
	hBmpBrush =LoadBitmap(ghInstance, MAKEINTRESOURCE(IDB_BACKGROUND));
	if(hBmpBrush ==NULL)
	{
		ErrMsg(NULL, "load background bitmap failed");
		return FALSE;
	}
	hBrushBkGround =CreatePatternBrush(hBmpBrush);
	if(hBrushBkGround ==NULL)
	{
		ErrMsg(NULL, "Create background brush failed");
		return FALSE;
	}
	
	
	if(access("DES3W16.DLL",0)==0)
		hDesDll = LoadLibrary("DES3W16.DLL");
	
	//if(hDesDll==NULL)
	//{
	//	ErrMsg(ghWndMain, "can not load DES dll"); 
	//	return FALSE;
	//}
	//else
	if(hDesDll>32)
	{
		desinit= (lpfnDES_INIT)GetProcAddress(hDesDll,"desinit");
		ecbencode =(lpfnDES_ECB)GetProcAddress(hDesDll,"ecbencode");
		if(!desinit||!ecbencode)
		{
			ErrMsg(ghWndMain, "can not load DES FUNC"); 
			FreeLibrary(hDesDll);
			hDesDll=NULL;
			//return FALSE;
		}
    }
    else
    	hDesDll =NULL;
    	
	strcpy(DesKey,"98124325");
	hBmpSel =LoadBitmap(ghInstance, MAKEINTRESOURCE(IDB_SEL));
	hBmpFoc =LoadBitmap(ghInstance, MAKEINTRESOURCE(IDB_FOC));
	return TRUE;
}

int InitQsInfo(void)
{ 
	int i;
	char buf[256];
	char item[40],file[80];
	
	sprintf(file,"%s\\sysinfo.dat",szDataPath);
	for(i=0;i<MAX_ZQS_COUNT;i++)	
	{
		sprintf(item,"QS%d",i+1);
		GetPrivateProfileString("ZQS_NAME", item, "", buf, 256, file);
		if(*buf==0)
			break;
		strcpy(Qsxx.zqsjc[i],buf);
		Qsxx.zqsid[i] =i+1;
		GetPrivateProfileString("ZQS_ADDR", item, "", buf, 256, file);
		if(*buf!=0)
			strcpy(Addr[i],buf);			
	}
	if(i==0&&*buf==0) return -1;
	return 0;
}

void JyExit(void)
{
	if(hBrushBkGround) DeleteObject(hBrushBkGround);
	if(hBmpBrush) DeleteObject(hBmpBrush);
	if(hBmpSel) DeleteObject(hBmpSel);
	if(hBmpFoc) DeleteObject(hBmpFoc);
	_ffree(JyReadBuf);   
	if(hDesDll!=NULL) FreeLibrary(hDesDll);
}

extern void SendJyExit(char *);
extern void SendJyQsxx(void);

int jy(void)
{       
	if(HqTime[0].fRunning ==FALSE && HqTime[1].fRunning ==FALSE)
	{
		ErrMsg(ghWndMain, "���ں��Ϻ��������Ѿ�����!");
		return 0;
	}
	
	if(JyQs ==0 && !gfTest)
	{
		ErrMsg(ghWndMain, "������F11��ѡ��ȯ��!");
		return 0;
	}
	if(curChkUsrRes.userId==0 && !gfTest)	
	{
		if(DlgSelectJys()<0) 
			return 0;
		// ����û��Ĺɶ�����ͽ�������
		if(DlgChkUsr() <0) 
			return 0;
		if(curChkUsrRes.userId==0)
			return 0;			
	}
	
	JyOffLineTime=250;
	while(1)
	{
		DlgJy();	
		switch(JyFunc)
		{
			case NULL_FUNC:
				return 0;
			case BUY_FUNC:
					DlgBuySell('B');
			break;
			case SELL_FUNC:
					DlgBuySell('S');
			break;
			case CANCEL_FUNC:
					DlgCancel();
			break;
			case CJCX_FUNC:
					DlgCjcx();
			break;
			case WTCX_FUNC:
					DlgWtcx();
			break;
			case YECX_FUNC:
					DlgYecx();
			break;
			case CHGPWD_FUNC:
					DlgChgPwd();
			break;				
			case EXIT_FUNC:
				SendJyExit(curChkUsrData.gddm);
				curChkUsrRes.flag =-1;
				curChkUsrRes.userId=0;
				return 0;
			break;
			default:
				break;
		}
	}
	return 0;
}

FARPROC lpDlgProc =NULL;

int DlgSelectJys(void)
{
	int jys =0;
	
	lpDlgProc =MakeProcInstance((FARPROC)SelJysDlgProc, ghInstance);
	jys =DialogBox(ghInstance, MAKEINTRESOURCE(IDD_JY_SZSH), ghWndMain,
				lpDlgProc);
	FreeProcInstance(lpDlgProc);
	
	jys -=1;
	if(jys >=0)
	{
		if(HqTime[jys].fRunning ==FALSE)
		{
			curChkUsrRes.flag =-1;
			ErrMsg(ghWndMain, "����ע�⣬�Ѿ�����!");
			return -1;
		}
		curChkUsrRes.jys =jys;
		if(jys !=HqPaintData.jys)
		{
			HqPaintData.curSelRec =0;
			HqPaintData.curRecNum =0;
			if(HqPaintData.jys =0) SendMessage(ghWndHq, WM_COMMAND, IDM_HQ_SZ, 0L);
			else SendMessage(ghWndHq, WM_COMMAND, IDM_HQ_SH, 0L);
		}
	}
	
	return jys;
}

int DlgSelectZqs(void)
{
	int zqs =0;
	
	lpDlgProc =MakeProcInstance((FARPROC)SelZqsDlgProc, ghInstance);
	zqs =DialogBox(ghInstance, MAKEINTRESOURCE(IDD_JY_ZQSXX), ghWndMain,
				lpDlgProc);
	FreeProcInstance(lpDlgProc);
	
    return(zqs);
}

int DlgChkUsr(void)
{
	curChkUsrRes.flag =-1;
	lpDlgProc =MakeProcInstance((FARPROC)ChkUsrDlgProc, ghInstance);
	DialogBox(ghInstance, MAKEINTRESOURCE(IDD_JY_CHKUSR), ghWndMain,
				lpDlgProc);
	FreeProcInstance(lpDlgProc);
	
	return curChkUsrRes.flag;
}

BOOL IsCanPwdChg =FALSE;

int DlgChgPwd(void)
{

	lpDlgProc =MakeProcInstance((FARPROC)AskPwdDlgProc, ghInstance);
	DialogBox(ghInstance, MAKEINTRESOURCE(IDD_JY_ASKPWD), ghDlgJy,
				lpDlgProc);
	FreeProcInstance(lpDlgProc);
    
    if(IsCanPwdChg)
    {
		lpDlgProc =MakeProcInstance((FARPROC)ChgPwdDlgProc, ghInstance);
		DialogBox(ghInstance, MAKEINTRESOURCE(IDD_JY_CHGPWD), ghDlgJy,
				lpDlgProc);
		FreeProcInstance(lpDlgProc);
	}
	
	return 0;
}

int DlgJy(void)
{
	lpDlgProc =MakeProcInstance((FARPROC)JyDlgProc, ghInstance);
	DialogBox(ghInstance, MAKEINTRESOURCE(IDD_JY_DLG), ghWndMain,
				lpDlgProc);
	FreeProcInstance(lpDlgProc);
	
	return 0;
}

int DlgBuySell(int bs)
{
	lpDlgProc =MakeProcInstance((FARPROC)BuySellDlgProc, ghInstance);
	DialogBoxParam(ghInstance, MAKEINTRESOURCE(IDD_JY_BUYSELL), ghDlgJy,
				lpDlgProc, bs);
	FreeProcInstance(lpDlgProc);
	
	return 0;
}

int DlgCancel(void)
{
	lpDlgProc =MakeProcInstance((FARPROC)CancelDlgProc, ghInstance);
	DialogBox(ghInstance, MAKEINTRESOURCE(IDD_JY_CANCEL), ghDlgJy,
				lpDlgProc);
	FreeProcInstance(lpDlgProc);
	
	return 0;
}

int DlgYecx(void)
{
	lpDlgProc =MakeProcInstance((FARPROC)YecxDlgProc, ghInstance);
	DialogBox(ghInstance, MAKEINTRESOURCE(IDD_JY_YECX), ghDlgJy,
				lpDlgProc);
	FreeProcInstance(lpDlgProc);
	
	return 0;
}

int DlgCjcx(void)
{
	lpDlgProc =MakeProcInstance((FARPROC)CjcxDlgProc, ghInstance);
	DialogBox(ghInstance, MAKEINTRESOURCE(IDD_JY_CJCX), ghDlgJy,
				lpDlgProc);
	FreeProcInstance(lpDlgProc);
	
	return 0;
}

int DlgWtcx(void)
{
	lpDlgProc =MakeProcInstance((FARPROC)WtcxDlgProc, ghInstance);
	DialogBox(ghInstance, MAKEINTRESOURCE(IDD_JY_WTCX), ghDlgJy,
				lpDlgProc);
	FreeProcInstance(lpDlgProc);
	
	return 0;
}

LRESULT CALLBACK SelJysDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	LPDRAWITEMSTRUCT lpdis;
	HWND hctl;

    HFONT hFont;
    LOGFONT lf;
	RECT rc;
			
	switch(msg)
	{
		case WM_INITDIALOG:
			ghDlgJy =hDlg;
			
			//if(Qsxx.zqsid[0]==0)
			//{
			//	if(InitQsInfo()!=0)
			//		SendJyQsxx();
			//}
			CenterWindow(hDlg);
		return TRUE;

		case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_DLG:
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_MSGBOX:
				case CTLCOLOR_STATIC:	
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
			}
		return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
        
		case WM_DRAWITEM:
			lpdis = (LPDRAWITEMSTRUCT)lParam;

			if (lpdis->itemID == -1)
				BtnFocusState(lpdis);
			else
			{
				switch (lpdis->itemAction)
				{
					case ODA_DRAWENTIRE: 
						BtnDrawEntireItem(lpdis);
					break;

					case ODA_SELECT:
						BtnSelectionState(lpdis);
					break;

					case ODA_FOCUS:
						BtnFocusState(lpdis);
					break;
				}
			}
		break;
		
		case WM_PAINT:
			BeginPaint(hDlg, &ps);			
			DrawFrame(ps.hdc, hDlg);
			
			GetClientRect(hDlg, &rc);		
			
			memset(&lf,0,sizeof(lf));
			lf.lfEscapement =0;
			lf.lfOrientation =0;
			lf.lfStrikeOut =0;
			lf.lfUnderline =0;
			lf.lfItalic =0;
			lf.lfCharSet = ANSI_CHARSET;
			lf.lfPitchAndFamily = FF_SCRIPT;
						
			lf.lfWeight =FW_NORMAL;            
			strcpy(lf.lfFaceName, "Termianl");			
       		lf.lfHeight=18;       		
       		hFont =CreateFontIndirect(&lf);
       		SelectObject(ps.hdc,hFont);

			SetBkMode(ps.hdc,TRANSPARENT);       		
			
       		SetTextColor(ps.hdc,RGB(0,0,0));
			TextOut(ps.hdc,rc.left +10,rc.top+10,"����ѡ������",14);

       		SetTextColor(ps.hdc,RGB(255,255,255));
			TextOut(ps.hdc,rc.left +10-1,rc.top+10-1,"����ѡ������",14);
			
			DeleteObject(hFont);
			EndPaint(hDlg, &ps);
		break;
		
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					hctl =GetFocus();
					SendMessage(hDlg, WM_COMMAND, GetWindowWord(hctl, GWW_ID), 0L);
				break;
				case IDC_SH:
					EndDialog(hDlg, 2);
				break;
				case IDC_SZ:
					EndDialog(hDlg, 1);
				break;
				case IDCANCEL:
					EndDialog(hDlg, 0);
					ghDlgJy =NULL;
				break;
			}
		break;
	}
	
	return FALSE;	
}


LRESULT CALLBACK SelZqsDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	LPDRAWITEMSTRUCT lpdis;
    char temp[20];
    int i;
	static HBRUSH 	hBrush;
	HWND hctl; 	
	DWORD dw;
			
	switch(msg)
	{
		case WM_INITDIALOG:
			ghDlgJy =hDlg;
			CenterWindow(hDlg);
			hBrush=CreateSolidBrush(RGB(0,255,255));			
		
			for(i=0;i<MAX_ZQS_COUNT;i++)
			{
				if(Qsxx.zqsid[i]!=0)
					SendDlgItemMessage(hDlg, IDC_LIST1, LB_ADDSTRING, 0,
						(LPARAM)(LPSTR)Qsxx.zqsjc[i]);
				else
					break;		
			}			
			if(i>0)
				SendDlgItemMessage(hDlg, IDC_LIST1, LB_SETCURSEL,(WPARAM)0L,
					(LPARAM)(LPSTR)0L);			 
			 
			//hctl =GetDlgItem(hDlg, IDC_LIST1);
			//SetFocus(hctl);
			return TRUE;

		case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_DLG:
				case CTLCOLOR_MSGBOX:
				case CTLCOLOR_STATIC:	
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_LISTBOX:
					return (LRESULT)hBrush;	
			}
		return (LRESULT)NULL;
        
		case WM_DRAWITEM:
			lpdis = (LPDRAWITEMSTRUCT)lParam;

			if (lpdis->itemID == -1)
				BtnFocusState(lpdis);
			else
			{
				switch (lpdis->itemAction)
				{
					case ODA_DRAWENTIRE: 
						BtnDrawEntireItem(lpdis);
					break;

					case ODA_SELECT:
						BtnSelectionState(lpdis);
					break;

					case ODA_FOCUS:
						BtnFocusState(lpdis);
					break;
				}
			}
		break;

		case WM_PAINT:
			BeginPaint(hDlg, &ps);			
			DrawFrame(ps.hdc, hDlg);			
			hctl =GetDlgItem(hDlg, IDC_LIST1);
			SetFocus(hctl);
			EndPaint(hDlg, &ps);
		break;
		
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					dw =SendDlgItemMessage(hDlg,IDC_LIST1,LB_GETCURSEL, 0 , 0);
					if(dw!=LB_ERR)
					{
						SendDlgItemMessage(hDlg,IDC_LIST1,LB_GETTEXT,(WPARAM)dw,(LPARAM)(LPSTR)temp);
						curChkUsrData.zqsid=(int)dw +1;
						DeleteObject(hBrush);
						ghDlgJy =NULL;						
						EndDialog(hDlg,(int)dw+1);
					}	
					else 
					{
					    ErrMsg(ghWndMain,"ѡ��ȯ�̳���");					    
						DeleteObject(hBrush);
						ghDlgJy =NULL;						
						EndDialog(hDlg, 0);
					}
				break;	
				case IDCANCEL:    
					DeleteObject(hBrush);
					ghDlgJy =NULL;					
					EndDialog(hDlg, 0);
				break;
			}
		break;
	}
	
	return FALSE;	
}


////////����������͹ɶ�������ڱ���,�Ժ�����server��������
LRESULT CALLBACK ChkUsrDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	int ret;
	char tmp[60];
	HWND hctl;
	int idFocus;
	LPDRAWITEMSTRUCT lpdis;
	HFONT hFont;
	LOGFONT lf;	
	static HBRUSH hBrush;	    
	RECT rc;
	HDC hDC;
	DWORD dw;
		    
	switch(msg)
	{
		case WM_INITDIALOG:
			ghDlgJy =hDlg;
			curChkUsrData.gddm[0] =0;
			curChkUsrData.jymm[0] =0;
			curChkUsrData.jys =curChkUsrRes.jys;
			curChkUsrData.sdHq =sdHq;
			SendDlgItemMessage(hDlg, IDC_INPUT, EM_LIMITTEXT, MAX_GDDM_SIZE, 0L);
			SendDlgItemMessage(hDlg, IDC_INPUT1, EM_LIMITTEXT, MAX_JYMM_SIZE, 0L);
			CenterWindow(hDlg);
			gnTimers =0;
			hBrush=CreateSolidBrush(RGB(0,255,255));
		return TRUE;

		case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_DLG:
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_MSGBOX:
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_LISTBOX:
				case CTLCOLOR_EDIT:	
					return (LRESULT)(HBRUSH)hBrush;
			}
		return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);

		case WM_DRAWITEM:
			lpdis = (LPDRAWITEMSTRUCT)lParam;

			if (lpdis->itemID == -1)
				BtnFocusState(lpdis);
			else
			{
				switch (lpdis->itemAction)
				{
					case ODA_DRAWENTIRE: 
						BtnDrawEntireItem(lpdis);
					break;

					case ODA_SELECT:
						BtnSelectionState(lpdis);
					break;

					case ODA_FOCUS:
						BtnFocusState(lpdis);
					break;
				}
			}
		break;
		
		case WM_PAINT:
			BeginPaint(hDlg, &ps);
			DrawFrame(ps.hdc, hDlg);

			GetClientRect(hDlg, &rc);
			SetBkMode(ps.hdc,TRANSPARENT);            
            
            memset(&lf,0,sizeof(lf));
			strcpy(lf.lfFaceName, "Termianl"); 
			lf.lfWeight =FW_NORMAL;
			lf.lfCharSet = ANSI_CHARSET;
			lf.lfPitchAndFamily = FF_SCRIPT;
			
       		lf.lfHeight=24;       		
       		hFont =CreateFontIndirect(&lf);
       		SelectObject(ps.hdc,hFont);
       		
			SetTextColor(ps.hdc,RGB(0,0,0));
			TextOut(ps.hdc,rc.left+20,44,"�ɶ�����",8);
			SetTextColor(ps.hdc,RGB(255,255,255));
			TextOut(ps.hdc,rc.left+20-1,44-1,"�ɶ�����",8);

			SetTextColor(ps.hdc,RGB(0,0,0));
			TextOut(ps.hdc,rc.left+20,84,"��������",8);
			SetTextColor(ps.hdc,RGB(255,255,255));
			TextOut(ps.hdc,rc.left+20-1,84-1,"��������",8);
			
			if(curChkUsrData.zqsid !=0)
			{
				strcpy(tmp,&Qsxx.zqsjc[curChkUsrData.zqsid -1][0]);
				strcat(tmp,"��ӭ��");
			}
			
			SetTextColor(ps.hdc,RGB(0,0,0));
			TextOut(ps.hdc,rc.left+20,rc.top +15,tmp,strlen(tmp));
			SetTextColor(ps.hdc,RGB(255,255,255));
			TextOut(ps.hdc,rc.left+20-1,rc.top +15-1,tmp,strlen(tmp));									
						
			DeleteObject(hFont);
			EndPaint(hDlg, &ps);
		break;

		case WM_TIMER:
			hDC =GetDC(hDlg);
			    
			GetClientRect(hDlg, &rc);
			rc.right =rc.right -40;
			rc.bottom =rc. bottom -15;				
				
			strcpy(tmp,"88");
			dw=GetTextExtent(hDC,tmp,strlen(tmp));
				
			rc.left =rc.right -LOWORD(dw)-12;
			rc.top = rc.bottom -HIWORD(dw);
			        
			SelectObject(hDC,GetStockObject(WHITE_PEN));    
			MoveTo(hDC,rc.left+1,rc.top-1);
			LineTo(hDC,rc.right+1,rc.top-1);
			    
			MoveTo(hDC,rc.left-1,rc.top+1);				
			LineTo(hDC,rc.left-1,rc.bottom+1);			    
				
			SelectObject(hDC,GetStockObject(BLACK_PEN));    
			MoveTo(hDC,rc.right+1,rc.top+1);
			LineTo(hDC,rc.right+1,rc.bottom+1);
			    
			MoveTo(hDC,rc.left+1,rc.bottom+1);
			LineTo(hDC,rc.right+1,rc.bottom+1);			    
			    				
			wsprintf(tmp,"%d",MAX_JY_WAIT_TIME-gnTimers);
			if(MAX_JY_WAIT_TIME-gnTimers<10)
			{
			    tmp[1]=tmp[0];
			    tmp[0]='0';
			}
			    
			SetBkColor(hDC,RGB(255,0,255));
			SetTextColor(hDC,RGB(255,255,0));
			    
			dw=GetTextExtent(hDC,tmp,strlen(tmp));
			    
			ExtTextOut(hDC,(int)(rc.right-rc.left-LOWORD(dw))/2+rc.left, rc.top, ETO_CLIPPED|ETO_OPAQUE, &rc,tmp , 2, NULL);
			
			ReleaseDC(hDlg, hDC);
		
			if(gnTimers++ >=MAX_JY_WAIT_TIME)
			{
				SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
				break;
			}

		break;
		
		case WM_COMMAND:
			gnTimers =0;
			switch(wParam)
			{
				case IDOK:
					hctl =GetFocus();
					idFocus =GetWindowWord(hctl, GWW_ID);
					if(idFocus ==IDCANCEL)
					{
						SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
						break;
					}
					hctl =GetDlgItem(hDlg, IDC_INPUT);
					if(curChkUsrData.gddm[0] ==0)
					{
						GetDlgItemText(hDlg, IDC_INPUT, curChkUsrData.gddm, sizeof(curChkUsrData.gddm));
						if(curChkUsrData.gddm[0] !=0)
						{
							hctl =GetDlgItem(hDlg, IDC_INPUT1);
							SetFocus(hctl);
						}
						break;
					}
					GetDlgItemText(hDlg, IDC_INPUT1, curChkUsrData.jymm, sizeof(curChkUsrData.jymm));
					if(curChkUsrData.jymm[0] ==0)
						break;
						
					EnableWindow(hDlg, FALSE);	
					
					hctl =GetDlgItem(hDlg, IDOK);
					SetFocus(hctl);
					
					if(gfTest)
						SendMessage(hDlg,WM_JY_RES,0,0L);
					else
					{
						SetTimer(hDlg, 1, 1000, NULL);
						ret =UDP_Jy_ChkUsr(&curChkUsrData, &curChkUsrRes);
						if(ret <0)
						{
							ErrMsg(hDlg, "Failed send data");
							SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
						}
					}
				break;
				case IDCANCEL:
					KillTimer(hDlg, 1);
					if(curChkUsrData.jymm[0] !=0)
						SendJyExit(curChkUsrData.gddm);
					udpread_stop =TRUE;
					ghDlgJy =NULL;
					DeleteObject(hBrush);
					EndDialog(hDlg, 1);
				break;
			}
		break;
		case WM_JY_RES:
			if(gfTest)
			{
				curChkUsrRes.userId =1;
				curChkUsrRes.flag=ret =ANS_SUCC;
			}
			else
				ret =curChkUsrRes.flag;
			if(ret!=ANS_SUCC)
			{
				curChkUsrRes.userId=0;
				switch(ret)
				{
				    case '1':
						strcpy(tmp,"����ע�⣬�޴˹ɶ����룡");
						break;
				    case '2':
						strcpy(tmp,"����ע�⣬���ѱ�ɾ����");
						break;
					case '3':
						strcpy(tmp,"����ע�⣬���ѹ�ʧ��");
						break;
					case '4':
						strcpy(tmp,"����ע�⣬���ѱ����ᣡ");
						break;
				    case '5':
						strcpy(tmp,"����ע�⣬û����������");
						break;
				    case '6':
						strcpy(tmp,"�ɶ������뽻�����벻����");
						break;
            		case ANS_SYS_ERR:
            			strcpy(tmp,"����ע�⣬����ϵͳ����");
            			break;
            		case ANS_SUSP_REQ:
            			strcpy(tmp,"�������ڴ��������ϴ�����");
            			break;
            		case ANS_NO_PRIV:
            			strcpy(tmp,"��û��Ȩ�޽���������");	
            			break;						
                    default:
                    	strcpy(tmp,"����ע�⣬δ֪����");
                }    	
				MessageBox(ghDlgJy, tmp,"�û�����", MB_OK);				
			}
			KillTimer(hDlg, 1);
			ghDlgJy =NULL;
			EndDialog(hDlg, 1);
		break;
	}
	return FALSE;
}


LRESULT CALLBACK JyDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	LPDRAWITEMSTRUCT lpdis;
	HWND hctl;
	int x,i,Width,gap;
	RECT rc;
    static HBRUSH hBrush;
	int GpFunc[8]={IDC_JY_BUY,IDC_JY_SELL,IDC_JY_CANCEL,IDC_JY_CJCX,IDC_JY_WTCX,
		IDC_JY_YECX,IDC_JY_CHGPWD,IDC_EXIT};
	
	
	switch(msg)
	{
		case WM_INITDIALOG:
			gnTimers =0;
			x =GetSystemMetrics(SM_CXSCREEN);
			GetWindowRect(ghWndStatus,&rc);
			SetWindowPos(hDlg,(HWND)HWND_TOP,0,rc.top,
				x , rc.bottom-rc.top,SWP_NOZORDER);
			
			gap =4;
			Width =(x-gap*9)/8;
			for(i=0;i<8;i++)
			{
				hctl =GetDlgItem(hDlg,GpFunc[i]);
				SetWindowPos(hctl,(HWND)NULL,(Width+gap)*i +gap,3,Width,
					rc.bottom-rc.top-8,SWP_NOZORDER);
			}
			hBrush=CreateSolidBrush(RGB(0,255,255));            
			SetTimer(hDlg, 1, 500, NULL);
		return TRUE;

		case WM_CTLCOLOR:
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_DLG:
					return (LRESULT)hBrush;
				case CTLCOLOR_MSGBOX:
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
			}
			//SetBkMode((HDC)wParam, TRANSPARENT);
		return (LRESULT)NULL;
		
		case WM_DRAWITEM:
			lpdis = (LPDRAWITEMSTRUCT)lParam;

			if (lpdis->itemID == -1)
				BtnFocusState(lpdis);
			else
			{
				switch (lpdis->itemAction)
				{
					case ODA_DRAWENTIRE: 
						BtnDrawEntireItem(lpdis);
					break;

					case ODA_SELECT:
						BtnSelectionState(lpdis);
					break;

					case ODA_FOCUS:
						BtnFocusState(lpdis);
					break;
				}
			}
		break;
		
		case WM_TIMER:
			if(gnTimers+10>MAX_IDEL_TIME*2)
			{  
			    if(gnTimers*(int)(gnTimers/2)==gnTimers)
			    {
					DrawTime(-3);
					MessageBeep(0);
				}	
				else
					DrawTime(-2);				
			}
			if(gnTimers++ >MAX_IDEL_TIME*2)
			{
				curChkUsrRes.flag =-1;
				gnTimers =0; 
				curChkUsrRes.userId=0;
				SendMessage(hDlg, WM_COMMAND, IDC_EXIT, 0L);
			}
		break;
		case WM_PAINT:
			BeginPaint(hDlg, &ps);
			DrawFrame(ps.hdc, hDlg);
			EndPaint(hDlg, &ps);
		break;
		case WM_COMMAND:
			gnTimers =0;
			switch(wParam)
			{
				case IDC_JY_BUY:
					JyFunc = BUY_FUNC;
				break;
				case IDC_JY_SELL:
					JyFunc = SELL_FUNC;
				break;
				case IDC_JY_CANCEL:
					JyFunc = CANCEL_FUNC;
				break;
				case IDC_JY_CJCX:
					JyFunc =CJCX_FUNC;
				break;
				case IDC_JY_WTCX:
					JyFunc = WTCX_FUNC;
				break;
				case IDC_JY_YECX:
					JyFunc = YECX_FUNC;
				break;
				case IDC_JY_CHGPWD:
					JyFunc =CHGPWD_FUNC;
				break;
				case IDOK:
					hctl =GetFocus();
					SendMessage(hDlg, WM_COMMAND, GetWindowWord(hctl, GWW_ID), 0L);
				break;
				case IDC_EXIT:
					JyFunc =EXIT_FUNC;
				case IDCANCEL:
					KillTimer(hDlg, 1);
					DeleteObject(hBrush);
					if(JyFunc!=EXIT_FUNC)
						JyFunc = NULL_FUNC;
				break;
				default:
				return FALSE;
			}  
			EndDialog(hDlg, 0);
		break;
	}
	
	return FALSE;
}

LRESULT CALLBACK AskPwdDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	static JY_ASK_CHGPWD ChgPwdData;
	static JY_ANS_CHGPWD ChgPwdRes;
	PAINTSTRUCT ps;
	static int state =0;
	char tmp[60];
	HWND hctl;
	static HBRUSH hBrush;
	
	switch(msg)
	{
		case WM_INITDIALOG:
			ghDlgJy =hDlg;
			SendDlgItemMessage(hDlg, IDC_OLDPWD, EM_LIMITTEXT, MAX_JYMM_SIZE, 0L);
			CenterWindow(hDlg);
			//ChgPwdData.newPwd[0] =0;
			hBrush=CreateSolidBrush(RGB(0,255,255));			
			IsCanPwdChg =FALSE;
		return TRUE;

		case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_DLG:
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_EDIT:
					return (LRESULT)hBrush;
			}
		return TRUE;

		case WM_PAINT:
			BeginPaint(hDlg, &ps);
			DrawFrame(ps.hdc, hDlg);
			EndPaint(hDlg, &ps);
		break;
		
		case WM_COMMAND:
			gnTimers =0;
			switch(wParam)
			{
				case IDOK:
					hctl =GetDlgItem(hDlg, IDC_OLDPWD);
					SetFocus(hctl);
					GetDlgItemText(hDlg, IDC_OLDPWD, tmp, sizeof(tmp));
					//if(tmp[0] ==0)
					//	break;
					if(strcmp(tmp,curChkUsrData.jymm)==0)
					{
						IsCanPwdChg =TRUE;
						EndDialog(hDlg, 0);
						ghDlgJy =NULL;					
					}
					else
					{   
					    ErrMsg(hDlg, "����������������޸����룡");
						IsCanPwdChg =FALSE;
						EndDialog(hDlg, 0);
						ghDlgJy =NULL;					
					}
				break;
				case IDCANCEL:
					IsCanPwdChg =FALSE;
					EndDialog(hDlg, 0);
					ghDlgJy =NULL;
				break;
			}
		break;
	}
	
	return FALSE;
}

LRESULT CALLBACK ChgPwdDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	static JY_ASK_CHGPWD ChgPwdData;
	static JY_ANS_CHGPWD ChgPwdRes;
	PAINTSTRUCT ps;
	static int state =0;
	char tmp[60];
	HWND hctl;
	static HBRUSH hBrush;
	int ret;
	
	switch(msg)
	{
		case WM_INITDIALOG:
			ghDlgJy =hDlg;
			memset(&ChgPwdData, 0, sizeof(ChgPwdData));
			memset(&ChgPwdRes, 0, sizeof(ChgPwdRes));
			ChgPwdData.jys =curChkUsrRes.jys;
			ChgPwdData.userId =curChkUsrRes.userId;
			strcpy(ChgPwdData.gddm, curChkUsrRes.gddm);
			state =0;
			gnTimers =0;
			SendDlgItemMessage(hDlg, IDC_NEWPWD, EM_LIMITTEXT, MAX_JYMM_SIZE, 0L);
			CenterWindow(hDlg);
			ChgPwdData.newPwd[0] =0;
			hBrush=CreateSolidBrush(RGB(0,255,255));			
			SetTimer(hDlg, 1, 1000, NULL);
		return TRUE;

		case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_DLG:
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_EDIT:
					return (LRESULT)hBrush;
			}
		return TRUE;

		case WM_PAINT:
			BeginPaint(hDlg, &ps);
			DrawFrame(ps.hdc, hDlg);
			EndPaint(hDlg, &ps);
		break;

		case WM_TIMER:
			if(gnTimers ++>60)
				SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
		
		case WM_COMMAND:
			gnTimers =0;
			switch(wParam)
			{
				case IDOK:
					if(state >=2) break;
					//if(ChgPwdData.newPwd[0] !=0) break;
					hctl =GetDlgItem(hDlg, IDC_NEWPWD);
					SetFocus(hctl);
					GetDlgItemText(hDlg, IDC_NEWPWD, tmp, sizeof(tmp));
					if(state ==0)
					{
						if(tmp[0] ==0)
							break;
						strcpy(ChgPwdData.newPwd, tmp);
						SetDlgItemText(hDlg, IDC_COMMENT, "����һ��");
						SetDlgItemText(hDlg, IDC_NEWPWD, "");
						state =1;
						break;
					}
					if(strcmp(ChgPwdData.newPwd, tmp))
					{
						ErrMsg(hDlg, "��������Ҫ��ͬ!\n����������");
						SetDlgItemText(hDlg, IDC_COMMENT, "������");
						SetDlgItemText(hDlg, IDC_NEWPWD, "");
						state =0;
						break;
					}
					state =2;
					UDP_Jy_ChgPwd(&ChgPwdData, &ChgPwdRes);
				break;
				case IDCANCEL:
					udpread_stop =TRUE;
					KillTimer(hDlg, 1);
					EndDialog(hDlg, 0);
					ghDlgJy =NULL;
				break;
			}
		break;
		case WM_JY_RES:
			ret=ChgPwdRes.flag;
			if(ret!=ANS_SUCC)
			{
				switch(ret)
				{
				    case '1':
						strcpy(tmp,"����ע�⣬�޴˹ɶ����룡");
						break;
				    case '2':
						strcpy(tmp,"����ע�⣬���ѱ�ɾ����");
						break;
					case '3':
						strcpy(tmp,"����ע�⣬���ѹ�ʧ��");
						break;
					case '4':
						strcpy(tmp,"����ע�⣬���ѱ����ᣡ");
						break;
				    case '5':
						strcpy(tmp,"����ע�⣬û����������");
						break;
				    case '6':
						strcpy(tmp,"�ɶ������뽻�����벻����");
						break;
            		case ANS_SYS_ERR:
            			strcpy(tmp,"����ע�⣬����ϵͳ����");
            			break;
            		case ANS_SUSP_REQ:
            			strcpy(tmp,"�������ڴ��������ϴ�����");
            			break;
            		case ANS_NO_PRIV:
            			strcpy(tmp,"��û��Ȩ�޽���������");	
            			break;						
                    default:
                    	strcpy(tmp,"����ע�⣬δ֪����");
                }
			}
			else
			{
				strcpy(tmp,"�����������޸ģ�");
			}
			MessageBox(ghDlgJy, tmp,"�޸�����", MB_OK);
			KillTimer(hDlg, 1);
			ghDlgJy =NULL;
			DeleteObject(hBrush);
			EndDialog(hDlg, 0);
		break;
	}
	
	return FALSE;
}

LRESULT CALLBACK BuySellDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	static JY_ASK_BUYSELL BuySellData;
	static JY_ANS_BUYSELL BuySellRes;
	int i, k,ret;
	DWORD dw;
	char tmp[100], tmp1[100];
	PAINTSTRUCT ps;
	HWND hctl;
	LPDRAWITEMSTRUCT lpdis;
	static int state =0;
	int idFocus;
	static HBRUSH hBuyBrush,hSellBrush;
	RECT rc;
	HDC hdc;
					
	switch(msg)
	{
		case WM_INITDIALOG:
			gnTimers =0;
			ghDlgJy =hDlg;
			memset(&BuySellData, 0, sizeof(BuySellData));
			memset(&BuySellRes, 0, sizeof(BuySellRes));
			BuySellData.jys =curChkUsrRes.jys;
			strcpy(BuySellData.gddm, curChkUsrRes.gddm);
			
			if(BuySellData.jys==0)
				strcpy(tmp,"����A��");
			if(BuySellData.jys==1)	
				strcpy(tmp,"�Ϻ�A��");			
				
			BuySellData.wtgs =0;
			BuySellData.wtjg =0;
			BuySellData.bs =(char)lParam;
			BuySellData.userId =curChkUsrRes.userId;
			if(BuySellData.bs =='B')
			{
				SetDlgItemText(hDlg, IDOK, "����");
				strcat(tmp,"��Ʊ����");
			}	
			else
			{ 
				SetDlgItemText(hDlg, IDOK, "����");	
				strcat(tmp,"��Ʊ����");
			}                             
			SetWindowText(hDlg,tmp);                             
			
			SendDlgItemMessage(hDlg, IDC_ZQDM, CB_LIMITTEXT, MAX_ZQDM_SIZE, 0L);
			SendDlgItemMessage(hDlg, IDC_JG, EM_LIMITTEXT, 7, 0L);
			SendDlgItemMessage(hDlg, IDC_SL, EM_LIMITTEXT, 8, 0L);

			i =HqPaintData.sortData.key[HqPaintData.curRecNum+HqPaintData.curSelRec];
			strcpy(tmp, HqData[HqPaintData.jys].lpPreData[i].zqmc);
			k =-1;
			for(i =0; i<HqData[BuySellData.jys].recCount; i++)
			{     
				//if(!IsZsRec(BuySellData.jys, i))
				//{
					SendDlgItemMessage(hDlg, IDC_ZQDM, CB_ADDSTRING,
						0, (LPARAM)(LPSTR)HqData[BuySellData.jys].lpPreData[i].zqmc);
					if(!strcmp(tmp, HqData[BuySellData.jys].lpPreData[i].zqmc))
						k =i;
				//}
			}
			SendDlgItemMessage(hDlg, IDC_ZQDM, CB_SETCURSEL, k, 0L);
			gnTimers =0;
			state =0;
			SetTimer(hDlg, 1, 1000, NULL);
			
			hBuyBrush=CreateSolidBrush(RGB(255,0,255));
			hSellBrush=CreateSolidBrush(RGB(0,255,255));
			
			SetDlgItemText(hDlg,IDC_STATIC,"֤ȯ����");
			SetDlgItemText(hDlg,IDC_STATIC2,"ί������");
			SetDlgItemText(hDlg,IDC_STATIC1,"ί�м۸�");
						
			CenterWindow(hDlg);
		return TRUE;

		case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_STATIC:			
				case CTLCOLOR_DLG:  
					if(BuySellData.bs =='B')
						return (LRESULT)hBuyBrush;
					else
						return (LRESULT)hSellBrush;						
				case CTLCOLOR_MSGBOX:
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_LISTBOX:
				case CTLCOLOR_EDIT:	
					return (LRESULT)(HBRUSH)NULL;					
			}
		return (LRESULT)NULL;

		case WM_DRAWITEM:
			lpdis = (LPDRAWITEMSTRUCT)lParam;

			if (lpdis->itemID == -1)
				BtnFocusState(lpdis);
			else
			{
				switch (lpdis->itemAction)
				{
					case ODA_DRAWENTIRE: 
						BtnDrawEntireItem(lpdis);
					break;

					case ODA_SELECT:
						BtnSelectionState(lpdis);
					break;

					case ODA_FOCUS:
						BtnFocusState(lpdis);
					break;
				}
			}
		break;
		
		case WM_PAINT:
			BeginPaint(hDlg, &ps);
			DrawFrame(ps.hdc, hDlg);
			EndPaint(hDlg, &ps);
		break;

		case WM_TIMER:
			if(gnTimers++ >300)
				SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
		
		case WM_COMMAND:
			gnTimers =0;
			switch(wParam)
			{
				case IDOK:
					hctl =GetFocus();
					idFocus =GetWindowWord(hctl, GWW_ID);
					if(idFocus ==IDCANCEL)
					{
						SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
						break;
					}
					//if(BuySellData.wtgs !=0 && BuySellData.wtjg !=0) break;
					GetDlgItemText(hDlg, IDC_ZQDM, tmp, sizeof(tmp));
					hctl =GetDlgItem(hDlg, IDC_ZQDM);
					if(tmp[0] ==0)
					{
						SetFocus(hctl);
						break;
					}
					for(i =0; i<HqData[BuySellData.jys].recCount; i++)
						if(!strcmp(HqData[BuySellData.jys].lpPreData[i].zqdm, tmp))
							break;
					if(i < HqData[BuySellData.jys].recCount)
					{
						SendDlgItemMessage(hDlg, IDC_ZQDM, CB_SETCURSEL, i, 0L);
						strcpy(BuySellData.gpdm, HqData[BuySellData.jys].lpPreData[i].zqdm);
					}
					else
					{
						dw =SendDlgItemMessage(hDlg, IDC_ZQDM, CB_GETCURSEL, 0, 0L);
						if(dw ==CB_ERR)
						{
							SetDlgItemText(hDlg, IDC_ZQDM, "");
							SetFocus(hctl);
							break;
						}
						i =(int)dw;
						SendDlgItemMessage(hDlg, IDC_ZQDM, CB_GETLBTEXT, i, (LPARAM)(LPSTR)tmp1);
						if(!strcmp(tmp1, tmp))
							strcpy(BuySellData.gpdm, HqData[BuySellData.jys].lpPreData[i].zqdm);
						else
						{
							SetDlgItemText(hDlg, IDC_ZQDM, "");
							SetFocus(hctl);
							break;
						}
					}	
					
					//if(state ==1) goto ACCEPT;
										
					//GetDlgItemText(hDlg, IDC_JG, tmp, sizeof(tmp));
					hctl =GetDlgItem(hDlg, IDC_JG);
					SetFocus(hctl);

					if(idFocus !=IDOK && idFocus !=IDC_JG
							&& idFocus !=IDC_SL)
					{
						if(IsWindowVisible(ghWndHq))
						{
							for(k =0; k<HqPaintData.recCount; k++)
							{
								if(IsZsRec(HqPaintData.jys, k))
								{
									i++;
									continue;
								}
								if(HqPaintData.sortData.key[k] ==i)
									break;
							}
							if(k <HqPaintData.recCount)
							{
								HqPaintData.curSelRec =0;
								HqPaintData.curRecNum =k;
								SendMessage(ghWndHq, WM_COMMAND, IDM_GRAPH, 0L);
							}
						}
						if(!IsWindowVisible(ghWndHq))
						{
							if(tmp[0]<'0'||tmp[0]>'9')
							{    
								if(i<HqData[BuySellData.jys].recCount&&i>0)
									strcpy(tmp,HqData[BuySellData.jys].lpPreData[i].zqdm);
							}	
							SetWindowText(hWndInput, &tmp[0]);													
							if(tmp[0]!=0)
							{
								SendMessage(ghWndXlt, WM_KEYDOWN, VK_RETURN, 0L);
								InvalidateRect(ghWndXlt, NULL, TRUE);
								InvalidateRect(ghWndJlt, NULL, TRUE);
								InvalidateRect(ghWndMmp, NULL, TRUE);
								InvalidateRect(ghWndLitHq, NULL, TRUE);
								InvalidateRect(ghWndCj, NULL, TRUE);
							}	
						}
						break;
					}

					if(state ==1) goto ACCEPT;
					GetDlgItemText(hDlg, IDC_JG, tmp, sizeof(tmp));
					
					if(tmp[0] ==0)
					{
						SetFocus(hctl);
						break;
					}
					else
					{
						k =strlen(tmp);
						for(i =0; i<k; i++)
						{
							if(!isdigit(tmp[i]) && tmp[i] !='.')
							{
								SetDlgItemText(hDlg, IDC_JG, "");
								SetFocus(hctl);
								return FALSE;
							}
						}
					}
					BuySellData.wtjg =(long)(_atold(tmp)*100);
					
					hctl =GetDlgItem(hDlg, IDC_SL);
					SetFocus(hctl);
					if(idFocus ==IDC_JG) break;

					GetDlgItemText(hDlg, IDC_SL, tmp, sizeof(tmp));
					if(tmp[0] ==0)
					{
						SetFocus(hctl);
						break;
					}
					else
					{
						k =strlen(tmp);
						/*
						if(k >8)
						{
							tmp[8] =0;
							SetDlgItemText(hDlg, IDC_SL, tmp);
							SendDlgItemMessage(hDlg, IDC_SL, EM_SETSEL, 0, MAKELONG(0, -1));
							SetFocus(hctl);
							break;
						}
						*/
						for(i =0; i<k; i++)
						{
							if(!isdigit(tmp[i]))
							{
								SetDlgItemText(hDlg, IDC_SL, "");
								//SetFocus(hctl);
								return FALSE;
							}
						}
					}
					BuySellData.wtgs =atol(tmp);
			ACCEPT:
					if(state==0)					
						state =1;
					else
						state++;	
					hctl =GetDlgItem(hDlg, IDOK);
					SetFocus(hctl);

					if(state ==2)
					{    
						state =0;
						
						GetClientRect(hDlg, &rc);
						EnableWindow(hDlg, FALSE);						
						k=UDP_Jy_BuySell(&BuySellData, &BuySellRes);
						hdc =GetDC(hDlg);
						SetBkColor(hdc,RGB(255,0,0));
						SelectObject(hdc,GetStockObject(WHITE_PEN));
						if(k>0)
							strcpy(&tmp[0],"����ί���Ѵ�������������ȴ�");
						if(k==0)
						    strcpy(&tmp[0],"�Ѿ�����,����ί��");
						if(k<0)
						    strcpy(&tmp[0],"����ί��δ����������,����ͨѶ���");
						TextOut(hdc,rc.left +10,rc.bottom -20,tmp,strlen(tmp));
						ReleaseDC(hDlg,hdc);
					}	
				break;
				case IDCANCEL:
					udpread_stop =TRUE;
					KillTimer(hDlg, 1);
					ghDlgJy =NULL;
					DeleteObject(hBuyBrush);
					DeleteObject(hSellBrush);					
					EndDialog(hDlg, 0);
				break;
			}
		break;
		case WM_JY_RES:
			ret=BuySellRes.flag;
			if(ret!=ANS_SUCC)
			{
				switch(ret)
				{
				    case '1':
						strcpy(tmp,"����ע�⣬��Ʊ�������");
						break;
				    case '2':
						strcpy(tmp,"�ɶ�������ʽ��ʺŴ���");
						break;
					case '3':
						strcpy(tmp,"����ע�⣬ί�м۸����");
						break;
					case '4':
						strcpy(tmp,"����ע�⣬ί�й�������");
						break;
				    case '5':
						strcpy(tmp,"�����������ֹ�����");
						break;
				    case '6':
						strcpy(tmp,"ί�й����������ޣ�");
						break;
					case '7':
						strcpy(tmp,"����ע�⣬�ʽ��㣡");
						break;						
					case '8':
						strcpy(tmp,"ϵͳ�޷�������ͬ���룡");
					case '9':
						strcpy(tmp,"����ע�⣬�������գ�");						
						break;
					case 'A':
						strcpy(tmp,"����ע�⣬���ѳ�ʱ��");
						break;
					case 'I':
						strcpy(tmp,"������ͬ�ɶ����������������ϵͳ��");
						break;
            		case ANS_SYS_ERR:
            			strcpy(tmp,"����ע�⣬����ϵͳ����");
            			break;
            		case ANS_SUSP_REQ:
            			strcpy(tmp,"�������ڴ��������ϴ�����");
            			break;
            		case ANS_NO_PRIV:
            			strcpy(tmp,"��û��Ȩ�޽���������");	
            			break;						
                    default:
                    	strcpy(tmp,"����ע�⣬δ֪����");
                }
               	MessageBox(ghDlgJy, tmp,"��Ʊ����", MB_OK);
			}
			else
			{
				wsprintf(tmp, "ί���ѽ������ϵͳ! ��ͬ������%s", BuySellRes.hthm);
				MessageBox(hDlg, tmp, "��Ʊ����", MB_OK);
			
			}
			
			hdc =GetDC(hDlg);
			GetClientRect(hDlg, &rc);			
			SetBkColor(hdc,RGB(255,0,0));
			SelectObject(hdc,GetStockObject(WHITE_PEN));
			strcpy(&tmp[0],"��ӭ������ί��...                         ");
			
			TextOut(hdc,rc.left +10,rc.bottom -20,tmp,strlen(tmp));
			ReleaseDC(hDlg,hdc);

			SendDlgItemMessage(hDlg, IDC_JG, EM_SETSEL, 0, MAKELONG(0,-1));
			SendDlgItemMessage(hDlg, IDC_JG, WM_CLEAR, 0, 0);
			
			SendDlgItemMessage(hDlg, IDC_SL, EM_SETSEL, 0, MAKELONG(0,-1));			
			SendDlgItemMessage(hDlg, IDC_SL, WM_CLEAR, 0, 0);

			gnTimers =0;
			state =0;
			EnableWindow(hDlg, TRUE);
		break;
	}
	
	return FALSE;
}

LRESULT CALLBACK CancelDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	static JY_ASK_CANCEL CancelData;
	static JY_ANS_CANCEL CancelRes;
	static JY_ASK_WTCX WtcxData;
	static JY_ANS_WTCX WtcxRes;
	PAINTSTRUCT ps;
	int i, j, k;
	DWORD dw;
	HWND hctl;
	static int sel_num[MAX_CANCEL_SENDCOUNT];
	char tmp[256],gpmc[9];
	LPSTR lpTmp;
	static int state;
	int idFocus,ret;
	static BOOL fFirst =TRUE;
	static  hBrush;
	LPDRAWITEMSTRUCT lpdis;
	LPMEASUREITEMSTRUCT lpmis;
	TEXTMETRIC tm;
	HWND hDC;
				
	switch(msg)
	{
		case WM_INITDIALOG:
			ghDlgJy =hDlg;
			memset(&CancelData, 0, sizeof(CancelData));
			memset(&CancelRes, 0, sizeof(CancelRes));
			memset(&WtcxData, 0, sizeof(WtcxData));
			memset(&WtcxRes, 0, sizeof(WtcxRes));
			CancelData.jys =curChkUsrRes.jys;
			CancelData.cancelCount =0;
			CancelData.userId =curChkUsrRes.userId;
			strcpy(CancelData.gddm, curChkUsrRes.gddm);
			WtcxData.jys =curChkUsrRes.jys;
			WtcxData.userId =curChkUsrRes.userId;
			WtcxData.cdcx='Y';
			strcpy(WtcxData.gddm, curChkUsrRes.gddm);
			
			hBrush=CreateSolidBrush(RGB(0,255,255));
			
			if(curChkUsrRes.jys==0)
				strcpy(tmp,"����A��");
			if(curChkUsrRes.jys==1)	
				strcpy(tmp,"�Ϻ�A��");			
			
			strcat(tmp,"����ί��");
			SetWindowText(hDlg,tmp);
							
			PostMessage(hDlg, WM_JY_INIT, 0, 0L);
			state =0;
			fFirst =TRUE;
			gnTimers =0;
			SetTimer(hDlg,1, 1000, NULL);
			CenterWindow(hDlg);
			
		return TRUE;
		
		case WM_JY_INIT:
			SendDlgItemMessage(hDlg, IDL_CX, LB_ADDSTRING, 0,
						(LPARAM)(LPSTR)"���ڲ�ѯί��...");
			gnTimers =0;
			if(gfTest)
			    SendMessage(hDlg,WM_JYCX_RES,0,0L);
			else
				UDP_Jy_Wtcx(&WtcxData, &WtcxRes);
		break;
		
		case WM_JYCX_RES:
			if(fFirst)
			{
				SendDlgItemMessage(hDlg, IDL_CX, LB_RESETCONTENT, 0, 0L);
				fFirst =FALSE;
			}
			if(gfTest)
			{
            	ret=WtcxRes.flag=ANS_SUCC;
            	WtcxRes.recCount=5;
            	for(i=0;i<WtcxRes.recCount;i++)
            	{
            		sprintf(WtcxRes.Wt[i].hthm,"%d",i+112);
            		strcpy(WtcxRes.Wt[i].wtsj,"091012");
            		WtcxRes.Wt[i].mmbz='S';
					if(curChkUsrRes.jys==0)
						sprintf(WtcxRes.Wt[i].gpdm ,"%04d",1+i);
					else
						sprintf(WtcxRes.Wt[i].gpdm ,"%06ld",(long)(600600+i));
            		sprintf(WtcxRes.Wt[i].wtgs,"%d",i*100+50);
            		sprintf(WtcxRes.Wt[i].wtjg,"%.2f",4.23*i+12.29);
            	}			
			}
			else
			{
				if(WtcxRes.flag !=ANS_SUCC&&WtcxRes.recCount>0)
				{
					MessageBox(hDlg,"ί�в�ѯʧ�ܣ�", "����", MB_OK);				
					break;
				} 
				if(WtcxRes.recCount ==0)
				{
					MessageBox(hDlg,"û�п��Գ���ί�еĺ�ͬ��", "����", MB_OK);							
					break;
				}
			}
			memset(&tmp[0], 0, sizeof(tmp));
			for(i =0,j=0; i<WtcxRes.recCount; i++)
			{
				lpTmp =&WtcxRes.Wt[i].wtgs[0];
				while(*lpTmp !=0 && *lpTmp !='-') lpTmp++;
				if(*lpTmp =='-')
				{
					sel_num[j] =i;
					j++;
					continue;
				}
			}
			k =j;
			for(i =0; i<WtcxRes.recCount; i++)
			{
				lpTmp =&WtcxRes.Wt[i].wtgs[0];
				while(*lpTmp !=0 && *lpTmp !='-') lpTmp++;
				if(*lpTmp =='-') continue;
				for(j =0; j<k; j++)
				{
					if(i ==sel_num[j]
						|| !strcmp(WtcxRes.Wt[i].hthm, WtcxRes.Wt[sel_num[j]].hthm))
						break;
				}
				if(j !=k) continue;
				
				for(j=0;j<HqData[curChkUsrRes.jys].recCount;j++)
				{
					if(strncmp(HqData[curChkUsrRes.jys].lpPreData[j].zqdm,
						WtcxRes.Wt[i].gpdm,strlen(HqData[curChkUsrRes.jys].lpPreData[j].zqdm))==0)
					break;
				}
				if(j<HqData[curChkUsrRes.jys].recCount)
				{
					strncpy(gpmc,HqData[curChkUsrRes.jys].lpPreData[j].zqmc,8);
					gpmc[8]=0;
				}
				else
					strcpy(gpmc,WtcxRes.Wt[i].gpdm);
				
				sprintf(tmp, "%06s  %8s  %4s  %8s %8s  %8s",
							WtcxRes.Wt[i].hthm, WtcxRes.Wt[i].wtsj,
							(WtcxRes.Wt[i].mmbz=='B')?"����":
							((WtcxRes.Wt[i].mmbz=='S')?"����":"����"),
							gpmc, WtcxRes.Wt[i].wtgs,WtcxRes.Wt[i].wtjg);
				SendDlgItemMessage(hDlg, IDL_CX, LB_ADDSTRING, 0,
						(LPARAM)(LPSTR)tmp);
			}
		break;

		case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_DLG:
				case CTLCOLOR_STATIC:
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_LISTBOX:
					return (LRESULT)hBrush;
				case CTLCOLOR_MSGBOX:
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
			}
		return (LRESULT)NULL;
		case WM_DRAWITEM:
			lpdis = (LPDRAWITEMSTRUCT)lParam;
			if (lpdis->itemID == -1)
			{
				if(lpdis->CtlType==ODT_BUTTON)
					BtnFocusState(lpdis);
				if(lpdis->CtlType==ODT_LISTBOX)
				{
					DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}
			}
			else
			{
				if(lpdis->itemAction&ODA_DRAWENTIRE)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnDrawEntireItem(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
					{   
						i=lpdis->itemID;
						SendMessage(lpdis->hwndItem,LB_GETTEXT,
							(WPARAM)lpdis->itemID,(LPARAM)(LPSTR)tmp);
						SelectObject(lpdis->hDC,GetStockObject(SYSTEM_FIXED_FONT));	
						TextOut(lpdis->hDC,lpdis->rcItem.left,lpdis->rcItem.top,tmp,strlen(tmp));
					}
					if(lpdis->itemState&ODS_SELECTED)
					{
						if(lpdis->CtlType==ODT_BUTTON)
							BtnSelectionState(lpdis);
						if(lpdis->CtlType==ODT_LISTBOX)
							InvertRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					}
					if(lpdis->itemState&ODA_FOCUS)
					{
						if(lpdis->CtlType==ODT_BUTTON)
							BtnFocusState(lpdis);
						if(lpdis->CtlType==ODT_LISTBOX)
							DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					}
					return TRUE;	
				}
				if(lpdis->itemAction&ODA_SELECT)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnSelectionState(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
						InvertRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}
				if(lpdis->itemAction&ODA_FOCUS)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnFocusState(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
						DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}				
			}
		break;
        case WM_MEASUREITEM:
        	lpmis =(LPMEASUREITEMSTRUCT)(lParam);
        	hDC =GetDC(hDlg);
        	SelectObject(hDC,GetStockObject(SYSTEM_FIXED_FONT));        	
        	GetTextMetrics(hDC,&tm);
        	lpmis->itemHeight =tm.tmHeight;
        	ReleaseDC(hDlg,hDC);
        break;
		
		case WM_PAINT:
			BeginPaint(hDlg, &ps);
			DrawFrame(ps.hdc, hDlg);
			EndPaint(hDlg, &ps);
		break;

		case WM_TIMER:
			if(gnTimers ++>60)
				SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
		
		case WM_COMMAND:
			gnTimers =0;
			switch(wParam)
			{
				case IDOK:
					hctl =GetFocus();
					idFocus =GetWindowWord(hctl, GWW_ID);
					if(idFocus ==IDCANCEL)
					{
						SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
						break;
					}
					if(CancelData.cancelCount !=0) break;
					dw =SendDlgItemMessage(hDlg, IDL_CX, LB_GETSELCOUNT, 0, 0L);
					hctl =GetDlgItem(hDlg, IDL_CX);
					SetFocus(hctl);
					if(dw ==LB_ERR)
						break;
					if((int)dw >MAX_CANCEL_SENDCOUNT-1)
					{
						wsprintf(tmp, "һ�����ѡ��%d��", (int)MAX_CANCEL_SENDCOUNT-1);
						ErrMsg(hDlg, tmp);
						break;
					}
					CancelData.cancelCount =(int)dw;
					if(CancelData.cancelCount ==0) break;
					if(SendDlgItemMessage(hDlg, IDL_CX, LB_GETSELITEMS, (int)dw,
								(LPARAM)(int FAR *)sel_num) ==LB_ERR)
						break;
					for(i =0; i<CancelData.cancelCount; i++)
					{
						if(SendDlgItemMessage(hDlg, IDL_CX, LB_GETTEXT, sel_num[i],
								(LPARAM)(LPSTR)tmp) ==LB_ERR)
							break;
						else
						    strncpy(CancelData.Cancel[i].hthm,tmp,MAX_HTHM_SIZE);
					}
					hctl =GetFocus();
					i =GetWindowWord(hctl, GWW_ID);
					if(i ==IDCANCEL)
					{
						SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
						break;
					}
					EnableWindow((HWND)LOWORD(lParam), FALSE);
					memset(&CancelRes.flag, ANS_UNKOWN, sizeof(CancelRes.flag));
					if(gfTest)					
						SendMessage(hDlg,WM_JY_RES ,0,0L);
					else
					{
						if(UDP_Jy_Cancel(&CancelData, &CancelRes) <0)
						{
							ErrMsg(hDlg, "ͨѶ���󣺲��ܽ������͵�����");
							EnableWindow((HWND)LOWORD(lParam), TRUE);
							break;
						}
					}
				break;
				case IDCANCEL:
					udpread_stop =TRUE;
					KillTimer(hDlg, 1);
					ghDlgJy =NULL;     
					DeleteObject(hBrush);
					EndDialog(hDlg, 0);
				break;
			}
		break;
		case WM_JY_RES:
		    if(gfTest)
		    	ret=CancelRes.flag[0]=ANS_SUCC;
			for(i=CancelData.cancelCount-1,j=0; i>=0; i--)
			{
				if(CancelRes.flag[i] ==ANS_SUCC)
				{
					j++;
					SendDlgItemMessage(hDlg, IDL_CX, LB_DELETESTRING, sel_num[i], 0L);
				}
			}
			ret=CancelRes.flag[0];	
			if(j>0&&ret==ANS_SUCC)
				wsprintf(tmp, "���ĳ����ѷ���!");
			else
			{
				switch(ret)
				{
				    case '1':
						strcpy(tmp,"����ע�⣬�޴˺�ͬ���룡");
						break;
				    case '2':
						strcpy(tmp,"�޴˹ɶ�������ѹ�ʧ��");
						break;
					case '3':
						strcpy(tmp,"����ע�⣬�޴˽����ʺţ�");
						break;
					case '4':
						strcpy(tmp,"����ע�⣬������������");
						break;
				    case '5':
						strcpy(tmp,"����ע�⣬�ظ���������");
						break;
				    case '6':
						strcpy(tmp,"����ע�⣬�����ʺŴ���");
						break;  
            		case ANS_SYS_ERR:
            			strcpy(tmp,"����ע�⣬����ϵͳ����");
            			break;
            		case ANS_SUSP_REQ:
            			strcpy(tmp,"�������ڴ��������ϴ�����");
            			break;
            		case ANS_NO_PRIV:
            			strcpy(tmp,"��û��Ȩ�޽���������");	
            			break;
                    default:
                    	strcpy(tmp,"����ע�⣬δ֪����");
                  }				
			}
			MessageBox(hDlg, tmp, "����", MB_OK);
			
			hctl =GetDlgItem(hDlg, IDOK);
			CancelData.cancelCount =0;
			EnableWindow(hctl, TRUE);
		break;
		
	}
	
	return FALSE;
}

LRESULT CALLBACK YecxDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	static JY_ASK_YECX YecxData;
	static JY_ANS_YECX YecxRes;
	PAINTSTRUCT ps;
	char tmp[256],gpmc[9];
	static BOOL fFirst =TRUE;
	int i,ret,j;
	static HBRUSH hBrush;
	LPDRAWITEMSTRUCT lpdis;
	LPMEASUREITEMSTRUCT lpmis;
	TEXTMETRIC tm;
	HWND hDC;
	
	switch(msg)
	{
		case WM_INITDIALOG:
			ghDlgJy =hDlg;
			memset(&YecxData, 0, sizeof(YecxData));
			memset(&YecxRes, 0, sizeof(YecxRes));
			fFirst =TRUE;
			YecxData.jys =curChkUsrRes.jys;
			YecxData.userId =curChkUsrRes.userId;
			YecxRes.recCount =0;
			strcpy(YecxData.gddm, curChkUsrRes.gddm);
			
			hBrush=CreateSolidBrush(RGB(0,255,255));			
			if(curChkUsrRes.jys==0)
				strcpy(tmp,"����A��");
			if(curChkUsrRes.jys==1)	
				strcpy(tmp,"�Ϻ�A��");			
			strcat(tmp,"����ѯ");
			SetWindowText(hDlg,tmp);
			
			PostMessage(hDlg, WM_JY_INIT, 0, 0L);
			SetTimer(hDlg, 1, 1000, NULL);
			gnTimers =0;
			CenterWindow(hDlg);
		return TRUE;

		case WM_JY_INIT:
			if(!fFirst) break;
			SendDlgItemMessage(hDlg, IDL_CX, LB_ADDSTRING, 0,
						(LPARAM)(LPSTR)"���ڲ�ѯ...");
			gnTimers =0;
			if(gfTest)
			{
				SendMessage(hDlg, WM_JYCX_RES, 0, 0L);
				YecxRes.kys =8880000.99;
				YecxRes.zjye=YecxRes.kys+100;
			}
			else
			{
				if(UDP_Jy_Yecx(&YecxData, &YecxRes) <0)
				{
					ErrMsg(hDlg, "ͨѶ���󣺲��ܽ������͵�����");
					SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
				}
			}
		break;

		case WM_JYCX_RES:
			gnTimers =0;
			if(fFirst)
			{
				SendDlgItemMessage(hDlg, IDL_CX, LB_RESETCONTENT, 0, 0L);
				fFirst =FALSE;				
			}   
			
			sprintf(tmp, "%.2f", YecxRes.kys);
			SetDlgItemText(hDlg, IDC_KYJE, tmp);
			sprintf(tmp, "%.2f", YecxRes.zjye);
			SetDlgItemText(hDlg, IDC_ZJYE, tmp);
			if(gfTest)
			{
			 	ret =YecxRes.flag=ANS_SUCC;
			 	YecxRes.recCount=5;
			 	for(i=0;i<YecxRes.recCount;i++)
			 	{   
			 		memset(&YecxRes.GpTg[i],0,sizeof(JY_GPTG));
					if(curChkUsrRes.jys==0)
						sprintf(YecxRes.GpTg[i].gpdm ,"%04d",1+i);
					else
						sprintf(YecxRes.GpTg[i].gpdm ,"%06ld",(long)(600600+i));
			 		sprintf(YecxRes.GpTg[i].kys,"%d",100+i);
			 		sprintf(YecxRes.GpTg[i].gpye,"%d",200+i);
			 		sprintf(YecxRes.GpTg[i].ghrq,"%6s","091008");
			 	}
			}
			else			
				ret =YecxRes.flag;
			if(ret!=ANS_SUCC)
			{   
			    if(ret==1)
			    	 strcpy(tmp,"����ע�⣬�޴˹ɶ����룡");
			    else if(ret==2)
			    	 strcpy(tmp,"����͸�ʣ����ܲ�ѯ");
            	else if(ret==ANS_SYS_ERR)
            		strcpy(tmp,"����ע�⣬����ϵͳ����");
            	else if(ret==ANS_SUSP_REQ)
            		strcpy(tmp,"�������ڴ��������ϴ�����");
            	else if(ret==ANS_NO_PRIV)
            		strcpy(tmp,"��û��Ȩ�޽���������");	
            	else
            		strcpy(tmp,"����ע�⣬δ֪ϵͳ����");			    	                            
				MessageBox(hDlg, tmp, "����ѯ", MB_OK);				
			}
			else
			{	
				memset(&tmp[0], 0, sizeof(tmp));
				if(YecxRes.recCount==0)  
				{        
					strcpy(tmp,"û�������й�����");
					SendDlgItemMessage(hDlg, IDL_CX, LB_ADDSTRING, 0,
						(LPARAM)(LPSTR)tmp);				
				}
				else
				{
					for(i =0; i<YecxRes.recCount; i++)
					{
						for(j=0;j<HqData[curChkUsrRes.jys].recCount;j++)
						{
							if(strncmp(HqData[curChkUsrRes.jys].lpPreData[j].zqdm,
								YecxRes.GpTg[i].gpdm,strlen(HqData[curChkUsrRes.jys].lpPreData[j].zqdm))==0)
							break;
						}
						if(j<HqData[curChkUsrRes.jys].recCount)
						{
							strncpy(gpmc,HqData[curChkUsrRes.jys].lpPreData[j].zqmc,8);
							gpmc[8]=0;
						}
						else
					    	strcpy(gpmc,YecxRes.GpTg[i].gpdm);
						sprintf(tmp, "%6s  %8s  %8s  %8s",
							gpmc, YecxRes.GpTg[i].kys,
							YecxRes.GpTg[i].gpye, YecxRes.GpTg[i].ghrq);
						SendDlgItemMessage(hDlg, IDL_CX, LB_ADDSTRING, 0,
						(LPARAM)(LPSTR)tmp);
					}
				}
			}
		break;
		
		case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_DLG:
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_LISTBOX:
					return (LRESULT)hBrush;
			}
		return (LRESULT)TRUE;
		case WM_DRAWITEM:
			lpdis = (LPDRAWITEMSTRUCT)lParam;
			if (lpdis->itemID == -1)
			{
				if(lpdis->CtlType==ODT_BUTTON)
					BtnFocusState(lpdis);
				if(lpdis->CtlType==ODT_LISTBOX)
				{
					DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}
			}
			else
			{
				if(lpdis->itemAction&ODA_DRAWENTIRE)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnDrawEntireItem(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
					{   
						i=lpdis->itemID;
						SendMessage(lpdis->hwndItem,LB_GETTEXT,
							(WPARAM)lpdis->itemID,(LPARAM)(LPSTR)tmp);
						SelectObject(lpdis->hDC,GetStockObject(SYSTEM_FIXED_FONT));	
						TextOut(lpdis->hDC,lpdis->rcItem.left,lpdis->rcItem.top,tmp,strlen(tmp));
					}
					if(lpdis->itemState&ODS_SELECTED)
					{
						if(lpdis->CtlType==ODT_BUTTON)
							BtnSelectionState(lpdis);
						if(lpdis->CtlType==ODT_LISTBOX)
							InvertRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					}
					if(lpdis->itemState&ODA_FOCUS)
					{
						if(lpdis->CtlType==ODT_BUTTON)
							BtnFocusState(lpdis);
						if(lpdis->CtlType==ODT_LISTBOX)
							DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					}
					return TRUE;	
				}
				if(lpdis->itemAction&ODA_SELECT)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnSelectionState(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
						InvertRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}
				if(lpdis->itemAction&ODA_FOCUS)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnFocusState(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
						DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}				
			}
		break;
        case WM_MEASUREITEM:
        	lpmis =(LPMEASUREITEMSTRUCT)(lParam);
        	hDC =GetDC(hDlg);
        	SelectObject(hDC,GetStockObject(SYSTEM_FIXED_FONT));        	
        	GetTextMetrics(hDC,&tm);
        	lpmis->itemHeight =tm.tmHeight;
        	ReleaseDC(hDlg,hDC);
        break;

		case WM_PAINT:
			BeginPaint(hDlg, &ps);
			DrawFrame(ps.hdc, hDlg);
			EndPaint(hDlg, &ps);
		break;

		case WM_TIMER:
			if(gnTimers++>60)
				SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
		
		case WM_COMMAND:
			gnTimers =0;
			switch(wParam)
			{
				case IDCANCEL:
					udpread_stop =TRUE;
					KillTimer(hDlg, 1);
					DeleteObject(hBrush);
					EndDialog(hDlg, 0);
					ghDlgJy =NULL;
				break;
			}
		break;
	}
	
	return FALSE;
}

LRESULT CALLBACK WtcxDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	static JY_ASK_WTCX WtcxData;
	static JY_ANS_WTCX WtcxRes;
	char tmp[256],gpmc[9];
	int i,ret,j;
	PAINTSTRUCT ps;
	LPDRAWITEMSTRUCT lpdis;
	LPMEASUREITEMSTRUCT lpmis;
	TEXTMETRIC tm;
	HWND hDC;
	static BOOL fFirst =TRUE;
	static HBRUSH hBrush;
	
	switch(msg)
	{
		case WM_INITDIALOG:
			ghDlgJy =hDlg;   
			fFirst =TRUE;
			memset(&WtcxData, 0, sizeof(WtcxData));
			memset(&WtcxRes, 0, sizeof(WtcxRes));
			WtcxData.jys =curChkUsrRes.jys;
			WtcxData.userId =curChkUsrRes.userId;
			WtcxRes.recCount =0;
			WtcxData.cdcx='N';
			strcpy(WtcxData.gddm, curChkUsrRes.gddm);
			
			hBrush=CreateSolidBrush(RGB(0,255,255));			
			if(curChkUsrRes.jys==0)
				strcpy(tmp,"����A��");
			if(curChkUsrRes.jys==1)	
				strcpy(tmp,"�Ϻ�A��");			
			
			strcat(tmp,"ί�в�ѯ");
			SetWindowText(hDlg,tmp);
			
			PostMessage(hDlg, WM_JY_INIT, 0, 0L);
			SetTimer(hDlg, 1, 1000, NULL);
			gnTimers =0;
			CenterWindow(hDlg);
		return TRUE;

		case WM_JY_INIT:
			if(!fFirst) break;
			SendDlgItemMessage(hDlg, IDL_CX, LB_ADDSTRING, 0,
					(LPARAM)(LPSTR)"���ڲ�ѯ...");
			gnTimers =0;
			if(gfTest)
				SendMessage(hDlg, WM_JYCX_RES, 0, 0L);
			else
			{
				if(UDP_Jy_Wtcx(&WtcxData, &WtcxRes) <0)
				{
					ErrMsg(hDlg, "ͨѶ���󣺲��ܽ������͵�����");
					SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
				}
			}
		break;
		
		case WM_JYCX_RES:
            gnTimers =0;
            if(gfTest)
            {
            	ret=WtcxRes.flag=ANS_SUCC;
            	WtcxRes.recCount=5;
            	for(i=0;i<WtcxRes.recCount;i++)
            	{
            		sprintf(WtcxRes.Wt[i].hthm,"%d",i+112);
            		strcpy(WtcxRes.Wt[i].wtsj,"091012");
            		WtcxRes.Wt[i].mmbz='S';
					if(curChkUsrRes.jys==0)
						sprintf(WtcxRes.Wt[i].gpdm ,"%04d",1+i);
					else
						sprintf(WtcxRes.Wt[i].gpdm ,"%06ld",(long)(600600+i));
            		sprintf(WtcxRes.Wt[i].wtgs,"%d",i*100+50);
            		sprintf(WtcxRes.Wt[i].wtjg,"%.2f",4.23*i+12.29);
            	}
            }	
            else
				ret=WtcxRes.flag;			
            memset(&tmp[0], 0, sizeof(tmp));
			if(fFirst)
			{
				fFirst =FALSE;
				SendDlgItemMessage(hDlg, IDL_CX, LB_RESETCONTENT, 0, 0L);
			}    
			if(ret!=ANS_SUCC)
			{
            	if(ret==1)
            		strcpy(tmp,"�޴˹ɶ����룡");				
            	else if(ret==ANS_SYS_ERR)
            		strcpy(tmp,"����ϵͳ����");
            	else if(ret==ANS_SUSP_REQ)
            		strcpy(tmp,"�������ڴ��������ϴ�����");
            	else if(ret==ANS_NO_PRIV)
            		strcpy(tmp,"��û��Ȩ�޽���������");	
            	else
            		strcpy(tmp,"δ֪ϵͳ����");

				SendDlgItemMessage(hDlg, IDL_CX, LB_ADDSTRING, 0,
						(LPARAM)(LPSTR)tmp);			 	
			}
			else
            {
				if(WtcxRes.recCount==0)
				{
			 		strcpy(tmp,"û������ί������");
					SendDlgItemMessage(hDlg, IDL_CX, LB_ADDSTRING, 0,
						(LPARAM)(LPSTR)tmp);			 	
				}
				else
				{            
					for(i =0; i<WtcxRes.recCount; i++)
					{
						for(j=0;j<HqData[curChkUsrRes.jys].recCount;j++)
						{
							if(strncmp(HqData[curChkUsrRes.jys].lpPreData[j].zqdm,
								WtcxRes.Wt[i].gpdm,strlen(HqData[curChkUsrRes.jys].lpPreData[j].zqdm))==0)
							break;
						}
						if(j<HqData[curChkUsrRes.jys].recCount)
						{
							strncpy(gpmc,HqData[curChkUsrRes.jys].lpPreData[j].zqmc,8);
							gpmc[8]=0;
						}
						else
					    	strcpy(gpmc,WtcxRes.Wt[i].gpdm);
					
						sprintf(tmp, "%06s  %8s  %4s  %8s  %8s  %8s",
							WtcxRes.Wt[i].hthm, WtcxRes.Wt[i].wtsj,
							(WtcxRes.Wt[i].mmbz=='B')?"����":
							((WtcxRes.Wt[i].mmbz=='S')?"����":"����"),
							gpmc, WtcxRes.Wt[i].wtgs,WtcxRes.Wt[i].wtjg);
						SendDlgItemMessage(hDlg, IDL_CX, LB_ADDSTRING, 0,
							(LPARAM)(LPSTR)tmp);
					}
				}
			}
		break;
		
		case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_DLG: 
				case CTLCOLOR_STATIC:
				    return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_LISTBOX:
					return (LRESULT)hBrush;
			}
		return (LRESULT)(HBRUSH)NULL;
		case WM_DRAWITEM:
			lpdis = (LPDRAWITEMSTRUCT)lParam;
			if (lpdis->itemID == -1)
			{
				if(lpdis->CtlType==ODT_BUTTON)
					BtnFocusState(lpdis);
				if(lpdis->CtlType==ODT_LISTBOX)
				{
					DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}
			}
			else
			{
				if(lpdis->itemAction&ODA_DRAWENTIRE)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnDrawEntireItem(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
					{   
						i=lpdis->itemID;
						SendMessage(lpdis->hwndItem,LB_GETTEXT,
							(WPARAM)lpdis->itemID,(LPARAM)(LPSTR)tmp);
						SelectObject(lpdis->hDC,GetStockObject(SYSTEM_FIXED_FONT));	
						TextOut(lpdis->hDC,lpdis->rcItem.left,lpdis->rcItem.top,tmp,strlen(tmp));
					}
					if(lpdis->itemState&ODS_SELECTED)
					{
						if(lpdis->CtlType==ODT_BUTTON)
							BtnSelectionState(lpdis);
						if(lpdis->CtlType==ODT_LISTBOX)
							InvertRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					}
					if(lpdis->itemState&ODA_FOCUS)
					{
						if(lpdis->CtlType==ODT_BUTTON)
							BtnFocusState(lpdis);
						if(lpdis->CtlType==ODT_LISTBOX)
							DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					}
					return TRUE;	
				}
				if(lpdis->itemAction&ODA_SELECT)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnSelectionState(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
						InvertRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}
				if(lpdis->itemAction&ODA_FOCUS)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnFocusState(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
						DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}				
			}
		break;
        case WM_MEASUREITEM:
        	lpmis =(LPMEASUREITEMSTRUCT)(lParam);
        	hDC =GetDC(hDlg);
        	SelectObject(hDC,GetStockObject(SYSTEM_FIXED_FONT));        	
        	GetTextMetrics(hDC,&tm);
        	lpmis->itemHeight =tm.tmHeight;
        	ReleaseDC(hDlg,hDC);
        break;
		case WM_PAINT:
			BeginPaint(hDlg, &ps);
			DrawFrame(ps.hdc, hDlg);
			EndPaint(hDlg, &ps);
		break;

		case WM_TIMER:
			if(gnTimers ++>60)
				SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
		
		case WM_COMMAND:
			gnTimers =0;
			switch(wParam)
			{
				case IDCANCEL:
					udpread_stop =TRUE;
					KillTimer(hDlg, 1);
					EndDialog(hDlg, 0);
					ghDlgJy =NULL;
				break;
			}
		break;
	}
	
	return FALSE;
}

LRESULT CALLBACK CjcxDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	static JY_ASK_CJCX CjcxData;
	static JY_ANS_CJCX CjcxRes;
	PAINTSTRUCT ps;
	LPDRAWITEMSTRUCT lpdis;
	LPMEASUREITEMSTRUCT lpmis;
	TEXTMETRIC tm;
	static int cWidth =0;
	static BOOL fFirst =TRUE;
	int i,ret,j;
	HDC hDC;
	char tmp[256],gpmc[9];
	static hBrush;
			
	switch(msg)
	{
		case WM_INITDIALOG:
			ghDlgJy =hDlg;
			memset(&CjcxData, 0, sizeof(CjcxData));
			memset(&CjcxRes, 0, sizeof(CjcxRes));
			CjcxData.jys =curChkUsrRes.jys;
			CjcxData.userId =curChkUsrRes.userId;
			strcpy(CjcxData.gddm, curChkUsrRes.gddm);
			fFirst =TRUE;
			hDC =GetDC(hDlg);
			GetTextMetrics(hDC, &tm);
			cWidth =tm.tmAveCharWidth;
			ReleaseDC(hDlg, hDC);
			    
			hBrush=CreateSolidBrush(RGB(0,255,255));			
			if(curChkUsrRes.jys==0)
				strcpy(tmp,"����A��");
			if(curChkUsrRes.jys==1)	
				strcpy(tmp,"�Ϻ�A��");			
			
			strcat(tmp,"�ɽ���ѯ");
			SetWindowText(hDlg,tmp);
			SendDlgItemMessage(hDlg, IDL_CJCX, LB_RESETCONTENT, 0, 0L);
			PostMessage(hDlg, WM_JY_INIT, 0, 0L);
			SetTimer(hDlg, 1, 1000, NULL);
			gnTimers =0;
			CenterWindow(hDlg);
		return TRUE;

		case WM_JY_INIT:
			SendDlgItemMessage(hDlg, IDL_CJCX, LB_ADDSTRING, 0,
					(LPARAM)(LPSTR)"���ڲ�ѯ...");
			gnTimers =0;
			if(gfTest)
				SendMessage(hDlg, WM_JYCX_RES, 0, 0L);
			else
			{
				if(UDP_Jy_Cjcx(&CjcxData, &CjcxRes) <0)
				{
					ErrMsg(hDlg, "ͨѶ���󣺲��ܽ������͵�����");
					SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
				}
			}
		break;
		
		case WM_JYCX_RES:
			gnTimers =0;
			if(gfTest)
			{
				CjcxRes.flag=ret =ANS_SUCC;
				CjcxRes.recCount =5;
				for(i=0;i<5;i++)
				{
					sprintf(CjcxRes.Cj[i].hthm ,"%d",12+i);
					strcpy(CjcxRes.Cj[i].cjsj ,"131012");
					CjcxRes.Cj[i].mmbz ='B';
					if(curChkUsrRes.jys==0)
						sprintf(CjcxRes.Cj[i].gpdm ,"%04d",1+i);
					else
						sprintf(CjcxRes.Cj[i].gpdm ,"%06ld",(long)(600600+i));
					sprintf(CjcxRes.Cj[i].cjgs,"%d",100*(i+1));
					sprintf(CjcxRes.Cj[i].cjjg,"%.2f",12.23+i*2);
				}
			}
			else
				ret=CjcxRes.flag;
            if(ret!=ANS_SUCC)
            {    
            	if(ret==1)
            		strcpy(tmp,"�޴˹ɶ����룡");
            	else if(ret==ANS_SYS_ERR)
            		strcpy(tmp,"����ϵͳ����");
            	else if(ret==ANS_SUSP_REQ)
            		strcpy(tmp,"�������ڴ��������ϴ�����");
            	else if(ret==ANS_NO_PRIV)
            		strcpy(tmp,"��û��Ȩ�޽���������");	
            	else
            		strcpy(tmp,"δ֪ϵͳ����");
				MessageBox(hDlg, tmp, "�ɽ���ѯ", MB_OK);
				break;
			}
			if(fFirst)
			{
				fFirst =FALSE;
				SendDlgItemMessage(hDlg, IDL_CJCX, LB_RESETCONTENT, 0, 0L);
			}
			memset(&tmp[0], 0, sizeof(tmp));
			if(CjcxRes.recCount==0)
			{
				strcpy(tmp,"����ί����δ�ɽ�");
				SendDlgItemMessage(hDlg, IDL_CJCX, LB_ADDSTRING, 0,
						(LPARAM)(LPSTR)tmp);		
			}
			else
			{
				for(i =0; i<CjcxRes.recCount; i++)
				{    
					for(j=0;j<HqData[curChkUsrRes.jys].recCount;j++)
					{
						if(strncmp(HqData[curChkUsrRes.jys].lpPreData[j].zqdm,
							CjcxRes.Cj[i].gpdm,strlen(HqData[curChkUsrRes.jys].lpPreData[j].zqdm))==0)
						break;
					}
					if(j<HqData[curChkUsrRes.jys].recCount)
					{
						strncpy(gpmc,HqData[curChkUsrRes.jys].lpPreData[j].zqmc,8);
						gpmc[8]=0;
					}
					else
					    strcpy(gpmc,CjcxRes.Cj[i].gpdm);
					sprintf(tmp, "%06s  %8s  %4s  %8s  %8s  %8s",
							CjcxRes.Cj[i].hthm, CjcxRes.Cj[i].cjsj,
							(CjcxRes.Cj[i].mmbz=='B')?"����":
							((CjcxRes.Cj[i].mmbz=='S')?"����":"����"),
							gpmc, CjcxRes.Cj[i].cjgs,
							CjcxRes.Cj[i].cjjg);
					if(SendDlgItemMessage(hDlg, IDL_CJCX, LB_ADDSTRING, 0,
						(LPARAM)(LPSTR)tmp)==LB_ERR)
					break;
				}
			}
		break;
		
		case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_DLG:
				case CTLCOLOR_STATIC:
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_LISTBOX:
					return (LRESULT)hBrush;
			}
		return (LRESULT)NULL;
		
		case WM_DRAWITEM:
			lpdis = (LPDRAWITEMSTRUCT)lParam;
			if (lpdis->itemID == -1)
			{
				if(lpdis->CtlType==ODT_BUTTON)
					BtnFocusState(lpdis);
				if(lpdis->CtlType==ODT_LISTBOX)
				{
					DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}
			}
			else
			{
				if(lpdis->itemAction&ODA_DRAWENTIRE)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnDrawEntireItem(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
					{   
						i=lpdis->itemID;
						SendMessage(lpdis->hwndItem,LB_GETTEXT,
							(WPARAM)lpdis->itemID,(LPARAM)(LPSTR)tmp);
						SelectObject(lpdis->hDC,GetStockObject(SYSTEM_FIXED_FONT));	
						TextOut(lpdis->hDC,lpdis->rcItem.left,lpdis->rcItem.top,tmp,strlen(tmp));
					}
					if(lpdis->itemState&ODS_SELECTED)
					{
						if(lpdis->CtlType==ODT_BUTTON)
							BtnSelectionState(lpdis);
						if(lpdis->CtlType==ODT_LISTBOX)
							InvertRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					}
					if(lpdis->itemState&ODA_FOCUS)
					{
						if(lpdis->CtlType==ODT_BUTTON)
							BtnFocusState(lpdis);
						if(lpdis->CtlType==ODT_LISTBOX)
							DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					}
					return TRUE;	
				}
				if(lpdis->itemAction&ODA_SELECT)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnSelectionState(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
						InvertRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}
				if(lpdis->itemAction&ODA_FOCUS)
				{
					if(lpdis->CtlType==ODT_BUTTON)
						BtnFocusState(lpdis);
					if(lpdis->CtlType==ODT_LISTBOX)
						DrawFocusRect(lpdis->hDC,(LPRECT)&lpdis->rcItem);
					return TRUE;
				}				
			}
		break;
        case WM_MEASUREITEM:
        	lpmis =(LPMEASUREITEMSTRUCT)(lParam);
        	hDC =GetDC(hDlg);
        	SelectObject(hDC,GetStockObject(SYSTEM_FIXED_FONT));        	
        	GetTextMetrics(hDC,&tm);
        	lpmis->itemHeight =tm.tmHeight;
        	ReleaseDC(hDlg,hDC);
        break;
		case WM_PAINT:
			BeginPaint(hDlg, &ps);
			DrawFrame(ps.hdc, hDlg);
			EndPaint(hDlg, &ps);
		break;

		case WM_TIMER:
			if(gnTimers ++>60)
				SendMessage(hDlg, WM_COMMAND, IDCANCEL, 0L);
		break;
		
		case WM_COMMAND:
			gnTimers =0;
			switch(wParam)
			{
				case IDCANCEL:
					udpread_stop =TRUE;
					KillTimer(hDlg, 1);
					ghDlgJy =NULL;
					DeleteObject(hBrush);
					EndDialog(hDlg, 0);
				break;
			}
		break;
	}
	
	return FALSE;
}

void JyTimer(void)
{
	if(HqTime[curChkUsrRes.jys].fRunning ==FALSE)
	{
		//jy_timers =0;
		//curChkUsrRes.flag =-1;
	}
	//else
	//	if(++jy_timers>=6)
	//	{
			//jy_timers =0;
			//curChkUsrRes.flag =-1;
	//	}
}

void CenterWindow(HWND hDlg)
{
	RECT rc2;
	int x,y;
	
	x =GetSystemMetrics(SM_CXSCREEN);
	y =GetSystemMetrics(SM_CYSCREEN);
	GetClientRect(hDlg, &rc2);
	SetWindowPos(hDlg, NULL, (x-rc2.right)/2, (y-rc2.bottom)/2,
					0, 0, SWP_NOSIZE|SWP_NOZORDER);
					
}

void FAR PASCAL BtnSelectionState(LPDRAWITEMSTRUCT lpdis)
{
	if(lpdis->itemState & ODS_SELECTED)
		DrawBtnSelected(lpdis);
	else
		if(lpdis->itemState & ODS_FOCUS)
		{
			SetTextColor(lpdis->hDC, RGB(0, 0, 255));
			DrawBtnFocus(lpdis);
		}
		else
		{
			SetTextColor(lpdis->hDC, RGB(0, 0, 0));
			DrawBtnUnFocus(lpdis);
		}	
}

void FAR PASCAL BtnFocusState(LPDRAWITEMSTRUCT lpdis)
{
		if(lpdis->itemState & ODS_FOCUS)
		{                      
			if(lpdis->itemState & ODS_SELECTED)
				DrawBtnSelected(lpdis);
			else
				DrawBtnFocus(lpdis);
			SetTextColor(lpdis->hDC, RGB(0, 0, 255));
		}
		else       
		{
			SetTextColor(lpdis->hDC, RGB(0, 0, 0));
			DrawBtnUnFocus(lpdis);
		}
		DrawBtnNormal(lpdis, FALSE);
}

void FAR PASCAL BtnDrawEntireItem(LPDRAWITEMSTRUCT lpdis)
{
	BtnFocusState(lpdis);
	DrawBtnNormal(lpdis, TRUE);
}

void DrawBtnSelected(LPDRAWITEMSTRUCT lpdis)
{
	ShowBitmap(lpdis->hDC, 5, (lpdis->rcItem.bottom-6)/2, hBmpSel);
}

void DrawBtnFocus(LPDRAWITEMSTRUCT lpdis)
{
	SelectObject(lpdis->hDC, GetStockObject(BLACK_PEN));
	SelectObject(lpdis->hDC, GetStockObject(NULL_BRUSH));
	Rectangle(lpdis->hDC, 0, 0, lpdis->rcItem.right, lpdis->rcItem.bottom);
	ShowBitmap(lpdis->hDC, 5, (lpdis->rcItem.bottom-6)/2, hBmpFoc);
}

void DrawBtnUnFocus(LPDRAWITEMSTRUCT lpdis)
{
	HPEN hPen;
	
	SelectObject(lpdis->hDC, GetStockObject(NULL_PEN));
	SelectObject(lpdis->hDC, GetStockObject(LTGRAY_BRUSH));
	Rectangle(lpdis->hDC, 5, (lpdis->rcItem.bottom-6)/2, 15, (lpdis->rcItem.bottom+8)/2);
	hPen =CreatePen(PS_SOLID, 1, RGB(180, 180, 180));
	SelectObject(lpdis->hDC, GetStockObject(NULL_BRUSH));
	SelectObject(lpdis->hDC, hPen);
	Rectangle(lpdis->hDC, 0, 0, lpdis->rcItem.right, lpdis->rcItem.bottom);
	SelectObject(lpdis->hDC, GetStockObject(BLACK_PEN));
	DeleteObject(hPen);
}

void DrawBtnNormal(LPDRAWITEMSTRUCT lpdis, BOOL fDrawFrame)
{
	char tmp[40];
	HPEN hPen;
	DWORD dw;
    HFONT hFont;
    LOGFONT lf;
    
	GetWindowText(lpdis->hwndItem, tmp, sizeof(tmp));
	memset(&lf,0,sizeof(LOGFONT));	
    lf.lfHeight=(int)((lpdis->rcItem.bottom -lpdis->rcItem.top)*0.8);
	lf.lfWeight =FW_NORMAL;            
	strcpy(lf.lfFaceName, "����");
           		
    hFont =CreateFontIndirect(&lf);
    SelectObject(lpdis->hDC,hFont);
    dw =GetTextExtent(lpdis->hDC, tmp, strlen(tmp));
	SetBkMode(lpdis->hDC, TRANSPARENT);
	
	SetTextColor(lpdis->hDC, RGB(0, 0, 0));	
	TextOut(lpdis->hDC, lpdis->rcItem.left+(lpdis->rcItem.right-LOWORD(dw)-lpdis->rcItem.left)/2, 
		(lpdis->rcItem.bottom-HIWORD(dw))/2, tmp, strlen(tmp));	
	SetTextColor(lpdis->hDC, RGB(255, 255, 255));	
	TextOut(lpdis->hDC, lpdis->rcItem.left+(lpdis->rcItem.right-LOWORD(dw)-lpdis->rcItem.left)/2-1,
	 	(lpdis->rcItem.bottom-HIWORD(dw))/2-1, tmp, strlen(tmp));	
	DeleteObject(hFont);

	if(!fDrawFrame) return;
	
	SelectObject(lpdis->hDC, GetStockObject(NULL_BRUSH));
	hPen =CreatePen(PS_SOLID, 1, RGB(80, 80, 80));
	SelectObject(lpdis->hDC, hPen);
	MoveTo(lpdis->hDC, lpdis->rcItem.right-2, 2);
	LineTo(lpdis->hDC, lpdis->rcItem.right-2, lpdis->rcItem.bottom-2);
	LineTo(lpdis->hDC, 2, lpdis->rcItem.bottom-2);

	SelectObject(lpdis->hDC, GetStockObject(WHITE_PEN));
	DeleteObject(hPen);
	MoveTo(lpdis->hDC, 1, lpdis->rcItem.bottom-2);
	LineTo(lpdis->hDC, 1, 1);
	LineTo(lpdis->hDC, lpdis->rcItem.right-1, 1);
	
	SelectObject(lpdis->hDC, GetStockObject(BLACK_PEN));
	MoveTo(lpdis->hDC, lpdis->rcItem.right-2, 1);
	LineTo(lpdis->hDC, lpdis->rcItem.right-2, lpdis->rcItem.bottom-2);
	LineTo(lpdis->hDC, 1, lpdis->rcItem.bottom-2);
}

int ShowBitmap(HDC hDC, int left, int top, HBITMAP hBmp)      //==
{
	BITMAP bmp;
	HDC hdcMem;
	
	GetObject(hBmp, sizeof(bmp), &bmp);
	hdcMem =CreateCompatibleDC(hDC);
	SelectObject(hdcMem, hBmp);
	BitBlt(hDC, left, top, bmp.bmWidth, bmp.bmHeight, hdcMem, 0, 0, SRCCOPY);
	DeleteObject(hdcMem);
	
	return 0;
}

void DrawFrame(HDC hDC, HWND hWnd)
{
	RECT rc;
	HPEN hPen;
	
	GetClientRect(hWnd, &rc);
	
	hPen =CreatePen(PS_SOLID, 2, RGB(180, 180, 180));
	SelectObject(hDC, hPen);
	SelectObject(hDC, GetStockObject(NULL_BRUSH));
	Rectangle(hDC, 2, 2, rc.right-2, rc.bottom-1);
	SelectObject(hDC, GetStockObject(WHITE_PEN));
	DeleteObject(hPen);
	MoveTo(hDC, rc.right, 0);
	LineTo(hDC, 0, 0);
	LineTo(hDC, 0, rc.bottom);
	hPen =CreatePen(PS_SOLID, 2, RGB(80, 80, 80));
	SelectObject(hDC, hPen);
	LineTo(hDC, rc.right-1, rc.bottom-1);
	LineTo(hDC, rc.right-1, 0);
	SelectObject(hDC, GetStockObject(WHITE_PEN));
	DeleteObject(hPen);
}

HBRUSH DrawChild(HDC hDC, HWND hWnd)
{
	HPEN hPen, hOldPen;
	HBRUSH hOldBrush;
	RECT rc;
	
	if(!IsWindowVisible(hWnd) || WinVer >3)
		return (HBRUSH)NULL;
	GetWindowRect(hWnd, &rc);
	
	rc.right -=rc.left;
	rc.left =0;
	rc.bottom -=rc.top;
	rc.top =0;
	
	if(isWndClass(hWnd,(LPSTR)"ListBox"))
	{
		rc.left-=1; 
		rc.top-=1;
		rc.right-=1;
		rc.bottom-=1;
	}  
	hPen=CreatePen(PS_SOLID,1,RGB(80,80,80)); 
	hOldBrush=SelectObject(hDC,GetStockObject(NULL_BRUSH));
	hOldPen=SelectObject(hDC,hPen);
	Rectangle(hDC,rc.left-1,rc.top-1,rc.right,rc.bottom);
	SelectObject(hDC,GetStockObject(WHITE_PEN));
	DeleteObject(hPen);
	MoveTo(hDC,rc.left-1,rc.bottom);
	LineTo(hDC,rc.right,rc.bottom);
	LineTo(hDC,rc.right,rc.top-2);
	SelectObject(hDC,hOldPen);                             
	SelectObject(hDC,hOldBrush);
	SetBkMode(hDC,TRANSPARENT);//Color((HDC)wParam,RGB(180,180,180));
	SetTextColor(hDC,GetSysColor(COLOR_WINDOWTEXT));
	  
	if(isWndClass(hWnd,(LPSTR)"ComboBox"))
		return (HBRUSH)GetStockObject(LTGRAY_BRUSH);
	else  
		return (HBRUSH)NULL;
}

BOOL isWndClass(HWND hWnd,LPSTR ClassName)
{                                            
	char tmp[40];
	
	if(!GetClassName(hWnd, (LPSTR)tmp, sizeof(tmp))) return FALSE;
		return (strcmpi((LPSTR)tmp, (LPSTR)ClassName)==0); 
}
