#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <commdlg.h>
#include "resource.h"
#include "global.h"
#include "fx.h"

#define	SELECTED_COLOR	RGB(255,0,0)
extern 	CHOOSECOLOR cc;
extern 	char *DIAGR_NAME;

extern HWND ghWndFx;

int DrawDiagram(HDC hDc,int CurRecPrt,int Show,PARA *Para,DATA *Data,PAINT_PARA *PaintPara,long Feature)
{
	int i,j,k;
	double 	fhdj,               //���ܶ�
			fwdt,               //���ܶ�
			step,               //ÿ���ں������ֵ��
			repl;
	int fwdk,                   //һ��K�ߵĿ�
		htitle,                 //����ע����
		ltitle,                 //����ע�����ȵ�һ��
		wleft,                  //���ע����
		wtitle,                 //����ע������
		show,                   //��ʾ��¼��
		coor;                   //��������Ŀ
	long feature;               //��ͼ������
	HPEN hPen,hDPen[20];
	HBRUSH hBBrush;
	char tmp[20];
	TEXTMETRIC tm;
	HDC hdc;	
	
    if(Para->rc.bottom ==0||Para->rc.right ==0)
    	return TRUE;
	if(hDc!=NULL)	hdc =hDc;
	else 	hdc =GetDC(ghWndFx);
	if(Feature==0L)	feature=Para->feature;
	else	feature=Feature;
	
	SetTextColor(hdc,RGB(200,155,0));
	SetBkColor(hdc,RGB(0,0,0));
	SetTextAlign(hdc,TA_LEFT|TA_TOP);
	SetBkMode(hdc, OPAQUE);
	SelectObject(hdc,GetStockObject(SYSTEM_FONT));
	SelectObject(hdc,GetStockObject(BLACK_PEN));
	SelectObject(hdc,GetStockObject(BLACK_BRUSH));
	GetTextMetrics(hdc, &tm);
	Rectangle(hdc,0,0,PaintPara->rc.right/2,tm.tmHeight+2);
	TextOut(hdc,0, 2, DIAGR_NAME, strlen(DIAGR_NAME));
	
	SetBkMode(hdc, TRANSPARENT);	
	SelectObject(hdc, PaintPara->hFont);
	show =Show;
	if(show+CurRecPrt>Data->size) show=Data->size-CurRecPrt;
	
	SelectObject(hdc, GetStockObject(WHITE_PEN));
	GetTextMetrics(hdc, &tm);
 
	htitle=(int)(tm.tmHeight+tm.tmHeight*30/100);
	Para->htitle =htitle;
	if(Fx->PaintPara.wleft==0)
	{
    	wleft=(int)(tm.tmAveCharWidth*10+tm.tmMaxCharWidth*20/100);
    	Fx->PaintPara.wleft=wleft;
    }
    else
    	wleft=Fx->PaintPara.wleft;

	//�����
	if(feature&DW_FRAME&&!(feature&DW_SELE))
	{
		SelectObject(hdc,GetStockObject(BLACK_BRUSH));
		hPen =CreatePen(PS_SOLID, FRAME_WIDTH, RGB(200,200,200));	
		SelectObject(hdc,hPen);
		SelectObject(hdc,GetStockObject(BLACK_BRUSH));
		Rectangle(hdc,Para->rc.left+1,Para->rc.top,
			Para->rc.right,Para->rc.bottom);    
		Rectangle(hdc,Para->rc.left+wleft,Para->rc.top,
			Para->rc.right,Para->rc.bottom);
		SelectObject(hdc, GetStockObject(BLACK_PEN));
		DeleteObject(hPen);    
	}		
	//��ѡ�б�־	
	SetBkMode(hdc, OPAQUE);
	SelectObject(hdc,GetStockObject(WHITE_PEN));
	if(PaintPara->object==Para->no)
		SelectObject(hdc,GetStockObject(GRAY_BRUSH));
	else
		SelectObject(hdc,GetStockObject(BLACK_BRUSH));
	Rectangle(hdc,Para->rc.left+2,Para->rc.top+1,
		Para->rc.left+wleft-1,Para->rc.top+htitle+2);
	SelectObject(hdc,GetStockObject(BLACK_BRUSH));	
	SetBkMode(hdc, TRANSPARENT);		
	
   	if(Data->size <=0||show==0)
   	{ 
   	    if(hDc==NULL)	ReleaseDC(ghWndFx,hdc);
   	 	return FALSE;
   	}
    if(DW_DELE&feature)
		SetROP2(hdc,R2_XORPEN);    
	
	SetRect(&Para->rc,Para->rc.left +FRAME_WIDTH,Para->rc.top +FRAME_WIDTH,
			Para->rc.right -FRAME_WIDTH,Para->rc.bottom -FRAME_WIDTH);
	if(DEFSHOWDOT>show)
		fwdt =(float)(Para->rc.right-Para->rc.left-wleft-5)/DEFSHOWDOT;
	else
		fwdt =(float)(Para->rc.right-Para->rc.left-wleft-5)/show;
	fwdk=(int)(fwdt*80/100);
    
	Para->fwdt =fwdt;
	
	//�������ֵ
	if(feature&DW_MAX)
	{
		Para->price[0]=0;
		for(i=CurRecPrt; i<CurRecPrt+show; i++)
		{ 
	    	for(j=0;j<Data->num;j++)
	    	{
				//if(Para->color[j]==0)
				//	continue;	    	
				if(Para->price[0]<Data->v[j][i]) 
					Para->price[0]=Data->v[j][i];
			}
		}
	}
	//������Сֵ
	if(feature&DW_MIN)
	{
		Para->price[1]=Para->price[0];    
		for(i=CurRecPrt; i<CurRecPrt+show; i++)
		{ 
	    	for(j=0;j<Data->num;j++)
	    	{
	    		if(Para->color[j]==0&&Data->method[0]==VOULMN_BAR_METHOD)
	    			continue;
				if(Para->price[1]>Data->v[j][i]&&Data->v[j][i]!=0) 
					Para->price[1]=Data->v[j][i];
			}
		}
	}	
	//if(Para->price[0]==0||Para->price[0]==Para->price[1])
	if(Para->price[0]==Para->price[1])
		fhdj=1;				
	else	
		fhdj =(double)(Para->rc.bottom-Para->rc.top-htitle)/(double)(Para->price[0]-Para->price[1]);
	Para->fhdj =fhdj;	
	
	//�궥����������
	SetTextAlign(hdc, TA_LEFT|TA_TOP);
	wtitle =(Para->rc.right-wleft -5)/4;
	ltitle =wtitle/2;
	for(i=0,j=0;i<10;i++)
	{
		if(strlen(Para->pname[i])==0)
			continue;
		strcpy(tmp,Para->pname[i]);
		Para->xtitle[j]=j*wtitle +5;
		if(feature&DW_NAME)
		{
			if((feature&DW_DELE|feature&DW_SELE)&&GetSerial(feature)==i)
				SetTextColor(hdc,SELECTED_COLOR);
			else
				SetTextColor(hdc,Para->color[i]);
			TextOut(hdc,Para->xtitle[j]+wleft,Para->rc.top+2,
				tmp,strlen(tmp));
		}
		Para->xtitle[j]+=ltitle+wleft;
		j++;
	}
	
	//���������
	coor =5;
	step = (Para->price[0]-Para->price[1])/coor;
	while(step*fhdj<tm.tmHeight&&coor>0)
	{
		coor--;
		if(coor==0) 
		{
			step =0;
			coor =1;
			break;
		}
		step = (Para->price[0]-Para->price[1])/coor;
	}
	SetViewportOrg(hdc, Para->rc.left+wleft,
		(int)((Para->price[0]-Para->price[1])*fhdj)+Para->rc.top+htitle);	
	SetTextAlign(hdc, TA_RIGHT|TA_TOP);
	if(feature&DW_SELE|feature&DW_DELE)
		SetTextColor(hdc,SELECTED_COLOR);
    else
		SetTextColor(hdc, RGB(255, 255, 0));
	SelectObject(hdc, PaintPara->hFont);
	for(i=1;i<=coor&&(feature&DW_LEFT);i++)
	{
		MoveTo(hdc,0,(int)(-1*(step*fhdj*i)));
		hLineTo(hdc,Para->rc.right-wleft-FRAME_WIDTH,(int)(-1*(step*fhdj*i)));	
		if(Data->method[0]==VOULMN_BAR_METHOD)
			sprintf(tmp, "%.0f",Para->price[1]+step*i);
		else
			sprintf(tmp, "%.2f",Para->price[1]+step*i);
		TextOut(hdc, -1*FRAME_WIDTH,(int)(-1*(step*fhdj*i)), tmp, strlen(tmp));
	}	
	//��������	
	SetViewportOrg(hdc, Para->rc.left+wleft,
		(int)(Para->price[0]*fhdj)+Para->rc.top+htitle);
	if(feature&DW_ALERT)
	{   
		for(j=0;j<3;j++)
		{
			if(Para->price[2+j]==0) 
				continue;
			if((feature&DW_DELE|feature&DW_SELE)&&GetSerial(feature)==j)
				hPen=CreatePen(PS_DOT,1,SELECTED_COLOR);  
	    	else
    			hPen=CreatePen(PS_DOT,1,RGB(10,150,100));  
    		SelectObject(hdc,hPen);
			MoveTo(hdc,0,-1*(int)(fhdj*Para->price[2+j]));
			LineTo(hdc,Para->rc.right-wleft-FRAME_WIDTH,-1*(int)(fhdj*Para->price[2+j]));
			SelectObject(hdc, GetStockObject(BLACK_PEN));
			DeleteObject(hPen);			
		}	
	}
	//��0��
	if(Para->price[1]<=0&&Para->price[0]>=0&&feature&DW_X_COOR)
	{   
		if(feature&DW_DELE|feature&DW_SELE)
			hPen=CreatePen(PS_SOLID,1,SELECTED_COLOR);  
	    else
			hPen =CreatePen(PS_SOLID, 1, RGB(65,65,65));
		SelectObject(hdc, hPen);         
		MoveTo(hdc,0,0);
		LineTo(hdc, Para->rc.right-wleft,0);
		SelectObject(hdc, GetStockObject(WHITE_PEN));
		DeleteObject(hPen);
	}
    //��������
    for(j=0;j<20;j++)
    {   
    	if(Para->color[j]!=0)
    	{   
			if((feature&DW_DELE|feature&DW_SELE)&&!(j/10)^GetSerial(feature))
				hDPen[j]=CreatePen(PS_SOLID,1,SELECTED_COLOR);  
    	    else
    			hDPen[j] =CreatePen(PS_SOLID, 1, Para->color[j]);
    	}
    	else
    	    hDPen[j] =0;
    }
    hBBrush=CreateSolidBrush(RGB(0,255,255));
    SelectObject(hdc,GetStockObject(BLACK_BRUSH));
	//������������
	for(j=0;j<10;j++)
	{   
		if(Para->color[j]==0)
			continue;
		if(!(feature>>j&0x1))
			continue;
		//��K��
		if(Data->method[j] ==PRICE_BAR_METHOD&&j<7)
		{
			if(Para->color[j+3]!=0)
				continue;
			for(i =CurRecPrt,k=1; i<CurRecPrt+show; i++,k++)
			{
				if(Data->v[j][i]<Data->v[j+1][i])      //ks<ss
				{       
					SelectObject(hdc, hDPen[j]);
					Rectangle(hdc,(int)(fwdt*k),-(int)(Data->v[j][i]*fhdj),
						(int)(fwdt*k)+fwdk,-(int)(Data->v[j+1][i]*fhdj));
					if(Data->v[j+2][i]>Data->v[j+1][i])
					{
						MoveTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+1][i]*fhdj));
						LineTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+2][i]*fhdj));
					}
					if(Data->v[j+3][i]<Data->v[j][i])
					{
						MoveTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j][i]*fhdj));
						LineTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+3][i]*fhdj));
					}
				}	
		
				if(Data->v[j][i]==Data->v[j+1][i])     //ks ==ss
				{
		    		SelectObject(hdc, hDPen[j]);
		    		MoveTo(hdc,(int)(fwdt*k),-(int)(Data->v[j][i]*fhdj));
		    		LineTo(hdc,(int)(fwdt*k)+fwdk,-(int)(Data->v[j][i]*fhdj));
					if(Data->v[j+2][i]>Data->v[j][i])
					{
						MoveTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j][i]*fhdj));
						LineTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+2][i]*fhdj));
					}
					if(Data->v[j+3][i]<Data->v[j+1][i])
					{
						MoveTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+1][i]*fhdj));
						LineTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+3][i]*fhdj));
					}		    
				}   
		 
		 
				if(Data->v[j][i]>Data->v[j+1][i])	//ks>ss
				{		   
					SelectObject(hdc, hDPen[10+j]);
					SelectObject(hdc,hBBrush);
					Rectangle(hdc,(int)(fwdt*k),-(int)(Data->v[j+1][i]*fhdj),
						(int)(fwdt*k)+fwdk,-(int)(Data->v[j][i]*fhdj));
					if(Data->v[j+2][i]>Data->v[j][i])
					{                              
						MoveTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j][i]*fhdj));
						LineTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+2][i]*fhdj));
					}
					if(Data->v[j+3][i]<Data->v[j+1][i])
					{
						MoveTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+1][i]*fhdj));
						LineTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+3][i]*fhdj));
					}
					SelectObject(hdc,GetStockObject(BLACK_BRUSH));									
				}	
		    }
		}
		//����
		if(Data->method[j] ==VOULMN_BAR_METHOD)
		{
			for(i =CurRecPrt,k=1; i<CurRecPrt+show; i++,k++)
			{		
				if(Data->v[j+1][i]<=0)
				{       
					SelectObject(hdc, hDPen[j]);
					if(fwdk>0)
						Rectangle(hdc,(int)(fwdt*k),-(int)(Data->v[j][i]*fhdj),
							(int)(fwdt*k)+fwdk,-(int)(Para->price[1]*fhdj));
					else
					{
						MoveTo(hdc,(int)(fwdt*k+fwdk/2),-(int)(Para->price[1]*fhdj));
						LineTo(hdc,(int)(fwdt*k+fwdk/2),-(int)(Data->v[j][i]*fhdj));
					}
				}		
				if(Data->v[j+1][i]>0)
				{		   
					SelectObject(hdc, hDPen[10+j]);
					SelectObject(hdc,hBBrush);					
					if(fwdk>0)
						Rectangle(hdc,(int)(fwdt*k),-(int)(Data->v[j][i]*fhdj),
							(int)(fwdt*k)+fwdk,-(int)(Para->price[1]*fhdj));
					else
					{
						MoveTo(hdc,(int)(fwdt*k+fwdk/2),-(int)(Para->price[1]*fhdj));
						LineTo(hdc,(int)(fwdt*k+fwdk/2),-(int)(Data->v[j][i]*fhdj));
					}
					SelectObject(hdc,GetStockObject(BLACK_BRUSH));		
				}	
        
			}		
		}
		//����
		if(Data->method[j] ==CURVE_METHOD)
		{
			for(i=CurRecPrt,k=1;i<CurRecPrt+show&&Data->v[j][i]==0;i++,k++);
			if(i<CurRecPrt+show)
			{
				if(Data->v[j][i]<Para->price[1])
					repl =Para->price[1];
				else if(Data->v[j][i]>Para->price[0])
			    	repl =Para->price[0];
		    	else
		    		repl =Data->v[j][i];
				MoveTo(hdc,(int)(fwdt*k+fwdk/2),(int)(-1*fhdj*repl));
				SelectObject(hdc,hDPen[j]);
	
				for(; i<CurRecPrt+show; i++,k++)
				{    
					if(Data->v[j][i]<Para->price[1])
						repl =Para->price[1];
					else if(Data->v[j][i]>Para->price[0])
			    		repl =Para->price[0];
		    		else
		    			repl =Data->v[j][i];			
        			LineTo(hdc,(int)(fwdt*k+fwdk/2),-1*(int)(fhdj*repl));
				}
			}
	    }
		//������
		if(Data->method[j] ==VERT_LINE_METHOD)
		{
			for(i=CurRecPrt,k=1; i<CurRecPrt+show; i++,k++)
			{   
				if(Data->v[j][i]==0) continue;
	    		if(Data->v[j][i]>=0)
	    			SelectObject(hdc,hDPen[j]);
	    		else
	    			SelectObject(hdc,hDPen[10+j]);
	    		if(Para->price[1]<=0)	
					MoveTo(hdc,(int)(fwdt*k)+fwdk/2,0);
				else
				    MoveTo(hdc,(int)(fwdt*k)+fwdk/2,-1*(int)(Para->price[1]*fhdj));
        		LineTo(hdc,(int)(fwdt*k)+fwdk/2,-1*(int)(Data->v[j][i]*fhdj));
			}
		}
	}
	SetViewportOrg(hdc, 0, 0); 
	SetTextAlign(hdc, TA_LEFT|TA_TOP);
	for(i=0,j=0;i<10&&(feature&DW_TOP);i++) 
	{   
		if(strlen(Para->pname[i])==0)
			continue;
		if(Para->color[i]==0)
			continue;
		if((feature&DW_DELE|feature&DW_SELE)&&GetSerial(feature)==i)
			SetTextColor(hdc,SELECTED_COLOR);
		else
			SetTextColor(hdc,Para->color[i]);
		if(Data->method[0]==VOULMN_BAR_METHOD)
		    sprintf(tmp,"%.0f",Data->v[i][CurRecPrt+show -1]);
		else		
			sprintf(tmp,"%.2f",Data->v[i][CurRecPrt+show -1]);			
		TextOut(hdc,Para->xtitle[j],Para->rc.top+2,
			tmp,strlen(tmp));
		j++;
	}
	SelectObject(hdc, GetStockObject(BLACK_BRUSH));
	DeleteObject(hBBrush);
	SelectObject(hdc, GetStockObject(BLACK_PEN));
    for(j=0;j<20;j++)
    {   
    	if(hDPen[j]!=0)
			DeleteObject(hDPen[j]);
    }
	SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
			Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);
    if(hDc==NULL)	
    	ReleaseDC(ghWndFx,hdc);    
    else
    	SetROP2(hDc, R2_COPYPEN);
	return TRUE;
}

long GetObjectItem(int x,int y,int CurRecPrt,int Show,PARA *Para,DATA *Data,PAINT_PARA *PaintPara)
{
	int i,j,k;
	double 	fhdj,               //���ܶ�
			fwdt,               //���ܶ�
			repl,
			v;
	int fwdk,                   //һ��K�ߵĿ�
		htitle,                 //����ע����
		ltitle,                 //����ע�����ȵ�һ��
		wleft,                  //���ע����
		wtitle,                 //����ע������
		show;                   //��ʾ��¼��
	POINT pt;
	RECT rc;
	
	//��ʼ������
	fhdj =Para->fhdj;
	fwdt =Para->fwdt;
	if(fhdj==0||fwdt==0) return(DW_NULL);
	fwdk = (int)(fwdt*80/100);	
	htitle =Para->htitle;
	ltitle =(Para->xtitle[1] -Para->xtitle[0])/2;
	wleft =Fx->PaintPara.wleft;
	wtitle = Para->xtitle[1] -Para->xtitle[0];
	show =Show;
	pt.x =x;
	pt.y =y;
    
    
	//���
	for(i=0;i<5;i++)
	{ 
		if(i==0)
			SetRect(&rc,Para->rc.left,Para->rc.top,Para->rc.left+2,Para->rc.bottom);
		if(i==1)
			SetRect(&rc,Para->rc.left,Para->rc.top,Para->rc.right+2,Para->rc.top+2);
		if(i==2)
		    SetRect(&rc,Para->rc.right-2,Para->rc.top,Para->rc.right,Para->rc.bottom);
		if(i==3)
		    SetRect(&rc,Para->rc.left,Para->rc.bottom-2,Para->rc.right,Para->rc.bottom);
		if(i==4)
		    SetRect(&rc,Para->rc.left+wleft,Para->rc.top,Para->rc.left+wleft+2,Para->rc.bottom);
		if(PtInRect(&rc,pt))
			return(SetSerial((long)i,DW_FRAME));
	}
	
	//ѡ�б�־
	SetRect(&rc,Para->rc.left+2,Para->rc.top+1,Para->rc.left+wleft-1,
			Para->rc.top+htitle+2);
	if(PtInRect(&rc,pt))
		return DW_SELE;
	
	SetRect(&Para->rc,Para->rc.left +FRAME_WIDTH,Para->rc.top +FRAME_WIDTH,
			Para->rc.right -FRAME_WIDTH,Para->rc.bottom -FRAME_WIDTH);
	//�궥����������
	for(i=0,j=0;i<10;i++)
	{
		if(strlen(Para->pname[i])==0)
			continue; 
		SetRect(&rc,Para->xtitle[j]-ltitle,Para->rc.top+2,Para->xtitle[j],
			Para->rc.top+htitle);			
		if(PtInRect(&rc,pt))
		{
			SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
				Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);		
			return(SetSerial((long)(i),DW_NAME));
		}
		j++;
	}
	
	//���������	
	SetRect(&rc,5,Para->rc.top+htitle+2,wleft-2,Para->rc.bottom-2);
	if(PtInRect(&rc,pt))
	{
		SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
			Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);
	
		return DW_LEFT;
	}
	//������	
	pt.x =x-(Para->rc.left+wleft);
	pt.y =y-((int)(Para->price[0]*fhdj)+Para->rc.top+htitle);
		
	if(pt.x>0&&pt.x<Para->rc.right-wleft-FRAME_WIDTH)
	{
		for(j=0;j<3;j++)
		{
			if(Para->price[2+j]==0) 
				continue;
			if(pt.y==-1*(int)(fhdj*Para->price[2+j]))
			{
				SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
					Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);			
				return(SetSerial((long)j,DW_ALERT));
			}
		}	
		
	}
	//0��
	if(Para->price[1]<=0&&Para->price[0]>=0)
	{
		if(pt.x>0&&pt.x<Para->rc.right-wleft&&pt.y==0)
		{
			SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
				Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);		
			return DW_X_COOR;
		}
	}
	//pt.x=(int)(fwdt*k+fwdk/2)
	k=(int)((pt.x-fwdk/2)/fwdt) +1;
	v =-pt.y/fhdj;
	i=CurRecPrt +k -1;
	
	//����������
	for(j=0;j<10&&k<=show&&k>0;j++)
	{   
		if(Para->color[j]==0)
			continue;
		//��K��
		if(Data->method[j] ==PRICE_BAR_METHOD&&j<7)
		{
			if(Para->color[j+3]!=0)
				continue;
			if(Data->v[j][i]<Data->v[j+1][i])      //ks<ss
			{       
				SetRect(&rc,(int)(fwdt*k),-(int)(Data->v[j+1][i]*fhdj),
					(int)(fwdt*k)+fwdk,-(int)(Data->v[j][i]*fhdj));
				if(PtInRect(&rc,pt))
				{
					SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
						Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);				
				 	return(SetSerial(0L,1L<<j));
				}
				//if(Data->v[j+2][i]>Data->v[j+1][i])
				//{
				//	MoveTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+1][i]*fhdj));
				//	LineTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+2][i]*fhdj));
				//}
				//if(Data->v[j+3][i]<Data->v[j][i])
				//{
				//	MoveTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j][i]*fhdj));
				//	LineTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+3][i]*fhdj));
				//}
			}	
		
			if(Data->v[j][i]==Data->v[j+1][i])     //ks ==ss
			{
		        if(pt.y>=-(int)(Data->v[j][i]*fhdj)-1&&		        		
		        		pt.y<=-(int)(Data->v[j][i]*fhdj)-1)
		        {
					 SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
						Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);
					 return(SetSerial(0L,1L<<j));
		        }
			}		 
		 
			if(Data->v[j][i]>Data->v[j+1][i])	//ks>ss
			{		   
				SetRect(&rc,(int)(fwdt*k),-(int)(Data->v[j][i]*fhdj),
					(int)(fwdt*k)+fwdk,-(int)(Data->v[j+1][i]*fhdj));
				if(PtInRect(&rc,pt))
				{
					SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
						Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);
					 return(SetSerial(1L,1L<<j));
				}
				//if(Data->v[j+2][i]>Data->v[j][i])
				//{                              
				//	MoveTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j][i]*fhdj));
				//	LineTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+2][i]*fhdj));
				//}
				//if(Data->v[j+3][i]<Data->v[j+1][i])
				//{
				//	MoveTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+1][i]*fhdj));
				//	LineTo(hdc,(int)((fwdt*k)+fwdk/2),-(int)(Data->v[j+3][i]*fhdj));
				//}
			}	
		}
		//����
		if(Data->method[j] ==VOULMN_BAR_METHOD)
		{
			if(Data->v[j+1][i]<=0)
			{       
				if(fwdk>0)
				{
					SetRect(&rc,(int)(fwdt*k),-(int)(Data->v[j][i]*fhdj),
							(int)(fwdt*k)+fwdk,-(int)(Para->price[1]*fhdj));
					if(PtInRect(&rc,pt)) 
					{
						SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
							Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);					
						return(1L<<j);
					}
				}
				else
				{
					if(pt.y<-(int)(Para->price[1]*fhdj)&&
							pt.y>-(int)(Data->v[j][i]*fhdj))
					{
						SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
							Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);					
						return(1L<<j);
					}
				}
			}		
			if(Data->v[j+1][i]>0)
			{		   
				if(fwdk>0)
				{
					SetRect(&rc,(int)(fwdt*k),-(int)(Data->v[j][i]*fhdj),
						(int)(fwdt*k)+fwdk,-(int)(Para->price[1]*fhdj));
					if(PtInRect(&rc,pt))
					{
						SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
							Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);					
						return(SetSerial(1L,1L<<j));
					}
				}
				else
				{
					if(pt.y<-(int)(Para->price[1]*fhdj)&&
							pt.y>-(int)(Data->v[j][i]*fhdj))
					{
						SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
							Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);					
						return(SetSerial(1L,1L<<j));
					}
				}
			}        
		}
		//����
		if(Data->method[j] ==CURVE_METHOD)
		{
			if(Data->v[j][i]<Para->price[1])
				repl =Para->price[1];
			else if(Data->v[j][i]>Para->price[0])
			    repl =Para->price[0];
		    else
		    	repl =Data->v[j][i];
		    if(pt.y>=-1*(int)(fhdj*repl)-1&&pt.y<=-1*(int)(fhdj*repl)+1)
		    {
				SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
					Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);		    
				return(1L<<j); 
			}
	    }
		//������
		if(Data->method[j] ==VERT_LINE_METHOD)
		{
        	if(pt.y<=0&&pt.y>=-1*(int)(Data->v[j][i]*fhdj))
        	{
				SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
					Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);        	
        		return(SetSerial(0L,1L<<j));
        	}
        	if(pt.y>=0&&pt.y<=-1*(int)(Data->v[j][i]*fhdj))
        	{
				SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
					Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);        	
        		return(SetSerial(1L,1L<<j));
        	}        	
		}
	}
	pt.x=x;
	pt.y=y;
	for(i=0,j=0;i<10;i++) 
	{   
		if(strlen(Para->pname[i])==0)
			continue;
		SetRect(&rc,Para->xtitle[j],Para->rc.top+2,Para->xtitle[j]+ltitle,		
				Para->rc.top+htitle);
		if(PtInRect(&rc,pt))
		{
			SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
				Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);		
			return(SetSerial((long)(i),DW_TOP));
		}
		j++;
	}
	SetRect(&Para->rc,Para->rc.left -FRAME_WIDTH,Para->rc.top -FRAME_WIDTH,
			Para->rc.right +FRAME_WIDTH,Para->rc.bottom +FRAME_WIDTH);
	return(DW_NULL);
}

int SetColor(HWND hwnd)
{
	COLORREF dwCustClrs[16]={RGB(255,255,255),RGB(239,239,239),
		RGB(223,223,223),RGB(207,207,207),
		RGB(191,191,191),RGB(175,175,175),
		RGB(159,159,159),RGB(143,143,143),
		RGB(127,127,127),RGB(111,111,111),
		RGB( 95, 95, 95),RGB( 79, 79, 79),
		RGB( 63, 63, 63),RGB( 47, 47, 47),
		RGB( 31, 31, 31),RGB( 15, 15, 15)};
					
	memset(&cc,0,sizeof(CHOOSECOLOR));
	cc.lStructSize =sizeof(CHOOSECOLOR);
	cc.hwndOwner =hwnd;
	cc.hInstance =NULL;
	cc.rgbResult=0L;
	cc.lpCustColors = dwCustClrs;
	cc.Flags = CC_PREVENTFULLOPEN;
	cc.rgbResult=0L;
	cc.lpTemplateName =(LPSTR)NULL;
	if(ChooseColor(&cc))
		return 0;	//(cc.rgbResult);
	else
		return -1;
}