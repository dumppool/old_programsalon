#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "hq.h"
#include "cj.h"
#include "hq_cl.h"
#include "toolbar.h"
#include "appmain.h"

#define CJ_CLASS	"CCJ"

extern HINSTANCE ghInstance;
extern HWND ghWndMain, ghWndCj;
extern BOOL ErrMsg(HWND, LPSTR);
extern BOOL IsZsRec(int jys, int rec_num);

BOOL RegisterCj(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	
	wc.lpfnWndProc =CjWndProc;
	wc.lpszClassName =CJ_CLASS;
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = ghInstance;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

extern int CapHig ;

BOOL CreateWndCj(HWND hWnd)
{                          
	int x, y;
	HWND hwnd;
	int x0,y0,x1,y1;
	TEXTMETRIC tm;
	HDC hDC;
	RECT rc,rc1;
		
	x =GetSystemMetrics(SM_CXSCREEN);
	
	GetClientRect(ghWndMain,&rc);
	y =rc.bottom -rc.top;

	GetWindowRect(ghWndXlt,&rc1);
	hDC =GetDC(hWnd);
	GetTextMetrics(hDC, &tm);
	ReleaseDC(hWnd, hDC);

    x0 =rc1.right;
    y0 =tm.tmHeight*14+STATUS_HEIGHT +TOOLBAR_HEIGHT+2;
    x1 =x*1/3-30-1;
    //y1 =y-y0 -STATUS_HEIGHT -6 -GetSystemMetrics(SM_CYCAPTION);
    y1 =rc.bottom -STATUS_HEIGHT-y0 -MSG_HEIGHT;
    
	if(y1<=tm.tmHeight*2) y1 =tm.tmHeight*2;
	
	if(ghWndCj ==NULL)
	{
		hwnd =CreateWindow(CJ_CLASS, NULL, WS_CHILD|WS_CLIPSIBLINGS,
						x0, y0, x1, y1,
						hWnd, NULL, ghInstance, NULL);
						
		if(hwnd ==NULL)
		{
			ErrMsg(hWnd, "���ܽ����ɽ���ϸ����");
			return FALSE;
		}
	
		ghWndCj =hwnd;
	}
	else
	{
		SetWindowPos(ghWndCj, (HWND) NULL,x0, y0, x1, y1,NULL);	
	}
	return TRUE;
}

LRESULT CALLBACK CjWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int i, k;
	long lc;
	char tmp[256];
	PAINTSTRUCT ps;
	DWORD dw;
	int x, y;
	RECT rc;
	HPEN hPen;
	static int cjRecNum =0;
	static BOOL fInBottom =FALSE;
	BOOL isb;
	float zjjg;
	TEXTMETRIC tm;           
	LPSTR lpCjTitles[] ={"ʱ��","�۸�","����",NULL};	
	           
	switch(message)
	{
		case WM_CREATE:
			cjRecNum =0;
		break;
		case WM_SETFOCUS:
			SetFocus(ghWndMain);
		break;
		case WM_TIMER:
		break;
		case WM_READ_OK:
			cjRecNum =0;
			fInBottom =FALSE;
			InvalidateRect(hWnd, NULL, TRUE);
		break;
		case WM_SIZE:
			if(IsWindowVisible)
				InvalidateRect(hWnd, NULL, TRUE);
		break;
		case WM_KEYDOWN:
			switch(wParam)
			{
				case VK_UP:
					fInBottom =FALSE;
					if(--cjRecNum <0)
					{
						cjRecNum =0;
						return 0L;
					}
				break;
				case VK_DOWN:
					if(fInBottom) return 0L;
					k =0;
					for(i =0; i<GraphData.minEnd; i++)
						if(GraphData.lpGraData[i].lc) k++;
					if(++cjRecNum >=k)
						cjRecNum =k-1;
						
				break;                                
				default: return 0L;
			}
			InvalidateRect(hWnd, NULL, TRUE);
		break;
		
		case WM_PAINT:
			BeginPaint(hWnd, &ps);
			GetClientRect(hWnd, &rc);
			
			hPen =CreatePen(PS_SOLID, 2, RGB(180, 180, 180));
			SelectObject(ps.hdc, hPen);
			SelectObject(ps.hdc, GetStockObject(NULL_BRUSH));
			Rectangle(ps.hdc, 2, 2, rc.right-2, rc.bottom-1);
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
			MoveTo(ps.hdc, rc.right, 0);
			LineTo(ps.hdc, 0, 0);
			LineTo(ps.hdc, 0, rc.bottom);
			hPen =CreatePen(PS_SOLID, 2, RGB(80, 80, 80));
			SelectObject(ps.hdc, hPen);
			LineTo(ps.hdc, rc.right-1, rc.bottom-1);
			LineTo(ps.hdc, rc.right-1, 0);
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
			
			strcpy(tmp, "�ɽ�");
			dw =GetTextExtent(ps.hdc, tmp, strlen(tmp));
			x =LOWORD(dw); y =HIWORD(dw);
			
			SetBkMode(ps.hdc, OPAQUE);
			SetBkColor(ps.hdc, RGB(0, 0, 0));
			k =0;
			i =0;
			isb =FALSE;
			if(GraphData.minEnd)
			{
				GetTextMetrics(ps.hdc, &tm);
				while(1)
				{
					if(k >=GraphData.minEnd)
					{
						fInBottom =TRUE;
						break;
					}
					lc =GraphData.lpGraData[GraphData.minEnd-1-k].lc;
					zjjg =GraphData.lpGraData[GraphData.minEnd-1-k].zjjg;
					isb =GraphData.lpGraData[GraphData.minEnd-1-k].BS;

					if((y+1)*(i-cjRecNum) +tm.tmHeight> rc.bottom) break;
					if(i<cjRecNum){i++;k++; continue;}
					// time
					SetTextColor(ps.hdc, RGB(0, 180, 180));
					wsprintf(tmp, "%02d:%02d",
						GraphData.lpGraData[GraphData.minEnd-1-k].tim/60,
						GraphData.lpGraData[GraphData.minEnd-1-k].tim%60);
					SetTextAlign(ps.hdc, TA_LEFT|TA_TOP);
					TextOut(ps.hdc, 10, (y)*(i-cjRecNum)+5, tmp, strlen(tmp));
					//zjjg
					if(zjjg >0)
						SetTextColor(ps.hdc, RGB(255, 0, 0));
					else if(zjjg <0) SetTextColor(ps.hdc, RGB(0, 255, 0));
					else SetTextColor(ps.hdc, RGB(255, 255, 0));
					sprintf(tmp, "%.2f", zjjg+GraphData.GraHead.zrsp);
					SetTextAlign(ps.hdc, TA_RIGHT|TA_TOP);
					TextOut(ps.hdc, rc.right/2+10, (y)*(i-cjRecNum)+5, tmp, strlen(tmp));
					//lc
					strcpy(tmp, " ");
					sprintf(&tmp[1], "%ld", lc);
					if(isb)
						SetTextColor(ps.hdc, RGB(255, 0, 0));
					else SetTextColor(ps.hdc, RGB(0, 255, 0));
					TextOut(ps.hdc, rc.right-10, (y)*(i-cjRecNum)+5, tmp, strlen(tmp));
					
					i++;k++;
				}
			}
			EndPaint(hWnd, &ps);
		break;
		
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}
