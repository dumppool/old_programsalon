#include <windows.h>
#include <string.h>
#include <time.h>
#include "resource.h"
#include "appmain.h"
#include "global.h"
#include "hq.h"
#include "hq_cl.h"
#include "caption.h"
#include "jy_cl.h"
#include "rsa.h"


#define 	CAPTION_CLASS	"�̱�"
#define		SCROLL_X_COOR	200
#define		TIMER_X_COOR	100

extern JyQs;

extern HFILE hfZx;
extern int UDP_Send_Zx(void);
extern char szDataPath[128];
extern void PASCAL ShowBmp(HDC hDC,HBITMAP hBmp,int left,int top,int width,int height);

BOOL RegisterCaption(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	
	wc.style =CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc =CaptionWndProc;
	wc.lpszClassName =CAPTION_CLASS;
	wc.hbrBackground =GetStockObject(LTGRAY_BRUSH);
	wc.hInstance = ghInstance;
	wc.lpszMenuName = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	wc.hIcon = LoadIcon(ghInstance, MAKEINTRESOURCE(IDR_MAINFRAME));
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

BOOL CreateWndCaption(HWND hWnd)
{                          
	int x;
	HWND hwnd;
	
	if(ghWndCaption!=NULL) return TRUE;
	x =GetSystemMetrics(SM_CXSCREEN);	
	hwnd =CreateWindow(CAPTION_CLASS, NULL, WS_CHILD|WS_CLIPSIBLINGS,
			0, 0, x, STATUS_HEIGHT-2,
			hWnd, NULL, ghInstance, NULL);
	if(hwnd ==NULL)
	{
			ErrMsg(hWnd, "���ܽ�������������");
			return FALSE;
	}
	
	ghWndCaption =hwnd;	
	ShowWindow(hwnd, SW_SHOW);
	return TRUE;
}

LRESULT CALLBACK CaptionWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	RECT rc;
	HDC hDC;
	DWORD dw;
    static int s_left=0;
    static int s_width =0;
    static char szText[2000];
	static HBITMAP	hBmpCaption =NULL;
	static BITMAP bmp;
	static RECT rcRoll;
	static int times_num =58;
	static long file_len =0, total_len =0;
	int read_len =0;
	unsigned int t_left;
	HPEN hPen;
	TEXTMETRIC tm;
	OFSTRUCT os;
	char temp[80];
		
	switch(message)
	{
		case WM_SETFOCUS:
			SetFocus(ghWndMain);
		break;
		case WM_CREATE:
			GetClientRect(hWnd, &rc);
			memcpy(&rcRoll, &rc, sizeof(rc));
			rcRoll.right -=4;
			rcRoll.left =SCROLL_X_COOR;
			s_width =0;
			s_left =rcRoll.right;
			szText[0] =0;
			SetTimer(hWnd, 1, 1000, NULL);
			hBmpCaption =LoadBitmap(ghInstance, MAKEINTRESOURCE(IDB_CAPTION));
			//hBmpCaption =LoadBitmap(ghInstance, MAKEINTRESOURCE(IDB_CX));
			GetObject(hBmpCaption, sizeof(BITMAP), &bmp);			
		break;
		
		case WM_USER+1:
			if((long)lParam !=0L) break;
			strcpy(temp, szDataPath);
			strcat(temp, "\\zx.txt");
	    	hfZx =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);		
			if(hfZx ==HFILE_ERROR) break;			
			_llseek(hfZx, 0, SEEK_SET);
			file_len =_llseek(hfZx, 0, SEEK_END);
			if(file_len <=0)
			{   
				_lclose(hfZx);
			 	break;
			}
			if(file_len <=total_len)
			{
				_llseek(hfZx, 0, SEEK_SET);
				total_len =0;
			}
			else _llseek(hfZx, total_len, SEEK_SET);
			
			read_len =1000;
			if(read_len > file_len-total_len)
				read_len =(int)(file_len-total_len);
			szText[0] =0;
			_lread(hfZx, szText, read_len);
			total_len +=read_len;
			
			szText[read_len] =0;
			hDC =GetDC(hWnd);
			dw =GetTextExtent(hDC, szText, strlen(szText));
			ReleaseDC(hWnd, hDC);
			s_width =LOWORD(dw);
			_lclose(hfZx);
			SendMessage(hWnd, WM_TIMER, 0, 0L);
			//_lclose(hfZx);
		break;
		case WM_USER+2:
			GetClientRect(hWnd, &rc);
			hDC =GetDC(hWnd);
			GetTextMetrics(hDC, &tm);
			SetTextColor(hDC, RGB(255, 0, 65));
			SetBkColor(hDC,RGB(200, 200, 200));
			
			ExtTextOut(hDC,s_left,(rc.bottom-tm.tmHeight)/2,ETO_CLIPPED,&rcRoll,
				szText,strlen(szText),(LPINT) NULL);	
				
			ReleaseDC(hWnd,hDC);
		break;
		case WM_TIMER:
		    KillTimer(hWnd, 1);
			if(szText[0]==0)
			{   
				if(IsSzRead&&IsShRead)
				{
					UDP_Send_Zx();
					SendMessage(hWnd, WM_USER+1, 0, 0L);
				}
				SetTimer(hWnd, 1, 1000*30, NULL);
				break;
			}
			if(times_num ++>5000) //10 minutes  //60
			{
				if(HqTime[0].fRunning)
					UDP_Send_Zx();
				times_num =0;
			}
			
			s_left -=1;
			SendMessage(hWnd, WM_USER+2, 0, 0L);
			if(s_width + s_left ==rcRoll.left)			
			{
			 	s_left =rcRoll.right;
			 	SetTimer(hWnd, 1, 8000,NULL);
			}
			else
				SetTimer(hWnd, 1, 100,NULL);
		break;

		case WM_RBUTTONDOWN:
		    if(IsWindowVisible(ghWndHq))
		    {
				SendMessage(ghWndHq, WM_KEYDOWN, VK_PRIOR, 0L);
			}		      
		break;
		case WM_LBUTTONDOWN:		      
			t_left =(unsigned int)DrawTime(-1);
			if(LOWORD(lParam)>(t_left-bmp.bmWidth)/2&&LOWORD(lParam)<t_left)
		    {
		    	hDC =GetDC(hWnd);
		    	GetClientRect(hWnd, &rc);
		    	hPen=CreatePen(PS_SOLID,1,RGB(65,65,65));		    	
		    	SelectObject(hDC,hPen);
		    	MoveTo(hDC,(t_left-bmp.bmWidth)/2,(rc.bottom -bmp.bmHeight)/2);
		    	LineTo(hDC,(t_left-bmp.bmWidth)/2,(rc.bottom +bmp.bmHeight)/2);
		    	MoveTo(hDC,(t_left-bmp.bmWidth)/2,(rc.bottom -bmp.bmHeight)/2);
		    	LineTo(hDC,(t_left+bmp.bmWidth)/2,(rc.bottom -bmp.bmHeight)/2);		    	
		    	SelectObject(hDC,GetStockObject(WHITE_PEN));
		    	MoveTo(hDC,(t_left+bmp.bmWidth)/2-1,(rc.bottom +bmp.bmHeight)/2-1);
		    	LineTo(hDC,(t_left-bmp.bmWidth)/2-1,(rc.bottom +bmp.bmHeight)/2-1);
		    	MoveTo(hDC,(t_left+bmp.bmWidth)/2-1,(rc.bottom +bmp.bmHeight)/2-1);
		    	LineTo(hDC,(t_left+bmp.bmWidth)/2-1,(rc.bottom -bmp.bmHeight)/2-1);
		    	DeleteObject(hPen);
		    	ReleaseDC(hWnd, hDC);
		    	SendMessage(ghWndHq,WM_KEYDOWN,VK_ESCAPE,0L);
		    }  			
		//break;		
		case WM_LBUTTONUP:
			t_left =(unsigned int)DrawTime(-1);
			if(LOWORD(lParam)>(t_left-bmp.bmWidth)/2&&LOWORD(lParam)<t_left)
		    {
		    	hDC =GetDC(hWnd);
		    	GetClientRect(hWnd, &rc);
		    	SelectObject(hDC,GetStockObject(WHITE_PEN));
		    	MoveTo(hDC,(t_left-bmp.bmWidth)/2,(rc.bottom -bmp.bmHeight)/2);
		    	LineTo(hDC,(t_left-bmp.bmWidth)/2,(rc.bottom +bmp.bmHeight)/2);
		    	MoveTo(hDC,(t_left-bmp.bmWidth)/2,(rc.bottom -bmp.bmHeight)/2);
		    	LineTo(hDC,(t_left+bmp.bmWidth)/2,(rc.bottom -bmp.bmHeight)/2);		    	
		    	hPen=CreatePen(PS_SOLID,1,RGB(65,65,65));		    	
		    	SelectObject(hDC,hPen);
		    	MoveTo(hDC,(t_left+bmp.bmWidth)/2-1,(rc.bottom +bmp.bmHeight)/2-1);
		    	LineTo(hDC,(t_left-bmp.bmWidth)/2-1,(rc.bottom +bmp.bmHeight)/2-1);
		    	MoveTo(hDC,(t_left+bmp.bmWidth)/2-1,(rc.bottom +bmp.bmHeight)/2-1);
		    	LineTo(hDC,(t_left+bmp.bmWidth)/2-1,(rc.bottom -bmp.bmHeight)/2-1);
		    	SelectObject(hDC,GetStockObject(WHITE_PEN));
		    	DeleteObject(hPen);
		    	ReleaseDC(hWnd, hDC);
		    }  			
		break;		
		case WM_PAINT:
			GetClientRect(hWnd, &rc);
			BeginPaint(hWnd, &ps);
			GetTextMetrics(ps.hdc, &tm);
            
			hPen=CreatePen(PS_SOLID,1,RGB(65,65,65));
			SelectObject(ps.hdc,hPen);
			MoveTo(ps.hdc,SCROLL_X_COOR-1,(rc.bottom-tm.tmHeight)/2-2); //����
			LineTo(ps.hdc,SCROLL_X_COOR-1,rc.bottom-(rc.bottom-tm.tmHeight)/2+2);
			MoveTo(ps.hdc,SCROLL_X_COOR-1,(rc.bottom-tm.tmHeight)/2-2);
			LineTo(ps.hdc,rc.right-4,(rc.bottom-tm.tmHeight)/2-2);

			SelectObject(ps.hdc,GetStockObject(WHITE_PEN));
			MoveTo(ps.hdc,rc.right-4,(rc.bottom-tm.tmHeight)/2-2);
			LineTo(ps.hdc,rc.right-4,rc.bottom-(rc.bottom-tm.tmHeight)/2+2);		
			MoveTo(ps.hdc,SCROLL_X_COOR-1,rc.bottom-(rc.bottom-tm.tmHeight)/2+2);
			LineTo(ps.hdc,rc.right-4,rc.bottom-(rc.bottom-tm.tmHeight)/2+2);	
            
			//SetTextColor(ps.hdc, RGB(255, 0, 65));
			//SetBkColor(ps.hdc,RGB(200, 200, 200));
			//SetBkMode(ps.hdc, TRANSPARENT);			
			
			//ExtTextOut(ps.hdc,s_left,(rc.bottom-tm.tmHeight)/2,ETO_CLIPPED,&rcRoll,
			//	szText,strlen(szText),(LPINT) NULL);	
			SelectObject(ps.hdc,GetStockObject(WHITE_PEN));
			
			t_left = DrawTime(-1);
			ShowBmp(ps.hdc,hBmpCaption,(t_left-bmp.bmWidth)/2,
				(rc.bottom -bmp.bmHeight)/2,bmp.bmWidth,rc.bottom);
				
			DispQsName(JyQs,RsaOk);
				
			DeleteObject(hPen);
			EndPaint(hWnd, &ps);
		break;
		case WM_DESTROY:
			if(hBmpCaption) DeleteObject(hBmpCaption);
			KillTimer(hWnd, 1);
		break;
		
		default:
		break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

int DrawTime(int ret)
{
	HDC hDC;
	RECT rc;
    HPEN hPen;
    int x0,y0,x1,y1;
    char temp[20];
    DWORD dw;
    
	if(ret>=0) return(0);
	hDC =GetDC(ghWndCaption);
	GetClientRect(ghWndCaption, &rc);
	SetTextColor(hDC,RGB(0,0,255));
		
	SetBkColor(hDC,RGB(200,200,200));
	
	_strtime(temp);
	dw=GetTextExtent(hDC,temp,strlen(temp));
	y0=(rc.bottom-HIWORD(dw))/2;
	y1=rc.bottom-y0;	
	x1=TIMER_X_COOR-4;
	x0=x1-LOWORD(dw);

	hPen=CreatePen(PS_SOLID,1,RGB(65,65,65));
	SelectObject(hDC,hPen);				
	MoveTo(hDC,x0-1,y0-2); //����
	LineTo(hDC,x0-1,y1+2);	     
	MoveTo(hDC,x0-1,y0-2);
	LineTo(hDC,x1+1,y0-2);
	
	SelectObject(hDC,GetStockObject(WHITE_PEN));
	MoveTo(hDC,x1+1,y0-2);
	LineTo(hDC,x1+1,y1+2);		
	MoveTo(hDC,x0-1,y1+2);
	LineTo(hDC,x1+1,y1+2);

	SelectObject(hDC,GetStockObject(GRAY_BRUSH));
	TextOut(hDC,x0,y0,temp,strlen(temp));
	
	SelectObject(hDC,GetStockObject(WHITE_PEN));
	DeleteObject(hPen);	
	ReleaseDC(ghWndCaption, hDC);
	return (x0);
}

extern ZQSXX Qsxx;

void DispQsName(int JyQs,int color)
{
	char temp[20];
	HDC hdc;
	HPEN hpen;
    DWORD dw;
	RECT rc;
	int x0,x1,y0,y1;
	
	memset(temp,' ',18);
	if(JyQs!=0&&Qsxx.zqsjc[JyQs-1][0]!=0) 
		strcpy(temp,Qsxx.zqsjc[JyQs-1]);
	
	hdc =GetDC(ghWndCaption);
	GetClientRect(ghWndCaption, &rc);
	dw =GetTextExtent(hdc,temp,strlen(temp));	
	y0=(rc.bottom-HIWORD(dw))/2;
	y1=rc.bottom-y0;	
	x0=TIMER_X_COOR;
	x1=SCROLL_X_COOR-4;
	
	hpen=CreatePen(PS_SOLID,1,RGB(65,65,65));	
	SelectObject(hdc,hpen);				
	MoveTo(hdc,x0-1,y0-2); //����
	LineTo(hdc,x0-1,y1+2);	     
	MoveTo(hdc,x0-1,y0-2);
	LineTo(hdc,x1+1,y0-2);
	
	SelectObject(hdc,GetStockObject(WHITE_PEN));
	MoveTo(hdc,x1+1,y0-2);
	LineTo(hdc,x1+1,y1+2);		
	MoveTo(hdc,x0-1,y1+2);
	LineTo(hdc,x1+1,y1+2);
                                             
    if(color ==0)
		SetTextColor(hdc,RGB(0,255,0));
	if(color ==1)
		SetTextColor(hdc,RGB(255,255,0));
	SetRect(&rc,x0,	y0, x1,y1);	
	if(JyQs !=0)
	{
		SetBkColor(hdc,RGB(200,200,200));
		ExtTextOut(hdc,x0+1,y0,ETO_CLIPPED,&rc,temp,strlen(temp),(LPINT) NULL);	
	}
	else
		FillRect(hdc,&rc,GetStockObject(LTGRAY_BRUSH));
	DeleteObject(hpen);	
	ReleaseDC(ghWndCaption, hdc);
	 
}
