#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "fx.h"

extern LPFX  Fx;

/*
	BIAS:������
	BIAS =(ZJJG -N��ƽ��ZJJG)/N��ƽ��ZJJG
*/

int CreateBiasData(K_DATA *lpKData,int RNum,DATA *Data,PARA *Para)
{
    
	int i,j;
    static double Tun[2],Tdn[2];
    static double Ttr,Tpdm,Tndm,Tadx;
    static int Trise;
	BIAS_DATA *BiasData;
	
	BiasData=(BIAS_DATA*)_fmalloc(sizeof(BIAS_DATA)*RNum);
	memset(BiasData,0,sizeof(BIAS_DATA)*RNum);
	for(j=0;j<RNum;j++)
	{    
    		if(j==0)	
    		{
    			Ttr=0;
    			BiasData[j].bias=0;
    			Para->price[0]=0;
    		}
    		else
    		{
    			if(j<=Para->periods[0]-1)
    			{        
    			    BiasData[j].bias=0;
    				Ttr+=lpKData[j].ss;
    			}
    			
    			if(j==Para->periods[0]-1)
    			{
                    //Ttr=Ttr/Para->periods[0];
                    //Para->price[0]=BiasData[j].bias=Ttr*100.00;
                    Para->price[0]=BiasData[j].bias=
                    	(lpKData[j].ss -Ttr/Para->periods[0])*100.00/(Ttr/Para->periods[0]);
    			}
    			
    			if(j>Para->periods[0]-1)
    			{
    			    //Ttr+=(double)lpKData[j].ss/(double)Para->periods[0]-
    			    //     (double)lpKData[j-Para->periods[0]].ss/(double)Para->periods[0];
    			         
    			    Ttr+=lpKData[j].ss-lpKData[j-Para->periods[0]].ss;    			         
    				//BiasData[j].bias=((double)(lpKData[j].ss-Ttr)*100.00/Ttr);
                    BiasData[j].bias=
                    	(lpKData[j].ss -Ttr/Para->periods[0])*100.00/(Ttr/Para->periods[0]);
    				
    				if(Para->price[0]<BiasData[j].bias)
    					Para->price[0]=BiasData[j].bias;
    			}    			
    		}
    }

    for(j=0;j<10;j++)
    {
        if(Data->v==NULL) 
        	break;
    	if(Data->v[j]!=NULL)
    	{
    		_ffree(Data->v[j]);
    		Data->v[j]=NULL;
    	}
    }
    Data->v==NULL;
    Data->num =Para->dnum; 
    Data->no =Para->no;
    strcpy(Data->gpdm,Fx->gpdm);
    Data->type =Fx->type;
    Data->range =Fx->range;
    Data->size =RNum;
    for(j=0;j<Data->num;j++)
    	Data->v[j]=(double *)_fmalloc(sizeof(double)*RNum);
    for(i=0;i<Data->num;i++)
    {
    	for(j=0;j<RNum&&i==0;j++) 
    		Data->v[i][j]=BiasData[j].bias;
    	Data->method[i]=CURVE_METHOD;
    }
    Para->feature |=DW_ALL;
    _ffree(BiasData);
	return TRUE;
}


