#include <windows.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "hq.h"
#include "hq_cl.h"
#include "jlt.h"
#include "toolbar.h"

#define JLT_CLASS	"CJLT"

extern HINSTANCE ghInstance;
extern HWND ghWndMain, ghWndJlt;
extern BOOL ErrMsg(HWND, LPSTR);
extern int UDP_Client_GMin10();

BOOL RegisterJlt(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	
	wc.lpfnWndProc =JltWndProc;
	wc.lpszClassName =JLT_CLASS;
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = ghInstance;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

extern int CapHig;

BOOL CreateWndJlt(HWND hWnd)
{                          
	int x, y;
	HWND hwnd;
	RECT rc;
	
	GetClientRect(ghWndMain, &rc);	
	x =rc.right -rc.left;
	y =rc.bottom -rc.top;
	
	if(ghWndJlt ==NULL)
	{
		hwnd =CreateWindow(JLT_CLASS, NULL, WS_CHILD|WS_CLIPSIBLINGS,
						0,
						STATUS_HEIGHT+TOOLBAR_HEIGHT+(y-STATUS_HEIGHT*2-TOOLBAR_HEIGHT-20)*3/5 ,
						x*2/3+30,
						(y-STATUS_HEIGHT*2-TOOLBAR_HEIGHT -20)*2/5,
						hWnd, NULL, ghInstance, NULL);
		if(hwnd ==NULL)
		{
			ErrMsg(hWnd, "���ܽ�����������ʾ����");
			return FALSE;
		}
	
		ghWndJlt =hwnd;
	}
	else
	{
		SetWindowPos(ghWndJlt, (HWND) NULL, 
			0, 
			STATUS_HEIGHT+TOOLBAR_HEIGHT+(y-STATUS_HEIGHT*2-TOOLBAR_HEIGHT -20)*3/5 ,
			x*2/3+30, 
			(y-STATUS_HEIGHT*2-TOOLBAR_HEIGHT -20)*2/5,
			NULL);	
	}
	return TRUE;
}

extern int DrawTimeLines(HWND hWnd,HDC, LPRECT, BOOL);
extern int DrawJlt(HDC, LPRECT);
int	UDP_Send_GMin00(int, int);
LRESULT CALLBACK JltWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	char tmp[256];
	PAINTSTRUCT ps;
	DWORD dw;
	int x, y;
	RECT rc;
	
	switch(message)
	{
		case WM_SETFOCUS:
			SetFocus(ghWndMain);
		break;
		
		case WM_CREATE:
		break;
		case WM_SIZE:
			if(IsWindowVisible(hWnd))
				InvalidateRect(hWnd, NULL, TRUE);		
		break;
		case WM_PAINT:
			BeginPaint(hWnd, &ps);
			GetClientRect(hWnd, &rc);
			strcpy(tmp, HqData[HqPaintData.jys].lpPreData[
					HqPaintData.sortData.key[
					HqPaintData.curRecNum+HqPaintData.curSelRec]].zqmc);
			dw =GetTextExtent(ps.hdc, tmp, strlen(tmp));
			x =LOWORD(dw); y =HIWORD(dw);
			SetBkColor(ps.hdc, RGB(0, 0, 0));
			
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			SetTextColor(ps.hdc, RGB(255, 255, 255));			
			rc.left =50; rc.right -=30;
			rc.top =y+5; rc.bottom -=30;
			DrawTimeLines(hWnd,ps.hdc, &rc, TRUE);
			rc.bottom --;
			DrawJlt(ps.hdc, &rc);
			EndPaint(hWnd, &ps);
		break;
		case WM_DESTROY:
		break;
		
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}
