#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "fx.h"

extern LPFX Fx;

int CreateWrData(K_DATA *lpKData,int RNum,DATA *Data,PARA *Para)
{   
	int i,j,k,l;
    double jia1,jia2;
	WR_DATA *WrData;
	
	WrData=(WR_DATA*)_fmalloc(sizeof(WR_DATA)*RNum);
	memset(WrData,0,sizeof(WR_DATA)*RNum);
	for(j=0;j<RNum;j++)
	{
    		if(j==0)	
    		{
    			Para->price[0]=0;
    			for(k=0;k<3;k++)
    				WrData[j].wr[k]=0;
    		}
    		else
    		{
    			for(k=0;k<3;k++)
    			{
    			 	if(j>=Para->periods[k]-1&&Para->periods[k]!=0)
    			 	{
    			 		for(l=1;l<=Para->periods[k];l++)    
    			 		{
    			 			if(l==1) 
    			 			{
    			 				jia1=lpKData[l+j-Para->periods[k]].zg;
    			 				jia2=lpKData[l+j-Para->periods[k]].zd;
    			 			}
    			 			else
    			 			{
    			 			 	if(jia1<lpKData[l+j-Para->periods[k]].zg)
    			 			 		jia1=lpKData[l+j-Para->periods[k]].zg;
    			 			 	if(jia2>lpKData[l+j-Para->periods[k]].zd)
    			 			 		jia2=lpKData[l+j-Para->periods[k]].zd;
    			 			}	
    			 		}
    			 		if(jia1==jia2) jia1=jia2+0.002;
    			 		WrData[j].wr[k]=(jia1-lpKData[j].ss)*100.00/(jia1-jia2);
    			 	}
    			 	else
    			 	{
    			 	 	WrData[j].wr[k]=0;
    			 	}
    			}
    		}
    }

    for(j=0;j<10;j++)
    {
        if(Data->v==NULL) 
        	break;
    	if(Data->v[j]!=NULL)
    	{
    		_ffree(Data->v[j]);
    		Data->v[j]=NULL;
    	}
    }    
    Data->v==NULL;     
    Data->num =Para->dnum; 
    Data->no =Para->no;
    strcpy(Data->gpdm,Fx->gpdm);
    Data->type =Fx->type;
    Data->range =Fx->range;
    Data->size =RNum;
    for(j=0;j<Data->num;j++)
    	Data->v[j]=(double *)_fmalloc(sizeof(double)*RNum);
    for(i=0;i<Data->num;i++)
    {
    	for(j=0;j<RNum;j++) 
    		Data->v[i][j]=WrData[j].wr[i];
    	Data->method[i]=CURVE_METHOD;
    }
    Para->price[0] =100;
    Para->price[1] =0;
    //Para->price[2] =10;
    //Para->price[3] =90;
    Para->feature |=DW_ALL;
    Para->feature &=~DW_MAX;
    Para->feature &=~DW_MIN;    
    _ffree(WrData);
	return TRUE;
}

