#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "resource.h"
#include "global.h"           		
#include "hq.h"
#include "hq_cl.h"
#include "xlt.h"
#include "fx.h"
#include "jy_cl.h"
#include "appmain.h"
#include "toolbar.h"

#define XLT_CLASS	"CXLT"

extern int LoadFile(char *filename,int sline,char *title);

extern HINSTANCE ghInstance;
extern HWND ghWndMain, ghWndXlt, ghWndCj, ghWndMaxMin, ghWndLitHq, ghWndZs, ghWndHelp,ghWndToolBar;
extern HMENU ghMenuGraph;
extern char szDataPath[128];
extern BOOL ErrMsg(HWND, LPSTR);
extern int DrawXlt(HDC, LPRECT);

extern LPFX Fx;
extern int FxInit(LPFX Fx);
extern int UDP_Send_DataDay(int jys,int rec_num);
extern int UDP_Send_Stock_Info(STOCK_INFO_FRAME *StockInfoFrame);

extern int DlgJy(void);
extern JY_ANS_CHKUSR curChkUsrRes;
extern int gfOnLine ,gfConnecting ,gfDelete;

BOOL RegisterXlt(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	
	wc.lpfnWndProc =XltWndProc;
	wc.lpszClassName =XLT_CLASS;
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = ghInstance;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

extern  int CapHig;

BOOL CreateWndXlt(HWND hWnd)
{                          
	int x, y;
	HWND hwnd;
	RECT rc;
		           
    GetClientRect(ghWndMain, &rc);
	x =rc.right -rc.left;
	y =rc.bottom -rc.top;
	
	if(ghWndXlt ==NULL)
	{
		hwnd =CreateWindow(XLT_CLASS, NULL, WS_CHILD|WS_CLIPSIBLINGS,
				0, 
				STATUS_HEIGHT+TOOLBAR_HEIGHT, 
				x*2/3+30, 
				(y-STATUS_HEIGHT*2- TOOLBAR_HEIGHT -20)*3/5,
				hWnd, NULL, ghInstance, NULL);
	
		if(hwnd ==NULL)
		{
			ErrMsg(hWnd, "���ܽ�����ʱ��ͼ");
			return FALSE;
		}
		ghWndXlt =hwnd;
	}
	else
	{   
		SetWindowPos(ghWndXlt, (HWND) NULL, 
			0, 
			STATUS_HEIGHT+TOOLBAR_HEIGHT, 
			x*2/3+30, 
			(y-STATUS_HEIGHT*2-TOOLBAR_HEIGHT -20)*3/5 ,
			NULL);
	}

	return TRUE;
}

extern int DrawTimeLines(HWND hWnd,HDC hDC, LPRECT rc, BOOL);
extern int DrawVLine(int);

extern BOOL fVLineDrawed;                         
extern HMENU ghMenuHq;
extern HWND hWndInput;
extern BOOL IsZsRec(int, int);
extern int UDP_Send_Gra00(int jys, int rec_num);

int graphTop =0;

LRESULT CALLBACK XltWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	char tmp[256],temp[256];
	PAINTSTRUCT ps;
	DWORD dw;
	int i, j, x, y;
	RECT rc;
	static int total_times =0,reload=0;
	static clock_t MouDownClk;
	STOCK_INFO_FRAME StockInfo;
	
	switch(message)
	{
		case WM_CREATE:
			MouDownClk=clock();
		break;
		case WM_SETFOCUS:
			if(fVLineDrawed)
			{
				DrawVLine(0);
				fVLineDrawed =FALSE;
			}
			SetFocus(ghWndMain);
		break;
		case WM_KILLFOCUS:
			if(fVLineDrawed)
			{
				DrawVLine(0);
				fVLineDrawed =FALSE;
			}
		break;

		case WM_LBUTTONDOWN:
			if(clock()-MouDownClk<240)
				PostMessage(hWnd,WM_KEYDOWN,VK_RETURN,0L);
			MouDownClk=clock();
		break;
		
		case WM_RBUTTONDOWN:
			SendMessage(hWnd, WM_KEYDOWN, VK_ESCAPE, 0L);
		break;				        
		case WM_SIZE:
			if(IsWindowVisible(hWnd))
				InvalidateRect(hWnd, NULL, TRUE);
		break;		
		case WM_COMMAND:
			SendMessage(ghWndMain, WM_COMMAND, wParam, lParam);
		break;
		case WM_TIMER:
			if(wParam==1)
			{
				KillTimer(hWnd,1);
				if(IsWindowVisible(hWnd))
			    	sprintf(StockInfo.name,"%s",HqData[GraphData.jys].lpPreData[GraphData.recNum].zqdm);
			    else if(IsWindowVisible(ghWndFx))
			    	sprintf(StockInfo.name,"%s",Fx->gpdm);			    	
			    else
			    {
					i =HqPaintData.sortData.key[HqPaintData.curSelRec+HqPaintData.curRecNum];					
					sprintf(StockInfo.name,"%s",HqData[HqPaintData.jys].lpPreData[i].zqdm);
			    }	
			    sprintf(tmp,"%s\\%s.txt",szDataPath,StockInfo.name);
				if((i=LoadFile(tmp,0,""))==0)
				{
					reload++;
					if(reload>20)
					{
					//	ErrMsg(NULL,"�ù�����Ϣ");
						reload=0;
					}
					//else
					//	SetTimer(hWnd,1,1000,NULL);	
				}	
			}	
		break;
		case WM_PAINT:
			BeginPaint(hWnd, &ps);
			GetClientRect(hWnd, &rc);
			SetTextColor(ps.hdc, RGB(255, 0, 255));
			SetBkColor(ps.hdc, RGB(0, 0, 0));
			strcpy(tmp, HqData[GraphData.jys].lpPreData[GraphData.recNum].zqmc);
			TextOut(ps.hdc, 2, 2, tmp, strlen(tmp));
			//SelectObject(ps.hdc,GetStockObject(ANSI_FIXED_FONT));
			dw =GetTextExtent(ps.hdc, tmp, strlen(tmp));
			x =LOWORD(dw); y =HIWORD(dw);			
			SetTextColor(ps.hdc, RGB(255, 255, 0));
			
			if((int)(GraphData.GraHead.dateNum/100)!=0)
			{
				wsprintf(tmp, "%2d��%2d��", GraphData.GraHead.dateNum/100,
							GraphData.GraHead.dateNum%100);
				TextOut(ps.hdc, x+1, 2, tmp, strlen(tmp));
			}
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			
			rc.left =50; 
			rc.right -=30;
			rc.top =y+10;
			graphTop =rc.top;
			DrawTimeLines(hWnd,ps.hdc, &rc, FALSE);			
			rc.bottom --;
			DrawXlt(ps.hdc, &rc);
			EndPaint(hWnd, &ps);
		break;

		case WM_READ_OK:
			if(fVLineDrawed)
			{
				DrawVLine(0);
				fVLineDrawed =FALSE;
			}
			if(wParam)
				InvalidateRect(hWnd, NULL, TRUE);
			else InvalidateRect(hWnd, NULL, FALSE);
		break;
        
		case WM_KEYDOWN:
			switch(wParam)
			{   
			    case VK_F1:
			    	ShowWindow(ghWndHelp,SW_SHOW);
					sprintf(tmp,"%s\\help.txt",szDataPath);			    	
			    	LoadFile(tmp,0,"����/[ESC]�˳�");
			    break;	
			    case VK_F2:
           			SendMessage(ghWndMain,WM_COMMAND,IDM_JY,NULL);				    	
				break;
			    case VK_F3:
			    	StockInfo.type=FILE_STOCK_INFO;			    	
					if(IsWindowVisible(hWnd))
			    		sprintf(StockInfo.name,"%s",HqData[GraphData.jys].lpPreData[GraphData.recNum].zqdm);
			    	else if(IsWindowVisible(ghWndFx))
			    		sprintf(StockInfo.name,"%s",Fx->gpdm);
			    	else
			    	{
						i =HqPaintData.sortData.key[HqPaintData.curSelRec+HqPaintData.curRecNum];
						sprintf(StockInfo.name,"%s",HqData[HqPaintData.jys].lpPreData[i].zqdm);
			    	}	
			    		
			    	sprintf(tmp,"%s\\%s.txt",szDataPath,StockInfo.name);
			    	if(gfOnLine) unlink(tmp);
			    	
			    	UDP_Send_Stock_Info(&StockInfo);
			    	
					ShowWindow(ghWndHelp,SW_SHOW);
					sprintf(temp,"������Ϣ%s/[ESC]�˳�",StockInfo.name);
					if((i=LoadFile(tmp,0,temp))==0)
					{       
						reload=0;
						SetTimer(hWnd,1,1000,NULL);
					}
			    break;
				case VK_F12:
				    StockInfo.type=FILE_LIST_DIR;
				    strcpy(StockInfo.name,"");
			    	sprintf(tmp,"%s\\%s",szDataPath,"news.idx");
			    	if(gfOnLine) unlink(tmp);
			    	UDP_Send_Stock_Info(&StockInfo);
			    	
			    	if(!IsWindowVisible(ghWndHelp))
						ShowWindow(ghWndHelp,SW_SHOW);
					else
					    SetFocus(ghWndHelp);
					LoadFile(tmp,0,"���Ź���/[ESC]�˳�");
				break;			    
				
				case VK_PRIOR:
				
				        i =GraphData.recNum;
				        j =GraphData.jys;
				        if(i>0)
				       	{   
				       	    i--;
							SetWindowText(hWndInput, HqData[j].lpPreData[i].zqdm);
							SendMessage(hWnd, WM_KEYDOWN, VK_RETURN, 0L);
						}
				break;
				case VK_NEXT:
				        i =GraphData.recNum;
				        j =GraphData.jys;
				        if(i <HqData[j].recCount-1)
				        {
				        	i++;
							SetWindowText(hWndInput, HqData[j].lpPreData[i].zqdm);				
							SendMessage(hWnd, WM_KEYDOWN, VK_RETURN, 0L);
						}
				break;
				case VK_RETURN:
					if(HqData[GraphData.jys].recCount <=0) break;
					if(fVLineDrawed)
						SendMessage(hWnd, WM_KILLFOCUS, 0, 0L);
					strcpy(tmp,"");
					GetWindowText(hWndInput, &tmp[0], sizeof(tmp));
					/*
						��ʱͼ�س�������ʷ����ͼ
					*/
					if(tmp[0] ==0)
					{
						ShowWindow(hWnd, SW_HIDE);
						ShowWindow(ghWndJlt, SW_HIDE);
						
						ShowWindow(ghWndZs, SW_HIDE);
						ShowWindow(ghWndMmp, SW_HIDE);
						ShowWindow(ghWndCj, SW_HIDE);
						ShowWindow(ghWndMaxMin, SW_HIDE);
						ShowWindow(ghWndLitHq, SW_HIDE);
						
                        strcpy(Fx->gpdm, HqData[GraphData.jys].lpPreData[GraphData.recNum].zqdm);
                        strcpy(Fx->gpmc, HqData[GraphData.jys].lpPreData[GraphData.recNum].zqmc);
		
                        for(i=IDM_FX_MACD;i<=IDM_FX_KDJ;i++)
                        {
                             if(GetMenuState(ghMenuMain, i, MF_BYCOMMAND)&MF_CHECKED)
                             	break;
                        }
                        if(i<=IDM_FX_KDJ)
                        	Fx->type = i;
                        else
                        {
                        	if(Fx->type==0)
                            	Fx->type=IDM_FX_MACD;
                        }
                        UDP_Send_DataDay(GraphData.jys,GraphData.recNum);
                        ShowWindow(ghWndFx,SW_SHOW);
                        InvalidateRect(ghWndFx, NULL, TRUE);
                        SetFocus(ghWndFx);
                    }
					else
					{
						for(j =0; j<2; j++)
						{
							for(i =0; i<HqData[j].recCount; i++)
							{
								if(!strcmp(HqData[j].lpPreData[i].zqdm, tmp))
									break;
							}
							if(i <HqData[j].recCount) break;
						}
						
						if(j<2 && i <HqData[j].recCount)
						{
							GraphData.minEnd =0;
							GraphData.jys =j;
							GraphData.recNum =i;
							MmpData.jys =j;
							MmpData.recNum =i;
							
							if(fVLineDrawed)
							{
								DrawVLine(0);
								fVLineDrawed =FALSE;
							}
							UDP_Send_Gra00(j, i);							
							InvalidateRect(hWnd, NULL, TRUE);
							InvalidateRect(ghWndJlt, NULL, TRUE);
							InvalidateRect(ghWndLitHq, NULL, TRUE);
							InvalidateRect(ghWndMmp, NULL, TRUE);
							
							if(IsZsRec(j, i))
							{
								if(!IsWindowVisible(ghWndZs))
								{
									ShowWindow(ghWndZs, SW_SHOW);
									ShowWindow(ghWndMmp, SW_HIDE);
									ShowWindow(ghWndCj, SW_HIDE);
									ShowWindow(ghWndMaxMin, SW_SHOW);
								}
							}
							else
							{
								if(IsWindowVisible(ghWndZs))
								{
									ShowWindow(ghWndZs, SW_HIDE);
									ShowWindow(ghWndMmp, SW_SHOW);
									ShowWindow(ghWndCj, SW_SHOW);
									ShowWindow(ghWndMaxMin, SW_HIDE);
								}
								SendMessage(ghWndCj, WM_READ_OK, 0, 0L);
							}
						}
						SetWindowText(hWndInput, "");
					}
				break;
				case VK_F6:
				case VK_ESCAPE:
					if(fVLineDrawed)
					{
						SendMessage(hWnd, WM_KILLFOCUS, 0, 0L);
						break;
					}
					ShowWindow(hWnd, SW_HIDE);
					ShowWindow(ghWndJlt, SW_HIDE);
					ShowWindow(ghWndCj, SW_HIDE);
					ShowWindow(ghWndMaxMin, SW_HIDE);
					ShowWindow(ghWndLitHq, SW_HIDE);
					ShowWindow(ghWndZs, SW_HIDE);
					ShowWindow(ghWndMmp, SW_HIDE);
					
					ShowWindow(ghWndHq, SW_SHOW);
					KillTimer(ghWndHq, 5);
					SetTimer(ghWndHq, 5, 1000, NULL);
				break;
				case VK_LEFT:
					DrawVLine(-1);
				break;
				case VK_RIGHT:
					DrawVLine(1);
				break;
				case VK_UP:
				case VK_DOWN:
					if(IsZsRec(GraphData.jys, GraphData.recNum))
					{
						SendMessage(ghWndZs, WM_KEYDOWN, wParam, lParam);
						SendMessage(ghWndMaxMin, WM_KEYDOWN, wParam, lParam);
					}
					else
						if(IsWindowVisible(ghWndCj))
						{
							SendMessage(ghWndCj, WM_KEYDOWN, wParam, lParam);
						}
			}
		break;
		case WM_DESTROY:
		break;
		
		default:
		break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}
