#include <windows.h>
#include <string.h>

#include "resource.h"
#include "appmain.h"
#include "global.h"
#include "toolbar.h"

typedef struct tag_BtnInfo{
	int bmpNO;
	UINT ID;
	int left, top;   
	BOOL enabled;
} BtnInfo; 

extern HWND ghWndToolBar, ghWndTips;

BtnInfo BtnInfos[]=
{
	{BTN_PLAY, IDM_GRAPH, 5, 2, TRUE},
	{BTN_PAUSE, IDM_JY, 5+BUTTON_WIDTH+1, 2, TRUE},
	{BTN_STOP, IDM_HQ_SZ, 5+2*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_NEXT, IDM_HQ_SH, 5+3*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_PREV, IDM_HQSEL_1, 5+4*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_RECORD, IDM_HQSEL_2, 5+5*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_SELE_3, IDM_HQSEL_3, 5+6*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_SELE_4, IDM_HQSEL_4, 5+7*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_SELE_5, IDM_HQSEL_5, 5+8*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_FX, IDM_FX, 5+9*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_NEWS,IDM_NEWS, 5+10*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_HELP,IDM_HELP, 5+11*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_SZDP,IDM_SZDP, 5+12*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_SHDP,IDM_SHDP, 5+13*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_GGXX,IDM_GGXX, 5+14*(BUTTON_WIDTH+1), 2, TRUE},
	{BTN_EXIT,IDM_EXIT, 5+15*(BUTTON_WIDTH+1), 2, TRUE}
};

//int TOOLBAR_HEIGHT =0;
WORD gState=0;
int count =0;
int CurSelBtn=-1, nMoveIn =-1, nTimes =-1;
RECT rcOld;             
POINT ptOld;
HBITMAP hBmpToolsUp=NULL,hBmpToolsDn=NULL,hBmpToolsDs=NULL;
LRESULT CALLBACK __export ToolsWndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK __export TipsWndProc(HWND, UINT, WPARAM, LPARAM);

int ShowTips(int nID);

#define CTOOLTIPS	"CTOOLTIPS"
#define CTOOLBAR	"CTOOLBAR"

BOOL RegisterToolBar(void)
{
	WNDCLASS wc;

	memset(&wc, 0, sizeof(wc));
	wc.lpfnWndProc =ToolsWndProc;
	wc.hInstance =ghInstance;
	wc.lpszClassName =CTOOLBAR; 
	wc.hbrBackground =GetStockObject(LTGRAY_BRUSH);
	wc.hCursor =LoadCursor(NULL, IDC_ARROW);

	if(!RegisterClass(&wc)) return FALSE;
	
	wc.style =CS_SAVEBITS;
	wc.lpfnWndProc =TipsWndProc;
	wc.lpszClassName =CTOOLTIPS;

	return RegisterClass(&wc);
}


HWND CreateToolBar(HWND hWnd)	
{
	int x, y;
	RECT rc;
	
    GetClientRect(ghWndMain, &rc);			
	x =GetSystemMetrics(SM_CXSCREEN);
	//y =GetSystemMetrics(SM_CYSCREEN)-GetSystemMetrics(SM_CYCAPTION);
	//x =rc.right -rc.left;
	y =rc.bottom -rc.top;	
	count =sizeof(BtnInfos)/sizeof(BtnInfo);
   
    if(ghWndToolBar==NULL)
    {
		ghWndToolBar =CreateWindow(CTOOLBAR, NULL,WS_CHILD|WS_CLIPSIBLINGS,//WS_POPUP,
					0, 
					STATUS_HEIGHT -2, 
					x, 
					BUTTON_HEIGHT+4,
					ghWndMain, NULL, ghInstance, NULL);
    }
	if(!ghWndToolBar) return NULL;
	
    if(ghWndTips==NULL)
    {
		ghWndTips =CreateWindow(CTOOLTIPS, CTOOLTIPS, WS_POPUP|WS_BORDER,
					2, 
					STATUS_HEIGHT-2 +GetSystemMetrics(SM_CYCAPTION),
					20, 
					20, 
					ghWndToolBar, NULL, ghInstance, NULL);
	}
	if(!ghWndTips) return NULL;
	SetWindowPos(ghWndToolBar, HWND_TOPMOST, 
			0, 
			STATUS_HEIGHT -2, 
			0, 
			0,
			SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER);
	
	return ghWndToolBar;
}

long CALLBACK __export ToolsWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{ 
	HPEN hPen;
	RECT rc;
	POINT pt; 
	static HDC hDC =NULL;
	int i;
	HBITMAP hBmp;
	HDC hMemDC; 
	LONG ltmp; 
	WORD wState;
	PAINTSTRUCT ps;     
	
	switch(message)
	{
		case WM_CREATE: 
			hBmpToolsUp = LoadBitmap(ghInstance,MAKEINTRESOURCE(IDB_TOOLSUP));
			if(hBmpToolsUp == NULL)
			{
				ErrMsg(NULL, "error load resource BMP_TOOLSUP");
				DestroyWindow(hWnd);
				return -1;
			}

			hBmpToolsDn = LoadBitmap(ghInstance,MAKEINTRESOURCE(IDB_TOOLSDN));
			if(hBmpToolsDn == NULL)
			{
				ErrMsg(NULL, "error load resource BMP_TOOLSDN");
				DestroyWindow(hWnd);
				return -1;
			}

			hBmpToolsDs = LoadBitmap(ghInstance,MAKEINTRESOURCE(IDB_TOOLSDS));
			if(hBmpToolsDs == NULL)
			{
				ErrMsg(NULL, "error load resource BMP_TOOLSDS");
				DestroyWindow(hWnd);
				return -1;
			}
		break;

		case WM_DRAWBUTTON:
			hBmp = NULL;
			if(CurSelBtn<0)
			{ 
				if( hBmpToolsUp == NULL) return 0L;
				hMemDC = CreateCompatibleDC ((HDC)wParam);
				for(i=0;i<count;i++)
				{
					if(BtnInfos[i].enabled)
						SelectObject (hMemDC, hBmpToolsUp); 
					else SelectObject(hMemDC, hBmpToolsDs);
						
					BitBlt ((HDC)wParam, BtnInfos[i].left, BtnInfos[i].top, 
								BUTTON_WIDTH, BUTTON_HEIGHT,
								hMemDC,1+i*(BUTTON_WIDTH+1) , 1, SRCCOPY) ;
				}
				DeleteDC (hMemDC) ; 
				return 0L;
			}
			else
			{
				if(CurSelBtn>=count) return 0L;
				switch(lParam)
				{
					case 0L:
						hBmp=hBmpToolsUp;
					break;
					case 1L: 
						hBmp=hBmpToolsDn;
					break;
					case 2L: 
						hBmp=hBmpToolsDs;
					break;
				}
				if(hBmp==NULL) return 0L;
				hDC=GetDC(hWnd);
				hMemDC = CreateCompatibleDC (hDC) ;
				SelectObject (hMemDC, hBmp) ;
				BitBlt (hDC, BtnInfos[CurSelBtn].left, BtnInfos[CurSelBtn].top, 
								BUTTON_WIDTH, BUTTON_HEIGHT,
				hMemDC,1+CurSelBtn*(BUTTON_WIDTH+1) , 1, SRCCOPY) ;
				DeleteDC (hMemDC) ; 
				ReleaseDC(hWnd,hDC);   
				hDC =NULL;
			}
		return 0;

		case WM_LBUTTONDOWN:
			pt=MAKEPOINT(lParam);
			KillTimer(hWnd, 1);   
			SendMessage(ghWndStatus, WM_USER+1, 0, 0L);
			//ReleaseCapture();
			if(IsWindowVisible(ghWndTips))
				ShowWindow(ghWndTips, SW_HIDE);   
			nMoveIn =-1;
				
			for(i=0;i<count;i++)
			{
				SetRect(&rc,BtnInfos[i].left,BtnInfos[i].top,
						BtnInfos[i].left+BUTTON_WIDTH,BtnInfos[i].top+BUTTON_HEIGHT);
				if (PtInRect(&rc, pt))
					break;
			} 
			if(i==count)
			{
				CurSelBtn=-1;
				gState |=STATE_NCMOUSEDOWN;
				hDC =GetDC(NULL);
				GetWindowRect(hWnd, &rcOld);
				SelectObject(hDC, GetStockObject(NULL_BRUSH));
				//SelectObject(hDC, GetStockObject(BLACK_PEN));
				SetROP2(hDC, R2_NOT);  
				Rectangle(hDC, rcOld.left, rcOld.top, rcOld.right, rcOld.bottom);
				ptOld =pt;
				ClientToScreen(hWnd, &ptOld);
				rcOld.right -=rcOld.left;
				rcOld.bottom -=rcOld.top;
			}	
			else
			{
				if(BtnInfos[i].enabled ==FALSE) return 0L;
				CurSelBtn=i;
				gState |=STATE_MOUSEDOWN;  
				gState &=~STATE_MOUSEOUT;
				SendMessage(hWnd,WM_DRAWBUTTON,0,1L);
			}
			SetCapture(hWnd);
		return 0L;

		case WM_MOUSEMOVE:   
			pt =MAKEPOINT(lParam);
			if(gState & STATE_NCMOUSEDOWN)
			{                  
				if(!hDC) break;
				Rectangle(hDC, rcOld.left, rcOld.top, rcOld.left+rcOld.right,
									rcOld.top+rcOld.bottom);
				ClientToScreen(hWnd, &pt);
				rcOld.left = rcOld.left +pt.x -ptOld.x;
				rcOld.top = rcOld.top +pt.y -ptOld.y;   
				ptOld.x =pt.x;
				ptOld.y =pt.y;
				Rectangle(hDC, rcOld.left, rcOld.top, rcOld.left+rcOld.right,
									rcOld.top+rcOld.bottom);
				break;
			}
			
			
			if(gState & STATE_MOUSEDOWN)
			{
				SetRect(&rc,BtnInfos[CurSelBtn].left,BtnInfos[CurSelBtn].top,
						BtnInfos[CurSelBtn].left+BUTTON_WIDTH,BtnInfos[CurSelBtn].top+BUTTON_HEIGHT);
				wState=gState;
				if(PtInRect(&rc,pt))
					gState &=~STATE_MOUSEOUT;
				else
					gState |=STATE_MOUSEOUT;
			
				if (wState!=gState)
				{
					if(gState & STATE_MOUSEOUT) ltmp=0L;
					else ltmp=1L;
					SendMessage(hWnd,WM_DRAWBUTTON,0,ltmp);
				}
				break;
			}
			
			for(i=0;i<count;i++)
			{
				SetRect(&rc,BtnInfos[i].left,BtnInfos[i].top,
						BtnInfos[i].left+BUTTON_WIDTH,BtnInfos[i].top+BUTTON_HEIGHT);
				if (PtInRect(&rc, pt))
					break;
			} 
			if(i ==count)
			{
				if(IsWindowVisible(ghWndTips))
				{
					nTimes =5;
					nMoveIn =-1;
				}	
				break;
			}
			if(i ==nMoveIn) break;	
			else
			{
				if(nMoveIn !=i) nTimes =-1;
				if(nTimes ==-1)// && nTimes <5)
				{
					if(!IsWindowVisible(ghWndTips))
						SetTimer(hWnd, 1, 1000, NULL);
					else
						ShowTips(i);
				}
				nTimes =-1;
				nMoveIn =i;
			}
		break;

		case WM_LBUTTONUP: 
			ReleaseCapture();
			if(gState & STATE_NCMOUSEDOWN)
			{
				if(!hDC) break;
				Rectangle(hDC, rcOld.left, rcOld.top, rcOld.left+rcOld.right,
									rcOld.top+rcOld.bottom);
				ReleaseDC(NULL, hDC);
				gState &=~STATE_NCMOUSEDOWN;					
				SetWindowPos(hWnd, 0, rcOld.left, rcOld.top, 0, 0,
							SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
			}
			if(CurSelBtn==-1) return 0L;
			if (gState & STATE_MOUSEDOWN)
			{
				gState &=~STATE_MOUSEDOWN;
				if(!(gState & STATE_MOUSEOUT))
				{
					SendMessage(hWnd,WM_DRAWBUTTON,0,0L);
					SendMessage(ghWndMain,WM_COMMAND,BtnInfos[CurSelBtn].ID,0L);
				} 
				else gState &=~STATE_MOUSEOUT;
			}               
			CurSelBtn=-1;
		return 0L;

		case WM_TIMER:
			if(nTimes++>5 || nMoveIn<0 || nMoveIn >=count)
			{
				KillTimer(hWnd, 1);
				SendMessage(ghWndStatus, WM_USER+1, 0, 0L);
				ShowWindow(ghWndTips, SW_HIDE);
				nTimes =5; 
				//nMoveIn =-1;
				break;
			}        
			GetCursorPos(&pt);
			GetWindowRect(hWnd, &rc);
			if(pt.x < rc.left+5 || pt.y < rc.top+5 ||
				pt.x >rc.right-5 || pt.y > rc.bottom-5)
			{
				KillTimer(hWnd, 1);
				SendMessage(ghWndStatus, WM_USER+1, 0, 0L);
				ShowWindow(ghWndTips, SW_HIDE);
				//nTimes =-1;  
				nMoveIn =-1;
			}	            
			if(nTimes ==0)
				ShowTips(nMoveIn);
		break;
		
		case WM_KEYDOWN:
			SetFocus(ghWndMain);
			SendMessage(ghWndMain, WM_KEYDOWN, wParam, lParam);
		break;
		
		case WM_SYSCOMMAND:
			if(wParam ==SC_KEYMENU)
			{
				SetFocus(ghWndMain);
				SendMessage(ghWndMain, WM_SYSCOMMAND, wParam, lParam);
				return 0L;
			}
		break;
		
		case WM_PAINT: 
			BeginPaint(hWnd,&ps); 
			SelectObject(ps.hdc,GetStockObject(NULL_BRUSH)); 
			hPen=CreatePen(PS_SOLID,1,RGB(80,80,80));
			SelectObject(ps.hdc,hPen);
			GetClientRect(hWnd,&rc);
			Rectangle(ps.hdc,0,0,rc.right,rc.bottom);
			SelectObject(ps.hdc,GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
			MoveTo(ps.hdc,0,rc.bottom-1);
			LineTo(ps.hdc,0,0);
			LineTo(ps.hdc,rc.right-1,0);
			SelectObject(ps.hdc,GetStockObject(BLACK_PEN));
			for(i=0;i<count;i++)
				Rectangle(ps.hdc,BtnInfos[i].left-1,BtnInfos[i].top-1,
			BtnInfos[i].left+BUTTON_WIDTH+1,BtnInfos[i].top+BUTTON_HEIGHT+1);
			SendMessage(hWnd,WM_DRAWBUTTON,(WPARAM)(HDC)ps.hdc,0L);
			EndPaint(hWnd,&ps);
		break; 

		case WM_DESTROY:
			if(hBmpToolsUp) DeleteObject(hBmpToolsUp);
			if(hBmpToolsDn) DeleteObject(hBmpToolsDn);
			if(hBmpToolsDs) DeleteObject(hBmpToolsDs);
		break;
	}
	return (DefWindowProc(hWnd, message, wParam, lParam));
}


HBRUSH ghBrushTips =NULL;
LRESULT CALLBACK _export TipsWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{                                                   
	char tmp[256];
	PAINTSTRUCT ps;
	
	switch(message)
	{
		case WM_CREATE:  
			ghBrushTips =CreateSolidBrush(RGB(127, 127, 65));
			if(ghBrushTips ==NULL)
				return -1;
			SetClassWord(hWnd, GCW_HBRBACKGROUND, (HBRUSH)ghBrushTips);
		break;
		
		case WM_MOUSEMOVE:
			nMoveIn =-1;   
			//nTimes =5;
			ShowWindow(hWnd, SW_HIDE);
		break;
		
		case WM_PAINT:                                
			BeginPaint(hWnd, &ps);
			SetBkMode(ps.hdc, TRANSPARENT);
			GetWindowText(hWnd, tmp, sizeof(tmp));
			TextOut(ps.hdc, 2, 2, tmp, strlen(tmp));
			EndPaint(hWnd, &ps);
		break; 
		
		case WM_DESTROY:                                  
			if(ghBrushTips) DeleteObject(ghBrushTips);
		break;
	}
	return (DefWindowProc(hWnd, message, wParam, lParam));
}

int ShowTips(int nID)
{
	char tmp[256];
	char *tok;
	DWORD dw;                  
	RECT rc;
	HDC hDC;
			
	if(LoadString(ghInstance, BtnInfos[nMoveIn].ID, tmp, sizeof(tmp)))
	{
		tok =strtok(tmp, "\\");
		if(!tok) return -1;
		SendMessage(ghWndStatus, WM_USER+1, 0, (LPARAM)(LPSTR)tok);
		tok =strtok(NULL, "\\");
		if(!tok) return -1;
		SetWindowText(ghWndTips, tok);
		hDC =GetDC(ghWndTips);
		dw =GetTextExtent(hDC, tok, strlen(tok));
		ReleaseDC(ghWndTips, hDC);
		hDC =NULL;                 
		GetWindowRect(ghWndToolBar, &rc);
			ShowWindow(ghWndTips, SW_HIDE);
		SetWindowPos(ghWndTips, 0, 
					rc.left +BtnInfos[nMoveIn].left+4, 
					rc.top+BtnInfos[nMoveIn].top+BUTTON_HEIGHT+10, 
					LOWORD(dw)+4, HIWORD(dw)+4, 
					SWP_NOREDRAW|SWP_NOZORDER|SWP_NOACTIVATE);
		//if(!IsWindowVisible(ghWndTips))
			ShowWindow(ghWndTips, SW_SHOWNA); 
		//InvalidateRect(ghWndTips, NULL, TRUE);    
	}
}

int PushPlay(void)
{
	BtnInfos[BTN_PLAY].enabled =FALSE;
	BtnInfos[BTN_PAUSE].enabled =TRUE;
	BtnInfos[BTN_STOP].enabled =TRUE;
	BtnInfos[BTN_NEXT].enabled =TRUE;
	BtnInfos[BTN_PREV].enabled =TRUE;
	BtnInfos[BTN_RECORD].enabled =TRUE;
	CurSelBtn =-1;
    InvalidateRect(ghWndToolBar, NULL, FALSE);
	//SendMessage(ghDlgPlay, WM_USER+1, 0, (LPARAM)(LPSTR)lpCurNodeID);
	return 0;
}

int PushStop(void)
{
	BtnInfos[BTN_PLAY].enabled =TRUE;
	BtnInfos[BTN_PAUSE].enabled =FALSE;
	BtnInfos[BTN_STOP].enabled =FALSE;
	BtnInfos[BTN_NEXT].enabled =FALSE;
	BtnInfos[BTN_PREV].enabled =FALSE;
	BtnInfos[BTN_RECORD].enabled =FALSE;
	CurSelBtn =-1;
    InvalidateRect(ghWndToolBar, NULL, FALSE);

	return 0;
}
 