#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <io.h>
#include <commdlg.h>
#include "resource.h"
#include "global.h"
#include "appmain.h"
#include "fx.h"
#include "hq.h"
#include "hq_cl.h"
#include "hq_tcp.h"
#include "jy_cl.h"
#include "toolbar.h"
#include "msg.h"

void FxFreeData(LPFX);

int InitObjectOne(void);
int InitObjectTwo(void);
int LoadData(FX* fx);

BOOL CreateHistoryData(int arnge,char *gpdm); 
int FxExit(FX *fx);

int CreateMacdData(K_DATA *Main,int RNum,DATA *Data,PARA *Para);
int CreateRsiData(K_DATA *Main,int RNum,DATA *Data,PARA *Para);
int CreateDmiData(K_DATA *Main,int RNum,DATA *Data,PARA *Para);
int CreatePsyData(K_DATA *Main,int RNum,DATA *Data,PARA *Para);
int CreateVrData(K_DATA *Main,int RNum,DATA *Data,PARA *Para);
int CreateObvData(K_DATA *Main,int RNum,DATA *Data,PARA *Para);
int CreateBiasData(K_DATA *Main,int RNum,DATA *Data,PARA *Para);
int CreateWrData(K_DATA *Main,int RNum,DATA *Data,PARA *Para);
int CreateKdjData(K_DATA *Main,int RNum,DATA *Data,PARA *Para);

int SetColor(HWND hwnd);
CHOOSECOLOR cc;

extern char szDataPath[128];
extern HWND hWndInput,ghWndHelp;
extern BOOL IsZsRec(int, int);
extern int UDP_Send_DataDay(int, int);

extern int DlgJy(void);
extern JY_ANS_CHKUSR curChkUsrRes;
extern int LoadFile(char *filename,int sline,char *title);
extern HFONT ghFontSmall;

HWND ghWndSetup=NULL;
FX *Fx;
char *RANGE_NAME[]={"5����","15����","30����","60����","��","��","��"};
unsigned int RANGE_MENU[7]={IDM_FX_5,IDM_FX_15,IDM_FX_30,IDM_FX_60,IDM_FX_DAY,IDM_FX_WEEK,IDM_FX_MONTH};

char *DIAGR_NAME=NULL;

ANALYSER_INIT_TABLE *INIT_TABLE;

#define		WIN_GAP		8

PARA *FindOpPara()
{
	PARA *para;	
	para =&Fx->KxPara;
	do
	{
		if(para->no ==Fx->PaintPara.object)
			return para;
		para =para->next;
	}while(para!=NULL);	
	return NULL;
}

DATA *FindOpData()
{
	DATA *data;	
	data =&Fx->KxData;
	do
	{
		if(data->no ==Fx->PaintPara.object)
			return data;
		data =data->next;
	}while(data!=NULL);	
	return NULL;
}
// frome 0 to 9
int GetNo(PARA *para,long feature)
{
	int i;
	if(para==NULL)
		return -1;
	if(feature&DW_NAME)
		return((int)GetSerial(feature));
	for(i=0;i<10;i++)
	{
		if(feature>>i&1L)
			return i;
	}
	return -1;
}

void GetDiagramName(PARA *Para,int range,char *gpmc)
{
	PARA *para;
	
	para =Para;
	strcpy(DIAGR_NAME,RANGE_NAME[range]);
	do
	{
		if(para->rc.right >para->rc.left&&
				para->rc.bottom >para->rc.top)
		{
			if(strlen(DIAGR_NAME)>strlen(RANGE_NAME[range]))
				strcat(DIAGR_NAME,"-");
			strcat(DIAGR_NAME,para->name);
		}
		para =para->next;
	}while(para!=NULL);
	strcat(DIAGR_NAME,"-");
	strcat(DIAGR_NAME,gpmc);
}

void MakeWinSpace()
{
	int i=0,height,vert;
	PARA *para;
	
	height =Fx->PaintPara.rc.bottom -Fx->PaintPara.rc.top;
	para =&Fx->KxPara;
	do
	{
		if(para->feature&DW_BASE)
			i++;
		else 
			memset(&para->rc,0,sizeof(RECT));
		para=para->next;
	}while(para!=NULL);
	if(i<=0)
	{   
		memcpy(&Fx->KxPara.rc,&Fx->PaintPara.rc,sizeof(RECT));
		Fx->PaintPara.object=1;
		return;
	}
	switch(i)
	{
		case 1: 
			para =&Fx->KxPara;
			do
			{   
				if(para->feature&DW_BASE)
					break;
				para=para->next;
			}while(para!=NULL);
			memcpy(&para->rc,&Fx->PaintPara.rc,sizeof(RECT));
			Fx->PaintPara.object=para->no;
		break;
		case 2:
			if(Fx->KxPara.feature&DW_BASE)
			{
				memcpy(&Fx->KxPara.rc,&Fx->PaintPara.rc,sizeof(RECT));
				Fx->KxPara.rc.bottom =(height -WIN_GAP)*2/3+Fx->KxPara.rc.top;
				vert =Fx->KxPara.rc.bottom+WIN_GAP;
				para=Fx->KxPara.next;
				do
				{   
					if(para->feature&DW_BASE)
						break;
					para=para->next;
				}while(para!=NULL);
				memcpy(&para->rc,&Fx->PaintPara.rc,sizeof(RECT));
				Fx->PaintPara.object=para->no;
				para->rc.top =vert;
			}
			else
			{
				para=Fx->KxPara.next;
				vert =Fx->PaintPara.rc.top;
				do
				{   
					if(para->feature&DW_BASE)
					{
						memcpy(&para->rc,&Fx->PaintPara.rc,sizeof(RECT));
						para->rc.top =vert;
						para->rc.bottom =(height -WIN_GAP)/2 +vert;
						vert =para->rc.bottom+WIN_GAP;
						Fx->PaintPara.object=para->no;
					}
					para=para->next;
				}while(para!=NULL);			
			}
		break;
		case 3:
			if(Fx->KxPara.feature&DW_BASE&&Fx->CjlPara.feature&DW_BASE)
			{
				memcpy(&Fx->KxPara.rc,&Fx->PaintPara.rc,sizeof(RECT));
				Fx->KxPara.rc.bottom =(height -2*WIN_GAP)*3/6 +Fx->KxPara.rc.top;
				Fx->PaintPara.object=1;
				vert =Fx->KxPara.rc.bottom +WIN_GAP;
				memcpy(&Fx->CjlPara.rc,&Fx->PaintPara.rc,sizeof(RECT));
				Fx->CjlPara.rc.top =vert;
				Fx->CjlPara.rc.bottom =(height -2*WIN_GAP)*1/6 +vert;
				vert =Fx->CjlPara.rc.bottom+WIN_GAP;
				para=Fx->CjlPara.next;
				do
				{   
					if(para->feature&DW_BASE)
						break;				
					para=para->next;
				}while(para!=NULL);
				memcpy(&para->rc,&Fx->PaintPara.rc,sizeof(RECT));
				para->rc.top =vert;
				break;
			}
		default:
			para=Fx->KxPara.next;
			vert =Fx->PaintPara.rc.top;
			do
			{   
				if(para->feature&DW_BASE)
				{
					memcpy(&para->rc,&Fx->PaintPara.rc,sizeof(RECT));
					para->rc.top =vert;
					para->rc.bottom =(height -WIN_GAP*(i-1))/i +vert;
					vert =para->rc.bottom+WIN_GAP;
					Fx->PaintPara.object=para->no;
				}
				para=para->next;
			}while(para!=NULL);			
		break;
	}
}

BOOL RegisterFx(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	
	wc.lpfnWndProc =FxWndProc;
	wc.lpszClassName =FX_CLASS;
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = ghInstance;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

BOOL AnalyseInit(void)
{
	LOGFONT lf;
	char temp[80];
	ANALYSER_INIT_TABLE InitTable[]={
		{IDM_FX_MACD,"MACD",CreateMacdData},
		{IDM_FX_DMI,"DMI",CreateDmiData},
		{IDM_FX_BIAS,"BIAS",CreateBiasData},
		{IDM_FX_RSI,"RSI",CreateRsiData},
		{IDM_FX_PSY,"PSY",CreatePsyData},
		{IDM_FX_VR,"VR",CreateVrData},
		{IDM_FX_OBV,"OBV",CreateObvData},
		{IDM_FX_WR,"WR",CreateWrData},
		{IDM_FX_KDJ,"KDJ",CreateKdjData}};
	
    //init object 0
	if(Fx==NULL)
	       Fx=(FX*)_fmalloc(sizeof(FX));
	if(Fx==NULL)
		return FALSE;
	memset(Fx,0,sizeof(FX));
	Fx->type=IDM_FX_MACD;
	
	if(GetInitString("FX", "RANGE", temp))
		Fx->range=atoi(temp);
	else
	Fx->range=MIN_5;
	
	//init object 1
	strcpy(Fx->KxPara.name,"K��");
    Fx->KxPara.no =1;
	GetAnalysePara(&Fx->KxPara);
	Fx->KxPara.feature |=DW_ALL;
	//init object 2
    strcpy(Fx->CjlPara.name,"�ɽ���");
    Fx->CjlPara.no =2;
	GetAnalysePara(&Fx->CjlPara);
	Fx->CjlPara.feature |=(DW_ALL);
	Fx->KxPara.next =&Fx->CjlPara;
	Fx->KxData.next =&Fx->CjlData;
	//init para object 3
	if(Fx->Para==NULL)
           Fx->Para=(PARA*)_fmalloc(sizeof(PARA));
    if(Fx->Para ==NULL)
    	return FALSE;
    memset(Fx->Para,0,sizeof(PARA));
	Fx->Para->no=3;
	Fx->CjlPara.next =Fx->Para;
	Fx->Para->feature |=DW_ALL|1L;
	//init data object 3
	if(Fx->Data==NULL)
		Fx->Data=(DATA*)_fmalloc(sizeof(DATA));
	if(Fx->Data==NULL)
		return FALSE;
	memset(Fx->Data,0,sizeof(DATA));
	Fx->Data->no=Fx->Para->no;
	Fx->CjlData.next =Fx->Data;
	//init selected object to object one
	Fx->PaintPara.object =1;
	Fx->PaintPara.item =DW_NULL;
    //init paint font
    if(Fx->PaintPara.hFont!=NULL)
     	DeleteObject(Fx->PaintPara.hFont);
	memset(&lf, 0, sizeof(lf));
	lf.lfHeight =13;
	lf.lfWeight =FW_NORMAL;
    strcpy(lf.lfFaceName,"����");
	lf.lfItalic=0;
	lf.lfUnderline=0;    		
			
	Fx->PaintPara.hFont =CreateFontIndirect(&lf);
            
    if(Fx->PaintPara.hFont ==0)
    	return FALSE;
    
    DIAGR_NAME =_fmalloc(sizeof(char)*60);
    if(DIAGR_NAME==NULL)
    	return FALSE;
    memset(DIAGR_NAME,0,sizeof(char)*60);
    
	INIT_TABLE =_fmalloc(sizeof(InitTable));
	if(INIT_TABLE ==NULL)
		return FALSE;
	memcpy(INIT_TABLE,InitTable,sizeof(InitTable));
	Fx->PaintPara.num =sizeof(InitTable)/sizeof(ANALYSER_INIT_TABLE);
    return TRUE;
}

BOOL CreateWndFx(HWND hWnd)
{                          
	int x, y;
	HWND hwnd;
	RECT rc;
		
	GetClientRect(ghWndMain, &rc);
	x =rc.right -rc.left;
	y =rc.bottom -rc.top;
	
	if(ghWndFx==NULL)
	{
		hwnd =CreateWindow(FX_CLASS, NULL, WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,
						10, 
						STATUS_HEIGHT+TOOLBAR_HEIGHT, 
						x -20,
						(y-STATUS_HEIGHT)-20-TOOLBAR_HEIGHT -GetSystemMetrics(SM_CYCAPTION),
						hWnd, NULL, ghInstance, NULL);						
		if(hwnd ==NULL) return FALSE;
		ghWndFx =hwnd;
	}
	else
	{
		SetWindowPos(ghWndFx, (HWND) NULL, 
			10, 
			STATUS_HEIGHT+TOOLBAR_HEIGHT, 
			x -20,
			(y-STATUS_HEIGHT)-20-TOOLBAR_HEIGHT -GetSystemMetrics(SM_CYCAPTION),
			NULL);	
	}
	return TRUE;
}

int WriteDefaultPara(void)
{	
	OFSTRUCT os;
	HFILE hf;
	char fname[80];
	PARA para;

	sprintf(fname,"%s\\sysset.dat",szDataPath);
	if((hf =OpenFile(fname,&os,OF_WRITE|OF_CREATE))==HFILE_ERROR)
			return -1;
    
    memset(&para,0,sizeof(PARA));
    strcpy(para.name ,"K��");
    para.pnum =3;
    para.dnum =7;                       //ks,ss,zg,zd,pma1,pma2,pma3
	strcpy(para.pname[4],"PMA");
	strcpy(para.pname[5],"PMA");
	strcpy(para.pname[6],"PMA");
    para.color[0] =RGB(255,0,255); para.color[10+0] =RGB(0,255,255);      //K diagram down color
    para.color[4] =RGB(255,100,255);    //K 5 minute average color
    para.color[5] =RGB(255,255,100);    //K 10 minute avrage color
	para.color[6] =RGB(100,100,255);    //K 20 ...                                    
    para.periods[4]=5;                  //K 5 minute avrage period
    para.periods[5]=10;                 //K 10...
    para.periods[6]=20;                 //k 20...
    _lwrite(hf,&para,sizeof(PARA));

	memset(&para,0,sizeof(PARA));
    strcpy(para.name ,"�ɽ���");
    para.pnum =2;
    para.dnum =4;                       //cj,ks-ss,pma1,pma2
	strcpy(para.pname[2],"PMA");
	strcpy(para.pname[3],"PMA");
    para.color[0] =RGB(255,0,255);  para.color[10+0] =RGB(0,255,255); 
    para.color[2] =RGB(255,0,255);      //Volumn average diagram color
    para.color[3] =RGB(255,255,0);
    para.periods[2]=5;
    para.periods[3]=10;
    _lwrite(hf,&para,sizeof(PARA));
    
	memset(&para,0,sizeof(PARA));
    strcpy(para.name ,"MACD");
    para.pnum =3;
    para.dnum =3;                       //macd,dif,cha
	strcpy(para.pname[0],"Macd");
	strcpy(para.pname[1],"Dif");
	strcpy(para.pname[2],"Dea");
    para.color[0] =RGB(255,255,100);
    para.color[1] =RGB(255,255,255); 
    para.color[2] =RGB(255,0,255); para.color[10+2] =RGB(0,255,255);
    para.periods[0]=12;
    para.periods[1]=26;
    para.periods[2]=9; 
    _lwrite(hf,&para,sizeof(PARA));

	memset(&para,0,sizeof(PARA));    
    strcpy(para.name,"RSI");
    para.pnum =2;
    para.dnum =2;                       //1Rsi,2Rsi
	strcpy(para.pname[0],"Rsi");
	strcpy(para.pname[1],"Rsi");
    para.color[0] =RGB(255,255,255); 
    para.color[1] =RGB(255,255,100);    
    para.periods[0]=6;
    para.periods[1]=12;
    _lwrite(hf,&para,sizeof(PARA));
    
	memset(&para,0,sizeof(PARA));    
    strcpy(para.name,"DMI");    
    para.pnum =1;
    para.dnum =3;
	strcpy(para.pname[0],"+Di");
	strcpy(para.pname[1],"-Di");
	strcpy(para.pname[2],"+Adx");
	para.color[0]=RGB(255,255,255);  //up di color
    para.color[1]=RGB(255,255,100);  //down di...
    para.color[2]=RGB(100,255,255);  //adx...
    //para.color[3]=RGB(100,100,255); 
    para.periods[0]=14;
    _lwrite(hf,&para,sizeof(PARA));
    
	memset(&para,0,sizeof(PARA));
    strcpy(para.name,"PSY");
    para.pnum =1;
    para.dnum =1;
	strcpy(para.pname[0],"Psy");
	para.color[0]=RGB(255,255,100);  //
    para.periods[0]=12;
    _lwrite(hf,&para,sizeof(PARA));
            
	memset(&para,0,sizeof(PARA));            
    strcpy(para.name,"VR");
    para.pnum =1;
    para.dnum =1;    
	strcpy(para.pname[0],"Vr");
	para.color[0]=RGB(255,255,100);  //
    para.periods[0]=26;
    _lwrite(hf,&para,sizeof(PARA));
    
	memset(&para,0,sizeof(PARA));    
    strcpy(para.name,"OBV");
    para.pnum =1;
    para.dnum =1;    
	strcpy(para.pname[0],"Obv");    
	para.color[0]=RGB(255,255,100);
    para.periods[0]=5;
    _lwrite(hf,&para,sizeof(PARA));
    
	memset(&para,0,sizeof(PARA));    
    strcpy(para.name,"BIAS");
    para.pnum =1;
    para.dnum =1;    
	strcpy(para.pname[0],"Bias");
	para.color[0]=RGB(255,255,100),  //
    para.periods[0]=10;
    _lwrite(hf,&para,sizeof(PARA));
    
	memset(&para,0,sizeof(PARA));    
    strcpy(para.name,"WR");    
    para.pnum =3;
    para.dnum =3;    
	strcpy(para.pname[0],"Wr");
	strcpy(para.pname[1],"Wr");	
	strcpy(para.pname[2],"Wr");
	para.color[0]=RGB(255,255,255);  //
	para.color[1]=RGB(255,255,100);  //
	para.color[2]=RGB(255,100,255);  //
	para.periods[0]=10;
	para.periods[1]=15;
	para.periods[2]=20;
	_lwrite(hf,&para,sizeof(PARA));
	
	memset(&para,0,sizeof(PARA));
    strcpy(para.name,"KDJ");
    para.pnum =1;
    para.dnum =3;
	strcpy(para.pname[0],"K");
	strcpy(para.pname[1],"D");
	strcpy(para.pname[2],"J");
	para.color[0]=RGB(255,100,100);  //
	para.color[1]=RGB(255,255,100);  //
	para.color[2]=RGB(255,100,255);  //
	para.periods[0]=9;
	_lwrite(hf,&para,sizeof(PARA));
	
    _lclose(hf);
    
}

int WritePara(PARA *para)
{
	OFSTRUCT os;
	HFILE hf;
	char fname[80];
	PARA temp;
	int i;
	
	sprintf(fname,"%s\\sysset.dat",szDataPath);
	if((hf =OpenFile(fname,&os,OF_READWRITE|OF_SHARE_DENY_NONE))==HFILE_ERROR)
		return -1;

	for(i=0;;i++)	
	{   
		memset(&temp,0,sizeof(PARA));
		if(_lread(hf,&temp,sizeof(PARA))!=sizeof(PARA))
			break;
		if(!strncmp(temp.name,para->name,strlen(para->name)))
		{   
			memcpy(&para->pname[0],&temp.pname[0],(MAX_PARA_NAME+1)*MAX_DATA_ITEM);
		    _lseek(hf,i*sizeof(PARA),SEEK_SET);
		    _lwrite(hf,para,sizeof(PARA));
			_lclose(hf);
			return 0;
		}
	}
    _lclose(hf);
    return -1;
}

int GetAnalysePara (PARA *para)
{
	OFSTRUCT os;
	HFILE hf;
	char fname[80];
	PARA temp;
	int i,j,k;
	
	if(strlen(para->name)==0)
	{
		memset(para,0,sizeof(PARA));
		return -1;
	}
	sprintf(fname,"%s\\sysset.dat",szDataPath);
	if(access(fname,0)!=0)
		WriteDefaultPara();
	if((hf =OpenFile(fname,&os,OF_READ|OF_SHARE_DENY_NONE))==HFILE_ERROR)
		return -1;
	for(;;)	
	{   
		memset(&temp,0,sizeof(PARA));
		if(_lread(hf,&temp,sizeof(PARA))!=sizeof(PARA))
			break;
		if(!strncmp(temp.name,para->name,strlen(para->name)))
		{
			memcpy(&para->color[0],&temp.color[0],sizeof(COLORREF)*MAX_DATA_ITEM*2);
			memcpy(&para->periods[0],&temp.periods[0],sizeof(int)*MAX_DATA_ITEM);
			memcpy(&para->pname[0],&temp.pname[0],(MAX_PARA_NAME+1)*MAX_DATA_ITEM);
			memset(&para->price[0],0,sizeof(double)*5);
			para->pnum =temp.pnum;
			para->dnum =temp.dnum;
			_lclose(hf);
			for(i=0;i<MAX_DATA_ITEM;i++)
			{
				if(para->color[i]!=0)
					para->feature = para->feature|(1L<<i);
			}
			for(i=0;i<MAX_DATA_ITEM;i++)
			{
				for(j=0,k=0;j<MAX_DATA_ITEM&&strlen(para->pname[i])!=0;j++)
					if(strstr(para->pname[j],para->pname[i])!=NULL) k++;
				if(k>1)
				{   
					strcpy(fname,para->pname[i]);
					sprintf(para->pname[i],"%d%s",para->periods[i],fname);
				}
			}
			return 0;
		}
	}
	_lclose(hf);
	return -1;
}

void SetAnalysePara(PAINT_PARA *PaintPara)
{
	RECT rc;
	int i,ltitle,htitle;
	HWND hwnd;
	char szBuff[80];
	PARA *Para;
	DATA *Data;
	
	// look for object
	Para =FindOpPara();
	Data =FindOpData();
	if(Para==NULL||Data==NULL)
		return;
	//look for item
	
	//if(PaintPara->item&DW_NAME)
	//	i=(int)GetSerial(PaintPara->item);
	//else 
	if((i=GetNo(Para,PaintPara->item))==-1)
		return;
	if(Para->periods[i]==0)
		return ;
	ltitle = (Para->xtitle[1]-Para->xtitle[0])/2;
	htitle = Para->htitle;
	
	if(ghWndSetup!=NULL)
	{
		SendMessage(ghWndSetup,WM_CLOSE,0,0L);
		ghWndSetup=NULL;
	}
	SetRect(&rc,Para->xtitle[0]-ltitle,Para->rc.top +2,
				Para->xtitle[0],Para->rc.top +htitle);
	ghWndSetup =CreateWindow("EDIT","",WS_VISIBLE|WS_CHILD|WS_DISABLED,
			    rc.left,rc.top ,ltitle ,htitle-2,
			    ghWndFx,100,ghInstance,NULL);	
	SetWindowPos(ghWndSetup, HWND_TOPMOST,rc.left,
		rc.top ,ltitle ,htitle-2,SWP_SHOWWINDOW);
	if(ghWndSetup!=NULL)
	{
	    SendMessage(hwnd,WM_SETFONT,PaintPara->hFont,0L);
	    PaintPara->IsSetPara =TRUE;
	    sprintf(szBuff,"%d",Para->periods[i]);
	    SetWindowText(ghWndSetup,(LPSTR)szBuff);
	    SendMessage(ghWndSetup,EM_SETSEL,(WPARAM)(UINT)0L,(LPARAM)MAKELPARAM(0,-1));
	}
} 

LRESULT CALLBACK FxWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	char tmp[256];
	PAINTSTRUCT ps;
	RECT rc;
	HDC hDc;
	LOGFONT lf;
	int i, j,x,y;
	static clock_t MouDownClk;
	POINT pt;
	DATA *lpData;
	PARA *lpPara;
	long flag;
		     
	switch(message)
	{       
	    case WM_CREATE:
	    	MouDownClk=clock();
	    break;	
        case WM_USER+1:   
        	if(Fx->PaintPara.hFont!=NULL)
        		DeleteObject(Fx->PaintPara.hFont);
			memset(&lf, 0, sizeof(lf));
			lf.lfHeight =13;
			lf.lfWeight =FW_NORMAL;
    		strcpy(lf.lfFaceName,"����");
    		
			lf.lfItalic=0;
			lf.lfUnderline=0;    		
			
			Fx->PaintPara.hFont =CreateFontIndirect(&lf);
            
    		if(Fx->PaintPara.hFont ==0)
    		{
    			wParam=VK_RETURN;
    			SendMessage(ghWndStatus, WM_KEYDOWN, wParam, lParam);
    		}
    		
	    break;
	    case WM_SIZE:
			GetClientRect(hWnd, &rc);
			memcpy(&Fx->PaintPara.rc,&rc,sizeof(RECT));
			Fx->PaintPara.rc.top+=30;
			Fx->PaintPara.rc.bottom-=20;
			MakeWinSpace();
			if(IsWindowVisible(ghWndFx))
				InvalidateRect(ghWndFx, NULL, TRUE);
	    break;
		case WM_SETFOCUS:
			SetFocus(ghWndMain);
			break;
		case WM_TIMER:
			if(wParam ==1)
			{   
				Fx->PaintPara.IsPainting=FALSE;
				KillTimer(ghWndFx,1);
			}
			if(wParam ==2)
				PostMessage(hWnd,WM_USER+1,NULL,NULL);						
		break;
		case WM_KILLFOCUS:
		    if(Fx->PaintPara.IsScroll)
		     	DrawScroll(Fx,SCROLL_CANCEL);
            if(Fx->PaintPara.IsUpDown)
                UpDown(Fx,0);
		break;
		case WM_CTLCOLOR:
			if(HIWORD(lParam) ==CTLCOLOR_STATIC)
			{
				hDc =(HDC)wParam;
				SetTextColor(hDc, RGB(255, 0, 0));
				SelectObject(hDc, Fx->PaintPara.hFont);
				return (LRESULT)(HBRUSH)GetStockObject(WHITE_BRUSH);
			}
		break;
		case WM_LBUTTONDOWN:
			if(!Fx->PaintPara.IsSetPara)
			{
				x=LOWORD(lParam);
				y=HIWORD(lParam);	
				pt.x=x=LOWORD(lParam);
				pt.y=y=HIWORD(lParam);
				lpPara =FindOpPara();
				lpData =FindOpData();
				if(lpPara!=NULL&&lpData!=NULL)
				{   
					UpDown(Fx,0);
					Fx->PaintPara.object=0;
					flag =Fx->PaintPara.item&lpPara->feature&DW_OBJECT;
					flag =flag|Fx->PaintPara.item&DW_ATTR;
					DrawDiagram(NULL,Fx->CurRecPrt,Fx->ShowDot,lpPara,lpData,&Fx->PaintPara,flag&~DW_SELE&~DW_FRAME);
				}
				lpPara =&Fx->KxPara;
				lpData =&Fx->KxData;
				do
				{
				    if(PtInRect(&lpPara->rc,pt))
				    	break;
					lpPara =lpPara->next;
					lpData =lpData->next;
				}while(lpPara!=NULL&&lpData!=NULL);
				if(lpPara!=NULL&&lpData!=NULL)
				{
					flag=GetObjectItem(x,y,Fx->CurRecPrt,Fx->ShowDot,lpPara,lpData,&Fx->PaintPara);
					Fx->PaintPara.object=lpPara->no;
					Fx->PaintPara.item =flag;
					flag =flag&lpPara->feature&DW_OBJECT;
					flag =flag|Fx->PaintPara.item&DW_ATTR;
					DrawDiagram(NULL,Fx->CurRecPrt,Fx->ShowDot,lpPara,lpData,&Fx->PaintPara,DW_SELE|flag);
				}
			}
		break;
		
		case WM_RBUTTONDOWN:
		    pt.x=x=LOWORD(lParam);
			pt.y=y=HIWORD(lParam);
		break;		
		case WM_PAINT:
		    //if(!LoadData(Fx))
		    //{
		    //    wParam=VK_RETURN;
		    //    Msg(0,0,"û�з������ݣ�",MSG_TIME|MSG_FOCU|MSG_HORT,RGB(255,0,0));
		    //    ValidateRect(hWnd,NULL);
		    //}
            //else
            //{
			hDc=BeginPaint(hWnd, &ps);
			if(!LoadData(Fx))
			{
				SetTextColor(hDc,RGB(255,0,0));
				SetBkColor(hDc,RGB(255,255,255));
				strcpy(tmp,"����ͨѶ�����Ժ�...");
				TextOut(hDc,0,2,tmp,strlen(tmp));
			}
			else
			{
				lpData =&Fx->KxData;
				lpPara =&Fx->KxPara;                
                GetDiagramName(lpPara,Fx->range,Fx->gpmc);
				do
				{
					if(lpPara->rc.right !=0)
						DrawDiagram(hDc,Fx->CurRecPrt,Fx->ShowDot,lpPara,lpData,&Fx->PaintPara,0L);
					lpData =lpData->next;
					lpPara =lpPara->next;					
				}while(lpData!=NULL&&lpPara!=NULL);				
			}
			EndPaint(hWnd, &ps);
		break;   
		case WM_KEYDOWN:
		    switch(wParam)
		    {
		    	case VK_F1:
					ShowWindow(ghWndHelp,SW_SHOW);
					sprintf(tmp,"%s\\help.txt",szDataPath);					
					i=LoadFile(tmp,0,"����/[ESC]�˳�");
				return 0L;
			    case VK_F2:
				    	SendMessage(ghWndMain,WM_COMMAND,IDM_JY,NULL);				    	
				return 0L;
				case VK_F3:
				    SendMessage(ghWndXlt,WM_KEYDOWN,VK_F3,0L);
				return 0L;
				case VK_F4:
					if(Fx->range<MONTH)
						Fx->range++;
					else
						Fx->range=MIN_5;
					Fx->IsDataOk =FALSE;
                    InvalidateRect(ghWndFx, NULL, TRUE);
                case VK_F9: 
                	if(Fx->PaintPara.item&DW_OBJECT) 
                	{
                    	if(SetColor(ghWndFx)==0)
                    	{
                    		lpPara =FindOpPara();
                    		lpData =FindOpData();
                    		if(lpPara!=NULL&lpData!=NULL)
                    		{
                    			if(Fx->PaintPara.item&DW_NAME)
                    				i=-1;
                    			else
                    			{
									i=GetNo(lpPara,Fx->PaintPara.item);
									j=(int)GetSerial(Fx->PaintPara.item);
								}	
								if(i!=-1&j==0|j==1)
									lpPara->color[i+j*10] =cc.rgbResult;
								WritePara(lpPara);
								flag =lpPara->feature&DW_ATTR|(1L<<i);
								DrawDiagram(NULL,Fx->CurRecPrt,Fx->ShowDot,lpPara,lpData,&Fx->PaintPara,flag);
                    		}
                    	}
                    }
				break;
				case VK_F11:
				    SetAnalysePara(&Fx->PaintPara);
				break;
				case VK_F12:
					SendMessage(ghWndXlt, WM_KEYDOWN, VK_F12, 0L);
				break;				
		     	case VK_ESCAPE:
		     		if(Fx->PaintPara.IsSetPara)
		     		{
						SendMessage(ghWndSetup,WM_CLOSE,0,0L);
						ghWndSetup=NULL;
		     			Fx->PaintPara.IsSetPara =FALSE;
		     			break;
		     		}
		     	    if(Fx->PaintPara.IsScroll)
		     	    {
		     	    	DrawScroll(Fx,SCROLL_CANCEL);
		     	    	break;
		     	    }	
		     	    else if(Fx->PaintPara.IsUpDown)
		     	    {
		     	    	UpDown(Fx,0);
		     	    	break;
		     	    }	
		     	//case VK_F9:		     	
		     	case VK_RETURN:
					if(HqData[GraphData.jys].recCount <=0) break;
		     	    if(Fx->PaintPara.IsScroll)
		     	    	DrawScroll(Fx,SCROLL_CANCEL);
					strcpy(tmp,"");
					if(ghWndSetup!=NULL&&Fx->PaintPara.IsSetPara)
					{
						GetWindowText(ghWndSetup, &tmp[0], sizeof(tmp));
						SetWindowText(ghWndSetup,"");
						SetWindowText(hWndInput,"");
						if(atoi(tmp)==0) break;						
						lpPara =FindOpPara();
						lpData =FindOpData();
						if(lpPara!=NULL)
						{    
							i=GetNo(lpPara,Fx->PaintPara.item);
							if(i!=-1)
								lpPara->periods[i] =atoi(tmp);
							WritePara(lpPara);
							GetAnalysePara (lpPara);
						}
						SendMessage(ghWndSetup,WM_CLOSE,0,0L);
						ghWndSetup=NULL;						
						if(lpData==NULL||lpData->no!=lpPara->no)
							break;						
						if(lpPara->no ==1)
							InitObjectOne();
						else if(lpPara->no ==2)
							InitObjectTwo();
						else
						{
		     				for(j=0;j<Fx->PaintPara.num;j++)
		     				{
		     					if(lpData->type ==INIT_TABLE[j].type)
		     						break;
		     				}
							if(j<Fx->PaintPara.num)
								(*INIT_TABLE[j].CreateData)(Fx->MainData,Fx->RecCount,lpData,lpPara);
							else
								break;
						}
						flag =lpPara->feature&DW_ATTR|(1L<<i);
						DrawDiagram(NULL,Fx->CurRecPrt,Fx->ShowDot,lpPara,lpData,&Fx->PaintPara,flag);
						Fx->PaintPara.IsSetPara =FALSE;
						break;
					}
					GetWindowText(hWndInput, &tmp[0], sizeof(tmp));
					if(tmp[0] ==0)
					{
			  			ShowWindow(ghWndMmp, SW_HIDE);
						ShowWindow(ghWndCj, SW_HIDE);
						ShowWindow(ghWndLitHq, SW_HIDE);
						ShowWindow(ghWndMaxMin, SW_HIDE);
						ShowWindow(ghWndZs, SW_HIDE);
			        	FxFreeData(Fx);
			        	ShowWindow(ghWndFx,SW_HIDE);
						ShowWindow(ghWndHq, SW_SHOW);
						KillTimer(ghWndHq, 5);
						SetTimer(ghWndHq, 5, 1000, NULL);
						SetFocus(ghWndHq);			
		     			break;
                     }
                     else
                     {   
						for(j =0; j<2; j++)
						{
							for(i =0; i<HqData[j].recCount; i++)
							{
								if(!strcmp(HqData[j].lpPreData[i].zqdm, tmp))
									break;
							}
							if(i <HqData[j].recCount) break;
						}
						
						if(j<2 && i <HqData[j].recCount)
						{
							GraphData.minEnd =0;
							GraphData.jys =j;
							GraphData.recNum =i;
							SendMessage(hWnd, WM_KILLFOCUS, 0, 0L);
							InvalidateRect(ghWndLitHq, NULL, TRUE);
							UDP_Send_Gra00(j, i);
							
							if(IsZsRec(j, i))
							{
								if(!IsWindowVisible(ghWndZs))
								{
									ShowWindow(ghWndZs, SW_SHOW);
									ShowWindow(ghWndMmp, SW_HIDE);
									ShowWindow(ghWndCj, SW_HIDE);
									ShowWindow(ghWndMaxMin, SW_SHOW);
								}
							}
							else
							{
								if(IsWindowVisible(ghWndZs))
								{
									ShowWindow(ghWndZs, SW_HIDE);
									ShowWindow(ghWndMmp, SW_SHOW);
									ShowWindow(ghWndCj, SW_SHOW);
									ShowWindow(ghWndMaxMin, SW_HIDE);
								}
								SendMessage(ghWndCj, WM_READ_OK, 0, 0L);
							}
						}
                        strcpy(Fx->gpdm, HqData[GraphData.jys].lpPreData[GraphData.recNum].zqdm);
                        strcpy(Fx->gpmc, HqData[GraphData.jys].lpPreData[GraphData.recNum].zqmc);
		
                        if(Fx->type==NULL)
                            Fx->type=IDM_FX_MACD;
                        Fx->range=DAY;
                        FxFreeData(Fx);
                        UDP_Send_DataDay(GraphData.jys,GraphData.recNum);
                        InvalidateRect(ghWndFx, NULL, TRUE);
						SetWindowText(hWndInput, "");
                    }
				break;
		     	case VK_UP:
		     		UpDown(Fx,1);
		     		break;
		     	case VK_DOWN:
		     		UpDown(Fx,-1);
		     		break;		
		     	case VK_LEFT:
		     	    if(Fx->RecCount!=0&&!Fx->PaintPara.IsSetPara)
		     			DrawScroll(Fx,SCROLL_LEFT);
		     		break;
		     	case VK_RIGHT:		     
		     		if(Fx->RecCount!=0&&!Fx->PaintPara.IsSetPara)
		     	    	DrawScroll(Fx,SCROLL_RIGHT);
		     		break; 
		     	case VK_HOME:
		     		if(Fx->RecCount!=0&&!Fx->PaintPara.IsSetPara)
		     	    	DrawScroll(Fx,SCROLL_HOME);
		     		break;
		     	case VK_END:
		     		if(Fx->RecCount!=0&&!Fx->PaintPara.IsSetPara)
		     	    	DrawScroll(Fx,SCROLL_END);
		     		break;		     				     		
		     	case VK_ADD:
		     	    if(Fx->RecCount!=0)
		     	    {
		     			if(Fx->PaintPara.IsScroll||Fx->PaintPara.IsUpDown)
		     				SendMessage(hWnd, WM_KILLFOCUS, 0, 0L);
		     			if(Fx->ShowDot<Fx->RecCount)
		     			{
		     				Fx->ShowDot+=30;
		     				if(Fx->ShowDot>Fx->RecCount)
		     					Fx->ShowDot=Fx->RecCount;
		     				Fx->CurRecPrt=Fx->RecCount-Fx->ShowDot;	
		     				InvalidateRect(hWnd, NULL, TRUE);	
		     			}	     	
		     		}
		     	break; 
		     	case VK_SUBTRACT:
		     		if(Fx->RecCount!=0)
		     		{
		     			if(Fx->PaintPara.IsScroll||Fx->PaintPara.IsUpDown)
		     				SendMessage(hWnd, WM_KILLFOCUS, 0, 0L);
		     			if(Fx->ShowDot>DEFSHOWDOT)
		     			{
		     				Fx->ShowDot-=30;
		     				if(Fx->ShowDot<DEFSHOWDOT-200)
		     					Fx->ShowDot=DEFSHOWDOT-200;
		     				Fx->CurRecPrt=Fx->RecCount-Fx->ShowDot;	
		     				InvalidateRect(hWnd, NULL, TRUE);	
		     			}		     			     	
		     		}
		     	break;
		     	case VK_DIVIDE:
		     		if(Fx->PaintPara.IsScroll)
		     			DrawScroll(Fx,SCROLL_CANCEL);  
		     		if(Fx->PaintPara.IsUpDown)
		     			UpDown(Fx,0);
		     		Fx->PaintPara.IsAvLineShow=!Fx->PaintPara.IsAvLineShow;
		     		InvalidateRect(hWnd, NULL, TRUE);			     		
		     		break;
		     	case VK_MULTIPLY: 
		     		if(Fx->PaintPara.IsScroll)
		     			DrawScroll(Fx,SCROLL_CANCEL);  
		     		if(Fx->PaintPara.IsUpDown)		     			
		     			UpDown(Fx,0);
		     		Fx->PaintPara.IsMax=!Fx->PaintPara.IsMax;
		     		InvalidateRect(hWnd, NULL, TRUE);
		     		break;
		     	case VK_PRIOR:
		     		CheckMenuItem(ghMenuMain, Fx->type, MF_BYCOMMAND|MF_UNCHECKED);
		     		for(i=0;i<Fx->PaintPara.num;i++)
		     		{
		     			if(Fx->type ==INIT_TABLE[i].type)
		     				break;
		     		}
		     		if(i==0)
		     			i=Fx->PaintPara.num -1;
		     		else if(i>=Fx->PaintPara.num)
		     			i=0;
		     		else
		     			i=i-1;		     			
		     		Fx->type =INIT_TABLE[i].type;
		     		strcpy(Fx->Para->name,INIT_TABLE[i].name);
		     		GetAnalysePara(Fx->Para);
					CheckMenuItem(ghMenuMain, Fx->type, MF_BYCOMMAND|MF_CHECKED);
					(*INIT_TABLE[i].CreateData)(Fx->MainData,Fx->RecCount,Fx->Data,Fx->Para);
					GetDiagramName(&Fx->KxPara,Fx->range,Fx->gpmc);
					DrawScroll(Fx,SCROLL_CANCEL);
					if(Fx->Para->rc.right ==0)	
					{
						MakeWinSpace();
						InvalidateRect(ghWndFx, NULL, TRUE);
					}
					else
						DrawDiagram(NULL,Fx->CurRecPrt,Fx->ShowDot,Fx->Para,Fx->Data,&Fx->PaintPara,0L);
		     	break;	
		     	case VK_NEXT:
					CheckMenuItem(ghMenuMain, Fx->type, MF_BYCOMMAND|MF_UNCHECKED);		     	
		     		for(i=0;i<Fx->PaintPara.num;i++)
		     		{
		     			if(Fx->type ==INIT_TABLE[i].type)
		     				break;
		     		}					
		     		if(i==Fx->PaintPara.num -1)
		     			i=0;
		     		else if(i>=Fx->PaintPara.num)
		     			i=0;
		     		else
		     			i=i+1;		     			
		     		Fx->type =INIT_TABLE[i].type;
		     		strcpy(Fx->Para->name,INIT_TABLE[i].name);
		     		GetAnalysePara(Fx->Para);
					CheckMenuItem(ghMenuMain, Fx->type, MF_BYCOMMAND|MF_CHECKED);
					(*INIT_TABLE[i].CreateData)(Fx->MainData,Fx->RecCount,Fx->Data,Fx->Para);
					GetDiagramName(&Fx->KxPara,Fx->range,Fx->gpmc);					
					DrawScroll(Fx,SCROLL_CANCEL);
					if(Fx->Para->rc.right ==0)
					{
						MakeWinSpace();
						InvalidateRect(ghWndFx, NULL, TRUE);
					}
					else
						DrawDiagram(NULL,Fx->CurRecPrt,Fx->ShowDot,Fx->Para,Fx->Data,&Fx->PaintPara,0L);
		        break;
		        case VK_DELETE:
		        	lpPara =FindOpPara();
		        	lpData =FindOpData();
		        	if(!(lpPara->feature&DW_BASE))
		        	{
		        	    Fx->PaintPara.item=0L;
		        	 	MakeWinSpace();
		        	 	InvalidateRect(ghWndFx, NULL, FALSE);
		        	}
		        	else if(Fx->PaintPara.item&DW_OBJECT)
		        	{   
		        	    flag =Fx->PaintPara.item;
		        	    Fx->PaintPara.item=Fx->PaintPara.item^(flag&DW_OBJECT);
		        	    lpPara->feature=lpPara->feature^(flag&DW_OBJECT);
		        		DrawDiagram(NULL,Fx->CurRecPrt,Fx->ShowDot,lpPara,lpData,&Fx->PaintPara,flag|DW_DELE);
		        	}
		        break;
		        case VK_INSERT:
		        	lpPara =FindOpPara();
		        	lpData =FindOpData();
		        	if(lpPara!=NULL&&lpData!=NULL)
		        	{
		        		for(i=0;i<MAX_DATA_ITEM;i++)
		        		{
		        			if(lpPara->color[i]!=0&&!(lpPara->feature&(1L<<i)))
		        				break;
		        		}
		        		if(i<MAX_DATA_ITEM)
		        		{   
		        		    lpPara->feature|=1L<<i;
		        		    flag=(lpPara->feature&DW_ATTR)|1L<<i;
		        			DrawDiagram(NULL,Fx->CurRecPrt,Fx->ShowDot,lpPara,lpData,&Fx->PaintPara,flag);
		        		}
		        		else
		        		{
		        		 	lpPara =&Fx->KxPara;
		        		 	lpData =&Fx->KxData;
		        		 	do
		        		 	{
		        		 		if(lpPara->rc.right==0)
		        		 			break;
		        		 		lpPara=lpPara->next;
		        		 		lpData=lpData->next;
		        		 	}while(lpPara!=NULL&&lpData!=NULL);
		        		 	if(lpPara!=NULL&&lpData!=NULL)
		        		 	{
		        				for(i=0;i<MAX_DATA_ITEM;i++)
		        				{
		        					if(lpPara->color[i]!=0&&!(lpPara->feature&(1L<<i)))
		        						break;
		        				}
		        				if(i<MAX_DATA_ITEM)
		        				{   
		        		    		lpPara->feature|=1L<<i;
		        		    		MakeWinSpace();
		        		    		InvalidateRect(ghWndFx, NULL, TRUE);
		        				}		        		 		
		        		 	}
		        		}
		        	}
		        break;
		        default:
		        	if(ghWndSetup!=NULL)		        	
		        		SendMessage(ghWndSetup,WM_CHAR,wParam,lParam);
		        break;
		    }
		break;
		case WM_COMMAND:
			switch(wParam)
			{
				case IDM_EXIT:
				    SendMessage(hWnd, WM_CLOSE, 0, 0L);
			        break;
				case IDM_HQ_SZ:
				case IDM_HQ_SH:
				case IDM_HQSEL_1:
				case IDM_HQSEL_2:
				case IDM_HQSEL_3:
				case IDM_HQSEL_4:
				case IDM_HQSEL_5:
				case IDM_GRAPH:
					ShowWindow(hWnd,SW_HIDE);
					SendMessage(ghWndHq, WM_COMMAND, wParam, 0L);
				break;			         
            }
		break;
		//case WM_DESTROY:
		//	if(Fx->PaintPara.hFont) 
		//		DeleteObject(Fx->PaintPara.hFont);
		//	Fx->PaintPara.hFont =NULL;
		//break;
		
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

int CompWeek(char *date1,char *date2)
{
	struct tm Tm[2];
	time_t Time[2];
	int i,last;
	char temp[20],tmp[20];

	for(i=0;i<2;i++)
	{
		if(i==0)
			strcpy(tmp,date1);
		else
			strcpy(tmp,date2);

		memset(&Tm[i],0,sizeof(struct tm));
		strncpy(temp,&tmp[0],4);
		Tm[i].tm_year =atoi(temp)-1900;

		strncpy(temp,&tmp[4],2);
		temp[2]=0;
		Tm[i].tm_mon =atoi(temp) -1;

		strncpy(temp,&tmp[6],2);
		temp[2]=0;
		Tm[i].tm_mday =atoi(temp);
		Tm[i].tm_isdst =0;
		if((Time[i]=mktime(&Tm[i]))==-1)
			return -1;
		memcpy(&Tm[i],(char *)gmtime(&Time[i]),sizeof(struct tm));
       }
       if(Time[0] ==Time[1])
		return 0;
       else if(Time[0]<Time[1])
       {
		if(Tm[0].tm_wday ==0)
			return 1;
		else
			last =7 -Tm[0].tm_wday;
		if((difftime(Time[1],Time[0])/3600)/24<=last)
			return 0;
		else
			return 1;
       }
       else
       {
		if(Tm[1].tm_wday ==0)
			return 1;
		else
			last =7 -Tm[1].tm_wday;
		if((difftime(Time[0],Time[1])/3600)/24<=last)
			return 0;
		else
			return 1;
       }
}

int InitObjectOne(void)
{
	long i,j;
	double Ave;
	
    Fx->KxData.num =Fx->KxPara.dnum; 
    Fx->KxData.no =Fx->KxPara.no;
    strcpy(Fx->KxData.gpdm,Fx->gpdm);
    Fx->KxData.type =Fx->type;
    Fx->KxData.range =Fx->range;
    Fx->KxData.size =Fx->RecCount;	
    //Fx->KxPara.feature =DW_ALL;
	for(i=0;i<Fx->KxData.num;i++)
	{
		if(Fx->KxData.v[i]!=NULL)
			_ffree(Fx->KxData.v[i]);
		Fx->KxData.v[i] =(double*)_fmalloc(sizeof(double)*Fx->RecCount);
		memset(Fx->KxData.v[i],0,sizeof(double)*Fx->RecCount);
	}
	for(i=0;i<Fx->KxData.num;i++)
	{
		if(i<4)
		{
    		for(j=0;j<Fx->RecCount&&i==0;j++) 
    			Fx->KxData.v[i][j]=Fx->MainData[j].ks;
    		for(j=0;j<Fx->RecCount&&i==1;j++) 
    			Fx->KxData.v[i][j]=Fx->MainData[j].ss;
    		for(j=0;j<Fx->RecCount&&i==2;j++) 
    			Fx->KxData.v[i][j]=Fx->MainData[j].zg;
    		for(j=0;j<Fx->RecCount&&i==3;j++) 
    			Fx->KxData.v[i][j]=Fx->MainData[j].zd;
    		Fx->KxData.method[i]=PRICE_BAR_METHOD;
    	}
    	else
    	{
    	    Ave = 0;
    	    for(j=0;j<Fx->RecCount;j++)
    	    {
    	    	if(Fx->KxPara.periods[i]==0)
    	    		break;
    	    	if(j<Fx->KxPara.periods[i]-1)
    	    		Ave +=Fx->MainData[j].ss;
    	    	else if(j==Fx->KxPara.periods[i]-1)
    	    	{
    	    	    Ave +=Fx->MainData[j].ss;
    	    		Fx->KxData.v[i][j]=Ave/Fx->KxPara.periods[i];
    	    	}
                else
           			Fx->KxData.v[i][j]=Fx->MainData[j].ss/Fx->KxPara.periods[i]+Fx->KxData.v[i][j-1]-
           				Fx->MainData[j-Fx->KxPara.periods[i]].ss/Fx->KxPara.periods[i];
    	    }
    	 	Fx->KxData.method[i]=CURVE_METHOD;
    	}
	}
    return TRUE;
}

int InitObjectTwo()
{
	double Ave;
	long i,j;

    Fx->CjlData.num =Fx->CjlPara.dnum; 
    Fx->CjlData.no =Fx->CjlPara.no;
    strcpy(Fx->CjlData.gpdm,Fx->gpdm);
    Fx->CjlData.type =Fx->type;
    Fx->CjlData.range =Fx->range;
    Fx->CjlData.size =Fx->RecCount;	
    //Fx->CjlPara.feature =DW_ALL;
	for(i=0;i<Fx->CjlData.num;i++)
	{
		if(Fx->CjlData.v[i]!=NULL)
			_ffree(Fx->CjlData.v[i]);
		Fx->CjlData.v[i] =(double*)_fmalloc(sizeof(double)*Fx->RecCount);
		memset(Fx->CjlData.v[i],0,sizeof(double)*Fx->RecCount);
	}
	for(i=0;i<Fx->CjlData.num;i++)
	{
		if(i<2)
		{
    		for(j=0;j<Fx->RecCount&&i==0;j++) 
    			Fx->CjlData.v[i][j]=Fx->MainData[j].cj;
    		for(j=0;j<Fx->RecCount&&i==1;j++) 
    			Fx->CjlData.v[i][j]=Fx->MainData[j].ks-Fx->MainData[j].ss;
    		Fx->CjlData.method[i]=VOULMN_BAR_METHOD;
    	}
    	else
    	{
    	    Ave = 0;
    	    for(j=0;j<Fx->RecCount;j++)
    	    {
    	    	if(Fx->CjlPara.periods[i]==0)
    	    		break;
    	    	if(j<Fx->CjlPara.periods[i]-1)
    	    		Ave +=Fx->MainData[j].cj;
    	    	else if(j==Fx->CjlPara.periods[i]-1)
    	    	{
    	    	    Ave +=Fx->MainData[j].cj;
    	    		Fx->CjlData.v[i][j]=Ave/Fx->CjlPara.periods[i];
    	    	}
                else
           			Fx->CjlData.v[i][j]=Fx->MainData[j].cj/Fx->CjlPara.periods[i]+Fx->CjlData.v[i][j-1]-
           				Fx->MainData[j-Fx->CjlPara.periods[i]].cj/Fx->CjlPara.periods[i];
    	    }
    	 	Fx->CjlData.method[i]=CURVE_METHOD;
    	}
	}
	return TRUE;	
}   

int LoadData(FX *Fx)
{                
	char temp[80];
	HFILE hFile;
	OFSTRUCT os;
	long i,j;
	K_DATA KBuff;
	DAY_DATA DayBuff;
	
	if(Fx->IsDataOk) return TRUE;
	switch(Fx->range)
	{
		case MIN_5:
	    case MIN_15:
	    case MIN_30:
	    case MIN_60:
			if(!CreateHistoryData(Fx->range,Fx->gpdm))
				return FALSE;   
			wsprintf(temp,"%s\\%s.%d",szDataPath,Fx->gpdm,Fx->range);
			//unlink(temp);
		break;
	    case WEEK:
	    case MONTH:
	    case DAY:
			wsprintf(temp,"%s\\%s.day",szDataPath,Fx->gpdm);
		break;
	    default:
			return FALSE;
	}
	  
	hFile =OpenFile(temp, &os, OF_READ);
	if(hFile ==HFILE_ERROR)
	{
		Fx->TotalCount=Fx->RecCount=Fx->ShowDot=0;
		return FALSE;
	}
	else
	{
		Fx->TotalCount=Fx->RecCount=(int)_llseek(hFile,0L,SEEK_END)/sizeof(K_DATA); 
		if(Fx->RecCount==0L) return FALSE;
		if(Fx->ShowDot<=0) Fx->ShowDot=DEFSHOWDOT;
		if(Fx->RecCount>MAXSHOWDOT) Fx->RecCount=MAXSHOWDOT;
		if(Fx->ShowDot>Fx->RecCount) Fx->ShowDot=Fx->RecCount;
	}
	if(!Fx->MainData)
		Fx->MainData=(MAIN_DATA *)_fmalloc(sizeof(MAIN_DATA)*Fx->RecCount);
	else 
		Fx->MainData=(MAIN_DATA *)_frealloc(Fx->MainData,sizeof(MAIN_DATA)*Fx->RecCount);
		
	memset(Fx->MainData,0,sizeof(K_DATA)*Fx->RecCount);
	
    //ȡ��ʷ���� ����������
	for(i=Fx->TotalCount-Fx->RecCount,j=0;i<Fx->TotalCount&&!Fx->IsDataOk;i++)
	{
	    memset(&DayBuff,0,sizeof(DAY_DATA));
	 	if(_llseek(hFile,i*sizeof(DAY_DATA),SEEK_SET)==HFILE_ERROR) 
	 	{
	 	    _lclose(hFile);
	 		return FALSE;    
	 	}	
		if(_lread(hFile,&DayBuff,sizeof(DAY_DATA))==HFILE_ERROR)
		{                 
			_lclose(hFile);
			return FALSE;
   	 	}
   	 	if(Fx->range>MIN_60)
   	 		sprintf(KBuff.date,"%ld",DayBuff.day);
   	 	else
   	 		sprintf(KBuff.date,"%04ld%02ld%02ld",DayBuff.day/1000,
   	 			(DayBuff.day%1000L)/60L,(DayBuff.day%1000L)%60L);
   	 	KBuff.ks=DayBuff.kpjg;
   	 	KBuff.ss=DayBuff.spjg;
   	 	KBuff.zg=DayBuff.zgjg;
   	 	KBuff.zd=DayBuff.zdjg;
   	 	KBuff.cj=DayBuff.cjss;
   	 	 
   	 	if(KBuff.zg<=0||KBuff.zd<=0||KBuff.ss<=0||KBuff.ks<=0) 
   	 		continue;
        memcpy(&Fx->MainData[j],&KBuff,sizeof(MAIN_DATA));
	 	j++;
	} 
	_lclose(hFile);	
	Fx->RecCount=(int)j;
	
	//�������� 
	if(Fx->range ==WEEK)
	{
		i=j=0;
		while(i<Fx->RecCount)
		{
			strcpy(KBuff.date,Fx->MainData[i].date);
			KBuff.cj =Fx->MainData[i].cj;
			KBuff.zg =Fx->MainData[i].zg;
			KBuff.zd =Fx->MainData[i].zd;
			KBuff.ks =Fx->MainData[i].ks;
			KBuff.ss =Fx->MainData[i].ss;
		    
		    i++;
			while(i<Fx->RecCount&&CompWeek(KBuff.date,Fx->MainData[i].date)==0) 
			{
				KBuff.cj+=Fx->MainData[i].cj;
				KBuff.ss =Fx->MainData[i].ss;
				if(KBuff.zg<Fx->MainData[i].zg)
					KBuff.zg=Fx->MainData[i].zg;
				if(KBuff.zd>Fx->MainData[i].zd)
					KBuff.zd=Fx->MainData[i].zd;
				i++;
			}
			strcpy(Fx->MainData[j].date,KBuff.date);
            Fx->MainData[j].ks =KBuff.ks;
            Fx->MainData[j].ss =KBuff.ss;
            Fx->MainData[j].zg =KBuff.zg;
            Fx->MainData[j].zd =KBuff.zd;
            Fx->MainData[j].cj =KBuff.cj;
            j++;
		}
		Fx->RecCount=(int)j;
	} 
	
	//��������
	if(Fx->range ==MONTH)
	{
		i=j=0;
		while(i<Fx->RecCount)
		{
			strcpy(KBuff.date,Fx->MainData[i].date);
			KBuff.cj =Fx->MainData[i].cj;
			KBuff.zg =Fx->MainData[i].zg;
			KBuff.zd =Fx->MainData[i].zd;
			KBuff.ks =Fx->MainData[i].ks;
			KBuff.ss =Fx->MainData[i].ss;
		    
		    i++;
			while(i<Fx->RecCount&&strncmp(KBuff.date,Fx->MainData[i].date,6)==0)
			{
				KBuff.cj+=Fx->MainData[i].cj;
				KBuff.ss =Fx->MainData[i].ss;
				if(KBuff.zg<Fx->MainData[i].zg)
					KBuff.zg=Fx->MainData[i].zg;
				if(KBuff.zd>Fx->MainData[i].zd)
					KBuff.zd=Fx->MainData[i].zd;
				i++;
			}
			strcpy(Fx->MainData[j].date,KBuff.date);
            Fx->MainData[j].ks =KBuff.ks;
            Fx->MainData[j].ss =KBuff.ss;
            Fx->MainData[j].zg =KBuff.zg;
            Fx->MainData[j].zd =KBuff.zd;
            Fx->MainData[j].cj =KBuff.cj;
            j++;
		}
		Fx->RecCount=(int)j;
	} 
	
	Fx->ShowDot=DEFSHOWDOT;
	if(Fx->ShowDot>Fx->RecCount) Fx->ShowDot=Fx->RecCount ;		
	
	//����K������  
	InitObjectOne();
	//���سɽ�������
	InitObjectTwo();
	//�����������
    for(i=0;i<Fx->PaintPara.num;i++)
    {
    	if(INIT_TABLE[i].type ==Fx->type)
    		break;
    }
    if(i>=Fx->PaintPara.num)
    {
    	i=0;
    	Fx->type =IDM_FX_MACD;
    }
    strcpy(Fx->Para->name,INIT_TABLE[i].name);
	GetAnalysePara(Fx->Para);      
    (*INIT_TABLE[i].CreateData)(Fx->MainData,Fx->RecCount,Fx->Data,Fx->Para);
    
	Fx->CurRecPrt=Fx->RecCount-Fx->ShowDot;
	if(Fx->CurRecPrt<0)
		Fx->CurRecPrt=0;
	Fx->PaintPara.IsScroll=FALSE;
	if(Fx->RecCount>0) 
		Fx->IsDataOk=TRUE;
	else
		Fx->IsDataOk=FALSE;
	Fx->PaintPara.IsMax=FALSE;
	Fx->PaintPara.IsAvLineShow=TRUE;
	return TRUE;
}


int FxExit(LPFX Fx)
{
    int i;
     
	if(Fx==0) return TRUE;
    if(Fx->MainData)
    	_ffree(Fx->MainData);
    for(i=0;i<10;i++)
    {
    	//unload object 1
    	if(Fx->KxData.v[i]!=NULL)
    	{   
    		_ffree(Fx->KxData.v[i]);
    		Fx->KxData.v[i]=NULL;
    	}
    	//unload object 2
    	if(Fx->CjlData.v[i]!=NULL)
    	{   
    		_ffree(Fx->CjlData.v[i]);
    		Fx->CjlData.v[i]=NULL;
    	}
    	//unload object 3
        if(Fx->Data->v==NULL) 
        	continue;
    	if(Fx->Data->v[i]!=NULL)
    	{
    		_ffree(Fx->Data->v[i]);
    		Fx->Data->v[i]=NULL;
    	}
    }    
	if(Fx->PaintPara.hFont!=NULL)
    	DeleteObject(Fx->PaintPara.hFont);
    
    if(Fx->Para)
    	_ffree(Fx->Para);
    if(Fx->Data)
    	_ffree(Fx->Data);
	_ffree(Fx);
    
    _ffree(DIAGR_NAME);
    _ffree(INIT_TABLE);
	Fx->IsDataOk=FALSE;
	return 	TRUE;
}

void FxFreeData(LPFX Fx)
{
	int i;
	
	if(Fx->MainData)
	{
    	_ffree(Fx->MainData);
    	Fx->MainData=0;
    }
    
    for(i=0;i<10;i++)
    {
    	//unload object 1
    	if(Fx->KxData.v[i]!=NULL)
    	{   
    		_ffree(Fx->KxData.v[i]);
    		Fx->KxData.v[i]=NULL;
    	}
    	//unload object 2
    	if(Fx->CjlData.v[i]!=NULL)
    	{   
    		_ffree(Fx->CjlData.v[i]);
    		Fx->CjlData.v[i]=NULL;
    	}
    	//unload object 3
        if(Fx->Data->v==NULL) 
        	continue;
    	if(Fx->Data->v[i]!=NULL)
    	{
    		_ffree(Fx->Data->v[i]);
    		Fx->Data->v[i]=NULL;
    	}
    }   	
	Fx->IsDataOk=FALSE;
	Fx->ShowDot=0;
} 

/*
BOOL CreateHistoryData(int range,char *gpdm)
{
	char f1[80],f2[80];
	OFSTRUCT os;
	HFILE hf1,hf2;
	GRA_HEAD GraHead;
	GRA_DATA GraData;
	DAY_DATA HistData,buff;
	long ltim;
	int i;
	
	sprintf(f1,"%s\\%s.dat",szDataPath,gpdm);
	sprintf(f2,"%s\\%s.%d",szDataPath,gpdm,MIN_5);
	
	hf2 =OpenFile(f2,&os,OF_READWRITE|OF_SHARE_DENY_NONE);
	if(hf2==HFILE_ERROR)
	{
		hf2 =OpenFile(f2,&os,OF_READWRITE|OF_SHARE_DENY_NONE|OF_CREATE);
		if(hf2==HFILE_ERROR) return FALSE;
	}
	hf1 =OpenFile(f1,&os,OF_READ|OF_SHARE_DENY_NONE);
	if(hf1!=HFILE_ERROR)
	{
		_lread(hf1,&GraHead,sizeof(GRA_HEAD));
		_lseek(hf1,sizeof(GRA_HEAD)+sizeof(GRA_DATA)*(GraHead.minTotal-1),
			SEEK_SET);
		_lread(hf1,&GraData,sizeof(GRA_DATA));
		if(filelength(hf2)>0)
		{
			_lseek(hf2,-1L*sizeof(DAY_DATA),SEEK_END);
			_lread(hf2,&HistData,sizeof(DAY_DATA));			
		}
		if(filelength(hf2)==0||HistData.day/1000<GraHead.dateNum)
		{
			memset(&HistData,0,sizeof(DAY_DATA));
			_lseek(hf1,sizeof(GRA_HEAD),SEEK_SET);
		 	for(i=0;i<GraHead.minTotal;i++)
		 	{
		 		
		 		if(_lread(hf1,&GraData,sizeof(GRA_DATA))!=sizeof(GRA_DATA))
		 			break;
		 		if(GraData.tim ==0)
		 			continue;
		 		if(HistData.day !=0&&GraData.tim>=HistData.day%1000+5)
		 		{
		 			_lwrite(hf2,&HistData,sizeof(DAY_DATA));
		 			memset(&HistData,0,sizeof(DAY_DATA));
		 		}	
		 		if(HistData.day ==0)		 			
		 			HistData.kpjg =GraData.zjjg +GraHead.zrsp;
		 		HistData.spjg =GraData.zjjg+GraHead.zrsp;
		 		if(HistData.day ==0)
		 			HistData.zgjg =HistData.zdjg =GraData.zjjg+GraHead.zrsp;
		 		else
		 		{
		 			if(HistData.zgjg<GraData.zjjg+GraHead.zrsp)
		 				HistData.zgjg=GraData.zjjg+GraHead.zrsp;
		 			if(HistData.zdjg>GraData.zjjg+GraHead.zrsp)
		 				HistData.zdjg=GraData.zjjg+GraHead.zrsp;
		 		}
		 		HistData.cjss +=GraData.lc;
		 		if(HistData.day ==0)
		 			HistData.day =(long)GraHead.dateNum*1000 +GraData.tim;
		 	}
		 	if(HistData.day!=0)
		 		_lwrite(hf2,&HistData,sizeof(DAY_DATA));		 	
		}
		else if(HistData.day/1000==GraHead.dateNum&&
				GraData.tim>HistData.day%1000+5)
		{			
			_lseek(hf1,sizeof(GRA_HEAD),SEEK_SET);
			ltim =HistData.day%1000;
			memset(&HistData,0,sizeof(DAY_DATA));
		 	for(i=0;i<GraHead.minTotal;i++)
		 	{
		 		if(_lread(hf1,&GraData,sizeof(GRA_DATA))!=sizeof(GRA_DATA))
		 			break;
		 		if(GraData.tim ==0)
		 			continue;
		 		if(ltim>=GraData.tim)
		 			continue;
		 		if(HistData.day !=0&&GraData.tim>=HistData.day%1000+5)
		 		{
		 			_lwrite(hf2,&HistData,sizeof(DAY_DATA));
		 			memset(&HistData,0,sizeof(DAY_DATA));
		 		}		 			
		 		if(HistData.day ==0)
		 			HistData.kpjg =GraData.zjjg+GraHead.zrsp;
		 		HistData.spjg =GraData.zjjg+GraHead.zrsp;
		 		if(HistData.day ==0)
		 			HistData.zgjg =HistData.zdjg =GraData.zjjg+GraHead.zrsp;
		 		else
		 		{
		 			if(HistData.zgjg<GraData.zjjg+GraHead.zrsp)
		 				HistData.zgjg=GraData.zjjg+GraHead.zrsp;
		 			if(HistData.zdjg>GraData.zjjg+GraHead.zrsp)
		 				HistData.zdjg=GraData.zjjg+GraHead.zrsp;
		 		}
		 		HistData.cjss +=GraData.lc;
		 		if(HistData.day ==0)
		 			HistData.day =(long)GraHead.dateNum*1000 +GraData.tim;
		 	}		
		 	if(HistData.day !=0)
		 		_lwrite(hf2,&HistData,sizeof(DAY_DATA));		 	
		}
		_lclose(hf1);
	}
	if(range!=MIN_5)
	{
		sprintf(f1,"%s\\%s.%d",szDataPath,gpdm,range);	
		hf1 =OpenFile(f1,&os,OF_WRITE|OF_SHARE_DENY_NONE|OF_CREATE);
		if(hf1==HFILE_ERROR) return FALSE;
		memset(&HistData,0,sizeof(DAY_DATA));
		if(filelength(hf2)/sizeof(DAY_DATA)>MAXSHOWDOT)
			_lseek(hf2,-1L*sizeof(DAY_DATA)*MAXSHOWDOT,SEEK_END);
		else
			_lseek(hf2,0L,SEEK_SET);
		for(;;)
		{
		 	if(_lread(hf2,&buff,sizeof(DAY_DATA))!=sizeof(DAY_DATA))
		 		break;
		 	if(HistData.day!=0&&buff.day%1000>=HistData.day%1000+atoi(RANGE_NAME[range]))
		 	{
		 		_lwrite(hf1,&HistData,sizeof(DAY_DATA));
		 		memset(&HistData,0,sizeof(DAY_DATA));		 	
		 	}
		 	if(HistData.day ==0) HistData.kpjg =buff.kpjg;
		 	HistData.spjg =buff.spjg;
		 	if(HistData.day ==0)
		 	{
		 		HistData.zgjg =buff.zgjg;
		 		HistData.zdjg =buff.zdjg;
		 	}
		 	else
		 	{
		 		if(HistData.zgjg<buff.zgjg)
		 			HistData.zgjg=buff.zgjg;
		 		if(HistData.zdjg>buff.zdjg)
		 			HistData.zdjg=buff.zdjg;
		 	}
		 	HistData.cjss +=buff.cjss;
		 	if(HistData.day ==0)
		 		HistData.day =buff.day;
		}
		 if(HistData.day !=0)
		 	_lwrite(hf1,&HistData,sizeof(DAY_DATA));		
		_lclose(hf1);
	}
	_lclose(hf2);
	return TRUE;
} 
*/

BOOL CreateHistoryData(int range,char *gpdm)
{
	char f1[80],f2[80];
	OFSTRUCT os;
	HFILE hf1,hf2;
	GRA_HEAD GraHead;
	GRA_DATA GraData;
	DAY_DATA HistData,buff;
	int i,am_start,am_end,jys,pm_start,pm_end;
	int area_start,area_end;
	
	jys =strlen(gpdm)==4?0:1;
	
	am_start =HqTime[jys].am_min_start;
	am_end =HqTime[jys].am_min_start+ HqTime[jys].am_min_count;
	pm_start =HqTime[jys].pm_min_start;
	pm_end =HqTime[jys].pm_min_start+ HqTime[jys].pm_min_count;
	
	area_start =HqTime[jys].am_min_start;
	area_end =area_start+5<=am_end?area_start+5:area_start+5+pm_start-am_end;
		
	sprintf(f1,"%s\\%s.dat",szDataPath,gpdm);
	sprintf(f2,"%s\\%s.%d",szDataPath,gpdm,MIN_5);
	
	hf2 =OpenFile(f2,&os,OF_READWRITE|OF_SHARE_DENY_NONE|OF_CREATE);
	if(hf2==HFILE_ERROR) return FALSE;
	
	hf1 =OpenFile(f1,&os,OF_READ|OF_SHARE_DENY_NONE);
	if(hf1!=HFILE_ERROR)
	{
		_lread(hf1,&GraHead,sizeof(GRA_HEAD));
		_lread(hf1,&GraData,sizeof(GRA_DATA));
		
		for(;;)
		{
			if(GraData.tim>area_end)
			{
				area_start =area_end;
				area_end =area_start+5<=am_end?area_start+5:
					area_start>pm_start?area_start+5:area_start+5+pm_start-am_end;					
			}
			else break;
			if(area_start>pm_end)
				break;
		}
		
		if(area_start<=pm_end)
		{
			memset(&HistData,0,sizeof(DAY_DATA));
			
			HistData.day =(long)GraHead.dateNum*1000 +area_start;
			HistData.kpjg =GraData.zjjg +GraHead.zrsp;
			HistData.zgjg =HistData.zdjg =GraData.zjjg+GraHead.zrsp;
			
			_lseek(hf1,sizeof(GRA_HEAD),SEEK_SET);
		 	for(i=0;i<GraHead.minTotal;i++)
		 	{
		 		
		 		if(_lread(hf1,&GraData,sizeof(GRA_DATA))!=sizeof(GRA_DATA))
		 			break;
		 		if(GraData.tim ==0)
		 			continue;
		 		
		 		if(GraData.tim<area_end&&GraData.tim>=area_start)
		 		{
		 			HistData.spjg =GraData.zjjg+GraHead.zrsp;
		 			
		 			if(HistData.zgjg<GraData.zjjg+GraHead.zrsp)
		 				HistData.zgjg=GraData.zjjg+GraHead.zrsp;
		 			if(HistData.zdjg>GraData.zjjg+GraHead.zrsp)
		 				HistData.zdjg=GraData.zjjg+GraHead.zrsp;		 			
		 			HistData.cjss +=GraData.lc;		 			
		 		}
		 		else
		 		{
		 			//HistData.day =(long)GraHead.dateNum*1000 +area_end;
		 			_lwrite(hf2,&HistData,sizeof(DAY_DATA));
                    
					area_start =area_end;
					area_end =area_start+5<=am_end?area_start+5:
					area_start>pm_start?area_start+5:area_start+5+pm_start-am_end;
                    
					for(;;)
					{
						if(GraData.tim>area_end)
						{
							area_start =area_end;
							area_end =area_start+5<=am_end?area_start+5:
							area_start>pm_start?area_start+5:area_start+5+pm_start-am_end;
						}
						else break;
						if(area_start>pm_end)
							break;
					}
		 			
		 			memset(&HistData,0,sizeof(DAY_DATA));   
		 			
		 			HistData.spjg =GraData.zjjg+GraHead.zrsp;		 			
		 			HistData.kpjg =GraData.zjjg +GraHead.zrsp;
		 			HistData.zgjg =HistData.zdjg =GraData.zjjg+GraHead.zrsp;
		 			
		 			HistData.cjss +=GraData.lc;		 			
		 			HistData.day =(long)GraHead.dateNum*1000 +area_start;		 			
		 		}	
		 	}		 	
		 	if(HistData.day!=0)
		 		_lwrite(hf2,&HistData,sizeof(DAY_DATA));		 	
		}
		_lclose(hf1);
	}
	if(range!=MIN_5)
	{
		sprintf(f1,"%s\\%s.%d",szDataPath,gpdm,range);	
		hf1 =OpenFile(f1,&os,OF_WRITE|OF_SHARE_DENY_NONE|OF_CREATE);
		if(hf1==HFILE_ERROR) return FALSE;
		memset(&HistData,0,sizeof(DAY_DATA));
		if(filelength(hf2)/sizeof(DAY_DATA)>MAXSHOWDOT)
			_lseek(hf2,-1L*sizeof(DAY_DATA)*MAXSHOWDOT,SEEK_END);
		else
			_lseek(hf2,0L,SEEK_SET);
		for(;;)
		{
		 	if(_lread(hf2,&buff,sizeof(DAY_DATA))!=sizeof(DAY_DATA))
		 		break;
		 	if(HistData.day!=0&&buff.day%1000>=HistData.day%1000+atoi(RANGE_NAME[range]))
		 	{
		 		_lwrite(hf1,&HistData,sizeof(DAY_DATA));
		 		memset(&HistData,0,sizeof(DAY_DATA));		 	
		 	}
		 	if(HistData.day ==0) HistData.kpjg =buff.kpjg;
		 	HistData.spjg =buff.spjg;
		 	if(HistData.day ==0)
		 	{
		 		HistData.zgjg =buff.zgjg;
		 		HistData.zdjg =buff.zdjg;
		 	}
		 	else
		 	{
		 		if(HistData.zgjg<buff.zgjg)
		 			HistData.zgjg=buff.zgjg;
		 		if(HistData.zdjg>buff.zdjg)
		 			HistData.zdjg=buff.zdjg;
		 	}
		 	HistData.cjss +=buff.cjss;
		 	if(HistData.day ==0)
		 		HistData.day =buff.day;
		}
		 if(HistData.day !=0)
		 	_lwrite(hf1,&HistData,sizeof(DAY_DATA));		
		_lclose(hf1);
	}
	_lclose(hf2);
	return TRUE;
} 

HBITMAP getImage(HDC hDC, LPRECT rc)
{
	HBITMAP hBmp, hOldBmp;
	HDC hdc =CreateCompatibleDC(hDC);
	hBmp =CreateCompatibleBitmap(hDC, rc->right-rc->left, rc->bottom-rc->top);
	hOldBmp =SelectObject(hdc, hBmp);
	BitBlt(hdc, 0, 0, rc->right-rc->left, rc->bottom-rc->top, hDC, rc->left, rc->top, SRCCOPY);
	SelectObject(hdc, hOldBmp);
	DeleteObject(hdc);
	return hBmp;
}

int putImage(HDC hDC, HBITMAP hBmp, LPRECT rc)
{
	HDC hdc =CreateCompatibleDC(hDC);
	SelectObject(hdc, hBmp);
	BitBlt(hDC, rc->left, rc->top, rc->right-rc->left, rc->bottom-rc->top, hdc, 0, 0, SRCCOPY);
	DeleteObject(hdc);
	return hBmp;
}

int DrawScroll(LPFX Fx,int orient)
{
	
	HDC hDc;
	static int pos,recnum;
	char tmp[100];
	int i,j,htitle,wleft,repl,num,gap,tune,ltitle;
	DATA *lpData;
	PARA *lpPara;
		
	if(Fx->KxData.v==NULL) return TRUE;
	if(Fx->PaintPara.IsPainting) return TRUE;
    if(!Fx->PaintPara.IsScroll&&orient==SCROLL_CANCEL)
    	return TRUE;
	lpData =&Fx->KxData;
	lpPara =&Fx->KxPara;
	
	hDc =GetDC(ghWndFx);	
	SetBkColor(hDc,RGB(0,0,0));
	SelectObject(hDc,Fx->PaintPara.hFont);
	SetROP2(hDc, R2_NOT);
	tune =FRAME_WIDTH;
    do
    {   
    	if(lpPara->rc.bottom==0)
    	{
        	lpData =lpData->next;
    		lpPara =lpPara->next;
    		continue;
        }
        repl =pos;
        num =recnum;
        htitle =lpPara->htitle+tune;
        gap =(int)((lpPara->fwdt*80/100)/2)+tune;
        wleft =Fx->PaintPara.wleft+gap;
    	if(!Fx->PaintPara.IsScroll) 
    	{
    		if(orient==SCROLL_LEFT||orient==SCROLL_END)
    		{    	
    			repl=Fx->ShowDot;				 //pos:1->show
    			num=Fx->CurRecPrt+Fx->ShowDot-1; //num:prt ->prt +show -1
    		}
    		if(orient==SCROLL_RIGHT||orient==SCROLL_HOME)
    		{
    			repl=1;
    			num=Fx->CurRecPrt;    	
    		}	
    		MoveTo(hDc,(int)(repl*lpPara->fwdt)+wleft,lpPara->rc.top+htitle+1);
    		LineTo(hDc,(int)(repl*lpPara->fwdt)+wleft,lpPara->rc.bottom-1);
    	}
    	else
    	{
    		if(orient==SCROLL_RIGHT)
    		{   
    			//����
    	 		if(++repl>Fx->ShowDot) 
    	 		{
    		    	if(Fx->CurRecPrt<Fx->RecCount-1-Fx->ShowDot)
    		    	{                                   //�һ�ҳ
						SetTimer(ghWndFx, 1, 500, NULL); 
						Fx->PaintPara.IsPainting=TRUE;
    					Fx->CurRecPrt=Fx->CurRecPrt+Fx->ShowDot*2<Fx->RecCount-1 
    						? Fx->CurRecPrt+Fx->ShowDot:Fx->RecCount-Fx->ShowDot;
						Fx->PaintPara.IsScroll=FALSE;
						if(Fx->PaintPara.IsUpDown)
		            		UpDown(Fx,0);		            		
						InvalidateRect(ghWndFx, NULL, FALSE);
						Fx->PaintPara.IsScroll=FALSE;
						ReleaseDC(ghWndFx, hDc);
						return 0;						
					}
					else
					{					
						repl=Fx->ShowDot;                //��ҳ����
						num =Fx->CurRecPrt+Fx->ShowDot-1;
					}
    	 		}	                                    
    	 		else
    	 		{                                       
    	 			repl--;                              //���� 
    				MoveTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.top+htitle+1);
    				LineTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.bottom-1);
    	 			if(++num>Fx->RecCount)	
    	 					num=Fx->RecCount;
    	 			repl++;
    				MoveTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.top+htitle+1);
    				LineTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.bottom-1);
    	 		}    	 	
    		}
        	if(orient==SCROLL_LEFT)
    		{  
    			//����
    			repl--;
    			if(repl<1)
    			{
    		    	if(Fx->CurRecPrt>0)
    		    	{                    //��ҳ
						SetTimer(ghWndFx, 1, 500, NULL); 
						Fx->PaintPara.IsPainting=TRUE;   		    
    					Fx->CurRecPrt=Fx->CurRecPrt-Fx->ShowDot>=0 ? Fx->CurRecPrt-=Fx->ShowDot:0;
						Fx->PaintPara.IsScroll=FALSE; 
						if(Fx->PaintPara.IsUpDown)
		            		UpDown(Fx,0);
						InvalidateRect(ghWndFx, NULL, FALSE);						
						Fx->PaintPara.IsScroll=FALSE;
						ReleaseDC(ghWndFx, hDc);
						return 0;						
					}
					else
					{
						repl=1;	         //��ҳ����
						num =0;
					}
    			}	
    			else
    			{	  
    				repl++;               //����    				
    				MoveTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.top+htitle+1);    	
    				LineTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.bottom-1);
    				repl--;
    	 			num--;
    	 			if(recnum<0) num=0; 
    				MoveTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.top+htitle+1);
    				LineTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.bottom-1);
    			}
    		}
    		//��[END]��
    		if(orient==SCROLL_END)
    		{
    			MoveTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.top+htitle+1);    	
    			LineTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.bottom-1);
    			repl=Fx->ShowDot;
    			num=Fx->CurRecPrt+Fx->ShowDot-1;
    			MoveTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.top+htitle+1);    	
    			LineTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.bottom-1);
    		}
    		//��[HOME]��
    		if(orient==SCROLL_HOME)
    		{
    			MoveTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.top+htitle+1);
    			LineTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.bottom-1);
    			repl=1;
    			num=Fx->CurRecPrt;
    			MoveTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.top+htitle+1);
    			LineTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.bottom-1);
    		}    	
    		//����SCROLL 
			if(orient==SCROLL_CANCEL)
			{
    			MoveTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.top+htitle+1);
    			LineTo(hDc,(int)(repl*lpPara->fwdt) +wleft,lpPara->rc.bottom-1);
    		}    	   	
    	}
    	lpData =lpData->next;
    	lpPara =lpPara->next;
    }while(lpData!=NULL&&lpPara!=NULL);

    pos =repl;
    recnum =num;
    SetTextColor(hDc,RGB(0,255,255));
    SetROP2(hDc, R2_COPYPEN);
    SetTextAlign(hDc, TA_LEFT|TA_TOP);    
    if(orient==SCROLL_CANCEL)
    {   
		Fx->PaintPara.IsScroll=FALSE;
		Msg("",MSG_HIDE);
		ReleaseDC(ghWndFx, hDc);
		return 0;
    }
    else
    {       
        i=(int)(Fx->PaintPara.rc.right/2)+5;
        Fx->MainData[recnum].date[8] =0;
   		sprintf(tmp, "��:%5.2f��:%5.2f�ɽ�:%6ld",
   				Fx->MainData[recnum].ks, Fx->MainData[recnum].ss,
				Fx->MainData[recnum].cj);
   		sprintf(tmp, "%s��:%5.2f��:%5.2f����:%8s",tmp,
   				Fx->MainData[recnum].zg, Fx->MainData[recnum].zd,
   				Fx->MainData[recnum].date);
   		Msg(tmp,MSG_VERT|MSG_TIME);
   	}
    Fx->PaintPara.IsScroll=TRUE;
    SetBkColor(hDc,RGB(0,0,0));
    SetTextAlign(hDc, TA_LEFT|TA_TOP);   	
   	lpData =&Fx->KxData;
   	lpPara =&Fx->KxPara;
   	
   	do
   	{   
   		ltitle =(lpPara->xtitle[1]-lpPara->xtitle[0])/2;
   		htitle =lpPara->htitle;
    	for(i=0,j=0;i<10&&lpPara->rc.bottom>0;i++)
    	{
    		if(lpPara->color[i]==0)
    			continue;
    		if(strlen(lpPara->pname[i])==0)	
    			continue;
    		if(lpData->method[0]==VOULMN_BAR_METHOD)
    		    sprintf(tmp,"%.0f",lpData->v[i][recnum]);
    		else
    			sprintf(tmp,"%.2f",lpData->v[i][recnum]);
    		SelectObject(hDc,GetStockObject(BLACK_BRUSH));
    		SetBkMode(hDc, OPAQUE);
    		Rectangle(hDc,lpPara->xtitle[j],lpPara->rc.top+4,
    				  lpPara->xtitle[j]+ltitle,lpPara->rc.top+htitle);
    	    //SetBkMode(hDc, TRANSPARENT);	
    		SetTextColor(hDc,lpPara->color[i]);
    		TextOut(hDc,lpPara->xtitle[j],lpPara->rc.top+4,tmp,strlen(tmp));
    		j++;
    	}
    	lpData =lpData->next;
    	lpPara =lpPara->next;
    }while(lpData!=NULL&&lpPara!=NULL);
	ReleaseDC(ghWndFx, hDc);
	return TRUE;
}

int UpDown(LPFX Fx,int orient)
{    
	HDC hDc;
	static int pos;
	static double start,step;
	HPEN hPen;
	char temp[10];
	int chars,wleft,htitle;
	static HBITMAP hBmp =NULL;
	static RECT rc;
    DATA *lpData;
    PARA *lpPara;

    if(orient==0&&!Fx->PaintPara.IsUpDown)
    	return TRUE;
    lpData =FindOpData();
    lpPara =FindOpPara();
    if(lpData==NULL||lpPara==NULL)
    {
    	lpData =&Fx->KxData;
    	lpPara =&Fx->KxPara;    
    }
    
	hDc =GetDC(ghWndFx);
	SelectObject(hDc,Fx->PaintPara.hFont);
	SetROP2(hDc, R2_NOT);
    SetTextAlign(hDc, TA_RIGHT|TA_TOP);
    SetBkColor(hDc,RGB(255,255,255));
    SetTextColor(hDc,RGB(255,0,0));
    hPen=CreatePen(PS_SOLID,1,RGB(200,0,0));
    SelectObject(hDc,hPen);
    
    SetRect(&lpPara->rc,lpPara->rc.left,lpPara->rc.top+FRAME_WIDTH,
            lpPara->rc.right,lpPara->rc.bottom-FRAME_WIDTH);
                    
    htitle =lpPara->htitle;
    wleft =Fx->PaintPara.wleft;
	SetViewportOrg(hDc, lpPara->rc.left+wleft,
		(int)(lpPara->price[0]*lpPara->fhdj)+lpPara->rc.top+htitle);
	
    if(!Fx->PaintPara.IsUpDown)
    {   
    	Fx->PaintPara.IsUpDown=TRUE;    	
    	start=lpPara->price[1];
    	step=(lpPara->price[0]-lpPara->price[1])/60;
    	pos=-(int)(start*lpPara->fhdj);
    	MoveTo(hDc,lpPara->rc.left,pos);
    	LineTo(hDc,lpPara->rc.right,pos);
    	sprintf(temp,"%7.2f",start);
    	chars=LOWORD(GetTextExtent(hDc,temp,strlen(temp)));
		rc.left =lpPara->rc.left-chars;
		rc.top =pos;
		rc.right =rc.left +60;
		rc.bottom =rc.top +13;
		hBmp =getImage(hDc, &rc);
    	TextOut(hDc, rc.left+chars, rc.top, temp, strlen(temp));
    }
    else    
    {
    	if(orient!=0)
    	{    		
   			putImage(hDc, hBmp, &rc);
    		DeleteObject(hBmp);
    		MoveTo(hDc,lpPara->rc.left,pos);
    		LineTo(hDc,lpPara->rc.right,pos);
    		if(lpData->method[0]==VOULMN_BAR_METHOD)
    			sprintf(temp,"%7.0f",start);
    		else
    			sprintf(temp,"%7.2f",start);
    		
			start+=orient*step;
			if(start>=lpPara->price[0]||start<lpPara->price[1])
				start-=orient*step;
    		pos=-(int)(start*lpPara->fhdj);    	
    		
    		MoveTo(hDc,lpPara->rc.left,pos);
    		LineTo(hDc,lpPara->rc.right,pos);
    		if(lpData->method[0]==VOULMN_BAR_METHOD)
    			sprintf(temp,"%7.0f",start);
    		else
    			sprintf(temp,"%7.2f",start);
    		chars=LOWORD(GetTextExtent(hDc,temp,strlen(temp)));    		
			rc.left =lpPara->rc.left-chars;
			rc.top =pos;
			rc.right =rc.left +60;
			rc.bottom =rc.top +13;
			hBmp =getImage(hDc, &rc);
    		TextOut(hDc, rc.left+chars, rc.top, temp, strlen(temp));
    	}
    	else
    	{
    		putImage(hDc, hBmp, &rc);
    		DeleteObject(hBmp);
    		Fx->PaintPara.IsUpDown=FALSE;
    		MoveTo(hDc,lpPara->rc.left,pos);
    		LineTo(hDc,lpPara->rc.right,pos);
    		if(lpData->method[0]==VOULMN_BAR_METHOD)
    			sprintf(temp,"%7.0f",start);
    		else
    			sprintf(temp,"%7.2f",start);
    		pos=-(int)(lpPara->price[1]*lpPara->fhdj);
    	}
    }
    SelectObject(hDc, GetStockObject(WHITE_PEN));
    DeleteObject(hPen);
	ReleaseDC(ghWndFx, hDc);	
    SetRect(&lpPara->rc,lpPara->rc.left,lpPara->rc.top-FRAME_WIDTH,
            lpPara->rc.right,lpPara->rc.bottom+FRAME_WIDTH);
	
	return TRUE;
}
