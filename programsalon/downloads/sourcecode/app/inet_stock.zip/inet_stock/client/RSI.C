#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "fx.h"

extern LPFX Fx;

int CreateRsiData(K_DATA *lpKData,int RNum,DATA *Data,PARA *Para)
{
    
	int i,j,k,l; 
    long m;
	double Tun[2],Tdn[2];
	RSI_DATA *RsiData;
	
	RsiData=(RSI_DATA*)_fmalloc(sizeof(RSI_DATA)*RNum);
	memset(RsiData,0,sizeof(RSI_DATA)*RNum);
	for(j=0;j<RNum;j++)
	{
    	if(j==0)
   		{   
   			for(k=0;k<2;k++)
    		{
    	     	RsiData[j].un[k]=0;
    	     	RsiData[j].dn[k]=0;
    	     	Tun[k]=0;
    	     	Tdn[k]=0;
    	     	if(lpKData[j].ks<lpKData[j].ss)
    	     	{
    	     		RsiData[j].un[k]=lpKData[j].ss-lpKData[j].ks;
    	     	}
    	     	if(lpKData[j].ss<lpKData[j].ks)
    	     	{
    	     		RsiData[j].dn[k]=lpKData[j].ks-lpKData[j].ss;
    	     	}    	     		
    		}	
    	}
    	else
    	{   
    		 for(k=0;k<2;k++)
    	 	{
    	    	if(j<=Para->periods[k]-1)
    	    	{    
    	     		if(lpKData[j-1].ss<lpKData[j].ss)
    	     		{
    	     			RsiData[j].un[k]=RsiData[j-1].un[k]+
    	     				lpKData[j].ss-lpKData[j-1].ss;
    	     		}
    	     		if(lpKData[j-1].ss>lpKData[j].ss)
    	     		{
    	     			RsiData[j].dn[k]=RsiData[j-1].dn[k]+
    	     					lpKData[j-1].ss-lpKData[j].ss;
    	     		} 
    	    	}
    	    	m=Para->periods[k];
    	    	if(j==Para->periods[k]-1)
    	    	{ 
    	     		if((RsiData[j].un[k]+RsiData[j].dn[k])!=0)
    	     			RsiData[j].rsi[k]=RsiData[j].un[k]/(RsiData[j].un[k]+RsiData[j].dn[k]);
    	    	}
    	    	if(j>Para->periods[k]-1)
    	    	{   
    	    		RsiData[j].un[k]=RsiData[j].dn[k]=0;
    	    		for(l=1;l<=Para->periods[k];l++)
    	    		{    	    		    
    	    			m=j+l-Para->periods[k];
    	    			if(lpKData[m-1].ss<lpKData[m].ss)
    	    			{
    	    		    	 	RsiData[j].un[k]+=lpKData[m].ss-lpKData[m-1].ss;
    	    			}
    	    			if(lpKData[m-1].ss>lpKData[m].ss)
    	    			{
    	    		    	RsiData[j].dn[k]+=lpKData[m-1].ss-lpKData[m].ss;
    	    			}    	    		     	
    	    		}
    	    		          
    	    		m=Para->periods[k];
    	    		RsiData[j].un[k] =RsiData[j-1].un[k]*(m-1)/(m+1)+RsiData[j].un[k]*2/(m+2);
    	    		RsiData[j].dn[k] =RsiData[j-1].dn[k]*(m-1)/(m+1)+RsiData[j].dn[k]*2/(m+2);
    	     		if((RsiData[j].un[k]+RsiData[j].dn[k])!=0)
    	     			RsiData[j].rsi[k]=RsiData[j].un[k]*100.00/(RsiData[j].un[k]+RsiData[j].dn[k]);    	     				
    	    	}    	    		
    	 	}	
    	}
    }
    for(j=0;j<10;j++)
    {
        if(Data->v==NULL) 
        	break;
    	if(Data->v[j]!=NULL)
    	{
    		_ffree(Data->v[j]);
    		Data->v[j]=NULL;
    	}
    }
    Data->v==NULL;     
    Data->num =Para->dnum; 
    Data->no =Para->no;
    strcpy(Data->gpdm,Fx->gpdm);
    Data->type =Fx->type;
    Data->range =Fx->range;
    Data->size =RNum;
    for(j=0;j<Data->num;j++)
    	Data->v[j]=(double *)_fmalloc(sizeof(double)*RNum);
    for(i=0;i<Data->num;i++)
    {
    	for(j=0;j<RNum;j++) 
    		Data->v[i][j]=RsiData[j].rsi[i];
    	Data->method[i]=CURVE_METHOD;
    }
    Para->price[0] =100;
    Para->price[1] =0;
    Para->price[2] =20;
    Para->price[3] =50;
    Para->price[4] =80;
    Para->feature |=DW_ALL;
    Para->feature &=~DW_MAX;
    Para->feature &=~DW_MIN;
    _ffree(RsiData);
	return TRUE;
} 

