#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "resource.h"
#include "global.h"
#include "fx.h"

int CreateMacdData(K_DATA *lpKData,int RNum,DATA *Data,PARA *Para)
{
    int j;
    MACD_DATA *MacdData;
    
    MacdData=(MACD_DATA*)_fmalloc(sizeof(MACD_DATA)*RNum);
    memset(MacdData,0,sizeof(MACD_DATA)*RNum);
    for(j=0;j<RNum;j++)
    {
    		if(j==0)
    		{
    		     Para->price[0]=0;
    		     MacdData[0].ema1=lpKData[0].ss;
    		     MacdData[0].ema2=lpKData[0].ss;
    		     MacdData[0].macd=MacdData[0].dif=0;
    		     MacdData[0].macd=MacdData[0].cha=0;
    		     Para->price[0]=0;
    		     continue;
    		}  
    	    MacdData[j].ema1=lpKData[j].ss*2/(Para->periods[0]+1)+
    	    	MacdData[j-1].ema1*(Para->periods[0]-1)/(Para->periods[0]+1);
    	    MacdData[j].ema2=lpKData[j].ss*2/(Para->periods[1]+1)+
    	    	MacdData[j-1].ema2*(Para->periods[1]-1)/(Para->periods[1]+1);
    	    	
    	    MacdData[j].dif=MacdData[j].ema1-MacdData[j].ema2;	
    	    MacdData[j].macd=MacdData[j].dif*2/(Para->periods[2]+1)+
    	        MacdData[j-1].macd*(Para->periods[2]-1)/(Para->periods[2]+1);
    	        
    	    MacdData[j].cha=MacdData[j].dif-MacdData[j].macd;    
    	    
    	    if(Para->price[0]<fabs(MacdData[j].dif)) 
    	     	Para->price[0]=fabs(MacdData[j].dif);
    	       
    	    if(Para->price[0]<fabs(MacdData[j].cha)) 
    	     	Para->price[0]=fabs(MacdData[j].cha);
    
    }
    
    for(j=0;j<10;j++)
    {
        if(Data->v==NULL) 
        	break;
    	if(Data->v[j]!=NULL)
    	{
    		_ffree(Data->v[j]);
    		Data->v[j]=NULL;
    	}
    }
    Data->v==NULL;     
    Data->num =Para->dnum; 
    Data->no =Para->no;
    strcpy(Data->gpdm,Fx->gpdm);
    Data->type =Fx->type;
    Data->range =Fx->range;
    Data->size =RNum;
    for(j=0;j<Data->num;j++)
    	Data->v[j]=(double *)_fmalloc(sizeof(double)*RNum);
    for(j=0;j<RNum;j++) 
    	Data->v[0][j]=MacdData[j].macd;
    Data->method[0]=CURVE_METHOD;
    for(j=0;j<RNum;j++) 
    	Data->v[1][j]=MacdData[j].dif;
    Data->method[1]=CURVE_METHOD;
    for(j=0;j<RNum;j++) 
    	Data->v[2][j]=MacdData[j].cha;
    Data->method[2]=VERT_LINE_METHOD;    
    Para->price[0] =0;
    Para->price[1] =0;
    Para->feature |=DW_ALL;
    _ffree(MacdData);
	return TRUE;
}

