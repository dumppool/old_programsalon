#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <math.h>
#include "resource.h"
#include "global.h"
#include "fx.h"

extern LPFX Fx;

int CreateDmiData(K_DATA *lpKData,int RNum,DATA *Data,PARA *Para)
{ 
 
 int i,j;
 long m;
 double jia1,jia2,jia3;
 double Ttr,Tpdm,Tndm,Tadx;
 DMI_DATA *DmiData;
                   
 DmiData=(DMI_DATA*)_fmalloc(sizeof(DMI_DATA)*RNum);
 memset(DmiData,0,sizeof(DMI_DATA)*RNum);
 for(j=0;j<RNum;j++)
 {
            if(j==0)
            {       
                Ttr=Tpdm=Tndm=Tadx=0;
             	jia1=fabs(lpKData[j].zg-lpKData[j].zd);
             	if(j>0)
             	{
             		jia2=fabs(lpKData[j].zd-lpKData[j-1].ss);
             		jia3=fabs(lpKData[j].zg-lpKData[j-1].ss);
             		Tpdm=DmiData[j].pdm=lpKData[j].zg - lpKData[j-1].zg;
             		if(DmiData[j].pdm<fabs(lpKData[j].zd - lpKData[j-1].zd))
             			Tpdm=DmiData[j].pdm=0;
             		Tndm=DmiData[j].ndm=lpKData[j].zd - lpKData[j-1].zd;
             		if(DmiData[j].ndm<fabs(lpKData[j].zg - lpKData[j-1].zg))
             			Tndm=DmiData[j].ndm=0;             			
             	}
             	else
             	{
             	 	jia2=jia3=0;
             	 	DmiData[j].pdm=DmiData[j].ndm=0;
             	}
             	Ttr=DmiData[j].tr=max(jia1,max(jia2,jia3));             	
             	DmiData[j].pdi=DmiData[j].ndi=0;
             	DmiData[j].dx=DmiData[j].adx=0;
             	Tadx=0;
            }
            else
            {
            	jia1=fabs(lpKData[j].zg-lpKData[j].zd);
             	jia2=fabs(lpKData[j].zd-lpKData[j-1].ss);
             	jia3=fabs(lpKData[j].zg-lpKData[j-1].ss);
            	DmiData[j].tr=max(jia1,max(jia2,jia3));
                
             	DmiData[j].pdm=lpKData[j].zg - lpKData[j-1].zg;
             	if(DmiData[j].pdm<0)	
             	    DmiData[j].pdm=0;
             	if(DmiData[j].pdm<fabs(lpKData[j].zd - lpKData[j-1].zd))
             		DmiData[j].pdm=0;
             	DmiData[j].ndm=lpKData[j-1].zd - lpKData[j].zd;
             	if(DmiData[j].ndm<0)
             	   DmiData[j].ndm=0;
             	if(DmiData[j].ndm<fabs(lpKData[j].zg - lpKData[j-1].zg))             		
             		DmiData[j].ndm=0;             			
                
            	if(j<=Para->periods[0]-1)
            	{                   
            	    Ttr+=DmiData[j].tr;
            	    Tpdm+=DmiData[j].pdm;
            	    Tndm+=DmiData[j].ndm;
            	    if(Tndm<0)
            	        Tndm=0;     
            	     
             		DmiData[j].pdi=DmiData[j].ndi=0;
             		DmiData[j].dx=DmiData[j].adx=0;            	
            	}
            	if(j>Para->periods[0]-1)
            	{   
            	    
            	    m=j-Para->periods[0];         	 		 
            	 	Ttr+=DmiData[j].tr-DmiData[m].tr;
            	 	Tpdm+=DmiData[j].pdm-DmiData[m].pdm;            	 		 
                    Tndm+=DmiData[j].ndm-DmiData[m].ndm;    	 		 
            	    if(Tndm<0)
            	        Tndm=0;
            	}
            	if(j>=Para->periods[0]-1)
            	{   
            		if(Ttr!=0)
            		{
            	    	DmiData[j].pdi=Tpdm/Ttr;
            	    	DmiData[j].ndi=Tndm/Ttr;
            	    	if(DmiData[j].pdi>1.00)
            	    	   DmiData[j].pdi=1.00;
            	    	if(DmiData[j].ndi>1.00)   
            	    		DmiData[j].ndi=1.00;   
            	    }
            	    else
            	    	DmiData[j].pdi=DmiData[j].ndi=0;
            	    if(Tpdm+Tndm!=0) 
            	    	DmiData[j].dx=fabs((Tpdm-Tndm)/(Tpdm+Tndm));
            	    else	
            	        DmiData[j].dx=0;
            	}
            	if(j<Para->periods[0]*2-1) 
            	{
            		Tadx+=DmiData[j].dx;
            		DmiData[j].adx=0;
            	} 
            	if(j==Para->periods[0]*2-1)   
            	{
            	    Tadx+=DmiData[j].dx;
            		DmiData[j].adx=0;            	
            	}
            	if(j>Para->periods[0]*2-1)
            	{
            	    m=Para->periods[0];
            	    DmiData[j].adx=
            	    	(DmiData[j-1].adx*(m-1)+DmiData[j].dx)/m;	
            	}            	           	           	
            }
    }         

    for(j=0;j<10;j++)
    {
        if(Data->v==NULL) 
        	break;
    	if(Data->v[j]!=NULL)
    	{
    		_ffree(Data->v[j]);
    		Data->v[j]=NULL;
    	}
    }
    Data->v==NULL;     
    Data->num =Para->dnum; 
    Data->no =Para->no;
    strcpy(Data->gpdm,Fx->gpdm);
    Data->type =Fx->type;
    Data->range =Fx->range;
    Data->size =RNum;
    for(j=0;j<Data->num;j++)
    	Data->v[j]=(double *)_fmalloc(sizeof(double)*RNum);
    for(i=0;i<Data->num;i++)
    {
    	for(j=0;j<RNum&&i==0;j++) 
    		Data->v[i][j]=DmiData[j].pdi;
    	for(j=0;j<RNum&&i==1;j++) 
    		Data->v[i][j]=DmiData[j].ndi;
    	for(j=0;j<RNum&&i==2;j++) 
    		Data->v[i][j]=DmiData[j].adx;
    	Data->method[i]=CURVE_METHOD;
    }
    //Para->price[2] =20;
    //Para->price[3] =50;
    //Para->price[4] =80;
    Para->feature |=DW_ALL;
    //Para->feature &=~DW_MAX;
    //Para->feature &=~DW_MIN;
    _ffree(DmiData);
	return TRUE;
}


