#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "fx.h"

LPFX Fx;

int CreateObvData(K_DATA *lpKData,int RNum,DATA *Data,PARA *Para)
{     
	int i,j;  
	OBV_DATA *ObvData;

	ObvData=(OBV_DATA*)_fmalloc(sizeof(OBV_DATA)*RNum);	
	memset(ObvData,0,sizeof(OBV_DATA)*RNum);
    for(j=0;j<RNum;j++)
    {
    	    if(j==0)	
    	    {
                ObvData[j].obv=0;
    	    }
    	    else
    	    {
    	    	if(lpKData[j].ss>lpKData[j-1].ss)
    	    	{
    	    		ObvData[j].obv=ObvData[j-1].obv+
    	    			lpKData[j].cj*lpKData[j].ss/100000,00;    	                
    	    	}
    	    	if(lpKData[j].ss<lpKData[j-1].ss)
    	    	{
    	    		ObvData[j].obv=ObvData[j-1].obv-
    	    			lpKData[j].cj*lpKData[j].ss/100000,00;
                }
                  
    	    	if(lpKData[j].ss==lpKData[j-1].ss)
    	    	{
    	    		ObvData[j].obv=ObvData[j-1].obv;    	    			
                }
                  
                if(j==1)
                {
                	Para->price[1]=ObvData[j].obv;
                	Para->price[0]=ObvData[j].obv;
                }
                else
                {
                 	if(Para->price[1]>ObvData[j].obv)
                 		Para->price[1]=ObvData[j].obv;
                 	if(Para->price[0]<ObvData[j].obv)	
                 		Para->price[0]=ObvData[j].obv;
                }
    	    }
    }
    for(j=0;j<10;j++)
    {
        if(Data->v==NULL) 
        	break;
    	if(Data->v[j]!=NULL)
    	{
    		_ffree(Data->v[j]);
    		Data->v[j]=NULL;
    	}
    }    
    Data->v==NULL;     
    Data->num =Para->dnum; 
    Data->no =Para->no;
    strcpy(Data->gpdm,Fx->gpdm);
    Data->type =Fx->type;
    Data->range =Fx->range;
    Data->size =RNum;
    for(j=0;j<Data->num;j++)
    	Data->v[j]=(double *)_fmalloc(sizeof(double)*RNum);
    for(i=0;i<Data->num;i++)
    {
    	for(j=0;j<RNum&&i==0;j++) 
    		Data->v[i][j]=ObvData[j].obv;
    	Data->method[i]=CURVE_METHOD;
    }
    Para->feature |=DW_ALL;
    _ffree(ObvData);
	return TRUE;
}

