#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "hq.h"
#include "hq_cl.h"
#include "msg.h"
                     //10,20,30
GRAPH_PARA def_para ={30, 40, 30};
LPGRAPH_PARA gra_para[] ={&GraphData.xlt, &GraphData.jlt, NULL};
LPSTR gra_items[] ={"XLT", "JLT", NULL};
extern BOOL GetInitString(LPSTR, LPSTR, LPSTR);
extern BOOL PutInitString(LPSTR, LPSTR, LPSTR);
extern ErrMsg(HWND, LPSTR);
extern HWND ghWndMain, ghWndXlt, ghWndJlt;
extern BOOL IsZsRec(int, int);

HBITMAP hBmp =NULL;
//this macro return respond x coor accroding to time value
#define	COOR(tim) 	(tim>=HqTime[GraphData.jys].pm_min_start?HqTime[GraphData.jys].am_min_count+(tim-HqTime[GraphData.jys].pm_min_start):tim -HqTime[GraphData.jys].am_min_start)
//this macro return respond time value accroding to set serial
#define	TIME(x)		(x>=HqTime[GraphData.jys].am_min_count?HqTime[GraphData.jys].pm_min_start+x-HqTime[GraphData.jys].am_min_count:HqTime[GraphData.jys].am_min_start+x)
#define	R_DOTS		0	//Ԥ���ռ�

                                 
BOOL GraphInit()
{
	int i;
	char tmp[100];
	LPSTR tok;
	int r, g, b;
	LOGFONT lf;
		
	i =0;
	while(gra_items[i])
	{
		if(!GetInitString("GRAPH", gra_items[i], tmp))
		{	
			memcpy(gra_para[i], &def_para, sizeof(GRAPH_PARA));
			sprintf(tmp, "%i,%i,%i", def_para.ma[0], def_para.ma[1], def_para.ma[2]);
			PutInitString("GRAPH", gra_items[i], tmp);
		}
		else
		{
			if(!(tok =strtok(tmp, ",")))
			{
				memcpy(gra_para[i], &def_para, sizeof(GRAPH_PARA));
				i++;
				continue;
			}
			while(*tok ==' ') tok++;
			gra_para[i]->ma[0] =atoi(tok);
			
			if(!(tok =strtok(NULL, ",")))
			{
				memcpy(gra_para[i], &def_para, sizeof(GRAPH_PARA));
				i++;
				continue;
			}
			while(*tok ==' ') tok++;
			gra_para[i]->ma[1] =atoi(tok);
			
			if(!(tok =strtok(NULL, ",")))
			{
				memcpy(gra_para[i], &def_para, sizeof(GRAPH_PARA));
				i++;
				continue;
			}
			while(*tok ==' ') tok++;
			gra_para[i]->gap =atoi(tok);
		}
		i++;
	}
	if(!GetInitString("GRAPH", "COLOR1", tmp))
	{
		strcpy(tmp, "180,180,0");
		PutInitString("GRAPH", "COLOR1", tmp);
	}
	r =255;
	if(tok =strtok(tmp, ","))
		r =atoi(tok)%256;
	g =0;
	if(tok)
		if(tok =strtok(NULL, ","))
			g =atoi(tok)%256;
	b =255;
	if(tok)
		if(tok =strtok(NULL, ","))
			b =atoi(tok)%256;
	GraphData.color[0] =RGB(r, g, b);
	
	if(!GetInitString("GRAPH", "COLOR2", tmp))
	{
		strcpy(tmp, "0,255,255");
		PutInitString("GRAPH", "COLOR2", tmp);
	}
	r =0;
	if(tok =strtok(tmp, ","))
		r =atoi(tok)%256;
	g =255;
	if(tok)
		if(tok =strtok(NULL, ","))
			g =atoi(tok)%256;
	b =255;
	if(tok)
		if(tok =strtok(NULL, ","))
			b =atoi(tok)%256;
	GraphData.color[1] =RGB(r, g, b);
	
	memset(&lf, 0, sizeof(lf));
	lf.lfHeight =13;
	lf.lfWeight =FW_NORMAL;
	strcpy(lf.lfFaceName, "Termianl");
	GraphData.hFont =CreateFontIndirect(&lf);
    
    if(GraphData.hFont ==NULL)
    {
    	ErrMsg(ghWndMain, "Create font failed!");
    }
	return TRUE;
}

void GraphExit(void)
{
	if(GraphData.hFont) DeleteObject(GraphData.hFont);
	if(hBmp) DeleteObject(hBmp);
}

int vLineTo(HDC hDC, int x1, int y1)
{
    int x0,y0,i;
    DWORD dw;
    
    dw =GetCurrentPosition(hDC);
    x0 =LOWORD(dw);
    y0 =HIWORD(dw);
    if(y1>y0)
    {
    	for(i=y0;i<=y1;i++)
    	{
        	if(i-(int)(i/4)*4==0)        
    			SetPixel(hDC,x0,i,RGB(80,80,80));    	
    	}
    }
    if(y1<y0)
    {
    	for(i=y0;i>=y1;i--)
    	{
        	if(i-(int)(i/4)*4==0)        
    			SetPixel(hDC,x0,i,RGB(80,80,80));    	
    	}    
    }
	return 0;
}


int hLineTo(HDC hDC, int x1, int y1)
{
    int x0,y0,i;
    DWORD dw;
    
    dw =GetCurrentPosition(hDC);
    x0 =LOWORD(dw);
    y0 =HIWORD(dw);
    if(x1>x0)
    {
    	for(i=x0;i<=x1;i++)
    	{
        	if(i-(int)(i/4)*4==0)        
    			SetPixel(hDC,i,y0,RGB(100,100,100));    	
    	}
    }
    if(x1<x0)
    {
    	for(i=x0;i>=x1;i--)
    	{
        	if(i-(int)(i/4)*4==0)        
    			SetPixel(hDC,i,y0,RGB(100,100,100));    	
    	}    
    }
	return 0;
}

int DrawXlt(HDC hDC, LPRECT rc)
{
	int i, k,j;
	int ma;
	double fplus;
	float zjjg;
	double fhdj, fwdt, f ,zgjg;
	HPEN hPen, hPenRed, hPenGreen;
	int tim;
	char tmp[20];

	//��Y����	
	hPen =CreatePen(PS_SOLID, 2, RGB(255, 255, 255));
	SelectObject(hDC, hPen);
	MoveTo(hDC,rc->left,rc->bottom);
	LineTo(hDC,rc->left,rc->top+2);
	LineTo(hDC,rc->right-1,rc->top+2);
	SelectObject(hDC,GetStockObject(WHITE_PEN));
	DeleteObject(hPen);

	if(GraphData.minEnd <=0 || GraphData.minCount <=0) return -1;
	SelectObject(hDC, GetStockObject(WHITE_PEN));
	
	fwdt =(double)(rc->right-rc->left)/(HqTime[HqPaintData.jys].am_min_count
						+HqTime[HqPaintData.jys].pm_min_count+R_DOTS);
	if(GraphData.GraHead.zgjg==0)
		zgjg = 100.00;
	else
	    zgjg =GraphData.GraHead.zgjg;
	    
	fhdj =(double)(rc->bottom-rc->top)/(zgjg*2);
	SetViewportOrg(hDC, rc->left, rc->bottom-(rc->bottom-rc->top)/2);
	
	SetTextColor(hDC, RGB(255, 255, 0));
	SelectObject(hDC, GraphData.hFont);
	
	//��X����	
	hPen =CreatePen(PS_SOLID, 1, RGB(80, 80, 80));
	SelectObject(hDC, hPen);
	for(f =-GraphData.GraHead.zgjg; f<=zgjg+0.001;f+=zgjg/5)
	{
		MoveTo(hDC, rc->right-rc->left-2, (int)(f*fhdj));
		LineTo(hDC, 0, (int)(f*fhdj));
		sprintf(tmp, "%.2f", f+GraphData.GraHead.zrsp);
		if((int)(f*100) >0)
			SetTextColor(hDC, RGB(255, 0, 0));
		else if((int)(f*100) <0)
			SetTextColor(hDC, RGB(0, 255, 0));
		else SetTextColor(hDC, RGB(255, 255, 255));
		SetTextAlign(hDC, TA_RIGHT|TA_BASELINE);
		TextOut(hDC, -4, -(int)(f*fhdj), tmp, strlen(tmp));
		sprintf(tmp, "%.1f%c", f*100/GraphData.GraHead.zrsp,'%');
		SetTextAlign(hDC, TA_LEFT|TA_BASELINE);
		TextOut(hDC, rc->right-rc->left+2, -(int)(f*fhdj), tmp, strlen(tmp));
	}
	
	SelectObject(hDC, GetStockObject(WHITE_PEN));
	DeleteObject(hPen);
	hPen =CreatePen(PS_SOLID, 2, RGB(255, 255, 255));
	SelectObject(hDC, hPen);
	MoveTo(hDC, 0, 0);
	LineTo(hDC, rc->right-rc->left-2, 0);
	SelectObject(hDC, GetStockObject(WHITE_PEN));
	DeleteObject(hPen);

	tim =GraphData.lpGraData[0].tim;
	hPenRed =CreatePen(PS_SOLID, 1, RGB(200, 0, 200));
	hPenGreen =CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
	zjjg =GraphData.lpGraData[0].zjjg;
	MoveTo(hDC, (int)(fwdt*COOR(tim)), -(int)(fhdj*zjjg));

	for(i =1; i<GraphData.minCount; i++)
	{
		tim =GraphData.lpGraData[GraphData.lpMinPos[i]].tim;
		if(tim>HqTime[GraphData.jys].pm_min_start+HqTime[GraphData.jys].pm_min_count)
			break;
		if(tim==0)	continue;
		zjjg =GraphData.lpGraData[GraphData.lpMinPos[i]].zjjg;
		SelectObject(hDC, hPenRed);		
		LineTo(hDC, (int)(fwdt*COOR(tim)), -(int)(fhdj*zjjg));
	}
	
	SelectObject(hDC, GetStockObject(WHITE_PEN));
	DeleteObject(hPenRed);
	DeleteObject(hPenGreen);
	
	for(k =0; k<1; k++)
	{
		ma =GraphData.xlt.ma[k];
		if(GraphData.minCount<ma) continue;
		hPen =CreatePen(PS_SOLID, 0, RGB(255,255,0));//GraphData.color[k]);
		SelectObject(hDC, hPen);
		//SetROP2(hDC, R2_XORPEN);
		
        ///////////////////////////////////////////////////////////        
        //����Ϊ��ʱƽ��
		//fplus =(float)0.0;
		//for(i =0; i<ma; i++)
		//	fplus +=GraphData.lpGraData[GraphData.lpMinPos[i]].zjjg;
		//tim =GraphData.lpGraData[GraphData.lpMinPos[i-1]].tim;
		//MoveTo(hDC, (int)(fwdt*COOR(tim)), -(int)(fhdj*fplus/ma));
		//
		//for(; i<GraphData.minCount; i++)
		//{
		//	zjjg =GraphData.lpGraData[GraphData.lpMinPos[i-ma]].zjjg;
		//	fplus-=zjjg;
		//	zjjg =GraphData.lpGraData[GraphData.lpMinPos[i]].zjjg;
		//	fplus +=zjjg;
		//	tim =GraphData.lpGraData[GraphData.lpMinPos[i]].tim;
		//	if(tim == 0) continue;			
		//	if(tim >=HqTime[GraphData.jys].pm_min_start)
		//		tim =HqTime[GraphData.jys].am_min_count
		//			+(tim-HqTime[GraphData.jys].pm_min_start);
		//	else tim -=HqTime[GraphData.jys].am_min_start;
		//	LineTo(hDC, (int)(fwdt*tim), -(int)(fhdj*fplus/ma));
		//} 
		///////////////////////////////////////////////////////////
		//����Ϊƽ����
		for(i=0,j=1,fplus=0;i<GraphData.minCount;i++)
		{
		    if(GraphData.lpGraData[GraphData.lpMinPos[i]].tim==0)
		    	continue;
		 	fplus +=GraphData.lpGraData[GraphData.lpMinPos[i]].zjjg;
			tim =GraphData.lpGraData[GraphData.lpMinPos[i]].tim;
			if(tim>HqTime[GraphData.jys].pm_min_start+HqTime[GraphData.jys].pm_min_count)
				break;
			if(i==0)
		 		MoveTo(hDC, (int)(fwdt*COOR(tim)), -(int)(fhdj*fplus/j++));
		 	else
		 		LineTo(hDC, (int)(fwdt*COOR(tim)), -(int)(fhdj*fplus/j++));
		}
		SelectObject(hDC, GetStockObject(WHITE_PEN));
		DeleteObject(hPen);
	}
	return 0;
}

int DrawJlt(HDC hDC, LPRECT rc)
{
	int i;
	//int ma;
	//long lplus;
	double fhdj, fwdt, zjjg, lastjg;
	long l, val, oldval;
	HPEN hPen, hPenRed, hPenGreen;
	int tim;
	char tmp[20];
	int ll;
	
	//��X���꼰Y����
	hPen =CreatePen(PS_SOLID, 2, RGB(255, 255, 255));
	SelectObject(hDC, hPen);
	MoveTo(hDC,rc->left,0);
	LineTo(hDC,rc->left,rc->bottom+1);
	LineTo(hDC,rc->right, rc->bottom+1);
	SelectObject(hDC,GetStockObject(WHITE_PEN));
	DeleteObject(hPen);

	if(GraphData.minEnd <=0 || GraphData.minCount <=0) 
		return -1;
	SelectObject(hDC, GetStockObject(WHITE_PEN));
	
	fwdt =(double)(rc->right-rc->left)/(HqTime[HqPaintData.jys].am_min_count
						+HqTime[HqPaintData.jys].pm_min_count+R_DOTS);
	if(GraphData.GraHead.zglc ==0) return -1;
	fhdj =(double)(rc->bottom-rc->top)/GraphData.GraHead.zglc;

	SetTextColor(hDC, RGB(255, 255, 0));
	SetTextAlign(hDC, TA_RIGHT|TA_TOP);
	val =0;
	if(IsZsRec(GraphData.jys, GraphData.recNum))
		ll =100;
	else ll =1;
	
	hPen =CreatePen(PS_SOLID, 1, RGB(80, 80, 80));
	SelectObject(hDC, hPen);
	if(fhdj)
	{
		oldval =val;
		if(GraphData.GraHead.zglc <100)
		{
			for(i =1; i<5; i++)
			{
				val =GraphData.GraHead.zglc*i/5;
				wsprintf(tmp, "%ld", val);
				MoveTo(hDC, rc->right-2, rc->bottom-(int)(fhdj*val));
				LineTo(hDC, rc->left, rc->bottom-(int)(fhdj*val));
				TextOut(hDC, rc->left-4, rc->bottom-(int)(fhdj*val)-4,
						tmp, strlen(tmp));
			}
		}
		else
		for(l =GraphData.GraHead.zglc/5; l >=0 && l<=GraphData.GraHead.zglc; l+=GraphData.GraHead.zglc/5)
		{
			wsprintf(tmp, "%ld", l);
			i =strlen(tmp)-2;
			if(i>0)
			{
				val =1;
				while(i-->0)
					val *=10;
				val =l -l%val;	
				if(oldval ==val) continue;
				wsprintf(tmp, "%ld", val);
			}
			else
				val =l;
			MoveTo(hDC, rc->right-2, rc->bottom-(int)(fhdj*val));
			LineTo(hDC, rc->left, rc->bottom-(int)(fhdj*val));
			TextOut(hDC, rc->left-4, rc->bottom-(int)(fhdj*val)-4,
						tmp, strlen(tmp));
			if(val >GraphData.GraHead.zglc) break;
			oldval =val;
		}				
	}
	SelectObject(hDC, GetStockObject(WHITE_PEN));
	DeleteObject(hPen);

	hPenRed =CreatePen(PS_SOLID, 1, RGB(255, 0, 255));
	hPenGreen =CreatePen(PS_SOLID, 1, RGB(0, 255, 255));
	
	zjjg =GraphData.lpGraData[GraphData.lpMinPos[0]].zjjg;
	lastjg =GraphData.GraHead.zrsp;
	for(i =0; i<GraphData.minCount; i++)
	{
		tim =GraphData.lpGraData[GraphData.lpMinPos[i]].tim;
		if(tim>HqTime[GraphData.jys].pm_min_start+HqTime[GraphData.jys].pm_min_count)
			break;
		if(tim ==0) continue;
		zjjg =GraphData.lpGraData[GraphData.lpMinPos[i]].zjjg;
		if(zjjg>lastjg)
			SelectObject(hDC, hPenRed);
		else if(zjjg<lastjg)
			SelectObject(hDC, hPenGreen);
		else
		    SelectObject(hDC, hPenRed);
		    
		l =GraphData.lpMinLc[i];
		MoveTo(hDC, rc->left+(int)(fwdt*COOR(tim)), rc->bottom);
		LineTo(hDC, rc->left+(int)(fwdt*COOR(tim)),
			rc->bottom-(int)(fhdj*l));
		lastjg =zjjg;
	}
	
	SelectObject(hDC, GetStockObject(WHITE_PEN));
	DeleteObject(hPenGreen);
	DeleteObject(hPenRed);
	
	//��ʱƽ���� 
	/*
	ma =GraphData.jlt.ma[0];
	if(GraphData.minCount <ma) return 0;
	
	hPen =CreatePen(PS_SOLID, 0, GraphData.color[0]);
	SelectObject(hDC, hPen);
	lplus =0L;
	for(i =0; i<ma; i++)
		lplus +=GraphData.lpMinLc[i];
	tim =GraphData.lpGraData[GraphData.lpMinPos[i-1]].tim;
	MoveTo(hDC, rc->left+(int)(fwdt*COOR(tim)), rc->bottom-(int)(fhdj*(lplus/ma)));

	for(; i<GraphData.minCount; i++)
	{
		lplus-=GraphData.lpMinLc[i-ma];
		lplus +=GraphData.lpMinLc[i];
		tim =GraphData.lpGraData[GraphData.lpMinPos[i-1]].tim;
		if(tim>HqTime[GraphData.jys].pm_min_start+HqTime[GraphData.jys].pm_min_count)
			break;
		if(tim ==0) continue;
		LineTo(hDC, rc->left+(int)(fwdt*COOR(tim)), rc->bottom-(int)(fhdj*(lplus/ma)));
	}
	
	SelectObject(hDC, GetStockObject(WHITE_PEN));
	DeleteObject(hPen);
	*/
	return 0;
}

int DrawTimeLines(HWND hWnd,HDC hDC, LPRECT rc, BOOL fDrawText)
{
	int i, j;
	char tmp[50];
	HPEN hPen;
	double fwdt;
	int top;
	
	if(hWnd ==ghWndJlt)	top =0;
	else top =rc->top+1;
	j = HqTime[HqPaintData.jys].am_min_count
			+HqTime[HqPaintData.jys].pm_min_count+R_DOTS;
			
	fwdt =(double)(rc->right-rc->left)/j;
	hPen =CreatePen(PS_SOLID, 0, RGB(80, 80, 80));
	SelectObject(hDC, hPen);
	SetTextAlign(hDC, TA_LEFT|TA_TOP);
	SelectObject(hDC, GraphData.hFont);
	for(i=0;i<=j;i=i+30)
	{     
		if(i>0)
		{
			MoveTo(hDC, rc->left+(int)(fwdt*i), top);	
			LineTo(hDC, rc->left+(int)(fwdt*i), rc->bottom);
		}
		if(fDrawText)
		{
			wsprintf(tmp, "%d:%02d",TIME(i)/60,TIME(i)%60);
			TextOut(hDC, rc->left+(int)(fwdt*i), rc->bottom+2,
				tmp,strlen(tmp));		
		}
	}
	SelectObject(hDC, GetStockObject(WHITE_PEN));
	DeleteObject(hPen);
	return 0;
}


BOOL fVLineDrawed =FALSE;
extern int graphTop;
extern HBITMAP getImage(HDC, LPRECT);
extern int putImage(HDC, HBITMAP, LPRECT);
extern int CapHig;

int DrawVLine(int pos)
{
	static int minNum =0;
	RECT rc, rc1, rc2;
	float fwdt, fhdj;
	HDC hDC;
	char tmp[100];
	static int slen =0;
	int ll;
	int timPos =0;
	static RECT rcJg;

	if(GraphData.minCount <=0 || GraphData.minEnd <=0) return 0;
	GetWindowRect(ghWndXlt, &rc1);
	SetRect(&rc, 0, graphTop, rc1.right-rc1.left, rc1.bottom-rc1.top-1);
	fwdt =(float)(rc1.right-rc1.left-80)/(HqTime[HqPaintData.jys].am_min_count
					+HqTime[HqPaintData.jys].pm_min_count+R_DOTS);
	fhdj =(float)(rc.bottom-rc.top-10)/(GraphData.GraHead.zgjg*2);
	hDC =GetDC(NULL);
	SetROP2(hDC, R2_NOT);
	if(minNum+pos <0)
		pos =GraphData.minCount-1 -minNum;
	if(minNum >=GraphData.minCount) minNum =GraphData.minCount-1;
	if(minNum+pos >=GraphData.minCount) pos =-minNum;

	GetWindowRect(ghWndJlt, &rc2);
	rc2.bottom -=10;

	timPos =GraphData.lpGraData[GraphData.lpMinPos[minNum]].tim;
	MoveTo(hDC, rc1.left+50+(int)(fwdt*COOR(timPos)), rc1.top+graphTop+2);
	LineTo(hDC, rc1.left+50+(int)(fwdt*COOR(timPos)), rc2.bottom-20);	
	if(pos && fVLineDrawed)
	{   
	    do
	    {
			minNum +=pos;
			timPos =GraphData.lpGraData[GraphData.lpMinPos[minNum]].tim;
		}while(timPos ==0);
		if(timPos >=HqTime[GraphData.jys].pm_min_start)
			timPos =HqTime[GraphData.jys].am_min_count+(timPos-HqTime[GraphData.jys].pm_min_start);
		else timPos -=HqTime[GraphData.jys].am_min_start;

		MoveTo(hDC, rc1.left+50+(int)(fwdt*timPos), rc1.top+graphTop+2);
		LineTo(hDC, rc1.left+50+(int)(fwdt*timPos), rc2.bottom-20);
	
	}
	fVLineDrawed =TRUE;
	
	if(IsZsRec(GraphData.jys, GraphData.recNum))
		ll =100;
	else ll =1;
	sprintf(tmp, "ʱ��:%2d:%02d �۸�:%6.2f ����:%5ld ����:%8ld",
	            GraphData.lpGraData[GraphData.lpMinPos[minNum]].tim/60,
	            GraphData.lpGraData[GraphData.lpMinPos[minNum]].tim%60,
				GraphData.lpGraData[GraphData.lpMinPos[minNum]].zjjg+GraphData.GraHead.zrsp,
				GraphData.lpMinLc[minNum],
				GraphData.lpGraData[GraphData.lpMinPos[minNum]].zl);
	if(GraphData.lpGraData[GraphData.lpMinPos[minNum]].zjjg<0)
		SetTextColor(hDC, RGB(0, 255, 0));
	else SetTextColor(hDC, RGB(255, 0, 0));
	
	SetROP2(hDC, R2_COPYPEN);	
	SelectObject(hDC,GetStockObject(BLACK_BRUSH));	
	
	ReleaseDC(NULL, hDC); 
	
	GetWindowRect(ghWndMain,&rc);
	GetWindowRect(ghWndXlt,&rc1);
	GetWindowRect(ghWndMsg,&rc2);
		
	if(pos&& fVLineDrawed)
		Msg(tmp,MSG_VERT|MSG_TIME);
	else
	Msg(tmp,MSG_HIDE);
		
	return 0;
}

