#include <windows.h>
#include <string.h>
#include <stdio.h>
#include "resource.h"
#include "global.h"
#include "hq.h"
#include "hq_cl.h"
#include "status.h"
#include "appmain.h"

#define STATUS_CLASS	"CSTATUS"

extern HINSTANCE ghInstance;
extern HWND ghWndMain, ghWndStatus;
extern BOOL ErrMsg(HWND, LPSTR);
extern int UDP_Send_Dp(void);
extern int UDP_Send_Gra00(int jys, int rec_num);
extern BOOL IsSzRead,IsShRead;

BOOL RegisterStatus(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	
	wc.style =CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc =StatusWndProc;
	wc.lpszClassName =STATUS_CLASS;
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = ghInstance;
	wc.lpszMenuName = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	wc.hIcon = LoadIcon(ghInstance, MAKEINTRESOURCE(IDR_MAINFRAME));
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

BOOL CreateWndStatus(HWND hWnd)
{                          
	int x ;
	HWND hwnd;
	RECT rc;
	
	GetClientRect(ghWndMain, &rc);
	x =GetSystemMetrics(SM_CXSCREEN);	
	if(ghWndStatus==NULL)
	{
		hwnd =CreateWindow(STATUS_CLASS, NULL, WS_CHILD|WS_CLIPSIBLINGS,
						0, 
						rc.bottom -STATUS_HEIGHT-MSG_HEIGHT,
						x, 
						STATUS_HEIGHT,
						hWnd, NULL, ghInstance, NULL);
		if(hwnd ==NULL)
		{
			ErrMsg(hWnd, "���ܽ���״̬��");
			return FALSE;
		}
	
		ghWndStatus =hwnd;
	}

	SetWindowPos(ghWndStatus, HWND_TOP,0,rc.bottom -STATUS_HEIGHT-MSG_HEIGHT,
		0,0,SWP_NOSIZE);
	ShowWindow(hwnd, SW_SHOW);
	
	return TRUE;
}

LRESULT CALLBACK StatusWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	RECT rc;
	HPEN hPen;
	char tmp[100];
	int i, x, x1, width;
	TEXTMETRIC tm;
	HBRUSH hBrush;
	LOGFONT lf;
	static HFONT hFont =NULL;
	HDC hMemDC;
		
	switch(message)
	{
		case WM_CREATE:
			GetClientRect(hWnd, &rc);			
		break;	
		break;
		case WM_SETFOCUS:
			SetFocus(ghWndMain);
		break;
		case WM_COMMAND:
			if(wParam ==100)
			{
				switch(HIWORD(lParam))
				{
					case EN_SETFOCUS:
						SetFocus(ghWndMain);
					break;
				}
			}
		break;
		case WM_LBUTTONDOWN:
			if(IsSzRead&&IsShRead)
			{
				if(wParam == MK_LBUTTON)
				{
					GetClientRect(hWnd, &rc);				
					if((int)LOWORD(lParam)> (int)((int)rc.right /2-30))
						SendMessage(ghWndHq, WM_COMMAND, IDM_HQ_SH, 0L);
					else
						SendMessage(ghWndHq, WM_COMMAND, IDM_HQ_SZ, 0L);
				}
			}
		break; 

		case WM_RBUTTONDOWN:
		    if(IsWindowVisible(ghWndHq))
				SendMessage(ghWndHq, WM_KEYDOWN, VK_NEXT, 0L);
		break; 
		case WM_PAINT:
			if(HqPaintData.recCount <=0) break;
			BeginPaint(hWnd, &ps);
			if(hFont==NULL)
			{
				memset(&lf, 0, sizeof(lf));
				lf.lfHeight =10;
				lf.lfWeight =FW_NORMAL;               
				strcpy(lf.lfFaceName, "Ms Sans Serif");
				hFont =CreateFontIndirect(&lf);		
			}

			GetClientRect(hWnd, &rc);
			GetTextMetrics(ps.hdc, &tm);
			x1 =rc.right/2-4;//-30;
			hPen=CreatePen(PS_SOLID, 1, RGB(180, 180, 180));
			SelectObject(ps.hdc, hPen);
			MoveTo(ps.hdc, 0, rc.bottom);//tm.tmHeight+6);
			LineTo(ps.hdc, rc.right, rc.bottom);//tm.tmHeight+6);
			MoveTo(ps.hdc, 0, 1);
			LineTo(ps.hdc, rc.right, 1);
			MoveTo(ps.hdc, x1+1, 2);
			LineTo(ps.hdc, x1+1, rc.bottom-1);//tm.tmHeight+5);
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
			MoveTo(ps.hdc, 0, 0);
			LineTo(ps.hdc, rc.right, 0);
			MoveTo(ps.hdc, 0, rc.bottom-1);//tm.tmHeight+5);
			LineTo(ps.hdc, rc.right, rc.bottom-1);//tm.tmHeight+5);
			MoveTo(ps.hdc, x1, 2);
			LineTo(ps.hdc, x1, rc.bottom-1);//tm.tmHeight+5);
			
			SetTextColor(ps.hdc, RGB(255, 0, 255));
			SetBkColor(ps.hdc, RGB(0, 0, 0));
			SetTextAlign(ps.hdc, TA_RIGHT|TA_TOP);
			x =tm.tmAveCharWidth*2+4+1;
			TextOut(ps.hdc, x, (rc.bottom-tm.tmHeight)/2, "��", 2);
			TextOut(ps.hdc, x1+x, (rc.bottom-tm.tmHeight)/2, "��", 2);

			x +=tm.tmAveCharWidth*8+1;
			//ָ��
			SetBkColor(ps.hdc, RGB(0, 0, 0));
			for(i =0; i<2; i++)
			{
				sprintf(tmp, "%.2f", DpData[i].zs[0]);
				if(DpData[i].sd[0] <0)
				{
					SetTextColor(ps.hdc, RGB(0, 255, 0));
					//strcat(tmp, "��");
				}
				else if(DpData[i].sd[0] >0)
				{
					SetTextColor(ps.hdc, RGB(255, 0, 0));
					//strcat(tmp, "��");
				}
				else
					SetTextColor(ps.hdc, RGB(255, 255, 255));
				TextOut(ps.hdc, x1*i+x, 2, tmp, strlen(tmp));
			}
			//ָ������
			x +=tm.tmAveCharWidth*6+5;
			for(i =0; i<2; i++)
			{
				//if(i==1)
				//{
				//	if(HqData[1].recCount!=0)
				//	{				
				//		DpData[1].sd[0]=
				//		 	DpData[1].zs[0]-HqData[1].lpPreData[0].zrsp;
				//	}
				//}		
				
				if(DpData[i].sd[0] <0)
				{
					SetTextColor(ps.hdc, RGB(0, 255, 0));
					//strcat(tmp, "��");
				}
				else if(DpData[i].sd[0] >0)
				{
					SetTextColor(ps.hdc, RGB(255, 0, 0));
					//strcat(tmp, "��");
				}
				else
					SetTextColor(ps.hdc, RGB(255, 255, 255));
				sprintf(tmp, "  %.2f", DpData[i].sd[0]);
				TextOut(ps.hdc, x1*i+x+10, 2, tmp, strlen(tmp));
			}
			//�ܳɽ����
			x +=tm.tmAveCharWidth*12+3;
			SetTextColor(ps.hdc, RGB(0, 180, 180));
			for(i =0; i<2; i++)
			{
				sprintf(tmp, "%.1f��", (float)DpData[i].cjzje/10);
				TextOut(ps.hdc, x1*i+x, 2, tmp, strlen(tmp));	
			}
			
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			
			hBrush =CreateSolidBrush(RGB(0, 255, 0));
			SelectObject(ps.hdc, hBrush);
			x+=2;
			width =x1 -2-x;
			//�����̱�
			for(i =0; i<2; i++)
				Rectangle(ps.hdc, x1*i+x, (rc.bottom-tm.tmHeight)/3-1,
							x1*i+x+width, (rc.bottom+tm.tmHeight)/3);
			
			SelectObject(ps.hdc, GetStockObject(WHITE_BRUSH));
			DeleteObject(hBrush);

			SelectObject(ps.hdc, GetStockObject(NULL_PEN));
			hBrush =CreateSolidBrush(RGB(255, 0, 0));
			SelectObject(ps.hdc, hBrush);
			for(i =0; i<2; i++)
				Rectangle(ps.hdc, x1*i+x+1, (rc.bottom-tm.tmHeight)/3,
							x1*i+x+1+(int)(DpData[i].npbl*width), (rc.bottom+tm.tmHeight)/3);
			
			SelectObject(ps.hdc, GetStockObject(WHITE_BRUSH));
			DeleteObject(hBrush);
			SelectObject(ps.hdc, hFont);
			SetBkColor(ps.hdc, RGB(0, 0, 0));
			SetTextAlign(ps.hdc, TA_LEFT|TA_BOTTOM);			
			hMemDC =CreateCompatibleDC(ps.hdc);
			
			for(i =0; i<2; i++)
			{
				SelectObject(hMemDC, hBmpUp);
				BitBlt(ps.hdc, x1*i+25, rc.bottom-12,
						10, tm.tmHeight, hMemDC, 0, 0, SRCCOPY);
				sprintf(tmp, "%d", DpData[i].upCount);
				SetTextColor(ps.hdc, RGB(255, 0, 0));
				TextOut(ps.hdc, x1*i+30+tm.tmAveCharWidth, rc.bottom-1, tmp, strlen(tmp));
				SelectObject(hMemDC, hBmpDown);
				BitBlt(ps.hdc, x1*i+25+tm.tmAveCharWidth*5, rc.bottom-12,
					10, tm.tmHeight, hMemDC, 0, 0, SRCCOPY);
				sprintf(tmp, "%d", DpData[i].downCount);
				SetTextColor(ps.hdc, RGB(0, 255, 0));
				TextOut(ps.hdc, x1*i+30+tm.tmAveCharWidth*6, rc.bottom-1, tmp, strlen(tmp)); 
				SelectObject(hMemDC, hBmpEqual);
				BitBlt(ps.hdc, x1*i+25+tm.tmAveCharWidth*10, rc.bottom-12,
					10, tm.tmHeight, hMemDC, 0, 0, SRCCOPY);
				sprintf(tmp, "%d", DpData[i].equalCount);
				SetTextColor(ps.hdc, RGB(255, 255, 0));
				TextOut(ps.hdc, x1*i+30+tm.tmAveCharWidth*11, rc.bottom-1, tmp, strlen(tmp));
			}
			DeleteObject(hMemDC);
			SetTextColor(ps.hdc, RGB(0, 180, 180));
			SetTextAlign(ps.hdc, TA_RIGHT|TA_BOTTOM);
			for(i =0; i<2; i++)
			{
				sprintf(tmp, "%ld��", DpData[i].cjss);
				TextOut(ps.hdc, x1*i+x-25, rc.bottom-2, tmp, strlen(tmp));
			}
			SetTextColor(ps.hdc, RGB(255, 255, 0));
			TextOut(ps.hdc, x1-2, rc.bottom-2, "Esc:�˵�", strlen("Esc:�˵�"));
			TextOut(ps.hdc, x1*2, rc.bottom-2, "F1:����", strlen("F1 ����"));
			EndPaint(hWnd, &ps);
		break;
		case WM_DESTROY:
			if(hFont) DeleteObject(hFont);
			hFont =NULL;
		break;
		default:
		break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}
