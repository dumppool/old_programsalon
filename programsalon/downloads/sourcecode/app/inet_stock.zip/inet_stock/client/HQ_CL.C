#include <windows.h>
#include <windowsx.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <direct.h>
#include <io.h>
#include <time.h>
#include "resource.h"
#include "global.h"
#include "appmain.h"
#include "hq.h"
#include "hq_cl.h"
#include "hq_tcp.h"
#include "jy_cl.h"
#include "msg.h"
#include "pctcp.h"
#include "caption.h"
#include "rsa.h"
#define HQ_CLASS                "CHQ"

HQ_DATA HqData[2];
HQ_PAINT_DATA HqPaintData;
HQSEL_DATA HqSelData[MAX_HQSEL_COUNT];
DP_DATA DpData[2];
HQ_TIME  HqTime[2];
GRAPH_DATA GraphData;
MMP_DATA MmpData;
MAXMIN_DATA     MaxMinData[2][2];
ZX_DATA ZxData;

int SeleQs=0;
HFONT ghFontSmall =NULL;
HFONT hHqFont =NULL;
char szDataPath[128];

extern int LoadFile(char *filename,int sline,char *title);

extern BOOL ErrMsg(HWND, LPSTR);
extern BOOL run_cancelled;
extern JY_ANS_CHKUSR curChkUsrRes;
extern BOOL jy_running;
extern int TOOLBAR_HEIGHT;
extern void SendJyQsxx(void);

int DrawTitle(HWND hWnd, HDC hDC);
void DrawSelRect(HWND hWnd, HDC hDC, int sel_num, int bClr);
LPSTR GetHqFldPos(HDC, int jys, int rec_num, int fld_num);
LPSTR GetHqFldPos1(int jys, int rec_num, int fld_num);
LRESULT CALLBACK HqWndProc(HWND, UINT, WPARAM, LPARAM);

int HqSort(void);
int SortFloat(LPSORT_DATA lpSortData, int jys);
int SortLong(LPSORT_DATA lpSortData, int jys);

BOOL IsZsRec(int jys, int recNum);
HFILE hfZx =HFILE_ERROR;
extern HBITMAP hBmpUp, hBmpDown, hBmpEqual;
extern int UDP_Send_Hq10(int, int, int, int);

LPSTR HqTimeDefs[] ={"9:30", "11:30", "13:00", "15:00",
					"9:30", "11:30", "13:00", "15:00",
};

int *lpHqTimes[] ={&HqTime[0].am_min_start, &HqTime[0].am_min_count,
				&HqTime[0].pm_min_start, &HqTime[0].pm_min_count,
				&HqTime[1].am_min_start, &HqTime[1].am_min_count,
				&HqTime[1].pm_min_start, &HqTime[1].pm_min_count
};

float  HqZd;
extern BOOL IsSzRead,IsShRead;

BOOL RegisterHq(void)
{
	WNDCLASS wc;
	BYTE bytes[20];
	float f =(float)0.1;
	
	memset(bytes, 0, sizeof(bytes));
	memcpy(bytes, &f, sizeof(float));
	
	memset(&wc, 0, sizeof(wc));
	
	wc.style =CS_HREDRAW | CS_VREDRAW;
	wc.cbWndExtra =sizeof(WORD);
	wc.lpfnWndProc =HqWndProc;
	wc.lpszClassName =HQ_CLASS;
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = ghInstance;
	wc.lpszMenuName = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	wc.hIcon = LoadIcon(ghInstance, MAKEINTRESOURCE(IDR_MAINFRAME));
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

BOOL CreateWndHq(HWND hWnd)
{                          
	HWND hwnd;
	RECT rc;
	
	GetClientRect(ghWndMain, &rc);
    if(ghWndHq==NULL)
    {
		hwnd =CreateWindow(HQ_CLASS, HQ_CLASS, WS_CHILD|WS_CLIPSIBLINGS,// |WS_VSCROLL|WS_HSCROLL,
						0, 
						STATUS_HEIGHT +TOOLBAR_HEIGHT ,
						rc.right -rc.left, 
						rc.bottom -rc.top -TOOLBAR_HEIGHT-STATUS_HEIGHT*2-MSG_HEIGHT,
						hWnd, IDW_HQ, ghInstance, NULL);
		if(hwnd ==NULL)
		{
			ErrMsg(hWnd, "Error create hq window");
			return FALSE;
		}
	
		ghWndHq =hwnd;
	
		SendMessage(hwnd, WM_COMMAND, IDM_HQ_SZ, 0L);
		ShowWindow(hwnd, SW_SHOW);
	}
	else
	{
		SetWindowPos(ghWndHq, (HWND)NULL,
		    0,
		    0,
			rc.right -rc.left,
			rc.bottom -rc.top -TOOLBAR_HEIGHT-STATUS_HEIGHT*2-MSG_HEIGHT,
			SWP_NOMOVE);	
		PostMessage(ghWndHq,WM_USER+1,NULL,NULL);
	}
	return TRUE;
}

BOOL HqInit(void)
{
	int i, jys;
	LOGFONT SmallLf;
	char temp[128];
	OFSTRUCT os;
	HANDLE hf;
		
	memset(&HqData, 0, sizeof(HqData));
	memset(&HqSelData, 0, sizeof(HqSelData));
	memset(&HqTime, 0, sizeof(HqTime));
	
	HqTime[0].fRunning =HqTime[1].fRunning =TRUE;
	
	memset(&HqPaintData, 0, sizeof(HqPaintData));
	memset(&MmpData, 0, sizeof(MmpData));
	memset(&GraphData, 0, sizeof(GraphData));
	memset(&ZxData, 0, sizeof(ZxData));
	
	memset(&lf, 0, sizeof(lf));
	if(!GetInitString("HQ", "DATAPATH", szDataPath))
	{
		strcpy(szDataPath, ".\\data");
	}
	else
	{
		i =strlen(szDataPath);
		if(szDataPath[i-1] =='\\') szDataPath[i-1] =0;
	}
	if(_access(szDataPath, 0) !=0 && _mkdir(szDataPath) !=0)
		strcpy(szDataPath, ".");
	PutInitString("HQ", "DATAPATH", szDataPath);


	if(!GetInitString("HQ", "ITEM_SPACE_X", temp))
	    ITEM_SPACE_X =0;
	else
	ITEM_SPACE_X =atoi(temp);

	if(!GetInitString("HQ", "X0_TITLE", temp))
	    X0_TITLE =0;
	else
	X0_TITLE =atoi(temp);
		
	strcpy(temp, szDataPath);
	strcat(temp, "\\zx.txt");
	if(access(temp,0)!=0)
		hfZx =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_READWRITE);
	else
	    hfZx =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READWRITE);	    
	if(hfZx ==HFILE_ERROR)
	{
		strcat(temp, ": Create failed!");
		ErrMsg(NULL, temp);
	}
	_lclose(hfZx);

	memset(&lf, 0, sizeof(LOGFONT));
	strcpy(temp, "font.dat");
	if(access(temp,0)==0)
	{
	    hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_READ);	    
		if(hfZx ==HFILE_ERROR)
			unlink(temp);
		else
		{
			if(_lread(hf,&lf,sizeof(LOGFONT))!=sizeof(LOGFONT))
			{
				_lclose(hfZx);
				memset(&lf, 0, sizeof(LOGFONT));
				unlink(temp);
			}
			else
			_lclose(hfZx);				
		}
	}
	memset(&SmallLf, 0, sizeof(LOGFONT));
	SmallLf.lfHeight =-12;
	SmallLf.lfWeight =FW_NORMAL;               
	strcpy(SmallLf.lfFaceName, "����");
	ghFontSmall =CreateFontIndirect(&SmallLf);
	
	//��HqTimeDefs��������HqTimes����
	for(jys =0; jys <2; jys++)
	{
		for(i =0; i<4; i++)
		{
			strcpy(temp, HqTimeDefs[i+4*jys]);
			*lpHqTimes[i+4*jys] =atoi(strtok(temp, ":"))*60;
			*lpHqTimes[i+4*jys] +=atoi(strtok(NULL, ":"));
		}
		HqTime[jys].am_min_count -=HqTime[jys].am_min_start;
		HqTime[jys].pm_min_count -=HqTime[jys].pm_min_start;
	}
	
	if(GetInitString("TIME", "SZ_AM_START",temp))
		HqTime[0].am_min_start =atoi(temp);
	if(GetInitString("TIME", "SZ_AM_COUNT",temp))
		HqTime[0].am_min_count =atoi(temp);
	if(GetInitString("TIME", "SZ_PM_START",temp))
		HqTime[0].pm_min_start =atoi(temp);
	if(GetInitString("TIME", "SZ_PM_COUNT",temp))
		HqTime[0].pm_min_count =atoi(temp);

	if(GetInitString("TIME", "SH_AM_START",temp))
		HqTime[1].am_min_start =atoi(temp);
	if(GetInitString("TIME", "SH_AM_COUNT",temp))
		HqTime[1].am_min_count =atoi(temp);
	if(GetInitString("TIME", "SH_PM_START",temp))
		HqTime[1].pm_min_start =atoi(temp);
	if(GetInitString("TIME", "SH_PM_COUNT",temp))
		HqTime[1].pm_min_count =atoi(temp);
	
	return TRUE;
}

void HqExit(void)
{
	static BOOL fExit =FALSE;
	int jys;
	char temp[80];
	OFSTRUCT os;
	HANDLE hf;
	
	if(fExit ==TRUE) return;
	fExit =TRUE;
	for(jys =0; jys <2; jys++)
	{
		if(HqData[jys].lpPreData !=NULL)
			GlobalFreePtr(HqData[jys].lpPreData);
		if(HqData[jys].lpRefData !=NULL)
			GlobalFreePtr(HqData[jys].lpRefData);
		if(HqData[jys].isJgChanged !=NULL)
			GlobalFreePtr(HqData[jys].isJgChanged);
		if(HqData[jys].isLcChanged !=NULL)
			GlobalFreePtr(HqData[jys].isLcChanged);
		if(HqData[jys].isReadOK !=NULL)
			GlobalFreePtr(HqData[jys].isReadOK);
	}
	if(GraphData.lpGraData) GlobalFreePtr(GraphData.lpGraData);
	if(GraphData.lpMinPos) GlobalFreePtr(GraphData.lpMinPos);
	if(GraphData.lpMinLc) GlobalFreePtr(GraphData.lpMinLc);
	
	if(ZxData.lpText) GlobalFreePtr(ZxData.lpText);

	strcpy(temp,"font.dat");
	hf =OpenFile(temp, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_WRITE);
	_lwrite(hf,&lf,sizeof(LOGFONT));
	_lclose(hf);

	if(ghFontSmall) DeleteObject(ghFontSmall);
    if(hHqFont!=NULL) DeleteObject(hHqFont);
	//if(hfZx !=HFILE_ERROR) _lclose(hfZx);
	
	sprintf(temp,"%d",HqTime[0].am_min_start);
	PutInitString("TIME", "SZ_AM_START",temp);
	
	sprintf(temp,"%d",HqTime[0].am_min_count);
	PutInitString("TIME", "SZ_AM_COUNT",temp);
	
	sprintf(temp,"%d",HqTime[0].pm_min_start);		
	PutInitString("TIME", "SZ_PM_START",temp);

	sprintf(temp,"%d",HqTime[0].pm_min_count);		
	PutInitString("TIME", "SZ_PM_COUNT",temp);

	sprintf(temp,"%d",HqTime[1].am_min_start);
	PutInitString("TIME", "SH_AM_START",temp);
	
	sprintf(temp,"%d",HqTime[1].am_min_count);
	PutInitString("TIME", "SH_AM_COUNT",temp);
	
	sprintf(temp,"%d",HqTime[1].pm_min_start);		
	PutInitString("TIME", "SH_PM_START",temp);

	sprintf(temp,"%d",HqTime[1].pm_min_count);		
	PutInitString("TIME", "SH_PM_COUNT",temp);	
}

//zqdm,zrsp,jrkp,zgjg,zdjg,zgjm,zdjm,zjjg,zdf,cjss,lc,npzl, wpzl, wb, cjje ,zd
int HqFldLens[HQ_FLDS_COUNT+1]=
{
	MAX_ZQDM_SIZE+2, sizeof(float),sizeof(float), sizeof(float), sizeof(float),
	sizeof(float), sizeof(float),sizeof(float), sizeof(float), sizeof(long),
	sizeof(long), sizeof(long), sizeof(long), sizeof(float), sizeof(long),sizeof(float)
};
int HqPaintFldLens[HQ_FLDS_COUNT+1]=
{
	MAX_ZQDM_SIZE+2, MAX_JG_SIZE, MAX_JG_SIZE, MAX_JG_SIZE, MAX_JG_SIZE,
	MAX_JG_SIZE, MAX_JG_SIZE, MAX_JG_SIZE, MAX_JG_SIZE -1, MAX_CJSS_SIZE+1,
	MAX_CJSS_SIZE -1, MAX_CJSS_SIZE+1, MAX_CJSS_SIZE+1, MAX_JG_SIZE-2, MAX_CJJE_SIZE,MAX_JG_SIZE+1
};

int HqFldTypes[HQ_FLDS_COUNT+1] =
{
	FLD_TYPE_STRING, FLD_TYPE_FLOAT, FLD_TYPE_FLOAT, FLD_TYPE_FLOAT,
	FLD_TYPE_FLOAT, FLD_TYPE_FLOAT, FLD_TYPE_FLOAT, FLD_TYPE_FLOAT,
	FLD_TYPE_FLOAT, FLD_TYPE_LONG, FLD_TYPE_LONG, FLD_TYPE_LONG,
	FLD_TYPE_LONG, FLD_TYPE_FLOAT, FLD_TYPE_LONG ,FLD_TYPE_FLOAT
};


short *recList =NULL;
int FontHight=-15;	
BOOL isRF=FALSE;

#define	R_VERT	4000
#define	R_HORZ	1000

//unsigned short ITEM_SPACE_Y =7;
//unsigned short X0_TITLE=84;
//unsigned short ITEM_SPACE_X =12;

unsigned short ITEM_SPACE_Y =0;
unsigned short X0_TITLE=0;
unsigned short ITEM_SPACE_X =0;

LOGFONT lf;

LRESULT CALLBACK HqWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	int i, j, m, l, n, k;
	RECT rc, rc1;
	HDC hDC;
	int x, y;	
	static TEXTMETRIC tm;
	char tmp[100];
	LPSTR lpTmp;
	int recNum, recCount;
	BOOL fRefresh =FALSE, fSel =FALSE;
	static clock_t MouDownClk;
	
	switch(message)
	{
		case WM_CREATE:
			MouDownClk=clock();
			HqPaintData.sortData.fldID =SORT_ZQDM;
			HqPaintData.sortData.type =SORT_DOWN;
			HqPaintData.filter =HQ_ALL;
			HqPaintData.jys =0;
			
			SetScrollRange(hWnd,SB_VERT,0,R_VERT,TRUE);
			SetScrollRange(hWnd,SB_HORZ,0,R_HORZ,TRUE);
			
			if(lf.lfHeight ==0)
			{
				memset(&lf,0,sizeof(lf));
				lf.lfWeight =FW_NORMAL;
    			lf.lfHeight=FontHight;
				lf.lfItalic=0;
				lf.lfUnderline=0;    		
			}
//			PostMessage(hWnd,WM_USER+1,NULL,NULL);
//			break;
		case WM_USER +1:	
			hDC =GetDC(hWnd);
			if(hHqFont!=NULL)
				DeleteObject(hHqFont);
    		hHqFont =CreateFontIndirect(&lf);
    		
    		SelectObject(hDC,hHqFont);
			GetTextMetrics(hDC, &tm);
			ReleaseDC(hWnd, hDC);
			
			if(X0_TITLE ==0) X0_TITLE =tm.tmAveCharWidth *10;
			if(ITEM_SPACE_X ==0) ITEM_SPACE_X =10;
			ITEM_SPACE_Y =tm.tmHeight*15/100;
			
//			PostMessage(hWnd,WM_USER +5,0,0L);
//		break;
		case WM_USER +5:
			GetClientRect(hWnd, &rc);
			i =rc.bottom -rc.top;

			HqPaintData.curRecCount =i/(tm.tmHeight+ITEM_SPACE_Y);	
			if(HqPaintData.curRecCount<=1) HqPaintData.curRecCount=2;
					
			ITEM_SPACE_Y +=(i-HqPaintData.curRecCount*(tm.tmHeight+ITEM_SPACE_Y))/HqPaintData.curRecCount;
			HqPaintData.itemHeight = tm.tmHeight+ITEM_SPACE_Y;
			if(HqPaintData.curRecCount>2)
				HqPaintData.curRecCount--;
			
			if(recList!=NULL)
				free(recList);
			recList =(short *)malloc(sizeof(short)*HqPaintData.curRecCount);
			if(recList ==NULL)
			{
				ErrMsg(hWnd, "alloc recList failed!");
				return -1;
			}
			
			x  =X0_TITLE;
			HqPaintData.x0 =0;
			HqPaintData.curFldNum=0;
			if(HqPaintData.fldCount <=0)
			{
				HqPaintData.fldCount =sizeof(HqFldLens)/sizeof(int);
				for(j =0; j<HqPaintData.fldCount; j++)
					HqPaintData.fldNum[j] =j;
			}
			
			for(j =0; j<HqPaintData.fldCount; j++)
			{
				HqPaintData.rcTitles[j].left =x;
				HqPaintData.rcTitles[j].right =
						x+(tm.tmAveCharWidth)*HqPaintFldLens[HqPaintData.fldNum[j]];
				x =HqPaintData.rcTitles[j].right+ITEM_SPACE_X;
				HqPaintData.rcTitles[j].top =0;  
				HqPaintData.rcTitles[j].bottom =tm.tmHeight;			
			} 
		break;
		case WM_VSCROLL:
		    if(wParam==SB_LINEDOWN)
		    	SendMessage(hWnd,WM_KEYDOWN,VK_DOWN,0L);
		    if(wParam==SB_LINEUP)
		    	SendMessage(hWnd,WM_KEYDOWN,VK_UP,0L);
		    if(wParam==SB_PAGEDOWN)
		    	SendMessage(hWnd,WM_KEYDOWN,VK_NEXT,0L);		    	
		    if(wParam==SB_PAGEUP)
		    	SendMessage(hWnd,WM_KEYDOWN,VK_PRIOR,0L);
		break;
		case WM_HSCROLL:
			if(wParam ==SB_LINEDOWN||wParam ==SB_PAGEDOWN)
				SendMessage(hWnd,WM_KEYDOWN,VK_RIGHT,0L);
			if(wParam ==SB_LINEUP||wParam ==SB_PAGEUP)
				SendMessage(hWnd,WM_KEYDOWN,VK_LEFT,0L);
		break;
		case WM_USER +2:
			if((int)wParam !=HqPaintData.jys) break;
			HqSort();
			InvalidateRect(hWnd, NULL, FALSE);
		break;		
		case WM_SETFOCUS:
			SetFocus(ghWndMain);
		break;		
		case WM_TIMER:
			if(wParam==5)
			{         
				if(HqPaintData.type >=HQ_SEL_1 && HqPaintData.type <=HQ_SEL_5||HqPaintData.filter!=HQ_ALL)
				{
					fSel =TRUE;
					for(i =0; i<HqPaintData.curRecCount
						&& i+HqPaintData.curRecNum<HqPaintData.recCount; i++)
						recList[i] =HqPaintData.sortData.key[i+HqPaintData.curRecNum];
					recCount =i;
				}
				else
				{
					fSel =FALSE;
					recList[0] =HqPaintData.sortData.key[HqPaintData.curRecNum];
					recCount =HqPaintData.curRecCount;
				}
				if(HqData[HqPaintData.jys].recCount ==0) fRefresh =FALSE;
				else fRefresh =TRUE;
				//to deal with the new stock code adding status,we must receive 
				//    stock code and other information 
				fRefresh=FALSE;				
				for(i =0; i<HqPaintData.curRecCount
						&& (i+HqPaintData.curRecNum <HqPaintData.recCount); i++)
				{
					recNum =HqPaintData.sortData.key[i+HqPaintData.curRecNum];
					
					if(HqData[HqPaintData.jys].isReadOK[recNum] ==FALSE)
					{
						fRefresh =FALSE;
						break;
					}
				}
				if(recCount&&!gfConnecting&&gfOnLine)
					UDP_Send_Hq00(HqPaintData.jys, FALSE, fRefresh, fSel, recCount, recList);

				KillTimer(hWnd,5);
				if(recCount)
				{   
				    recNum =HqPaintData.sortData.key[0];
					if((HqData[HqPaintData.jys].recCount==0||HqData[HqPaintData.jys].lpRefData[recNum].zdjm==0.00&&
							HqData[HqPaintData.jys].lpRefData[recNum].zgjm==0.00)&&gfOnLine)
						SetTimer(hWnd,5,10000,NULL);
				}	
			}
		break;
		
		case WM_RBUTTONDOWN:
			SetFocus(hWnd);
			SendMessage(hWnd, WM_KEYDOWN, VK_ESCAPE, 0L);
		break;
		case WM_KEYDOWN:
			GetClientRect(hWnd, &rc);
			DrawSelRect(hWnd, NULL, HqPaintData.curSelRec, TRUE);
			switch(wParam)
			{
				case VK_ESCAPE:
					DrawSelRect(hWnd, NULL, HqPaintData.curSelRec, FALSE);
					TrackPopupMenu(ghMenuHq, TPM_LEFTALIGN, 0,STATUS_HEIGHT -2,
						0, ghWndMain, NULL);
				return 0L;
				case VK_ADD:
					//if(FontHight<24)
					{
						FontHight-=2;
						lf.lfHeight=FontHight;
						PostMessage(hWnd,WM_USER+1,NULL,NULL);
						SetWindowText(hWndInput, "");						
						InvalidateRect(hWnd, NULL, TRUE);
					}
				return 0L;
				case VK_SUBTRACT:
					//if(FontHight>14)
					{
						FontHight+=2;
						lf.lfHeight=FontHight;
						PostMessage(hWnd,WM_USER+1,NULL,NULL);
						SetWindowText(hWndInput, "");						
						InvalidateRect(hWnd, NULL, TRUE);
					}
				return 0L;
				case VK_F1:
					if(!IsSzRead||!IsShRead)
						return 0L;
					if(!IsWindowVisible(ghWndHelp))
						ShowWindow(ghWndHelp,SW_SHOW);
					else
					    SetFocus(ghWndHelp);
					sprintf(tmp,"%s\\help.txt",szDataPath);
					i=LoadFile(tmp,0,"����/[ESC]�˳�");
					if(i>0)
						SendMessage(ghWndHelp,WM_USER+1,NULL,i);
				break;                                
				case VK_F2:
					if(!IsSzRead||!IsShRead)
						return 0L;				
				    SendMessage(ghWndMain,WM_COMMAND,IDM_JY,NULL);
				return 0L;
				break;
				case VK_F3:
					if(!IsSzRead||!IsShRead)
						return 0L;
				    SendMessage(ghWndXlt,WM_KEYDOWN,VK_F3,0L);
				return 0L;
				case VK_F4:
					if(!IsSzRead||!IsShRead)
						return 0L;
                    if(HqPaintData.jys==0)
						SendMessage(hWnd, WM_COMMAND, IDM_HQ_SH, 0L); 
					else
						SendMessage(hWnd, WM_COMMAND, IDM_HQ_SZ, 0L);
				return 0L;
				case VK_F5:
					if(!IsSzRead||!IsShRead)
						return 0L;
					switch(HqPaintData.type) 
					{
						case HQ_SZALL:
						case HQ_SHALL:
							SendMessage(hWnd, WM_COMMAND, IDM_HQSEL_1, 0L);
						    break;
						case HQ_SEL_1:
							SendMessage(hWnd, WM_COMMAND, IDM_HQSEL_2, 0L);
						    break;
						case HQ_SEL_2:
							SendMessage(hWnd, WM_COMMAND, IDM_HQSEL_3, 0L);
						    break;
						case HQ_SEL_3:
							SendMessage(hWnd, WM_COMMAND, IDM_HQSEL_4, 0L);
						    break;
						case HQ_SEL_4:
							SendMessage(hWnd, WM_COMMAND, IDM_HQSEL_5, 0L);							
						    break;
						case HQ_SEL_5:
							SendMessage(hWnd, WM_COMMAND, IDM_HQSEL_1, 0L);
							break;						    
					}
				return 0L;
				case VK_F7:
					SendMessage(hWnd, WM_COMMAND, IDM_HQSEL_SET_1, 0L);
				return 0L;
				case VK_F8:
					SendMessage(hWnd, WM_COMMAND, IDM_HQ_FLD_SEL, 0L);
				return 0L;
				case VK_F9:
					if(!IsSzRead||!IsShRead)
						return 0L;
					i =HqPaintData.sortData.key[HqPaintData.curSelRec+HqPaintData.curRecNum];
					GraphData.jys =MmpData.jys =HqPaintData.jys;
					GraphData.recNum =MmpData.recNum =i;					
					UDP_Send_Gra00(GraphData.jys, i);
					
					ShowWindow(ghWndLitHq, SW_SHOW);
					SendMessage(ghWndLitHq, WM_READ_OK, GraphData.jys, GraphData.recNum);
					if(IsZsRec(GraphData.jys, i))
					{
						ShowWindow(ghWndMmp, SW_HIDE);
						ShowWindow(ghWndCj, SW_HIDE);
						ShowWindow(ghWndZs, SW_SHOW);
						ShowWindow(ghWndMaxMin, SW_SHOW);
					}
					else
					{
						ShowWindow(ghWndZs, SW_HIDE);
						ShowWindow(ghWndMaxMin, SW_HIDE);
						ShowWindow(ghWndMmp, SW_SHOW);
						ShowWindow(ghWndCj, SW_SHOW);
					}
			
					SendMessage(ghWndXlt, WM_KEYDOWN, VK_RETURN, 0L);
					ShowWindow(hWnd, SW_HIDE);					
				return 0L;
				case VK_F11:
					if(!IsSzRead||!IsShRead)
						break;
					if(gfConnecting)
					{
						ErrMsg(ghWndMain,"��������ȯ��...��");
						break;
					}
					if(Addr[0][0]==0)
						InitQsInfo();
				    if(Addr[0][0]==0) break;
				    
				    if(Qsxx.zqsid[0]!=0&&Qsxx.zqsid[1]==0) //��ȯ��
				    {
				    	curChkUsrData.zqsid =Qsxx.zqsid[0];
				    	i=1;
				    }
				    else
				    {                                      //��ȯ��
						if((i=DlgSelectZqs())==0)
						{
							ErrMsg(ghWndMain,"ѡ��֤ȯ�̳��������ܽ��ף�");
							break;
						}
					}
					if(JyQs!=i)
					{		    
		    			Msg("��������֤ȯ���������Ժ�...",MSG_VERT);
		    			gfConnecting =TRUE;
		    			JyQs =0;
		    			SeleQs =i;
						if(ConnectToJyHost(Addr[i -1])!=0)
						{
							Msg("",MSG_HIDE);
							gfConnecting =FALSE;
							Msg("����֤ȯ������,��������...",MSG_VERT);
							JyQs =0;
							DispQsName(JyQs,0);
							break;
						}
						gfConnecting =FALSE;
					}
				break;
				case VK_F12:
					if(!IsSzRead||!IsShRead)
						return 0L;
					SendMessage(ghWndXlt, WM_KEYDOWN, VK_F12, 0L);
				return 0L;	
				case VK_F6:
				case VK_RETURN:
					if(!IsSzRead||!IsShRead)
						return 0L;
					if(HqPaintData.recCount <=0) break;
					tmp[0] =0;
					GetWindowText(hWndInput, &tmp[0], sizeof(tmp));
					if(tmp[0] ==0)
						SendMessage(hWnd, WM_COMMAND, IDM_GRAPH, 0L);
					else
					{                        
                        if(!strcmp("01", tmp))
                        {
                        	//if(HqPaintData.jys!=0)
                        	{
                        	    HqPaintData.filter =HQ_ALL;
								SendMessage(hWnd, WM_COMMAND, IDM_HQ_SZ, 0L);
								HqSort();
								InvalidateRect(hWnd, NULL, TRUE);
							}
							SetWindowText(hWndInput, "");								
							break;	
                        }

                        if(!strcmp("02", tmp))
                        {
                        	//if(HqPaintData.jys!=1)
                        	{
                        		HqPaintData.filter =HQ_ALL;
								SendMessage(hWnd, WM_COMMAND, IDM_HQ_SH, 0L);                        		
								HqSort();
								InvalidateRect(hWnd, NULL, TRUE);							
							}	
							SetWindowText(hWndInput, "");															
							break;	
                        }
                        if(!strcmp("03",tmp))
                        {
							SetWindowText(hWndInput, "");
							SendMessage(hWnd, WM_COMMAND, IDM_GRAPH, 3L);
							break;
                        }
                        if(!strcmp("04",tmp))
                        {
							SetWindowText(hWndInput, "");
							SendMessage(hWnd, WM_COMMAND, IDM_GRAPH, 4L);
							break;                        								
                        }
                        if(!strcmp("05",tmp))
                        {
                        	HqPaintData.filter =HQ_A;
							HqSort();
							InvalidateRect(hWnd, NULL, TRUE);
							SetWindowText(hWndInput, "");
							break;
                        }
                        else if(!strcmp("06",tmp))
                        {
                        	HqPaintData.filter =HQ_B;
                        	HqSort();
							InvalidateRect(hWnd, NULL, TRUE);
							SetWindowText(hWndInput, "");
							break;
                        }
                        else if(!strcmp("07",tmp))
                        {
                        	HqPaintData.filter =HQ_BOND;
                        	HqSort();
							InvalidateRect(hWnd, NULL, TRUE);
							SetWindowText(hWndInput, "");
							break;
                        }                        
                        else if(HqPaintData.type==HQ_SZALL&&strlen(tmp)==6)
                        {
							SendMessage(hWnd, WM_COMMAND, IDM_HQ_SH, 0L);
							InvalidateRect(hWnd, NULL, TRUE);                        	
                        }
                        else if(HqPaintData.type==HQ_SHALL&&strlen(tmp)==4)
                        {
							SendMessage(hWnd, WM_COMMAND, IDM_HQ_SZ, 0L);
							InvalidateRect(hWnd, NULL, TRUE);                        
                        }
						for(i =0; i<HqPaintData.recCount; i++)
						{
							j =HqPaintData.sortData.key[i];
							if(!strcmp(HqData[HqPaintData.jys].lpPreData[j].zqdm, tmp))
								break;
						}
						if(i <HqPaintData.recCount)
						{   
							if(HqPaintData.type==HQ_SZALL||HqPaintData.type==HQ_SHALL)
							{
								HqPaintData.curRecNum =i-i%HqPaintData.curRecCount;
								HqPaintData.curSelRec =i%HqPaintData.curRecCount;

								if(HqPaintData.curRecNum+HqPaintData.curRecCount >=HqPaintData.recCount)
								{
									HqPaintData.curRecNum =
										HqPaintData.recCount-HqPaintData.curRecCount;							
									for(i=0;i<HqPaintData.curRecCount;i++)
										if(!strcmp(HqData[HqPaintData.jys].lpPreData[i+HqPaintData.curRecNum].zqdm, tmp))
											break;
									HqPaintData.curSelRec=i;								
								}
							}
							else
								HqPaintData.curSelRec=i;
							InvalidateRect(hWnd, NULL, TRUE);
						}
						KillTimer(hWnd, 5);
						SetTimer(hWnd,5,1000,NULL);
						SetWindowText(hWndInput, "");
					}
				break;
				case VK_LEFT:
					DrawSelRect(hWnd, NULL, HqPaintData.curSelRec, FALSE);
					if(HqPaintData.curFldNum ==0) break;
					HqPaintData.curFldNum --;
					rc.left =X0_TITLE;
					x =HqPaintData.x0;
					if(HqPaintData.curFldNum >0)
					{
						HqPaintData.x0 +=
							HqPaintData.rcTitles[HqPaintData.curFldNum].right
							-HqPaintData.rcTitles[HqPaintData.curFldNum-1].right;
					}	
					else
						HqPaintData.x0 +=
							HqPaintData.rcTitles[HqPaintData.curFldNum].right
							-X0_TITLE;
					ScrollWindow(hWnd, HqPaintData.x0-x, 0, &rc, &rc);
					SetScrollPos(hWnd,SB_HORZ,(int)(HqPaintData.curFldNum*R_HORZ/HqPaintData.fldCount),TRUE);
				break;
				case VK_RIGHT:
					if(HqPaintData.rcTitles[HqPaintData.fldCount-1].right==0)
					{
						x  =X0_TITLE;
						for(j =0; j<HqPaintData.fldCount; j++)
						{
							HqPaintData.rcTitles[j].left =x;
							HqPaintData.rcTitles[j].right =
								x+tm.tmAveCharWidth*HqPaintFldLens[HqPaintData.fldNum[j]];
							HqPaintData.rcTitles[j].top =0;
							HqPaintData.rcTitles[j].bottom =tm.tmHeight;
			
							x =HqPaintData.rcTitles[j].right+ITEM_SPACE_X;
						}
					
					}
					DrawSelRect(hWnd, NULL, HqPaintData.curSelRec, FALSE);					
					if(HqPaintData.rcTitles[HqPaintData.fldCount-1].right
						+HqPaintData.x0<rc.right) break;
					if(HqPaintData.curFldNum>=HqPaintData.fldCount-1) break;
					rc.left =X0_TITLE;
					x =HqPaintData.x0;
					if(HqPaintData.curFldNum >0)
					{
						HqPaintData.x0 -=
							HqPaintData.rcTitles[HqPaintData.curFldNum].right
							-HqPaintData.rcTitles[HqPaintData.curFldNum-1].right;
					}		
					else    
						HqPaintData.x0 -=
							HqPaintData.rcTitles[HqPaintData.curFldNum].right
							-X0_TITLE;
					HqPaintData.curFldNum ++;
					ScrollWindow(hWnd, HqPaintData.x0-x, 0, &rc, &rc);
					SetScrollPos(hWnd,SB_HORZ,(int)(HqPaintData.curFldNum*R_HORZ/HqPaintData.fldCount),TRUE);					
				break;
				
				case VK_UP:
				
					HqPaintData.curSelRec--;
					if(HqPaintData.curSelRec <0)
					{
						HqPaintData.curSelRec =HqPaintData.curRecCount-1; //0
						if(HqPaintData.curSelRec >=HqPaintData.recCount)
							HqPaintData.curSelRec =HqPaintData.recCount-1;
					}
					SetScrollPos(hWnd,SB_VERT,(int)((long)(HqPaintData.curRecNum+HqPaintData.curSelRec)*(long)R_VERT/(long)HqPaintData.recCount),TRUE);
				break;
				case VK_DOWN:
					if(HqPaintData.curSelRec+HqPaintData.curRecNum
							>=HqPaintData.recCount-1)
					{
						HqPaintData.curSelRec =0;
						break;
					}
					HqPaintData.curSelRec++;
					if(HqPaintData.curSelRec >=HqPaintData.curRecCount)
						HqPaintData.curSelRec =0;//HqPaintData.curRecCount-1;
					SetScrollPos(hWnd,SB_VERT,(int)((long)(HqPaintData.curRecNum+HqPaintData.curSelRec)*(long)R_VERT/(long)HqPaintData.recCount),TRUE);	
				break;
				case VK_PRIOR:
					if(HqPaintData.rcTitles[HqPaintData.fldCount-1].right==0)
					{
						x  =X0_TITLE;
						for(j =0; j<HqPaintData.fldCount; j++)
						{
							HqPaintData.rcTitles[j].left =x;
							HqPaintData.rcTitles[j].right =
								x+tm.tmAveCharWidth*HqPaintFldLens[HqPaintData.fldNum[j]];
							HqPaintData.rcTitles[j].top =0;
							HqPaintData.rcTitles[j].bottom =tm.tmHeight;
			
							x =HqPaintData.rcTitles[j].right+ITEM_SPACE_X;
						}
					
					}
				
					if(HqPaintData.curRecNum ==0) break;
					i =HqPaintData.curRecNum;
					HqPaintData.curRecNum-=HqPaintData.curRecCount-1;
					if(HqPaintData.curRecNum <0)
						HqPaintData.curRecNum =0;
					HqPaintData.curSelRec =0;
					rc.top =HqPaintData.itemHeight;
					rc.bottom =HqPaintData.itemHeight*(HqPaintData.curRecCount+1);
					ScrollWindow(hWnd, 0,
							+(HqPaintData.curRecCount-1)*HqPaintData.itemHeight,
							&rc, &rc);
					SetScrollPos(hWnd,SB_VERT,(int)((long)(HqPaintData.curRecNum+HqPaintData.curSelRec)*(long)R_VERT/(long)HqPaintData.recCount),TRUE);
					if(HqPaintData.curRecCount <HqPaintData.recCount)
					{
						KillTimer(hWnd, 5);
						SetTimer(hWnd,5,500,NULL);
					}
				break;
				case VK_NEXT:
					if(IsSzRead&&IsShRead)
					{				
						if(HqPaintData.rcTitles[HqPaintData.fldCount-1].right==0)
						{
							x  =X0_TITLE;
							for(j =0; j<HqPaintData.fldCount; j++)
							{
								HqPaintData.rcTitles[j].left =x;
								HqPaintData.rcTitles[j].right =
									x+tm.tmAveCharWidth*HqPaintFldLens[HqPaintData.fldNum[j]];
								HqPaintData.rcTitles[j].top =0;
								HqPaintData.rcTitles[j].bottom =tm.tmHeight;
			
								x =HqPaintData.rcTitles[j].right+ITEM_SPACE_X;
							}					
						}
				
						if(HqPaintData.curRecNum+HqPaintData.curRecCount >=HqPaintData.recCount)
							break;
						i =HqPaintData.curRecNum;
						HqPaintData.curRecNum+=HqPaintData.curRecCount-1;
						if(HqPaintData.curRecNum+HqPaintData.curRecCount >=HqPaintData.recCount)
							HqPaintData.curRecNum =HqPaintData.recCount-HqPaintData.curRecCount;
						HqPaintData.curSelRec =0;
						rc.top =HqPaintData.itemHeight;
						rc.bottom =HqPaintData.itemHeight*(HqPaintData.curRecCount+1);
						ScrollWindow(hWnd, 0,
							-(HqPaintData.curRecCount-1)*HqPaintData.itemHeight,
							&rc, &rc);
						SetScrollPos(hWnd,SB_VERT,(int)((long)(HqPaintData.curRecNum+HqPaintData.curSelRec)*(long)R_VERT/(long)HqPaintData.recCount),TRUE);
						if(HqPaintData.curRecNum+HqPaintData.curRecCount >=HqPaintData.recCount)
							InvalidateRect(hWnd, NULL, TRUE);
						if(HqPaintData.curRecCount <HqPaintData.recCount)
						{
							KillTimer(hWnd, 5);
							SetTimer(hWnd,5,500,NULL);
						}
					}
				break;
				case VK_HOME:
					HqPaintData.curRecNum =HqPaintData.curSelRec =0;
					InvalidateRect(hWnd, NULL, TRUE);
					if(HqPaintData.recCount >HqPaintData.curRecCount)
					{
						KillTimer(hWnd, 5);
						SetTimer(hWnd,5,500,NULL);
					}
					SetScrollPos(hWnd,SB_VERT,(int)((long)(HqPaintData.curRecNum+HqPaintData.curSelRec)*(long)R_VERT/(long)HqPaintData.recCount),TRUE);
				return 0L;
				case VK_END:
					if(IsSzRead&&IsShRead)
					{				
						if(HqPaintData.recCount <HqPaintData.curRecCount)
						{
							HqPaintData.curRecNum =0;
							HqPaintData.curSelRec =HqPaintData.recCount-1;
						}
						else
						{
							HqPaintData.curSelRec =HqPaintData.curRecCount-1;
							HqPaintData.curRecNum =HqPaintData.recCount
								-HqPaintData.curRecCount;
							KillTimer(hWnd, 5);
							SetTimer(hWnd,5,500,NULL);
						}
						InvalidateRect(hWnd, NULL, TRUE);
					}
					SetScrollPos(hWnd,SB_VERT,(int)((long)(HqPaintData.curRecNum+HqPaintData.curSelRec)*(long)R_VERT/(long)HqPaintData.recCount),TRUE);
					return 0L;
				default:
					break;  
			}
			UpdateWindow(hWnd);
			DrawSelRect(hWnd, NULL, HqPaintData.curSelRec, FALSE);
		break;

		case WM_LBUTTONDBLCLK:
			PostMessage(hWnd,WM_KEYDOWN,VK_RETURN,NULL);
		break;
		
		case WM_LBUTTONDOWN:
			SetFocus(hWnd);
			x=LOWORD(lParam);
			y=HIWORD(lParam);
			
			DrawSelRect(hWnd, NULL, HqPaintData.curSelRec, TRUE);
			i=(int)((y)/(HqPaintData.rcTitles[0].bottom+ITEM_SPACE_Y)) -1;
			if(i>=HqPaintData.recCount) i=HqPaintData.recCount -1;
			if(i<0) i=0;
			HqPaintData.curSelRec=i;
			DrawSelRect(hWnd, NULL, HqPaintData.curSelRec, FALSE);
			if(clock()-MouDownClk<240)
				PostMessage(hWnd,WM_KEYDOWN,VK_RETURN,NULL);
			MouDownClk=clock();
		break;
		
		case WM_PAINT:
			if(HqPaintData.type<2&&
				HqPaintData.curRecCount>0&&HqPaintData.recCount>0)
			{
				if(HqPaintData.curRecNum+HqPaintData.curRecCount >=HqPaintData.recCount)
					HqPaintData.curRecNum =HqPaintData.recCount-HqPaintData.curRecCount;
		    }	
			if(HqData[HqPaintData.jys].recCount <=0) break;
			
			GetClientRect(hWnd, &rc);
			BeginPaint(hWnd, &ps);
    		SelectObject(ps.hdc,hHqFont);
			GetClientRect(hWnd, &rc);
			
			// draw title
			rc.left =DrawTitle(hWnd, ps.hdc);
			
			rc.top =HqPaintData.itemHeight;
			rc.bottom =HqPaintData.itemHeight*(HqPaintData.curRecCount+1);
			IntersectClipRect(ps.hdc, rc.left, rc.top, rc.right, rc.bottom);
			SetTextAlign(ps.hdc, TA_TOP|TA_RIGHT);
			
			SetBkMode(ps.hdc, OPAQUE);
			i =HqPaintData.curRecNum;
			SetBkColor(ps.hdc, RGB(0, 0, 0));
			
			m =0;
			//for(j =0; j<HqPaintData.curFldNum; j++)
			//      m +=HqFldLens[j];
			SetTextColor(ps.hdc, RGB(0, 255, 0));
			hDC =CreateCompatibleDC(ps.hdc);
			n =-1;
			while(i <=HqPaintData.curRecNum+HqPaintData.curRecCount
					&& i<HqPaintData.recCount)
			{
				for(j =HqPaintData.curFldNum;
					j<HqPaintData.fldCount; j++)
				{
					x =HqPaintData.rcTitles[j].right+HqPaintData.x0;
					//if(x >rc.right) break;
					
					y =(HqPaintData.rcTitles[0].bottom+ITEM_SPACE_Y)
							*(i-HqPaintData.curRecNum+1);
							
					lpTmp =GetHqFldPos(ps.hdc, HqPaintData.jys,
								HqPaintData.sortData.key[i],
								HqPaintData.fldNum[j]);
					/*if(HqData[HqPaintData.jys].isChanged[HqPaintData.sortData.key[i]*HQ_REF_ITEM_COUNT+j] >0)
						SetTextColor(ps.hdc, RGB(255, 0, 0));   // red
					else if(HqData[HqPaintData.jys].isChanged[HqPaintData.sortData.key[i]*HQ_REF_ITEM_COUNT+j] <0)
						SetTextColor(ps.hdc, RGB(0, 255, 0));   // blue
					else SetTextColor(ps.hdc, RGB(255, 255, 255));  // black
					*/
					l =HqPaintFldLens[HqPaintData.fldNum[j]]-strlen(tmp);
					for(k =0; k<l; k++)
						tmp[k] =0x20;
					switch(HqFldTypes[HqPaintData.fldNum[j]])
					{
						case FLD_TYPE_STRING:
							strcpy(&tmp[0], lpTmp);
						break;
						case FLD_TYPE_FLOAT:
							sprintf(&tmp[k], "%.2f", *(float *)lpTmp);
							if(strncmp(&tmp[k],"9999.99",7)==0) strcpy(&tmp[k],"-.--");
								
							if(HqPaintData.fldNum[j] ==7)
							{
								if(HqData[HqPaintData.jys].isJgChanged[i] >0)
								{
									SelectObject(hDC, hBmpUp);
									BitBlt(ps.hdc, x+2, y+2, 10, 10, hDC, 0, 0, SRCCOPY);
								}
								else if(HqData[HqPaintData.jys].isJgChanged[i] <0)
								{
									SelectObject(hDC, hBmpDown);
									BitBlt(ps.hdc, x+2, y+2, 10, 10, hDC, 0, 0, SRCCOPY);
								}
								else
								{
									SelectObject(ps.hdc, GetStockObject(BLACK_BRUSH));
									SelectObject(ps.hdc, GetStockObject(NULL_PEN));
									Rectangle(ps.hdc, x+2, y+2, x+12, y+12);
								}
								n =j+1;
							}
						break;
						case FLD_TYPE_LONG:
							if(HqPaintData.fldNum[j] ==14)
								sprintf(&tmp[k], "%.1f", (float)*(long *)lpTmp/10);
							else
								sprintf(&tmp[k], "%ld", *(long *)lpTmp);
						break;
					}
					//strcpy(&tmp[k], lpTmp);
					if(j ==0)
						SetRect(&rc1, rc.left,
								y, x, y+HqPaintData.rcTitles[0].bottom+1);
					else if(j ==n)
						SetRect(&rc1, HqPaintData.rcTitles[j-1].right+HqPaintData.x0+12,
								y, x, y+HqPaintData.rcTitles[0].bottom+1);
					else
						SetRect(&rc1, HqPaintData.rcTitles[j-1].right+HqPaintData.x0,
								y, x, y+HqPaintData.rcTitles[0].bottom+1);
					if(HqPaintData.fldNum[j] ==10)
					{
						SelectObject(ps.hdc, GetStockObject(NULL_PEN));
						SelectObject(ps.hdc, GetStockObject(BLACK_BRUSH));
						Rectangle(ps.hdc, rc1.left, rc1.top,
									rc1.right, rc1.bottom);
						ExtTextOut(ps.hdc, x, y, ETO_CLIPPED,
								&rc1, tmp, strlen(tmp), NULL);
					}
					else    
						ExtTextOut(ps.hdc, x, y, ETO_CLIPPED|ETO_OPAQUE,
								&rc1, tmp, strlen(tmp), NULL);
					//lpTmp +=HqFldLens[j];
					if(x >rc.right) break;
				}
				i++;
			}
			DeleteObject(hDC);
			EndPaint(hWnd, &ps);
		break;
		
		case WM_COMMAND:
			if(wParam >=IDM_SORT_ZQDM && wParam <=IDM_SORT_CJJE)
			{
				if(!IsWindowVisible(hWnd)) return 0L;
				CheckMenuItem(ghMenuHq, HqPaintData.sortData.fldID+IDM_SORT_ZQDM,
						MF_BYCOMMAND|MF_UNCHECKED);
				HqPaintData.sortData.fldID =(int)wParam -IDM_SORT_ZQDM;
						HqSort();
				CheckMenuItem(ghMenuHq, wParam, MF_BYCOMMAND|MF_CHECKED);
				InvalidateRect(hWnd, NULL, TRUE);
				return 0L;
			}
			
			i =HqPaintData.type;
			switch(wParam)
			{
				case IDM_HQSEL_SET_1:
				case IDM_HQSEL_SET_2:
				case IDM_HQSEL_SET_3:
				case IDM_HQSEL_SET_4:
				case IDM_HQSEL_SET_5:
				case IDM_HQ_FLD_SEL:
				case IDM_JY:
				case IDM_MINIMIZE:
				case IDM_EXIT:
					SendMessage(ghWndMain, WM_COMMAND, wParam, lParam);
				return 0L;
				
				case IDM_GRAPH:
					if(!HqPaintData.recCount) return 0L;
					if(lParam==3)
					{   
					    for(i=HqData[0].recCount-1;i>=0;i--)
					    {
					    	if(strncmp("9901",HqData[0].lpPreData[i].zqdm,4)==0)
					    		break;
					    }
					    if(i<0)	return 0L;
						GraphData.jys =MmpData.jys=0;
						
					}	
					if(lParam==4)
					{
					    for(i=0;i<HqData[1].recCount;i++)
					    {
					    	if(strncmp("000001",HqData[1].lpPreData[i].zqdm,6)==0)
					    	{
					    		break;
					    	}
					    }
					    if(i>=HqData[1].recCount) return 0L;
						GraphData.jys =MmpData.jys=1;
					}	
					if(lParam==0)	
					{
						i =HqPaintData.sortData.key[HqPaintData.curSelRec+HqPaintData.curRecNum];
						GraphData.jys =MmpData.jys =HqPaintData.jys;
					}	
					GraphData.recNum =MmpData.recNum =i;					
					UDP_Send_Gra00(GraphData.jys, i);
					
					if(!IsWindowVisible(ghWndXlt))
						ShowWindow(ghWndXlt, SW_SHOW);
					else
						InvalidateRect(ghWndXlt, NULL, TRUE);
					if(!IsWindowVisible(ghWndJlt))	
						ShowWindow(ghWndJlt, SW_SHOW);
					else
					    InvalidateRect(ghWndJlt, NULL, TRUE);
					if(!IsWindowVisible(ghWndLitHq))    
						ShowWindow(ghWndLitHq, SW_SHOW);
					else
					    InvalidateRect(ghWndLitHq, NULL, TRUE);
					SendMessage(ghWndLitHq, WM_READ_OK, GraphData.jys, GraphData.recNum);
					if(IsZsRec(GraphData.jys, i))
					{
						ShowWindow(ghWndMmp, SW_HIDE);
						ShowWindow(ghWndCj, SW_HIDE);
						
						if(!IsWindowVisible(ghWndZs))
							ShowWindow(ghWndZs, SW_SHOW);
						else
						    InvalidateRect(ghWndZs, NULL, TRUE);
						if(!IsWindowVisible(ghWndMaxMin))    
							ShowWindow(ghWndMaxMin, SW_SHOW);
						else
						   	InvalidateRect(ghWndMaxMin, NULL, TRUE);
					}
					else
					{
						ShowWindow(ghWndZs, SW_HIDE);
						ShowWindow(ghWndMaxMin, SW_HIDE);    
						
						if(!IsWindowVisible(ghWndMmp))    
							ShowWindow(ghWndMmp, SW_SHOW);
						else
						    InvalidateRect(ghWndMmp, NULL, TRUE); 
						if(!IsWindowVisible(ghWndCj))        
							ShowWindow(ghWndCj, SW_SHOW);
						else
						    InvalidateRect(ghWndCj, NULL, TRUE); 
					}
			        if(IsWindowVisible(ghWndHq)) ShowWindow(hWnd, SW_HIDE);
				return 0L;
				
				case IDM_SORT_UP:
					if(!IsWindowVisible(hWnd)) return 0L;
					CheckMenuItem(ghMenuHq, IDM_SORT_DOWN, MF_BYCOMMAND|MF_UNCHECKED);
					HqPaintData.sortData.type =SORT_UP;
					HqSort();
					CheckMenuItem(ghMenuHq, IDM_SORT_UP, MF_BYCOMMAND|MF_CHECKED);
					InvalidateRect(hWnd, NULL, TRUE);
				return 0L;
				case IDM_SORT_DOWN:
					if(!IsWindowVisible(hWnd)) return 0L;
					CheckMenuItem(ghMenuHq, IDM_SORT_UP, MF_BYCOMMAND|MF_UNCHECKED);
					HqPaintData.sortData.type =SORT_DOWN;
					HqSort();
					CheckMenuItem(ghMenuHq, IDM_SORT_DOWN, MF_BYCOMMAND|MF_CHECKED);
					InvalidateRect(hWnd, NULL, TRUE);
				return 0L;
				
				case IDM_HQ_SZ:
					HqPaintData.type =HQ_SZALL;
				break;
				case IDM_HQ_SH:
					HqPaintData.type =HQ_SHALL;
				break;
				case IDM_HQSEL_1:
					HqPaintData.type =HQ_SEL_1;
				break;
				case IDM_HQSEL_2:
					HqPaintData.type =HQ_SEL_2;
				break;
				case IDM_HQSEL_3:
					HqPaintData.type =HQ_SEL_3;
				break;
				case IDM_HQSEL_4:
					HqPaintData.type =HQ_SEL_4;
				break;
				case IDM_HQSEL_5:
					HqPaintData.type =HQ_SEL_5;
				break;
				default: return 0L;
			}                                                 
			
			ShowWindow(ghWndFx,SW_HIDE);
			ShowWindow(ghWndJlt, SW_HIDE);
			ShowWindow(ghWndXlt, SW_HIDE);
			ShowWindow(ghWndCj, SW_HIDE);
			ShowWindow(ghWndLitHq,SW_HIDE);
			ShowWindow(ghWndMmp, SW_HIDE);
			ShowWindow(ghWndZs, SW_HIDE);
			ShowWindow(ghWndMaxMin, SW_HIDE);
			
			CheckMenuItem(ghMenuHq, i+IDM_HQ_SZ, MF_BYCOMMAND|MF_UNCHECKED);
			HqSort();
			HqPaintData.curRecNum =0;
			HqPaintData.curFldNum =0;
			HqPaintData.curSelRec =0;
			HqPaintData.x0 =0;
			if(!IsWindowVisible(hWnd))
			{
				ShowWindow(hWnd, SW_SHOW);
			}
			CheckMenuItem(ghMenuHq, wParam, MF_BYCOMMAND|MF_CHECKED);

			KillTimer(hWnd, 5);
			SetTimer(hWnd, 5, 1000, NULL);
					
			InvalidateRect(hWnd, NULL, TRUE);
		break;
		case WM_DESTROY:
			if(recList) free(recList); 
	}
	
	return DefWindowProc(hWnd, message, wParam, lParam);
}

LPSTR HqTitles[HQ_FLDS_COUNT+2] =
{
	"����","����","��","���","���","����","����","�ɽ�","�Ƿ�",
	"����","����", "����", "����", "ί��", "���(��)","�ǵ�",NULL
};
					
int DrawTitle(HWND hWnd, HDC hDC)
{
	int i, jys;
	RECT rc;
	char temp[20];
	
	jys =HqPaintData.jys;
	GetClientRect(hWnd, &rc);
	
	//SetBkMode(hDC, TRANSPARENT);
	SetBkMode(hDC, OPAQUE);
	SetTextColor(hDC, RGB(255, 0, 255));
	SetBkColor(hDC,RGB(0,0,0));
	SetTextAlign(hDC, TA_LEFT|TA_TOP);
	i =HqPaintData.curRecNum;
	for(;i <HqPaintData.curRecNum+HqPaintData.curRecCount
			&& i<HqPaintData.recCount; i++)
	{
		if(IsZsRec(HqPaintData.jys, HqPaintData.sortData.key[i]))
			SetTextColor(hDC, RGB(255, 0, 0));
		else SetTextColor(hDC, RGB(255, 0, 255));
		strcpy(temp,HqData[jys].lpPreData[HqPaintData.sortData.key[i]].zqmc);
		TextOut(hDC, 0,(HqPaintData.rcTitles[0].bottom+ITEM_SPACE_Y)
				*(i-HqPaintData.curRecNum+1),temp, 
				strlen(HqData[jys].lpPreData[HqPaintData.sortData.key[i]].zqmc));
	}
	DrawSelRect(hWnd, hDC, HqPaintData.curSelRec, FALSE);
	SetTextColor(hDC, RGB(0, 255, 255));
	TextOut(hDC, 0, 0, "֤ȯ����", strlen("֤ȯ����"));
	rc.left =LOWORD(GetTextExtent(hDC, "֤ȯ����", 8))+2;//X0_TITLE-ITEM_SPACE_X;
	IntersectClipRect(hDC, rc.left, rc.top, rc.right, rc.bottom);
	SetTextAlign(hDC, TA_RIGHT|TA_TOP);
	for(i =HqPaintData.curFldNum;
			i<HqPaintData.fldCount; i++)
	{
		if(HqPaintData.rcTitles[i].left+HqPaintData.x0 >rc.right) break;
		if(HqPaintData.sortData.fldID ==HqPaintData.fldNum[i])
		{
			if(HqPaintData.sortData.type ==SORT_UP)
				SetTextColor(hDC, RGB(255, 0, 0));
			else SetTextColor(hDC, RGB(0, 0, 255));
		}
		else SetTextColor(hDC, RGB(0, 255, 255));
		TextOut(hDC, HqPaintData.rcTitles[i].right+HqPaintData.x0, 0,
				HqTitles[HqPaintData.fldNum[i]],
				strlen(HqTitles[HqPaintData.fldNum[i]]));
	}
	
	return rc.left;
}

extern int CompString(LPSTR, LPSTR);
void DrawSelRect(HWND hWnd, HDC hDC, int sel_num, int bClr)
{
	RECT rc;
	DWORD dw;
	HPEN hPen;
	HDC hdc;
	int height, width,i;
    char temp[20];
    
	if(HqPaintData.recCount <=0) return;
	if(hDC ==NULL) hdc =GetDC(hWnd);
	else hdc =hDC;
	
	SelectObject(hdc,hHqFont);
	dw =GetTextExtent(hdc, "֤ȯ����", 8);
	GetClientRect(hWnd, &rc);

	height=HqPaintData.itemHeight-ITEM_SPACE_Y;
	width =LOWORD(dw);	
	SelectObject(hdc, GetStockObject(NULL_BRUSH));
	i=HqPaintData.curSelRec+HqPaintData.curRecNum;
	if(bClr)       
	{
		hPen =CreatePen(PS_SOLID, 0, RGB(0, 0, 0));
		SetBkColor(hdc,RGB(0,0,0));
		if(IsZsRec(HqPaintData.jys, HqPaintData.sortData.key[i]))		
		    SetTextColor(hdc, RGB(255, 0, 0));
		else
			SetTextColor(hdc, RGB(255, 0, 255));
	}
	else
	{
		hPen =CreatePen(PS_SOLID, 0, RGB(180, 180, 180));
		SetBkColor(hdc,RGB(255,255,255));		
		SetTextColor(hdc, RGB(0,0, 255));
	}
	SelectObject(hdc, hPen);
	MoveTo(hdc, 0, (sel_num+1)*(height+ITEM_SPACE_Y)+height+1);
	LineTo(hdc, rc.right-1, (sel_num+1)*(height+ITEM_SPACE_Y)+height+1);

    rc.right =width +rc.left;
    rc.top =(sel_num+1)*(height+ITEM_SPACE_Y);
    rc.bottom =rc.top+height+1;
    if(bClr)
    	FillRect(hdc,&rc,GetStockObject(BLACK_BRUSH));
    else       
    	FillRect(hdc,&rc,GetStockObject(WHITE_BRUSH));
    
	strcpy(temp,HqData[HqPaintData.jys].lpPreData[HqPaintData.sortData.key[i]].zqmc);
	for(i=strlen(temp);i<8;i++) temp[i]=' ';
	TextOut(hdc, 0,(HqPaintData.rcTitles[0].bottom+ITEM_SPACE_Y)
		*(HqPaintData.curSelRec+1),temp,8);
	SelectObject(hdc, GetStockObject(WHITE_PEN));
	DeleteObject(hPen);
	if(hDC ==NULL) ReleaseDC(hWnd, hdc);	
	if(hDC !=NULL)
	{ 
		SelectObject(hDC, GetStockObject(WHITE_PEN));
	 	SetBkColor(hDC,RGB(0,0,0));	
	}
}

int HqSort(void)
{
	int i,j;
	int jys;
		
	switch(HqPaintData.type)
	{
		case HQ_SZALL:
			HqPaintData.recCount =HqData[0].recCount;
			jys =HqPaintData.jys =0;
			for(i =0,j=0; i<HqData[0].recCount; i++)
			{ 
				if(HqPaintData.filter ==HQ_ALL)					
					HqPaintData.sortData.key[j++] =i;
				if(HqPaintData.filter ==HQ_A)
				{
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='1')
						continue;
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='2')
						continue;						
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='3')
						continue;
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='8')
						continue;
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='9')
						continue;
					HqPaintData.sortData.key[j++] =i;
				}
				if(HqPaintData.filter ==HQ_B)
				{
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='2')
						HqPaintData.sortData.key[j++] =i;
					else
						continue;
				}
				if(HqPaintData.filter ==HQ_BOND)
				{
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='1')
						HqPaintData.sortData.key[j++] =i;
					else
						continue;
				}				
			}
			HqPaintData.recCount =j;
		break;
		case HQ_SHALL:
			HqPaintData.recCount =HqData[1].recCount;
			jys =HqPaintData.jys =1;
			for(i =0,j=0; i<HqData[1].recCount; i++)
			{
			    if(HqPaintData.filter ==HQ_ALL)
					HqPaintData.sortData.key[j++] =i;
				if(HqPaintData.filter ==HQ_A)
				{
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='0')
						continue;
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='1')
						continue;						
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='2')
						continue;
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='7')
						continue;
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='9')
						continue;
					HqPaintData.sortData.key[j++] =i;
				}
				if(HqPaintData.filter ==HQ_B)
				{
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]=='9')
						HqPaintData.sortData.key[j++] =i;
					else
						continue;
				}
				if(HqPaintData.filter ==HQ_BOND)
				{
					if(atoi(HqData[HqPaintData.jys].lpPreData[i].zqdm)<=10)
						continue;
					if(HqData[HqPaintData.jys].lpPreData[i].zqdm[0]<='2')
						HqPaintData.sortData.key[j++] =i;
					else
						continue;
				}				
			}
			HqPaintData.recCount =j;
		break;
		case HQ_SEL_1:
			HqPaintData.recCount =HqSelData[0].recCount;
			for(i =0; i<HqPaintData.recCount; i++)
				HqPaintData.sortData.key[i] =HqSelData[0].recNum[i];
			jys =HqPaintData.jys =HqSelData[0].jys;
		break;
		case HQ_SEL_2:
			HqPaintData.recCount =HqSelData[1].recCount;
			for(i =0; i<HqPaintData.recCount; i++)
				HqPaintData.sortData.key[i] =HqSelData[1].recNum[i];
			jys =HqPaintData.jys =HqSelData[1].jys;
		break;
		case HQ_SEL_3:
			HqPaintData.recCount =HqSelData[2].recCount;
			for(i =0; i<HqPaintData.recCount; i++)
				HqPaintData.sortData.key[i] =HqSelData[2].recNum[i];
			jys =HqPaintData.jys =HqSelData[2].jys;
		break;
		case HQ_SEL_4:
			HqPaintData.recCount =HqSelData[3].recCount;
			for(i =0; i<HqPaintData.recCount; i++)
				HqPaintData.sortData.key[i] =HqSelData[3].recNum[i];
			jys =HqPaintData.jys =HqSelData[3].jys;
		break;
		case HQ_SEL_5:
			HqPaintData.recCount =HqSelData[4].recCount;
			for(i =0; i<HqPaintData.recCount; i++)
				HqPaintData.sortData.key[i] =HqSelData[4].recNum[i];
			jys =HqPaintData.jys =HqSelData[4].jys;
		break;
	}
		
	//if(HqPaintData.sortData.fldID >=HqPaintData.fldCount)
	//      return 0;
	if(HqFldTypes[HqPaintData.sortData.fldID] ==FLD_TYPE_FLOAT)
		SortFloat(&HqPaintData.sortData, jys);
	else
		if(HqFldTypes[HqPaintData.sortData.fldID] ==FLD_TYPE_LONG)
			SortLong(&HqPaintData.sortData, jys);
	
	return 0;
}

int SortFloat(LPSORT_DATA lpSortData, int jys)
{
	int key, i, j, k, n;
	float fval, f1, f;
	
	k =HqPaintData.sortData.fldID;
	
	for(i=0; i<HqPaintData.recCount-1; i++)
	{
		key =i;
		fval =*(float*)GetHqFldPos1(jys, lpSortData->key[key], k);
		for(j =i+1; j<HqPaintData.recCount; j++)
		{
			f1 =*(float *)GetHqFldPos1(jys, lpSortData->key[j], k);
			f =f1-fval;
			if(lpSortData->type ==SORT_UP && f>.0)
			{
				key =j;
				fval =f1;
			}
			else if(lpSortData->type ==SORT_DOWN && f<.0)           
			{
				key =j;
				fval =f1;
			}
		}
		if(key >i)
		{
			//fval =*(float *)GetHqFldPos1(jys, lpSortData->key[key], k);
			n =lpSortData->key[i];
			lpSortData->key[i] =lpSortData->key[key];
			lpSortData->key[key] =n;
		}
	}
	return 0;
}

int SortLong(LPSORT_DATA lpSortData, int jys)
{
	int key, i, j, k, n;
	long lval, l1, l;
	
	k =HqPaintData.sortData.fldID;
	
	for(i=0; i<HqPaintData.recCount-1; i++)
	{
		key =i;
		lval =*(long*)GetHqFldPos1(jys, lpSortData->key[key], k);
		for(j =i+1; j<HqPaintData.recCount; j++)
		{
			l1 =*(long *)GetHqFldPos1(jys, lpSortData->key[j], k);
			l =l1-lval;
			if(lpSortData->type ==SORT_UP && l>0)
			{
				key =j;
				lval =l1;
			}
			else if(lpSortData->type ==SORT_DOWN && l<0)            
			{
				key =j;
				lval =l1;
			}
		}
		if(key >i)
		{
			//lval =*(long *)GetHqFldPos1(jys, lpSortData->key[key], k);
			n =lpSortData->key[i];
			lpSortData->key[i] =lpSortData->key[key];
			lpSortData->key[key] =n;
		}
	}
	return 0;
}

LPSTR GetHqFldPos(HDC hDC, int jys, int rec_num, int fld_num)
{
	float f;
	LPSTR lpFld;
	static long l;


	if(HqData[jys].lpPreData[rec_num].zrsp!=0)
	{
		HqData[jys].lpRefData[rec_num].zdf=
			(HqData[jys].lpRefData[rec_num].zjjg-HqData[jys].lpPreData[rec_num].zrsp)*100/
				HqData[jys].lpPreData[rec_num].zrsp;
	}
		
	SetBkColor(hDC, RGB(0, 0, 0));
	switch(fld_num)
	{
		case 0:
			SetTextColor(hDC, RGB(180, 180, 0));
		return (LPSTR)&HqData[jys].lpPreData[rec_num].zqdm[0];
		case 1:
			SetTextColor(hDC, RGB(255, 255, 255));
		return (LPSTR)&HqData[jys].lpPreData[rec_num].zrsp;
		case 2:
			f =((HqData[jys].lpPreData[rec_num].jrkp
					-HqData[jys].lpPreData[rec_num].zrsp));
			lpFld =(LPSTR)&HqData[jys].lpPreData[rec_num].jrkp;
		break;
		case 3:
			f =((HqData[jys].lpRefData[rec_num].zgjg
					-HqData[jys].lpPreData[rec_num].zrsp));
			lpFld =(LPSTR)&HqData[jys].lpRefData[rec_num].zgjg;
		break;
		case 4:
			f =((HqData[jys].lpRefData[rec_num].zdjg
					-HqData[jys].lpPreData[rec_num].zrsp));
			lpFld =(LPSTR)&HqData[jys].lpRefData[rec_num].zdjg;
		break;
		case 5:
			f =((HqData[jys].lpRefData[rec_num].zgjm
					-HqData[jys].lpPreData[rec_num].zrsp));
			lpFld =(LPSTR)&HqData[jys].lpRefData[rec_num].zgjm;
		break;
		case 6:
			f =((HqData[jys].lpRefData[rec_num].zdjm
					-HqData[jys].lpPreData[rec_num].zrsp));
			lpFld =(LPSTR)&HqData[jys].lpRefData[rec_num].zdjm;
		break;
		case 7:
			f =((HqData[jys].lpRefData[rec_num].zjjg
					-HqData[jys].lpPreData[rec_num].zrsp));
			lpFld =(LPSTR)&HqData[jys].lpRefData[rec_num].zjjg;
		break;
		case 8:
			f =(float)(HqData[jys].lpRefData[rec_num].zdf);
			lpFld =(LPSTR)&HqData[jys].lpRefData[rec_num].zdf;
		break;
		case 9:
			f =HqData[jys].lpRefData[rec_num].zdf;
			lpFld =(LPSTR)&HqData[jys].lpRefData[rec_num].cjss;
		break;
		case 10:
			f =HqData[jys].lpRefData[rec_num].zdf;
			if(HqData[jys].isJgChanged[rec_num]>0)
				SetBkColor(hDC, RGB(80, 0, 0));
			else if(HqData[jys].isJgChanged[rec_num]<0)
				SetBkColor(hDC, RGB(0, 80, 0));
			else SetBkColor(hDC, RGB(0, 0, 0));
			SetTextColor(hDC, RGB(255, 255, 0));
			return (LPSTR)&HqData[jys].lpRefData[rec_num].lc;
		//break;
		case 11:
			f =HqData[jys].lpRefData[rec_num].zdf;
			lpFld = (LPSTR)&HqData[jys].lpRefData[rec_num].npzl;
		break;
		case 12:
			l =HqData[jys].lpRefData[rec_num].cjss
				-HqData[jys].lpRefData[rec_num].npzl;
			f =HqData[jys].lpRefData[rec_num].zdf;
			lpFld =(LPSTR)&l;
		break;
		case 13:
			f =HqData[jys].lpRefData[rec_num].zdf;
			lpFld =(LPSTR)&HqData[jys].lpRefData[rec_num].wb;
		break;
		case 14:
			f =HqData[jys].lpRefData[rec_num].zdf;
			lpFld =(LPSTR)&HqData[jys].lpRefData[rec_num].cjje;
		break;	
		case 15:
			f =HqData[jys].lpRefData[rec_num].zdf;
					
			HqZd =HqData[jys].lpRefData[rec_num].zjjg -
				HqData[jys].lpPreData[rec_num].zrsp;
			lpFld =(LPSTR)&HqZd;
		break;
	}
	if(f >0) SetTextColor(hDC, RGB(255, 0, 0));
	else if(f <0) SetTextColor(hDC, RGB(0, 255, 0));
	else SetTextColor(hDC, RGB(255, 255, 255));
	
	return lpFld;
}

LPSTR GetHqFldPos1(int jys, int rec_num, int fld_num)
{
	long l;

	if(HqData[jys].lpPreData[rec_num].zrsp!=0)
	{
		HqData[jys].lpRefData[rec_num].zdf=
			(HqData[jys].lpRefData[rec_num].zjjg-HqData[jys].lpPreData[rec_num].zrsp)*100/
				HqData[jys].lpPreData[rec_num].zrsp;
	}
	
	switch(fld_num)
	{
		case 0:
		return (LPSTR)&HqData[jys].lpPreData[rec_num].zqdm[0];
		case 1:
		return (LPSTR)&HqData[jys].lpPreData[rec_num].zrsp;
		case 2:
		return (LPSTR)&HqData[jys].lpPreData[rec_num].jrkp;
		case 3:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zgjg;
		case 4:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zdjg;
		case 5:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zgjm;
		case 6:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zdjm;
		case 7:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zjjg;
		case 8:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].zdf;
		case 9:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].cjss;
		case 10:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].lc;
		case 11:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].npzl;
		case 12:
			l =HqData[jys].lpRefData[rec_num].cjss
				-HqData[jys].lpRefData[rec_num].npzl;
		return (LPSTR)&l;
		case 13:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].wb;
		case 14:
		return (LPSTR)&HqData[jys].lpRefData[rec_num].cjje;
		case 15:
			HqZd =HqData[jys].lpRefData[rec_num].zjjg -
				HqData[jys].lpPreData[rec_num].zrsp;
		return (LPSTR)&HqZd;
	}
}

BOOL IsZsRec(int jys, int rec_num)
{
	if(jys ==0)
	{
		if(!strncmp(HqData[jys].lpPreData[rec_num].zqdm, "99", 2))
			return TRUE;
	}
	else
		if(!strncmp(HqData[jys].lpPreData[rec_num].zqdm, "0000", 4)
			&& (HqData[jys].lpPreData[rec_num].zqdm[4] =='0'
				||HqData[jys].lpPreData[rec_num].zqdm[4] =='1'))
			return TRUE;
	
	return FALSE;
}

void ReadHqDataAll(void)
{
	int jys, i;
	char fileName[128];
	HFILE hf;
	OFSTRUCT os;
	extern BOOL HqAllocMem(int);
	
	HQ_REF_DATA_V202 DataV202,*lpDataV202;
	
	i =250;
	if(GraphData.lpMinPos ==NULL)
		GraphData.lpMinPos =(short *)GlobalAllocPtr(GHND, i*sizeof(short));
	else
		GraphData.lpMinPos =(short *)GlobalReAllocPtr(GraphData.lpMinPos,
					i*sizeof(short), GMEM_MOVEABLE);

	if(GraphData.lpMinPos ==NULL)
	{
		GraphData.minEnd =0;
		ErrMsg(NULL,"alloc record data memory failed!");
		return;
	}
		
	if(GraphData.lpMinLc ==NULL)
		GraphData.lpMinLc =(long *)GlobalAllocPtr(GHND, i*sizeof(long));
	else
		GraphData.lpMinLc =(long *)GlobalReAllocPtr(GraphData.lpMinLc,
					i*sizeof(long), GHND);

	if(GraphData.lpMinLc ==NULL)
	{
		GraphData.minEnd =0;
		ErrMsg(NULL,"alloc record data memory failed!");
		return;
	}
		
	strcpy(fileName, szDataPath);
	strcat(fileName, "\\dpdata.dat");
	
	hf =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hf !=HFILE_ERROR)
	{
		_lread(hf, &DpData, sizeof(DpData));
		_lclose(hf);
	}

	for(jys =0; jys <2; jys++)
	{
		strcpy(fileName, szDataPath);
		if(jys ==0) strcat(fileName, "\\szhq.dat");
		else strcat(fileName, "\\shhq.dat");
	
		hf =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
		if(hf ==HFILE_ERROR) return;
		if(_lread(hf, &HqData[jys].recCount, sizeof(int)) !=sizeof(int))
		{
			_lclose(hf);
			return;
		}
		if(HqData[jys].recCount <=0)
		{
			_lclose(hf);
			continue;
		}
		if(!HqAllocMem(jys))
		{
			_lclose(hf);
			return;
		}
		if((long)HqData[jys].recCount *(sizeof(HQ_PRE_DATA)+sizeof(HQ_REF_DATA))+sizeof(int)
			==_filelength(hf))
		{	
			_lread(hf, &HqData[jys].lpPreData[0], sizeof(HQ_PRE_DATA)*HqData[jys].recCount);
			_lread(hf, &HqData[jys].lpRefData[0], sizeof(HQ_REF_DATA)*HqData[jys].recCount);
		}	
		else
		{   
		    lpDataV202 =(HQ_REF_DATA_V202 *)malloc(sizeof(HQ_REF_DATA_V202)*HqData[jys].recCount);
		    if(lpDataV202!=NULL)
		    {
		    	if((unsigned int)(_read(hf,lpDataV202,sizeof(HQ_REF_DATA_V202)*HqData[jys].recCount))!=
		    			(unsigned int)(sizeof(HQ_REF_DATA_V202)*HqData[jys].recCount))
		    	{		
		    		free(lpDataV202);
		    		lpDataV202=NULL;
		    	}		    		
		    }	
			for(i=0;i<HqData[jys].recCount;i++)
			{
			    if(lpDataV202==NULL)
			 		_read(hf,&DataV202,sizeof(HQ_REF_DATA_V202));
			 	else
			 		memcpy(&DataV202,&lpDataV202[i],sizeof(HQ_REF_DATA_V202));
			 	HqData[jys].lpRefData[i].zdjg =(float)(DataV202.zdjg/100.00);
			 	HqData[jys].lpRefData[i].zgjg =(float)((DataV202.zgjg+DataV202.zdjg)/100.00);
			 	HqData[jys].lpRefData[i].zdjm =(float)((DataV202.zdjm+DataV202.zdjg)/100.00);
			 	HqData[jys].lpRefData[i].zgjm =(float)((DataV202.zgjm+DataV202.zdjg)/100.00);
			 	HqData[jys].lpRefData[i].zjjg =(float)((DataV202.zjjg+DataV202.zdjg)/100.00);
			 	HqData[jys].lpRefData[i].npzl =DataV202.npzl;
			 	HqData[jys].lpRefData[i].cjss =DataV202.npzl+DataV202.cjss;
			 	HqData[jys].lpRefData[i].wb =(float)(DataV202.wb/100.00);
			 	
			 	HqData[jys].lpPreData[i].zrsp =(float)((DataV202.zrsp+DataV202.zdjg)/100.00);
			 	HqData[jys].lpPreData[i].jrkp =(float)((DataV202.jrkp+DataV202.zdjg)/100.00);
			 	strcpy(HqData[jys].lpPreData[i].zqdm,DataV202.zqdm);
			 	strcpy(HqData[jys].lpPreData[i].zqmc,DataV202.zqmc);			 	
			}
		    if(lpDataV202!=NULL)
				free(lpDataV202);
		}
		_lclose(hf);
	}
	strcpy(fileName, szDataPath);
	strcat(fileName, "\\maxmin.dat");
	
	hf =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hf !=HFILE_ERROR)
	{
		_lread(hf, &MaxMinData, sizeof(MaxMinData));
		_lclose(hf);
	}
}

void WriteHqDataAll(void)
{
	int jys;
	char fileName[128];
	HFILE hf;
	OFSTRUCT os;
	
	strcpy(fileName, szDataPath);
	strcat(fileName, "\\dpdata.dat");
	
	hf =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_READWRITE);
	if(hf !=HFILE_ERROR)
	{
		_lwrite(hf, &DpData, sizeof(DpData));
		_lclose(hf);
	}

	for(jys =0; jys <2; jys++)
	{
		if(HqData[jys].recCount <=0) continue;
		strcpy(fileName, szDataPath);
		if(jys ==0) strcat(fileName, "\\szhq.dat");
		else strcat(fileName, "\\shhq.dat");
	
		hf =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_READWRITE);
		if(hf ==HFILE_ERROR) return;
		if(_lwrite(hf, &HqData[jys].recCount, sizeof(int)) !=sizeof(int))
		{
			_lclose(hf);
			return;
		}
		_lwrite(hf, &HqData[jys].lpPreData[0], sizeof(HQ_PRE_DATA)*HqData[jys].recCount);
		_lwrite(hf, &HqData[jys].lpRefData[0], sizeof(HQ_REF_DATA)*HqData[jys].recCount);
		_lclose(hf);
	}
	strcpy(fileName, szDataPath);
	strcat(fileName, "\\maxmin.dat");
	
	hf =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hf ==HFILE_ERROR)
	{
		_lwrite(hf, &MaxMinData, sizeof(MaxMinData));
		_lclose(hf);
	}
}

void DelOldData(void)
{
	int jys;
	char fileName[128];
	OFSTRUCT os;
	
	strcpy(fileName, szDataPath);
	strcat(fileName, "\\dpdata.dat");
	
	unlink(fileName);

	for(jys =0; jys <2; jys++)
	{
		strcpy(fileName, szDataPath);
		if(jys ==0) strcat(fileName, "\\szhq.dat");
		else strcat(fileName, "\\shhq.dat");
	
		unlink(fileName);
	}
	strcpy(fileName, szDataPath);
	strcat(fileName, "\\maxmin.dat");	
	unlink(fileName);
	
	_lclose(hfZx);
	strcpy(fileName, szDataPath);
	strcat(fileName, "\\zx.txt");
	unlink(fileName);		
	hfZx =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_CREATE|OF_READWRITE);
	_lclose(hfZx);
	
	sprintf(fileName,"%s\\news.idx",szDataPath);
	unlink(fileName);
	
}

void ReadHqData(int jys)
{
	char fileName[128];
	HFILE hf;
	OFSTRUCT os;
	extern BOOL HqAllocMem(int);	
	HQ_REF_DATA_V202 DataV202;
	int i;
		
	strcpy(fileName, szDataPath);
	if(jys ==0) 
		strcat(fileName, "\\szhq.dat");
	else 
		strcat(fileName, "\\shhq.dat");
	
	hf =OpenFile(fileName, &os, OF_SHARE_DENY_NONE|OF_READ);
	if(hf ==HFILE_ERROR) return;
	if(_lread(hf, &HqData[jys].recCount, sizeof(int)) !=sizeof(int))
	{
		_lclose(hf);
		return;
	}
	if(HqData[jys].recCount <=0)
	{
		_lclose(hf);
		return;
	}
	if(!HqAllocMem(jys))
	{
		_lclose(hf);
		return;
	}

	if((long)HqData[jys].recCount *(sizeof(HQ_PRE_DATA)+sizeof(HQ_REF_DATA))+sizeof(int)
			==_filelength(hf))
	{
		_lread(hf, &HqData[jys].lpPreData[0], sizeof(HQ_PRE_DATA)*HqData[jys].recCount);
		_lread(hf, &HqData[jys].lpRefData[0], sizeof(HQ_REF_DATA)*HqData[jys].recCount);
	}
	else
	{
		for(i=0;i<HqData[jys].recCount;i++)
		{
			 _read(hf,&DataV202,sizeof(HQ_REF_DATA_V202));
			 HqData[jys].lpRefData[i].zdjg =(float)(DataV202.zdjg/100.00);
			 HqData[jys].lpRefData[i].zgjg =(float)(DataV202.zgjg/100.00)+HqData[jys].lpRefData[i].zdjg;
			 HqData[jys].lpRefData[i].zdjm =(float)(DataV202.zdjm/100.00)+HqData[jys].lpRefData[i].zdjg;
			 HqData[jys].lpRefData[i].zgjm =(float)(DataV202.zgjm/100.00)+HqData[jys].lpRefData[i].zdjg;
			 HqData[jys].lpRefData[i].zjjg =(float)(DataV202.zjjg/100.00)+HqData[jys].lpRefData[i].zdjg;
			 HqData[jys].lpRefData[i].npzl =DataV202.npzl;
			 
			 //HqData[jys].lpRefData[i].cjss =DataV202.npzl+DataV202.cjss;
			 HqData[jys].lpRefData[i].cjss =DataV202.cjss;
			 HqData[jys].lpRefData[i].cjje =DataV202.cjje;
			 
			 HqData[jys].lpRefData[i].wb =(float)(DataV202.wb/100.00);
			 	
			 HqData[jys].lpPreData[i].zrsp =(float)(DataV202.zrsp/100.00)+HqData[jys].lpRefData[i].zdjg;
			 HqData[jys].lpPreData[i].jrkp =(float)(DataV202.jrkp/100.00)+HqData[jys].lpRefData[i].zdjg;
			 strcpy(HqData[jys].lpPreData[i].zqdm,DataV202.zqdm);
			 strcpy(HqData[jys].lpPreData[i].zqmc,DataV202.zqmc);			 	
		}	
	}	
	_lclose(hf);	
}
