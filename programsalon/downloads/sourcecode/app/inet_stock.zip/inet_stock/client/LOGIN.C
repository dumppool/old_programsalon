#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <io.h>
#include "global.h"
#include "resource.h"
#include "appmain.h"
#include "hq.h"
#include "jy_cl.h"
#include "msg.h"

extern void UDP_Send_Exit(void);

LRESULT CALLBACK HqUserDlgProc(HWND hDlg, UINT message,
						WPARAM wParam, LPARAM lParam)
{
	char tmp[10];
	HWND hctl;
	int idFocus,xWindowExt,yWindowExt;
	PAINTSTRUCT ps;
	static int input_try_times =0, total_times_1 =0,login_time=30;
	RECT rc;
	HDC hDC;
    static HBRUSH hBrush;
    HFONT hFont;
    LOGFONT lf;
    DWORD dw;
    
	switch(message)
	{
		case WM_INITDIALOG:
			ghDlgChkUsr =ghDlgJy =hDlg;
			input_try_times =total_times_1 =0;
			hBrush=CreateSolidBrush(RGB(0,255,255));
			SendDlgItemMessage(hDlg, IDC_USER, EM_LIMITTEXT, HQ_USERID_SIZE, 0L);
			SendDlgItemMessage(hDlg, IDC_PASSWORD, EM_LIMITTEXT, HQ_USERPWD_SIZE, 0L);
			CenterWindow(hDlg);
			SetTimer(hDlg, 2, 1000, NULL);
			return TRUE;
		case WM_PAINT:
			BeginPaint(hDlg, &ps);
			DrawFrame(ps.hdc, hDlg);
			
			GetClientRect(hDlg, &rc);
			xWindowExt =rc.	right;
			yWindowExt =rc.bottom;
			SetBkMode(ps.hdc,TRANSPARENT);            
			
			memset(&lf,0,sizeof(lf));
			lf.lfWeight =FW_NORMAL;
			lf.lfQuality =PROOF_QUALITY;
			lf.lfOutPrecision = OUT_DEVICE_PRECIS;
			strcpy(lf.lfFaceName, "Termianl");
			
       		lf.lfHeight=35;       		
       		hFont =CreateFontIndirect(&lf);
       		SelectObject(ps.hdc,hFont);
       		
			SetTextColor(ps.hdc,RGB(0,0,0));
			TextOut(ps.hdc,35,10,"�� ң ��",8);
			SetTextColor(ps.hdc,RGB(255,255,255));
			TextOut(ps.hdc,34,10-1,"�� ң ��",8);

       		lf.lfHeight=16;       		
       		hFont =CreateFontIndirect(&lf);
       		SelectObject(ps.hdc,hFont);
       		
			SetTextColor(ps.hdc,RGB(0,0,0));
			TextOut(ps.hdc,150,24,"�汾��V 2.20",12);
			SetTextColor(ps.hdc,RGB(255,255,255));
			TextOut(ps.hdc,150-1,24-1,"�汾��V 2.20",12);
			
			SetTextColor(ps.hdc,RGB(0,0,0));
			TextOut(ps.hdc,150,10,"���ߣ���Ӧ��",12);
			SetTextColor(ps.hdc,RGB(255,255,255));
			TextOut(ps.hdc,150-1,10-1,"���ߣ���Ӧ��",12);

       		lf.lfHeight=16;
       		hFont =CreateFontIndirect(&lf);
       		SelectObject(ps.hdc,hFont);
       		
			SetTextColor(ps.hdc,RGB(0,0,0));
			TextOut(ps.hdc,35,(int)yWindowExt/4+15,"�û�����",8);
			SetTextColor(ps.hdc,RGB(255,255,255));
			TextOut(ps.hdc,34,(int)yWindowExt/4 -1+15,"�û�����",8);
             
			SetTextColor(ps.hdc,RGB(0,0,0));
			TextOut(ps.hdc,35,(int)yWindowExt*2/4+15,"��        ��",12);
			SetTextColor(ps.hdc,RGB(255,255,255));
			TextOut(ps.hdc,34,(int)yWindowExt*2/4-1+15,"��        ��",12);

			SetTextColor(ps.hdc,RGB(0,0,0));
			
			//TextOut(ps.hdc,35,(int)yWindowExt*3/4+15,"��ͷ��Ѷ��չ��˾������",22);
			//SetTextColor(ps.hdc,RGB(255,255,255));
			//TextOut(ps.hdc,34,(int)yWindowExt*3/4-1+15,"��ͷ��Ѷ��չ��˾������",22);

			TextOut(ps.hdc,35,(int)yWindowExt*3/4+15,"��ESC����������״̬",17);
			SetTextColor(ps.hdc,RGB(255,255,255));
			TextOut(ps.hdc,34,(int)yWindowExt*3/4-1+15,"��ESC����������״̬",17);
			
			DeleteObject(hFont);
			EndPaint(hDlg, &ps);
		break;
		
		case WM_CTLCOLOR:
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_EDIT:
					SetTextColor((HDC)wParam,RGB(0,0,0));
					SetBkColor((HDC)wParam,RGB(0,255,255));
				return (LRESULT)hBrush;
				case CTLCOLOR_MSGBOX:
					 return  (LRESULT)hBrush;
			}
		return (LRESULT)(HBRUSH)NULL;
		
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					GetDlgItemText(hDlg, IDC_USER, UserID, sizeof(UserID));
					if(UserID[0] ==0)
					{
						SetFocus(GetDlgItem(hDlg, IDC_USER));
						MessageBeep(0);
						break;
					}
					GetDlgItemText(hDlg, IDC_PASSWORD, UserPwd, sizeof(UserPwd));
					if(UserPwd[0] ==0)
					{
						SetFocus(GetDlgItem(hDlg, IDC_PASSWORD));
						MessageBeep(0);
						break;
					}
					
					hctl =GetFocus();
					idFocus =GetWindowWord(hctl, GWW_ID);
					if(idFocus ==IDC_USER)
					{
						SetFocus(GetDlgItem(hDlg, IDC_PASSWORD));
						break;
					}
					if(idFocus ==IDC_PASSWORD || UserPwd[0]!=0 && UserID[0]!=0)
					{
						Msg("��������Ч������",MSG_VERT);
						HqCheckUser(UserID, UserPwd);
						EnableWindow(LOWORD(lParam), FALSE);
					}
				break;
				case IDCANCEL:
					KillTimer(hDlg, 1);
					KillTimer(hDlg, 2);
					UDP_Send_Exit();
					gfOnLine=FALSE;
					DeleteObject(hBrush);
					EndDialog(hDlg, IDCANCEL);
					ghDlgJy =NULL;
				break;
				case 100:
					KillTimer(hDlg, 1);
					if(lParam !=LOGIN_SUCC)
					{
						if(input_try_times <3)
						{
						    if(lParam==LOGIN_NO_THIS_ID)
								ErrMsg(hDlg, "�޴��û��ţ�");
							else if(lParam==LOGIN_NO_PRIV)	
								ErrMsg(hDlg, "�û����������벻��");
							else if(lParam==LOGIN_NO_TIME)
								ErrMsg(hDlg, "����û����������ʱ��");
							else if(lParam==LOGIN_LOCKED)
								ErrMsg(hDlg, "���ѱ���������");
							else if(lParam==LOGIN_SYS_ERR)
								ErrMsg(hDlg, "����ϵͳ�������ܵ�¼");
							else if(lParam==LOGIN_ANOTHER)
								ErrMsg(hDlg, "������ͬ���û��Ž���������");							
																															
							SetDlgItemText(hDlg, IDC_USER, NULL);
							SetDlgItemText(hDlg, IDC_PASSWORD, NULL);
							hctl =GetDlgItem(hDlg, IDOK);
							EnableWindow(hctl, TRUE);
							hctl =GetDlgItem(hDlg, IDC_USER);
							SetFocus(hctl);
							input_try_times++;
							break;
						}
						else
						{
							ErrMsg(hDlg, "��¼ʧ�ܣ�ϵͳ��������״̬");
							gfOnLine=FALSE;							
							UDP_Send_Exit();
						}	
					}
					EndDialog(hDlg, IDOK);
					ghDlgJy =NULL;
			}
			break;
		case WM_TIMER:
			if(wParam==2)
			{   
			    hDC =GetDC(hDlg);
			    
			    GetClientRect(hDlg, &rc);
			    rc.right =rc.right -40;
			    rc.bottom =rc. bottom -15;				
				
				strcpy(tmp,"88");
				dw=GetTextExtent(hDC,tmp,strlen(tmp));
				
			    rc.left =rc.right -LOWORD(dw)-12;
			    rc.top = rc.bottom -HIWORD(dw);
			        
			    SelectObject(hDC,GetStockObject(WHITE_PEN));    
			    MoveTo(hDC,rc.left+1,rc.top-1);
			    LineTo(hDC,rc.right+1,rc.top-1);
			    
			    MoveTo(hDC,rc.left-1,rc.top+1);
				LineTo(hDC,rc.left-1,rc.bottom+1);			    
				
			    SelectObject(hDC,GetStockObject(BLACK_PEN));    
			    MoveTo(hDC,rc.right+1,rc.top+1);
			    LineTo(hDC,rc.right+1,rc.bottom+1);
			    
			    MoveTo(hDC,rc.left+1,rc.bottom+1);
				LineTo(hDC,rc.right+1,rc.bottom+1);			    
			    				
			    wsprintf(tmp,"%d",login_time);
			    if(login_time<10)
			    {
			    	tmp[1]=tmp[0];
			    	tmp[0]='0';
			    }
			    
			    SetBkColor(hDC,RGB(255,0,255));
			    SetTextColor(hDC,RGB(255,255,0));
			    
			    dw=GetTextExtent(hDC,tmp,strlen(tmp));
			    
			    ExtTextOut(hDC,(int)(rc.right-rc.left-LOWORD(dw))/2+rc.left, rc.top, ETO_CLIPPED|ETO_OPAQUE, &rc,tmp , 2, NULL);
				login_time--;			    
				ReleaseDC(hDlg, hDC);
				
				if(login_time==0)
					PostMessage(hDlg,WM_COMMAND,IDCANCEL,NULL);				
			}				
			break;
	}
	return FALSE;
}
