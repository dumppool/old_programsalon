#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "hq.h"
#include "hq_cl.h"
#include "lithq.h"
#include "toolbar.h"

#define LITHQ_CLASS	"CLITHQ"

extern HINSTANCE ghInstance;
extern HWND ghWndMain, ghWndLitHq;
extern BOOL ErrMsg(HWND, LPSTR);
extern BOOL IsZsRec(int jys, int rec_num);

BOOL RegisterLitHq(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	
	wc.lpfnWndProc =LitHqWndProc;
	wc.lpszClassName =LITHQ_CLASS;
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = ghInstance;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

BOOL CreateWndLitHq(HWND hWnd)
{                          
	int x ;
	HWND hwnd;
    int x0,y0,x1,y1;
	TEXTMETRIC tm;
	HDC hDC;
	RECT rc;
			
	x =GetSystemMetrics(SM_CXSCREEN);
	
	hDC =GetDC(hWnd);
	GetTextMetrics(hDC, &tm);
	ReleaseDC(hWnd, hDC);

    GetWindowRect(ghWndXlt,&rc);
    
    x0 =rc.right;
    y0 =tm.tmHeight*8+STATUS_HEIGHT +TOOLBAR_HEIGHT ;
    x1 =x*1/3-30-1;
    y1 =tm.tmHeight*6;
    if(ghWndLitHq ==NULL)
    {    
		hwnd =CreateWindow(LITHQ_CLASS, NULL, WS_CHILD|WS_CLIPSIBLINGS,
					x0, y0, x1, y1,
					hWnd, NULL, ghInstance, NULL);
						
		if(hwnd ==NULL)
		{
			ErrMsg(hWnd, "Error create lithq window");
			return FALSE;
		}
	
		ghWndLitHq =hwnd;
	}
	else
	{
		SetWindowPos(ghWndLitHq, (HWND) NULL,x0, y0, x1, y1,NULL);	
	}
	
	return TRUE;
}

LPSTR LitHqTitles[]=
{
	"����", "ƽ��", "���", "���", "���", "�Ƿ�", "����", "����", "����", "�ǵ�", NULL
};

float CalcAveJg(int jys, int recNum);
float CalcWb(void);
extern IsZsRec(int, int);
extern HFONT ghFontSmall;

extern int UDP_Send_Hq10(int, int, int, int);

LRESULT CALLBACK LitHqWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	char tmp[256];
	PAINTSTRUCT ps;
	DWORD dw;
	int i, j, k, y;
	RECT rc;
	HPEN hPen;
	static float aveJg =0;
	static int x =15;
	
	switch(message)
	{
		case WM_SETFOCUS:
			SetFocus(ghWndMain);
		break;
		case WM_READ_OK:
			if(IsZsRec(GraphData.jys, GraphData.recNum)) x =5;
			else x =15;
			aveJg =CalcAveJg(GraphData.jys, GraphData.recNum);
			InvalidateRect(hWnd, NULL, TRUE);
		break;
		case WM_SIZE:
			if(IsWindowVisible)
				InvalidateRect(hWnd,NULL,TRUE);
		break; 
		case WM_PAINT:
			GetClientRect(hWnd, &rc);
			
			BeginPaint(hWnd, &ps);
			hPen =CreatePen(PS_SOLID, 2, RGB(180, 180, 180));
			SelectObject(ps.hdc, hPen);
			SelectObject(ps.hdc, GetStockObject(NULL_BRUSH));
			Rectangle(ps.hdc, 2, 2, rc.right-2, rc.bottom-1);
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
			MoveTo(ps.hdc, rc.right, 0);
			LineTo(ps.hdc, 0, 0);
			LineTo(ps.hdc, 0, rc.bottom);
			hPen =CreatePen(PS_SOLID, 2, RGB(80, 80, 80));
			SelectObject(ps.hdc, hPen);
			LineTo(ps.hdc, rc.right-1, rc.bottom-1);
			LineTo(ps.hdc, rc.right-1, 0);
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);

			strcpy(tmp, "����");
			dw =GetTextExtent(ps.hdc, tmp, strlen(tmp));
			y =HIWORD(dw);
			
			SetBkMode(ps.hdc, TRANSPARENT);
			
			SetTextColor(ps.hdc, RGB(255, 255, 0));
			
			SetTextAlign(ps.hdc, TA_LEFT|TA_TOP);
			
			k =	GraphData.recNum;
			if(IsZsRec(GraphData.jys, k)) j =9;
			else j =10;
			for(i =0; i<j; i++)
			{
				TextOut(ps.hdc, rc.right*(i/5)/2+5-10*(i/5), 5+(y+2)*(i%5),
							LitHqTitles[i], strlen(LitHqTitles[i]));
			}
			SelectObject(ps.hdc, ghFontSmall);
			SetTextAlign(ps.hdc, TA_RIGHT|TA_TOP);
			//SetTextColor(ps.hdc, RGB(180, 0, 0));
			if(HqData[GraphData.jys].lpPreData[k].jrkp >
					HqData[GraphData.jys].lpPreData[k].zrsp)
				SetTextColor(ps.hdc, RGB(255, 0, 0));
			else if(HqData[GraphData.jys].lpPreData[k].jrkp <
					HqData[GraphData.jys].lpPreData[k].zrsp)
				SetTextColor(ps.hdc, RGB(0, 255, 0));
			else SetTextColor(ps.hdc, RGB(255, 255, 0));
			sprintf(tmp, "%.2f", HqData[GraphData.jys].lpPreData[k].jrkp);
			TextOut(ps.hdc, rc.right/2-x, 5, tmp, strlen(tmp));

			if(aveJg >HqData[GraphData.jys].lpPreData[k].zrsp)
				SetTextColor(ps.hdc, RGB(255, 0, 0));
			else if(aveJg <	HqData[GraphData.jys].lpPreData[k].zrsp)
				SetTextColor(ps.hdc, RGB(0, 255, 0));
			else SetTextColor(ps.hdc, RGB(255, 255, 0));
			sprintf(tmp, "%.2f", aveJg);
			TextOut(ps.hdc, rc.right/2-x, 5+(y+2), tmp, strlen(tmp));
			
			if(HqData[GraphData.jys].lpRefData[k].zgjg >
					HqData[GraphData.jys].lpPreData[k].zrsp)
				SetTextColor(ps.hdc, RGB(255, 0, 0));
			else if(HqData[GraphData.jys].lpRefData[k].zgjg <
					HqData[GraphData.jys].lpPreData[k].zrsp)
				SetTextColor(ps.hdc, RGB(0, 255, 0));
			else SetTextColor(ps.hdc, RGB(255, 255, 0));
			sprintf(tmp, "%.2f", HqData[GraphData.jys].lpRefData[k].zgjg);
			TextOut(ps.hdc, rc.right/2-x, 5+(y+2)*2, tmp, strlen(tmp));
			
			if(HqData[GraphData.jys].lpRefData[k].zdjg >
					HqData[GraphData.jys].lpPreData[k].zrsp)
				SetTextColor(ps.hdc, RGB(255, 0, 0));
			else if(HqData[GraphData.jys].lpRefData[k].zdjg <
					HqData[GraphData.jys].lpPreData[k].zrsp)
				SetTextColor(ps.hdc, RGB(0, 255, 0));
			else SetTextColor(ps.hdc, RGB(255, 255, 0));
			sprintf(tmp, "%.2f", HqData[GraphData.jys].lpRefData[k].zdjg);
			TextOut(ps.hdc, rc.right/2-x, 5+(y+2)*3, tmp, strlen(tmp));
			
			if(HqData[GraphData.jys].lpRefData[k].zjjg >
					HqData[GraphData.jys].lpPreData[k].zrsp)
				SetTextColor(ps.hdc, RGB(255, 0, 0));
			else if(HqData[GraphData.jys].lpRefData[k].zjjg <
					HqData[GraphData.jys].lpPreData[k].zrsp)
				SetTextColor(ps.hdc, RGB(0, 255, 0));
			else SetTextColor(ps.hdc, RGB(255, 255, 0));
			sprintf(tmp, "%.2f", HqData[GraphData.jys].lpRefData[k].zjjg);
			TextOut(ps.hdc, rc.right/2-x, 5+(y+2)*4, tmp, strlen(tmp));
			
			sprintf(tmp, "%.2f", HqData[GraphData.jys].lpRefData[k].zdf);
			TextOut(ps.hdc, rc.right-5, 5, tmp, strlen(tmp));		
			
			SetTextColor(ps.hdc, RGB(0, 255, 255));
			sprintf(tmp, "%ld", HqData[GraphData.jys].lpRefData[k].cjss);
			TextOut(ps.hdc, rc.right-5, 5+(y+2)*1, tmp, strlen(tmp));		
			
			sprintf(tmp, "%ld", HqData[GraphData.jys].lpRefData[k].npzl);
			TextOut(ps.hdc, rc.right-5, 5+(y+2)*2, tmp, strlen(tmp));		
			sprintf(tmp, "%ld", HqData[GraphData.jys].lpRefData[k].cjss
							-HqData[GraphData.jys].lpRefData[k].npzl);
			TextOut(ps.hdc, rc.right-5, 5+(y+2)*3, tmp, strlen(tmp));		
			if(j ==10)
			{
				sprintf(tmp, "%.2f", HqData[GraphData.jys].lpRefData[k].zjjg -
					HqData[GraphData.jys].lpPreData[k].zrsp);
				TextOut(ps.hdc, rc.right-5, 5+(y+2)*4, tmp, strlen(tmp));		
			}
			EndPaint(hWnd, &ps);
		break;
		
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

float CalcAveJg(int jys, int recNum)
{
	int i;
	double jg;
	
	if(GraphData.minEnd <=0)
		return HqData[jys].lpRefData[recNum].zjjg;
	jg =0;
	for(i =0; i<GraphData.minEnd; i++)
		jg+=GraphData.lpGraData[0].zjjg;
	
	jg /=GraphData.minEnd;
	jg +=HqData[jys].lpPreData[recNum].zrsp;
	
	return (float)jg;
}

float CalcWb(void)
{
	int i;
	double slSell =0, slBuy =0;
	
	for(i =0; i<3; i++)
		slSell +=(double)MmpData.slSell[i];
	for(i =0; i<3; i++)
		slBuy +=(double)MmpData.slBuy[i];
		
	if(slSell +slBuy ==0) return 0;
	
	return (float)((slBuy-slSell)/(slSell+slBuy));
}
