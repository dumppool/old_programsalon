
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <malloc.h>
#include "hq.h"
#include "pctcp.h"

int sdHq =-1, sdJy =-1;

#define WSA_MAKEWORD(x,y)       ((y) * 256 + (x))

BOOL running =FALSE, run_cancelled =FALSE;
int PROTO_USE =PROTO_UDP;
char  * ReadBuf;	//[MAX_READ_BUF_SIZE+1];  
BOOL can_read =TRUE, can_write =FALSE;
BOOL fSockError =FALSE;
char HostName[40];

LPSTR GetError(LPSTR err_prefix);

FILE *fp =NULL;

int CalcTime(int jys);
int StringSub(LPSTR lpstr1, LPSTR lpstr2, LPSTR lpres, int s_type);
int CompString(LPSTR, LPSTR);
int     GMinRecalcJgMax(void);
int     GMinRecalcLcMax(void);
int MaxMinChangeHqData(int jys, int maxmin);
void SetStatusText(LPSTR);
int UDPBlockingHook (void);

extern BOOL GetInitString(LPSTR, LPSTR, LPSTR);
extern BOOL PutInitString(LPSTR, LPSTR, LPSTR);
extern BOOL ErrMsg(HWND, LPSTR);
extern HWND ghWndMain, ghWndHq, ghWndStatus, ghWndCj;
extern HINSTANCE ghInstance;
extern HWND ghWndXlt, ghWndJlt, ghWndMaxMin;
extern HWND ghDlgJy;

void WriteMsg(LPSTR msg)
{                
	if(fp) fputs(msg, fp);
}

int PCTCPInit(void)
{
	char temp[40];
	//WORD VersionReqd;        
	WSADATA myWSAData;
    int ret;
    
	//VersionReqd=WSA_MAKEWORD(MAJOR_VERSION, MINOR_VERSION);

	if(!GetInitString("NET", "HOST", HostName))
	{
		//strcpy(HostName, "172.20.16.68     ");   //��ͷ 
		//strcpy(HostName, "10.17.128.188     ");   //ʯ��ׯ
		//strcpy(HostName, "172.21.112.99    ");   //÷�� 
		//strcpy(HostName, "10.62.171.68     ");   //��ɳ
		//strcpy(HostName, "10.190.2.103     ");   //����
		strcpy(HostName, "10.29.15.3     ");   //����
		//strcpy(HostName, "10.157.2.6     ");   //���� 
		//strcpy(HostName, "10.19.160.30     ");   //��̨
		PutInitString("NET", "HOST", HostName);
	}
	
	ReadBuf =(char *)_fmalloc(MAX_READ_BUF_SIZE+1);
	
	ret = WSAStartup(0x0101, &myWSAData);
	    
	sdHq =sdJy =-1;
	if (ret != 0)
		return -1;
	
	if(GetInitString("NET", "PROTO", temp))
	{
		if(temp[0] =='U') PROTO_USE =PROTO_UDP;
		else PROTO_USE=PROTO_TCP;
	}
	else 
	{
		PutInitString("NET", "PROTO", "TCP");      
		PROTO_USE=PROTO_TCP;	                            
	}
	                            
	return 0;
}

int PCTCPClose(void)
{
	int ret;

	run_cancelled =TRUE;
	
	//WSACancelBlockingCall();
	if(sdHq !=-1)
	{
		closesocket(sdHq);
		sdHq =-1;
    }
	if(sdJy !=-1)
	{
		closesocket(sdJy);
		sdJy =-1;
    }
	
	ret = WSACleanup();
	if (ret == SOCKET_ERROR && h_errno == WSAEINPROGRESS)
	{
		//ErrMsg(NULL, "Data transfer in progress.\nStop transfer first.");
		return -1;
	}
	
	if(fp) fclose(fp);
	
	return 0;
}
		
int PCTCPExit(void)
{
	static BOOL fExit =FALSE;
	
	_ffree(ReadBuf);
	if(fExit ==TRUE) return 0;
	fExit =TRUE;            
	
	PCTCPClose();
	
	if(fp) fclose(fp);
	
	return 0;
}

// used for client
int ConnectHost(int type, int protoUse)
{
	LPSTR lpHostName;
	struct  hostent FAR *hp;
	struct  sockaddr_in server_addr;
	SOCKET  hSock;
	int iSockType,ret;
	//long lret;
	time_t time_start, time_end;
	
	lpHostName =&HostName[0];

	if(protoUse ==-1) protoUse =PROTO_USE;
	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_addr.s_addr =/*INADDR_BROADCAST;//ANY;*/(u_long)inet_addr(lpHostName);
	
	if (server_addr.sin_addr.s_addr == (u_long) -1L || 
		server_addr.sin_addr.s_addr == 0) 
	{
		if ((hp = gethostbyname(lpHostName)) == NULL) 
		{
			//ErrMsg(NULL, "rpcinfo: server address is unknown");
			return -1;
		}
		_fmemcpy((char *)&server_addr.sin_addr, hp->h_addr, hp->h_length);
	}
	server_addr.sin_family = PF_INET;
	if (protoUse == PROTO_TCP)
		iSockType = SOCK_STREAM;
	else
		iSockType = SOCK_DGRAM;
    
	if(type !=1)
	{
		if(sdHq !=-1) closesocket(sdHq);
		
		server_addr.sin_port = htons(PORT_HQ);
    
		hSock = socket(PF_INET, iSockType, 0);
		if (hSock == INVALID_SOCKET)
			return -1;
    
		ret =WSAAsyncSelect(hSock, ghWndMain, WM_USER+1, FD_READ);//|FD_CONNECT);		
		if(ret <0)
		{
			closesocket(hSock);
			return -1;
		}
	
		time(&time_start);
		
retry_hq_connect:
		time(&time_end);
		if(difftime(time_end, time_start) >10)
		{
			closesocket(hSock);
			return (SOCKET) -1;
		}
		ret=connect(hSock,(struct sockaddr FAR *)&server_addr,sizeof(server_addr));
    
		if (ret == SOCKET_ERROR) {
			if (h_errno == WSAEWOULDBLOCK)
				goto retry_hq_connect;
		}                            
		sdHq =hSock;
	}

	return hSock;
}

int BeginConnect(char *host)
{
	LPSTR lpHostName;
	struct  hostent FAR *hp;
	struct  sockaddr_in server_addr;
	SOCKET  hSock;
	int iSockType,ret;
	
	lpHostName =host;

	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_addr.s_addr =(u_long)inet_addr(lpHostName);
	
	if (server_addr.sin_addr.s_addr == (u_long) -1L || 
		server_addr.sin_addr.s_addr == 0) 
	{
		if ((hp = gethostbyname(lpHostName)) == NULL) 
			return -1;
		_fmemcpy((char *)&server_addr.sin_addr, hp->h_addr, hp->h_length);
	}
	server_addr.sin_family = PF_INET;
	iSockType = SOCK_STREAM;
    
	if(sdHq !=-1) closesocket(sdHq);
		
	server_addr.sin_port = htons(PORT_HQ);
    
	hSock = socket(PF_INET, iSockType, 0);
	if (hSock == INVALID_SOCKET)
		return -1;
    
	ret =WSAAsyncSelect(hSock, ghWndMain, WM_USER+1, FD_READ|FD_CONNECT);
	if(ret <0)
	{
		closesocket(hSock);
		return -1;
	}
	
		
	ret=connect(hSock,(struct sockaddr FAR *)&server_addr,sizeof(server_addr));
	if (ret == SOCKET_ERROR) 
	{
		if (h_errno != WSAEWOULDBLOCK)
			return -1;
	}                            
	sdHq =hSock;
	return hSock;
}


int ConnectToJyHost(char *HostName)
{
	LPSTR lpHostName;
	struct  hostent FAR *hp;
	struct  sockaddr_in server_addr;
    int hSock,iSockType,ret;
	
	if(sdJy !=-1)
	{
		closesocket(sdJy);
		sdJy =-1;
	}
	lpHostName =&HostName[0];

	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_addr.s_addr =(u_long)inet_addr(lpHostName);
	
	if (server_addr.sin_addr.s_addr == (u_long) -1L || 
		server_addr.sin_addr.s_addr == 0) 
	{
		if ((hp = gethostbyname(lpHostName)) == NULL) 
		{
			ErrMsg(NULL, "rpcinfo: server address is unknown");
			return -1;
		}
		_fmemcpy((char *)&server_addr.sin_addr, hp->h_addr, hp->h_length);
	}
	server_addr.sin_family = PF_INET;
	iSockType = SOCK_STREAM;
    
	server_addr.sin_port = htons((u_int) PORT_JY);
    
	hSock = socket(PF_INET, iSockType, 0);
	if (hSock == INVALID_SOCKET)
	{
		ErrMsg(NULL, "socket() failed");
		return (SOCKET) -1;
	}
	
	ret =WSAAsyncSelect(hSock, ghWndMain, WM_USER+2, FD_READ|FD_CONNECT);
	if(ret <0)
	{
		closesocket(hSock);
		return -1;
	}
    ret=connect(hSock,(struct sockaddr FAR *)&server_addr,sizeof(server_addr));
	if (ret == SOCKET_ERROR)
	{
		ret =WSAGetLastError();
		if(ret ==WSAEWOULDBLOCK)
			ret =0;
		else
		{			
			closesocket(hSock);
			return ret;
		}
	}
	
	sdJy =hSock;
	
	return ret;
}

int PCTCPStop(void)
{
	run_cancelled =TRUE;
	can_read =FALSE;
	
	return 0;
}

void PCTCPPause(BOOL fPause)
{
	can_read =!fPause;
}                  

int UDPBlockingHook (void)
{
	MSG msg;

	//run_cancelled =FALSE;
	if(run_cancelled ==TRUE) return FALSE;
	if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
	{
		TranslateMessage(&msg);
		 DispatchMessage(&msg);   
		if(msg.message ==WM_QUIT)
		{
		       PostQuitMessage(0);
		       run_cancelled =TRUE;               
		       WSASetLastError(WSAEINTR);
		       return FALSE;
		}
		//WriteMsg("message\n");
		return TRUE;
	}
	return FALSE;
}

int PASCAL FAR WSAsperror(int errorcode, char far * buf, int len)
{
	int err_len;
    
	if (errorcode == 0)
		errorcode = WSABASEERR;
	if (errorcode < WSABASEERR)
		return 0;
	    
	err_len = LoadString(ghInstance,errorcode,buf,len);
	
	return err_len;
	
}

LPSTR GetError(LPSTR err_prefix)
{
	int wsa_err;
	char errbuf[1000];
	char prbuf[1000];
	
	wsa_err =WSAGetLastError(); 
	
	WSAsperror(wsa_err, (LPSTR)errbuf, sizeof(errbuf));
	    
	wsprintf((LPSTR)prbuf, "%s:\n%s", (LPSTR) err_prefix, (LPSTR)errbuf);
	
	return &prbuf[0];  
}

int check_socket_status(int sd)
{
	struct timeval wait;
	fd_set send_ready,except;

	wait.tv_sec =wait.tv_usec=0;
	FD_ZERO(&send_ready);
	FD_ZERO(&except);
	FD_SET(sd,&send_ready);
	FD_SET(sd,&except);
	if(select(FD_SETSIZE,(fd_set *)0,&send_ready,
			&except,&wait)<0)
		return(-1);
	if(FD_ISSET(sd,&send_ready))
		return(0);
	else if(FD_ISSET(sd,&except))
		return(-2);
	else
		return(-3);
}

void SetStatusText(LPSTR tmp)
{                 
	HDC hDC;
	
	hDC =GetDC(NULL);
	SetBkColor(hDC, RGB(255, 0, 255));
	SetBkMode(hDC, TRANSPARENT);
	TextOut(hDC, 10, 2, tmp, strlen(tmp));
	ReleaseDC(NULL, hDC);
}

