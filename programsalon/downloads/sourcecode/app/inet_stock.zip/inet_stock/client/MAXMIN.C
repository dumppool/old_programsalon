#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "hq.h"
#include "hq_cl.h"
#include "maxmin.h"
#include "toolbar.h"
#include "appmain.h"

#define MAXMIN_CLASS	"CMAXMIN"

extern HINSTANCE ghInstance;
extern HWND ghWndMain, ghWndMaxMin;
extern BOOL ErrMsg(HWND, LPSTR);
extern BOOL IsZsRec(int jys, int rec_num);

BOOL RegisterMaxMin(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	
	wc.lpfnWndProc =MaxMinWndProc;
	wc.lpszClassName =MAXMIN_CLASS;
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = ghInstance;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

BOOL CreateWndMaxMin(HWND hWnd)
{                          
	int x, y;
	HWND hwnd;
	int x0,y0,x1,y1;
	HDC hDC;
	TEXTMETRIC tm;
	RECT rc,rc1;	
	
	x =GetSystemMetrics(SM_CXSCREEN);
	GetClientRect(ghWndMain,&rc);
	y =rc.bottom -rc.top;
	
	hDC =GetDC(hWnd);
	GetTextMetrics(hDC, &tm);
	ReleaseDC(hWnd, hDC);
	
	GetWindowRect(ghWndXlt,&rc1);
    x0 =rc1.right;
    y0 =tm.tmHeight*14+STATUS_HEIGHT +TOOLBAR_HEIGHT+2;
    x1 =x*1/3-30-1;
    
    y1 =rc.bottom -STATUS_HEIGHT-y0-MSG_HEIGHT;
    
    if(y1 <tm.tmHeight*2) y1 =tm.tmHeight*2;
    
	if(ghWndMaxMin==NULL)
	{					
		hwnd =CreateWindow(MAXMIN_CLASS, NULL, WS_CHILD|WS_CLIPSIBLINGS,
					x0, y0, x1, y1,
					hWnd, NULL, ghInstance, NULL);
						
		if(hwnd ==NULL)
		{
			ErrMsg(hWnd, "Error create maxmin window");
			return FALSE;	
		}
		ghWndMaxMin =hwnd;
	}
	else
	{
		SetWindowPos(ghWndMaxMin, (HWND) NULL,x0, y0, x1, y1,NULL);
	}
	
	return TRUE;
}

LPSTR MaxMinCaptions[]=
{
	"�Ƿ����","�ǵ����","�������","������",
	"�Ƿ����","�ǵ����","�������","������"
};

LPSTR MaxMinTitles[]=
{
	"����", "���", "�Ƿ�", "����", NULL
};

extern HFONT ghFontSmall;

LRESULT CALLBACK MaxMinWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	char tmp[256];
	PAINTSTRUCT ps;
	DWORD dw;
	int i, x, y;
	RECT rc;
	HPEN hPen;
	static int maxmin =0;
	static int maxmin_num =0;
	TEXTMETRIC tm;
		
	switch(message)
	{
		case WM_SETFOCUS:
			SetFocus(ghWndMain);
		break;
		case WM_CREATE:
		break;
		
		case WM_READ_OK:
			InvalidateRect(hWnd, NULL, TRUE);
		break;
		case WM_SIZE:
			if(IsWindowVisible(hWnd))
				InvalidateRect(hWnd, NULL, TRUE);
		break;
		case WM_KEYDOWN:
			switch(wParam)
			{
				case VK_UP:
					maxmin_num--;
					if(maxmin_num <0)
					{
						maxmin =(maxmin+1)%2;
						maxmin_num =3;
					}
				break;
				case VK_DOWN:
					maxmin_num++;
					if(maxmin_num >3)
					{
						maxmin =(maxmin+1)%2;
						maxmin_num =0;
					}
				break;
				default:
				return 0L;
			}
			InvalidateRect(hWnd, NULL, TRUE);
		break;
		
		case WM_PAINT:
			BeginPaint(hWnd, &ps);
			GetClientRect(hWnd, &rc);
			GetTextMetrics(ps.hdc, &tm);
			hPen =CreatePen(PS_SOLID, 2, RGB(180, 180, 180));
			SelectObject(ps.hdc, hPen);
			SelectObject(ps.hdc, GetStockObject(NULL_BRUSH));
			Rectangle(ps.hdc, 2, 2, rc.right-2, rc.bottom-1);
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
			MoveTo(ps.hdc, rc.right, 0);
			LineTo(ps.hdc, 0, 0);
			LineTo(ps.hdc, 0, rc.bottom);
			hPen =CreatePen(PS_SOLID, 2, RGB(80, 80, 80));
			SelectObject(ps.hdc, hPen);
			LineTo(ps.hdc, rc.right-1, rc.bottom-1);
			LineTo(ps.hdc, rc.right-1, 0);
			SelectObject(ps.hdc, GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
			
			strcpy(tmp, MaxMinCaptions[maxmin*4+maxmin_num]);
			dw =GetTextExtent(ps.hdc, tmp, strlen(tmp));
			x =LOWORD(dw)/strlen(tmp); y =HIWORD(dw);
			
			SetTextColor(ps.hdc, RGB(0, 255, 255));
			SetBkMode(ps.hdc, TRANSPARENT);
			SetTextAlign(ps.hdc, TA_CENTER|TA_TOP);
			TextOut(ps.hdc, rc.right/2, 3, tmp, strlen(tmp));
			
			SetTextColor(ps.hdc, RGB(255, 255, 255));
			SetTextAlign(ps.hdc, TA_LEFT|TA_TOP);
			TextOut(ps.hdc, 5+x, y+2, MaxMinTitles[0], strlen(MaxMinTitles[0]));
			TextOut(ps.hdc, 5+x*6+5, y+2,
						MaxMinTitles[1], strlen(MaxMinTitles[1]));
			TextOut(ps.hdc, 5+x*12, y+2,
						MaxMinTitles[2], strlen(MaxMinTitles[2]));
			SetTextAlign(ps.hdc, TA_RIGHT|TA_TOP);
			TextOut(ps.hdc, rc.right-5, y+2,
						MaxMinTitles[3], strlen(MaxMinTitles[3]));
			
			if(maxmin >=0)
			{
				SelectObject(ps.hdc, ghFontSmall);
				for(i =0; i<10; i++)
				{	                
				    if(MaxMinData[GraphData.jys][maxmin].MaxMin[maxmin_num][i].zjjg==0)
				    	break;
					SetTextColor(ps.hdc, RGB(255, 0, 255));
					SetTextAlign(ps.hdc, TA_LEFT|TA_TOP);
					if(2+(y+1)*(i+2) +tm.tmHeight >rc.bottom)
						break;
					TextOut(ps.hdc, 5, 2+(y+1)*(i+2), HqData[GraphData.jys].lpPreData[
							MaxMinData[GraphData.jys][maxmin].recNum[maxmin_num][i]].zqmc,
							strlen(HqData[GraphData.jys].lpPreData[
							MaxMinData[GraphData.jys][maxmin].recNum[maxmin_num][i]].zqmc));
					SetTextColor(ps.hdc, RGB(255, 255, 0));
					sprintf(tmp, "%.2f", MaxMinData[GraphData.jys][maxmin].MaxMin[maxmin_num][i].zjjg);
					TextOut(ps.hdc, 5+x*6+5, 2+(y+1)*(i+2), tmp, strlen(tmp));
				
					SetTextColor(ps.hdc, RGB(0, 180, 0));
					sprintf(tmp, "%.2f", MaxMinData[GraphData.jys][maxmin].MaxMin[maxmin_num][i].zdf);
					TextOut(ps.hdc, 5+x*12, 2+(y+1)*(i+2), tmp, strlen(tmp));
				
					SetTextAlign(ps.hdc, TA_RIGHT|TA_TOP);
					SetTextColor(ps.hdc, RGB(0, 180, 180));
					sprintf(tmp, "%ld", MaxMinData[GraphData.jys][maxmin].MaxMin[maxmin_num][i].cjss);
					TextOut(ps.hdc, rc.right-5, 2+(y+1)*(i+2), tmp, strlen(tmp));
				}
			}
			EndPaint(hWnd, &ps);
		break;
		case WM_DESTROY:
		break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}
