#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <io.h>
#include "global.h"
#include "resource.h"
#include "appmain.h"
#include "hq.h"
#include "hq_cl.h"

#include "comm.h"

extern void CenterWindow(HWND hDlg);
extern void DrawFrame(HDC hDC, HWND hWnd);

int PreComm(char *comm)
{
	char buff[255];
	int i=0,dot=0,j=0;
	BOOL digital=FALSE,alpha=FALSE;
	
	j=strlen(comm);           
	if(j==0) return NULL_COMM;
	if(j>=255) comm[255]=0;

	while(comm[i]==' '&&comm[i]!=0) i++;	
    if(comm[i]==0) return NULL_COMM;
    
    strcpy(buff,&comm[i]);
    _strlwr(buff);
    for(i=0,j=0;buff[i]!=0;i++)
    {
    	if(buff[i]!=' ')
    	{
    		if(buff[i]>='0'&&buff[i]<='9')
    			digital =TRUE;
    		if(buff[i]>='a'&&buff[i]<='z')
    			alpha =TRUE;
    		if(buff[i]=='.')
    			dot++;
    		comm[j++] =buff[i];
    	}
    }
    comm[j]=0;
    if(!alpha)
    {
    	if(digital&&dot==3) 
    		return IP_CONN_COMM;
    	if(digital&&dot==0&&strlen(comm)==2)
    		return OP_CODE_COMM; 
    	if(digital&&dot==0&&strlen(comm)>2)
    		return GP_CODE_COMM;
    }
    else
    {   
    	if(strlen(comm)<2)
    		return BAD_COMM;
    	if(dot ==0)
        	return PY_NAME_COMM;
        else return BAD_COMM;
    }    
}

void PreStockName(char *name)
{
	char buff[255],*ptr;
	int i,j,len;
	
	len =strlen(name);
	if(len>=255) len =255;
	
	if((ptr =strstr(name,"��"))!=NULL)
	{
		*ptr++ ='a';
		*ptr =' ';
	}
	if((ptr =strstr(name,"��"))!=NULL)
	{
		*ptr++ ='b';
		*ptr =' ';
	}
	if((ptr =strstr(name,"��"))!=NULL)
	{
		*ptr++ ='c';
		*ptr =' ';
	}
	
	for(i=0,j=0;i<len;i++)
	{
		if(name[i]!=' ')
		{
			buff[j++]=name[i];
		}
	}
	buff[j]=0;
	_strlwr(buff);
	strcpy(name,buff);
}   

BOOL IsPyOk(char *py,char *name)
{
    int j;
    unsigned int ofset=0,num =0,k,l;
    
	for(j=0,l=0;py[j]!=0;j++)
	{							
		if(name[l]==0) return FALSE;
		if((unsigned int)name[l]<128||py[j]<'a'||py[j]>'z')
		{
			if(name[l]!=py[j])
				return FALSE;
			else l++;	
		}
		else
		{
			ofset =*(unsigned int *)&winpy[(py[j]-'a')*sizeof(unsigned int)*2];
			num =*(unsigned int *)&winpy[(py[j]-'a')*sizeof(unsigned int)*2+2];
			ofset =ofset*2+26*4;
		
			for(k=0;k<num;k++)
			{
				if(!strncmp(&name[l],&winpy[ofset+k*2],2))
					break;
			}
			if(k>=num)
				return FALSE;
			else l+=2;
		}
	}
    return TRUE;
}


LRESULT CALLBACK SelGpDlgProc(HWND hDlg, UINT msg,
					WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
//	LPDRAWITEMSTRUCT lpdis;
    char temp[20];
    int i;
	static HBRUSH 	hBrush;
	HWND hctl; 	
	DWORD dw;
			
	switch(msg)
	{
		case WM_INITDIALOG:
			CenterWindow(hDlg);
			hBrush=CreateSolidBrush(RGB(0,255,255));			

			for(i=0;i<MAX_SELE_NUM&&SeleGp[i][0]!=-1;i++)
			{
				SendDlgItemMessage(hDlg, IDC_LIST_GP, LB_ADDSTRING, 0,
					(LPARAM)(LPSTR)HqData[SeleGp[i][0]].lpPreData[SeleGp[i][1]].zqmc);
			}			
			if(i>0)
				SendDlgItemMessage(hDlg, IDC_LIST_GP, LB_SETCURSEL,(WPARAM)0L,
					(LPARAM)(LPSTR)0L);			 
			return TRUE;
		case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			switch(HIWORD(lParam))
			{
				case CTLCOLOR_DLG:
				case CTLCOLOR_MSGBOX:
				case CTLCOLOR_STATIC:	
					return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
				case CTLCOLOR_LISTBOX:
					return (LRESULT)hBrush;	
			}
		return (LRESULT)NULL;
/*        
		case WM_DRAWITEM:
			lpdis = (LPDRAWITEMSTRUCT)lParam;

			if (lpdis->itemID == -1)
				BtnFocusState(lpdis);
			else
			{
				switch (lpdis->itemAction)
				{
					case ODA_DRAWENTIRE: 
						BtnDrawEntireItem(lpdis);
					break;

					case ODA_SELECT:
						BtnSelectionState(lpdis);
					break;

					case ODA_FOCUS:
						BtnFocusState(lpdis);
					break;
				}
			}
		break;
*/
		case WM_PAINT:
			BeginPaint(hDlg, &ps);			
			DrawFrame(ps.hdc, hDlg);			
			hctl =GetDlgItem(hDlg, IDC_LIST_GP);
			SetFocus(hctl);
			EndPaint(hDlg, &ps);
		break;
		
		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					dw =SendDlgItemMessage(hDlg,IDC_LIST_GP,LB_GETCURSEL, 0 , 0);
					if(dw!=LB_ERR)
					{
						SendDlgItemMessage(hDlg,IDC_LIST_GP,LB_GETTEXT,(WPARAM)dw,(LPARAM)(LPSTR)temp);
						DeleteObject(hBrush);
//						ghDlgJy =NULL;						
						EndDialog(hDlg,(int)dw);
					}	
					else 
					{
						DeleteObject(hBrush);
						EndDialog(hDlg, -1);
					}
				break;	
				case IDCANCEL:    
					DeleteObject(hBrush);
					EndDialog(hDlg, -1);
				break;
			}
		break;
	}
	
	return FALSE;	
}


int DlgSelectGp(void)
{
	int gp =0;
	FARPROC lpDlgProc =NULL;
	
	lpDlgProc =MakeProcInstance((FARPROC)SelGpDlgProc, ghInstance);
	gp =DialogBox(ghInstance, MAKEINTRESOURCE(IDD_GP_SELE), ghWndMain,
				lpDlgProc);
	FreeProcInstance(lpDlgProc);
	
    return(gp);
}
