#include <windows.h>
#include <string.h>
#include <time.h>
#include <winsock.h>
#include "pctcp.h"
#include "hq.h"
#include "jy_cl.h"
#include "caption.h"
#include "des.h"
#include "rsa.h"
#include "msg.h"

BOOL udpread_stop =TRUE;
extern BOOL gfOnLine,gfConnecting;

extern JY_ANS_CHKUSR ChkUsrRes;
extern ZQSXX Qsxx;

extern BOOL ErrMsg(HWND, LPSTR);
extern HWND ghWndMain, ghDlgJy;
extern BOOL run_cancelled;
extern int sdJy;    

extern BOOL IsSzRead,IsShRead;

char  *JyReadBuf;	//[MAX_READ_BUF_SIZE+1];  
uchar DesKey[9];
	
int UDP_Client_ReadJy(void);
extern LPSTR GetError(LPSTR);

LPVOID lpCurJyData =NULL, lpCurJyRes =NULL, lpCurJyHead =NULL;
int curJyDataSize =0, curJyHead =0, curJyResSize =0;
BOOL fIsJyCx =FALSE;

HINSTANCE hDesDll=NULL;
lpfnDES_INIT far pascal desinit=NULL;
lpfnDES_ECB far pascal ecbencode=NULL;

int UDP_Client_JySend(LPSTR, LPVOID, int, LPVOID, int);

int UDP_Jy_ChkUsr(LPJY_ASK_CHKUSR lpChkUsrData, LPJY_ANS_CHKUSR lpChkUsrRes)
{
	fIsJyCx =FALSE;
	return UDP_Client_JySend(JY_CHKUSR_HEAD, lpChkUsrData, sizeof(JY_ASK_CHKUSR),
			lpChkUsrRes, sizeof(JY_ANS_CHKUSR));
}

int UDP_Jy_ChgPwd(LPJY_ASK_CHGPWD lpChgPwdData, LPJY_ANS_CHGPWD lpChgPwdRes)
{
	fIsJyCx =FALSE;
	return UDP_Client_JySend(JY_CHGPWD_HEAD, lpChgPwdData, sizeof(JY_ASK_CHGPWD),
			lpChgPwdRes, sizeof(JY_ANS_CHGPWD));
}

int UDP_Jy_BuySell(LPJY_ASK_BUYSELL lpBuySellData, LPJY_ANS_BUYSELL lpBuySellRes)
{
	fIsJyCx =FALSE;
	return UDP_Client_JySend(JY_BUYSELL_HEAD, lpBuySellData, sizeof(JY_ASK_BUYSELL),
			lpBuySellRes, sizeof(JY_ANS_BUYSELL));
}

int UDP_Jy_Cancel(LPJY_ASK_CANCEL lpCancelData, LPJY_ANS_CANCEL lpCancelRes)
{
	fIsJyCx =FALSE;
	return UDP_Client_JySend(JY_CANCEL_HEAD, lpCancelData, sizeof(JY_ASK_CANCEL),
			lpCancelRes, sizeof(JY_ANS_CANCEL));
}

int UDP_Jy_Wtcx(LPJY_ASK_WTCX lpWtcxData, LPJY_ANS_WTCX lpWtcxRes)
{
	fIsJyCx =TRUE;
	return UDP_Client_JySend(JY_WTCX_HEAD, lpWtcxData, sizeof(JY_ASK_WTCX),
			(LPVOID)lpWtcxRes, sizeof(JY_ANS_WTCX));
}

int UDP_Jy_Cjcx(LPJY_ASK_CJCX lpCjcxData, LPJY_ANS_CJCX lpCjcxRes)
{
	fIsJyCx =TRUE;
	return UDP_Client_JySend(JY_CJCX_HEAD, (LPVOID)lpCjcxData, sizeof(JY_ASK_CJCX),
			(LPVOID)lpCjcxRes, sizeof(JY_ANS_CJCX));
}

int UDP_Jy_Yecx(LPJY_ASK_YECX lpYecxData, LPJY_ANS_YECX lpYecxRes)
{
	fIsJyCx =TRUE;
	return UDP_Client_JySend(JY_YECX_HEAD, (LPVOID)lpYecxData, sizeof(JY_ASK_YECX),
			lpYecxRes, sizeof(JY_ANS_YECX));
}

char en[43]={'A','=','U','X','Z','E','R','P','4','W','5','S','Q','B','7','O',
	     '<','1','V','Y','?','0','L','N','T','@','6','F','C','9','D','G',
	 '>',';','H','3','J','K',':','2','I','M','8'};

int gn_jy_num =0;
#define 	DATA_START_SIGN -16

int UDP_Client_JySend(LPSTR lpHead, LPVOID lpData, int DataSize, LPVOID lpRes, int ResSize)
{
	int len,i= 0,x,tlen;
	char JyWriteBuf[MAX_WRITE_BUF_SIZE+1],temp[100];
    static uchar * b;
    
	if(HqTime[*(char *)lpData].fRunning ==FALSE)
	{
		ErrMsg(ghDlgJy, "�Ѿ�����!");
		return 0;
	}
	
	if(!gfOnLine||gfConnecting) return 0;		
	
	udpread_stop =FALSE;

	lpCurJyData =NULL;
	lpCurJyRes =NULL;
	lpCurJyHead =NULL;
	curJyDataSize =0;
	curJyResSize =0;
	 
	memset(&JyWriteBuf[0], 0,sizeof(JyWriteBuf));
	JyWriteBuf[0]=DATA_START_SIGN;
	len=1+sizeof(int);
	
	strcpy(&JyWriteBuf[len], lpHead);
	len += strlen(lpHead);
	
	gn_jy_num ++;
	*(short *)&JyWriteBuf[len] =gn_jy_num;
	
	len +=sizeof(short);
	memcpy(&JyWriteBuf[len], lpData, DataSize);
	len +=DataSize;
    
    *(int*)&JyWriteBuf[1]= len - 1 - sizeof(int);
    
    if(hDesDll!=NULL)
    {
  		desinit(DesKey);
  		for(b=&JyWriteBuf[3],i=len-3;i>0;i-=8,b+=8)
  		{
  			if(i<8) break;
  			ecbencode(b,b);
  		}
  	}
  	
  	if(hDesDll!=NULL &&RsaOk &&
  		strncmp(lpHead,JY_CHKUSR_HEAD,strlen(JY_CHKUSR_HEAD)) ==0)
  	{
  		memset(temp,0,100);
  		BytToStr(RsaKey,temp);
  		memcpy(&JyWriteBuf[len],temp,100);
  		len +=100;
  		memcpy(&JyWriteBuf[len],"RSAKEY",6);
  		len +=6;
  		*(int*)&JyWriteBuf[1]= len - 1 - sizeof(int);
  	}
  	
	for(i=1+sizeof(int);i<len;i++)
	{
		if(JyWriteBuf[i]>='0'&&JyWriteBuf[i]<='Z')
		{
			JyWriteBuf[i]=en[JyWriteBuf[i]-'0'];
		}
	}

  	tlen = len;
	for(x=0;;)
	{
	    DrawTime(1);
		len = send(sdJy,&JyWriteBuf[x], tlen -x, 0);
		if (len == SOCKET_ERROR)
		{
			if ((len =h_errno) == WSAEWOULDBLOCK)
			{
				DrawTime(YELLOW_SIGN);
				continue;
			}
			else if(len !=WSAENETRESET)
			{
				ErrMsg(ghDlgJy, GetError("translate jy"));
				DrawTime(RED_SIGN);
				return(-1);
			}
		}
		if(x+len !=tlen)
			x+=len;
		else
			break;
	}
	
	lpCurJyData =lpData;
	lpCurJyRes =lpRes;
	lpCurJyHead =lpHead;
	curJyDataSize =DataSize;
	curJyResSize =ResSize;
	*(char *)lpCurJyRes =ANS_UNKOWN;
	
	DrawTime(0);
	return len;
}


#define		DATA_HEAD_SIZE	3

char JydataHead[DATA_HEAD_SIZE+1];
int  JyHeadPrt=0,JydataPrt=0 ;


int AnaJyRecvData(void)
{
  int prt,len,try_times,dataNum;
  char temp[MAX_READ_BUF_SIZE+1];  

   prt=len=try_times=dataNum=0;
   
retry_read:
	if(try_times ++>10)
	{
		ErrMsg(ghDlgJy, "recv error");
		return -1;
	}	

	memset((char *)&temp[0],0,MAX_READ_BUF_SIZE*sizeof(char));
  	DrawTime(1);	
	len = recv(sdJy,(char *)&temp[0],MAX_READ_BUF_SIZE*sizeof(char),0);
	if (len == SOCKET_ERROR) 
	{
		if (h_errno == WSAEWOULDBLOCK)
			goto retry_read;
		else
		{
			ErrMsg(ghDlgJy, GetError("recv cancel error"));
			if(ConnectHost(0, -1)<0)
			{
				ErrMsg(ghDlgJy, "Reconnect failed");
				DrawTime(2);
				return -1;
			}
		}
	}
	if(len <=0)
	{   
		DrawTime(2);
	 	return -1;
    }
    if(len>4)
    {        
    	if(temp[0]==DATA_START_SIGN && JyHeadPrt!=0 && temp[3]>='A' && temp[3]<='Z')
    	{
     		JydataPrt=0; 
     		JyHeadPrt=0;
    	}	
    }        
    while(prt<len)
    {
     	if(JyHeadPrt<DATA_HEAD_SIZE)
     	{
     		if(JyHeadPrt==0)
     		{
     			if(temp[prt]!=DATA_START_SIGN)
     			{
     				prt++;
     				DrawTime(2);
     				continue;
     			}     			
     			else
     			{
     				DrawTime(1);     			
     			    JydataHead[JyHeadPrt]=temp[prt];
     			    JyHeadPrt++;
     				prt++;
     			}	
     		}
     		if(prt>=len)
     		{
     			DrawTime(2);     		
     			return 0;
     		}	
     		if(DATA_HEAD_SIZE - JyHeadPrt	>len-prt)
     		{
     			memcpy((char*)&JydataHead[JyHeadPrt],(char*)&temp[prt],len-prt);
     			JyHeadPrt+=len-prt;
     			DrawTime(2);
     			return 0;
     		}
     		else
     		{
     			memcpy((char*)&JydataHead[JyHeadPrt],(char*)&temp[prt],DATA_HEAD_SIZE - JyHeadPrt);
     			prt+=DATA_HEAD_SIZE - JyHeadPrt;
     			JyHeadPrt=DATA_HEAD_SIZE;
     		}
     			
     	}
     	
     	if(prt>=len)
     	{
     	    DrawTime(2);
     		return 0;
     	}	
     	dataNum=*(int *)&JydataHead[1];
     	if(dataNum<=0)
     	{
			MessageBeep(0);     	
			DrawTime(2);
     		return -1;
     	}
     	if(dataNum-JydataPrt  > len - prt)
     	{
     		memcpy((char FAR *)&JyReadBuf[JydataPrt],(char*)&temp[prt],len-prt);
     		JydataPrt+=len-prt;
     		DrawTime(2);     		
     		return 0;
     	}
     	else
     	{
     		memcpy((char FAR *)&JyReadBuf[JydataPrt],(char*)&temp[prt],dataNum-JydataPrt);
     		prt+=dataNum-JydataPrt;
     		JydataPrt=dataNum;

     		UDP_Client_ReadJy();
     		JydataPrt=0; 
     		JyHeadPrt=0;
     		dataNum=0;
     	}
     	
     	if(prt>=len)
     	{   
     		DrawTime(0);     		
     		return 0;     		
     	}	
    }
    DrawTime(0);     		
    return 0;    
    
}

int UDP_Client_ReadJy(void)
{
	int len, jy_num;
	LPSTR lpTmp;
	int retry_times =0;
	
	
	lpTmp =&JyReadBuf[0];

	if(!strnicmp(JY_ZQSXX_HEAD,lpTmp,sizeof(JY_ZQSXX_HEAD)))
	{
		lpTmp +=strlen(JY_ZQSXX_HEAD);		
		//memset(&Qsxx, 0, sizeof(ZQSXX));
		//memcpy(&Qsxx,lpTmp,sizeof(ZQSXX));
		if(*(lpTmp+DATALENGTH -1) !=0)
		{   
			Msg("���ڳ�ʼ�����׼��ܲ����������Ժ�...",MSG_VERT);
			gfConnecting =TRUE;
			WriteRsaPk(JyQs,lpTmp,lpTmp+DATALENGTH);		
			EncipherDesKey(DesKey,lpTmp,lpTmp+DATALENGTH,RsaKey);
			WriteRsaCiper(JyQs,RsaKey,DesKey);
			RsaOk =1;
			DispQsName(JyQs,RsaOk);			
			Msg("",MSG_HIDE);
			gfConnecting =FALSE;
		}
		else
			RsaOk =0;
		return 0;
	}

	len=JydataPrt;
	if(len ==0) return -1;
	if(lpCurJyData ==NULL) return -1;
	
	if(strnicmp(lpCurJyHead, lpTmp, strlen(lpCurJyHead)))
	{
		MessageBeep(0);
		return -1;
	}
	lpTmp +=strlen(lpCurJyHead);
	len -=strlen(lpCurJyHead);
	jy_num =*(short *)lpTmp;
	lpTmp +=sizeof(short);
	len -=sizeof(short);
	if(jy_num !=gn_jy_num) return -1;
	if(len ==1)
	{
		*(char *)lpCurJyRes =*lpTmp;    //cx_end, sys_err, time_out, other ret_err...
		goto read_ok;
	}
	
	if(!fIsJyCx && len !=curJyResSize)
	{
		MessageBeep(0);
		return -1;
	}
	memcpy(lpCurJyRes, lpTmp, curJyResSize);

read_ok:

	if(fIsJyCx)
		SendMessage(ghDlgJy, WM_JYCX_RES, 0, 0L);
	else
		SendMessage(ghDlgJy, WM_JY_RES, 0, 0L);
	
	return 0;
}

void SendJyExit(char *lpgddm)
{
	char SendBuff[100];
	int i, len,x,tlen;
	
	memset(&SendBuff[0],0,sizeof(SendBuff));
	SendBuff[0]=DATA_START_SIGN;

	len = 1 + sizeof(int );
	
	memcpy(&SendBuff[len], JY_EXIT,strlen(JY_EXIT));
	len += strlen(JY_EXIT);
	
	memcpy(&SendBuff[len], lpgddm ,strlen(lpgddm));
	len +=strlen(lpgddm);
	
	SendBuff[len++] =0;
	SendBuff[len] =0;
	*(int *)&SendBuff[1] =	len -1 -sizeof(int );
	
    len= len -1 - sizeof( int );
    
    for(i=0;i<len;i++)
    {
		if(SendBuff[i+1+sizeof(int)]>='0'&&SendBuff[i+1+sizeof(int)]<='Z')
		{
	    	SendBuff[i+1+sizeof(int)]=en[SendBuff[i+1+sizeof(int)]-'0'];
		}
    }
	
	len = len +1 + sizeof(int);
	DrawTime(1);
	tlen =len;
	for(x=0;;)
	{
		len =send(sdJy, &SendBuff[x], tlen -x, 0);
		if (len == SOCKET_ERROR)
		{
			if (h_errno == WSAEWOULDBLOCK)
				continue;
			else 
				return;
		}
		if(x+len !=tlen)
			x+=len;
		else
			break;
	}
	DrawTime(0);     				
}


void SendJyQsxx(void)
{
	char SendBuff[100];
	int i, len ,tlen,x;
	
	memset(&SendBuff[0],0,sizeof(SendBuff));
	SendBuff[0]=DATA_START_SIGN;

	len = 1 + sizeof(int );
	
	memcpy(&SendBuff[len], JY_ZQSXX_HEAD,strlen(JY_ZQSXX_HEAD));
	len += strlen(JY_ZQSXX_HEAD);	
	SendBuff[len] =0;
	
	*(int *)&SendBuff[1] =	len -1 -sizeof(int );
	
    len= len -1 - sizeof( int );    
    for(i=0;i<len;i++)
    {
		if(SendBuff[i+1+sizeof(int)]>='0'&&SendBuff[i+1+sizeof(int)]<='Z')
		{
	    	SendBuff[i+1+sizeof(int)]=en[SendBuff[i+1+sizeof(int)]-'0'];
		}
    }	
	len = len +1 + sizeof(int);	
	DrawTime(1);     				
	tlen =len;
	for(x =0;;)
	{
		len =send(sdJy, &SendBuff[x],tlen -x, 0);
		if (len == SOCKET_ERROR)
		{
			if (h_errno == WSAEWOULDBLOCK)
				continue;
			else 
				return;
		}
		if(len+x!=tlen)
			x+=len;
		else
			break;
	}
	DrawTime(0);     					
}
