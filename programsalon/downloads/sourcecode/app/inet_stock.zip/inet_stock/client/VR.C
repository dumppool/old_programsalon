#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "resource.h"
#include "global.h"
#include "fx.h"

extern LPFX Fx;

int CreateVrData(K_DATA *lpKData,int RNum,DATA *Data,PARA *Para)
{   
	int i,j,l;
    long m;
    double Tun[2],Tdn[2];
    double Ttr;
	VR_DATA *VrData;
	
	VrData=(VR_DATA*)_fmalloc(sizeof(VR_DATA)*RNum);
	memset(VrData,0,sizeof(VR_DATA)*RNum);
    for(j=0;j<RNum;j++)
    {
    		if(j==0)
    		{
    			Tun[0]=Tdn[0]=Ttr=0;
    			Para->price[0]=0.0;
    			VrData[j].vr=0;
    		}
    		if(j<=Para->periods[0]-1&&j>0)
    		{    			     
    			if(lpKData[j-1].ss<lpKData[j].ss)
    				Tun[0]+=lpKData[j].cj*lpKData[j].ss;
    			if(lpKData[j-1].ss>lpKData[j].ss)
    				Tdn[0]+=lpKData[j].cj*lpKData[j].ss;
    			Ttr+=lpKData[j].cj*lpKData[j].ss;    			     
    			VrData[j].vr=0;
    		}
    		m=j-Para->periods[0];
    		if(j>Para->periods[0]-1)
    		{
    			
    			Tun[0]=Tdn[0]=0;
    			for(l=1;l<=Para->periods[0];l++)
    			{
    			    m=l+j-Para->periods[0];
    				if(lpKData[m-1].ss<lpKData[m].ss)
    			        Tun[0]+=lpKData[m].ss*lpKData[m].cj;
    				if(lpKData[m-1].ss>lpKData[m].ss)
    			        Tdn[0]+=lpKData[m].ss*lpKData[m].cj;    			        
    			}    
    			m=j-Para->periods[0];
    			Ttr+=lpKData[j].cj*lpKData[j].ss-lpKData[m].cj*lpKData[m].ss;
    		}
    		if(j>=Para->periods[0]-1)
    		{   
    		    if((Tdn[0]+Ttr/2)!=0)
    				VrData[j].vr=(Tun[0]+Ttr/(double)2.00)/(Tdn[0]+Ttr/(double)2.00);
    			else
    				VrData[j].vr=0;
    			if(Para->price[0]<VrData[j].vr)
    				Para->price[0]=VrData[j].vr;		
    		}
    }
    for(j=0;j<10;j++)
    {
        if(Data->v==NULL) 
        	break;
    	if(Data->v[j]!=NULL)
    	{
    		_ffree(Data->v[j]);
    		Data->v[j]=NULL;
    	}
    }    
    Data->v==NULL;     
    Data->num =Para->dnum; 
    Data->no =Para->no;
    strcpy(Data->gpdm,Fx->gpdm);
    Data->type =Fx->type;
    Data->range =Fx->range;
    Data->size =RNum;
    for(j=0;j<Data->num;j++)
    	Data->v[j]=(double *)_fmalloc(sizeof(double)*RNum);
    for(i=0;i<Data->num;i++)
    {
    	for(j=0;j<RNum&&i==0;j++) 
    		Data->v[i][j]=VrData[j].vr;
    	Data->method[i]=CURVE_METHOD;
    }
    Para->feature |=DW_ALL;
    _ffree(VrData);
	return TRUE;
}

