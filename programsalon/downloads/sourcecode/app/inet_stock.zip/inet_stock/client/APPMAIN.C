/* hq_cl:��Ʊ���飬��������Ѷ�����ס�
*  by lgd/Paladin.InetSoft guangzhou 1996.9
*  http://www.nease.net/~inetsoft, inetsoft@163.net
*  modify by lym(���˳���ѧ��Щwin32��̣��޸ĺ�������ȴ��Ըд��ԭ���ߵ�һ����) guangzhou 1997.5-1998
*/
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <io.h>
#include "global.h"
#include "resource.h"
#include "appmain.h"

#include "pctcp.h"
#include "hq.h"
#include "hq_cl.h"
#include "jy_cl.h"

#include "caption.h"
#include "mmp.h"
#include "cj.h"
#include "status.h"
#include "xlt.h"
#include "jlt.h"
#include "graph.h"
#include "maxmin.h"
#include "lithq.h"
#include "zs.h"
#include "fx.h"
#include "toolbar.h"
#include "msg.h"
#include "rsa.h"
#include "env.h"
#include "comm.h"

#include "hq_tcp.h"

int WinVer =3;
HINSTANCE ghInstance =NULL;

HWND ghWndMain =NULL, 
    ghWndStatus =NULL, 
    ghWndMaxMin =NULL,
	ghWndXlt =NULL, 
	ghWndJlt =NULL,
	ghWndCaption =NULL, 
	ghWndZs =NULL,
	ghWndMmp =NULL, 
	ghWndCj =NULL, 
	ghWndHq =NULL, 
	ghWndLitHq =NULL, 
	ghWndFx =NULL,
	ghDlgChkUsr =NULL,
	ghWndToolBar =NULL, 
	ghWndTips =NULL,
	ghWndHelp=NULL,
	hWndInput =NULL;
	
HMENU ghMenuHq =NULL, 
	ghMenuMain =NULL, 
	ghMenuMainGraph =NULL, 
	ghMenuGraph =NULL;
	
HBITMAP hBmpUp =NULL, 
	hBmpDown =NULL, 
	hBmpEqual =NULL;
	
BOOL IsSzRead=FALSE,IsShRead=FALSE;

int STATUS_HEIGHT=0;
int MSG_HEIGHT =0;
int INPUT_WIDTH =0; 
int TOOLBAR_HEIGHT =0;

BOOL gfTest =FALSE;

int gfOnLine = FALSE,
	gfConnecting =TRUE,
	gfDelete=FALSE;
int jy_running =FALSE;

char * IpSendBuffer,
	 *IpCommitBuffer;
unsigned int IpSendLen =0,
	IpCommitLen =0;

HANDLE hLibCtl3d =NULL;
char inkey[16+1],*winpy=NULL;
short SeleGp[MAX_SELE_NUM][2];

char UserID[HQ_USERID_SIZE+1];
char UserPwd[HQ_USERPWD_SIZE+1];

//extern HWND ghDlgJy;

extern char szDataPath[128];
extern unsigned int RANGE_MENU[7];
extern int SeleQs;

extern LPSTR HqTitles[HQ_FLDS_COUNT+2];
extern int Jy(void);
extern void UDP_Send_Exit(void);
extern HBRUSH DrawChild(HDC hDC, HWND hWnd);

extern int UDP_Client_ReadHq(void);
extern int AnaRecvData(void);
extern int AnaJyRecvData(void);

extern int UDP_Client_ReadJy(void);
extern int UDP_Send_Hq00(int jys, BOOL fFirst, int fRefresh, int fSel, int recCount, short *recList);
extern int UDP_Send_Hq01(int, BOOL, int, int);
extern int UDP_Send_Zx(void);
extern int sdHq,JyOffLineTime;
extern JY_ANS_CHKUSR curChkUsrRes;
extern HFILE hfZx ;

extern BOOL  Ip_Send_Pack();
extern int InitQsInfo(void);
extern int JyQs;
extern char Addr[MAX_ZQS_COUNT][15];
extern int ConnectToJyHost(char *HostName);
extern void SendJyQsxx(void);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hInstPre,
					LPSTR lpszCmdLine, int nCmdShow)
{                      	
	WNDCLASS wc;
	HWND hwnd;
	MSG msg;
	int x,y;
    
	if(hInstPre)
	{
		hwnd =FindWindow(APPNAME, NULL);
		if(hwnd)
			SetFocus(hwnd);
		return FALSE;
	}
	ghInstance =hInstance;
	
	memset(&wc, 0, sizeof(wc));
	wc.style =0;
	wc.lpfnWndProc = MainWndProc;
	wc.lpszClassName =APPNAME;
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = hInstance;
	wc.lpszMenuName = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDR_MAINFRAME));
		
	if(!RegisterClass(&wc))
	{
		ErrMsg(NULL, "RegisterClass wnd_main failed!");
		return FALSE;                         
	}       
	
	if(!RegisterChilds()) return FALSE;
	
	if(!AppInit())
	{
		ErrMsg(NULL, "AppInit failed!");
		AppExit();
		return FALSE;
	}
	if(strstr(lpszCmdLine,"/T")!=NULL||strstr(lpszCmdLine,"/t")!=NULL)
		gfTest =TRUE;

	x =GetSystemMetrics(SM_CXSCREEN);
	y =GetSystemMetrics(SM_CYSCREEN) -GetSystemMetrics(SM_CYCAPTION)*2;
	hwnd =CreateWindow(APPNAME, APPNAME, WS_SYSMENU|WS_CLIPCHILDREN|
			WS_THICKFRAME|WS_MAXIMIZEBOX|WS_MINIMIZEBOX,
			0, 0, x, y,
			NULL, NULL, hInstance, NULL);	
	if(hwnd ==NULL)
	{
		ErrMsg(NULL, "����������ʧ�ܣ�");
		return FALSE;
	}
	ghWndMain =hwnd;	
	ShowWindow(hwnd, SW_SHOW);
	InvalidateRect(hwnd, NULL, FALSE);
	
	while(GetMessage(&msg, 0, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	
	AppExit();
	
	return msg.wParam;
}

void LoadPy(void)
{
	OFSTRUCT os;
	HANDLE hf;
	long len;
	
	hf=OpenFile("winpy.dat", &os, OF_SHARE_DENY_NONE|OF_READ);	
	if(hf!=HFILE_ERROR)
	{   
		if((len =_llseek(hf,0L,SEEK_END))>0L)
		{
			winpy = (char *)GlobalAllocPtr(GHND,len+1);
			if(winpy!=NULL)
			{
				_llseek(hf,0L,SEEK_SET);
				if(_lread(hf,winpy,(UINT)len)!=(UINT)len)
				{
					GlobalFreePtr(winpy);
					winpy =NULL;
				}	
			}
		}
	}
	if(hf!=HFILE_ERROR) _lclose(hf);
}

BOOL AppInit(void)
{
	FARPROC fpTemp =NULL;
		
	WinVer =LOBYTE(LOWORD(GetVersion()));
	if(WinVer <4)
	{
		hLibCtl3d =LoadLibrary("CTL3DV2.DLL");
		if((UINT)hLibCtl3d <=32)
			hLibCtl3d =LoadLibrary("CTL3D.DLL");
		if((UINT)hLibCtl3d >32)
		{
			fpTemp =GetProcAddress(hLibCtl3d, "Ctl3dRegister");
			if(fpTemp)
				(*fpTemp)(ghInstance);
			fpTemp =GetProcAddress(hLibCtl3d, "Ctl3dAutoSubclass");
			if(fpTemp)
				(*fpTemp)(ghInstance);
		}
	}

	ghMenuMain =LoadMenu(ghInstance, MAKEINTRESOURCE(IDR_MENU_MAIN));
	if(!ghMenuMain)
	{
		ErrMsg(NULL, "Load main menu failed!");
		return FALSE;
	}
	ghMenuHq =GetSubMenu(ghMenuMain, 0);
	ghMenuMainGraph =LoadMenu(ghInstance, MAKEINTRESOURCE(IDR_MENU_GRAPH));
	
	if(!ghMenuMainGraph)
	{
		ErrMsg(NULL, "Load graph menu failed!");
		return FALSE;
	}
	ghMenuGraph =GetSubMenu(ghMenuMainGraph, 0);

	hBmpUp =LoadBitmap(ghInstance, MAKEINTRESOURCE(IDB_UP));
	hBmpDown =LoadBitmap(ghInstance, MAKEINTRESOURCE(IDB_DOWN));
	hBmpEqual =LoadBitmap(ghInstance, MAKEINTRESOURCE(IDB_EQUAL));

	if(!HqInit()) return FALSE;
	if(!JyInit()) return FALSE;
	if(!GraphInit()) return FALSE;
	if(!AnalyseInit()) return FALSE;
	if(PCTCPInit() !=0)
	{
		ErrMsg(NULL, "PCTCPInit() failed!");
		gfOnLine =FALSE;
	}
	IpSendBuffer = (char *)GlobalAllocPtr(GHND,MAX_WRITE_BUF_SIZE +1);
	if(IpSendBuffer ==NULL) return FALSE;
	
	IpCommitBuffer = (char *)GlobalAllocPtr(GHND,MAX_WRITE_BUF_SIZE +1);
	if(IpCommitBuffer ==NULL) return FALSE;
	GetSet();
	LoadPy();
	return TRUE;
}

void AppExit(void)
{
	FARPROC fpTemp =NULL;
	static BOOL fExit =FALSE;
	
	if(fExit) return;
	
	fExit =TRUE;

	SaveSet();

	GraphExit();
	HqExit();
	JyExit();
	PCTCPExit();
	GlobalFreePtr(IpSendBuffer);
	GlobalFreePtr(IpCommitBuffer);
	FxExit(Fx);

	if(ghMenuMain) DestroyMenu(ghMenuMain);
	if(ghMenuMainGraph) DestroyMenu(ghMenuMainGraph);
	if(hBmpUp) DeleteObject(hBmpUp);
	if(hBmpDown) DeleteObject(hBmpDown);
	if(hBmpEqual) DeleteObject(hBmpEqual);
	if((UINT)hLibCtl3d >32)
	{
		fpTemp =GetProcAddress(hLibCtl3d, "Ctl3dUnregister");
		if(fpTemp)
			(*fpTemp)(ghInstance);
		FreeLibrary(hLibCtl3d);
	}
	if(winpy!=NULL) GlobalFreePtr(winpy);
}

extern void ReadHqDataAll(void); 
extern void WriteHqDataAll(void);
extern void DelOldData(void);   
extern void ReadHqData(int jys);


LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message,
					WPARAM wParam, LPARAM lParam)
{
	FARPROC lpFarProc=NULL;
	static int recNum =0;
	int i,ret,j;
	char temp[100+1];
	HDC hDC;
	TEXTMETRIC tm;		
	STOCK_INFO_FRAME StockInfo;
	
	switch(message)
	{
		case WM_CREATE:		
			ghWndMain =hWnd;
			ghDlgJy =NULL;

			hDC =GetDC(hWnd);
			GetTextMetrics(hDC, &tm);
			ReleaseDC(hWnd,hDC);
			
			STATUS_HEIGHT =30;			
            MSG_HEIGHT =tm.tmHeight+4;
			INPUT_WIDTH =tm.tmMaxCharWidth*10;
			
			if(!CreateChilds(hWnd)) 
				return -1;
			InvalidateRect(hWnd, NULL, FALSE);
			PostMessage(hWnd,WM_USER+4,0,0L);
		break;  
		case WM_USER+1:
			switch(lParam)
			{
				case FD_READ:
					AnaRecvData();
				break;
				case FD_CONNECT:
					gfConnecting=FALSE;	
					gfOnLine =TRUE;					
					if(UDP_Send_Hq00(0, TRUE, FALSE, FALSE, HqPaintData.curRecCount, &recNum)<0)
					{
						ErrMsg(ghWndMain, "����������������");
						gfOnLine =FALSE;
						PostMessage(hWnd,WM_USER+3,0,0L);
						break;
					}
					
					SetTimer(hWnd, 1, 100, NULL);		
					SetTimer(hWnd, 2, 1000*HQ_REFRESH_TIME, NULL);
				
					lpFarProc =MakeProcInstance((FARPROC)HqUserDlgProc, ghInstance);
					DialogBox(ghInstance, MAKEINTRESOURCE(IDD_HQUSER),
								hWnd, lpFarProc);
					FreeProcInstance(lpFarProc);
					
					if(!gfOnLine)
						PostMessage(hWnd,WM_USER+3,0,0L);
					else
					{			
						Msg("�����������ͳ�ʼ������",MSG_VERT);
						DelOldData();
						gfDelete=TRUE;
						gfOnLine=TRUE;						
					}
				break;
			}
		break;		
		case WM_USER+2:
			switch(lParam)
			{
				case FD_READ:
				    AnaJyRecvData();
				break;
				case FD_CONNECT:
					JyQs =SeleQs;
					DispQsName(JyQs,0);
					if(!ReadRsaCiper(JyQs,RsaKey,temp))
					{
						SendJyQsxx();
						RsaOk =0;
					}
					else
					{
						strncpy(DesKey,temp,8);
						DesKey[8]=0;
						RsaOk =1;
						DispQsName(JyQs,RsaOk);
					}				
				break;
			}
		break;
		case WM_USER +3:
			gfConnecting=FALSE;
			ReadHqDataAll();
			if(ReCreateChild()!=0)
				return (-1);
			IsSzRead=IsShRead=TRUE;				
			GetSelSet();
			SetTimer(hWnd, 1, 100, NULL);		
			SetTimer(hWnd, 2, 1000*HQ_REFRESH_TIME, NULL);
		break;
		case WM_USER +4:
			gfOnLine =FALSE;			
			gfConnecting=TRUE;            
			recNum =0;	     
            
            if(BeginConnect(HostName)<0)
			{
				Msg("��������ʧ�ܣ�ϵͳ��������״̬",MSG_VERT);
				PostMessage(hWnd,WM_USER+3,0,0L);
			}
			else
			{
				sprintf(temp,"������������%s",HostName);
				Msg(temp,MSG_VERT);
				SetTimer(hWnd, 1, 15000, NULL);
			}		
		break;
		case WM_USER +5:
			Msg("��ȡ���ڳ�ʼ���ļ�",MSG_VERT);		
			ReadHqData(0);
			IsSzRead=TRUE;		
		break;
		case WM_USER +6:
			Msg("��ȡ�Ϻ���ʼ���ļ�",MSG_VERT);		
			ReadHqData(1);
			IsShRead=TRUE;
			InitQsInfo();
			GetSelSet();
			if(access("winpy.dat",0)!=0)
			{
			 	StockInfo.type=FILE_WINPY;
				strcpy(StockInfo.name,"winpy.dat");
			   	UDP_Send_Stock_Info(&StockInfo);
			}			
		break;
		case WM_USER +7:
			LoadPy();
		break;
		case WM_SIZE:
		    CreateChilds(ghWndMain);
		break;

		case WM_SYSKEYDOWN:
			ret =toupper(wParam);
			switch(ret)
			{
			    case 'H':
					SendMessage(ghWndHq, WM_KEYDOWN,VK_F1, 0L);
			    break; 
			    case 'J':
					SendMessage(ghWndHq, WM_KEYDOWN,VK_F2, 0L);
			    break; 
				case 'R':
					SendMessage(ghWndXlt, WM_KEYDOWN,VK_F3, 0L);
				break;
				case 'A':
					SendMessage(ghWndHq, WM_KEYDOWN,VK_F4, 0L);
				break;				
				case 'Z':
					SendMessage(ghWndHq, WM_KEYDOWN,VK_F5, 0L);
				break;
				case 'W':
					SendMessage(ghWndHq, WM_KEYDOWN,VK_F6, 0L);
				break;				
				case 'S':
					SendMessage(ghWndHq, WM_KEYDOWN,VK_F7, 0L);
				break;
				case 'F':
					SendMessage(ghWndHq, WM_KEYDOWN,VK_F8, 0L);				
				break;				
				case 'E':
					SendMessage(ghWndHq, WM_KEYDOWN,VK_F9, 0L);					
				break; 
				case 'G':
					SendMessage(ghWndHq, WM_KEYDOWN,VK_F12, 0L);
				break;
				case 'Q':
					SendMessage(hWnd, WM_CLOSE,0, 0L);
				break;
				case '1':
					if((curChkUsrRes.userId !=0 && curChkUsrRes.flag==ANS_SUCC)||
							gfTest)
                    	DlgBuySell('B');
				break;
				case '2':
					if((curChkUsrRes.userId !=0 && curChkUsrRes.flag==ANS_SUCC)||
							gfTest)
                    	DlgBuySell('S');
				break;				
				case '3':
					if((curChkUsrRes.userId !=0 && curChkUsrRes.flag==ANS_SUCC)||
							gfTest)
                    	DlgCancel();
				break;	
				case '4':
					if((curChkUsrRes.userId !=0 && curChkUsrRes.flag==ANS_SUCC)||
							gfTest)
                    	DlgCjcx();
				break;
				case '5':
					if((curChkUsrRes.userId !=0 && curChkUsrRes.flag==ANS_SUCC)||
							gfTest)
                    	DlgWtcx();
				break;
				case '6':
					if((curChkUsrRes.userId !=0 && curChkUsrRes.flag==ANS_SUCC)||
							gfTest)
                    	DlgYecx();
				break;								
				case '7':
					if((curChkUsrRes.userId !=0 && curChkUsrRes.flag==ANS_SUCC)||
							gfTest)
                    	DlgChgPwd();
				break;				
			}
		break;

		case WM_TIMER:
			if(wParam ==2 && gfOnLine)
				CheckTime(TRUE);
			if(wParam ==1)
			{   
				KillTimer(ghWndMain,1);
				
				if(gfConnecting &&!gfOnLine)
				{
					ErrMsg(hWnd, "��������ʧ�ܣ�ϵͳ��������״̬");
					PostMessage(hWnd,WM_USER+3,0,0L);
				}				
				Ip_Send_Pack();
				
			    //if(JyOffLineTime>0)
             	//	JyOffLineTime--;
             	//if(JyOffLineTime==0)
             	//{
             	//	Msg("��������ʱ�������ϵͳ��λ",MSG_VERT);
             	//  	curChkUsrRes.userId=0;
             	//} 
             	
             	//if(JyOffLineTime<10&&JyOffLineTime*(int)JyOffLineTime/2==JyOffLineTime
             	//		&&JyOffLineTime>0)
             	//	DrawTime(-2);
             	//else
				DrawTime(-1);
					
             	SetTimer(ghWndMain,1,400,NULL);
			}
			if(wParam ==6) DestroyWindow(hWnd);
		break;
		
		case WM_CHAR:
			if(ghWndSetup==NULL)
			{
				SendMessage(ghWndMsg, WM_CHAR, wParam, lParam);
				return 0;
			}
		break;		
		case WM_KEYDOWN:
			if(wParam==VK_RETURN)
			{
				GetWindowText(hWndInput, inkey, sizeof(inkey));				
			    ret =PreComm(inkey);
			    switch(ret)
			    {
			    	case IP_CONN_COMM:
						strcpy(HostName,inkey);
						strcpy(inkey,"");
			    		SendMessage(hWnd, WM_USER+4, 0, 0L);
			    		SetWindowText(hWndInput, "");			    	
			    	break;
					case NULL_COMM:			    	
			    	case OP_CODE_COMM:
			    	case GP_CODE_COMM:
						if(IsWindowVisible(ghWndFx))
							SendMessage(ghWndFx, WM_KEYDOWN, wParam, lParam);
						else if(IsWindowVisible(ghWndXlt))
							SendMessage(ghWndXlt, WM_KEYDOWN, wParam, lParam);
						else SendMessage(ghWndHq, WM_KEYDOWN, wParam, lParam);			    	
			    	break;
			    	case PY_NAME_COMM:
			    		if(winpy==NULL)
			    			break;
			    		for(i=0;i<10;i++) SeleGp[i][0]=-1;
			    		
						for(i =0,j=0; i<HqData[0].recCount&&j<MAX_SELE_NUM; i++)
						{
							strcpy(temp,HqData[0].lpPreData[i].zqmc);							
							PreStockName(temp);
							
							if(IsPyOk(inkey,temp))
							{
								SeleGp[j][0]=0;
								SeleGp[j++][1]=i;
							}
						}
						for(i =0; i<HqData[1].recCount&&j<MAX_SELE_NUM; i++)
						{
							strcpy(temp,HqData[1].lpPreData[i].zqmc);							
							PreStockName(temp);
							
							if(IsPyOk(inkey,temp))
							{
								SeleGp[j][0]=1;
								SeleGp[j++][1]=i;
							}
						}
						
						if(SeleGp[1][0]!=-1)
						{
							i=DlgSelectGp();						
							if(i!=-1)
							if(SeleGp[i][0]!=-1)
							SetWindowText(hWndInput, HqData[SeleGp[i][0]].lpPreData[SeleGp[i][1]].zqdm);
						}
						else
						{
						 	if(SeleGp[0][0]!=-1)
							SetWindowText(hWndInput, HqData[SeleGp[0][0]].lpPreData[SeleGp[0][1]].zqdm);
						}
						if(IsWindowVisible(ghWndFx))
							SendMessage(ghWndFx, WM_KEYDOWN, wParam, lParam);
						else if(IsWindowVisible(ghWndXlt))
							SendMessage(ghWndXlt, WM_KEYDOWN, wParam, lParam);
						else SendMessage(ghWndHq, WM_KEYDOWN, wParam, lParam);			    	
			    	break;
			    }
			    strcpy(inkey,"");
			    SetWindowText(hWndInput, "");
			}
			else
			{
				if(IsWindowVisible(ghWndXlt))
					SendMessage(ghWndXlt, WM_KEYDOWN, wParam, lParam);
				else if(IsWindowVisible(ghWndFx))
					SendMessage(ghWndFx, WM_KEYDOWN, wParam, lParam);
				else SendMessage(ghWndHq, WM_KEYDOWN, wParam, lParam);			
			}
		break;		
		case WM_KILLFOCUS:
			if(IsWindowVisible(ghWndFx))
				SendMessage(ghWndFx, WM_KILLFOCUS, wParam, lParam);
			else SendMessage(ghWndXlt, WM_KILLFOCUS, wParam, lParam);
		break;		
		case WM_CLOSE:
			if(MessageBox(hWnd, "���Ƿ�ȷ��Ҫ�˳�?",APPNAME,
						MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2|MB_SYSTEMMODAL)
							==IDNO)
				return 0L;
			UDP_Send_Exit();
			SetTimer(hWnd, 6, 1000,NULL);
			gfOnLine = FALSE;
			//DestroyWindow(hWnd);
		break;
		
		case WM_DESTROY:
			WriteHqDataAll();
			ghWndMain =NULL;
			KillTimer(hWnd, 1);
			KillTimer(hWnd, 2);
			KillTimer(hWnd, 5);
			KillTimer(hWnd, 6);
			PostQuitMessage(0);
		break;
		
		case WM_COMMAND:
			switch(wParam)
			{
				case IDM_ONLINE:
					SetHqEnv();
				break;
				
				case IDM_VIEW_TOOLBAR:
					if(IsWindowVisible(ghWndToolBar))
					{
					    ShowWindow(ghWndFx, SW_HIDE);
						ShowWindow(ghWndToolBar, SW_HIDE);
						ModifyMenu(ghMenuMain, IDM_VIEW_TOOLBAR, MF_STRING|MF_BYCOMMAND,
									IDM_VIEW_TOOLBAR, "��ʾ������");
						TOOLBAR_HEIGHT=0;
						ReCreateChild();
					}
					else
					{
						ShowWindow(ghWndFx, SW_HIDE);
						ShowWindow(ghWndToolBar, SW_SHOW);
						ModifyMenu(ghMenuMain, IDM_VIEW_TOOLBAR, MF_STRING|MF_BYCOMMAND,
									IDM_VIEW_TOOLBAR, "���ع�����");
						TOOLBAR_HEIGHT=BUTTON_HEIGHT +12;
						ReCreateChild();
					}
				break;
				case IDM_HQ_SZ:
				case IDM_HQ_SH:
				case IDM_HQSEL_1:
				case IDM_HQSEL_2:
				case IDM_HQSEL_3:
				case IDM_HQSEL_4:
				case IDM_HQSEL_5:
				case IDM_GRAPH:
					SendMessage(ghWndHq, WM_COMMAND, wParam, 0L);
				break;
				
				case IDM_HQSEL_SET_1:
				case IDM_HQSEL_SET_2:
				case IDM_HQSEL_SET_3:
				case IDM_HQSEL_SET_4:
				case IDM_HQSEL_SET_5:
					lpFarProc =MakeProcInstance((FARPROC)HqSelDlgProc, ghInstance);
					DialogBoxParam(ghInstance, MAKEINTRESOURCE(IDD_HQSEL_SET),
							hWnd, lpFarProc, (LPARAM)wParam);
					FreeProcInstance(lpFarProc);
				break;
				
				case IDM_HQ_FLD_SEL:
					lpFarProc =MakeProcInstance((FARPROC)HqFldSelDlgProc, ghInstance);
					DialogBox(ghInstance, MAKEINTRESOURCE(IDD_FLDSEL),
							hWnd, lpFarProc);
					FreeProcInstance(lpFarProc);
				break;				
				//case IDM_SORT_REFRESH:
				//	UDP_Client_Hq01(HqPaintData.jys, TRUE);
				//break;				
				case IDM_JY:
					jy_running =TRUE;
					Jy();
					jy_running =FALSE;
				break;
				case IDM_MINIMIZE:
					ShowWindow(hWnd, SW_MINIMIZE);
				break;
				case IDM_FX:
				case IDM_FX_MACD:
				case IDM_FX_DMI:
				case IDM_FX_RSI:
				case IDM_FX_PSY:
				case IDM_FX_VR:
				case IDM_FX_OBV:
				case IDM_FX_BIAS:
				case IDM_FX_WR:
				case IDM_FX_KDJ:
					for(i=IDM_FX_MACD;i<=IDM_FX_KDJ;i++)
					{
                    	if(GetMenuState(ghMenuMain, i, MF_BYCOMMAND)&MF_CHECKED)
                             break;
					}
					if((unsigned int)i!= wParam)
					{
						CheckMenuItem(ghMenuMain, i, MF_BYCOMMAND|MF_UNCHECKED);
						CheckMenuItem(ghMenuMain, wParam, MF_BYCOMMAND|MF_CHECKED);
						if(i<=IDM_FX_KDJ) Fx->type =i;
						else Fx->type =IDM_FX_MACD;
					}
					Fx->IsDataOk=FALSE;
				    SendMessage(ghWndHq,WM_KEYDOWN,VK_F9,0L);
				break;
				case IDM_FX_5:
				case IDM_FX_15:
				case IDM_FX_30:
				case IDM_FX_60:
				case IDM_FX_DAY:
				case IDM_FX_WEEK:
				case IDM_FX_MONTH:
					for(i=0;i<MONTH+1;i++)
						if(RANGE_MENU[i]==wParam) break;
					if(i<MONTH+1)
					{
						CheckMenuItem(ghMenuMain, wParam, MF_BYCOMMAND|MF_CHECKED);
						CheckMenuItem(ghMenuMain,RANGE_MENU[Fx->range], MF_BYCOMMAND|MF_UNCHECKED);
						Fx->range =i;
					}
					if(IsWindowVisible(ghWndFx))
					{
						Fx->IsDataOk=FALSE;
						InvalidateRect(ghWndFx, NULL, TRUE);
					}
				break;				
				case IDM_NEWS:
				     SendMessage(ghWndHq,WM_KEYDOWN,VK_F12,0L);
				break;
				case IDM_HELP:
				     SendMessage(ghWndHq,WM_KEYDOWN,VK_F1,0L);
				break;				
				case IDM_SZDP:
					SendMessage(ghWndHq, WM_COMMAND, IDM_GRAPH, 3L);
				break;
				case IDM_SHDP:
				    SendMessage(ghWndHq, WM_COMMAND, IDM_GRAPH, 4L);
				break;
				case IDM_GGXX:
				     SendMessage(ghWndHq,WM_KEYDOWN,VK_F3,0L);
				break;
				case IDM_EXIT:
					SendMessage(hWnd, WM_CLOSE, 0, 0L);
				break;
				
				default:
					if(IsWindowVisible(ghWndHq))
						SendMessage(ghWndHq, WM_COMMAND, wParam, lParam);
					//else if(IsWindowVisible(ghWndXlt))
					//	SendMessage(ghWndXlt, WM_COMMAND, wParam, lParam);
		    		else if(IsWindowVisible(ghWndFx))
						SendMessage(ghWndFx ,WM_COMMAND, wParam, lParam);
				break;
			}
		break;
	}
	
	return DefWindowProc(hWnd, message, wParam, lParam);
}

LRESULT CALLBACK HqSelDlgProc(HWND hDlg, UINT message,
						WPARAM wParam, LPARAM lParam)
{
	int i, k;
	char tmp[256];
	static int SelNum;
	DWORD dw;
	HWND hctl;
	int sel_num[MAX_HQSEL_REC_COUNT+1];
	LPSTR tok;
	
	switch(message)
	{
		case WM_INITDIALOG:
			ghDlgJy =hDlg;
			SendMessage(hDlg,WM_USER+1,wParam,lParam);
		return TRUE;	
		case WM_USER+1:
			SelNum =(int)lParam-IDM_HQSEL_SET_1;
			
			if(SelNum >=5)
			{
				EndDialog(hDlg, 0);
				return FALSE;
			}
			k =0;
			if(HqSelData[SelNum].recCount <=0)
				HqSelData[SelNum].jys =HqPaintData.jys;
			for(i =0; i<HqData[HqSelData[SelNum].jys].recCount; i++)
			{
				if(HqData[HqSelData[SelNum].jys].lpPreData[i].zqdm[0] ==0)
					continue;
				wsprintf(tmp, "%s-%d-%s",
							(LPSTR)HqData[HqSelData[SelNum].jys].lpPreData[i].zqdm,
							i, (LPSTR)HqData[HqSelData[SelNum].jys].lpPreData[i].zqmc);
				if(HqSelData[SelNum].recCount)
				{
					if(HqSelData[SelNum].recNum[k] ==i && k<HqSelData[SelNum].recCount)
					{
						SendDlgItemMessage(hDlg, IDL_SEL, LB_ADDSTRING,
								0, (LPARAM)(LPSTR)tmp);
						k++;
						continue;
					}
				}
				SendDlgItemMessage(hDlg, IDL_NOTSEL, LB_ADDSTRING,
							0, (LPARAM)(LPSTR)tmp);
			}
		return TRUE;
		case WM_COMMAND:
			switch(wParam)
			{
				case IDC_ADD:
					dw =SendDlgItemMessage(hDlg, IDL_NOTSEL, LB_GETSELCOUNT, 0, 0L);
					if(dw ==LB_ERR) break;
					if((int)dw >MAX_HQSEL_REC_COUNT)
					{
						wsprintf(tmp, "����ѡ�������ܳ���%d", MAX_HQSEL_REC_COUNT);
						ErrMsg(hDlg, tmp);
						break;
					}
					if(SendDlgItemMessage(hDlg, IDL_NOTSEL, LB_GETSELITEMS, (int)dw,
										(LPARAM)(int FAR *)&sel_num[0]) ==LB_ERR)
						break;
					
					for(i =0; i<(int)dw; i++)
					{
						if(SendDlgItemMessage(hDlg, IDL_NOTSEL, LB_GETTEXT, sel_num[i],
							(LPARAM)(LPSTR)tmp) ==LB_ERR)
						{
							ErrMsg(hDlg, "Error LB_GETTEXT");
							break;
						}
						SendDlgItemMessage(hDlg, IDL_SEL, LB_ADDSTRING, i,
							(LPARAM)(LPSTR)tmp);
					}
					for(i =(int)dw -1; i>=0; i--)
						SendDlgItemMessage(hDlg, IDL_NOTSEL, LB_DELETESTRING, sel_num[i], 0L);
					
					hctl =GetDlgItem(hDlg, IDOK);
					EnableWindow(hctl, TRUE);
				break;
			    
			    case IDC_DEL:
					dw =SendDlgItemMessage(hDlg, IDL_SEL, LB_GETSELCOUNT, 0, 0L);
					if(dw ==LB_ERR) break;
					if(SendDlgItemMessage(hDlg, IDL_SEL, LB_GETSELITEMS, (int)dw,
										(LPARAM)(int FAR *)&sel_num[0]) ==LB_ERR)
						break;
					
					for(i =0; i<(int)dw; i++)
					{
						if(SendDlgItemMessage(hDlg, IDL_SEL, LB_GETTEXT, sel_num[i],
							(LPARAM)(LPSTR)tmp) ==LB_ERR)
						{
							ErrMsg(hDlg, "Error LB_GETTEXT");
							break;
						}
						SendDlgItemMessage(hDlg, IDL_NOTSEL, LB_ADDSTRING, i,
							(LPARAM)(LPSTR)tmp);
					}
					for(i =(int)dw -1; i>=0; i--)
						SendDlgItemMessage(hDlg, IDL_SEL, LB_DELETESTRING, sel_num[i], 0L);
					
					hctl =GetDlgItem(hDlg, IDOK);
					EnableWindow(hctl, TRUE);
				break;
			    
				case IDOK:
					k =(int)SendDlgItemMessage(hDlg, IDL_SEL, LB_GETCOUNT, 0, 0L);
					if(k >MAX_HQSEL_REC_COUNT)
					{
						wsprintf(tmp, "����ѡ�������ܳ���%d", MAX_HQSEL_REC_COUNT);
						ErrMsg(hDlg, tmp);
						break;
					}
					
					for(i =0; i<k; i++)
					{
						if(SendDlgItemMessage(hDlg, IDL_SEL, LB_GETTEXT, i,
								(LPARAM)(LPSTR)tmp) ==LB_ERR)
						{
							ErrMsg(hDlg, "get list text failed!");
							break;
						}
						tok =strtok(tmp, "-");
						if(!tok)
							break;
						else tok =strtok(NULL, "-");
						if(!tok) break;
						HqSelData[SelNum].recNum[i] =atoi(tok);
					}
					HqSelData[SelNum].recCount =i;
					if(HqPaintData.type ==SelNum+2)
						SendMessage(ghWndHq, WM_HQSEL_RESET, SelNum+2, 0L);
				case IDCANCEL:
					EndDialog(hDlg, 0);
					ghDlgJy =NULL;
				break;
			break;
		}
	}
	
	return FALSE;
} 

LRESULT CALLBACK HqFldSelDlgProc(HWND hDlg, UINT message,
						WPARAM wParam, LPARAM lParam)
{
	int i, j;
	char tmp[256];
	DWORD dw;
	HWND hctl;
	LPSTR tok;
	
	switch(message)
	{
		case WM_INITDIALOG:
			ghDlgJy =hDlg;
			for(i =0; i<HqPaintData.fldCount; i++)
			{
				wsprintf(tmp, "%d-%s", HqPaintData.fldNum[i],
						HqTitles[HqPaintData.fldNum[i]]);
				SendDlgItemMessage(hDlg, IDL_SEL, LB_ADDSTRING,
					0, (LPARAM)(LPSTR)tmp);
			}
			for(i =0; i<HQ_FLDS_COUNT+1; i++)
			{
				wsprintf(tmp, "%d-%s", i, HqTitles[i]);
				for(j =0; j<HqPaintData.fldCount; j++)
				{
					if(HqPaintData.fldNum[j] ==i)
						break;
				}
				if(j ==HqPaintData.fldCount)
					SendDlgItemMessage(hDlg, IDL_NOTSEL, LB_ADDSTRING,
						0, (LPARAM)(LPSTR)tmp);
			}
		return TRUE;
		
		/*case WM_CTLCOLOR:
			SetBkMode((HDC)wParam, TRANSPARENT);
			if(HIWORD(lParam) == CTLCOLOR_LISTBOX)
					return (LRESULT)DrawChild((HDC)wParam, (HWND)LOWORD(lParam));
			return (LRESULT)(HBRUSH)GetStockObject(LTGRAY_BRUSH);
		break;
		
	case WM_NCACTIVATE:
		if(WinVer >3) break;
		DrawDlgFrame(hDlg, (BOOL)wParam, 1);
	return TRUE;

	case WM_NCPAINT:
		if(WinVer >3) break;
		DrawDlgFrame(hDlg, -1, 0);
	return TRUE;   
    */
		case WM_COMMAND:
			switch(wParam)
			{
				case IDC_ADD:
					dw =SendDlgItemMessage(hDlg, IDL_NOTSEL, LB_GETCURSEL, 0, 0L);
					if(dw ==LB_ERR) break;
					i =(int)dw;
					if(SendDlgItemMessage(hDlg, IDL_NOTSEL, LB_GETTEXT, i,
							(LPARAM)(LPSTR)tmp) ==LB_ERR)
					{
						ErrMsg(hDlg, "Error LB_GETTEXT");
						break;
					}
					SendDlgItemMessage(hDlg, IDL_SEL, LB_ADDSTRING, i,
						(LPARAM)(LPSTR)tmp);
					
					SendDlgItemMessage(hDlg, IDL_NOTSEL, LB_DELETESTRING, i, 0L);
					
					hctl =GetDlgItem(hDlg, IDOK);
					EnableWindow(hctl, TRUE);
				break;
			    
			    case IDC_DEL:
					dw =SendDlgItemMessage(hDlg, IDL_SEL, LB_GETCURSEL, 0, 0L);
					if(dw ==LB_ERR) break;
					i =(int)dw;
					if(SendDlgItemMessage(hDlg, IDL_SEL, LB_GETTEXT, i,
							(LPARAM)(LPSTR)tmp) ==LB_ERR)
					{
						ErrMsg(hDlg, "Error LB_GETTEXT");
						break;
					}
					SendDlgItemMessage(hDlg, IDL_NOTSEL, LB_ADDSTRING, i,
							(LPARAM)(LPSTR)tmp);
					SendDlgItemMessage(hDlg, IDL_SEL, LB_DELETESTRING, i, 0L);
					
					hctl =GetDlgItem(hDlg, IDOK);
					EnableWindow(hctl, TRUE);
				break;
			    
				case IDOK:
					j =(int)SendDlgItemMessage(hDlg, IDL_SEL, LB_GETCOUNT, 0, 0L);
					
					for(i =0; i<j; i++)
					{
						if(SendDlgItemMessage(hDlg, IDL_SEL, LB_GETTEXT, i,
								(LPARAM)(LPSTR)tmp) ==LB_ERR)
						{
							ErrMsg(hDlg, "get list text failed!");
							break;
						}
						tok =strtok(tmp, "-");
						if(!tok) break;
						HqPaintData.fldNum[i] =atoi(tok);
					}
					HqPaintData.fldCount =i;
					if(IsWindowVisible(ghWndHq))
						SendMessage(ghWndHq, WM_USER +1, 0, 0L);
				case IDCANCEL:
					EndDialog(hDlg, 0);
					ghDlgJy =NULL;
				break;
			break;
		}
	}
	
	return FALSE;
}

extern void WriteMsg(LPSTR);
BOOL ErrMsg(HWND hWnd, LPSTR msg)
{
	char tmp[256];
	HWND hwnd;
		
	WriteMsg(msg);
	if(strlen(msg)>=250) *(msg+250) =0;
	wsprintf(tmp, "����: %s", msg);
	if(ghDlgJy) hwnd =ghDlgJy;
	else if(hwnd ==NULL) hwnd =ghWndMain;
	else hwnd =hWnd;
	MessageBox(hwnd, tmp, APPNAME, MB_OK|MB_ICONSTOP);
	return FALSE;
}

BOOL GetInitString(char *Entry, char *Item, char *buf)
{
	GetPrivateProfileString(Entry, Item, "", buf, 256, "st_cl.ini");
	if(*buf ==0) return FALSE;
	return TRUE;
}

BOOL PutInitString(char *Entry, char *Item, char *buf)
{
	return WritePrivateProfileString(Entry, Item, buf, "st_cl.ini");
}

int CheckTime(BOOL fRead)
{
	char tmp[15];
	LPSTR tok;
	int tim, jys;
	static int recNum =0;
	BOOL fret =FALSE;
	
	_strtime(tmp);
	tok =strtok(tmp, ":");
	tim =atoi(tok)*60;
	tim +=atoi(strtok(NULL, ":"));
	tim -=1;
	for(jys =0; jys <2; jys++)
	{
		if(tim <HqTime[jys].am_min_start
				|| tim >HqTime[jys].pm_min_start+HqTime[jys].pm_min_count
				|| (tim <HqTime[jys].pm_min_start 
					&& tim >HqTime[jys].am_min_start+HqTime[jys].am_min_count))
		{
			//if(HqTime[jys].fRunning ==TRUE)
				//HqTime[jys].fRunning =FALSE;
		}
		else if(HqTime[jys].fRunning ==FALSE)
		{
			HqTime[jys].fRunning =TRUE;     
			if(fRead)
			{
			    //if(!gfConnecting&&gfOnLine)
			    //{
				//	if(UDP_Send_Hq00(0, TRUE, FALSE, FALSE, HqPaintData.curRecCount, &recNum)<0)
				//	{
				//		ErrMsg(ghWndMain, "UDP_Send_Hq00 failed");
				//		DestroyWindow(ghWndMain);
				//		return FALSE;
				//	}
				//}
				fret =TRUE;
			}
		}
	}
	return fret;
}

int SaveSet(void)
{
	int i, j;
	char tmp[6000], tmp1[256];
	
	for(i =0; i<5; i++)
	{
		sprintf(tmp, "%d,%d", HqSelData[i].jys, HqSelData[i].recCount);
		for(j =0; j<HqSelData[i].recCount; j++)
		{
			//HqData[HqSelData[i].jys].lpPreData[j].zqdm
			//sprintf(&tmp[strlen(tmp)], ",%d", HqSelData[i].recNum[j]);
			sprintf(&tmp[strlen(tmp)], ",%s", HqData[HqSelData[i].jys].lpPreData[HqSelData[i].recNum[j]].zqdm);
		}
		sprintf(tmp1, "HQSEL%d", i);
		PutInitString("HQSEL", tmp1, tmp);
	}
	sprintf(tmp, "%d", HqPaintData.fldCount);
	for(i =0; i<HqPaintData.fldCount; i++)
	{
		sprintf(&tmp[strlen(tmp)], ",%d", HqPaintData.fldNum[i]);
	}
	PutInitString("HQ", "FLDS", tmp);
	
	return 0;
}

int GetSet(void)
{
	int i ;//, j;
	char tmp[1000]; //, tmp1[20];
	LPSTR tok;
	        
	/*        
	for(i =0; i<5; i++)
	{
		sprintf(tmp1, "HQSEL%d", i);
		if(!GetInitString("HQSEL", tmp1, tmp))
		{
			HqSelData[i].recCount =0;
			continue;
		}
		if(!(tok =strtok(tmp, ","))) continue;;
		HqSelData[i].jys =atoi(tok);
		if(HqSelData[i].jys <0) HqSelData[i].jys =0;
		if(HqSelData[i].jys >=2) HqSelData[i].jys =1;
		if(!(tok =strtok(NULL, ","))) continue;
		HqSelData[i].recCount =atoi(tok);
		for(j =0; j<HqSelData[i].recCount; j++)
		{
			if(!(tok =strtok(NULL, ","))) break;
			HqSelData[i].recNum[j] =atoi(tok);
			
		}
		HqSelData[i].recCount =j;
	}
	*/
	if(!GetInitString("HQ", "FLDS", tmp))
	{
		HqPaintData.fldCount =0;
		return 0;
	}
	if(!(tok =strtok(tmp, ",")))
	{
		HqPaintData.fldCount =0;
		return 0;
	}
	HqPaintData.fldCount =atoi(tok);
	for(i =0; i<HqPaintData.fldCount; i++)
	{
		if(!(tok =strtok(NULL, ","))) break;
		HqPaintData.fldNum[i] =atoi(tok);
	}
	HqPaintData.fldCount =i;
	
	return 0;
}


int GetSelSet(void)
{
	int i, j,k;
	char tmp[6000], tmp1[20];
	LPSTR tok;
	
	for(i =0; i<5; i++)
	{
		sprintf(tmp1, "HQSEL%d", i);
		if(!GetInitString("HQSEL", tmp1, tmp))
		{
			HqSelData[i].recCount =0;
			continue;
		}
		if(!(tok =strtok(tmp, ","))) continue;;
		HqSelData[i].jys =atoi(tok);
		if(HqSelData[i].jys <0) HqSelData[i].jys =0;
		if(HqSelData[i].jys >=2) HqSelData[i].jys =1;
		if(!(tok =strtok(NULL, ","))) continue;
		HqSelData[i].recCount =atoi(tok);
		for(j =0; j<HqSelData[i].recCount; j++)
		{
			if(!(tok =strtok(NULL, ","))) break;
			HqData[HqSelData[i].jys].lpPreData[HqSelData[i].recNum[j]].zqdm;
			for(k=0;k<HqData[HqSelData[i].jys].recCount;k++)
			{
				if(strncmp(tok,HqData[HqSelData[i].jys].lpPreData[k].zqdm,
						strlen(tok))==0)
					break;				
			}     
			if(k<HqData[HqSelData[i].jys].recCount)
				HqSelData[i].recNum[j] =k;
			else
				continue;
			
		}
		HqSelData[i].recCount =j;
	}
	
	return 0;
}

BOOL RegisterChilds(void)
{
	if(!RegisterHq())
	{
		ErrMsg(NULL, "Error Register HQ");
		return FALSE;
	}
	
	if(!RegisterXlt())
	{
		ErrMsg(NULL, "Error Register JgGraph");
		return FALSE;
	}
	
	if(!RegisterJlt())
	{
		ErrMsg(NULL, "Error Register JltGraph");
		return FALSE;
	}
	
	if(!RegisterStatus())
	{
		ErrMsg(NULL, "Error Register Status");
		return FALSE;
	}
	
	if(!RegisterCaption())
	{
		ErrMsg(NULL, "Error Register Caption");
		return FALSE;
	}
	
	if(!RegisterMmp())
	{
		ErrMsg(NULL, "Error Register Mmp");
		return FALSE;
	}
	
	if(!RegisterCj())
	{
		ErrMsg(NULL, "Error Register Cj");
		return FALSE;
	}
	if(!RegisterLitHq())
	{
		ErrMsg(NULL, "Error Register LitHq");
		return FALSE;
	}
	if(!RegisterMaxMin())
	{
		ErrMsg(NULL, "Error Register LitHq");
		return FALSE;
	}
	if(!RegisterZs())
	{
		ErrMsg(NULL, "Error Register Zs");
		return FALSE;
	}
    if(!RegisterFx())
	{
		ErrMsg(NULL, "Error Register Fx");
		return FALSE;
	}
    if(!RegisterToolBar())
	{
		ErrMsg(NULL, "Error Register ToolBar");
		return FALSE;
	}
	if(!RegisterHelp())
	{
		ErrMsg(NULL, "Error Register Help");
		return FALSE;	
	}
	if(!RegisterMsg())
	{
		ErrMsg(NULL, "Error Register Msg");
		return FALSE;	
	}
	
	return TRUE;    
}

BOOL CreateChilds(HWND hWnd)
{
	if(!CreateWndHq(hWnd))
	{
		ErrMsg(hWnd, "CreateWndHq failed!");
		return FALSE;
	}
	if(!CreateWndStatus(hWnd))
	{
		ErrMsg(hWnd, "CreateWndStatus failed!");
		return FALSE;
	}
	if(!CreateWndCaption(hWnd))
	{
		ErrMsg(hWnd, "CreateWndCaption failed!");
		return FALSE;
	}
	if(!CreateWndXlt(hWnd))
	{
		ErrMsg(hWnd, "CreateWndXlt failed!");
		return FALSE;
	}
	if(!CreateWndJlt(hWnd))
	{
		ErrMsg(hWnd, "CreateWndJlt failed!");
		return FALSE;
	}
	if(!CreateWndMmp(hWnd))
	{
		ErrMsg(hWnd, "CreateWndMmp failed!");
		return FALSE;
	}
	if(!CreateWndCj(hWnd))
	{
		ErrMsg(hWnd, "CreateWndCj failed!");
		return FALSE;
	}
	if(!CreateWndLitHq(hWnd))
	{
		ErrMsg(hWnd, "CreateWndLitHq failed!");
		return FALSE;
	}
	if(!CreateWndMaxMin(hWnd))
	{
		ErrMsg(hWnd, "CreateWndMaxMin failed!");
		return FALSE;
	}
	if(!CreateWndZs(hWnd))
	{
		ErrMsg(hWnd, "CreateWndZs failed!");
		return FALSE;
	}
    if(!CreateWndFx(hWnd))
	{
		ErrMsg(hWnd, "CreateWndFx failed!");
		return FALSE;
    }
    if(!CreateToolBar(hWnd))
	{
		ErrMsg(hWnd, "CreateWnd ToolBar failed!");
		return FALSE;
    }
    if(!CreateWndHelp(hWnd))
	{
		ErrMsg(hWnd, "CreateWnd Help!");
		return FALSE;
    }
    if(!CreateWndMsg(hWnd))
	{
		ErrMsg(hWnd, "CreateWnd Msg!");
		return FALSE;
    }
	return TRUE;
}

void PASCAL ShowBmp(HDC hDC,HBITMAP hBmp,int left,int top,int width,int height)
{
  HDC hMemDC = CreateCompatibleDC(hDC);
  
  if(hBmp)
  {
    SelectObject(hMemDC,hBmp);
    BitBlt(hDC,left,top,width,height,hMemDC,0,0,SRCCOPY);
  }         
  DeleteObject(hMemDC);
}

void PASCAL ShowBmp1(HDC hDC,HBITMAP hBmp,int left,int top,int width,int height)
{
  BITMAP bmp;
  HDC hMemDC = CreateCompatibleDC(hDC);
  
  GetObject(hBmp, sizeof(BITMAP), &bmp);
  if(hBmp)
  {
    SelectObject(hMemDC,hBmp);
    StretchBlt(hDC,left,top,width,height,hMemDC,0,0,
			bmp.bmWidth, bmp.bmHeight,SRCCOPY);
  }         
  DeleteObject(hMemDC);
}

LRESULT CALLBACK HelpWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

BOOL RegisterHelp(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	wc.style =CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc =HelpWndProc;
	wc.lpszClassName ="HELP";
	wc.hbrBackground =GetStockObject(BLACK_BRUSH);
	wc.hInstance = ghInstance;
	wc.lpszMenuName = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	wc.hIcon = LoadIcon(ghInstance, MAKEINTRESOURCE(IDR_MAINFRAME));
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}


int LoadFile(char *filename,int sline,char *title)
{
    static char infile[80];
    ShowWindow(ghWndHelp,SW_SHOW);
    SetFocus(ghWndHelp);
	if(strlen(filename)!=0)
	{
    	strcpy(infile,filename);
    	SendMessage(ghWndHelp,WM_USER+2,(UINT)sline,(LPARAM)filename);
    }
    if(strlen(title)!=0)
    	SetWindowText(ghWndHelp,title);
 
    return 1;
}

#define		MAX_LINE_CHARS	200
#define		MAX_DISP_LINE	300
char *PageBuff[MAX_DISP_LINE];

int LoadPage(char *filename,int lstart,int lnum)
{
    
    FILE *fp;
    int i,j=0;
    char line[MAX_LINE_CHARS+1];
    
	fp=fopen(filename,"rt");
	if(fp==NULL)	 return -1;
	
	if(lnum ==0) lnum =MAX_DISP_LINE;
    for(i=0;i<lstart+lnum;i++)
    {
    	if(fgets(line,MAX_LINE_CHARS,fp)==NULL)
    		break;
    	if(i<lstart) continue;
    	if(PageBuff[j] ==NULL)
    		PageBuff[j] =(char *)GlobalAllocPtr(GHND,MAX_LINE_CHARS*sizeof(char));	
    	if(PageBuff[j]==NULL)
    		break;
    	memset(PageBuff[j],' ',MAX_LINE_CHARS);
    	strcpy(PageBuff[j++],line);
    }
	fclose(fp);
    return j;
}

extern int UDP_Send_Stock_Info(STOCK_INFO_FRAME *StockInfoFrame);


LRESULT CALLBACK HelpWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	RECT rc;
	static char file[256];
	static int sline=0,
			   TolNum=0,
			   minRange,maxRange,step,LinePerScr,CurSor=0;
	int pos;
    char line[256];
    int i,j;
    STOCK_INFO_FRAME StockInfo;
    HDC hdc;
    TEXTMETRIC tm;
	static int FontHeight;
	
	switch(message)
	{
		case WM_CREATE:
			hdc =GetDC(hWnd);
			SelectObject(hdc,GetStockObject(SYSTEM_FIXED_FONT));
			GetTextMetrics(hdc, &tm);
			FontHeight =tm.tmHeight;
			FontHeight +=FontHeight*15/100;
			ReleaseDC(hWnd, hdc);
		
			SetScrollRange(hWnd,SB_VERT,0,5000,TRUE);
			GetScrollRange(hWnd,SB_VERT,&minRange,&maxRange);			
			GetClientRect(hWnd, &rc);
			LinePerScr  =(rc.bottom -rc.top)/FontHeight;
			memset(PageBuff,0,sizeof(char *)*MAX_DISP_LINE);
		break;
		case WM_SIZE:
			GetClientRect(hWnd, &rc);
			LinePerScr  =(rc.bottom -rc.top)/FontHeight;
			if(TolNum>0)
				step = maxRange/TolNum;
		break;
		case WM_USER+2:
			strcpy(file,(LPSTR)lParam);
			TolNum=sline =CurSor=0;
			
			TolNum =LoadPage(file,sline,0);
			if(TolNum>0) 
			{
				step = maxRange/TolNum;
				InvalidateRect(ghWndHelp, NULL, TRUE);
			}
			else
				SetTimer(hWnd,1,1000,NULL);
			
		break;
		case WM_VSCROLL:
			pos=GetScrollPos(hWnd,SB_VERT);
			if(wParam==SB_BOTTOM)
				sline=TolNum -1;
			if(wParam==SB_LINEDOWN)
				if(sline<TolNum) sline++;
			if(wParam==SB_PAGEDOWN)
				if(sline+LinePerScr<=TolNum) sline+=LinePerScr;
			if(wParam==SB_PAGEUP)
			{
				if(sline -LinePerScr>=0) 
					sline -=LinePerScr;
				else 
					sline=0;			
			}
			if(wParam==SB_LINEUP) if(sline>0) sline--;
			if(wParam==SB_TOP) sline=0;
			pos=step*sline ;
			SetScrollPos(hWnd,SB_VERT,pos,TRUE);
			InvalidateRect(ghWndHelp, NULL, TRUE);
		break;
		case WM_KEYDOWN:
			if(wParam==VK_ESCAPE)
			{
				SetScrollPos(hWnd,SB_VERT,0,TRUE);
				ShowWindow(hWnd,SW_HIDE);
				KillTimer(hWnd,1);
				for(i=0;i<TolNum;i++) 
				{
					GlobalFreePtr(PageBuff[i]);
					PageBuff[i] =NULL;
				}
				TolNum=sline =CurSor=0;				
				break;
			}
			pos=GetScrollPos(hWnd,SB_VERT);

			if(wParam==VK_UP)
			{   
				if(TolNum>0)
				{
					hdc =GetDC(hWnd);
					SelectObject(hdc,GetStockObject(SYSTEM_FIXED_FONT));
					SetBkColor(hdc, RGB(0, 0, 0));				
					SetTextColor(hdc, RGB(10,150,100));
					TextOut(hdc,2,CurSor*FontHeight,PageBuff[sline+CurSor],
						strlen(PageBuff[sline+CurSor])-1);
						
			 		if(CurSor>0) CurSor--; 
					SetTextColor(hdc, RGB(0,255,255));
					TextOut(hdc,2,CurSor*FontHeight,PageBuff[sline+CurSor],
						strlen(PageBuff[sline+CurSor])-1);
						
			 		ReleaseDC(hWnd,hdc);
			 	}
			 	break;
			}
			
			if(wParam==VK_DOWN) 
			{   
				if(TolNum>0)
				{
					hdc =GetDC(hWnd);	
					SelectObject(hdc,GetStockObject(SYSTEM_FIXED_FONT));
					SetBkColor(hdc, RGB(0, 0, 0));				
					SetTextColor(hdc, RGB(10,150,100));
					TextOut(hdc,2,CurSor*FontHeight,PageBuff[sline+CurSor],
						strlen(PageBuff[sline+CurSor])-1);			
					
					if(CurSor<LinePerScr &&CurSor +sline <TolNum-1) 
						CurSor++;
					SetTextColor(hdc, RGB(0,255,255));
					TextOut(hdc,2,CurSor*FontHeight,PageBuff[sline+CurSor],
						strlen(PageBuff[sline+CurSor])-1);						
			 		ReleaseDC(hWnd,hdc);
				}
				break;
			}
			
			if(wParam==VK_NEXT)
			{   
				if(TolNum>0)
				{
					CurSor =0;
					if(sline+LinePerScr<TolNum)
						sline+=LinePerScr;
					else
					{
						sline =TolNum -LinePerScr -1;
						if(sline <0) sline =0;
					}
				}
			}
			if(wParam==VK_PRIOR)
			{
				if(TolNum>0)
				{
					CurSor =LinePerScr -1;
					if(sline -LinePerScr>=0) 
						sline -=LinePerScr;
					else 
						sline=0;
				}
			}
			if(wParam ==VK_RETURN)
			{   
			
				if(TolNum>0)
				{
					if(strstr(strupr(file),"IDX")!=NULL)
			        {
						StockInfo.type= 2;
						strncpy(line,PageBuff[sline+CurSor],12);
						line[12] =0;
						for(i=0;i<12;i++)
						{
							if(line[i]!=' ') break;
						}
						if(i<12)
						{
							strcpy(StockInfo.name,&line[i]);
			    			sprintf(file,"%s\\%s",szDataPath,&line[i]);
			    			TolNum=sline =CurSor=0;
			    			UDP_Send_Stock_Info(&StockInfo);
			    			SetTimer(hWnd,1,3000,NULL);
			    		}
			    	}
			    }
			}
			pos=step*sline ; 
			SetScrollPos(hWnd,SB_VERT,pos,TRUE);
			InvalidateRect(ghWndHelp, NULL, TRUE);
		break;
		case WM_TIMER:
			KillTimer(hWnd,1);
			TolNum =LoadPage(file,sline,0);
			if(TolNum>0) 
			{
				step = maxRange/TolNum;
				InvalidateRect(ghWndHelp, NULL, TRUE);
			}
			else
				SetTimer(hWnd,1,1000,NULL);
		break;
		//case WM_KILLFOCUS:
		//	KillTimer(hWnd,1);
		//break;
		case WM_PAINT:
			BeginPaint(hWnd, &ps);
			SelectObject(ps.hdc,GetStockObject(SYSTEM_FIXED_FONT));
			SetBkColor(ps.hdc, RGB(0, 0, 0));
			
    		for(i=sline,j=0;i<TolNum&&i<=LinePerScr+sline;i++,j++)
    		{
    			memset(line,' ',256);
    			TextOut(ps.hdc,2,j*FontHeight,line,256);
    				
    			if(j==CurSor)
    				SetTextColor(ps.hdc, RGB(0,255,255));
    			else
    				SetTextColor(ps.hdc, RGB(10,150,100));
    			TextOut(ps.hdc,2,j*FontHeight,PageBuff[i],strlen(PageBuff[i])-1);
    		}
			EndPaint(hWnd, &ps);
		break;
		case WM_DESTROY:		
			KillTimer(hWnd,1);
		break;
		default:
		break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}


BOOL CreateWndHelp(HWND hWnd)
{                          
	int x ;
	HWND hwnd;
	RECT rc;	
	
	GetClientRect(ghWndMain, &rc);		
	x =GetSystemMetrics(SM_CXSCREEN);
		
	if(ghWndHelp ==NULL)
	{
		hwnd =CreateWindow("HELP", "���߰���[ESC�˳�]", WS_POPUP|WS_CAPTION|WS_HSCROLL|WS_VSCROLL|WS_THICKFRAME,
						0, 
						STATUS_HEIGHT-2+TOOLBAR_HEIGHT,
						x, 
						rc.bottom -rc.top -STATUS_HEIGHT*2-TOOLBAR_HEIGHT+2,
						NULL, NULL, ghInstance, NULL);
		if(hwnd ==NULL)
		{
			ErrMsg(hWnd, "Error create help window");
			return FALSE;
		}
	
		ghWndHelp =hwnd;
		ShowWindow(hwnd, SW_HIDE);
	}
	return TRUE;
}
    
int ReCreateChild(void)
{
	PostMessage(ghWndHq,WM_CLOSE,0,0L);
	PostMessage(ghWndStatus,WM_CLOSE,0,0L);
	//PostMessage(ghWndCaption,WM_CLOSE,0,0L);
	PostMessage(ghWndXlt,WM_CLOSE,0,0L);
	PostMessage(ghWndJlt,WM_CLOSE,0,0L);
	PostMessage(ghWndMmp,WM_CLOSE,0,0L);
	PostMessage(ghWndCj,WM_CLOSE,0,0L);
	PostMessage(ghWndLitHq,WM_CLOSE,0,0L);
	PostMessage(ghWndMaxMin,WM_CLOSE,0,0L);
	PostMessage(ghWndZs,WM_CLOSE,0,0L);
	PostMessage(ghWndFx,WM_CLOSE,0,0L);
	ghWndHq=ghWndXlt=ghWndJlt=ghWndMmp=NULL;
	ghWndCj = ghWndLitHq =ghWndMaxMin =ghWndZs =NULL;
	ghWndFx =NULL;
	ghWndStatus =NULL;
	//PostMessage(ghWndToolBar,WM_CLOSE,0,0L);	
	if(!CreateChilds(ghWndMain)) 
		return -1;
    else
     	return 0;
}