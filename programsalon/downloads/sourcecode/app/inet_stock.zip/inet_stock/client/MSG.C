#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <string.h>
#include "appmain.h"
#include "resource.h"
#include "msg.h"

HWND ghWndMsg=NULL;
char MsgInfo[100];

LRESULT CALLBACK _export MsgWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

BOOL RegisterMsg(void)
{
	WNDCLASS wc;
	
	memset(&wc, 0, sizeof(wc));
	wc.style =CS_SAVEBITS;
	wc.lpfnWndProc =MsgWndProc;
	wc.lpszClassName ="MSG";
	wc.hbrBackground =GetStockObject(LTGRAY_BRUSH);
	wc.hInstance = ghInstance;
	wc.lpszMenuName = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);        
	wc.hIcon = LoadIcon(ghInstance, MAKEINTRESOURCE(IDR_MAINFRAME));
	if(!RegisterClass(&wc)) return FALSE;
	
	return TRUE;
}

int Msg(char *msg,int type)
{
    if(type&MSG_VERT|type&MSG_HORT&&strlen(msg)!=0)
    {    
    	strcpy(MsgInfo,msg);    	    	
    	InvalidateRect(ghWndMsg,NULL, TRUE);
    }    
    if(type&MSG_HIDE)
    {
    	strcpy(MsgInfo,"");    	    	
    	InvalidateRect(ghWndMsg,NULL, TRUE);    
    }
    if(type&MSG_FOCU)
    {
    	EnableWindow(ghWndMsg,TRUE);
    	SetFocus(ghWndMsg);
    }
	return TRUE;
}

LRESULT CALLBACK  MsgWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	static LastWin =NULL;
	RECT rc,rc1;
	HPEN hPen;
	
	switch(message)
	{
		case WM_TIMER:
			KillTimer(hWnd,1);
			ShowWindow(hWnd,SW_HIDE);
			if(IsWindowEnabled(hWnd)&&LastWin!=NULL)
			{    
				SetFocus(LastWin);
				EnableWindow(hWnd,FALSE);
				SendMessage(LastWin,WM_KEYDOWN,VK_RETURN,0L);
			}
		break;
		case WM_CHAR:
			SendMessage(hWndInput, WM_CHAR, wParam, lParam);
		break;
		case WM_SIZE:
			if(IsWindowVisible(hWnd))
				InvalidateRect(hWnd, NULL, TRUE);		
		break;
		case WM_CTLCOLOR:
       		switch(HIWORD(lParam))
       		{
            	case CTLCOLOR_EDIT:
            	case CTLCOLOR_LISTBOX:
               		SetTextColor((HDC) wParam, RGB(255, 0, 255));
                	SetBkMode((HDC) wParam, TRANSPARENT);
                	return (LRESULT) GetStockObject(LTGRAY_BRUSH);
        	}
        	return (LRESULT) NULL;		
		break;		
		case WM_PAINT:
			GetClientRect(hWnd, &rc);	
			hdc =BeginPaint(hWnd,&ps);
			
			SelectObject(hdc,GetStockObject(WHITE_PEN));			
		    MoveTo(hdc,1,rc.bottom-1);
		    LineTo(hdc,rc.right-8-INPUT_WIDTH,rc.bottom-1);
			LineTo(hdc,rc.right-8-INPUT_WIDTH,1);
		    hPen=CreatePen(PS_SOLID,1,RGB(65,65,65));		    	
		    SelectObject(hdc,hPen);
		    LineTo(hdc,1,1);
			LineTo(hdc,1,rc.bottom-1);
			
			SelectObject(hdc,GetStockObject(WHITE_PEN));
			MoveTo(hdc,rc.right-3-INPUT_WIDTH,rc.bottom-1);
			LineTo(hdc,rc.right-3+1,rc.bottom-1);
			LineTo(hdc,rc.right-3+1,1);
			SelectObject(hdc,hPen);
			LineTo(hdc,rc.right-3-INPUT_WIDTH,1);
			LineTo(hdc,rc.right-3-INPUT_WIDTH,rc.bottom-1);
			SelectObject(hdc,GetStockObject(WHITE_PEN));
			DeleteObject(hPen);
						
			SelectObject(hdc,GetStockObject(SYSTEM_FIXED_FONT));
			SetBkMode(hdc,TRANSPARENT);
			SetTextColor(hdc,RGB(0,0,255));
			
			SetRect(&rc1,1,1,rc.right-8-INPUT_WIDTH-1,rc.bottom-1);
			ExtTextOut(hdc,2,2,ETO_CLIPPED,&rc1,MsgInfo,strlen(MsgInfo),
				(LPINT) NULL);	
			
			EndPaint(hWnd, &ps);
		break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}


BOOL CreateWndMsg(HWND hWnd)
{                          
	int x, y;
	HWND hwnd;                    
	RECT rc;
		
	GetClientRect(ghWndMain, &rc);	
	x =rc.right -rc.left;
	y =rc.bottom -rc.top;

	if(ghWndMsg==NULL)
	{
		hwnd =CreateWindow("MSG", NULL, WS_CHILD,
						0, 
						rc.bottom -MSG_HEIGHT, 
						x,
						MSG_HEIGHT,
						ghWndMain, NULL, ghInstance, NULL);
		
		if(hwnd ==NULL)
		{
			ErrMsg(hWnd, "Error create msg window");
			return FALSE;	
		}
	    ShowWindow(hwnd, SW_SHOW);
		ghWndMsg =hwnd;
		
		hWndInput =CreateWindow("EDIT", "", WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL,
						x-INPUT_WIDTH-2,
						2,
						INPUT_WIDTH,
						MSG_HEIGHT-4,
						hwnd, NULL, ghInstance, NULL);
		SendMessage(hWndInput, EM_LIMITTEXT, 16, 0L);		
	}
	else
	{
		SetWindowPos(ghWndMsg, (HWND)NULL,
		    0,
			rc.bottom -MSG_HEIGHT, 
			x,
			MSG_HEIGHT,
			NULL);	
		SetWindowPos(hWndInput, (HWND)NULL,
			x-INPUT_WIDTH-2,
			2,
			INPUT_WIDTH,
			MSG_HEIGHT-4,
			NULL);			
	}
	return TRUE;
}
