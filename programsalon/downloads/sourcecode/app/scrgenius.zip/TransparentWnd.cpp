//********************************************************************************
//* TransparentWindow.CPP
//*
//* A transparent window class.
//*
//* Based on the idea of Jason Wylie
//*
//* (C) 1998 by Franz Polzer
//*
//* Visit me at:	stud1.tuwien.ac.at/~e9225140
//* Write to me:	e9225140@student.tuwien.ac.at
//********************************************************************************

/*
modified by wenyy ������
add timer switcher to deal with current event
visit me at : http://vchelp.163.net
write to me : wyy_cq@21cn.com

*/
#include "stdafx.h"
#include "TransparentWnd.h"
#include <assert.h>
#include "ScrGenius.h"
#include "ScrGeniusDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define TIMER_SET			1
#define TIMER_WALK			2
#define TIMER_IDLE			3
#define TIMER_RUN			4
#define TIMER_HIDE			5
#define TIMER_SHOW			6
#define TIMER_WAITSHOW		7

//********************************************************************************
//* Constructor
//********************************************************************************

CTransparentWnd::CTransparentWnd()
{
	m_iAniSeq=0;
	m_fontLogo.CreateFont(13, 0, 0, 0, FW_NORMAL, 0, 0,0,0,0,0,0,0, "����");
}


//********************************************************************************
//* Destructor
//********************************************************************************

CTransparentWnd::~CTransparentWnd()
{
}


BEGIN_MESSAGE_MAP(CTransparentWnd, CWnd)
	//{{AFX_MSG_MAP(CTransparentWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_CREATE()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


//********************************************************************************
//* CreateTransparent()
//*
//* Creates the main application window transparent
//********************************************************************************
void CTransparentWnd::CreateTransparent(LPCTSTR pTitle, RECT &rect)
{
	CreateEx(	0,
		AfxRegisterWndClass(0,AfxGetApp()->LoadStandardCursor(IDC_ARROW)),
						pTitle,
						WS_POPUP | WS_SYSMENU,
						rect,
						NULL,
						NULL,
						NULL );
	Reset();
//	m_bmpDraw.LoadBitmap(MaskID);
//	SetupRegion(GetWindowDC(), MaskID);
}

//********************************************************************************
//* SetupRegion()
//*
//* Set the Window Region for transparancy outside the mask region
//********************************************************************************
void CTransparentWnd::SetupRegion(CDC *pDC)
{
	CDC					memDC;
	CBitmap			&cBitmap=m_bmpDraw;
	CBitmap*		pOldMemBmp = NULL;
	COLORREF		col,colMask;
	CRect				cRect;
	int					x, y;
	CRgn				wndRgn, rgnTemp;

	GetWindowRect(&cRect);
	CPoint ptOrg=cRect.TopLeft();

	BITMAP bmInfo;
	cBitmap.GetObject(sizeof(bmInfo),&bmInfo);
	CRect rcNewWnd=CRect(ptOrg,CSize(bmInfo.bmWidth,bmInfo.bmHeight));

	memDC.CreateCompatibleDC(pDC);
	pOldMemBmp = memDC.SelectObject(&cBitmap);
	colMask=memDC.GetPixel(0,0);

	wndRgn.CreateRectRgn(0, 0, rcNewWnd.Width(), rcNewWnd.Height());
	for(x=0; x<=rcNewWnd.Width(); x++)
	{
		for(y=0; y<=rcNewWnd.Height(); y++)
		{
			col = memDC.GetPixel(x, y);
			if(col == colMask)
			{
				rgnTemp.CreateRectRgn(x, y, x+1, y+1);
				wndRgn.CombineRgn(&wndRgn, &rgnTemp, RGN_XOR);
				rgnTemp.DeleteObject();	
			}
		}
	}
	if (pOldMemBmp) memDC.SelectObject(pOldMemBmp);
	SetWindowRgn((HRGN)wndRgn, TRUE);
	MoveWindow(rcNewWnd);
}

void CTransparentWnd::Reset(void)
{
	char szBmp[20];
	sprintf(szBmp,"VCHELP");
	m_bmpDraw.DeleteObject();
	m_bmpDraw.LoadBitmap(szBmp);
	CWindowDC dc(this);
	SetupRegion(&dc);
	Invalidate();
}

void CTransparentWnd::DoSet(void)
{
	int iSW=GetSystemMetrics(SM_CXFULLSCREEN);
	int iSH=GetSystemMetrics(SM_CYFULLSCREEN);

	KillTimer(1);
	SetTimer(2,1000,NULL);

}

void CTransparentWnd::DoWalk(void)
{
	CRect rcW;
	GetWindowRect(rcW);

	if(rcW.left<200) xcounter=5;
	if(rcW.top<200) ycounter=5;
	if(rcW.left>600) xcounter=-5;
	if(rcW.top>400) ycounter=-5;

	CPoint ptOffset(xcounter,ycounter);
 	rcW+=ptOffset;
	MoveWindow(rcW);

	char szBmp[20];
	sprintf(szBmp,"WALK%d",m_iAniSeq%5+1);
	m_iLastDirection=1;

	m_bmpDraw.DeleteObject();
	m_bmpDraw.LoadBitmap(szBmp);
	CWindowDC dc(this);
	SetupRegion(&dc);
	Invalidate();
}


//********************************************************************************
//* CTransparentWnd message handlers
//********************************************************************************

void CTransparentWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CWnd::OnLButtonDown(nFlags, point);
	PostMessage(WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM(point.x,point.y));
}

int CTransparentWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	xcounter=5,ycounter=5;
	SetTimer(1,300,NULL);
	SetWindowPos(&wndTopMost,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);
	return 0;
}

BOOL CTransparentWnd::OnEraseBkgnd(CDC* pDC) 
{
	CRect	rect;
	GetWindowRect(&rect);

	CDC memDC;
	CBitmap			&cBitmap=m_bmpDraw;;
	CBitmap*		pOldMemBmp = NULL;
	CFont* pOldMemFont=NULL;

	memDC.CreateCompatibleDC(pDC);
	pOldMemBmp = memDC.SelectObject(&cBitmap);
	pDC->BitBlt(0, 0, rect.Width(), rect.Height(), &memDC, 0, 0, SRCCOPY);

	if (pOldMemBmp) memDC.SelectObject( pOldMemBmp );

	return TRUE;
}

void CTransparentWnd::OnPaint()
{
	CPaintDC dc(this);
	// Add your drawing code here!
}


void CTransparentWnd::OnTimer(UINT nIDEvent) 
{
	
	switch(nIDEvent)
	{
	case(1)://judge
		DoSet();
		break;
	case(2)://walk
		DoWalk();
		break;
	default:
		break;
	}
	m_iAniSeq++;

	CWnd::OnTimer(nIDEvent);
}

void CTransparentWnd::OnDestroy() 
{
	CWnd::OnDestroy();
}

void CTransparentWnd::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CWnd::OnRButtonDown(nFlags, point);
	CScrGeniusDlg dlg;
	if(IDOK!=dlg.DoModal())
		DestroyWindow();
}
