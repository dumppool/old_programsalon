// EWordView.h : interface of the CEWordView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_EWORDVIEW_H__C8E0A8B1_42A1_11D2_AF1B_001A48C10500__INCLUDED_)
#define AFX_EWORDVIEW_H__C8E0A8B1_42A1_11D2_AF1B_001A48C10500__INCLUDED_

#include "WordData.h"	// Added by ClassView
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CEWordSet;

class CEWordView : public CDaoRecordView
{
protected: // create from serialization only
	CEWordView();
	DECLARE_DYNCREATE(CEWordView)

public:
	//{{AFX_DATA(CEWordView)
	enum { IDD = IDD_EWORD_FORM };
	CEWordSet* m_pSet;
	CString	m_Meaning;
	CString	m_Spell;
	//}}AFX_DATA

// Attributes
public:
	CEWordDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEWordView)
	public:
	virtual CDaoRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnMove(UINT nIDMoveCommand);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	
	void OptionInit();
	OptionData Option;
	virtual ~CEWordView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CEWordView)
	afx_msg void OnRecordAdd();
	afx_msg void OnChangeMeans();
	afx_msg void OnRecordDelete();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnWordStudy();
	afx_msg void OnWordReview();
	afx_msg void OnOption();
	afx_msg BOOL OnAddOk();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnChangeWord();
	afx_msg void OnAddCancel();
	afx_msg void OnHelp();
	afx_msg void JSAddWord();
    afx_msg void ShowSmall();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString m_TempString;
	CMenu* pMenu;
	BOOL m_bAdding;
};

#ifndef _DEBUG  // debug version in EWordView.cpp
inline CEWordDoc* CEWordView::GetDocument()
   { return (CEWordDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EWORDVIEW_H__C8E0A8B1_42A1_11D2_AF1B_001A48C10500__INCLUDED_)
