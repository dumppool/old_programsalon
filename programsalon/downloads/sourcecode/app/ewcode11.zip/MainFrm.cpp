// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "EWord.h"
#include "FlashDlg.h"

#include "MainFrm.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define WM_LIBEN WM_USER+101

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code !
    ON_WM_CREATE()
    ON_MESSAGE(WM_LIBEN,OnLiben)
    ON_COMMAND(ID_APP_EXIT, OnAppExit)
	ON_COMMAND(ID_DISPLAY,OnShowMyWindow)
	ON_WM_SYSCOMMAND() 
    	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	CFlashDlg dlg;
	dlg.DoModal();
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
   
   NOTIFYICONDATA tnd;
    tnd.cbSize=sizeof(NOTIFYICONDATA);

     tnd.hWnd=this->m_hWnd;

     tnd.uID=IDR_CON2;

    tnd.uFlags=NIF_MESSAGE|NIF_ICON|NIF_TIP;

     tnd.uCallbackMessage=WM_LIBEN;

     tnd.hIcon=LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_CON2));

    strcpy(tnd.szTip,"EWord2000");

    Shell_NotifyIcon(NIM_ADD,&tnd);
   	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	
		if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	
	       cs.style=WS_POPUP;
           cs.dwExStyle |=WS_EX_TOOLWINDOW;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

void CMainFrame::OnAppExit() 
{
	// TODO: Add your command handler code here
	NOTIFYICONDATA tnid;

tnid.cbSize=sizeof(NOTIFYICONDATA);

tnid.hWnd=this->m_hWnd;

tnid.uID=IDR_CON2;//��֤ɾ���������ǵ�ͼ��

Shell_NotifyIcon(NIM_DELETE,&tnid);

AfxPostQuitMessage(0);

}
void CMainFrame::OnLiben(WPARAM wParam,LPARAM lParam)

{

UINT uID;//��������Ϣ��ͼ���ID

UINT uMouseMsg;//��궯��

POINT pt;

uID=(UINT) wParam;

uMouseMsg=(UINT) lParam;
CMenu menu;
if(uMouseMsg==WM_RBUTTONDOWN)//����ǵ����Ҽ�

{

switch(uID)

{

case IDR_CON2://��������ǵ�ͼ��

GetCursorPos(&pt);//ȡ�����λ��
//ִ����Ӧ����
    menu.LoadMenu(IDR_BEGINMENU);
    pMenu=menu.GetSubMenu(0);
    ASSERT(pMenu!=0);
    pMenu->TrackPopupMenu (0,pt.x,pt.y,this);
   	break;
default:
	break;
}
}
return; 

}

void CMainFrame::OnShowMyWindow()
{
 //CREATESTRUCT cs ; 
  
  // cs.style = WS_OVERLAPPEDWINDOW;
    ModifyStyle(WS_POPUP,
		WS_CAPTION|FWS_PREFIXTITLE|WS_SYSMENU|
	WS_MINIMIZEBOX|WS_MAXIMIZEBOX);
	ModifyStyleEx(WS_EX_TOOLWINDOW,WS_EX_TOPMOST);
    ShowWindow(SW_SHOWMAXIMIZED);
	//UpdateWindow();

	
    GetWindowRect(&rect);
	rect.left =rect.right /6;
	rect.top=rect.bottom /6;
	rect.right=rect.right*5/6;
	rect.bottom=rect.bottom*5/6;
	ShowWindow(SW_NORMAL);
	MoveWindow(&rect,TRUE);
     UpdateWindow();
}

void CMainFrame::OnSysCommand( UINT nID, LPARAM lParam )
{
  switch(nID)
  {
  case SC_RESTORE:   
        MoveMyWindow();
	     break;
  case  SC_MINIMIZE:
         ShowWindow(SW_HIDE);
	     ModifyStyle(WS_CAPTION|FWS_PREFIXTITLE|WS_SYSMENU|
	     WS_MINIMIZEBOX|WS_MAXIMIZEBOX,WS_POPUP);
	     ModifyStyleEx(WS_EX_TOPMOST,WS_EX_TOOLWINDOW);
	break;
	     default:
		 Default();
         break;
   
  }
}
void CMainFrame::MoveMyWindow()
{
    ShowWindow(SW_NORMAL);
	MoveWindow(&rect,TRUE);
	UpdateWindow();
}
void CMainFrame::OnAddWord()
{
OnShowMyWindow();
}
/*
void CMainFrame::OnSysCommand( UINT nID, LPARAM lParam )
{
  switch(nID)
  {
    case ID_ADD_WORD:
        ShowWindow(SW_NORMAL); 
	    //PostMessage(ID_ADD_WORD);
		 break;
	     default:
		 Default();
         break;
   
  }
}*/


/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers



