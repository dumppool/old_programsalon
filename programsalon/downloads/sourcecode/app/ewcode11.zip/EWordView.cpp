// EWordView.cpp : implementation of the CEWordView class
//
#include <afxwin.h>
#include "stdafx.h"
#include "EWord.h"
#include "afx.h"
#include "EWordSet.h"
#include "EWordDoc.h"
#include "EWordView.h"
#include "MainFrm.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#include "Studydlg.h"
#include "Reviewdlg.h"
#include "OptionDlg.h"
/////////////////////////////////////////////////////////////////////////////
// CEWordView

IMPLEMENT_DYNCREATE(CEWordView, CDaoRecordView)

BEGIN_MESSAGE_MAP(CEWordView, CDaoRecordView)
	//{{AFX_MSG_MAP(CEWordView)
	ON_COMMAND(ID_RECORD_ADD, OnRecordAdd)
	ON_EN_CHANGE(IDC_MEANS, OnChangeMeans)
	ON_COMMAND(ID_RECORD_DELETE, OnRecordDelete)
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_WORD_STUDY, OnWordStudy)
	ON_COMMAND(ID_WORD_REVIEW, OnWordReview)
	ON_COMMAND(IDC_OPTION, OnOption)
	ON_BN_CLICKED(IDC_ADD_OK, OnAddOk)
	ON_WM_RBUTTONDOWN()
	ON_EN_CHANGE(IDC_WORD, OnChangeWord)
	ON_BN_CLICKED(IDC_ADD_CANCEL, OnAddCancel)
	ON_COMMAND(ID_HELP, OnHelp)
	ON_COMMAND(ID_ADD_WORD,JSAddWord)
	ON_COMMAND(ID_SHOWMINAL,ShowSmall)
	ON_WM_TIMER()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CDaoRecordView::OnFilePrintPreview)
   
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEWordView construction/destruction

CEWordView::CEWordView()
	: CDaoRecordView(CEWordView::IDD)
{
	//{{AFX_DATA_INIT(CEWordView)
	m_pSet = NULL;
	m_Meaning = _T("");
	m_Spell = _T("");
	//}}AFX_DATA_INIT
	// TODO: add construction code here
   m_bAdding=FALSE;
   CFile File;
   if(File.Open("Option.sav",CFile::modeRead))
   {
	   File.Read(&Option,sizeof(Option));
   }
   	else
   {
	 OptionInit();
	}

}

CEWordView::~CEWordView()
{
}

void CEWordView::DoDataExchange(CDataExchange* pDX)
{
	CDaoRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEWordView)
	DDX_Text(pDX, IDC_MEANS, m_Meaning);
	DDX_Text(pDX, IDC_WORD, m_Spell);
	//}}AFX_DATA_MAP
}

BOOL CEWordView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CDaoRecordView::PreCreateWindow(cs);
}

void CEWordView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_eWordSet;
	CDaoRecordView::OnInitialUpdate();
}

/////////////////////////////////////////////////////////////////////////////
// CEWordView printing

BOOL CEWordView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CEWordView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CEWordView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CEWordView diagnostics

#ifdef _DEBUG
void CEWordView::AssertValid() const
{
	CDaoRecordView::AssertValid();
}

void CEWordView::Dump(CDumpContext& dc) const
{
	CDaoRecordView::Dump(dc);
}

CEWordDoc* CEWordView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEWordDoc)));
	return (CEWordDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEWordView database support
CDaoRecordset* CEWordView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CEWordView message handlers

void CEWordView::OnRecordAdd() 
{
	// TODO: Add your command handler code here
	
   // m_pSet->AddNew();
    m_bAdding = TRUE;
	CButton *pb=(CButton*)GetDlgItem(IDC_ADD_OK);
	pb->ShowWindow(SW_SHOW);
	//pb->SetReadOnly(FALSE);
	pb=(CButton*)GetDlgItem(IDC_ADD_CANCEL);
    pb->ShowWindow(SW_SHOW);
//	pb->SetReadOnly(FALSE);
    CEdit* pCtrl = (CEdit*)GetDlgItem(IDC_WORD);
    pCtrl->SetReadOnly(FALSE);
    pCtrl->SetWindowText("");
	pCtrl = (CEdit*)GetDlgItem(IDC_MEANS);
     pCtrl->SetReadOnly(FALSE);
   //UpdateData(FALSE);
	pCtrl->SetWindowText("");
	

}

BOOL CEWordView::OnMove(UINT nIDMoveCommand) 
{
	// TODO: Add your specialized code here and/or call the base class
	 
     if (m_bAdding)
     {
		 CEdit *pCtrl=(CEdit*)GetDlgItem(IDC_WORD);
		 CString s;
		 pCtrl->GetWindowText(s);
		 
         if(s.GetLength()<1)
			 return(FALSE);
		  pCtrl=(CEdit*)GetDlgItem(IDC_MEANS);

		 pCtrl->GetWindowText(s);
		 
         if(s.GetLength()<1)
			 return(FALSE);
		 m_bAdding = FALSE;
         UpdateData(TRUE);
		 m_pSet->m_column4=0;
		 m_pSet->m_column5=0;
		 COleDateTime time;
		 time=time.GetCurrentTime();
		 m_pSet->m_column3=time;
         if (m_pSet->CanUpdate())
             m_pSet->Update();
         m_pSet->Requery();
         UpdateData(FALSE);
          pCtrl = (CEdit*)GetDlgItem(IDC_WORD);
         pCtrl->SetReadOnly(TRUE);
		 pCtrl = (CEdit*)GetDlgItem(IDC_MEANS);
         pCtrl->SetReadOnly(TRUE);

         return TRUE;
     }
     else

	 if(CDaoRecordView::OnMove(nIDMoveCommand))
	 {
		 m_Spell=m_pSet->m_column1;
		 m_Meaning=m_pSet->m_column2;
		 UpdateData(FALSE);
	     return(TRUE);
	 }
	 else return(FALSE);
}

void CEWordView::OnChangeMeans() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CRecordView::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	
	if(!m_bAdding)return;
    
	 CEdit* pNewWord = (CEdit*)GetDlgItem(IDC_MEANS);
	 CString m_NewWord;
	 pNewWord->GetWindowText(m_NewWord);
	int i=m_NewWord.Find(':');
	if(i>2)
	{
	m_Spell=m_NewWord.Left(i-1);
	//CEdit * pWord=(CEdit*)GetDlgItem(IDC_WORD);
	//pWord->SetWindowText(m_Word);
	int j;
	j=m_NewWord.GetLength();
	if(i>2&&j>4)
	{
	m_Meaning=m_NewWord.Right(j-i-2);
	//CEdit * pMeans=(CEdit*)GetDlgItem(IDC_MEANS);
	//pMeans->SetWindowText(m_Means);
	}
	UpdateData(FALSE); 
	}
}

void CEWordView::OnRecordDelete() 
{										
	// TODO: Add your command handler code here
  if(m_pSet->m_column1=="Chenshengli"|m_pSet->m_column1=="EWord2000")
  {
	  MessageBox("����ɾ��������");
  return;
  }
  m_pSet->Delete();
  m_pSet->MoveNext();
  if (m_pSet->IsEOF())
  m_pSet->MoveLast();
  if (m_pSet->IsBOF())
  m_pSet->SetFieldNull(NULL);
        m_Spell=m_pSet->m_column1;
		 m_Meaning=m_pSet->m_column2;
		  UpdateData(FALSE);	
}

void CEWordView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	// PostMessage(ID_RECORD_ADD,0,0);
	 OnRecordAdd();
	CDaoRecordView::OnLButtonDblClk(nFlags, point);
}

void CEWordView::OnWordStudy() 
{
	// TODO: Add your command handler code here
    CStudyDlg dlg(m_pSet);
	dlg.StudyNumber=Option.StudyNumber;
	if(dlg.DoModal()==IDOK)
	{
	}
	else
	{
	}
}

void CEWordView::OnWordReview() 
{
	// TODO: Add your command handler code here
	CReviewDlg dlg(Option,m_pSet);
	if(dlg.DoModal()==IDOK)
	{
	}
}

void CEWordView::OnOption() 
{
	// TODO: Add your command handler code here
	COptionDlg dlg(Option);
	if(dlg.DoModal()==IDOK)
	{
		
		Option=dlg.Option;
		  CFile File;
		  if(File.Open("Option.sav",CFile::modeCreate|CFile::modeWrite))
   {
	   File.Write(&Option,sizeof(Option));
   }

	}

}

void CEWordView::OptionInit()
{
   Option.StudyNumber=20;
	 Option.ReviewNumber=20;
	 Option.Day1=1;
	 Option.Day2=2;
	 Option.Day3=4;
	 Option.Day4=8;
	 Option.Day5=16;

}



BOOL CEWordView::OnAddOk() 
{
	// TODO: Add your control notification handler code here
    
	BOOL IsNewWord=TRUE;
    m_bAdding = FALSE;
	CButton *pb=(CButton*)GetDlgItem(IDC_ADD_OK);
	pb->ShowWindow(SW_HIDE);
	//pb->SetReadOnly(FALSE);
	pb=(CButton*)GetDlgItem(IDC_ADD_CANCEL);
    pb->ShowWindow(SW_HIDE);
    CEdit* pCtrl = (CEdit*)GetDlgItem(IDC_WORD);
    int result = pCtrl->SetReadOnly(TRUE);
	pCtrl = (CEdit*)GetDlgItem(IDC_MEANS);
     pCtrl->SetReadOnly(TRUE);
    UpdateData(TRUE);
	m_pSet->MoveFirst();
	while(!m_pSet->IsEOF()&&IsNewWord)
	{
		if(m_pSet->m_column1==m_Spell)
			IsNewWord=FALSE;
		 m_pSet->MoveNext();
	};
    if((!IsNewWord)|(m_Spell.GetLength()<1))
	{
		m_pSet->MoveFirst();
		MessageBox("�õ����Ѵ��ڻ���󣬲��ܼ���ʿ�");
		return FALSE;
	}
     m_pSet->AddNew();
     m_pSet->m_column1=m_Spell;
	 m_pSet->m_column2=m_Meaning;
	 m_pSet->m_column4=0;
	 m_pSet->m_column5=0;
	 COleDateTime time;
	 time=time.GetCurrentTime();
	 m_pSet->m_column3=time;
      if (m_pSet->CanUpdate())
             m_pSet->Update();
        m_pSet->Requery();
	while(!m_pSet->IsEOF())
	{
		if(m_pSet->m_column1==m_Spell)
		break;
		 m_pSet->MoveNext();
	};
return (TRUE);
}



void CEWordView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
    CMenu Menu;
	Menu.LoadMenu(IDR_ADDMENU);
	pMenu=Menu.GetSubMenu(0);
	ASSERT(pMenu!=0);
	CPoint p=point;
	ClientToScreen(&p);
	pMenu->TrackPopupMenu(0,p.x,p.y,this);


	CDaoRecordView::OnRButtonDown(nFlags, point);
}

void CEWordView::OnChangeWord() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDaoRecordView::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	if(!m_bAdding)return;
     //CButton* pb=(CButton*)GetDlgItem(IDC_ADD_OK);
     //pb->EnableWindow(FALSE);
	 CEdit* pNewWord = (CEdit*)GetDlgItem(IDC_WORD);
	 CString m_NewWord;
	 pNewWord->GetWindowText(m_NewWord);
	 /*
	 if(m_NewWord.GetLength()>0)
	 {
       pb->EnableWindow(TRUE);
	 }
	 */
	int i=m_NewWord.Find(':');
	if(i>2)
	{
	m_Spell=m_NewWord.Left(i-1);
	//CEdit * pWord=(CEdit*)GetDlgItem(IDC_WORD);
	//pWord->SetWindowText(m_Word);
	int j;
	j=m_NewWord.GetLength();
	if(i>2&&j>4)
	{
	m_Meaning=m_NewWord.Right(j-i-2);
	//CEdit * pMeans=(CEdit*)GetDlgItem(IDC_MEANS);
	//pMeans->SetWindowText(m_Means);
	i=m_NewWord.ReverseFind('/');
		if(i>4)
         m_Meaning=m_NewWord.Right(j-i-1);   
	}
	UpdateData(FALSE);
}
}

void CEWordView::OnAddCancel() 
{
	// TODO: Add your control notification handler code here
	 m_bAdding = FALSE;
	CButton *pb=(CButton*)GetDlgItem(IDC_ADD_OK);
	pb->ShowWindow(SW_HIDE);
	//pb->SetReadOnly(FALSE);
	pb=(CButton*)GetDlgItem(IDC_ADD_CANCEL);
    pb->ShowWindow(SW_HIDE);
    CEdit* pCtrl = (CEdit*)GetDlgItem(IDC_WORD);
    int result = pCtrl->SetReadOnly(TRUE);
	pCtrl = (CEdit*)GetDlgItem(IDC_MEANS);
     pCtrl->SetReadOnly(TRUE);
        m_Spell=m_pSet->m_column1;
		 m_Meaning=m_pSet->m_column2;
		 UpdateData(FALSE);
}

void CEWordView::OnHelp() 
{
CString parth;
	CFile cFile;
     CString temp="eword2000.html";
	if(cFile.Open(temp,CFile::modeRead))
	{
		parth=cFile.GetFilePath();
		parth=parth.Left(parth.GetLength()-temp.GetLength());
		ShellExecute(::GetDesktopWindow(),"open","eword2000.html",
		NULL,parth,SW_SHOW );
	//	SW_SHOWMAXIMIZED );

	}
}

void CEWordView::JSAddWord()
{
       
	//	CMainFrame::OnAddWord();
		char *s;
		CString string;
	 if(OpenClipboard())
		 if(IsClipboardFormatAvailable (CF_TEXT))
		 {
		 HANDLE handle=GetClipboardData(CF_TEXT);
		 s=(char*)handle;
		 string=s;
		 }
		 CloseClipboard();
          int i=string.Find(" ");
		  int j=string.Find(":");
          if(i<2&&j!=(i-1)){
		 MessageBox("û��ѡ��Ҫ����ĵ���");
		 }
		  else
		  {
		  {
         if(string.GetLength()>100)
			 string=string.Left(100);
		 OnRecordAdd();
		 m_Spell=string;
		 UpdateData(FALSE);
         OnChangeWord();
		  }
		  CMainFrame * cwnd;
           cwnd=(CMainFrame*)GetParent();
		   if(!cwnd->IsWindowVisible( )) 
		   cwnd->OnAddWord();
    	}	
	
}

void CEWordView::ShowSmall ()
{
         CMainFrame * cwnd;
           cwnd=(CMainFrame*)GetParent();
		   cwnd->ShowWindow(SW_HIDE);
}

void CEWordView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default

char *s;
		CString string;
		if(OpenClipboard()){
		 if(IsClipboardFormatAvailable (CF_TEXT))
		 {
		 HANDLE handle=GetClipboardData(CF_TEXT);
		 s=(char*)handle;
		 string=s;
		 }
		 CloseClipboard();
          int i=string.Find(" ");
		  int j=string.Find(":");
          if(i>2&&j==(i+1)&&m_TempString!=string)
		  {
			  m_TempString=string;
			  JSAddWord();
		 	}
		 
    	}
	CDaoRecordView::OnTimer(nIDEvent);
}

int CEWordView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDaoRecordView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	SetTimer(0,1000,NULL);
	return 0;
}
