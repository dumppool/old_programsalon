// ReviewDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EWord.h"
#include "ReviewDlg.h"
#include "WordData.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReviewDlg dialog



CReviewDlg::CReviewDlg(OptionData Option1,CEWordSet* m_pSetTemp,CWnd* pParent /*=NULL*/)
	: CDialog(CReviewDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CReviewDlg)
	m_Spell = _T("");
	m_Means = _T("");
	m_Suggest = _T("");
	m_Time = 0;
	//}}AFX_DATA_INIT
	IsReview=FALSE;
	m_pSet=m_pSetTemp;
	Count=0;
	m_iTimeLimit=3;
	Option=Option1;
    //WordNumber=Option.ReviewNumber;
}


void CReviewDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReviewDlg)
	DDX_Text(pDX, IDC_REVIEW_LINE1, m_Spell);
	DDX_Text(pDX, IDC_REVIEW_LINE2, m_Means);
	DDX_Text(pDX, IDC_REVIEW_SUGGEST, m_Suggest);
	DDX_Text(pDX, IDC_REVIEW_TIMER, m_Time);
	DDX_Text(pDX, IDC_TIME_LIMIT, m_sTimeLimit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CReviewDlg, CDialog)
	//{{AFX_MSG_MAP(CReviewDlg)
	ON_BN_CLICKED(IDC_START_REVIEW, OnStartReview)
	ON_WM_CREATE()
	ON_MESSAGE(ID_TEST_BEGIN_REVIEW	,TestBegin)
	ON_EN_CHANGE(IDC_TIME_LIMIT, OnTimeLimitChange)
	ON_BN_CLICKED(IDC_STOP_REVIEW, OnStopReview)
	ON_EN_CHANGE(IDC_REVIEW_LINE2, OnChangeReviewLine2)
	ON_BN_CLICKED(IDC_REVIEW_SUGGESTION, OnReviewSuggestion)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReviewDlg message handlers

void CReviewDlg::OnStartReview() 
{
	// TODO: Add your control notification handler code here
    	SetWord();
	if(Count>=WordNumber)return;
	 IsReview=TRUE;

	if(WordNumber<1)
	{
		MessageBox("�Ѿ���ϰ�����е���!" );
			CButton *pCtrl=(CButton*)GetDlgItem(IDC_START_REVIEW);
         	pCtrl->EnableWindow(FALSE);
			IsReview=FALSE;
	}
	CButton *pCtrl=(CButton*)GetDlgItem(IDC_REVIEW_SUGGESTION);
	pCtrl->EnableWindow(FALSE);
	 m_Spell=m_Word[Count].Spell;
	 m_Means=m_Word[Count].Meaning;
	 UpdateData(FALSE);
}

int CReviewDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	 m_cTimeLimit.Create(WS_CHILD|WS_VISIBLE|WS_BORDER,
		  CRect(380,30,417,55),this,IDC_TIME_LIMIT);
	  m_UpDown.Create(WS_CHILD|WS_VISIBLE|WS_BORDER
		  |UDS_ALIGNRIGHT|UDS_SETBUDDYINT|UDS_ARROWKEYS,
		  CRect(0,0,0,0),this,IDC_REVIEW_UPDOWN);
	  m_UpDown.SetBuddy(&m_cTimeLimit);
	  m_UpDown.SetRange(1,10);
	  m_UpDown.SetPos(m_iTimeLimit);
	  m_sTimeLimit.Format("%i",m_UpDown.GetPos());
 	  SetTimer(0,1000,NULL);

	return 0;
}

void CReviewDlg::SetWord()
{
  
 int i=0;
  m_pSet->MoveFirst();
 while(i<Option.ReviewNumber&&!m_pSet->IsEOF())
 {
  
	COleDateTime Time,WordTime;
	int m_Day,m_Month,m_wDay,m_wMonth;

	Time=Time.GetCurrentTime(); 
		
	m_Day=Time.GetDay();
	m_Month=Time.GetMonth();
	 WordTime=m_pSet->m_column3;
	 m_wDay=WordTime.GetDay();
     m_wMonth=WordTime.GetMonth();
	 switch(m_pSet->m_column5)
  {		
		 
	   case 1:
			  m_Day+=(m_Month-m_wMonth)*30;
			if(m_Day>=(m_wDay+Option.Day1))
			{
				m_Word[i].Spell=m_pSet->m_column1;
	            m_Word[i].Meaning=m_pSet->m_column2;
	            m_Word[i].Times=0;
	            i++;
			}
	 		break;
		case 2:
			 m_Day+=(m_Month-m_wMonth)*30;
			 if((m_Day>=(m_wDay+Option.Day2))) 
			{
				m_Word[i].Spell=m_pSet->m_column1;
	            m_Word[i].Meaning=m_pSet->m_column2;
	            m_Word[i].Times=0;
	            i++;
			}

			break;
		case 3:
			 	 m_Day+=(m_Month-m_wMonth)*30;
			 if(m_Day>=(m_wDay+Option.Day3))
			{
				m_Word[i].Spell=m_pSet->m_column1;
	            m_Word[i].Meaning=m_pSet->m_column2;
	            m_Word[i].Times=0;
	            i++;
			}
			break;
		case 4:
		   	 m_Day+=(m_Month-m_wMonth)*30;
			 if(m_Day>=(m_wDay+Option.Day4))
			{
				m_Word[i].Spell=m_pSet->m_column1;
	            m_Word[i].Meaning=m_pSet->m_column2;
	            m_Word[i].Times=0;
	            i++;
			}
			break;
	  	 case 5:
		   	 m_Day+=(m_Month-m_wMonth)*30;
			 if(m_Day>=(m_wDay+Option.Day5))
			{
				m_Word[i].Spell=m_pSet->m_column1;
	            m_Word[i].Meaning=m_pSet->m_column2;
	            m_Word[i].Times=0;
	            i++;
			}
			break;

		default:
			break;
 }
   m_pSet->MoveNext();
}
 WordNumber=i-1;
}



void CReviewDlg::OnStopReview() 
{
	// TODO: Add your control notification handler code here
	IsReview=FALSE;
	
}

void CReviewDlg::TestBegin()
{
  if(Count>=WordNumber)
		{
		   	WordReset();
			MessageBox("�Ѿ���ϰ����鵥��");
			 IsReview=FALSE;
		     CButton *pC=(CButton*)GetDlgItem(IDC_START_REVIEW);
		     pC->EnableWindow();
		     CEdit* pCtrl=(CEdit*)GetDlgItem(IDC_REVIEW_LINE2);
		     pCtrl->SetReadOnly(TRUE);
			 Count=0;
			 return;
		}
		 CButton *pCtrl1=(CButton*)GetDlgItem(IDC_REVIEW_SUGGESTION);
    	pCtrl1->EnableWindow();
		CString Text="";
		if(Count>0)
		Text=m_Word[Count-1].Spell;
		 CEdit* pCtrl=(CEdit*)GetDlgItem(IDC_REVIEW_SUGGEST);
		m_Spell=m_Word[Count].Meaning;
		m_Means="";
	     UpdateData(FALSE);
		 pCtrl->SetWindowText(Text);
		  pCtrl=(CEdit*)GetDlgItem(IDC_REVIEW_LINE2);
		 pCtrl->SetReadOnly(FALSE);
		m_Means=m_Word[Count].Spell;

}

void CReviewDlg::OnChangeReviewLine2() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	  CString Text;
	 CEdit *pCtrl=(CEdit*)GetDlgItem(IDC_REVIEW_LINE2);
	 pCtrl->GetWindowText(Text);
	 if(Text==m_Means)
	 {
		 
		 Count++;
		 Sleep(500);
		// PostMessage(ID_TEST_BEGIN_REVIEW);
		 TestBegin();
	 }
	 int i;
	 i=Text.GetLength();
	// POINT *point;
	 //point=new POINT;
	  // GetCursorPos(point);
	 if(Text.Left(i)!=m_Means.Left(i)&&i>0)
	 { 
		 
		 pCtrl->SetWindowText(Text.Left(i-1));
		// SetCursorPos(point->x,point->y);
	 }

}

void CReviewDlg::WordReset()
{ int i=0;
  m_pSet->MoveFirst();
 while(i<WordNumber&&!m_pSet->IsEOF())
 {
  if(m_pSet->m_column1==m_Word[i].Spell)
  {
	  /*
	  m_pSet->Delete();
  	  m_pSet->MoveNext();
      if (m_pSet->IsEOF())
      m_pSet->MoveLast();
      if (m_pSet->IsBOF())
      m_pSet->SetFieldNull(NULL);
       UpdateData(FALSE);
		*/
	  m_pSet->Edit();
	  m_pSet->m_column5++;
	  COleDateTime time;
		time=time.GetCurrentTime();
		m_pSet->m_column3=time;
		m_pSet->m_column4+=m_Word[i].Times;
	  m_pSet->Update();
	  m_pSet->Edit();
	  i++;
	  /*
	  if (m_pSet->CanUpdate())
             m_pSet->Update();
         m_pSet->Requery();
		 i++;
		 */
 }
   m_pSet->MoveNext();
}
 



}

void CReviewDlg::OnReviewSuggestion() 
{
	// TODO: Add your control notification handler code here
	 CString Text;
	 CEdit *pCtrl=(CEdit*)GetDlgItem(IDC_REVIEW_LINE2);
	 pCtrl->GetWindowText(Text);
  	m_Suggest=m_Means.Left(Text.GetLength()+1);
	 pCtrl=(CEdit*)GetDlgItem(IDC_REVIEW_SUGGEST);
	 pCtrl->SetWindowText(m_Suggest);
	 m_Word[Count].Times++;

}

void CReviewDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	 	if(!IsReview)return;
   	m_Time--;
	 CString s;
     s.Format("%i",m_Time);
      CEdit * pCtrl=(CEdit*)GetDlgItem(IDC_REVIEW_TIMER);
     if(pCtrl)
        pCtrl->SetWindowText(s);
	if(m_Time==0)
	{
		m_Time=m_iTimeLimit;
		 m_UpDown.SetPos(m_Time);
		   m_sTimeLimit.Format("%i",m_UpDown.GetPos());
          m_Spell=m_Word[Count].Spell;
	    m_Means=m_Word[Count].Meaning;
	    UpdateData(FALSE);
		if(++Count>WordNumber)
		{ 
			IsReview=FALSE;
		    CButton *pC=(CButton*)GetDlgItem(IDC_START_REVIEW);
		     pC->EnableWindow(FALSE);
		    //PostMessage(ID_TEST_BEGIN_REVIEW);
             Count=0;
           TestBegin();
		}
		
	}

	CDialog::OnTimer(nIDEvent);
}
void CReviewDlg:: OnTimeLimitChange()
{
 m_iTimeLimit=m_UpDown.GetPos();
 m_Time=m_iTimeLimit;
 CString s;
 s.Format("%i",m_Time);
 CEdit * pCtrl=(CEdit*)GetDlgItem(IDC_REVIEW_TIMER);
 if(pCtrl)
 pCtrl->SetWindowText(s);
 
}

CReviewDlg::~CReviewDlg()
{
m_pSet->MoveFirst();
}
