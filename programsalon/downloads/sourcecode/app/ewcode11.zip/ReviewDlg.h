#if !defined(AFX_REVIEWDLG_H__68601DE3_B43D_11D2_AF1B_B00C48C10801__INCLUDED_)
#define AFX_REVIEWDLG_H__68601DE3_B43D_11D2_AF1B_B00C48C10801__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ReviewDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CReviewDlg dialog
#include "worddata.h"
 #include"EWordSet.h"

class CReviewDlg : public CDialog
{
// Construction
	CEWordSet* m_pSet;
	Word m_Word[40];

public:
	~CReviewDlg();
	OptionData Option;

	CReviewDlg(OptionData Option1,CEWordSet* m_pSetTemp,CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CReviewDlg)
	enum { IDD = IDD_REVIEWDLG };
	CString	m_Spell;
	CString	m_Means;
	CString	m_Suggest;
	CEdit	m_cTimeLimit;
	CSpinButtonCtrl	m_UpDown;
	int		m_Time;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReviewDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void WordReset();
	void SetWord();

	// Generated message map functions
	//{{AFX_MSG(CReviewDlg)
	afx_msg void OnStartReview();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnStopReview();
	afx_msg void OnChangeReviewLine2();
	afx_msg void OnReviewSuggestion();
	afx_msg void OnTimer(UINT nIDEvent);
	 afx_msg void OnTimeLimitChange();
	 afx_msg void TestBegin();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString m_sTimeLimit;
	int WordNumber;
	int m_iTimeLimit;
	int Count;
	BOOL IsReview;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REVIEWDLG_H__68601DE3_B43D_11D2_AF1B_B00C48C10801__INCLUDED_)
