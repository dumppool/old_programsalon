// EWordSet.cpp : implementation of the CEWordSet class
//

#include "stdafx.h"
#include "EWord.h"
#include "EWordSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEWordSet implementation

IMPLEMENT_DYNAMIC(CEWordSet, CDaoRecordset)

CEWordSet::CEWordSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CEWordSet)
	m_column1 = _T("");
	m_column2 = _T("");
	m_column3 = (DATE)0;
	m_column4 = 0;
	m_column5 = 0;
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
//	m_nDefaultType = snapshot;
}

CString CEWordSet::GetDefaultDBName()
{
	return _T("ew.mdb");
}

CString CEWordSet::GetDefaultSQL()
{
	return _T("[����]");

}

void CEWordSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoEWordSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[����]"), m_column1);
	DFX_Text(pFX, _T("[����]"), m_column2);
	DFX_DateTime(pFX, _T("[ѧϰ����]"), m_column3);
	DFX_Short(pFX, _T("[ѧϰ�̶�]"), m_column4);
	DFX_Short(pFX, _T("[��Ϥ�̶�]"), m_column5);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CEWordSet diagnostics

#ifdef _DEBUG
void CEWordSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CEWordSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
