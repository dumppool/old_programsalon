// HelpDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EWord.h"
#include "HelpDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHelpDlg dialog


CHelpDlg::CHelpDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHelpDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHelpDlg)
	m_HelpEdit = _T("");
	
	//}}AFX_DATA_INIT
	/*
    CFile file;
		if(file.Open("EWord2000.txt",CFile::modeRead|CFile::typeText))
			return;
	long filelength;
	filelength=file.GetLength();
	char *ch;
	ch=new char[filelength];
	file.Read(ch,sizeof(*ch));
	m_HelpEdit=ch;
	delete []ch;
	*/
}


void CHelpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHelpDlg)
	DDX_Text(pDX, IDC_HELPEDIT, m_HelpEdit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHelpDlg, CDialog)
	//{{AFX_MSG_MAP(CHelpDlg)
	ON_BN_CLICKED(IDC_SHellTest, OnSHellTest)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHelpDlg message handlers

void CHelpDlg::OnSHellTest() 
{
	// TODO: Add your control notification handler code here
	CString parth;
	CFile cFile;
     CString temp="eword2000.html";
	if(cFile.Open(temp,CFile::modeRead))
	{
		parth=cFile.GetFilePath();
		parth=parth.Left(parth.GetLength()-temp.GetLength());
		ShellExecute(::GetDesktopWindow(),"open","eword2000.html",
		NULL,parth,SW_SHOW );
	//	SW_SHOWMAXIMIZED );
	}
}
