// FlashDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EWord.h"
#include "FlashDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFlashDlg dialog


CFlashDlg::CFlashDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFlashDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFlashDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	Time=0;
}


void CFlashDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFlashDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFlashDlg, CDialog)
	//{{AFX_MSG_MAP(CFlashDlg)
	ON_WM_CREATE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFlashDlg message handlers

int CFlashDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
  //  DisplayBmp();
	SetTimer(0,1000,NULL);
	return 0;
}

void CFlashDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(Time++>1)
		EndDialog(TRUE);
	CDialog::OnTimer(nIDEvent);
}

BOOL CFlashDlg::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	KillTimer(0);
	return CDialog::DestroyWindow();
}
/*
void CFlashDlg::DisplayBmp()
{
 HBITMAP hBitmap=
		   ::LoadBitmap (AfxGetInstanceHandle(),
		   MAKEINTRESOURCE(IDB_BEGINBMP));
	   HDC hDc=::CreateCompatibleDC(NULL);
	   SelectObject(hDc,hBitmap);
	   StretchBlt(::GetDC(m_hWnd),0,0,300,300,
		   hDc,0,0,300,300,SRCCOPY);
	  // Sleep(1);
	   ::DeleteDC(hDc);
	   ::DeleteObject(hBitmap);
	  // CRect rect(150,150,300,300);
	  // ::InvalidateRect (::GetDesktopWindow(),
	//	   &rect,TRUE);
}
*/