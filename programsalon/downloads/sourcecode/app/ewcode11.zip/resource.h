//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EWord.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_EWORD_FORM                  101
#define IDC_STUDY_UPDOWN                101
#define IDC_TIME_LIMIT                  102
#define IDP_FAILED_OPEN_DATABASE        103
#define IDC_REVIEW_UPDOWN               103
#define ID_TEST_BEGIN_REVIEW            104
#define ID_ADD_WORD                     105
#define ID_SHOWMYWINDOW                 108
#define IDR_MAINFRAME                   128
#define IDR_EWORDTYPE                   129
#define IDI_RIGHT                       130
#define IDI_ERR                         131
#define IDD_STUDYDLG                    133
#define IDD_REVIEWDLG                   134
#define IDB_LEAF_BMP                    135
#define IDD_OPTIONDLG                   136
#define IDB_LEAF_BMP1                   137
#define IDB_TREE                        139
#define IDI_ICON1                       142
#define IDR_ADDMENU                     145
#define IDD_HELPDLG                     148
#define IDR_BEGINMENU                   150
#define IDR_CON2                        151
#define IDD_FLASHDLG                    152
#define IDB_BEGINBMP                    153
#define IDB_BEGINBMP1                   156
#define IDC_WORD                        1000
#define IDC_MEANS                       1001
#define IDC_NUMBER                      1002
#define IDC_ERR_CON                     1003
#define IDC_RIGHT_CON                   1004
#define IDC_STUDY_LINE1                 1005
#define IDC_STUDY_LINE2                 1006
#define IDC_STUDY_TIMER                 1008
#define IDC_START_STUDY                 1012
#define IDC_STOP_STUDY                  1013
#define IDC_STUDY_SUGGESTION            1014
#define IDC_STUDY_SUGGEST               1015
#define IDC_START_REVIEW                1016
#define IDC_REVIEW_SUGGESTION           1017
#define IDC_STOP_REVIEW                 1018
#define IDC_REVIEW_LINE1                1019
#define IDC_REVIEW_SUGGEST              1020
#define IDC_REVIEW_LINE2                1021
#define IDC_REVIEW_TIMER                1022
#define IDC_DAY_REVIEW                  1023
#define IDC_DAY_REVIEW2                 1024
#define IDC_STUDY_NUMBER                1025
#define IDC_STUDY_NUMBER_SPAN           1027
#define IDC_DAY_REVIEW3                 1028
#define IDC_DAY_REVIEW4                 1029
#define IDC_OPTION_INIT                 1030
#define IDC_DAY_REVIEW5                 1031
#define IDC_ADD_WORD                    1031
#define IDC_REVIEW_NUMBER               1032
#define IDC_ADD_OK                      1032
#define IDC_REVIEW_NUMBER_SPAN          1033
#define IDC_ADD_CANCEL                  1033
#define IDC_MAILTOME                    1034
#define IDC_RICHTEXTCTRL1               1037
#define IDC_HELPEDIT                    1038
#define IDC_STUDYOPTION                 1042
#define ID_RECORD_ADD                   32771
#define ID_RECORD_DELETE                32772
#define ID_WORD_STUDY                   32773
#define ID_WORD_REVIEW                  32774
#define IDC_OPTION                      32775
#define ID_DISPLAY                      32777
#define ID_SHOWMINAL                    32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        157
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
