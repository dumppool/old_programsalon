#if !defined(AFX_OPTIONDLG_H__16A36483_B500_11D2_AF1B_B05B4DC10500__INCLUDED_)
#define AFX_OPTIONDLG_H__16A36483_B500_11D2_AF1B_B05B4DC10500__INCLUDED_

#include "WordData.h"	// Added by ClassView
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// OptionDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptionDlg dialog

class COptionDlg : public CDialog
{
// Construction
public:
	OptionData Option;
	COptionDlg(OptionData Option1,CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(COptionDlg)
	enum { IDD = IDD_OPTIONDLG };
	int		m_rDay2;
	int		m_rDay3;
	int		m_rDay4;
	int		m_rDay5;
	int		m_rNumber;
	int		m_sNumber;
	int		m_rDay1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COptionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COptionDlg)
	virtual void OnOK();
	afx_msg void OnOptionInit();
	afx_msg void OnOutofmemoryReviewNumberSpan(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposReviewNumberSpan(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONDLG_H__16A36483_B500_11D2_AF1B_B05B4DC10500__INCLUDED_)
