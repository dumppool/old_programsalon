// StudyDlg.cpp : implementation file
//
const int ID_TEST_BEGIN=WM_USER+100;
#include "stdafx.h"
#include "EWord.h"
#include "StudyDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStudyDlg dialog
 


CStudyDlg::CStudyDlg(CEWordSet* m_pSetTemp,CWnd* pParent /*=NULL*/)
	: CDialog(CStudyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStudyDlg)
	m_Spell = _T("");
	m_Means = _T("");
	m_Time = 0;
	m_sTimeLimit = _T("");
	m_sSuggest = _T("");
	m_StudyOption = _T("ѧϰ����");
	//}}AFX_DATA_INIT
	IsStudy=FALSE;
	m_pSet=m_pSetTemp;
	Count=0;
	m_iTimeLimit=3;
    WordNumber=StudyNumber;
}


void CStudyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStudyDlg)
	DDX_Text(pDX, IDC_STUDY_LINE1, m_Spell);
	DDX_Text(pDX, IDC_STUDY_LINE2, m_Means);
	DDX_Text(pDX, IDC_STUDY_TIMER, m_Time);
	DDX_Text(pDX, IDC_TIME_LIMIT, m_sTimeLimit);
	DDX_Text(pDX, IDC_STUDY_SUGGEST, m_sSuggest);
	DDX_Text(pDX, IDC_STUDYOPTION, m_StudyOption);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStudyDlg, CDialog)
	//{{AFX_MSG_MAP(CStudyDlg)
	ON_WM_CREATE()
	ON_EN_CHANGE(IDC_TIME_LIMIT, OnTimeLimitChange)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_START_STUDY, OnStartStudy)
	ON_BN_CLICKED(IDC_STOP_STUDY, OnStopStudy)
	ON_MESSAGE(ID_TEST_BEGIN,OnTestBegin)
	ON_EN_CHANGE(IDC_STUDY_LINE2, OnChangeStudyLine2)
	ON_BN_CLICKED(IDC_STUDY_SUGGESTION, OnStudySuggestion)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStudyDlg message handlers
void CStudyDlg::SetWord()
{
 
 int i=0;
  m_pSet->MoveFirst();
 while(i<StudyNumber&&!m_pSet->IsEOF())
 {
  if(m_pSet->m_column5==0)
  {
	  m_Word[i].Spell=m_pSet->m_column1;
	  m_Word[i].Meaning=m_pSet->m_column2;
	  m_Word[i].Times=0;
	  i++;
	 
 }
   m_pSet->MoveNext();
}
 WordNumber=i-1;
}

int CStudyDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	  m_cTimeLimit.Create(WS_CHILD|WS_VISIBLE|WS_BORDER,
		  CRect(380,30,417,55),this,IDC_TIME_LIMIT);
	  m_UpDown.Create(WS_CHILD|WS_VISIBLE|WS_BORDER
		  |UDS_ALIGNRIGHT|UDS_SETBUDDYINT|UDS_ARROWKEYS,
		  CRect(0,0,0,0),this,IDC_STUDY_UPDOWN);
	  m_UpDown.SetBuddy(&m_cTimeLimit);
	  m_UpDown.SetRange(1,10);
	  m_UpDown.SetPos(m_iTimeLimit);
	  m_sTimeLimit.Format("%i",m_UpDown.GetPos());
 	  SetTimer(0,1000,NULL);
	return 0;
}

void CStudyDlg:: OnTimeLimitChange()
{
 m_iTimeLimit=m_UpDown.GetPos();
 m_Time=m_iTimeLimit;
 CString s;
 s.Format("%i",m_Time);
 CEdit * pCtrl=(CEdit*)GetDlgItem(IDC_STUDY_TIMER);
 if(pCtrl)
 pCtrl->SetWindowText(s);
 
}

void CStudyDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(!IsStudy)return;
   	m_Time--;
	 CString s;
     s.Format("%i",m_Time);
      CEdit * pCtrl=(CEdit*)GetDlgItem(IDC_STUDY_TIMER);
     if(pCtrl)
        pCtrl->SetWindowText(s);
	if(m_Time==0)
	{
	
        m_Time=m_iTimeLimit;
		 m_UpDown.SetPos(m_Time);
		   m_sTimeLimit.Format("%i",m_UpDown.GetPos());
		m_Spell=m_Word[Count].Spell;
	    m_Means=m_Word[Count].Meaning;
	    UpdateData(FALSE); 
		if(++Count>WordNumber)
		{ 
			IsStudy=FALSE;
		    CButton *pC=(CButton*)GetDlgItem(IDC_START_STUDY);
		     pC->EnableWindow(FALSE);
             Count=0;
		    //PostMessage(ID_TEST_BEGIN);
           // IsTest=TRUE;
           // CButton *pCtrl=(CButton*)GetDlgItem(IDC_START_STUDY);
         //	pCtrl->EnableWindow(TRUE);
		//	pCtrl->SetWindowText("��ʼ��ϰ");
			 m_StudyOption=_T("��ϰ����");
			 Test();
			}
	     
	}
	CDialog::OnTimer(nIDEvent);
}

void CStudyDlg::OnStartStudy() 
{
	// TODO: Add your control notification handler code here
   	SetWord();	
	if(Count>=WordNumber)return;
	 IsStudy=TRUE;
  		 	if(WordNumber<1)
	{
		MessageBox("�Ѿ�ѧϰ�����е���!" );
			CButton *pCtrl=(CButton*)GetDlgItem(IDC_START_REVIEW);
         	pCtrl->EnableWindow(FALSE);
			IsStudy=FALSE;
	}

	CButton *pCtrl=(CButton*)GetDlgItem(IDC_STUDY_SUGGESTION);
	pCtrl->EnableWindow(FALSE);
	 m_Spell=m_Word[Count].Spell;
	 m_Means=m_Word[Count].Meaning;
	 UpdateData(FALSE);
}

void CStudyDlg::OnStopStudy() 
{
	// TODO: Add your control notification handler code here
	IsStudy=FALSE;
}

void CStudyDlg::OnTestBegin()
{      
    
}

void CStudyDlg::OnChangeStudyLine2() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	 CString Text;
	 CEdit *pCtrl=(CEdit*)GetDlgItem(IDC_STUDY_LINE2);
	 pCtrl->GetWindowText(Text);
	 if(Text==m_Means)
	 {
		 Count++;
		 Sleep(500);
		// PostMessage(ID_TEST_BEGIN);
		 Test();
		 return;
	 }
	 int i;
	 i=Text.GetLength();
	 if(Text.Left(i)!=m_Means.Left(i)&&i>0)
	 { 
		 
		 pCtrl->SetWindowText(Text.Left(i-1));
		 }
	}

void CStudyDlg::WordReset()
{
  int i=0;
  m_pSet->MoveFirst();
 while(i<WordNumber&&!m_pSet->IsEOF())
 {
  if(m_pSet->m_column1==m_Word[i].Spell)
  {
	   m_pSet->Edit();
	  m_pSet->m_column5++;
	  COleDateTime time;
		time=time.GetCurrentTime();
		m_pSet->m_column3=time;
		m_pSet->m_column4+=m_Word[i].Times;
	  m_pSet->Update();
	  m_pSet->Edit();
	  i++;
	  
 }
   m_pSet->MoveNext();
}
 
}

void CStudyDlg::OnStudySuggestion() 
{
	// TODO: Add your control notification handler code here
	 CString Text;
	 CEdit *pCtrl=(CEdit*)GetDlgItem(IDC_STUDY_LINE2);
	 pCtrl->GetWindowText(Text);
  	m_sSuggest=m_Means.Left(Text.GetLength()+1);
	 pCtrl=(CEdit*)GetDlgItem(IDC_STUDY_SUGGEST);
	 pCtrl->SetWindowText(m_sSuggest);
	 m_Word[Count].Times++;
}

CStudyDlg::~CStudyDlg()
{
//KillTimer(0);
m_pSet->MoveFirst();
}

void CStudyDlg::Test()
{
	if(Count>=WordNumber)
		{
		   	WordReset();
			MessageBox("�Ѿ�ѧ����鵥��");
			 IsStudy=FALSE;
		     CButton *pC=(CButton*)GetDlgItem(IDC_START_STUDY);
		     pC->EnableWindow();
		     CEdit* pCtrl=(CEdit*)GetDlgItem(IDC_STUDY_LINE2);
		     pCtrl->SetReadOnly(TRUE);
			 Count=0;
			 return;
		}
		 CButton *pCtrl1=(CButton*)GetDlgItem(IDC_STUDY_SUGGESTION);
    	pCtrl1->EnableWindow();
		CString Text="";
		if(Count>0)
	    	Text=m_Word[Count-1].Spell;
		 CEdit* pCtrl=(CEdit*)GetDlgItem(IDC_STUDY_SUGGEST);
	    m_Spell=m_Word[Count].Meaning;

		m_Means="";
	    UpdateData(FALSE);
		pCtrl->SetWindowText(Text);
		 pCtrl=(CEdit*)GetDlgItem(IDC_STUDY_LINE2);
		 pCtrl->SetReadOnly(FALSE);
		m_Means=m_Word[Count].Spell;
}
