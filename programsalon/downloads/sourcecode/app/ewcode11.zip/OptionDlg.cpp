// OptionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EWord.h"
#include "OptionDlg.h"
#include "WordData.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptionDlg dialog


COptionDlg::COptionDlg(OptionData Option1,CWnd* pParent /*=NULL*/)
	: CDialog(COptionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COptionDlg)
	 Option=Option1;

	m_rDay2 = Option.Day2;
	m_rDay3 = Option.Day3;
	m_rDay4 = Option.Day4;
	m_rDay5 = Option.Day5;
	m_rNumber = Option.ReviewNumber;
	m_sNumber = Option.StudyNumber;
	 
	 m_rDay1=Option.Day1;

	//}}AFX_DATA_INIT
}


void COptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptionDlg)
	DDX_Text(pDX, IDC_DAY_REVIEW2, m_rDay2);
	DDX_Text(pDX, IDC_DAY_REVIEW3, m_rDay3);
	DDX_Text(pDX, IDC_DAY_REVIEW4, m_rDay4);
	DDX_Text(pDX, IDC_DAY_REVIEW5, m_rDay5);
	DDX_Text(pDX, IDC_REVIEW_NUMBER, m_rNumber);
	DDV_MinMaxInt(pDX, m_rNumber, 0, 40);
	DDX_Text(pDX, IDC_STUDY_NUMBER, m_sNumber);
	DDV_MinMaxInt(pDX, m_sNumber, 0, 40);
	DDX_Text(pDX, IDC_DAY_REVIEW, m_rDay1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptionDlg, CDialog)
	//{{AFX_MSG_MAP(COptionDlg)
	ON_BN_CLICKED(IDC_OPTION_INIT, OnOptionInit)
	ON_NOTIFY(NM_OUTOFMEMORY, IDC_REVIEW_NUMBER_SPAN, OnOutofmemoryReviewNumberSpan)
	ON_NOTIFY(UDN_DELTAPOS, IDC_REVIEW_NUMBER_SPAN, OnDeltaposReviewNumberSpan)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionDlg message handlers

void COptionDlg::OnOK() 
{
	// TODO: Add extra validation here
	 UpdateData(TRUE);
	 Option.Day1=m_rDay1;
	 Option.Day2=m_rDay2;
	 Option.Day3=m_rDay3;
	 Option.Day4=m_rDay4;
	 Option.Day5=m_rDay5;
     Option.ReviewNumber=	 m_rNumber;
	 Option.StudyNumber =m_sNumber;
	
	CDialog::OnOK();
}



void COptionDlg::OnOptionInit() 
{
	// TODO: Add your control notification handler code here
	 Option.StudyNumber=20;
	 Option.ReviewNumber=20;
	 Option.Day1=1;
	 Option.Day2=2;
	 Option.Day3=4;
	 Option.Day4=8;
	 Option.Day5=16;
	 m_rDay2 = Option.Day2;
	m_rDay3 = Option.Day3;
	m_rDay4 = Option.Day4;
	m_rDay5 = Option.Day5;
	m_rNumber= Option.ReviewNumber;
	m_sNumber = Option.StudyNumber;
	 m_rDay1=Option.Day1;
	 UpdateData(FALSE);
}

void COptionDlg::OnOutofmemoryReviewNumberSpan(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void COptionDlg::OnDeltaposReviewNumberSpan(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if(m_rNumber>40)
	{
		m_rNumber=0;
        UpdateData(FALSE);
	}
	*pResult = 0;
}
