// EWordDoc.h : interface of the CEWordDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_EWORDDOC_H__C8E0A8AF_42A1_11D2_AF1B_001A48C10500__INCLUDED_)
#define AFX_EWORDDOC_H__C8E0A8AF_42A1_11D2_AF1B_001A48C10500__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CEWordDoc : public CDocument
{
protected: // create from serialization only
	CEWordDoc();
	DECLARE_DYNCREATE(CEWordDoc)

// Attributes
public:
	CEWordSet m_eWordSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEWordDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEWordDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CEWordDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EWORDDOC_H__C8E0A8AF_42A1_11D2_AF1B_001A48C10500__INCLUDED_)
