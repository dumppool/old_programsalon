// EWordDoc.cpp : implementation of the CEWordDoc class
//

#include "stdafx.h"
#include "EWord.h"

#include "EWordSet.h"
#include "EWordDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEWordDoc

IMPLEMENT_DYNCREATE(CEWordDoc, CDocument)

BEGIN_MESSAGE_MAP(CEWordDoc, CDocument)
	//{{AFX_MSG_MAP(CEWordDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEWordDoc construction/destruction

CEWordDoc::CEWordDoc()
{
	// TODO: add one-time construction code here

}

CEWordDoc::~CEWordDoc()
{
}

BOOL CEWordDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CEWordDoc diagnostics

#ifdef _DEBUG
void CEWordDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CEWordDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEWordDoc commands
