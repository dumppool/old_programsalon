#ifndef _WORDDATA_H
#define _WORDDATA_H
struct Word
{
	CString Spell;
	CString Meaning;
	int Times;
};

 struct OptionData{
	int StudyNumber;
	int ReviewNumber;
	int Day1;
	int Day2;
	int Day3;
	int Day4;
	int Day5;
};


#endif