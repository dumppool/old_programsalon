#if !defined(AFX_STUDYDLG_H__4E840AC5_B1E1_11D2_AF1B_B01848C10500__INCLUDED_)
#define AFX_STUDYDLG_H__4E840AC5_B1E1_11D2_AF1B_B01848C10500__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// StudyDlg.h : header file
//
#include"WordData.h"
#include"EWordSet.h"
#define ID_TEST_BEGIN WM_USER+100
/////////////////////////////////////////////////////////////////////////////
// CStudyDlg dialog


class CStudyDlg : public CDialog
{
// Construction
public:
	void Test();
	~CStudyDlg();
	int StudyNumber;
	void WordReset();
	void SetWord();
	CStudyDlg(CEWordSet* m_pSetTemp,CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CStudyDlg)
	enum { IDD = IDD_STUDYDLG };
	CEdit	m_cTimeLimit;
	CSpinButtonCtrl	m_UpDown;
	CString	m_Spell;
	CString	m_Means;
	int		m_Time;
	CString	m_sTimeLimit;
	int m_iTimeLimit;
	CString	m_sSuggest;
	CString	m_StudyOption;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStudyDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CEWordSet* m_pSet;
	Word m_Word[40];

	// Generated message map functions
	//{{AFX_MSG(CStudyDlg)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	 afx_msg void OnTimeLimitChange();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnStartStudy();
	afx_msg void OnStopStudy();
	afx_msg void OnTestBegin();
	afx_msg void OnChangeStudyLine2();
	afx_msg void OnStudySuggestion();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:

	int WordNumber;
	int Count;
	BOOL IsStudy;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STUDYDLG_H__4E840AC5_B1E1_11D2_AF1B_B01848C10500__INCLUDED_)
