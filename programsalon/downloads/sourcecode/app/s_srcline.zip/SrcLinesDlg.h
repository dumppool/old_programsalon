// SrcLinesDlg.h : header file
//

#if !defined(AFX_SRCLINESDLG_H__BF50A1A8_0588_11D3_8556_B0344DC10001__INCLUDED_)
#define AFX_SRCLINESDLG_H__BF50A1A8_0588_11D3_8556_B0344DC10001__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//
#include "HyperLink.h"
#include "BtnST.h"
#include "HoverButton.h"
/////////////////////////////////////////////////////////////////////////////
// CSrcLinesDlg dialog

class CSrcLinesDlg : public CDialog
{
// Construction
public:
	unsigned long m_lCpp;
	unsigned long m_lC;
	CSrcLinesDlg(CWnd* pParent = NULL);	// standard constructor
	~CSrcLinesDlg ();
// Dialog Data
	//{{AFX_DATA(CSrcLinesDlg)
	enum { IDD = IDD_SRCLINES_DIALOG };
	CHoverButton	m_btnC;
	CHoverButton    m_btnCpp;
	CButtonST	m_btnExit;
	CButtonST	m_btnOpen;
	CButtonST	m_btnAbout;
	DWORD	m_lCppLines;
	DWORD	m_lHeaderLines;
	DWORD	m_lTotalLines;
	CString	m_stcSource;
	UINT m_nSelected;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSrcLinesDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSrcLinesDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnOpenfile();
	afx_msg void OnRadiocpp();
	afx_msg void OnRadioc();
	afx_msg void OnAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int RefreshButtons(int nSelected = 0);
	UINT nSelected;
	void SetupRadioBtns();
	void SetupFlatBtns();
	CString GetFileExt(LPCTSTR lpszFile);
	unsigned long GetFileLines(char* &lpBuf, unsigned long lSize);
	void SetupEditCtrls();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SRCLINESDLG_H__BF50A1A8_0588_11D3_8556_B0344DC10001__INCLUDED_)
