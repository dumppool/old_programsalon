//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SrcLines.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SRCLINES_DIALOG             102
#define IDS_FILEFILTER                  102
#define IDR_MAINFRAME                   128
#define IDB_RBU                         129
#define IDI_OK                          130
#define IDB_RBF                         130
#define IDB_LOGO                        131
#define IDI_EXIT                        132
#define IDB_RBX                         132
#define IDI_ABOUT                       133
#define IDI_OPEN                        134
#define IDB_RBD                         137
#define IDC_HAND                        144
#define IDC_OPENFILE                    1000
#define IDC_ABOUT                       1001
#define IDC_CPPLINES                    1002
#define IDC_HEADERLINES                 1003
#define IDC_TOTALLINES                  1004
#define IDC_STATIC_CORCPP               1007
#define IDC_WEB                         1010
#define IDC_EMAIL                       1011
#define IDC_BTNCPP                      1015
#define IDC_BTNC                        1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
