// SrcLinesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SrcLines.h"
#include "SrcLinesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CHyperLink	m_web;
	CButtonST	m_btnOk;
	CHyperLink m_email;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_WEB, m_web);
	DDX_Control(pDX, IDOK, m_btnOk);
	DDX_Control(pDX, IDC_EMAIL, m_email);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSrcLinesDlg dialog

CSrcLinesDlg::CSrcLinesDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSrcLinesDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSrcLinesDlg)
	m_lC = 0;
	m_lCpp = 0;
	m_lCppLines = 0;
	m_lHeaderLines = 0;
	m_lTotalLines = 0;
	m_stcSource = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CSrcLinesDlg::~CSrcLinesDlg ()
{
}

void CSrcLinesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSrcLinesDlg)
	DDX_Control(pDX, IDC_BTNC, m_btnC);
	DDX_Control(pDX, IDC_BTNCPP, m_btnCpp);
	DDX_Control(pDX, IDOK, m_btnExit);
	DDX_Control(pDX, IDC_OPENFILE, m_btnOpen);
	DDX_Control(pDX, IDC_ABOUT, m_btnAbout);
	DDX_Text(pDX, IDC_CPPLINES, m_lCppLines);
	DDX_Text(pDX, IDC_HEADERLINES, m_lHeaderLines);
	DDX_Text(pDX, IDC_TOTALLINES, m_lTotalLines);
	DDX_Text(pDX, IDC_STATIC_CORCPP, m_stcSource);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSrcLinesDlg, CDialog)
	//{{AFX_MSG_MAP(CSrcLinesDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_OPENFILE, OnOpenfile)
	ON_BN_CLICKED(IDC_BTNCPP, OnRadiocpp)
	ON_BN_CLICKED(IDC_BTNC, OnRadioc)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSrcLinesDlg message handlers

BOOL CSrcLinesDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	SetupEditCtrls ();
	SetupFlatBtns ();
	SetupRadioBtns ();
	m_stcSource = " *.CPP�ļ�����";
	UpdateData ( false );

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSrcLinesDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSrcLinesDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSrcLinesDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSrcLinesDlg::OnOpenfile() 
{
// Construct a file open dialog and show it for 
// selecting source file
	CString strFilter;
	strFilter.LoadString ( IDS_FILEFILTER );
	char pBuffer[255*255] = "";
//	
	CFileDialog dlgOpen ( 
		true, NULL, NULL, 
		OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY | 
		OFN_ENABLESIZING | OFN_OVERWRITEPROMPT,
		strFilter, NULL );
	dlgOpen.m_ofn.lpstrTitle = "��ѡ��Դ�ļ�";
	// Pointer to file name buffer
	dlgOpen.m_ofn.lpstrFile = pBuffer;
	// Max number of files you can open once
	dlgOpen.m_ofn.nMaxFile = sizeof ( pBuffer );
	//
	if ( dlgOpen.DoModal () == IDOK )
	{
		POSITION pos;
		pos = dlgOpen.GetStartPosition ();
		CString strFile = "";
		unsigned long lLines = 0;	// One source file lines
		unsigned long lTotal = 0;	// Total source file lines
		unsigned long lCpp = 0;		// Cpp source file lines
		unsigned long lC = 0;		// C source file lines
		unsigned long lHeader = 0;  // Header file lines
		while ( pos )
		{
			CFile cFile;
			CFileException e;
			// Get file name one by one
			strFile= dlgOpen.GetNextPathName ( pos );
			// If open file successful
			if ( cFile.Open ( strFile, CFile::modeRead, &e ) )
			{
				unsigned long lSize = cFile.GetLength ();
				char *pBuf = new char[lSize];
				if ( !pBuf )  // Out of memory
					MessageBox ( 
						"\n\n  �ڴ治��!�޷����ļ�!  ",
						"�޷����ļ�!" );
				else		  // Alloc memory success
				{
					cFile.ReadHuge ( pBuf, lSize );
					lLines = GetFileLines ( pBuf,lSize );
					CString strExt = "";
					strExt = GetFileExt ( strFile );
					if ( "cpp" == strExt )
						lCpp += lLines;
					else if ( "c" == strExt )
						lC += lLines;
					else if ( "h"  == strExt || "hpp" == strExt )
						lHeader += lLines;
					lTotal += lLines; // Total lines

					if ( pBuf )		  // Release memory
						delete []pBuf;
				}
				cFile.Close ();		// Close file manually
			}				// End of if ( cFile.Opne...)
		}					// End of while ( pos )	
		// Record cpp & c file lines
		m_lC = lC;			// C file lines
		m_lCpp = lCpp;		// Cpp file lines

		// Show cpp & header file lines		  
		if ( m_btnCpp.GetButtonState () ==  BUTTON_ON )
			m_lCppLines = lCpp;
		else
			m_lCppLines = lC;
		m_lHeaderLines = lHeader;
		// Show total file lines
		m_lTotalLines = lTotal;

		UpdateData ( false );
	}						// End of if ( IDOK == ... )
}							// End of OnFileOpen

void CSrcLinesDlg::SetupEditCtrls()
{
	UpdateData ();
}

unsigned long CSrcLinesDlg::GetFileLines(char* &lpBuf, unsigned long lSize)
{
	// Counter
	unsigned long lLines = 0;
	for ( unsigned long i = 0; i < lSize; i++ )
		if ( '\n' == lpBuf[i] )
			lLines++;
	// Return lines of source file
	return lLines;
}

CString CSrcLinesDlg::GetFileExt(LPCTSTR lpszFile)
{
	CString strExt = "";
	CString name ( lpszFile );
	UINT nSize = 0;
	nSize = name.GetLength ();
	name.MakeLower ();
	if ( 'h' == name.GetAt ( nSize - 1 ) && 
		 '.' == name.GetAt ( nSize - 2 ) )	// Found it is a header file
		strExt = "h";
	else if ( 'c' == name.GetAt ( nSize - 1 ) &&
		      '.' == name.GetAt ( nSize - 2 ) )
		strExt = "c";						// C file
	else if ( 'p' == name.GetAt ( nSize - 1 ) &&
			  'p' == name.GetAt ( nSize - 2 ) )
	{
		if ( 'c' == name.GetAt ( nSize - 3 ) )
			strExt = "cpp";					// Cpp file
		else if ( 'h' == name.GetAt ( nSize - 3 ) )
			strExt = "hpp";					// Hpp file
	}
	// Return extension of specified file
	return strExt;
}

void CSrcLinesDlg::OnRadiocpp() 
{
	m_stcSource = " *.CPP�ļ�����";
	m_lCppLines = m_lCpp;	// Load cpp file lines

	RefreshButtons ();
	UpdateData ( false );
}

void CSrcLinesDlg::OnRadioc() 
{
	m_stcSource = " *.C�ļ�����";
	m_lCppLines = m_lC;		// Load c file lines

	RefreshButtons ( 1 );
	UpdateData ( false );		
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_email.SetURL ( "mailto:anty@990.net" );
	m_email.SetLinkCursor ( AfxGetApp()->LoadCursor ( IDC_HAND ) );
	m_web.SetURL ( "antbaby.126.com" );
	m_web.SetLinkCursor ( AfxGetApp()->LoadCursor ( IDC_HAND ) );
	//Add flat button ok
	m_btnOk.SubclassDlgItem ( IDI_OK, this );
	m_btnOk.SetIcon ( IDI_OK );
	m_btnOk.AddToolTip ( "����" );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSrcLinesDlg::OnAbout() 
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal ();
}

void CSrcLinesDlg::SetupFlatBtns()
{
// Flat button open
	m_btnOpen.SubclassDlgItem ( IDI_OPEN, this );
	m_btnOpen.SetIcon ( IDI_OPEN );
	m_btnOpen.SetShowText ( false );
	m_btnOpen.AddToolTip ( "��Դ�ļ�" );
// Flat button about
	m_btnAbout.SubclassDlgItem ( IDI_ABOUT, this );
	m_btnAbout.SetIcon ( IDI_ABOUT );
	m_btnAbout.SetShowText ( false );
	m_btnAbout.AddToolTip ( "����SrcLines..." );
// Flat button exit
	m_btnExit.SubclassDlgItem ( IDI_EXIT, this );
	m_btnExit.SetIcon ( IDI_EXIT );
	m_btnExit.SetShowText ( false );
	m_btnExit.AddToolTip ( "����û����^_^" );
}

void CSrcLinesDlg::SetupRadioBtns()
{
	m_btnCpp.LoadBitmaps ( IDB_RBU, IDB_RBD, IDB_RBF, IDB_RBX );	
	m_btnC.LoadBitmaps ( IDB_RBU, IDB_RBD, IDB_RBF, IDB_RBX );
	RefreshButtons ( 0 );
}

int CSrcLinesDlg::RefreshButtons(int nSelected)
{
	m_btnCpp.SetButtonState( BUTTON_OFF );
	m_btnC.SetButtonState( BUTTON_OFF );
	if ( nSelected == 1 )
	{
		m_nSelected = nSelected;
		m_btnC.SetButtonState ( BUTTON_ON );
	}
	else if ( nSelected == 0 )
	{
		m_nSelected = nSelected;
		m_btnCpp.SetButtonState ( BUTTON_ON );
	}

	return m_nSelected;
}
