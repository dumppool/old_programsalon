//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by lovepet.rc
//
#define IDS_TOOLTIP_EXIT                1
#define IDS_TOOLTIP_BROWER              2
#define IDC_BROWSE                      4
#define IDC_BROWSE1                     4
#define IDC_BROWSE2                     5
#define IDD_LITTLEPIG_DIALOG            102
#define IDD_ScrGenius_DIALOG            102
#define IDD_LOVEPET_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDI_ROSE                        154
#define IDR_POPUP                       164
#define IDB_SHUTDOWN                    166
#define IDB_EXIT                        167
#define IDB_EJECT                       168
#define IDB_EMAIL                       169
#define IDB_REGISTER                    170
#define IDB_CLOSE                       174
#define IDB_SHOW                        175
#define IDB_HIDE                        176
#define IDB_BAR                         177
#define IDB_CHECKED                     182
#define IDB_CHECK                       183
#define IDD_GetIP                       184
#define IDC_PET                         185
#define IDB_GETIP                       186
#define IDD_BMP2TXT                     192
#define IDB_BMP2TXT                     193
#define IDD_ABOUT                       196
#define IDB_HELP                        197
#define IDD_CUSTOMWAVE                  198
#define IDB_CUSTOM                      199
#define IDB_CHECK1                      200
#define IDB_CHECKED1                    201
#define IDB_BIG2GB                      205
#define IDD_BIG2GB                      206
#define IDD_HIDEINBMP                   221
#define IDB_HIDEINBMP                   222
#define IDC_HAND                        224
#define IDI_FILEOPEN                    230
#define IDC_DROP                        234
#define IDD_FILESPLIT                   236
#define IDB_FILESPLIT                   237
#define IDD_REGOCX                      242
#define IDD_EDSTAR                      243
#define IDB_EDSTAR                      244
#define IDB_REGOCX                      245
#define IDD_SETTIME_SHUTDOWN            246
#define IDC_BUTTON1                     1000
#define IDC_BUTTON_MERGE                1000
#define IDC_DECRYPT                     1000
#define IDC_PicRose                     1001
#define IDC_RADIO1                      1001
#define IDC_REGOCX                      1001
#define IDC_PASSWORD                    1001
#define IDC_LOVEPET                     1002
#define IDC_RADIO2                      1002
#define IDC_UNREGOCX                    1002
#define IDC_PATH1                       1002
#define IDC_GETIP                       1003
#define IDC_SHOWDESKTOP                 1003
#define IDC_ENCRYPT                     1003
#define IDC_EDIT1                       1004
#define IDC_COMBOX_FILESIZE             1004
#define IDC_DIRBROWSER                  1005
#define IDC_FILENAME                    1005
#define IDC_BUTTON_SHUTDOWN             1005
#define IDC_EDIT2                       1006
#define IDC_SHUTDOWN                    1006
#define IDC_FILEBROWSER                 1007
#define IDC_REBOOT                      1007
#define IDC_DATETIMEPICKER1             1009
#define IDC_MAIL                        1010
#define IDC_PATH                        1012
#define IDC_FILEBROWSER1                1013
#define IDC_PATH2                       1013
#define IDC_HELPFILE                    1014
#define IDC_PROGRESS1                   1015
#define IDC_HIDEFILE                    1016
#define IDC_STATIC_NOW                  1016
#define IDC_PROGRESS                    1017
#define IDC_RADIO3                      1018
#define IDC_CHECK1                      1018
#define IDC_RADIO4                      1019
#define IDC_PARTS                       1035
#define IDR_SHOW                        32771
#define IDR_HIDE                        32772
#define IDR_EMAIL                       32773
#define IDR_REGISTER                    32774
#define IDR_SHUTDOWN                    32775
#define IDR_EJECT                       32776
#define IDR_CLOSE                       32777
#define IDR_EXIT                        32778
#define IDR_MUTE                        32789
#define IDR_GETIP                       32790
#define IDR_BMP2TXT                     32791
#define IDR_HELP                        32792
#define IDR_CUSTOMWAVFILE               32793
#define IDR_BIG2GB                      32794
#define IDR_HIDEINBMP                   32795
#define IDR_REGOCX                      32796
#define IDR_EDSTAR                      32797

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        247
#define _APS_NEXT_COMMAND_VALUE         32798
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
