//---------------------------------------------------------------------------
#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>
#include <ToolWin.hpp>
#include <ExtCtrls.hpp>
#include <ImgList.hpp>
#include <ActnList.hpp>
#include <Dialogs.hpp>
#include <Db.hpp>
#include <DBClient.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TMainMenu *MainMenu1;
        TToolBar *ToolBar1;
        TTreeView *TreeView1;
        TSplitter *Splitter1;
        TListView *ListView1;
        TStatusBar *StatusBar1;
        TImageList *ImageList1;
        TActionList *ActionList1;
        TAction *itemAbout;
        TAction *itemExt;
        TAction *itemAddCD;
        TAction *itemDelCD;
        TAction *itemFindCD;
        TAction *itemAddSoft;
        TAction *itemDelSoft;
        TAction *itemFindSoft;
        TMenuItem *R1;
        TMenuItem *recAddCD;
        TMenuItem *recDelCD;
        TMenuItem *recAddSoft;
        TMenuItem *recDelSoft;
        TMenuItem *N3;
        TMenuItem *recFindCD;
        TMenuItem *recFindSoft;
        TToolButton *tbAddCD;
        TToolButton *tbDelCD;
        TToolButton *tbDelSoft;
        TToolButton *ToolButton4;
        TToolButton *tbFindCD;
        TToolButton *tbFindSoft;
        TToolButton *tbAbout;
        TToolButton *tbAddSoft;
        TMenuItem *itemHelp;
        TMenuItem *hlpAbout;
        TMenuItem *itemFile;
        TMenuItem *filExt;
        TToolButton *ToolButton3;
        TAction *itemNew;
        TAction *itemOpen;
        TMenuItem *filNew;
        TMenuItem *filOpen;
        TMenuItem *N1;
        TToolButton *tbNew;
        TToolButton *tbOpen;
        TToolButton *ToolButton6;
        TOpenDialog *OpenDialog1;
        TClientDataSet *ClientDataSet1;
        TClientDataSet *ClientDataSet2;
        TPopupMenu *PopupMenu1;
        TPopupMenu *PopupMenu2;
        TMenuItem *pmAddCD;
        TMenuItem *pmDelCD;
        TMenuItem *pmFindCD;
        TMenuItem *pmAddSF;
        TMenuItem *pmDelSF;
        TMenuItem *pmFindSF;
        TMenuItem *pmModiSF;
        TAction *itemFindNext;
        TToolButton *tbFindNext;
        TMenuItem *recFindNext;
        TAction *itemSave;
        TToolButton *tbSave;
        TMenuItem *filSave;
        TMenuItem *Phtml1;
        TAction *itemOutput;
        TAction *itemConfig;
        TMenuItem *N2;
        TMenuItem *C1;
        void __fastcall itemAboutExecute(TObject *Sender);
        void __fastcall itemExtExecute(TObject *Sender);
        void __fastcall itemAddCDExecute(TObject *Sender);
        void __fastcall itemAddSoftExecute(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall itemFindCDExecute(TObject *Sender);
        void __fastcall itemFindSoftExecute(TObject *Sender);
        void __fastcall itemNewExecute(TObject *Sender);
        void __fastcall itemOpenExecute(TObject *Sender);
        void __fastcall FormPaint(TObject *Sender);
        void __fastcall TreeView1Change(TObject *Sender, TTreeNode *Node);
        void __fastcall itemDelCDExecute(TObject *Sender);
        void __fastcall itemDelSoftExecute(TObject *Sender);
        void __fastcall ListView1Change(TObject *Sender, TListItem *Item,
          TItemChange Change);
        void __fastcall TreeView1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall ListView1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall TreeView1Edited(TObject *Sender, TTreeNode *Node,
          AnsiString &S);
        void __fastcall TreeView1Editing(TObject *Sender, TTreeNode *Node,
          bool &AllowEdit);
        void __fastcall itemFindNextExecute(TObject *Sender);
        void __fastcall pmModiSFClick(TObject *Sender);
        void __fastcall ListView1DblClick(TObject *Sender);
        void __fastcall StatusBar1DblClick(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall itemSaveExecute(TObject *Sender);
        void __fastcall itemConfigExecute(TObject *Sender);
        void __fastcall itemOutputExecute(TObject *Sender);
private:	// User declarations
        void __fastcall ShowHint(TObject *);
    void __fastcall OpenCDBFile(AnsiString filename);
    void __fastcall OutputHTML(TObject * Sender, bool isLink);
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
        TList * pList;

};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
