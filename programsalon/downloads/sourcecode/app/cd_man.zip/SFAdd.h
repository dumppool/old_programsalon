//---------------------------------------------------------------------------
#ifndef SFAddH
#define SFAddH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TForm4 : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TEdit *edFileName;
        TButton *btBrowse;
        TLabel *Label2;
        TEdit *edSoftName;
        TLabel *Label3;
        TEdit *edDescription;
        TButton *btOK;
        TOpenDialog *OpenDialog1;
        void __fastcall btBrowseClick(TObject *Sender);
        void __fastcall edFileNameChange(TObject *Sender);
        void __fastcall btOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm4(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm4 *Form4;
//---------------------------------------------------------------------------
#endif
