//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USEFORM("main.cpp", Form1);
USEFORM("about.cpp", AboutBox);
USEFORM("CDAdd.cpp", Form3);
USEFORM("SFAdd.cpp", Form4);
USEFORM("CDFind.cpp", Form5);
USEUNIT("SerchDisk.cpp");
USEFORM("ModiSF.cpp", Form2);
USEFORM("config.cpp", Form6);
USEFORM("ProgressBar.cpp", Form7);
USERC("cdpacket.rc");
USERES("CDPacket.res");
//---------------------------------------------------------------------------
AnsiString cdbname;
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR str, int)
{
        try
        {
                 Application->Initialize();
                 Application->Title = "ѧ躵��ӹ��̲�";
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->CreateForm(__classid(TForm5), &Form5);
                 Application->CreateForm(__classid(TForm2), &Form2);
                 Application->CreateForm(__classid(TForm3), &Form3);
                 Application->CreateForm(__classid(TForm4), &Form4);
                 Application->CreateForm(__classid(TForm6), &Form6);
                 Application->CreateForm(__classid(TForm7), &Form7);
                 cdbname=str;
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
