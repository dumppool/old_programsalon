//---------------------------------------------------------------------------
#ifndef CDAddH
#define CDAddH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <FileCtrl.hpp>
//---------------------------------------------------------------------------
class TForm3 : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TDriveComboBox *DriveComboBox1;
        TEdit *Edit1;
        TLabel *Label2;
        TButton *btOK;
        TCheckBox *CheckBox1;
        TLabel *Label3;
        TEdit *Edit2;
        TCheckBox *CheckBox2;
        void __fastcall DriveComboBox1Change(TObject *Sender);
        void __fastcall Edit2Change(TObject *Sender);
        void __fastcall btOKClick(TObject *Sender);
private:
    AnsiString __fastcall GetSWName(AnsiString str);	// User declarations
public:		// User declarations
        __fastcall TForm3(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm3 *Form3;
//---------------------------------------------------------------------------
#endif
