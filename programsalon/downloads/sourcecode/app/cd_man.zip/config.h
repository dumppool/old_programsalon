//---------------------------------------------------------------------------
#ifndef configH
#define configH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TForm6 : public TForm
{
__published:	// IDE-managed Components
        TListBox *ListBox1;
        TEdit *Edit1;
        TButton *btAdd;
        TButton *btDel;
        TCheckBox *cbBind;
        TCheckBox *cbLink;
        TLabel *Label1;
        TButton *btOk;
        TButton *btCancel;
        void __fastcall btOkClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall Edit1Change(TObject *Sender);
        void __fastcall btAddClick(TObject *Sender);
        void __fastcall btDelClick(TObject *Sender);
        void __fastcall btCancelClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm6(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm6 *Form6;
//---------------------------------------------------------------------------
#endif
