// TransparentWnd.cpp : implementation file
//
// Modified by �쾰��. 2000.12
//���ܣ�͸��λͼ��WAV��Դ����

#include "stdafx.h"
#include "West.h"
#include "TransparentWnd.h"
#include "BCMenu.h"  //����λͼ�˵�
#include "WestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BCMenu popmenu;  //����λͼ�˵�����
/////////////////////////////////////////////////////////////////////////////
// TransparentWnd

TransparentWnd::TransparentWnd()
{
	m_iAniSeq=0; //ͼ��仯��ʼֵ
}

TransparentWnd::~TransparentWnd()
{
}

BEGIN_MESSAGE_MAP(TransparentWnd, CWnd)
	//{{AFX_MSG_MAP(TransparentWnd)
	ON_WM_LBUTTONDOWN()
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_TIMER()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(IDR_HELP, OnHelp)
	ON_COMMAND(IDR_EXIT, OnExit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//********************************************************************************
//* CreateTransparent()
//*
//* Creates the main application window transparent
//********************************************************************************
void TransparentWnd::CreateTransparent(LPCTSTR pTitle, RECT &rect)
{
	// ����һ�����ش���
	CreateEx(   0,  
		AfxRegisterWndClass(0,AfxGetApp()->LoadStandardCursor(IDC_ARROW)),
				pTitle,
				WS_POPUP ,
				rect,
				NULL,
				NULL,
			    NULL);
	DoChange();
}

//********************************************************************************
//* SetupRegion()
//*
//* Set the Window Region for transparancy outside the mask region
//********************************************************************************
void TransparentWnd::SetupRegion(CDC *pDC)
{
	CDC					memDC;
	CBitmap			&cBitmap=m_bmpDraw;
	CBitmap*		pOldMemBmp = NULL;
	COLORREF		col,colMask;
	CRect				cRect;
	int					x, y;
	CRgn				wndRgn, rgnTemp;

	GetWindowRect(&cRect);
	CPoint ptOrg=cRect.TopLeft();

	BITMAP bmInfo;
	cBitmap.GetObject(sizeof(bmInfo),&bmInfo);
	CRect rcNewWnd=CRect(ptOrg,CSize(bmInfo.bmWidth,bmInfo.bmHeight));

	memDC.CreateCompatibleDC(pDC);
	pOldMemBmp = memDC.SelectObject(&cBitmap);
	colMask=memDC.GetPixel(0,0);

	wndRgn.CreateRectRgn(0, 0, rcNewWnd.Width(), rcNewWnd.Height());
	for(x=0; x<=rcNewWnd.Width(); x++)
	{
		for(y=0; y<=rcNewWnd.Height(); y++)
		{
			col = memDC.GetPixel(x, y);
			if(col == colMask)
			{
				rgnTemp.CreateRectRgn(x, y, x+1, y+1);
				wndRgn.CombineRgn(&wndRgn, &rgnTemp, RGN_XOR);
				rgnTemp.DeleteObject();	
			}
		}
	}
	if (pOldMemBmp) memDC.SelectObject(pOldMemBmp);
	SetWindowRgn((HRGN)wndRgn, TRUE);
	MoveWindow(rcNewWnd);
}

void TransparentWnd::DoChange(void)
{
  char szBmp[20];
  
   //�����滻ͼ��
   sprintf(szBmp,"WEST%d",m_iAniSeq%2+1);

	m_bmpDraw.DeleteObject();
	m_bmpDraw.LoadBitmap(szBmp);
	CWindowDC dc(this);
	SetupRegion(&dc);
	Invalidate();

	
}

void TransparentWnd::SoundPlay(void)
{
 //�ȹر�ԭ��������
	PlaySound("WEST",AfxGetResourceHandle(),SND_RESOURCE|SND_PURGE|SND_NODEFAULT  ); 
    SetTimer(2,61080,NULL); //���ò�������ʱ��61.08��
	 //��ԴWAV�ļ���ID���˫���ţ�����API��������
    PlaySound("WEST",AfxGetResourceHandle(),SND_RESOURCE|SND_ASYNC|SND_NODEFAULT  ); 
}

void TransparentWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{

	CWnd::OnLButtonDown(nFlags, point);

	//ʵ���ޱ����϶�
	PostMessage(WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM(point.x,point.y)); 	
}

int TransparentWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
    SetTimer(1,1000,NULL);  //��ʼʱ��ͼ����ʾʱ��
    SetTimer(2,500,NULL); //�����������ż�ʱ��

	SetWindowPos(&wndTopMost,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE); //����������ǰ��	
	return 0;
}

BOOL TransparentWnd::OnEraseBkgnd(CDC* pDC) 
{
    CRect	rect;
	GetWindowRect(&rect);

	CDC memDC;
	CBitmap			&cBitmap=m_bmpDraw;;
	CBitmap*		pOldMemBmp = NULL;
	CFont* pOldMemFont=NULL;

	memDC.CreateCompatibleDC(pDC);
	pOldMemBmp = memDC.SelectObject(&cBitmap);
	pDC->BitBlt(0, 0, rect.Width(), rect.Height(), &memDC, 0, 0, SRCCOPY);

	if (pOldMemBmp) memDC.SelectObject( pOldMemBmp );

	return TRUE;	
//	return CWnd::OnEraseBkgnd(pDC);
}

void TransparentWnd::OnTimer(UINT nIDEvent) 
{
   switch(nIDEvent)
	{
	case(1)://�任ͼ��
		DoChange();
		break;
	case(2): //��������
		SoundPlay();
		break;
	default:
		break;
	}
	m_iAniSeq++; 
	if(m_iAniSeq==2)
      m_iAniSeq=0;
	
	CWnd::OnTimer(nIDEvent);
}

void TransparentWnd::OnRButtonDown(UINT nFlags, CPoint point) 
{
	
	CWnd::OnRButtonDown(nFlags, point);

   //�����Ҽ����ͼ��˵�(��������ʽ�˵�)
  popmenu.LoadMenu(IDR_MENU);
 
  popmenu.ModifyODMenu(NULL, IDR_HELP,IDB_HELP);
  popmenu.ModifyODMenu(NULL,IDR_EXIT,IDB_EXIT);
  
  ClientToScreen(&point);
  BCMenu *psub = (BCMenu *)popmenu.GetSubMenu(0); 
  psub->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON,point.x,point.y,this);
  popmenu.DestroyMenu();
}

void TransparentWnd::OnHelp() 
{
	CWestDlg dlg; 

	//�˶Ի���ֻ��ʾһ��
  if( !FindWindow(NULL,"����"))
	    dlg.DoModal();	
}

void TransparentWnd::OnExit() 
{
  DestroyWindow();	
}
