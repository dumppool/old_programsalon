// West.h : main header file for the WEST application
//

#if !defined(AFX_WEST_H__C7595E24_DE5B_11D4_9003_9BEC1FC0EBE6__INCLUDED_)
#define AFX_WEST_H__C7595E24_DE5B_11D4_9003_9BEC1FC0EBE6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CWest:
// See West.cpp for the implementation of this class
//

class CWest : public CWinApp
{
public:
	CWest();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWest)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CWest)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WEST_H__C7595E24_DE5B_11D4_9003_9BEC1FC0EBE6__INCLUDED_)
