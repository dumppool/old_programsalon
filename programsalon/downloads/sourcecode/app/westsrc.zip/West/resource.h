//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by West.rc
//
#define IDD_WEST_DIALOG                 102
#define IDD_WEST                        102
#define IDR_MAINFRAME                   128
#define IDR_MENU                        134
#define IDB_HELP                        135
#define IDB_EXIT                        136
#define IDC_EDIT1                       1004
#define IDC_MAIL                        1010
#define IDR_HELP                        32771
#define IDR_EXIT                        32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
